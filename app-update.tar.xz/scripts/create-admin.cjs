// =============================================================
// ORDOMOTIK - Seed: create/update admin & demo users
// Schema tables are created by sqlite3 CLI in Dockerfile CMD
// This script ONLY handles user seeding
// =============================================================

const { hash } = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

// FIX-SEED : le modèle "Home" n'existe pas dans le schéma ConcergerieHub
// (résidu du template ORDOMOTIK/QR Domotik). Il faisait planter le script
// AVANT la création de l'utilisateur démo → identifiants client inopérants.

async function seedUsers() {
  // Super Admin
  const adminHash = await hash('QrDomotik2024!', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@qrdomotik.roomscan.pro' },
    update: { passwordHash: adminHash, fullName: 'Administrateur ORDOMOTIK', role: 'superadmin' },
    create: {
      email: 'admin@qrdomotik.roomscan.pro',
      fullName: 'Administrateur ORDOMOTIK',
      passwordHash: adminHash,
      role: 'superadmin',
    },
  });
  console.log('[seed] Super Admin OK:', admin.email);

  // Demo Client — mot de passe aligné sur le bouton "Client Demo" du
  // formulaire de connexion (src/components/auth/login-form.tsx → Demo2024!)
  const demoHash = await hash('Demo2024!', 12);
  const demo = await prisma.user.upsert({
    where: { email: 'demo@qrdomotik.roomscan.pro' },
    update: { passwordHash: demoHash, fullName: 'Utilisateur Demo', role: 'user' },
    create: {
      email: 'demo@qrdomotik.roomscan.pro',
      fullName: 'Utilisateur Demo',
      passwordHash: demoHash,
      role: 'user',
    },
  });
  console.log('[seed] Demo Client OK:', demo.email);
}

async function main() {
  try {
    await seedUsers();
    console.log('[seed] Done.');
  } catch (err) {
    console.error('[seed] Fatal error:', err.message);
    console.error(err.stack);
  } finally {
    await prisma.$disconnect();
  }
}

main();