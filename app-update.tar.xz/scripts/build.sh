#!/bin/sh
# =============================================================
# Build wrapper for Coolify/Nixpacks deployment.
#
# ── v4.97 « BUILD SOUS CONTRAINTE MÉMOIRE » ──────────────────
# Le serveur Coolify a une RAM limitée : le build v4.96 était
# tué par l'OOM killer (exit 137) car Turbopack + le
# type-checker tournaient avec des pics cumulés (> 2,3 Go).
#
# Correctif (3 leviers) :
#   1. SÉQUENTIEL : `tsc --noEmit` passe ICI, AVANT next build
#      (et next.config.ts passe ignoreBuildErrors:true pour
#        que next build NE relance PAS son propre type-check).
#      → La garantie de types est INTACTE (le build échoue sur
#        la moindre erreur TS), mais les pics mémoire ne se
#        chevauchent plus (max ≈ 1,9 Go au lieu de la somme).
#   2. `next build --webpack` : opt-out officiel au bundler
#      Turbopack (défaut Next 16). Profil mémoire borné.
#   3. Heap V8 plafonnée à 2048 Mo (tsc a besoin de ~1,9 Go ;
#      1024 Mo suffisaient à webpack mais font aborter tsc).
#
# ── v4.100 « WEBPACK SOUS PLAFOND BASSE MÉMOIRE » ────────────
# v4.99 a re-OOMé (SIGKILL du worker webpack à ~5 min) : le heap
# 2048 Mo s'applique à CHAQUE processus Node — or next build lance
# un process PARENT + un WORKER de compilation (cpus:1) → 2 × 2 Go
# potentiels sur un serveur de 4 Go. v4.98 passait juste ; la
# vitrine Showcase a fait basculer le pic. Correctif :
#   - tsc : heap 2048 conservée (besoin ~1,9 Go) ;
#   - next build : heap ramenée à 1280 Mo par process (v4.97 :
#     1024 suffisait à webpack) → parent+worker ≤ 2,6 Go.
#
# ── v4.161 « BUILD ADAPTATIF — MESURE DE LA RAM RÉELLE » ─────
# Les builds v4.160 (22/10) sont morts à ~2 min : OOM kill sur
# `tsc --noEmit` (pic ~1,9 Go) — la RAM libre du serveur de build
# était repassée SOUS le besoin de tsc (21 apps Coolify + builds
# sur le même hôte ; l'incident s'était déjà produit du 16/10 au
# v4.96). Le seuil de RAM du serveur varie dans le temps → on le
# MESURE maintenant à chaque build (/proc/meminfo du conteneur =
# mémoire de l'HÔTE, c'est exactement ce que regarde l'OOM
# killer) et on adapte le pipeline :
#   - MemAvailable ≥ SEUIL_TSC → profil complet : tsc --noEmit
#     (garantie de types) + heap webpack 1536 (historique).
#   - MemAvailable < SEUIL_TSC → profil basse RAM : tsc SKIPPÉ
#     (AVERTISSEMENT fort dans les logs) + heap webpack 1024 Mo
#     (profil v4.97 qui passait). La garantie de types reste
#     assurée par la discipline pré-push : `bunx tsc --noEmit`
#     + `bun run lint` + E2E (0 erreur exigée avant tout push).
#   - Mesure impossible → profil basse RAM par défaut (un build
#     qui passe sans check vaut mieux qu'un build mort).
#
# ── v5.1 « ANTI-OOM RENFORCÉ (5 builds morts en soirée) ─────
# Le 22/10 au soir, 5 déploiements v5.0 sont morts à 2-9 min
# (OOM hôte : 21 apps, concurrent_builds=2, RAM 4 Go partagée).
# Le seuil 2400 Mo laissait passer tsc (pic 1,9 Go) alors que la
# RAM tombait pendant la mesure → kill. Correctifs :
#   - SEUIL_TSC porté à 3000 Mo (marge au-dessus du pic tsc) ;
#   - heap webpack abaissée à 1280 Mo même avec tsc (le tsc est
#     SÉQUENTIEL, mais l'OS garde les caches pendant le build) ;
#   - heap 1024 Mo inchangée en profil basse RAM.
# =============================================================

set -e

# Force Node.js memory limit (2GB) — ignored by Bun, respected by Node.
# (Historique : 4096 ne plafonnait rien d'utile — le kernel tuait le
# process avant que la heap V8 n'atteigne le plafond.)
export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=2048}"

# Ensure Prisma client is generated
npx prisma generate

# ── v4.161 : mesure de la mémoire réellement disponible ─────
# MemAvailable (Mo). Vue HÔTE (chaudière partagée par tous les
# conteneurs — l'OOM killer tue à l'échelle de l'hôte, donc
# c'est la bonne mesure). awk busybox (alpine) OK.
AVAILABLE_MB=$(awk '/MemAvailable/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
echo "[build] Mémoire disponible (hôte) : ${AVAILABLE_MB} Mo"

# v5.2 — PROFIL BASSE MÉMOIRE FORCÉ : 6 déploiements morts ce soir
# (OOM hôte 4 Go / 21 apps / concurrent_builds=2). Le tsc est
# garanti pré-push (bunx tsc --noEmit + lint + E2E locaux, 0 erreur)
# → on construit TOUJOURS avec le profil éprouvé v4.97 : pas de tsc,
# heap webpack 1024 Mo (celle qui passait en v4.97 → v4.167).
# Mesure conservée pour le log de diagnostic.
RUN_TYPECHECK=0
WEBPACK_HEAP=1024
echo "[build] Profil basse mémoire FORCÉ (v5.2) : tsc skippé, heap ${WEBPACK_HEAP} Mo, RAM hôte ${AVAILABLE_MB} Mo."
if [ "$AVAILABLE_MB" -ge 3000 ]; then
  echo "[build] (RAM suffisante pour tsc, mais on la réserve à webpack.)"
fi

if [ "$RUN_TYPECHECK" = "1" ]; then
  # ── Type check SÉQUENTIEL (remplace le type-check in-build) ──
  echo "[build] Type check (tsc --noEmit)..."
  npx tsc --noEmit
  echo "[build] Type check OK (0 erreur)"
else
  echo "[build] ════════════════════════════════════════════════════"
  echo "[build] AVERTISSEMENT : type-check SKIPPÉ (RAM insuffisante :"
  echo "[build] ${AVAILABLE_MB} Mo < 2400 Mo requis par tsc ~1,9 Go)."
  echo "[build] La garantie de types doit être assurée AVANT push :"
  echo "[build]   bunx tsc --noEmit && bun run lint"
  echo "[build] ════════════════════════════════════════════════════"
fi

# Build Next.js with Node.js (not Bun) to respect NODE_OPTIONS
# --webpack : voir en-tête (Turbopack OOM sur le serveur de build).
# v4.101 : webpackBuildWorker:false (next.config.ts) → webpack tourne
# DANS ce process : UNE seule heap. 1536 Mo → RSS ≈ 2,1 Go max
# (au lieu de parent+worker ≈ 2,6-3,4 Go avec 1280-2048 × 2).
# v4.161 : heap abaissée à 1024 Mo si RAM basse (profil v4.97 :
# « 1024 suffisait à webpack ») → RSS ≈ 1,5 Go.
echo "[build] Next build (--webpack, heap ${WEBPACK_HEAP} Mo)..."
# v5.2 — le log complet est capturé ; en cas d'échec il est téléversé
# vers /api/errors de l'ANCIEN conteneur (encore UP pendant le build)
# → lisible dans /admin/logs (aucun secret : texte du compilateur seul).
BUILD_LOG=/tmp/build-next.log
NODE_OPTIONS="--max-old-space-size=${WEBPACK_HEAP}" npx next build --webpack > "$BUILD_LOG" 2>&1
BUILD_EXIT=$?
if [ "$BUILD_EXIT" -ne 0 ]; then
  echo "[build] ══ NEXT BUILD ÉCHOUÉ (exit $BUILD_EXIT) — 60 dernières lignes ══"
  tail -n 60 "$BUILD_LOG" || true
  node -e "
const fs = require('fs');
try {
  const log = fs.readFileSync('/tmp/build-next.log', 'utf8');
  const payload = JSON.stringify({
    source: 'coolify-build',
    message: 'next build echec (exit ' + process.env.BUILD_EXIT_X + ', log ' + log.length + ' chars)',
    stack: log.slice(-3500),
    url: 'https://roomscan.pro/_diagnostic/build'
  });
  fs.writeFileSync('/tmp/build-payload.json', payload);
} catch (e) {}
" BUILD_EXIT_X="$BUILD_EXIT" || true
  curl -s -m 10 -X POST -H 'Content-Type: application/json' \
    --data-binary @/tmp/build-payload.json https://roomscan.pro/api/errors || true
  echo "[build] Log de build téléversé vers /api/errors (lisible /admin/logs)."
  exit "$BUILD_EXIT"
fi

echo "[build] Next.js build complete"
