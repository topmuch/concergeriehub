// =============================================================
// v4.97 « ÉTAT DES LIEUX » — MODULE STANDALONE — LIB PDF (pdfkit)
//
// Document juridique généré à la volée pour le formulaire invité
// public : renderStandaloneInspectionPdf(). L'invité signe via
// roomscan.pro/i/<token>, le PDF est téléchargé depuis
// /api/inspection/pdf/<token>.
//
// Style STRICT et JURIDIQUE : A4 marge 48, Helvetica pour le corps,
// Times-Bold pour les titres majuscules, filets gris fins, accents
// FR OK — AUCUN émoji (fontes PDF standard). En-tête : logo RoomScan
// à gauche (public/brand/roomscan-logo.png, lu depuis le disque) +
// QR code de vérification en ligne à droite (lib qrcode, import
// dynamique, échec toléré). Photos & signature : Buffers décodés
// depuis les dataURL (try/catch par image — un dataURL invalide ne
// fait JAMAIS planter le PDF).
// pdfkit est externalisé (serverExternalPackages) — import dynamique
// dans la fonction pour éviter tout souci ESM/CJS.
// =============================================================

import { readFile } from 'fs/promises';
import path from 'path';
import { inspectionDocumentId } from './inspection-hash';
import { isElectronicItem } from './inspection-template';

// Type de l'instance PDFKit (module typé `export = doc` → typeof).
type PdfDoc = typeof import('pdfkit');

// ---------- Types d'entrée ----------

export interface StandalonePdfItem {
  name: string;
  state: string; // 'TRES_BON' | 'BON' | 'MOYEN' | 'MAUVAIS'
  comment?: string | null;
  photoUrl?: string | null; // dataURL (jpeg/png) — défaut signalé
  photoOnUrl?: string | null; // appareil électronique ALLUMÉ
  photoOffUrl?: string | null; // appareil électronique ÉTEINT
}

export interface StandalonePdfRoom {
  name: string;
  globalState: string; // 'TRES_BON' | 'BON' | 'MOYEN' | 'MAUVAIS'
  comment?: string | null;
  items: StandalonePdfItem[];
}

export interface StandaloneInspectionPdfData {
  inspection: {
    publicToken: string;
    propertyName: string;
    propertyAddress: string;
    ownerName: string;
    guestName: string;
    type: string; // 'ENTREE' | 'SORTIE'
    scheduledDate: Date;
    status: string; // 'PENDING' | 'IN_PROGRESS' | 'COMPLETED'
    signedAt?: Date | null;
    completedAt?: Date | null;
    cleanlinessScore?: string | null;
    cleanlinessComment?: string | null;
    /** dataURL de la photo de propreté (annexe). */
    cleanlinessPhotoUrl?: string | null;
    guestSignature?: string | null;
    /** Date de l'EDL d'entrée lié (SORTIE uniquement). */
    linkedEntranceDate?: Date | null;
    // ── Preuve & anti-fraude (v4.110) ──
    /** Ville légale (« Fait à … ») — fallback : 1re partie de l'adresse. */
    city?: string | null;
    /** Empreinte SHA-256 du contenu canonique (calculée à la signature). */
    sha256Hash?: string | null;
    /** Position GPS de l'invité à la signature (optionnelle). */
    gpsLocation?: string | null;
    /** Adresse IP de signature (stockée serveur). */
    ipAddress?: string | null;
  };
  rooms: StandalonePdfRoom[];
}

// ---------- Constantes ----------

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 48;
const CONTENT_W = PAGE_W - MARGIN * 2; // 499.28

const INK = '#111827';
const MUTED = '#6B7280';
const LINE = '#d4d4d8'; // zinc-300
const BOX_BG = '#f4f4f5'; // zinc-100
const ROW_LINE = '#e4e4e7'; // zinc-200

// Bandeau d'en-tête « Bouclier » : dégradé noir → rouge sombre.
const BAND_H = 108;
const BAND_INK = '#ffffff';
const BAND_MUTED = '#e7d5d3';

/** Couleurs d'état — palette discrète vert / vert / ambre / rouge. */
const STATE_COLORS: Record<string, string> = {
  TRES_BON: '#15803d',
  BON: '#4d7c0f',
  MOYEN: '#b45309',
  MAUVAIS: '#b91c1c',
};
const STATE_LABELS: Record<string, string> = {
  TRES_BON: 'Très bon',
  BON: 'Bon',
  MOYEN: 'Moyen',
  MAUVAIS: 'Mauvais',
};
const CLEAN_COLORS: Record<string, string> = {
  IMPECCABLE: '#15803d',
  CORRECT: '#4d7c0f',
  A_NETTOYER: '#b45309',
  TRES_SALE: '#b91c1c',
};
const CLEAN_LABELS: Record<string, string> = {
  IMPECCABLE: 'Impeccable',
  CORRECT: 'Correct',
  A_NETTOYER: 'À nettoyer',
  TRES_SALE: 'Très sale',
};

const frDateTime = (d: Date) =>
  d.toLocaleString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

const frDate = (d: Date) =>
  d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

// ---------- Logo RoomScan (copie du pattern inspection-pdf.ts) ----------

const ROOMSCAN_LOGO_REL = path.join('brand', 'roomscan-logo.png');
let roomScanLogoCache: Buffer | null | undefined;

async function loadRoomScanLogo(): Promise<Buffer | null> {
  if (roomScanLogoCache !== undefined) return roomScanLogoCache;
  const cwd = process.cwd();
  const candidates = [
    path.join(cwd, 'public', ROOMSCAN_LOGO_REL),
    path.join(cwd, '.next', 'standalone', 'public', ROOMSCAN_LOGO_REL),
  ];
  for (const p of candidates) {
    try {
      const buf = await readFile(p);
      if (buf.length > 0) {
        roomScanLogoCache = buf;
        return buf;
      }
    } catch {
      // fichier absent — candidat suivant
    }
  }
  roomScanLogoCache = null;
  return null;
}

// ---------- Helpers ----------

/** Décode un dataURL (image/png|jpeg) en Buffer — null si invalide. */
function decodeDataUrl(dataUrl: unknown): Buffer | null {
  if (typeof dataUrl !== 'string') return null;
  const match = dataUrl.match(/^data:image\/(png|jpeg|jpg);base64,([\s\S]+)$/);
  if (!match) return null;
  try {
    const buf = Buffer.from(match[2], 'base64');
    return buf.length > 0 ? buf : null;
  } catch {
    return null;
  }
}

/** Décale en nouvelle page si l'espace restant est insuffisant. */
function ensureSpace(doc: PdfDoc, needed: number): void {
  if (doc.y + needed > PAGE_H - MARGIN - 34) doc.addPage();
}

/** Libellé sûr d'un état (jamais de texte technique brut si inconnu). */
function stateLabel(state: string): string {
  return STATE_LABELS[state] ?? state;
}
function stateColor(state: string): string {
  return STATE_COLORS[state] ?? INK;
}

/** Pied de page légal sur TOUTES les pages + pagination X / Y. */
function drawFooters(
  doc: PdfDoc,
  opts: { city: string; generatedAt: Date },
): void {
  const range = doc.bufferedPageRange();
  const legal =
    `Fait à ${opts.city}, le ${frDate(opts.generatedAt)}. ` +
    'Ce document numérique signé électroniquement a valeur juridique.';
  // Les pieds sont écrits SOUS la marge basse : pdfkit ajouterait une
  // page à chaque texte qui dépasse maxY — on neutralise donc la marge
  // basse de CHAQUE page (chacune a ses propres marges) le temps du
  // dessin, puis on restaure sur la page courante.
  for (let i = 0; i < range.count; i++) {
    doc.switchToPage(i);
    const savedBottom = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    doc
      .font('Helvetica')
      .fontSize(7)
      .fillColor(MUTED)
      .text(legal, MARGIN, PAGE_H - 40, { width: CONTENT_W, lineBreak: false });
    doc
      .font('Helvetica')
      .fontSize(7.5)
      .fillColor(MUTED)
      .text(`Page ${i + 1} / ${range.count}`, MARGIN, PAGE_H - 28, {
        width: CONTENT_W,
        align: 'center',
        lineBreak: false,
      });
    doc.page.margins.bottom = savedBottom;
  }
}

/** Titre de section (Times-Bold + filet fin). */
function sectionTitle(doc: PdfDoc, title: string): void {
  ensureSpace(doc, 46);
  doc.moveDown(0.4);
  doc.font('Times-Bold').fontSize(12.5).fillColor(INK).text(title, MARGIN, doc.y, {
    width: CONTENT_W,
  });
  doc
    .moveTo(MARGIN, doc.y + 3)
    .lineTo(PAGE_W - MARGIN, doc.y + 3)
    .lineWidth(0.75)
    .strokeColor(LINE)
    .stroke();
  doc.y += 12;
}

/** Rangée « libellé : valeur » à l'intérieur du bloc infos gris. */
function infoRow(doc: PdfDoc, label: string, value: string, valW: number): void {
  const y = doc.y;
  doc.font('Helvetica').fontSize(9).fillColor(MUTED).text(label, MARGIN + 12, y, {
    width: 100,
    lineBreak: false,
  });
  doc.font('Helvetica').fontSize(9).fillColor(INK).text(value, MARGIN + 116, y, {
    width: valW,
  });
  doc.x = MARGIN;
  doc.moveDown(0.2);
}

/**
 * En-tête « Bouclier » (v4.110) : bandeau pleine largeur en dégradé
 * noir → rouge sombre, logo RoomScan sur pastille blanche à gauche,
 * titre « ÉTAT DES LIEUX CERTIFIÉ » centré en blanc, ID unique du
 * document (RS-XXXXXX) et date/heure de génération à droite. Aucun
 * de ces éléments ne fait planter le document (logo absent →
 * pastille seule, le PDF ne plante jamais).
 */
async function drawHeader(doc: PdfDoc, data: StandaloneInspectionPdfData): Promise<void> {
  const generatedAt = new Date();

  // — Bandeau dégradé (pleine largeur, débords de marge inclus) —
  doc.save();
  const grad = doc.linearGradient(0, 0, PAGE_W, BAND_H);
  grad.stop(0, '#16161a');
  grad.stop(0.55, '#3d1a18');
  grad.stop(1, '#7f1d1d');
  doc.rect(0, 0, PAGE_W, BAND_H).fill(grad);
  doc.restore();

  // — Pastille blanche + logo (à gauche) —
  const chipX = MARGIN;
  const chipY = (BAND_H - 56) / 2;
  const chipW = 64;
  const chipH = 56;
  doc.save();
  doc.roundedRect(chipX, chipY, chipW, chipH, 8).fill('#ffffff');
  doc.restore();
  const logo = await loadRoomScanLogo();
  if (logo) {
    try {
      doc.image(logo, chipX + 6, chipY + 6, { fit: [chipW - 12, chipH - 12] });
    } catch {
      // logo illisible — pastille blanche seule, le PDF ne plante jamais.
    }
  }

  // — Titre centré (entre logo et bloc ID) —
  const titleX = chipX + chipW + 10;
  const rightW = 132;
  const titleW = CONTENT_W - chipW - 10 - rightW - 10;
  const isEntree = data.inspection.type !== 'SORTIE';
  doc
    .font('Times-Bold')
    .fontSize(14)
    .fillColor(BAND_INK)
    .text('ÉTAT DES LIEUX CERTIFIÉ', titleX, chipY + 6, {
      width: titleW,
      align: 'center',
      lineBreak: false,
    });
  doc
    .font('Helvetica')
    .fontSize(7)
    .fillColor(BAND_MUTED)
    .text(
      isEntree
        ? "État des lieux d'entrée — document contradictoire"
        : 'État des lieux de sortie — document contradictoire',
      titleX,
      chipY + 28,
      { width: titleW, align: 'center', lineBreak: false },
    );
  doc
    .font('Helvetica')
    .fontSize(6.5)
    .fillColor(BAND_MUTED)
    .text('roomscan.pro · module États des Lieux', titleX, chipY + 40, {
      width: titleW,
      align: 'center',
      lineBreak: false,
    });

  // — Bloc droit : ID unique + date/heure de génération —
  doc
    .font('Helvetica-Bold')
    .fontSize(10)
    .fillColor(BAND_INK)
    .text(inspectionDocumentId(data.inspection.publicToken), PAGE_W - MARGIN - rightW, chipY + 8, {
      width: rightW,
      align: 'right',
      lineBreak: false,
    });
  doc
    .font('Helvetica')
    .fontSize(7)
    .fillColor(BAND_MUTED)
    .text(
      `Édité le ${generatedAt.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' })}`,
      PAGE_W - MARGIN - rightW,
      chipY + 26,
      { width: rightW, align: 'right', lineBreak: false },
    );
  doc
    .font('Helvetica')
    .fontSize(7)
    .fillColor(BAND_MUTED)
    .text(
      `à ${generatedAt.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`,
      PAGE_W - MARGIN - rightW,
      chipY + 36,
      { width: rightW, align: 'right', lineBreak: false },
    );

  doc.y = BAND_H + 14;
}

/**
 * Bloc de vérification (v4.110) : QR code géant pointant vers la
 * page publique du document + ID + empreinte SHA-256 du contenu
 * (affichée en clair pour permettre le contrôle d'intégrité) +
 * consigne de vérification en ligne.
 */
async function drawVerificationBlock(doc: PdfDoc, data: StandaloneInspectionPdfData): Promise<void> {
  const ins = data.inspection;
  const boxTop = doc.y;
  const qrSize = 92;
  const boxH = qrSize + 24;

  // — Encadré gris clair —
  doc.save();
  doc.roundedRect(MARGIN, boxTop, CONTENT_W, boxH, 5).fill(BOX_BG);
  doc.roundedRect(MARGIN, boxTop, CONTENT_W, boxH, 5).lineWidth(0.75).strokeColor(LINE).stroke();
  doc.restore();

  // — QR géant à gauche —
  let qrDrawn = false;
  try {
    const qrcode = await import('qrcode');
    const qrData = await qrcode.toDataURL(`https://roomscan.pro/i/${ins.publicToken}`, {
      width: 320,
      margin: 1,
      color: { dark: '#111827', light: '#ffffff' },
    });
    const qrBuf = decodeDataUrl(qrData);
    if (qrBuf) {
      doc.image(qrBuf, MARGIN + 12, boxTop + 12, { width: qrSize, height: qrSize });
      qrDrawn = true;
    }
  } catch {
    // QR indisponible — le bloc reste lisible sans lui.
  }

  const textX = MARGIN + 12 + qrSize + (qrDrawn ? 14 : 0);
  const textW = CONTENT_W - (textX - MARGIN) - 14;
  let ty = boxTop + 12;

  doc.font('Helvetica-Bold').fontSize(9).fillColor(INK).text('Vérification en ligne', textX, ty, {
    width: textW,
    lineBreak: false,
  });
  ty += 13;
  doc
    .font('Helvetica')
    .fontSize(7.5)
    .fillColor(MUTED)
    .text(`Document ${inspectionDocumentId(ins.publicToken)} — scannez le QR code ou ouvrez roomscan.pro/i/${ins.publicToken}`, textX, ty, {
      width: textW,
    });
  ty = Math.max(doc.y, ty + 20) + 4;

  // — Empreinte SHA-256 (Courier, sur 2 lignes) —
  doc.font('Helvetica-Bold').fontSize(7.5).fillColor(INK).text('Empreinte SHA-256 du contenu :', textX, ty, {
    width: textW,
    lineBreak: false,
  });
  ty += 11;
  doc.font('Courier').fontSize(6.5).fillColor(INK);
  if (ins.sha256Hash) {
    doc.text(ins.sha256Hash.slice(0, 32).toUpperCase(), textX, ty, { width: textW, lineBreak: false });
    doc.text(ins.sha256Hash.slice(32).toUpperCase(), textX, ty + 9, { width: textW, lineBreak: false });
  } else {
    doc
      .font('Courier-Oblique')
      .text('Disponible après signature électronique', textX, ty, { width: textW, lineBreak: false });
  }

  doc.y = boxTop + boxH + 12;
}

/**
 * Bloc infos gris clair (encadré) : logement, adresse, propriétaire,
 * invité, type, date, signature éventuelle, référence du document.
 */
function drawInfoBox(doc: PdfDoc, data: StandaloneInspectionPdfData): void {
  const ins = data.inspection;
  const signed = ins.status === 'COMPLETED';
  const valW = CONTENT_W - 24 - 112;

  // Hauteur calculée AVANT le dessin (l'adresse peut passer sur 2 lignes).
  doc.font('Helvetica').fontSize(9);
  const addrH = Math.max(doc.heightOfString(ins.propertyAddress || '—', { width: valW }), 12);
  const rows: [string, string, number][] = [
    ['Logement', ins.propertyName || '—', 13],
    ['Adresse', ins.propertyAddress || '—', addrH + 4],
    ...(ins.city?.trim()
      ? ([['Ville (mention « Fait à »)', ins.city.trim(), 13]] as [string, string, number][])
      : []),
    ['Propriétaire', ins.ownerName || '—', 13],
    ['Invité', ins.guestName || '—', 13],
    ["Type d'état des lieux", ins.type === 'SORTIE' ? 'Sortie du logement' : 'Entrée dans le logement', 13],
    ['Date de l’inspection', frDate(ins.scheduledDate), 13],
  ];
  if (signed) {
    rows.push(['Signé le', frDateTime(ins.signedAt ?? ins.completedAt ?? new Date()), 13]);
  }
  const boxH = 12 + rows.reduce((h, r) => h + r[2], 0) + 10;

  const boxTop = doc.y;
  doc.save();
  doc.roundedRect(MARGIN, boxTop, CONTENT_W, boxH, 5).fill(BOX_BG);
  doc.roundedRect(MARGIN, boxTop, CONTENT_W, boxH, 5).lineWidth(0.75).strokeColor(LINE).stroke();
  doc.restore();

  doc.y = boxTop + 12;
  for (const [label, value, h] of rows) {
    infoRow(doc, label, value, valW);
    doc.y += Math.max(h - 13, 0);
  }
  doc.y = boxTop + boxH + 12;

  // — Encart de comparaison (SORTIE liée à son entrée) —
  if (ins.type === 'SORTIE' && ins.linkedEntranceDate) {
    const noteH = 24;
    doc.save();
    doc.roundedRect(MARGIN, doc.y, CONTENT_W, noteH, 4).fill('#fafaf9');
    doc.roundedRect(MARGIN, doc.y, CONTENT_W, noteH, 4).lineWidth(0.5).strokeColor(LINE).stroke();
    doc.restore();
    doc
      .font('Helvetica-Oblique')
      .fontSize(8.5)
      .fillColor(MUTED)
      .text(
        `Établi en comparaison de l'état des lieux d'entrée du ${frDate(ins.linkedEntranceDate)}.`,
        MARGIN + 10,
        doc.y + 8,
        { width: CONTENT_W - 20, lineBreak: false },
      );
    doc.y += noteH + 10;
  }
}

/** En-tête du tableau à 3 colonnes d'une pièce (redessiné si saut de page). */
function drawTableHeader(doc: PdfDoc): void {
  const y = doc.y;
  doc.save();
  doc.rect(MARGIN, y, CONTENT_W, 15).fill(BOX_BG);
  doc.restore();
  doc.font('Helvetica-Bold').fontSize(7.5).fillColor(INK);
  doc.text('Élément', MARGIN + 6, y + 4, { width: 160, lineBreak: false });
  doc.text('État', MARGIN + 172, y + 4, { width: 88, lineBreak: false });
  doc.text('Commentaires', MARGIN + 268, y + 4, { width: CONTENT_W - 274, lineBreak: false });
  doc.y = y + 15;
  doc.x = MARGIN;
}

/**
 * Sections « Corps » (v4.110) : une section NUMÉROTÉE par pièce
 * (2. Cuisine, 3. Séjour… — le numéro de départ est passé par le
 * rendu, la section 1 étant le Ménage). Renvoie le prochain numéro.
 */
function drawRooms(doc: PdfDoc, data: StandaloneInspectionPdfData, startNumber: number): number {
  for (const [index, room] of data.rooms.entries()) {
    ensureSpace(doc, 84);

    // — Numéro + nom de la pièce + état global à droite —
    const headY = doc.y;
    doc
      .font('Times-Bold')
      .fontSize(12)
      .fillColor(INK)
      .text(`${startNumber + index}. ${room.name}`, MARGIN, headY, {
        width: CONTENT_W - 110,
        lineBreak: false,
      });
    doc
      .font('Helvetica-Bold')
      .fontSize(9)
      .fillColor(stateColor(room.globalState))
      .text(stateLabel(room.globalState), MARGIN, headY + 2, {
        width: CONTENT_W,
        align: 'right',
        lineBreak: false,
      });
    doc.y = headY + 18;
    doc.x = MARGIN;

    // — Tableau : Élément | État | Commentaires —
    drawTableHeader(doc);
    for (const item of room.items) {
      const isBad = item.state === 'MAUVAIS';
      doc.font('Helvetica').fontSize(8.5);
      const commentH = item.comment
        ? Math.max(doc.heightOfString(item.comment, { width: CONTENT_W - 280 }), 11)
        : 0;
      const rowH = Math.max(18, commentH + 9);
      // Saut de page propre : réen-tête du tableau sur la nouvelle page.
      if (doc.y + rowH > PAGE_H - MARGIN - 34) {
        doc.addPage();
        drawTableHeader(doc);
      }
      const rowY = doc.y;
      doc.font('Helvetica').fontSize(9).fillColor(INK).text(item.name, MARGIN + 6, rowY + 2, {
        width: 160,
        lineBreak: false,
      });
      doc
        .font(isBad ? 'Helvetica-Bold' : 'Helvetica')
        .fontSize(9)
        .fillColor(stateColor(item.state))
        .text(stateLabel(item.state), MARGIN + 172, rowY + 2, {
          width: 88,
          lineBreak: false,
        });
      if (item.comment) {
        doc
          .font('Helvetica')
          .fontSize(8.5)
          .fillColor(isBad ? '#b91c1c' : '#374151')
          .text(item.comment, MARGIN + 268, rowY + 3, { width: CONTENT_W - 280 });
        doc.y = Math.max(doc.y, rowY + rowH);
      } else {
        doc.y = rowY + rowH;
      }
      doc.x = MARGIN;
      doc
        .moveTo(MARGIN, doc.y)
        .lineTo(PAGE_W - MARGIN, doc.y)
        .lineWidth(0.5)
        .strokeColor(ROW_LINE)
        .stroke();
    }
    if (room.items.length === 0) {
      doc
        .font('Helvetica-Oblique')
        .fontSize(8.5)
        .fillColor(MUTED)
        .text('Aucun élément répertorié pour cette pièce.', MARGIN + 6, doc.y + 3, {
          width: CONTENT_W - 12,
          lineBreak: false,
        });
      doc.y += 18;
    } else {
      doc.y += 4;
    }

    // — Remarques de pièce —
    if (room.comment && room.comment.trim()) {
      doc
        .font('Helvetica-Oblique')
        .fontSize(8.5)
        .fillColor(MUTED)
        .text(`Remarques : ${room.comment.trim()}`, MARGIN, doc.y + 2, { width: CONTENT_W });
      doc.y += 4;
    }

    doc.y += 10;
  }
  doc.moveDown(0.3);
  return startNumber + data.rooms.length;
}

/**
 * Section « Électronique & électroménager » (v4.110) : tableau des
 * appareils (pièce, état constaté) + grille des preuves de
 * fonctionnement jointes (photo ALLUMÉ / photo ÉTEINT). Aucune
 * sortie si le document ne contient aucun appareil connu.
 * Renvoie le prochain numéro de section.
 */
function drawElectronics(
  doc: PdfDoc,
  data: StandaloneInspectionPdfData,
  sectionNumber: number,
): number {
  const appliances: { room: string; item: StandalonePdfItem }[] = [];
  for (const room of data.rooms) {
    for (const item of room.items) {
      if (isElectronicItem(item.name) || item.photoOnUrl || item.photoOffUrl) {
        appliances.push({ room: room.name, item });
      }
    }
  }
  if (appliances.length === 0) return sectionNumber;

  sectionTitle(doc, `${sectionNumber}. Électronique & électroménager`);
  doc
    .font('Helvetica')
    .fontSize(8)
    .fillColor(MUTED)
    .text(
      'Appareils vérifiés avec preuves de fonctionnement : photo appareil ALLUMÉ (ON) et photo appareil ÉTEINT (OFF).',
      MARGIN,
      doc.y,
      { width: CONTENT_W },
    );
  doc.y += 8;

  // — Tableau Appareil | Pièce | État constaté —
  const headY = doc.y;
  doc.save();
  doc.rect(MARGIN, headY, CONTENT_W, 15).fill(BOX_BG);
  doc.restore();
  doc.font('Helvetica-Bold').fontSize(7.5).fillColor(INK);
  doc.text('Appareil', MARGIN + 6, headY + 4, { width: 200, lineBreak: false });
  doc.text('Pièce', MARGIN + 212, headY + 4, { width: 150, lineBreak: false });
  doc.text('État constaté', MARGIN + 368, headY + 4, { width: 120, lineBreak: false });
  doc.y = headY + 15;
  doc.x = MARGIN;

  for (const { room, item } of appliances) {
    const rowH = 18;
    if (doc.y + rowH > PAGE_H - MARGIN - 34) {
      doc.addPage();
      doc.x = MARGIN;
    }
    const rowY = doc.y;
    doc
      .font('Helvetica')
      .fontSize(9)
      .fillColor(INK)
      .text(item.name, MARGIN + 6, rowY + 2, { width: 200, lineBreak: false });
    doc
      .font('Helvetica')
      .fontSize(9)
      .fillColor('#374151')
      .text(room, MARGIN + 212, rowY + 2, { width: 150, lineBreak: false });
    doc
      .font(item.state === 'MAUVAIS' ? 'Helvetica-Bold' : 'Helvetica')
      .fontSize(9)
      .fillColor(stateColor(item.state))
      .text(stateLabel(item.state), MARGIN + 368, rowY + 2, {
        width: 120,
        lineBreak: false,
      });
    doc.y = rowY + rowH;
    doc.x = MARGIN;
    doc
      .moveTo(MARGIN, doc.y)
      .lineTo(PAGE_W - MARGIN, doc.y)
      .lineWidth(0.5)
      .strokeColor(ROW_LINE)
      .stroke();
  }
  doc.y += 8;

  // — Grille des preuves ON / OFF (si ≥ 1 photo) —
  const proofs: LabeledPhoto[] = [];
  for (const { room, item } of appliances) {
    const on = decodeDataUrl(item.photoOnUrl);
    const off = decodeDataUrl(item.photoOffUrl);
    if (on) proofs.push({ buffer: on, label: `${item.name} — ALLUMÉ (ON) · ${room}` });
    if (off) proofs.push({ buffer: off, label: `${item.name} — ÉTEINT (OFF) · ${room}` });
  }
  if (proofs.length > 0) {
    doc
      .font('Helvetica')
      .fontSize(8)
      .fillColor(MUTED)
      .text('Preuves de fonctionnement jointes :', MARGIN, doc.y, {
        width: CONTENT_W,
        lineBreak: false,
      });
    doc.y += 10;
    drawPhotoGrid(doc, proofs);
  }
  return sectionNumber + 1;
}

/** Section « MÉNAGE » distincte (numérotée) : score + commentaire. */
function drawCleanliness(
  doc: PdfDoc,
  data: StandaloneInspectionPdfData,
  sectionNumber: number,
): void {
  sectionTitle(doc, `${sectionNumber}. Ménage — propreté générale`);
  const ins = data.inspection;
  if (!ins.cleanlinessScore) {
    doc
      .font('Helvetica-Oblique')
      .fontSize(9)
      .fillColor(MUTED)
      .text('Non renseignée au moment de l’édition du document.', MARGIN, doc.y, {
        width: CONTENT_W,
      });
    doc.y += 8;
    return;
  }
  ensureSpace(doc, 50);
  const y = doc.y;
  doc.font('Helvetica').fontSize(9.5).fillColor(MUTED).text('État constaté', MARGIN, y, {
    width: 130,
    lineBreak: false,
  });
  doc
    .font('Helvetica-Bold')
    .fontSize(10)
    .fillColor(CLEAN_COLORS[ins.cleanlinessScore] ?? INK)
    .text(CLEAN_LABELS[ins.cleanlinessScore] ?? ins.cleanlinessScore, MARGIN + 134, y - 1, {
      width: CONTENT_W - 134,
      lineBreak: false,
    });
  doc.y = y + 18;
  if (ins.cleanlinessComment && ins.cleanlinessComment.trim()) {
    doc
      .font('Helvetica')
      .fontSize(9)
      .fillColor(INK)
      .text(ins.cleanlinessComment.trim(), MARGIN, doc.y, { width: CONTENT_W });
    doc.y += 6;
  }
}

interface LabeledPhoto {
  buffer: Buffer;
  label: string;
}

/** Photos des items (ordre des pièces) + photo de propreté. */
function collectPhotos(data: StandaloneInspectionPdfData): LabeledPhoto[] {
  const photos: LabeledPhoto[] = [];
  for (const room of data.rooms) {
    for (const item of room.items) {
      const buf = decodeDataUrl(item.photoUrl);
      if (buf) photos.push({ buffer: buf, label: `${room.name} — ${item.name}` });
    }
  }
  const clean = decodeDataUrl(data.inspection.cleanlinessPhotoUrl);
  if (clean) photos.push({ buffer: clean, label: 'Propreté générale' });
  return photos;
}

/**
 * Grille photos 2 colonnes, vignettes cadrées + légende — partagée
 * par la section Électronique (preuves ON/OFF) et l'annexe.
 */
function drawPhotoGrid(doc: PdfDoc, photos: LabeledPhoto[]): void {
  const cellW = (CONTENT_W - 14) / 2;
  const imgH = 165;
  const cellH = imgH + 22;
  let col = 0;
  for (const photo of photos) {
    ensureSpace(doc, cellH + 16);
    const x = MARGIN + col * (cellW + 14);
    const y = doc.y;
    doc.save();
    doc.roundedRect(x, y, cellW, imgH, 3).lineWidth(0.75).strokeColor(LINE).stroke();
    doc.restore();
    try {
      doc.image(photo.buffer, x, y, { fit: [cellW - 4, imgH - 4], align: 'center', valign: 'center' });
    } catch {
      // dataURL invalide — cadre vide, le PDF ne plante jamais.
    }
    doc
      .font('Helvetica')
      .fontSize(7.5)
      .fillColor(MUTED)
      .text(photo.label, x, y + imgH + 5, { width: cellW, align: 'center', lineBreak: false });
    if (col === 1) {
      doc.y = y + cellH;
      doc.x = MARGIN;
      col = 0;
    } else {
      col = 1;
    }
  }
  if (col === 1) doc.y += cellH;
}

/** Annexe photos : grille 2 colonnes, vignettes cadrées + légende. */
function drawPhotoAnnex(doc: PdfDoc, photos: LabeledPhoto[]): void {
  sectionTitle(doc, `Annexe — Photos des constats (${photos.length})`);
  drawPhotoGrid(doc, photos);
}

/** Dernière page : approbation, signature de l'invité, pied légal. */
function drawSignaturePage(doc: PdfDoc, data: StandaloneInspectionPdfData): void {
  doc.addPage();
  const ins = data.inspection;

  doc.moveDown(0.4);
  doc.font('Times-Bold').fontSize(13).fillColor(INK).text('Lu et approuvé, certifié exact', MARGIN, doc.y, {
    width: CONTENT_W,
  });
  doc.y += 10;
  doc
    .font('Helvetica')
    .fontSize(9.5)
    .fillColor(INK)
    .text(`Signature de l'invité : ${ins.guestName}`, MARGIN, doc.y, { width: CONTENT_W });
  doc.y += 12;

  // — Cadre signature ~320 px —
  const frameW = 340;
  const frameH = 140;
  const frameX = MARGIN + (CONTENT_W - frameW) / 2;
  const frameY = doc.y;
  doc.save();
  doc.roundedRect(frameX, frameY, frameW, frameH, 5).lineWidth(0.75).strokeColor(LINE).stroke();
  doc.restore();
  const sigBuf = decodeDataUrl(ins.guestSignature);
  if (sigBuf) {
    try {
      doc.image(sigBuf, frameX + 10, frameY + 10, { fit: [frameW - 20, frameH - 20] });
    } catch {
      // signature illisible — cadre conservé.
    }
  } else {
    doc
      .font('Helvetica')
      .fontSize(8.5)
      .fillColor(MUTED)
      .text('Signature non transmise', frameX + 12, frameY + frameH / 2 - 6, { lineBreak: false });
  }
  doc.y = frameY + frameH + 14;

  doc
    .font('Helvetica')
    .fontSize(9.5)
    .fillColor(INK)
    .text(
      `Signé électroniquement le ${frDateTime(ins.signedAt ?? ins.completedAt ?? new Date())}.`,
      MARGIN,
      doc.y,
      { width: CONTENT_W },
    );

  // — Preuve technique : GPS + IP de signature (v4.110, si présents) —
  const proofLines: string[] = [];
  if (ins.gpsLocation?.trim()) proofLines.push(`Position GPS de la signature : ${ins.gpsLocation.trim()}`);
  if (ins.ipAddress?.trim()) proofLines.push(`Adresse IP de signature : ${ins.ipAddress.trim()}`);
  if (proofLines.length > 0) {
    doc.y += 6;
    doc
      .font('Helvetica')
      .fontSize(7.5)
      .fillColor(MUTED)
      .text(proofLines.join('  ·  '), MARGIN, doc.y, { width: CONTENT_W });
  }

  // — Pied légal —
  doc.y += 18;
  doc
    .font('Helvetica')
    .fontSize(7.5)
    .fillColor(MUTED)
    .text(
      "Ce document numérique signé électroniquement a valeur juridique. Établi contradictoirement entre le propriétaire " +
        "et l'invité, il fait foi entre les parties conformément aux articles 1365 et 1366 du Code civil (écrit et " +
        "signature électroniques). Il est horodaté par la plateforme RoomScan, conservé et consultable en ligne à vie " +
        `via son jeton public (référence ${ins.publicToken.slice(-6).toUpperCase()}). Toute contestation devra être ` +
        'accompagnée des photos figurant en annexe, seules preuves photographiques opposables.',
      MARGIN,
      doc.y,
      { width: CONTENT_W },
    );
}

// ---------- Document ----------

export async function renderStandaloneInspectionPdf(
  data: StandaloneInspectionPdfData,
): Promise<Buffer> {
  const { default: PDFDocument } = await import('pdfkit');
  const doc = new PDFDocument({
    size: 'A4',
    margin: MARGIN,
    bufferPages: true,
    info: {
      Title: data.inspection.type === 'SORTIE' ? 'État des lieux de sortie' : "État des lieux d'entrée",
      Author: 'RoomScan',
    },
  });
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const finished = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  // — En-tête « Bouclier » (1re page) —
  await drawHeader(doc, data);

  // — Bloc vérification : QR géant + empreinte SHA-256 —
  await drawVerificationBlock(doc, data);

  // — Bloc infos + encart comparaison entrée —
  drawInfoBox(doc, data);

  // — Corps numéroté : 1. Ménage → 2..N pièces → N+1 électronique —
  let sectionNumber = 1;
  drawCleanliness(doc, data, sectionNumber);
  sectionNumber += 1;
  sectionNumber = drawRooms(doc, data, sectionNumber);
  drawElectronics(doc, data, sectionNumber);

  // — Annexe photos (si ≥ 1 photo) —
  const photos = collectPhotos(data);
  if (photos.length > 0) {
    // L'annexe démarre sur une page propre si la page courante est déjà bien remplie.
    if (doc.y > PAGE_H - MARGIN - 240) doc.addPage();
    drawPhotoAnnex(doc, photos);
  }

  // — Dernière page : signature —
  drawSignaturePage(doc, data);

  // — Pieds de page (APRÈS le corps, pagination complète) —
  const city =
    data.inspection.city?.trim() ||
    data.inspection.propertyAddress.split(',')[0]?.trim() ||
    'la commune du logement';
  drawFooters(doc, { city, generatedAt: new Date() });

  doc.end();
  return finished;
}
