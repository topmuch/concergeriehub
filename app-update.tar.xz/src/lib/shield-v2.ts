// =============================================================
// ROOMSCAN BOUCLIER V2 (master prompt — ÉTAPE 2)
// Catalogues partagés client/serveur + helpers métier.
//
// ⚠️ Restreindre RSC : ce module ne contient AUCUNE référence de
// composant (icônes résolues dans les composants clients).
// =============================================================

// -------------------------------------------------------------
// PIÈCES (clés stables en base — Json `properties.rooms`)
// -------------------------------------------------------------
export type ShieldRoomKey =
  | 'SALON'
  | 'ENTREE'
  | 'COULOIR'
  | 'CUISINE'
  | 'SDB'
  | 'WC'
  | 'CHAMBRE_1'
  | 'CHAMBRE_2'
  | 'CHAMBRE_3'
  | 'CHAMBRE_4';

export const ROOM_LABELS: Record<string, string> = {
  SALON: 'Salon',
  ENTREE: 'Entrée',
  COULOIR: 'Couloir',
  CUISINE: 'Cuisine',
  SDB: 'Salle de bain',
  WC: 'WC',
  CHAMBRE_1: 'Chambre 1',
  CHAMBRE_2: 'Chambre 2',
  CHAMBRE_3: 'Chambre 3',
  CHAMBRE_4: 'Chambre 4',
};

// Ordre d'affichage / de passage du cleaner
export const ROOM_ORDER: string[] = [
  'ENTREE',
  'COULOIR',
  'SALON',
  'CHAMBRE_1',
  'CHAMBRE_2',
  'CHAMBRE_3',
  'CHAMBRE_4',
  'CUISINE',
  'SDB',
  'WC',
];

// -------------------------------------------------------------
// APPAREILS (clés stables en base — Json `properties.appliances`)
// -------------------------------------------------------------
export const APPLIANCE_LABELS: Record<string, string> = {
  PLAQUE: 'Plaque de cuisson',
  FOUR: 'Four',
  MICRO_ONDES: 'Micro-ondes',
  FRIGO: 'Réfrigérateur',
  LAVE_LINGE: 'Lave-linge',
  LAVE_VAISELLE: 'Lave-vaisselle',
  TV: 'TV',
  CLIMATISATION: 'Climatisation',
  CAFETIERE: 'Cafetière',
  BOUILLOIRE: 'Bouilloire',
  GRILLE_PAIN: 'Grille-pain',
  ASPIRATEUR: 'Aspirateur',
};

export const APPLIANCE_ORDER: string[] = [
  'PLAQUE',
  'FOUR',
  'MICRO_ONDES',
  'FRIGO',
  'LAVE_LINGE',
  'LAVE_VAISELLE',
  'TV',
  'CLIMATISATION',
  'CAFETIERE',
  'BOUILLOIRE',
  'GRILLE_PAIN',
  'ASPIRATEUR',
];

// -------------------------------------------------------------
// TYPES DE LOGEMENT (FLUX A — étape 1 du wizard)
// nbRooms : 0 = Studio, 1..3 = chambres (3 = « 3 et + »)
// -------------------------------------------------------------
export interface ShieldPropertyType {
  nbRooms: number;
  label: string;
  hint: string;
  /** Pièces pré-cochées (modifiable à l'étape 2). */
  defaultRooms: string[];
}

export const PROPERTY_TYPES: ShieldPropertyType[] = [
  {
    nbRooms: 0,
    label: 'Studio',
    hint: 'Pièce unique + cuisine + salle de bain',
    defaultRooms: ['SALON', 'CUISINE', 'SDB'],
  },
  {
    nbRooms: 1,
    label: '1 chambre',
    hint: 'Salon, 1 chambre, cuisine, salle de bain',
    defaultRooms: ['ENTREE', 'SALON', 'CHAMBRE_1', 'CUISINE', 'SDB'],
  },
  {
    nbRooms: 2,
    label: '2 chambres',
    hint: 'Salon, 2 chambres, cuisine, salle de bain',
    defaultRooms: ['ENTREE', 'COULOIR', 'SALON', 'CHAMBRE_1', 'CHAMBRE_2', 'CUISINE', 'SDB'],
  },
  {
    nbRooms: 3,
    label: '3 chambres et +',
    hint: 'Grand logement — composez librement vos pièces',
    defaultRooms: [
      'ENTREE',
      'COULOIR',
      'SALON',
      'CHAMBRE_1',
      'CHAMBRE_2',
      'CHAMBRE_3',
      'CUISINE',
      'SDB',
    ],
  },
];

export function propertyTypeLabel(nbRooms: number | null | undefined): string {
  if (nbRooms === null || nbRooms === undefined) return 'Logement';
  if (nbRooms === 0) return 'Studio';
  if (nbRooms >= 3) return '3 chambres et +';
  return `${nbRooms} chambre${nbRooms > 1 ? 's' : ''}`;
}

// -------------------------------------------------------------
// STATUTS — « En retard » est VIRTUEL : une session A_VENIR dont
// la date prévue est dépassée s'affiche EN_RETARD (aucun cron).
// -------------------------------------------------------------
export type ShieldStatus = 'A_VENIR' | 'EN_RETARD' | 'TERMINE' | 'ANNULE';

export function effectiveStatus(
  session: { status: string; scheduledDate: Date | string },
  now: Date = new Date(),
): ShieldStatus {
  if (session.status !== 'A_VENIR') return session.status as ShieldStatus;
  const scheduled =
    session.scheduledDate instanceof Date
      ? session.scheduledDate
      : new Date(session.scheduledDate);
  return scheduled.getTime() < now.getTime() ? 'EN_RETARD' : 'A_VENIR';
}

// -------------------------------------------------------------
// PLANS (master prompt §Abonnement) — limite du nombre de biens.
// -------------------------------------------------------------
export const PLAN_LIMITS: Record<string, number> = {
  '299_3_BIENS': 3,
  '499_20_BIENS': 20,
};

export function planLimit(plan: string | null | undefined): number {
  return PLAN_LIMITS[plan ?? '299_3_BIENS'] ?? 3;
}

// -------------------------------------------------------------
// Formatage dates FR (sans dépendance locale date-fns)
// -------------------------------------------------------------
export function formatSessionDate(date: Date | string): string {
  const d = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat('fr-FR', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
}

export function formatDay(date: Date | string): string {
  const d = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat('fr-FR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(d);
}

// -------------------------------------------------------------
// Validation clés (sécurité filenames média)
// -------------------------------------------------------------
export function isValidZoneKey(key: string): boolean {
  return /^[A-Z0-9_]{2,40}$/.test(key);
}
