// =============================================================
// v5.3 — FACTURE D'ABONNEMENT EDL — GÉNÉRATEUR PDF (pdfkit)
//
// Style aligné sur le design certifié RoomScan (module standalone) :
// en-tête BLEU NUIT pleine largeur (logo texte « RoomScan » +
// mention FACTURE), bloc méta (numéro RS-ANNÉE-0001, dates, statut),
// encadré acheteur, ligne d'abonnement 299,00 €, mention
// « TVA non applicable, art. 293 B du CGI », badge PAYÉ vert,
// pieds de page RoomScan / roomscan.pro.
//
// Robustesse : polices DejaVu embarquées (public/fonts) avec repli
// Helvetica ; pdfkit externalisé (serverExternalPackages) → import
// dynamique ; aucune entrée ne fait planter le document.
// =============================================================

import { readFile } from 'fs/promises';
import path from 'path';

// Type de l'instance PDFKit (module typé `export = doc` → typeof).
type PdfDoc = typeof import('pdfkit');

// ---------- Entrée (ligne Prisma allégée — jamais de throw) ----------

export interface EdlInvoicePdfData {
  invoiceNumber: string;
  buyerName: string;
  buyerEmail: string;
  planLabel: string;
  amountEur: number;
  currency: string;
  status: string; // 'PAID' | 'REFUNDED'
  issuedAt: Date;
  paidAt?: Date | null;
}

// ---------- Palette « facture » (alignée sur le design unifié) ----------

const NAVY = '#0F2440'; // en-tête bleu nuit
const NAVY_SOFT = '#1E3A5F';
const GREEN = '#1F9D44';
const INK = '#1F2937';
const MUTED = '#6B7280';
const LIGHT_BG = '#F6F6F7';
const CARD_BORDER = '#E3E4E8';

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 42;
const CONTENT_W = PAGE_W - MARGIN * 2;

// ---------- Polices DejaVu (même mécanique que le PDF EDL) ----------

const FONT_FILES: Record<string, string> = {
  DVS: 'DejaVuSans.ttf',
  'DVS-B': 'DejaVuSans-Bold.ttf',
  DVM: 'DejaVuSansMono.ttf',
};

let fontsDirCache: string | null | undefined;

async function findFontsDir(): Promise<string | null> {
  if (fontsDirCache !== undefined) return fontsDirCache;
  const cwd = process.cwd();
  const candidates = [
    path.join(cwd, 'public', 'fonts'),
    path.join(cwd, '.next', 'standalone', 'public', 'fonts'),
  ];
  for (const dir of candidates) {
    try {
      await readFile(path.join(dir, 'DejaVuSans-Bold.ttf'));
      fontsDirCache = dir;
      return dir;
    } catch {
      // candidat suivant
    }
  }
  fontsDirCache = null;
  return null;
}

async function registerFonts(doc: PdfDoc): Promise<boolean> {
  const dir = await findFontsDir();
  if (!dir) return false;
  try {
    for (const [name, file] of Object.entries(FONT_FILES)) {
      doc.registerFont(name, path.join(dir, file));
    }
    return true;
  } catch {
    return false;
  }
}

type FontName = 'body' | 'bold' | 'mono';
function fname(kind: FontName, fontsOk: boolean): string {
  if (!fontsOk) {
    switch (kind) {
      case 'bold':
        return 'Helvetica-Bold';
      case 'mono':
        return 'Courier';
      default:
        return 'Helvetica';
    }
  }
  switch (kind) {
    case 'bold':
      return 'DVS-B';
    case 'mono':
      return 'DVM';
    default:
      return 'DVS';
  }
}

// ---------- Helpers ----------

const frDateLong = (d: Date) =>
  d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

const frDateTime = (d: Date) =>
  d.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

/** 299 → « 299,00 € » (montant stocké en euros entiers). */
function eur(amount: number): string {
  return `${amount.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} \u20AC`;
}

/** Texte positionné une ligne (n'influence pas le flux doc.y). */
function txt(
  doc: PdfDoc,
  font: string,
  size: number,
  color: string,
  str: string,
  x: number,
  y: number,
  width: number,
  align: 'left' | 'center' | 'right' = 'left',
): void {
  doc
    .font(font)
    .fontSize(size)
    .fillColor(color)
    .text(str, x, y, { width, align, lineBreak: false });
}

// ---------- Document ----------

/**
 * Rend la facture PDF (1 page A4) → Buffer.
 * `invoice` = ligne EdlInvoice Prisma allégée.
 */
export async function renderEdlInvoicePdf(invoice: EdlInvoicePdfData): Promise<Buffer> {
  const { default: PDFDocument } = await import('pdfkit');
  const doc = new PDFDocument({
    size: 'A4',
    margin: MARGIN,
    bufferPages: true,
    info: {
      Title: `Facture ${invoice.invoiceNumber} — RoomScan`,
      Author: 'RoomScan',
      Subject: 'Facture d\u2019abonnement RoomScan',
    },
  });
  const chunks: Buffer[] = [];
  doc.on('data', (c: Buffer) => chunks.push(c));
  const finished = new Promise<Buffer>((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
  });

  const fontsOk = await registerFonts(doc);
  const paid = invoice.status === 'PAID';
  const refunded = invoice.status === 'REFUNDED';

  // ── En-tête bleu nuit (logo texte RoomScan + FACTURE) ──
  const BAND_H = 104;
  doc.save();
  doc.rect(0, 0, PAGE_W, BAND_H).fill(NAVY);
  doc.rect(0, BAND_H, PAGE_W, 3).fill(GREEN);
  doc.restore();

  // « Logo » texte : pastille + wordmark + domaine.
  doc.save();
  doc.roundedRect(MARGIN, 26, 30, 30, 7).fill('#ffffff');
  doc.restore();
  doc
    .font(fname('bold', fontsOk))
    .fontSize(15)
    .fillColor(NAVY)
    .text('R', MARGIN + 1, 33, { width: 28, align: 'center', lineBreak: false });
  txt(doc, fname('bold', fontsOk), 17, '#ffffff', 'RoomScan', MARGIN + 42, 30, 200, 'left');
  txt(doc, fname('body', fontsOk), 8, '#9FB4D0', 'roomscan.pro \u2014 \u00e9tats des lieux certifi\u00e9s', MARGIN + 42, 50, 240, 'left');

  txt(doc, fname('bold', fontsOk), 21, '#ffffff', 'FACTURE', PAGE_W - MARGIN - 220, 30, 220, 'right');
  txt(
    doc,
    fname('body', fontsOk),
    9.5,
    '#C9D7EA',
    `N\u00b0 ${invoice.invoiceNumber}`,
    PAGE_W - MARGIN - 220,
    52,
    220,
    'right',
  );

  doc.y = BAND_H + 22;

  // ── Bloc émetteur / dates ──
  const metaY = doc.y;
  txt(doc, fname('bold', fontsOk), 6.6, MUTED, '\u00c9METTEUR', MARGIN, metaY, 220, 'left');
  txt(doc, fname('bold', fontsOk), 9.5, INK, 'RoomScan (micro-entreprise)', MARGIN, metaY + 11, 240, 'left');
  txt(doc, fname('body', fontsOk), 8, MUTED, 'roomscan.pro \u2014 service d\u2019\u00e9tats des lieux', MARGIN, metaY + 23, 260, 'left');

  txt(doc, fname('bold', fontsOk), 6.6, MUTED, "DATE D'\u00c9MISSION", PAGE_W - MARGIN - 240, metaY, 240, 'right');
  txt(doc, fname('body', fontsOk), 9, INK, frDateLong(invoice.issuedAt), PAGE_W - MARGIN - 240, metaY + 11, 240, 'right');
  txt(
    doc,
    fname('body', fontsOk),
    8,
    MUTED,
    invoice.paidAt ? `Paiement : ${frDateTime(invoice.paidAt)}` : 'Paiement : \u2014',
    PAGE_W - MARGIN - 240,
    metaY + 23,
    240,
    'right',
  );

  doc.y = metaY + 48;

  // ── Encadré acheteur ──
  const boxH = 64;
  doc.save();
  doc.roundedRect(MARGIN, doc.y, CONTENT_W, boxH, 8).fill(LIGHT_BG);
  doc.roundedRect(MARGIN, doc.y, CONTENT_W, boxH, 8).lineWidth(0.75).strokeColor(CARD_BORDER).stroke();
  doc.restore();
  txt(doc, fname('bold', fontsOk), 6.6, MUTED, 'FACTUR\u00c9 \u00c0', MARGIN + 14, doc.y + 10, 200, 'left');
  txt(doc, fname('bold', fontsOk), 10.5, INK, invoice.buyerName.slice(0, 60), MARGIN + 14, doc.y + 24, CONTENT_W - 28, 'left');
  txt(doc, fname('body', fontsOk), 8.5, MUTED, invoice.buyerEmail.slice(0, 80), MARGIN + 14, doc.y + 39, CONTENT_W - 28, 'left');
  doc.y += boxH + 26;

  // ── Badge de statut ──
  const badgeLabel = refunded ? 'REMBOURS\u00c9E' : 'PAY\u00c9E';
  const badgeColor = refunded ? MUTED : GREEN;
  doc.font(fname('bold', fontsOk)).fontSize(8.5);
  const badgeW = doc.widthOfString(badgeLabel) + 26;
  doc.save();
  doc.roundedRect(MARGIN, doc.y, badgeW, 20, 10).fill(badgeColor);
  doc.restore();
  txt(doc, fname('bold', fontsOk), 8.5, '#ffffff', `${badgeLabel}${fontsOk ? '  \u2713' : ''}`, MARGIN, doc.y + 5.5, badgeW, 'center');
  doc.y += 30;

  // ── Tableau : ligne d'abonnement ──
  const tableTop = doc.y;
  const colPriceW = 110;
  doc.save();
  doc.rect(MARGIN, tableTop, CONTENT_W, 24).fill(NAVY_SOFT);
  doc.restore();
  txt(doc, fname('bold', fontsOk), 8, '#ffffff', 'D\u00c9SIGNATION', MARGIN + 12, tableTop + 7.5, CONTENT_W - colPriceW - 24, 'left');
  txt(doc, fname('bold', fontsOk), 8, '#ffffff', 'MONTANT HT', MARGIN + CONTENT_W - colPriceW - 12, tableTop + 7.5, colPriceW, 'right');
  doc.y = tableTop + 24;

  const rowH = 46;
  doc.save();
  doc.rect(MARGIN, doc.y, CONTENT_W, rowH).fill('#ffffff');
  doc.rect(MARGIN, doc.y, CONTENT_W, rowH).lineWidth(0.75).strokeColor(CARD_BORDER).stroke();
  doc.restore();
  txt(doc, fname('bold', fontsOk), 9.5, INK, invoice.planLabel.slice(0, 64), MARGIN + 12, doc.y + 9, CONTENT_W - colPriceW - 24, 'left');
  txt(
    doc,
    fname('body', fontsOk),
    8,
    MUTED,
    '\u00c9tats des lieux illimit\u00e9s \u2022 signature \u00e9lectronique \u2022 documents certifi\u00e9s \u2022 12 mois',
    MARGIN + 12,
    doc.y + 24,
    CONTENT_W - colPriceW - 24,
    'left',
  );
  txt(
    doc,
    fname('bold', fontsOk),
    11,
    INK,
    eur(invoice.amountEur),
    MARGIN + CONTENT_W - colPriceW - 12,
    doc.y + 15,
    colPriceW,
    'right',
  );
  doc.y += rowH;

  // ── Totaux ──
  doc.y += 14;
  const totalX = MARGIN + CONTENT_W - 250;
  txt(doc, fname('body', fontsOk), 8.5, MUTED, 'Total HT', totalX, doc.y, 160, 'left');
  txt(doc, fname('body', fontsOk), 8.5, INK, eur(invoice.amountEur), totalX + 160, doc.y, 90, 'right');
  doc.y += 15;
  txt(
    doc,
    fname('body', fontsOk),
    8.5,
    MUTED,
    'TVA non applicable, art. 293 B du CGI (0,00 \u20AC)',
    totalX,
    doc.y,
    160,
    'left',
  );
  txt(doc, fname('body', fontsOk), 8.5, INK, '0,00 \u20AC', totalX + 160, doc.y, 90, 'right');
  doc.y += 24;

  // Bandeau total
  const totalH = 30;
  doc.save();
  doc.roundedRect(MARGIN, doc.y, CONTENT_W, totalH, 5).fill(NAVY);
  doc.restore();
  txt(doc, fname('bold', fontsOk), 10, '#ffffff', 'TOTAL PAY\u00c9', MARGIN + 14, doc.y + 8.5, 200, 'left');
  txt(
    doc,
    fname('bold', fontsOk),
    12,
    '#ffffff',
    eur(invoice.amountEur),
    MARGIN + CONTENT_W - 190,
    doc.y + 7.5,
    176,
    'right',
  );
  doc.y += totalH + 24;

  // ── Mention de règlement ──
  txt(
    doc,
    fname('body', fontsOk),
    8,
    INK,
    invoice.paidAt
      ? `R\u00e8glement int\u00e9gral encaiss\u00e9 le ${frDateTime(invoice.paidAt)} (PayPal). Document tenu \u00e0 disposition du client.`
      : 'R\u00e8glement en cours de confirmation.',
    MARGIN,
    doc.y,
    CONTENT_W,
    'left',
  );

  // ── Pieds de page (toutes pages) ──
  const range = doc.bufferedPageRange();
  for (let i = 0; i < range.count; i += 1) {
    doc.switchToPage(i);
    const savedBottom = doc.page.margins.bottom;
    doc.page.margins.bottom = 0;
    doc
      .moveTo(MARGIN, PAGE_H - 46)
      .lineTo(PAGE_W - MARGIN, PAGE_H - 46)
      .lineWidth(0.6)
      .strokeColor(CARD_BORDER)
      .stroke();
    txt(
      doc,
      fname('body', fontsOk),
      7,
      MUTED,
      `RoomScan \u2022 roomscan.pro \u2022 Facture ${invoice.invoiceNumber} \u2022 TVA non applicable, art. 293 B du CGI`,
      MARGIN,
      PAGE_H - 36,
      CONTENT_W,
      'center',
    );
    txt(
      doc,
      fname('body', fontsOk),
      7,
      MUTED,
      `Page ${i + 1} / ${range.count} \u2022 Document g\u00e9n\u00e9r\u00e9 \u00e9lectroniquement \u2014 valable sans signature manuscrite`,
      MARGIN,
      PAGE_H - 25,
      CONTENT_W,
      'center',
    );
    doc.page.margins.bottom = savedBottom;
  }

  doc.end();
  return finished;
}
