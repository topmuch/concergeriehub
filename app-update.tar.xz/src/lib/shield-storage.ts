// =============================================================
// ROOMSCAN BOUCLIER V2 — STOCKAGE MÉDIAS (serveur)
//
// Les photos de référence (bibliothèque onboarding) et les médias
// de session (6 photos + vidéo 120 s) vivent sur le disque dans
// le VOLUME persistant : data/uploads/shield/{propertyId}/
//   · ref_{ZONE|APPAREIL}.jpg            — bibliothèque verrouillée
//   · {sessionId}_photo_{ZONE}.jpg       — photos de session
//   · {sessionId}_video.webm             — vidéo walkthrough 120 s
//
// En prod Coolify, data/ est monté sur /app/data (volume) — les
// fichiers survivent aux redéploiements. La base ne garde que les
// URLs (Json) + le hash SHA-256 (non falsifiable, recalculé ici).
// =============================================================
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';

export function shieldRootDir(): string {
  return join(process.cwd(), 'data', 'uploads', 'shield');
}

/** Sauvegarde un média et retourne le nom de fichier stocké. */
export async function saveShieldFile(
  propertyId: string,
  filename: string,
  data: Buffer,
): Promise<void> {
  const dir = join(shieldRootDir(), propertyId);
  await mkdir(dir, { recursive: true });
  await writeFile(join(dir, filename), data);
}

/** Lit un média (null si absent — jamais d'exception de chemin). */
export async function readShieldFile(
  propertyId: string,
  filename: string,
): Promise<Buffer | null> {
  try {
    return await readFile(join(shieldRootDir(), propertyId, filename));
  } catch {
    return null;
  }
}

/** SHA-256 hex MAJUSCULE (intégrité juridique, recalcul serveur). */
export function sha256Hex(data: Buffer): string {
  return createHash('sha256').update(data).digest('hex').toUpperCase();
}

const MIME_BY_EXT: Record<string, string> = {
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webm: 'video/webm',
  mp4: 'video/mp4',
};

export function mimeForFilename(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() ?? '';
  return MIME_BY_EXT[ext] ?? 'application/octet-stream';
}

// -------------------------------------------------------------
// dataURL « data:image/jpeg;base64,… » → Buffer (photos Ghost /
// bibliothèque). Retourne null si malformé ou trop lourd.
// -------------------------------------------------------------
const MAX_DATAURL_BYTES = 4_000_000; // 4 Mo par photo

export function dataUrlToBuffer(dataUrl: string): Buffer | null {
  if (typeof dataUrl !== 'string') return null;
  const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl);
  if (!match) return null;
  const base64 = match[2] ?? '';
  let buffer: Buffer;
  try {
    buffer = Buffer.from(base64, 'base64');
  } catch {
    return null;
  }
  if (buffer.length === 0 || buffer.length > MAX_DATAURL_BYTES) return null;
  return buffer;
}

// -------------------------------------------------------------
// Garde-fous de noms de fichiers (jamais de traversal)
//   ref_{KEY}.jpg — bibliothèque
//   {uuid}_photo_{KEY}.jpg / {uuid}_video.webm — session
// -------------------------------------------------------------
export function isRefFilename(filename: string): boolean {
  return /^ref_[A-Z0-9_]{2,40}\.(jpg|jpeg|png|webp)$/.test(filename);
}

export function isSessionFilename(filename: string, sessionId: string): boolean {
  if (sessionId.includes('-')) {
    // uuid : échapper pour construire la regex
    const esc = sessionId.replace(/[^a-z0-9-]/g, '');
    return (
      new RegExp(`^${esc}_photo_[A-Z0-9_]{2,40}\\.(jpg|jpeg|png|webp)$`).test(filename) ||
      new RegExp(`^${esc}_video\\.(webm|mp4)$`).test(filename)
    );
  }
  return false;
}
