// =============================================================
// V2 « BOUCLIER » — lib partagée (client + serveur)
// Types, presets d'onboarding, statuts et helpers du rebuild V2.
// Règle d'or « zéro case vide » : toute l'UI s'adapte aux cases
// cochées à l'onboarding (pièces / équipements réels du logement).
// =============================================================

// ---------- Types de logement (étape 1 du wizard) ----------
export const HOUSING_TYPES = ['STUDIO', 'T2', 'T3', 'T4', 'MAISON'] as const;
export type HousingType = (typeof HOUSING_TYPES)[number];

export const HOUSING_TYPE_LABELS: Record<HousingType, string> = {
  STUDIO: 'Studio',
  T2: 'T2 — 1 chambre + salon',
  T3: 'T3 — 2 chambres + salon',
  T4: 'T4 — 3 chambres + salon',
  MAISON: 'Maison — 4 chambres et +',
};

// ---------- Presets de pièces par type (étape 2) ----------
// Toutes cochées par défaut : l'hôte décoche ce qui n'existe pas.
export const ROOM_PRESETS: Record<HousingType, string[]> = {
  STUDIO: ['Coin nuit', 'Coin salon', 'Kitchenette', 'Salle de bain', 'WC'],
  T2: ['Salon', 'Chambre 1', 'Cuisine', 'Salle de bain', 'WC', 'Couloir'],
  T3: ['Salon', 'Chambre 1', 'Chambre 2', 'Cuisine', 'Salle de bain', 'WC', 'Couloir'],
  T4: ['Salon', 'Chambre 1', 'Chambre 2', 'Chambre 3', 'Cuisine', 'Salle de bain', 'WC', 'Couloir'],
  MAISON: [
    'Salon',
    'Cuisine',
    'Chambre 1',
    'Chambre 2',
    'Chambre 3',
    'Chambre 4',
    'Salle de bain',
    'WC',
    'Couloir',
    'Terrasse',
  ],
};

// ---------- Équipements (étape 2) — décochés par défaut ----------
export const APPLIANCE_OPTIONS: string[] = [
  'Réfrigérateur',
  'Plaques de cuisson',
  'Four',
  'Micro-ondes',
  'Lave-linge',
  'Lave-vaisselle',
  'Sèche-linge',
  'Machine à café',
  'Bouilloire',
  'TV',
  'Box Wi-Fi',
  'Climatisation',
  'Chauffe-eau',
  'Aspirateur',
  'Fer à repasser',
];

// ---------- Statuts de session ----------
export const SESSION_TYPES = ['CHECKIN', 'CHECKOUT'] as const;
export type SessionType = (typeof SESSION_TYPES)[number];

export const SESSION_STATUSES = ['A_VENIR', 'EN_RETARD', 'TERMINE', 'ANNULE'] as const;
export type SessionStatus = (typeof SESSION_STATUSES)[number];

export const STATUS_LABELS: Record<SessionStatus, string> = {
  A_VENIR: 'À venir',
  EN_RETARD: 'En retard',
  TERMINE: 'Terminé',
  ANNULE: 'Annulé',
};

// Couleurs V2 : jaune = à venir, rouge = en retard, vert = terminé, gris = annulé
export const STATUS_CLASSES: Record<SessionStatus, string> = {
  A_VENIR: 'bg-amber-100 text-amber-800 ring-amber-200',
  EN_RETARD: 'bg-red-100 text-red-700 ring-red-200',
  TERMINE: 'bg-emerald-100 text-emerald-700 ring-emerald-200',
  ANNULE: 'bg-slate-200 text-slate-600 ring-slate-300',
};

/** Statut d'affichage : un A_VENIR dont la date est passée = EN_RETARD. */
export function displayStatus(
  status: string,
  scheduledAt: string | null,
  now: number = Date.now(),
): SessionStatus {
  if (status === 'A_VENIR' && scheduledAt && new Date(scheduledAt).getTime() < now) {
    return 'EN_RETARD';
  }
  return (SESSION_STATUSES as readonly string[]).includes(status)
    ? (status as SessionStatus)
    : 'A_VENIR';
}

// ---------- DTOs échangés avec /api/airbnb/v2/* ----------
export interface V2PropertyDto {
  id: string;
  name: string;
  address: string | null;
  housingType: HousingType | null;
  onboardingDone: boolean;
  rooms: string[];
  appliances: string[];
  /** Nombre total de photos de référence (toutes zones). */
  referencePhotoCount: number;
  createdAt: string;
}

export interface V2SessionDto {
  id: string;
  type: SessionType;
  status: SessionStatus;
  scheduledAt: string | null;
  completedAt: string | null;
  propertyId: string;
  propertyName: string;
  /** Check-out : id du check-in d'origine (comparaison photo par photo). */
  checkInSessionId: string | null;
  /** Lien cleaner public — /s/[publicToken] (flux C). */
  publicToken: string | null;
  /** Étape 7 — email du ménager (lien /s/[token] envoyé automatiquement). */
  cleanerEmail: string | null;
  createdAt: string;
}

// ---------- Cycle Bouclier (règle d'or : check-in → check-out) ----------
// Le cycle est « ouvert » quand le dernier séjour TERMINÉ du bien est un
// check-in : le client est entré, le check-out de sortie n'a pas encore
// été réalisé. Un check-in est refusé cycle ouvert, un check-out est
// refusé hors cycle ouvert (même règle validée sur la V1 Bouclier).
export interface PropertyCycleState {
  /** Dernier séjour terminé = CHECKIN (sortie pas encore faite). */
  openCycle: boolean;
  /** Id du check-in terminé qui a ouvert le cycle (null sinon). */
  openCheckInId: string | null;
  /** Un check-out (prévu ou réalisé) est déjà rattaché à ce check-in. */
  hasLinkedCheckout: boolean;
}

export function computeCycleState(sessions: V2SessionDto[]): PropertyCycleState {
  const termine = sessions
    .filter((s) => s.status === 'TERMINE')
    .sort((a, b) => {
      const ta = new Date(a.completedAt ?? a.createdAt).getTime();
      const tb = new Date(b.completedAt ?? b.createdAt).getTime();
      return tb - ta; // plus récent d'abord
    });
  const last = termine[0];
  if (!last || last.type !== 'CHECKIN') {
    return { openCycle: false, openCheckInId: null, hasLinkedCheckout: false };
  }
  const hasLinkedCheckout = sessions.some(
    (s) => s.type === 'CHECKOUT' && s.status !== 'ANNULE' && s.checkInSessionId === last.id,
  );
  return { openCycle: true, openCheckInId: last.id, hasLinkedCheckout };
}

export interface V2OverviewDto {
  properties: number;
  onboarded: number;
  menageAFaire: number;
  checkins: number;
  checkouts: number;
  documents: number;
}

// ---------- Validation serveur (POST sessions — flux B) ----------
export interface CreateSessionPayload {
  propertyId: string;
  type: SessionType;
  /** Date/heure prévue — les dates passées sont admises (=> EN_RETARD). */
  scheduledAt: Date;
  cleanerName: string | null;
  /** Étape 7 — si renseigné, le lien /s/[token] lui est envoyé par email. */
  cleanerEmail: string | null;
}

export function validateCreateSessionPayload(
  body: unknown,
): { ok: true; value: CreateSessionPayload } | { ok: false; error: string } {
  if (typeof body !== 'object' || body === null) return { ok: false, error: 'Corps invalide' };
  const b = body as Record<string, unknown>;

  const propertyId = typeof b.propertyId === 'string' ? b.propertyId.trim() : '';
  if (propertyId.length < 1) return { ok: false, error: 'Choisissez un logement' };

  const type = b.type as SessionType;
  if (!SESSION_TYPES.includes(type)) {
    return { ok: false, error: 'Type de séjour invalide' };
  }

  if (typeof b.scheduledAt !== 'string' || b.scheduledAt.trim().length === 0) {
    return { ok: false, error: 'Choisissez une date et une heure' };
  }
  const scheduledAt = new Date(b.scheduledAt);
  if (Number.isNaN(scheduledAt.getTime())) {
    return { ok: false, error: 'Date et heure invalides' };
  }
  // Garde-fou large : pas de créneau à plus de 2 ans.
  if (scheduledAt.getTime() > Date.now() + 2 * 365 * 24 * 3600 * 1000) {
    return { ok: false, error: 'Créneau trop éloigné (2 ans maximum)' };
  }

  const cleanerName =
    typeof b.cleanerName === 'string' && b.cleanerName.trim().length > 0
      ? b.cleanerName.trim().slice(0, 60)
      : null;

  // Étape 7 — email du ménager optionnel (envoi auto du lien cleaner).
  let cleanerEmail: string | null = null;
  if (typeof b.cleanerEmail === 'string' && b.cleanerEmail.trim().length > 0) {
    const email = b.cleanerEmail.trim().slice(0, 120);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return { ok: false, error: 'Email du ménager invalide' };
    }
    cleanerEmail = email.toLowerCase();
  }

  return {
    ok: true,
    value: { propertyId, type, scheduledAt, cleanerName, cleanerEmail },
  };
}

// =============================================================
// Flux C — page cleaner publique /s/[token] (étape 5)
// Le token EST l'authentification : aucun autre garde.
// =============================================================

/** Photos d'une session : 1 photo (dataURL) par pièce, clé = nom de pièce. */
export type ShieldSessionPhotos = Record<string, string>;

const MAX_SESSION_PHOTO_CHARS = 900_000; // aligné onboarding (~900 Ko / photo)
const MAX_SESSION_VIDEO_CHARS = 30_000_000; // ~22 Mo de vidéo binaire

export const ALLOWED_VIDEO_MIMES = ['video/webm', 'video/mp4', 'video/quicktime', 'video/ogg'];

/**
 * Valide une photo de session (dataURL). Retourne un message d'erreur
 * ou null si valide.
 */
export function validateSessionPhoto(dataUrl: unknown): string | null {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) {
    return 'Format de photo invalide';
  }
  if (dataUrl.length > MAX_SESSION_PHOTO_CHARS) {
    return 'Photo trop lourde (900 Ko maximum)';
  }
  return null;
}

/**
 * Valide une vidéo de session (dataURL data:video/…). Retourne un
 * message d'erreur ou null si valide.
 */
export function validateSessionVideo(dataUrl: unknown): string | null {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:video/')) {
    return 'Format de vidéo invalide';
  }
  const mime = dataUrl.slice(5, dataUrl.indexOf(';')).toLowerCase();
  if (!ALLOWED_VIDEO_MIMES.some((m) => mime.startsWith(m))) {
    return 'Format de vidéo non autorisé (webm ou mp4)';
  }
  if (dataUrl.length > MAX_SESSION_VIDEO_CHARS) {
    return 'Vidéo trop lourde (22 Mo maximum) — raccourcissez la traversée';
  }
  return null;
}

/** Hash SHA-256 (hex MAJUSCULE) des octets d'un dataURL — côté serveur. */
export async function sha256OfDataUrl(dataUrl: string): Promise<string> {
  const { createHash } = await import('crypto');
  const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
  return createHash('sha256').update(Buffer.from(base64, 'base64')).digest('hex').toUpperCase();
}

/** Photo de référence d'une zone (bibliothèque Bouclier). */
export interface ReferencePhoto {
  dataUrl: string;
  takenAt: string;
}

export type ReferencePhotoLibrary = Record<string, ReferencePhoto[]>;

// ---------- Validation serveur (POST/PATCH properties) ----------
const MAX_PHOTO_CHARS = 900_000; // ≈ 900 Ko / photo compressée côté client

export interface OnboardingPayload {
  name: string;
  address: string | null;
  housingType: HousingType;
  rooms: string[];
  appliances: string[];
  referencePhotos: ReferencePhotoLibrary;
}

export function validateOnboardingPayload(
  body: unknown,
): { ok: true; value: OnboardingPayload } | { ok: false; error: string } {
  if (typeof body !== 'object' || body === null) return { ok: false, error: 'Corps invalide' };
  const b = body as Record<string, unknown>;

  const name = typeof b.name === 'string' ? b.name.trim() : '';
  if (name.length < 1 || name.length > 80) {
    return { ok: false, error: 'Le nom du logement doit faire entre 1 et 80 caractères' };
  }
  const address =
    typeof b.address === 'string' && b.address.trim().length > 0
      ? b.address.trim().slice(0, 200)
      : null;

  const housingType = b.housingType as HousingType;
  if (!HOUSING_TYPES.includes(housingType)) {
    return { ok: false, error: 'Type de logement invalide' };
  }

  const rooms = Array.isArray(b.rooms)
    ? b.rooms.filter((r): r is string => typeof r === 'string' && r.trim().length > 0).map((r) => r.trim().slice(0, 40))
    : [];
  const roomsUnique = Array.from(new Set(rooms));
  if (roomsUnique.length < 1 || roomsUnique.length > 20) {
    return { ok: false, error: 'Sélectionnez au moins une pièce (20 maximum)' };
  }

  const appliances = Array.isArray(b.appliances)
    ? Array.from(
        new Set(
          b.appliances
            .filter((a): a is string => typeof a === 'string' && a.trim().length > 0)
            .map((a) => a.trim().slice(0, 40)),
        ),
      )
    : [];
  if (appliances.length > 30) return { ok: false, error: '30 équipements maximum' };

  // Bibliothèque : chaque PIÈCE cochée exige ≥ 1 photo de référence.
  const lib = (typeof b.referencePhotos === 'object' && b.referencePhotos !== null
    ? (b.referencePhotos as Record<string, unknown>)
    : {}) as ReferencePhotoLibrary;
  const cleaned: ReferencePhotoLibrary = {};
  for (const [zone, list] of Object.entries(lib)) {
    if (!Array.isArray(list)) continue;
    const photos: ReferencePhoto[] = [];
    for (const p of list) {
      if (typeof p === 'object' && p !== null && typeof (p as ReferencePhoto).dataUrl === 'string') {
        const dataUrl = (p as ReferencePhoto).dataUrl;
        if (!dataUrl.startsWith('data:image/')) continue;
        if (dataUrl.length > MAX_PHOTO_CHARS) {
          return { ok: false, error: `Photo trop lourde pour « ${zone} » (900 Ko max)` };
        }
        photos.push({
          dataUrl,
          takenAt: typeof (p as ReferencePhoto).takenAt === 'string' ? (p as ReferencePhoto).takenAt : new Date().toISOString(),
        });
      }
    }
    if (photos.length > 0) cleaned[zone] = photos.slice(0, 8);
  }
  const missingRoom = roomsUnique.find((r) => !cleaned[r] || cleaned[r].length < 1);
  if (missingRoom) {
    return { ok: false, error: `Ajoutez au moins une photo de référence pour « ${missingRoom} »` };
  }

  return {
    ok: true,
    value: { name, address, housingType, rooms: roomsUnique, appliances, referencePhotos: cleaned },
  };
}

/** Compte le nombre total de photos d'une bibliothèque (côté affichage). */
export function countReferencePhotos(lib: unknown): number {
  if (typeof lib !== 'object' || lib === null) return 0;
  let n = 0;
  for (const list of Object.values(lib as Record<string, unknown>)) {
    if (Array.isArray(list)) n += list.length;
  }
  return n;
}
