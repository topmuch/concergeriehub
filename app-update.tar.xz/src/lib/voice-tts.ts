// =============================================================
// v4.37 « MESSAGES VOCAUX DU HUB » — GÉNÉRATION TTS SERVEUR
// src/lib/voice-tts.ts
//
// Convertit le texte de l'hôte en MP3 jouable par les invités :
//   1. (arabe uniquement) translittération LLM arabe → latin phonétique
//      (le moteur TTS ne lit PAS l'écriture arabe — test v4.37 :
//      syllabes illisibles ; la voix `jam` prononce très bien la
//      translittération latine, vérifié par transcription inverse ASR) ;
//   2. synthèse z-ai-web-dev-sdk (sortie WAV 24 kHz — l'API refuse le
//      MP3 direct, erreur 1214 « response_format non supporté ») ;
//   3. conversion WAV → MP3 64 kbps mono via @breezystack/lamejs
//      (encodeur MP3 PUR JS — aucun ffmpeg requis dans l'image Docker
//      Coolify, qui n'en embarque pas) : 30 s ≈ 240 Ko → base64 ≈ 320 Ko,
//      4× plus léger que le WAV brut stocké en base.
//
// Voix par langue (tests v4.37, transcript croisé TTS→ASR) :
//   fr → 'xiaochen' (seule voix à débit normal sur le français)
//   en → 'jam'      (voix britannique native — parfait)
//   es → 'xiaochen' (meilleur compromis testé)
//   ar → 'jam'      (sur texte translittéré — arabe reconnaissable)
//
// Limites API : 1024 caractères/requête (on plafonne à 600 ≈ 30 s),
// rate limit 429 par rafales → retries exponentiels 8/16/24 s.
// =============================================================

import ZAI from 'z-ai-web-dev-sdk';
// Encodeur MP3 pur JS (ESM « type: module ») — l'import NOMMÉ est la
// seule voie fiable : le build require (IIFE) n'expose pas Mp3Encoder
// sous Bun/Next (interop CJS → undefined, constaté au test v4.37).
import { Mp3Encoder } from '@breezystack/lamejs';

/** Langues de voix supportées (demande client v4.37 : FR·EN·ES·AR). */
export const VOICE_LANGS = ['fr', 'en', 'es', 'ar'] as const;
export type VoiceLang = (typeof VOICE_LANGS)[number];

export const VOICE_LANG_LABELS: Record<VoiceLang, string> = {
  fr: 'Français',
  en: 'English',
  es: 'Español',
  ar: 'العربية (Arabe)',
};

const TTS_VOICE_BY_LANG: Record<VoiceLang, string> = {
  fr: 'xiaochen',
  en: 'jam',
  es: 'xiaochen',
  ar: 'jam',
};

/** Plafond serveur du texte TTS (600 ≈ 30 s à débit normal, cohérent
 *  avec la durée max des vocaux — demande client). */
export const MAX_TTS_CHARS = 600;

export interface GeneratedVoice {
  base64: string;
  mime: 'audio/mpeg';
  durationSec: number;
  sizeKb: number;
}

/** Écrit .z-ai-config depuis Z_AI_CONFIG_JSON si absent (1er appel) —
 *  même convention que /api/public/translate (config Coolify prod). */
async function ensureSdkConfig(): Promise<void> {
  const raw = process.env.Z_AI_CONFIG_JSON;
  if (!raw) return;
  try {
    const fs = await import('fs');
    const path = await import('path');
    const target = path.join(process.cwd(), '.z-ai-config');
    try {
      const existing = JSON.parse(fs.readFileSync(target, 'utf-8'));
      if (existing?.baseUrl && existing?.apiKey) return; // déjà en place
    } catch {
      /* absent ou invalide → on écrit */
    }
    const cfg = JSON.parse(raw) as { baseUrl?: string; apiKey?: string };
    if (!cfg?.baseUrl || !cfg?.apiKey) return;
    fs.writeFileSync(target, raw, { mode: 0o600 });
  } catch {
    /* config env invalide — le TTS restera indisponible */
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Détecte une erreur 429 (rate limit SDK) dans un message d'erreur. */
function isRateLimitError(e: unknown): boolean {
  const msg = e instanceof Error ? e.message : String(e ?? '');
  return msg.includes('429') || msg.toLowerCase().includes('too many requests');
}

/** Translittération LLM : écriture arabe → latin phonétique lisible par
 *  un moteur TTS orienté anglais (voix `jam`). Best-effort : en cas
 *  d'échec LLM, on renvoie le texte tel quel (le TTS produira un audio
 *  médiocre plutôt qu'aucune voix). */
export async function transliterateArabic(text: string): Promise<string> {
  try {
    await ensureSdkConfig();
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create(
      {
        messages: [
          {
            role: 'assistant',
            content:
              'You transliterate Arabic script into Latin letters for a text-to-speech engine. ' +
              'Spell each word the way an ENGLISH-speaking TTS engine would pronounce natural spoken Arabic: ' +
              'simple English phonetic spelling, no diacritics, no apostrophes for ayin/hamza (use plain vowels), ' +
              'write numbers as words in Arabic. ' +
              'Return ONLY the transliteration on a single line, nothing else, no quotes.',
          },
          { role: 'user', content: text },
        ],
        thinking: { type: 'disabled' },
      } as never,
    );
    const out = completion.choices[0]?.message?.content?.trim() ?? '';
    // Garde-fou : une translittération vide ou identique au texte arabe
    // (le LLM a échoué) → on renvoie l'entrée brute.
    if (out.length > 0 && !/[\u0600-\u06FF]/.test(out)) return out;
    return text;
  } catch {
    return text;
  }
}

/** Parse un fichier WAV (RIFF) → PCM Int16 + métriques. Gère les
 *  chunks non standard (le header « data » n'est pas toujours à 44 o). */
function parseWav(buffer: Buffer): {
  pcm: Int16Array;
  sampleRate: number;
  channels: number;
} {
  if (buffer.length < 44 || buffer.toString('ascii', 0, 4) !== 'RIFF') {
    throw new Error('Audio WAV invalide (en-tête RIFF absent)');
  }
  let offset = 12; // saute RIFF(12) + 'WAVE'
  let sampleRate = 24000;
  let channels = 1;
  let bitsPerSample = 16;
  while (offset + 8 <= buffer.length) {
    const chunkId = buffer.toString('ascii', offset, offset + 4);
    const chunkSize = buffer.readUInt32LE(offset + 4);
    if (chunkId === 'fmt ') {
      channels = buffer.readUInt16LE(offset + 10);
      sampleRate = buffer.readUInt32LE(offset + 12);
      bitsPerSample = buffer.readUInt16LE(offset + 22);
    } else if (chunkId === 'data') {
      const dataStart = offset + 8;
      const dataEnd = Math.min(dataStart + chunkSize, buffer.length);
      const bytesPerSample = bitsPerSample / 8;
      const frameCount = Math.floor((dataEnd - dataStart) / (bytesPerSample * channels));
      // On ne garde que le canal 1 (mono source) — le TTS est mono.
      const pcm = new Int16Array(frameCount);
      for (let i = 0; i < frameCount; i++) {
        pcm[i] = buffer.readInt16LE(dataStart + i * bytesPerSample * channels);
      }
      return { pcm, sampleRate, channels: 1 };
    }
    offset += 8 + chunkSize + (chunkSize % 2); // chunks alignés sur 2 octets
  }
  throw new Error('Audio WAV invalide (chunk data absent)');
}

/** Encode PCM Int16 mono → MP3 via lamejs (pur JS, sans ffmpeg). */
function encodeMp3(pcm: Int16Array, sampleRate: number): Buffer {
  const encoder = new Mp3Encoder(1, sampleRate, 64);
  const chunks: Buffer[] = [];
  const BLOCK = 1152 * 20; // ~1 s par appel (multiples de 1152 frames)
  for (let i = 0; i < pcm.length; i += BLOCK) {
    const slice = pcm.subarray(i, Math.min(i + BLOCK, pcm.length));
    const encoded = encoder.encodeBuffer(slice);
    if (encoded.length > 0) chunks.push(Buffer.from(encoded));
  }
  const tail = encoder.flush();
  if (tail.length > 0) chunks.push(Buffer.from(tail));
  return Buffer.concat(chunks);
}

/** Génère la voix MP3 d'un message dans la langue donnée.
 *  Retries 429 : 3 tentatives (délais 8/16/24 s) — la génération des
 *  4 langues est séquentielle côté client, ce qui espace déjà les appels. */
export async function generateVoiceMessage(
  text: string,
  lang: VoiceLang,
): Promise<GeneratedVoice> {
  const clean = text.replace(/\s+/g, ' ').trim().slice(0, MAX_TTS_CHARS);
  if (!clean) throw new Error('Texte vide');
  if (!VOICE_LANGS.includes(lang)) throw new Error(`Langue non supportée : ${lang}`);

  // 1) Arabe : translittération LLM (le moteur ne lit pas l'écriture arabe).
  const ttsInput = lang === 'ar' ? await transliterateArabic(clean) : clean;

  // 2) Synthèse WAV avec retries sur 429.
  await ensureSdkConfig();
  const zai = await ZAI.create();
  let wav: Buffer | null = null;
  let lastError: unknown = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await zai.audio.tts.create({
        input: ttsInput,
        voice: TTS_VOICE_BY_LANG[lang],
        speed: 1.0,
        response_format: 'wav',
        stream: false,
      });
      const arrayBuffer = await response.arrayBuffer();
      wav = Buffer.from(new Uint8Array(arrayBuffer));
      break;
    } catch (e) {
      lastError = e;
      if (isRateLimitError(e) && attempt < 2) {
        await sleep(8000 * (attempt + 1) * 2); // 16 s puis 32 s
        continue;
      }
      throw e;
    }
  }
  if (!wav) throw lastError ?? new Error('Synthèse vocale échouée');

  // 3) WAV → MP3 (lamejs) + métriques.
  const { pcm, sampleRate } = parseWav(wav);
  const durationSec = Math.round(pcm.length / sampleRate);
  const mp3 = encodeMp3(pcm, sampleRate);
  return {
    base64: mp3.toString('base64'),
    mime: 'audio/mpeg',
    durationSec,
    sizeKb: Math.round(mp3.length / 1024),
  };
}
