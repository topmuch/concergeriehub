// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — Utilitaires SHA-256 (client)
//
// Empreintes calculées DANS LE NAVIGATEUR (WebCrypto) pour :
//   · la vidéo walkthrough (hash affiché dès l'aperçu) ;
//   · le scellé global de session (aperçu avant envoi).
// Le serveur recalcule TOUJOURS ses propres hashes (node:crypto)
// — ce module ne sert qu'à l'affichage client + double contrôle.
// =============================================================

/** ArrayBuffer → hexadécimal majuscule. */
function bufferToHexUpper(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let hex = '';
  for (const b of bytes) hex += b.toString(16).padStart(2, '0');
  return hex.toUpperCase();
}

/** Base64 → ArrayBuffer (dataURL ou base64 pur). */
function base64ToArrayBuffer(input: string): ArrayBuffer {
  const b64 = input.includes(',') ? (input.split(',')[1] ?? '') : input;
  const clean = b64.replace(/[^A-Za-z0-9+/=]/g, '');
  const bin = atob(clean);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes.buffer;
}

/**
 * Hash SHA-256 (hex MAJUSCULE) d'une chaîne (dataURL/base64/texte),
 * d'un Blob (vidéo, fichier) ou d'un ArrayBuffer.
 * Retourne null si WebCrypto est indisponible (contexte non sécurisé).
 */
export async function generateSHA256Hash(
  data: string | Blob | ArrayBuffer,
): Promise<string | null> {
  try {
    if (typeof globalThis.crypto?.subtle?.digest !== 'function') return null;
    let buffer: ArrayBuffer;
    if (typeof data === 'string') {
      // Texte brut court (métadonnées) vs dataURL/base64 (fichiers).
      buffer = /^data:|^[A-Za-z0-9+/=\s]{64,}$/.test(data)
        ? base64ToArrayBuffer(data)
        : new TextEncoder().encode(data).buffer as ArrayBuffer;
    } else if (data instanceof Blob) {
      buffer = await data.arrayBuffer();
    } else {
      buffer = data;
    }
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return bufferToHexUpper(digest);
  } catch {
    return null;
  }
}

/** Formatage court « A1B2C3D4… » pour l'affichage. */
export function shortHash(hash: string | null | undefined, keep = 8): string {
  if (!hash) return '';
  return `${hash.slice(0, keep)}…`;
}
