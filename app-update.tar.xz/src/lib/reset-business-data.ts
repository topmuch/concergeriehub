import { mkdir, readdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { db } from '@/lib/db';

// =============================================================
// v4.135 « REMISE À ZÉRO » — purge métier complète (ÉTAPE 1)
//
// Demande client : « tu supprimes toutes les rubriques du tableau de
// bord, avec remise à zéro — sans appartement, sans onboarding — on
// reprend à zéro. »
//
// Cette lib purge TOUTES les données métier (biens, onboarding,
// séjours, états des lieux Bouclier/EDL, photos, vidéos, QR, hub
// invité, marketplace, prestataires, coach, facturation hôte…)
// en respectant l'ordre enfants → parents (SQLite foreign_keys=ON).
//
// CONSERVÉ volontairement :
//   • User / Profile — les comptes (superadmin, hôte démo) restent
//     utilisables pour la reprise ;
//   • tables plateforme (EmailTemplate, PlatformSetting, FeatureFlag,
//     ApiKey, IpBlacklist, SupportTicket, SystemSetting, SystemMetric,
//     SystemIncident, CronLog, AuditLog) — noyau technique admin.
//
// Le seed de boot prod (`prisma/seed.ts` mode bootstrap) ne recrée des
// prestataires démo QUE s'il existe des biens actifs : après purge
// (0 biens), la prod reste propre au redémarrage.
// =============================================================

/** Delegates Prisma à purger, dans l'ordre strict enfants → parents. */
const PURGE_ORDER: readonly string[] = [
  // 1. Plaques QR, QR & logs associés (EmergencyQrCode cascade QrCode ;
  //    PhysicalQrCode = SetNull sur property → purge explicite).
  'emergencyQrCode',
  'activationLog',
  'physicalQrCode',
  'qrContent',
  'qrBatch',
  'qrCode',
  'scanLog',
  'guestbookEntry',

  // 2. Hub invité & séjours (enfants de Booking d'abord — beaucoup en
  //    SetNull sur booking → purge explicite avant le parent).
  'hubAccessSession',
  'guestSession',
  'minibarRestockRequest',
  'minibarCheck',
  'minibarOrder',
  'middleStayRequest',
  'guestMemory',
  'checkoutReport',
  'checkOutInspection',
  'checkoutFinalEvent',
  'privateFeedback',
  'guestComplaint',
  'specialRequest',
  'laundryOrder',
  'inventoryAlert',
  'housekeepingTask',
  'cleaningReport',
  'souvenirOrder',
  'souvenirProduct',

  // 3. Ménage & stock (instances → produits).
  'productInstance',
  'product',

  // 4. Marketplace & monétisation (Subscription purge AVANT ShieldProperty :
  //    ShieldProperty.subscriptionId cascade depuis Subscription).
  'couponScan',
  'coupon',
  'flashSale',
  'promoRedemption',
  'promo',
  'merchantPhoto',
  'merchant',
  'serviceOrder',
  'transaction',
  'payout',
  'subscription',
  'scrapingJob',

  // 5. Prestataires & services.
  'review',
  'chatMessage',
  'serviceRequest',
  'serviceOffer',
  'service',
  'provider',

  // 6. Notifications & médias (audio en base + push).
  'notificationLog',
  'notificationSettings',
  'notification',
  'pushSubscription',
  'voiceMessage',
  'hubVoiceMessage',

  // 7. Automatisations & hub de bien.
  'propertyIcalFeed',
  'propertyAutomation',
  'automationRule',
  'webhook',
  'hostProvider',

  // 8. Coach IA, facturation hôte, activité, outbox (PDF certificats).
  'insightAction',
  'dashboardInsight',
  'coachAnalytics',
  'coachPreferences',
  'hostSettings',
  'monthlyCommissionInvoice',
  'activityLog',
  'emailOutbox',

  // 9. EDL standalone + BOUCLIER (onboarding, check-in/out, photos,
  //    vidéos — tout le circuit état des lieux).
  'inspectionItem',
  'inspectionRoom',
  'inspection',
  'shieldZoneShot',
  'shieldVideo',
  'shieldSession',
  'shieldDevice',
  'shieldZone',
  'shieldProperty',
  'edlInvoice',
  'edlPurchase',
  'inspectionSubscription',
  'edlSupportMessage',
  'edlSupportTicket',

  // 10. Membres d'équipe & biens — la purge de Property cascade sur
  //     ~45 tables enfants restantes (onDelete: Cascade).
  'propertyMember',
  'room',
  'property',

  // 11. Technique (tokens de reset de mot de passe orphelins).
  'passwordResetToken',
] as const;

export interface PurgeActor {
  id?: string | null;
  email?: string | null;
}

export interface ResetBusinessDataResult {
  purged: Record<string, number>;
  totalRows: number;
  filesRemoved: number;
}

type DeleteManyDelegate = {
  deleteMany: (args?: Record<string, never>) => Promise<{ count: number }>;
};

/** Répertoires d'uploads filesystem à vider (re-créés vides ensuite). */
const UPLOAD_DIRS: readonly string[] = [
  'data/uploads/voice', // messages vocaux (volume Docker /app/data)
  'data/uploads/concierge', // photos/GIF conciergerie
  'public/uploads/branding', // logos white-label
  'public/uploads/verification', // documents prestataires
] as const;

async function countFilesIn(dir: string): Promise<number> {
  try {
    const entries = await readdir(dir, { recursive: true, withFileTypes: true });
    return entries.filter((entry) => entry.isFile()).length;
  } catch {
    return 0; // répertoire absent → rien à compter
  }
}

/** Vide les répertoires d'uploads (re-créés vides) — chemins constants. */
async function purgeUploadDirs(): Promise<number> {
  let removed = 0;
  for (const rel of UPLOAD_DIRS) {
    const dir = path.join(process.cwd(), rel);
    removed += await countFilesIn(dir);
    await rm(dir, { recursive: true, force: true });
    await mkdir(dir, { recursive: true });
  }
  return removed;
}

/**
 * Purge TOUTES les données métier + les fichiers uploads, puis trace
 * l'opération dans l'AuditLog (conservé). Ne supprime AUCUN compte.
 */
export async function purgeBusinessData(actor: PurgeActor | null = null): Promise<ResetBusinessDataResult> {
  const client = db as unknown as Record<string, DeleteManyDelegate | undefined>;
  const purged: Record<string, number> = {};
  let totalRows = 0;

  for (const delegate of PURGE_ORDER) {
    const table = client[delegate];
    if (!table || typeof table.deleteMany !== 'function') {
      throw new Error(`Modèle Prisma introuvable pour la purge : ${delegate}`);
    }
    const { count } = await table.deleteMany({});
    if (count > 0) {
      purged[delegate] = count;
      totalRows += count;
    }
  }

  const filesRemoved = await purgeUploadDirs();

  // Trace d'audit (AuditLog est conservé — copie lisible de l'acteur).
  await db.auditLog.create({
    data: {
      actorId: actor?.id ?? null,
      actorEmail: actor?.email ?? 'system',
      action: 'platform.reset_business_data',
      entityType: 'platform',
      entityId: null,
      detailsJson: JSON.stringify({ totalRows, filesRemoved, purged }),
    },
  });

  return { purged, totalRows, filesRemoved };
}
