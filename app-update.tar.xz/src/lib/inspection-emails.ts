// =============================================================
// MODULE STANDALONE « ÉTAT DES LIEUX » — EMAILS (v4.103 + circuit v2)
//
// Emails transactionnels du module 299 €/an, envoyés via la
// file EmailOutbox (queueEmail — SMTP, fire-and-forget, retry auto) :
//   1. sendInspectionCreatedEmails() — à la CRÉATION (flux v1) :
//        • INVITÉ (si son email est connu) : invitation à compléter
//          l'état des lieux en ligne (lien public /i/<token>) ;
//        • HÔTE : confirmation de création + rappel du lien de partage.
//   2. sendInspectionCompletedEmail() — à la SIGNATURE (v4.103) :
//        • HÔTE : document signé, lien PDF direct + lien dashboard.
//        ⚠️ Circuit v2 (Task 4-a) : plus appelé pour ENTREE (aucun
//        email) ni SORTIE (remplacé par le PDF fusionné) — conservé.
//   3. sendStayCompletedEmails() — SÉJOUR COMPLÉTÉ (circuit v2) :
//        à la complétion de la SORTIE UNIQUEMENT, PDF FUSIONNÉ
//        (entrée + sortie) en pièce jointe à l'HÔTE et à l'INVITÉ.
//
// Style strict du produit : sobre, juridique, zéro émoji, palette
// RoomScan (#101b36 / #f7f6f3) — même famille que le rapport Coach.
// Ne lève JAMAIS : un échec email ne casse jamais le flux métier
// (les fonctions sont appelées en fire-and-forget dans les routes).
// =============================================================

import { db } from '@/lib/db';
import { queueEmail } from '@/lib/email';
import { inspectionShareUrl } from '@/lib/inspection-template';
import { siteUrl } from '@/lib/site';

// ---------- Helpers ----------

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

const frDateTime = (d: Date) =>
  d.toLocaleString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'Europe/Paris',
  });

/** Données minimales attendues (inspection telle que renvoyée par Prisma). */
export interface InspectionEmailData {
  propertyName: string;
  propertyAddress: string;
  ownerName: string;
  guestName: string;
  guestEmail: string | null;
  type: string; // 'ENTREE' | 'SORTIE'
  scheduledDate: Date;
  publicToken: string;
  /** Abonnement module — remonte l'email du hôte (signature). */
  subscriptionId?: string;
}

const typeLabel = (type: string) => (type === 'SORTIE' ? 'de sortie' : "d'entrée");

/** Squelette HTML commun (même famille visuelle que le rapport Coach). */
function emailShell(opts: {
  eyebrow: string;
  title: string;
  intro: string;
  bodyHtml: string;
  footerHtml: string;
}): string {
  return `
    <div style="background:#f7f6f3;padding:32px 16px;font-family:Georgia,'Times New Roman',serif">
      <div style="max-width:560px;margin:0 auto">
        <p style="margin:0;font-size:11px;font-weight:700;letter-spacing:0.18em;text-transform:uppercase;color:#8a94ad;text-align:center">${escapeHtml(opts.eyebrow)}</p>
        <h1 style="margin:10px 0 4px;font-size:24px;font-weight:600;color:#101b36;text-align:center">${opts.title}</h1>
        <p style="margin:0 0 24px;font-size:14px;line-height:1.6;color:#5d6b8a;text-align:center">${opts.intro}</p>
        ${opts.bodyHtml}
        <table style="width:100%;border-collapse:collapse;margin-top:28px">
          <tr>
            <td style="text-align:center;padding:16px;border-top:1px solid #e8edf6">
              ${opts.footerHtml}
              <p style="margin:12px 0 0;font-size:11px;color:#b6bdd0">RoomScan — États des Lieux, module indépendant.</p>
            </td>
          </tr>
        </table>
      </div>
    </div>`;
}

/** Encadré récapitulatif (logement / invité / date). */
function recapBox(inspection: InspectionEmailData): string {
  const row = (label: string, value: string) => `
    <tr>
      <td style="padding:7px 16px;font-size:12px;color:#5d6b8a;white-space:nowrap;vertical-align:top">${escapeHtml(label)}</td>
      <td style="padding:7px 16px;font-size:13px;font-weight:600;color:#101b36">${escapeHtml(value)}</td>
    </tr>`;
  return `
    <table style="width:100%;border-collapse:collapse;background:#ffffff;border:1px solid #e8edf6;border-radius:14px;overflow:hidden">
      ${row('Logement', inspection.propertyName)}
      ${row('Adresse', inspection.propertyAddress)}
      ${row('Type', `État des lieux ${typeLabel(inspection.type)}`)}
      ${row('Invité', inspection.guestName)}
      ${row('Date visée', frDateTime(inspection.scheduledDate))}
      ${row('Propriétaire', inspection.ownerName)}
    </table>`;
}

// -------------------------------------------------------------
// 1. CRÉATION — email invité + confirmation hôte
// -------------------------------------------------------------

/**
 * Invité : « vous êtes invité à compléter votre état des lieux ».
 * Envoyé uniquement si l'email de l'invité est connu (sinon no-op).
 */
async function sendGuestInviteEmail(inspection: InspectionEmailData): Promise<void> {
  if (!inspection.guestEmail) return;

  const shareUrl = inspectionShareUrl(inspection.publicToken, siteUrl);
  const subject = `Votre état des lieux ${typeLabel(inspection.type)} — ${inspection.propertyName}`;
  const html = emailShell({
    eyebrow: 'RoomScan · États des Lieux',
    title: `État des lieux ${typeLabel(inspection.type)}`,
    intro: `Bonjour <strong>${escapeHtml(inspection.guestName)}</strong>, ${escapeHtml(inspection.ownerName)} vous invite à compléter l'état des lieux ${typeLabel(inspection.type)} du logement <strong>${escapeHtml(inspection.propertyName)}</strong>, prévu le ${frDateTime(inspection.scheduledDate)}.`,
    bodyHtml: `
      <table style="width:100%;border-collapse:collapse;background:#ffffff;border:1px solid #e8edf6;border-radius:14px;overflow:hidden">
        <tr><td style="padding:20px 22px">
          <p style="margin:0 0 12px;font-size:14px;line-height:1.65;color:#3f4c6b">
            Vous décrivez chaque pièce et équipement depuis votre téléphone, joignez des photos si nécessaire,
            puis signez électroniquement. Deux minutes suffisent — aucune application à installer.
          </p>
          <p style="margin:0;font-size:13px;line-height:1.6;color:#5d6b8a">
            Ce document signé a valeur juridique et protège votre dépôt de garantie.
          </p>
        </td></tr>
      </table>
      <div style="text-align:center;margin-top:24px">
        <a href="${shareUrl}"
           style="display:inline-block;padding:12px 26px;border-radius:9999px;background:#101b36;color:#ffffff;font-size:13px;font-weight:600;text-decoration:none">
          Compléter mon état des lieux →
        </a>
        <p style="margin:14px 0 0;font-size:12px;color:#8a94ad;word-break:break-all">${escapeHtml(shareUrl)}</p>
      </div>`,
    footerHtml: `
      <p style="margin:0;font-size:11px;color:#8a94ad">
        Vous recevez cet email parce que votre séjour est concerné par un état des lieux sur roomscan.pro.
      </p>`,
  });

  await queueEmail({
    to: inspection.guestEmail,
    subject,
    html,
    text: [
      `État des lieux ${typeLabel(inspection.type)} — ${inspection.propertyName}`,
      ``,
      `Bonjour ${inspection.guestName},`,
      `${inspection.ownerName} vous invite à compléter l'état des lieux ${typeLabel(inspection.type)} du logement ${inspection.propertyName}, prévu le ${frDateTime(inspection.scheduledDate)}.`,
      `Depuis votre téléphone : pièces, photos si nécessaire, signature électronique — 2 minutes, valeur juridique.`,
      ``,
      `Ouvrir : ${shareUrl}`,
    ].join('\n'),
    template: 'inspection_guest_invite',
    referenceType: 'inspection',
    referenceId: inspection.publicToken,
    meta: { module: 'inspection', kind: 'guest_invite', type: inspection.type },
  });
}

/**
 * Hôte : confirmation de création + rappel du lien de partage et du dashboard.
 * `hostEmail` : email du compte hôte connecté (créateur du document).
 */
async function sendHostCreatedEmail(
  inspection: InspectionEmailData,
  hostEmail: string,
): Promise<void> {
  const shareUrl = inspectionShareUrl(inspection.publicToken, siteUrl);
  const subject = `État des lieux créé — ${inspection.propertyName}`;
  const html = emailShell({
    eyebrow: 'RoomScan · États des Lieux',
    title: 'Document créé',
    intro: `Votre état des lieux ${typeLabel(inspection.type)} pour <strong>${escapeHtml(inspection.propertyName)}</strong> est prêt à être partagé avec votre invité.`,
    bodyHtml: `
      ${recapBox(inspection)}
      <div style="text-align:center;margin-top:24px">
        <a href="${shareUrl}"
           style="display:inline-block;padding:12px 26px;border-radius:9999px;background:#101b36;color:#ffffff;font-size:13px;font-weight:600;text-decoration:none">
          Voir le document partagé →
        </a>
        <p style="margin:14px 0 0;font-size:12px;color:#8a94ad;word-break:break-all">${escapeHtml(shareUrl)}</p>
      </div>`,
    footerHtml: `
      <p style="margin:0;font-size:11px;color:#8a94ad">
        Partagez le lien par WhatsApp ou email depuis votre
        <a href="${siteUrl}/inspection/dashboard" style="color:#5d6b8a">tableau de bord États des Lieux</a>.
      </p>`,
  });

  await queueEmail({
    to: hostEmail,
    subject,
    html,
    text: [
      `État des lieux créé — ${inspection.propertyName}`,
      ``,
      `Votre état des lieux ${typeLabel(inspection.type)} est prêt :`,
      `Logement : ${inspection.propertyAddress}`,
      `Invité : ${inspection.guestName}${inspection.guestEmail ? ` (${inspection.guestEmail})` : ''}`,
      `Date visée : ${frDateTime(inspection.scheduledDate)}`,
      ``,
      `Lien de partage : ${shareUrl}`,
      `Tableau de bord : ${siteUrl}/inspection/dashboard`,
    ].join('\n'),
    template: 'inspection_host_created',
    referenceType: 'inspection',
    referenceId: inspection.publicToken,
    meta: { module: 'inspection', kind: 'host_created', type: inspection.type },
  });
}

/**
 * Point d'entrée création — jamais bloquant, jamais levant.
 * `hostEmail` : email du compte hôte (utilisateur connecté).
 */
export async function sendInspectionCreatedEmails(
  inspection: InspectionEmailData,
  hostEmail: string,
): Promise<void> {
  try {
    await Promise.allSettled([
      sendGuestInviteEmail(inspection),
      hostEmail ? sendHostCreatedEmail(inspection, hostEmail) : Promise.resolve(),
    ]);
  } catch (error) {
    console.error('[inspection-emails] created emails failed:', error);
  }
}

// -------------------------------------------------------------
// 2. SIGNATURE — email hôte (document complété)
// -------------------------------------------------------------

/**
 * Hôte : l'invité a signé — lien PDF direct + lien dashboard.
 * `hostEmail` : email du compte hôte propriétaire de l'abonnement.
 */
async function sendHostCompletedEmail(
  inspection: InspectionEmailData,
  hostEmail: string,
  signedAt: Date,
): Promise<void> {
  const pdfUrl = `${siteUrl}/api/inspection/pdf/${inspection.publicToken}`;
  const subject = `État des lieux signé — ${inspection.propertyName}`;
  const html = emailShell({
    eyebrow: 'RoomScan · États des Lieux',
    title: 'Document signé',
    intro: `<strong>${escapeHtml(inspection.guestName)}</strong> a signé l'état des lieux ${typeLabel(inspection.type)} du logement <strong>${escapeHtml(inspection.propertyName)}</strong> le ${frDateTime(signedAt)}.`,
    bodyHtml: `
      ${recapBox(inspection)}
      <div style="text-align:center;margin-top:24px">
        <a href="${pdfUrl}"
           style="display:inline-block;padding:12px 26px;border-radius:9999px;background:#101b36;color:#ffffff;font-size:13px;font-weight:600;text-decoration:none">
          Télécharger le PDF signé →
        </a>
        <p style="margin:14px 0 0;font-size:12px;color:#8a94ad">
          Le document est consultable en ligne à vie et vérifiable par QR code.
        </p>
      </div>`,
    footerHtml: `
      <p style="margin:0;font-size:11px;color:#8a94ad">
        Tous vos documents : <a href="${siteUrl}/inspection/dashboard" style="color:#5d6b8a">tableau de bord États des Lieux</a>.
      </p>`,
  });

  await queueEmail({
    to: hostEmail,
    subject,
    html,
    text: [
      `État des lieux signé — ${inspection.propertyName}`,
      ``,
      `${inspection.guestName} a signé l'état des lieux ${typeLabel(inspection.type)} le ${frDateTime(signedAt)}.`,
      ``,
      `PDF signé : ${pdfUrl}`,
      `Tableau de bord : ${siteUrl}/inspection/dashboard`,
    ].join('\n'),
    template: 'inspection_host_completed',
    referenceType: 'inspection',
    referenceId: inspection.publicToken,
    meta: { module: 'inspection', kind: 'host_completed', type: inspection.type },
  });
}

/**
 * Point d'entrée signature — jamais bloquant, jamais levant.
 * Remonte l'email du hôte via l'abonnement au module.
 * Circuit v2 : plus appelé pour les types ENTREE (aucun email) ni
 * SORTIE (remplacé par sendStayCompletedEmails) — conservé pour
 * les éventuels flux tiers / réutilisations futures.
 */
export async function sendInspectionCompletedEmail(
  inspection: InspectionEmailData,
  signedAt: Date,
): Promise<void> {
  try {
    if (!inspection.subscriptionId) return;
    const subscription = await db.inspectionSubscription.findUnique({
      where: { id: inspection.subscriptionId },
      select: { user: { select: { email: true } } },
    });
    const hostEmail = subscription?.user.email;
    if (!hostEmail) return;
    await sendHostCompletedEmail(inspection, hostEmail, signedAt);
  } catch (error) {
    console.error('[inspection-emails] completed email failed:', error);
  }
}

// -------------------------------------------------------------
// 3. SÉJOUR COMPLÉTÉ — PDF fusionné (circuit v2, Task 4-a)
// -------------------------------------------------------------

/** Données requises pour l'email final du séjour (circuit v2). */
export interface StayCompletedEmailInput {
  /** EDL de SORTIE (source du couple, déjà COMPLETED). */
  exit: {
    propertyName: string;
    propertyAddress: string;
    ownerName: string;
    guestName: string;
    guestEmail: string | null;
    publicToken: string;
    scheduledDate: Date;
    subscriptionId: string;
  };
  /** Date visée de l'EDL d'ENTRÉE (période du séjour). */
  entryScheduledDate: Date;
  /** Nom du fichier fusionné (pièce jointe). */
  fileName: string;
  /** Empreinte SHA-256 du document fusionné (affichée + texte). */
  sha256: string;
  /** Contenu binaire du PDF fusionné (pièce jointe). */
  pdfBytes: Uint8Array;
}

const frDateOnly = (d: Date) =>
  d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

/** Encadré récapitulatif du séjour (logement / séjour / empreinte). */
function stayRecapBox(input: StayCompletedEmailInput): string {
  const row = (label: string, value: string) => `
    <tr>
      <td style="padding:7px 16px;font-size:12px;color:#5d6b8a;white-space:nowrap;vertical-align:top">${escapeHtml(label)}</td>
      <td style="padding:7px 16px;font-size:13px;font-weight:600;color:#101b36">${escapeHtml(value)}</td>
    </tr>`;
  return `
    <table style="width:100%;border-collapse:collapse;background:#ffffff;border:1px solid #e8edf6;border-radius:14px;overflow:hidden">
      ${row('Logement', input.exit.propertyName)}
      ${row('Adresse', input.exit.propertyAddress)}
      ${row('Propriétaire', input.exit.ownerName)}
      ${row('Invité', input.exit.guestName)}
      ${row('Séjour', `${frDateOnly(input.entryScheduledDate)} → ${frDateOnly(input.exit.scheduledDate)}`)}
      ${row('Empreinte SHA-256', input.sha256)}
    </table>`;
}

/** Corps HTML/TEXT commun (même coquille visuelle que les autres emails). */
function stayEmailShell(input: StayCompletedEmailInput): { html: string; text: string } {
  const intro = `Bonjour, votre état des lieux complet du logement <strong>${escapeHtml(input.exit.propertyName)}</strong> est disponible en pièce jointe : les pages de l'entrée suivies des pages de la sortie, un seul document signé.`;
  const html = emailShell({
    eyebrow: 'RoomScan · États des Lieux',
    title: 'Séjour documenté — état des lieux complet',
    intro,
    bodyHtml: `
      ${stayRecapBox(input)}
      <div style="margin-top:20px">
        <p style="margin:0 0 12px;font-size:14px;line-height:1.65;color:#3f4c6b">
          Votre état des lieux complet (entrée + sortie) est disponible en pièce jointe —
          document signé et certifié (empreinte SHA-256 : <strong>${escapeHtml(input.sha256)}</strong>).
        </p>
        <p style="margin:0;font-size:12px;line-height:1.6;color:#5d6b8a">
          Fichier : ${escapeHtml(input.fileName)} — vérifiable en ligne par QR code.
        </p>
      </div>`,
    footerHtml: `
      <p style="margin:0;font-size:11px;color:#8a94ad">
        Tous vos documents : <a href="${siteUrl}/inspection/dashboard" style="color:#5d6b8a">tableau de bord États des Lieux</a>.
      </p>`,
  });
  const text = [
    `État des lieux complet — ${input.exit.propertyName}`,
    ``,
    `Votre état des lieux complet (entrée + sortie) est disponible en pièce jointe — document signé et certifié (empreinte SHA-256 : ${input.sha256}).`,
    ``,
    `Fichier : ${input.fileName}`,
    `Tableau de bord : ${siteUrl}/inspection/dashboard`,
  ].join('\n');
  return { html, text };
}

/** Envoi unitaire avec pièce jointe fusionnée (jamais levant). */
async function sendStayCompletedEmail(to: string, input: StayCompletedEmailInput): Promise<void> {
  const { html, text } = stayEmailShell(input);
  await queueEmail({
    to,
    subject: `État des lieux complet (entrée + sortie) — ${input.exit.propertyName}`,
    html,
    text,
    template: 'inspection_stay_completed',
    referenceType: 'inspection',
    referenceId: input.exit.publicToken,
    meta: { module: 'inspection', kind: 'stay_completed', merged: true, sha256: input.sha256 },
    attachment: {
      filename: input.fileName,
      mime: 'application/pdf',
      data: Buffer.from(input.pdfBytes),
    },
  });
}

/**
 * Circuit v2 — envoi UNIQUE final à la complétion de la SORTIE :
 * l'hôte (propriétaire de l'abonnement) ET l'invité (si son email
 * est connu) reçoivent chacun le PDF FUSIONNÉ (entrée + sortie) en
 * pièce jointe. Jamais bloquant, jamais levant.
 */
export async function sendStayCompletedEmails(input: StayCompletedEmailInput): Promise<void> {
  try {
    // Email de l'hôte : remonté via l'abonnement au module
    // (db.inspectionSubscription → userId → db.user.email).
    const subscription = await db.inspectionSubscription.findUnique({
      where: { id: input.exit.subscriptionId },
      select: { user: { select: { email: true } } },
    });
    const hostEmail = subscription?.user.email;
    if (!hostEmail) {
      console.error('[inspection-emails] stay completed: host email not found');
      return;
    }
    await Promise.allSettled([
      sendStayCompletedEmail(hostEmail, input),
      input.exit.guestEmail
        ? sendStayCompletedEmail(input.exit.guestEmail, input)
        : Promise.resolve(),
    ]);
  } catch (error) {
    console.error('[inspection-emails] stay completed emails failed:', error);
  }
}
