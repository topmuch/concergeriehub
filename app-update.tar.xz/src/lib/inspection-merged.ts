// =============================================================
// MODULE STANDALONE « ÉTAT DES LIEUX » — PDF FUSIONNÉ DU SÉJOUR
// (circuit v2 — Task 4-a, décisions client EDL-CIRCUIT-1 Q3/Q6)
//
// À la complétion de la SORTIE uniquement, le document final du
// séjour est le PDF FUSIONNÉ : pages de l'EDL d'ENTRÉE d'abord,
// pages de l'EDL de SORTIE ensuite — AUCUNE page de garde.
//
// buildMergedStayPdf() est la source unique partagée par :
//   • la route de téléchargement hôte
//     GET /api/inspection/merged-pdf/[id] (réponse binaire) ;
//   • l'email final hôte + invité (pièce jointe, submit SORTIE).
//
// Chaque EDL est rendu par le générateur historique
// renderStandaloneInspectionPdf (titres métier ATTESTATION
// D'ENTRÉE / RAPPORT DE SORTIE, photos dataURL, QR, empreinte) —
// la fusion est faite avec pdf-lib (PDFDocument.create +
// copyPages, aucune réécriture du rendu).
//
// Empreinte SHA-256 : calculée sur les bytes FUSIONNÉS complets
// (contrat client Q6) puis stockée sur les 2 inspections
// (update simple — le rendu des 2 PDF est effectué AVANT l'update
// pour que les empreintes affichées restent stables).
// Ne lève JAMAIS d'erreur brute : MergedStayPdfError typée pour
// que les appelants répondent 404/409 proprement.
// =============================================================
import { createHash } from 'crypto';
import type { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import { renderStandaloneInspectionPdf, type StandaloneInspectionPdfData } from '@/lib/inspection-standalone-pdf';
import { computeInspectionSha256 } from '@/lib/inspection-hash';

/** Erreur typée du circuit fusionné (l'appelant mappe vers 404/409). */
export class MergedStayPdfError extends Error {
  constructor(
    /** 'not_found' → 404 ; 'incomplete' → 409 (couple incomplet ou non signé). */
    public code: 'not_found' | 'incomplete',
    message: string,
  ) {
    super(message);
    this.name = 'MergedStayPdfError';
  }
}

/** Inspection complète chargée pour le rendu (rooms + items + date entrée liée). */
type FullInspection = Prisma.InspectionGetPayload<{
  include: {
    rooms: { include: { items: true } };
    linkedInspection: { select: { scheduledDate: true } };
  };
}>;

/**
 * Mappe une inspection Prisma vers le format du générateur PDF
 * historique — même mapping que /api/inspection/pdf/[token] :
 * photos dataURL, signature, propreté, preuve & anti-fraude, et
 * empreinte SHA-256 (stockée à la signature, recalculée à la volée
 * pour les documents signés avant v4.110 — contenu figé = stable).
 */
function toStandalonePdfData(inspection: FullInspection): StandaloneInspectionPdfData {
  return {
    inspection: {
      publicToken: inspection.publicToken,
      propertyName: inspection.propertyName,
      propertyAddress: inspection.propertyAddress,
      ownerName: inspection.ownerName,
      guestName: inspection.guestName,
      type: inspection.type,
      scheduledDate: inspection.scheduledDate,
      status: inspection.status,
      signedAt: inspection.signedAt,
      completedAt: inspection.completedAt,
      cleanlinessScore: inspection.cleanlinessScore,
      cleanlinessComment: inspection.cleanlinessComment,
      cleanlinessPhotoUrl: inspection.cleanlinessPhotoUrl,
      guestSignature: inspection.guestSignature,
      // Date de l'EDL d'entrée lié (page SORTIE uniquement).
      linkedEntranceDate:
        inspection.type === 'SORTIE' ? inspection.linkedInspection?.scheduledDate ?? null : null,
      city: inspection.city,
      ipAddress: inspection.ipAddress,
      gpsLocation: inspection.gpsLocation,
      sha256Hash:
        inspection.sha256Hash ??
        (inspection.status === 'COMPLETED'
          ? computeInspectionSha256({
              publicToken: inspection.publicToken,
              propertyName: inspection.propertyName,
              propertyAddress: inspection.propertyAddress,
              ownerName: inspection.ownerName,
              guestName: inspection.guestName,
              type: inspection.type,
              scheduledDate: inspection.scheduledDate,
              status: inspection.status,
              signedAt: inspection.signedAt,
              cleanlinessScore: inspection.cleanlinessScore,
              cleanlinessComment: inspection.cleanlinessComment,
              cleanlinessPhotoUrl: inspection.cleanlinessPhotoUrl,
              guestSignature: inspection.guestSignature,
              rooms: inspection.rooms.map((room) => ({
                name: room.name,
                globalState: room.globalState,
                comment: room.comment,
                items: room.items.map((item) => ({
                  name: item.name,
                  state: item.state,
                  comment: item.comment,
                  photoUrl: item.photoUrl,
                  photoOnUrl: item.photoOnUrl,
                  photoOffUrl: item.photoOffUrl,
                })),
              })),
            })
          : null),
    },
    rooms: inspection.rooms.map((room) => ({
      name: room.name,
      globalState: room.globalState,
      comment: room.comment,
      items: room.items.map((item) => ({
        name: item.name,
        state: item.state,
        comment: item.comment,
        photoUrl: item.photoUrl,
        photoOnUrl: item.photoOnUrl,
        photoOffUrl: item.photoOffUrl,
      })),
    })),
  };
}

/** Options include pour charger une inspection complète (3 usages). */
const FULL_INSPECTION_INCLUDE = {
  rooms: {
    orderBy: { sortOrder: 'asc' as const },
    include: { items: { orderBy: { sortOrder: 'asc' as const } } },
  },
  linkedInspection: { select: { scheduledDate: true } },
} satisfies Prisma.InspectionInclude;

/**
 * Nom de propriété « fichier » : accents retirés (NFD), tout
 * caractère non alphanumérique → tiret, sans doublons de tirets,
 * plafonné à 60 caractères. Toujours ASCII → sûr en Content-Disposition.
 */
function slugifyPropertyName(name: string): string {
  return (
    name
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60) || 'propriete'
  );
}

/**
 * Construit le PDF FUSIONNÉ du séjour (ENTRÉE puis SORTIE).
 *
 * @param exitInspectionId id de l'EDL de SORTIE (ou de l'ENTRÉE —
 *        le couple est résolu dans les deux sens via linkedInspectionId).
 * @throws MergedStayPdfError 'not_found'  → inspection inconnue ou sans couple ;
 *         MergedStayPdfError 'incomplete' → l'ENTRÉE ou la SORTIE n'est
 *         pas COMPLETED (l'appelant répond 409).
 */
export async function buildMergedStayPdf(exitInspectionId: string): Promise<{
  bytes: Uint8Array;
  fileName: string;
  sha256: string;
}> {
  // ── 1. Résolution du couple (SORTIE ↔ ENTRÉE) ──
  let exit: FullInspection | null = await db.inspection.findUnique({
    where: { id: exitInspectionId },
    include: FULL_INSPECTION_INCLUDE,
  });

  // On a passé l'ENTRÉE → retrouver sa SORTIE liée (linkedBy).
  if (exit && exit.type !== 'SORTIE') {
    const linkedExit = await db.inspection.findFirst({
      where: { linkedInspectionId: exit.id, type: 'SORTIE' },
      select: { id: true },
    });
    if (!linkedExit) {
      throw new MergedStayPdfError(
        'not_found',
        "Aucun état des lieux de sortie n'est lié à cette entrée.",
      );
    }
    exit = await db.inspection.findUnique({
      where: { id: linkedExit.id },
      include: FULL_INSPECTION_INCLUDE,
    });
  }

  if (!exit) {
    throw new MergedStayPdfError('not_found', 'État des lieux introuvable.');
  }

  // ── 2. L'ENTRÉE liée (couple incomplet → 409) ──
  const entry: FullInspection | null = exit.linkedInspectionId
    ? await db.inspection.findUnique({
        where: { id: exit.linkedInspectionId },
        include: FULL_INSPECTION_INCLUDE,
      })
    : null;
  if (!entry || entry.type !== 'ENTREE') {
    throw new MergedStayPdfError(
      'incomplete',
      "Le couple entrée/sortie est incomplet : aucun état des lieux d'entrée lié.",
    );
  }

  // ── 3. Garde métier : les 2 documents doivent être signés ──
  if (entry.status !== 'COMPLETED' || exit.status !== 'COMPLETED') {
    throw new MergedStayPdfError(
      'incomplete',
      'Le PDF fusionné est disponible après la complétion du check-out.',
    );
  }

  // ── 4. Rendu des 2 PDF via le générateur historique ──
  const [entryBuffer, exitBuffer] = await Promise.all([
    renderStandaloneInspectionPdf(toStandalonePdfData(entry)),
    renderStandaloneInspectionPdf(toStandalonePdfData(exit)),
  ]);

  // ── 5. Fusion pdf-lib : pages ENTRÉE d'abord, pages SORTIE ensuite ──
  const { PDFDocument } = await import('pdf-lib');
  const merged = await PDFDocument.create();
  const entryDoc = await PDFDocument.load(entryBuffer, { ignoreEncryption: true });
  const exitDoc = await PDFDocument.load(exitBuffer, { ignoreEncryption: true });

  const entryPages = await merged.copyPages(entryDoc, entryDoc.getPageIndices());
  for (const page of entryPages) merged.addPage(page);
  const exitPages = await merged.copyPages(exitDoc, exitDoc.getPageIndices());
  for (const page of exitPages) merged.addPage(page);

  const mergedBytes = await merged.save(); // Uint8Array (PDF complet)

  // ── 6. Empreinte SHA-256 du document fusionné complet (contrat Q6) ──
  const sha256 = createHash('sha256').update(Buffer.from(mergedBytes)).digest('hex');

  // Stockée sur les 2 inspections (update simple). Le rendu (étape 4)
  // a DÉJÀ été effectué avec les empreintes canoniques d'alors → les
  // empreintes affichées dans les PDF restent stables.
  await db.inspection
    .updateMany({
      where: { id: { in: [entry.id, exit.id] } },
      data: { sha256Hash: sha256 },
    })
    .catch((error) =>
      console.error('[inspection-merged] sha256 persist failed:', error),
    );

  // ── 7. Nom de fichier normalisé : Etat-des-lieux_{Propriété}_{AAAA-MM-JJ}.pdf ──
  // Date de référence = date visée de la SORTIE (clôture du séjour).
  const fileName = `Etat-des-lieux_${slugifyPropertyName(exit.propertyName)}_${exit.scheduledDate
    .toISOString()
    .slice(0, 10)}.pdf`;

  return { bytes: mergedBytes, fileName, sha256 };
}
