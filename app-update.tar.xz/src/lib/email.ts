// =============================================================
// EMAIL OUTBOX — ÉTAPE 22 (V3) — SERVER ONLY
//
// File d'emails transactionnels journalisée en base (EmailOutbox).
//
// Principes (alignés sur le moteur d'automatisations É13) :
//  - FIRE-AND-FORGET : queueEmail() ne lève JAMAIS — un échec email
//    ne doit jamais casser le flux métier (réservation, paiement…).
//  - 1 email = 1 ligne d'audit : QUEUED (en file) → SENT (remis au
//    provider, ou mode démo dev) / FAILED (retentable via Console).
//  - PROVIDERS (aucune dépendance au démarrage) :
//      * RESEND_API_KEY        → API HTTPS Resend (fetch natif)
//      * SMTP_HOST + SMTP_PORT → nodemailer (import dynamique lazy)
//      * sans clés en dev      → mode DÉMO : status SENT + provider
//        'demo' (aucun envoi réel, l'email est consultable dans la
//        Console Superadmin /admin/emails)
//      * sans clés en prod     → FAILED « provider non configuré »
//        (retentez après configuration : bouton Réessayer)
//  - CLÉS : RESEND_API_KEY, SMTP_HOST, SMTP_PORT, SMTP_USER,
//    SMTP_PASS, EMAIL_FROM, NOTIFICATIONS_EMAIL.
//  - v4.55 — NOTIFICATIONS_EMAIL : boîte « mail du système ». Si
//    configurée (Coolify), les emails de NOTIFICATION (alertes hôte,
//    automatisations, relais superadmin) partent sur CETTE boîte
//    centrale et JAMAIS sur le mail des comptes hôtes. Les emails
//    transactionnels INVITÉS (reçus, avis…) restent inchangés.
//  - v4.56 — CONFIG ÉDITABLE : les deux réglages (expéditeur + boîte
//    de réception des notifications) sont désormais éditables depuis
//    la Console Superadmin (/admin/emails → Configuration) et
//    persistés en base (table system_settings). Priorité de
//    résolution : BASE DE DONNÉES > variable d'environnement > défaut
//    codé. Valeur vide en base = pas d'override (retour env/défaut).
//
// ⚠️ Ne jamais ré-exporter ce module depuis une lib partagée
// client/server (leçon ioredis É21) : imports directs côté API.
// =============================================================
import { db } from '@/lib/db';

export interface QueueEmailParams {
  to: string;
  subject: string;
  html: string;
  text?: string;
  /** Clé de template : 'host_notification' | 'guest_receipt' | 'guest_refund' | 'custom'. */
  template: string;
  userId?: string | null;
  propertyId?: string | null;
  referenceType?: string | null;
  referenceId?: string | null;
  meta?: Record<string, unknown>;
}

export interface QueueEmailResult {
  id: string | null;
  status: 'QUEUED' | 'SENT' | 'FAILED' | 'SKIPPED';
  provider: string | null;
  error: string | null;
}

// v4.55 — Expéditeur par défaut = adresse SYSTÈME sur le domaine de
// production (jamais le mail d'un hôte). Surchargable via EMAIL_FROM
// ou la config Superadmin (v4.56).
const DEFAULT_FROM = 'Conciergerie Hub <noreply@roomscan.pro>';

// v4.56 — Clés de configuration en base (table system_settings).
export const EMAIL_SETTING_KEYS = {
  FROM: 'email.from',
  NOTIFICATIONS_INBOX: 'email.notifications_inbox',
} as const;

interface DbEmailSettings {
  from: string | null;
  inbox: string | null;
}

// Cache 30 s : évite une lecture SQLite à chaque envoi. Invalidation
// immédiate à la sauvegarde (invalidateEmailConfigCache).
let cfgCache: { value: DbEmailSettings; at: number } | null = null;
const CFG_TTL_MS = 30_000;

export function invalidateEmailConfigCache(): void {
  cfgCache = null;
}

async function dbEmailSettings(): Promise<DbEmailSettings> {
  if (cfgCache && Date.now() - cfgCache.at < CFG_TTL_MS) return cfgCache.value;
  let value: DbEmailSettings = { from: null, inbox: null };
  try {
    const rows = await db.systemSetting.findMany({
      where: { key: { in: [EMAIL_SETTING_KEYS.FROM, EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX] } },
      select: { key: true, value: true },
    });
    for (const row of rows) {
      if (row.key === EMAIL_SETTING_KEYS.FROM) value.from = row.value;
      if (row.key === EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX) value.inbox = row.value;
    }
  } catch (error) {
    // Table absente (démarrage à froid) → fallback env/défaut, jamais bloquant.
    console.error('[email] dbEmailSettings failed (fallback env):', error);
  }
  cfgCache = { value, at: Date.now() };
  return value;
}

async function fromAddress(): Promise<string> {
  const settings = await dbEmailSettings();
  return settings.from?.trim() || process.env.EMAIL_FROM?.trim() || DEFAULT_FROM;
}

/** Adresse d'expéditeur effective (affichage Console Superadmin). */
export async function emailFromAddress(): Promise<string> {
  return fromAddress();
}

/**
 * Boîte centrale « mail du système » (redirection des notifications).
 * Priorité : config Superadmin (system_settings) > env NOTIFICATIONS_EMAIL.
 * Vide = aucune redirection (comportement historique : email copie
 * envoyé au mail de chaque compte hôte). Jamais bloquant.
 */
export async function systemNotificationEmail(): Promise<string> {
  const settings = await dbEmailSettings();
  const inbox = settings.inbox !== null ? settings.inbox.trim() : (process.env.NOTIFICATIONS_EMAIL?.trim() ?? '');
  return inbox.includes('@') ? inbox : '';
}

/**
 * v4.56 — Sauvegarde d'un réglage e-mail depuis la Console Superadmin.
 * Valeur vide → l'override est SUPPRIMÉ (retour env/défaut).
 * `kind` : 'from' (expéditeur) ou 'inbox' (boîte notifications).
 */
export async function saveEmailSetting(
  kind: 'from' | 'inbox',
  rawValue: string,
): Promise<{ ok: boolean; error?: string }> {
  const value = rawValue.trim();
  const key = kind === 'from' ? EMAIL_SETTING_KEYS.FROM : EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX;
  try {
    if (!value) {
      await db.systemSetting.deleteMany({ where: { key } });
    } else {
      // Validation souple : doit contenir un email (« a@b.c » ou
      // « Nom <a@b.c> » pour l'expéditeur).
      const emailPart = kind === 'from' ? (value.match(/<([^>]+)>/)?.[1] ?? value) : value;
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailPart)) {
        return { ok: false, error: 'Adresse email invalide (ex : nom@domaine.fr ou Conciergerie <noreply@domaine.fr>)' };
      }
      await db.systemSetting.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      });
    }
    invalidateEmailConfigCache();
    return { ok: true };
  } catch (error) {
    console.error('[email] saveEmailSetting failed:', error);
    return { ok: false, error: 'Sauvegarde impossible (base de données)' };
  }
}

/** Un provider réel est-il configuré ? (sinon démo dev / échec prod) */
export function emailProviderConfigured(): boolean {
  return Boolean(
    process.env.RESEND_API_KEY?.trim() ||
      (process.env.SMTP_HOST?.trim() && process.env.SMTP_PORT?.trim()),
  );
}

function isDev(): boolean {
  return process.env.NODE_ENV !== 'production';
}

// -------------------------------------------------------------
// Envoi réel par provider (lève en cas d'échec → géré par deliver)
// -------------------------------------------------------------

async function sendViaResend(params: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<void> {
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: await fromAddress(),
      to: [params.to],
      subject: params.subject,
      html: params.html,
      ...(params.text ? { text: params.text } : {}),
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Resend HTTP ${res.status} : ${body.slice(0, 300)}`);
  }
}

async function sendViaSmtp(params: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<void> {
  // Import dynamique lazy : nodemailer ne doit JAMAIS entrer dans un
  // bundle client (même leçon que ioredis, É21).
  const nodemailer = (await import('nodemailer')).default;
  const port = Number(process.env.SMTP_PORT || 587);
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port,
    secure: port === 465,
    auth:
      process.env.SMTP_USER && process.env.SMTP_PASS
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        : undefined,
  });
  await transport.sendMail({
    from: await fromAddress(),
    to: params.to,
    subject: params.subject,
    html: params.html,
    ...(params.text ? { text: params.text } : {}),
  });
}

// -------------------------------------------------------------
// Délivrance d'une entrée de l'outbox
// -------------------------------------------------------------

export interface DeliverResult {
  status: 'SENT' | 'FAILED' | 'SKIPPED';
  provider: string | null;
  error: string | null;
}

/**
 * Tente la délivrance d'un email de l'outbox (idempotent côté statut :
 * un email SENT n'est jamais renvoyé). Incrémente attempts et trace
 * l'erreur éventuelle. Ne lève jamais.
 */
export async function deliverEmail(outboxId: string): Promise<DeliverResult> {
  try {
    const row = await db.emailOutbox.findUnique({ where: { id: outboxId } });
    if (!row) return { status: 'SKIPPED', provider: null, error: 'introuvable' };
    if (row.status === 'SENT') return { status: 'SKIPPED', provider: row.provider, error: null };

    const attempts = row.attempts + 1;
    const payload = { to: row.to, subject: row.subject, html: row.htmlBody, text: row.textBody ?? undefined };

    // ── Provider réel configuré ? ──
    if (process.env.RESEND_API_KEY?.trim()) {
      try {
        await sendViaResend(payload);
        await db.emailOutbox.update({
          where: { id: outboxId },
          data: { status: 'SENT', provider: 'resend', attempts, sentAt: new Date(), lastError: null },
        });
        return { status: 'SENT', provider: 'resend', error: null };
      } catch (error) {
        return await markFailed(outboxId, attempts, error, 'resend');
      }
    }

    if (process.env.SMTP_HOST?.trim() && process.env.SMTP_PORT?.trim()) {
      try {
        await sendViaSmtp(payload);
        await db.emailOutbox.update({
          where: { id: outboxId },
          data: { status: 'SENT', provider: 'smtp', attempts, sentAt: new Date(), lastError: null },
        });
        return { status: 'SENT', provider: 'smtp', error: null };
      } catch (error) {
        return await markFailed(outboxId, attempts, error, 'smtp');
      }
    }

    // ── Sans clés ──
    if (isDev()) {
      // Mode démo : journalisé comme envoyé (aucun envoi réel),
      // consultable dans la Console Superadmin.
      await db.emailOutbox.update({
        where: { id: outboxId },
        data: { status: 'SENT', provider: 'demo', attempts, sentAt: new Date(), lastError: null },
      });
      return { status: 'SENT', provider: 'demo', error: null };
    }

    // Prod sans provider → échec explicite et retentable.
    return await markFailed(
      outboxId,
      attempts,
      new Error('Aucun provider email configuré (RESEND_API_KEY ou SMTP_HOST/SMTP_PORT)'),
      null,
    );
  } catch (error) {
    console.error('[email] deliverEmail failed:', error);
    return { status: 'FAILED', provider: null, error: error instanceof Error ? error.message : 'erreur inconnue' };
  }
}

async function markFailed(
  outboxId: string,
  attempts: number,
  error: unknown,
  provider: string | null,
): Promise<DeliverResult> {
  const message = error instanceof Error ? error.message : String(error);
  await db.emailOutbox
    .update({
      where: { id: outboxId },
      data: { status: 'FAILED', provider, attempts, lastError: message.slice(0, 900) },
    })
    .catch((e) => console.error('[email] markFailed update failed:', e));
  return { status: 'FAILED', provider, error: message };
}

// -------------------------------------------------------------
// API publique : queue + délivrance inline (fire-and-forget)
// -------------------------------------------------------------

/**
 * Journalise un email dans l'outbox puis tente sa délivrance
 * immédiatement. NE LÈVE JAMAIS (le flux métier appelle sans garde).
 */
export async function queueEmail(params: QueueEmailParams): Promise<QueueEmailResult> {
  // Destinataire invalide → no-op silencieux (jamais bloquant).
  const to = params.to?.trim();
  if (!to || !to.includes('@')) {
    return { id: null, status: 'SKIPPED', provider: null, error: 'destinataire invalide' };
  }
  try {
    const row = await db.emailOutbox.create({
      data: {
        to,
        subject: params.subject,
        htmlBody: params.html,
        textBody: params.text ?? null,
        template: params.template,
        status: 'QUEUED',
        userId: params.userId ?? null,
        propertyId: params.propertyId ?? null,
        referenceType: params.referenceType ?? null,
        referenceId: params.referenceId ?? null,
        metaJson: JSON.stringify(params.meta ?? {}),
      },
      select: { id: true },
    });
    const delivered = await deliverEmail(row.id);
    return { id: row.id, status: delivered.status, provider: delivered.provider, error: delivered.error };
  } catch (error) {
    console.error('[email] queueEmail failed:', error);
    return {
      id: null,
      status: 'FAILED',
      provider: null,
      error: error instanceof Error ? error.message : 'erreur inconnue',
    };
  }
}

export interface RetryEmailResult {
  notFound?: boolean;
  alreadySent?: boolean;
  status?: 'SENT' | 'FAILED' | 'SKIPPED';
  provider?: string | null;
  error?: string | null;
}

/**
 * Réessaie un email FAILED/QUEUED (bouton Console Superadmin).
 * Un email SENT n'est jamais renvoyé (idempotence).
 */
export async function retryEmail(outboxId: string): Promise<RetryEmailResult> {
  const row = await db.emailOutbox.findUnique({ where: { id: outboxId }, select: { status: true } });
  if (!row) return { notFound: true };
  if (row.status === 'SENT') return { alreadySent: true };
  const result = await deliverEmail(outboxId);
  return { status: result.status, provider: result.provider, error: result.error };
}
