// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — DÉTECTION SMART (vision IA, serveur)
//
// Analyse chaque photo de zone (taches, casses, saleté, désordre,
// dégâts) et renvoie un JSON STRICT :
//   { hasAnomaly, description, severity 'LOW'|'MEDIUM'|'HIGH',
//     suggestedAction, boundingBox? { x, y, width, height } (0–1) }
//
// MOTEURS (par ordre de priorité) :
//   1. GROQ VISION (meta-llama/llama-4-scout) — actif dès que
//      GROQ_API_KEY est définie dans .env (API REST OpenAI-compatible,
//      aucun SDK supplémentaire — fetch natif).
//   2. MOTEUR VISION DU SDK SERVEUR (z-ai-web-dev-sdk, glm-4.6v) —
//      repli automatique si Groq échoue ou clé absente.
//   3. FALLBACK local — l'analyse ne doit JAMAIS casser le flux.
// Le champ `model` de chaque analyse reflète le moteur RÉELLEMENT
// utilisé (traçabilité juridique). Le SDK z-ai est exclusivement
// BACKEND (jamais importé côté client).
// =============================================================
import ZAI from 'z-ai-web-dev-sdk';

export type AiSeverity = 'LOW' | 'MEDIUM' | 'HIGH';

export interface RoomPhotoAnalysis {
  hasAnomaly: boolean;
  description: string;
  severity: AiSeverity;
  suggestedAction: string;
  boundingBox?: { x: number; y: number; width: number; height: number };
  /** Métadonnées de traçabilité (modèle + horodatage). */
  model: string;
  analyzedAt: string;
}

export interface SessionAiSummary {
  globalState: 'IMPECCABLE' | 'BON' | 'MOYEN' | 'MAUVAIS';
  anomalies: string[];
  recommendation: string;
  model: string;
  analyzedAt: string;
}

// API Groq (OpenAI-compatible) : endpoint chat/completions standard.
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
// Modèles vision multimodaux Groq (Llama 4 Scout d'abord, Maverick en
// repli — Groq décommissionne régulièrement des modèles, l'ID évolue).
const GROQ_MODELS = [
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'meta-llama/llama-4-maverick-17b-128e-instruct',
];
const VISION_MODEL = 'glm-4.6v';
/** Garde-fou de latence : aucune analyse ne doit pendre indéfiniment. */
const AI_TIMEOUT_MS = 25_000;

const SYSTEM_PROMPT =
  'Tu es un expert en état des lieux immobilier. Tu réponds UNIQUEMENT avec le JSON demandé, rien d\u2019autre, sans markdown.';

const PHOTO_PROMPT = (roomName: string) => `Tu es un expert en état des lieux immobilier. Analyse cette photo de "${roomName}".

Si tu détectes une anomalie (tache, casse, saleté, désordre, dégât), réponds AU FORMAT JSON STRICT :
{
  "hasAnomaly": true,
  "description": "Description précise en français (ex: Tache sombre de 15cm sur le coussin gauche du canapé)",
  "severity": "LOW|MEDIUM|HIGH",
  "suggestedAction": "Action recommandée (ex: Nettoyage professionnel requis)",
  "boundingBox": { "x": 0.3, "y": 0.4, "width": 0.2, "height": 0.3 }
}

Les coordonnées boundingBox sont en pourcentage (0-1) de l'image, indiquant la zone du dégât.

Si tout est en bon état, réponds :
{
  "hasAnomaly": false,
  "description": "Aucune anomalie visible",
  "severity": "LOW",
  "suggestedAction": "Aucune action requise"
}

Réponds UNIQUEMENT avec le JSON, rien d'autre.`;

/** Clé Groq présente et plausible (les clés gsk_ font > 20 caractères). */
function hasGroqKey(): boolean {
  const key = process.env.GROQ_API_KEY;
  return typeof key === 'string' && key.trim().length > 20;
}

/** Extraction robuste du premier objet JSON d'une réponse LLM. */
function parseJsonLoose<T>(text: string): T | null {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    return JSON.parse(match[0]) as T;
  } catch {
    return null;
  }
}

/** Borne les coordonnées du boundingBox (0–1) — défense en profondeur. */
function sanitizeBoundingBox(raw: unknown): RoomPhotoAnalysis['boundingBox'] | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const b = raw as Record<string, unknown>;
  const nums = [b.x, b.y, b.width, b.height].map((v) =>
    typeof v === 'number' && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : NaN,
  );
  if (nums.some((v) => Number.isNaN(v))) return undefined;
  const [x, y, width, height] = nums;
  if (width <= 0.01 || height <= 0.01) return undefined;
  return { x, y, width, height };
}

/** Normalise la réponse brute d'un moteur en analysis valide (jamais d'exception). */
function normalizeAnalysis(
  parsed: Partial<RoomPhotoAnalysis> | null,
  model: string,
): RoomPhotoAnalysis | null {
  if (!parsed || typeof parsed.hasAnomaly !== 'boolean') return null;
  const stamp = new Date().toISOString();
  const severity: AiSeverity =
    parsed.severity === 'MEDIUM' || parsed.severity === 'HIGH' ? parsed.severity : 'LOW';
  return {
    hasAnomaly: parsed.hasAnomaly,
    description:
      typeof parsed.description === 'string' && parsed.description.trim()
        ? parsed.description.trim().slice(0, 400)
        : parsed.hasAnomaly
          ? 'Anomalie détectée'
          : 'Aucune anomalie visible',
    severity,
    suggestedAction:
      typeof parsed.suggestedAction === 'string' && parsed.suggestedAction.trim()
        ? parsed.suggestedAction.trim().slice(0, 300)
        : 'Aucune action requise',
    boundingBox: parsed.hasAnomaly ? sanitizeBoundingBox(parsed.boundingBox) : undefined,
    model,
    analyzedAt: stamp,
  };
}

/** Rejette la promesse si elle dépasse `ms` (le moteur sous-jacent est abandonné). */
function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout ${ms}ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

/** Valeur de secours (l'analyse ne doit JAMAIS faire planter le flux). */
export function fallbackPhotoAnalysis(roomName: string): RoomPhotoAnalysis {
  return {
    hasAnomaly: false,
    description: `Analyse IA indisponible pour ${roomName} — vérification manuelle requise.`,
    severity: 'LOW',
    suggestedAction: 'Vérification manuelle requise',
    model: 'fallback',
    analyzedAt: new Date().toISOString(),
  };
}

// -------------------------------------------------------------
// MOTEUR 1 — GROQ VISION (clé client, prioritaire)
// -------------------------------------------------------------
async function analyzeWithGroq(
  imageBase64: string,
  roomName: string,
): Promise<RoomPhotoAnalysis | null> {
  if (!hasGroqKey()) return null;
  const m = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64,(.+)$/);
  if (!m) return null;
  // Normalise le mime (Groq n'accepte pas image/jpg) et reconstruit le dataURL.
  const dataUrl = `data:image/jpeg;base64,${m[2]}`;
  const apiKey = process.env.GROQ_API_KEY!.trim();

  for (const model of GROQ_MODELS) {
    try {
      const res = await fetch(GROQ_API_URL, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            {
              role: 'user',
              content: [
                { type: 'text', text: PHOTO_PROMPT(roomName) },
                { type: 'image_url', image_url: { url: dataUrl } },
              ],
            },
          ],
          temperature: 0.2,
          max_tokens: 1024,
        }),
      });

      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        // Diagnostic ciblé : blocage géo à l'edge Cloudflare (403 Forbidden)
        // → la clé n'est pas testable depuis cette région ; Groq servira
        // depuis une région supportée (ex. prod EU). Inutile d'essayer
        // le 2ᵉ modèle : même blocage edge.
        if (res.status === 403 && /forbidden/i.test(errText)) {
          console.error(
            '[ai-vision] Groq: région serveur bloquée par l\u2019API (Cloudflare 403) ' +
              '— repli glm-4.6v actif. Déployé dans une région supportée (EU/US), ' +
              'Groq vision servira automatiquement.',
          );
          return null;
        }
        // Modèle décommissionné / introuvable → essai du modèle suivant.
        if (/decommissioned|model_not_found|does not exist|not found/i.test(errText)) {
          console.error(`[ai-vision] Groq: modèle ${model} indisponible → modèle suivant.`);
          continue;
        }
        console.error(
          `[ai-vision] Groq ${model} HTTP ${res.status} → moteur suivant:`,
          errText.slice(0, 200),
        );
        continue;
      }

      const json = (await res.json().catch(() => null)) as {
        choices?: { message?: { content?: string } }[];
      } | null;
      const text = json?.choices?.[0]?.message?.content ?? '';
      const parsed = parseJsonLoose<Partial<RoomPhotoAnalysis>>(text);
      const normalized = normalizeAnalysis(parsed, model);
      if (!normalized) {
        console.error('[ai-vision] Groq: réponse JSON invalide → moteur suivant.');
        continue;
      }
      return normalized;
    } catch (error) {
      console.error(
        '[ai-vision] Groq failed → moteur suivant:',
        error instanceof Error ? error.message : error,
      );
    }
  }
  return null;
}

// -------------------------------------------------------------
// MOTEUR 2 — SDK SERVEUR z-ai (glm-4.6v), repli automatique
// -------------------------------------------------------------
async function analyzeWithZai(
  imageBase64: string,
  roomName: string,
): Promise<RoomPhotoAnalysis | null> {
  try {
    const zai = await ZAI.create();
    const response = await zai.chat.completions.createVision({
      model: VISION_MODEL,
      messages: [
        { role: 'assistant', content: SYSTEM_PROMPT },
        {
          role: 'user',
          content: [
            { type: 'text', text: PHOTO_PROMPT(roomName) },
            { type: 'image_url', image_url: { url: imageBase64 } },
          ],
        },
      ],
      thinking: { type: 'disabled' },
    });
    const text = response.choices?.[0]?.message?.content ?? '';
    const parsed = parseJsonLoose<Partial<RoomPhotoAnalysis>>(text);
    return normalizeAnalysis(parsed, VISION_MODEL);
  } catch (error) {
    console.error(
      '[ai-vision] glm-4.6v failed → fallback local:',
      error instanceof Error ? error.message : error,
    );
    return null;
  }
}

/**
 * Analyse UNE photo de zone (dataURL image/jpeg|png) avec le moteur
 * prioritaire disponible. Aucune exception ne sort de cette fonction :
 * en cas d'échec le fallback est retourné (le flux cleaner ne doit
 * jamais casser).
 */
export async function analyzeRoomPhoto(
  imageBase64: string,
  roomName: string,
): Promise<RoomPhotoAnalysis> {
  try {
    // Garde-fou : dataURL seulement, taille raisonnable (≤ 4 Mo base64).
    if (!/^data:image\/(jpeg|jpg|png);base64,/.test(imageBase64) || imageBase64.length > 5_600_000) {
      return fallbackPhotoAnalysis(roomName);
    }
    // 1) Groq vision (clé client) — sinon null, on continue.
    const groq = await withTimeout(
      analyzeWithGroq(imageBase64, roomName),
      AI_TIMEOUT_MS,
    ).catch(() => null);
    if (groq) return groq;
    // 2) Repli : moteur vision du SDK serveur.
    const zai = await withTimeout(
      analyzeWithZai(imageBase64, roomName),
      AI_TIMEOUT_MS,
    ).catch(() => null);
    if (zai) return zai;
    // 3) Fallback déterministe.
    return fallbackPhotoAnalysis(roomName);
  } catch (error) {
    console.error('[ai-vision] analyzeRoomPhoto failed:', error);
    return fallbackPhotoAnalysis(roomName);
  }
}

/**
 * Synthèse GLOBALE de session à partir des analyses par photo —
 * déterministe (aucun 2ᵉ appel modèle, latence zéro) :
 *   IMPECCABLE (aucune anomalie) · BON (LOW seulement) ·
 *   MOYEN (≥1 MEDIUM) · MAUVAIS (≥1 HIGH).
 */
export function summarizeSessionAnalysis(
  analyses: RoomPhotoAnalysis[],
): SessionAiSummary {
  const stamp = new Date().toISOString();
  const real = (analyses ?? []).filter((a) => a && typeof a.hasAnomaly === 'boolean');
  const anomalies = real
    .filter((a) => a.hasAnomaly)
    .map((a) => `[${a.severity}] ${a.description}`);
  const hasHigh = real.some((a) => a.hasAnomaly && a.severity === 'HIGH');
  const hasMedium = real.some((a) => a.hasAnomaly && a.severity === 'MEDIUM');
  const hasAny = anomalies.length > 0;

  const globalState: SessionAiSummary['globalState'] = !hasAny
    ? 'IMPECCABLE'
    : hasHigh
      ? 'MAUVAIS'
      : hasMedium
        ? 'MOYEN'
        : 'BON';

  const worst = real
    .filter((a) => a.hasAnomaly)
    .sort((a, b) => {
      const rank = { HIGH: 3, MEDIUM: 2, LOW: 1 } as const;
      return rank[b.severity] - rank[a.severity];
    })[0];

  const recommendation = !hasAny
    ? 'Logement rendu conforme — caution libérable sans retenue.'
    : worst
      ? `${worst.suggestedAction}${worst.boundingBox ? ' (zone encadrée sur la photo)' : ''}`
      : 'Vérification manuelle requise';

  return {
    globalState,
    anomalies,
    recommendation,
    model: real[0]?.model ?? 'n/a',
    analyzedAt: stamp,
  };
}
