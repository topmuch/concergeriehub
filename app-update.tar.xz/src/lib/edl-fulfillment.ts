// =============================================================
// EDL FULFILLMENT — Capture PayPal + création de compte (v4.107)
// SERVER ONLY. Utilisé par la page /edl/paiement/retour (capture)
// et l'API /api/edl/activate (création du compte EDL-only).
// v5.3 — FACTURE D'ABONNEMENT : une EdlInvoice (statut PAID) est
// émise automatiquement dès que l'achat passe « paid », avec un
// numéro séquentiel RS-<ANNÉE>-<0001> (retry anti-collision).
// =============================================================
import { compare, hash } from 'bcryptjs';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { captureEdlPayPalOrder, EDL_PLAN } from '@/lib/edl-paypal';
import { queueEmail } from '@/lib/email';

// -------------------------------------------------------------
// FACTURE D'ABONNEMENT EDL (v5.3)
// -------------------------------------------------------------

/** Libellé de l'offre facturée (EdlPurchase.amountEur = 299). */
export const EDL_PLAN_LABEL = 'Abonnement RoomScan — 1 à 3 biens';

/** Libellé de l'offre facturée (EdlPurchase.amountEur = 499). */
export const EDL_PRO_PLAN_LABEL = 'Abonnement RoomScan — 4 à 20 biens';

/** Libellé dérivé du montant payé (299 → 1-3 biens, 499 → 4-20 biens). */
function edlPlanLabelForAmount(amountEur: number): string {
  return amountEur >= 499 ? EDL_PRO_PLAN_LABEL : EDL_PLAN_LABEL;
}

export interface IssueEdlInvoiceInput {
  purchaseId?: string | null;
  userId?: string | null;
  buyerName: string;
  buyerEmail: string;
  planLabel?: string;
  amountEur?: number;
  paidAt?: Date | null;
}

/**
 * Crée la facture PAYÉE au numéro séquentiel RS-<ANNÉE>-<0001>.
 * Le compteur repart de 1 chaque année ; les collisions de numéro
 * (courses entre deux captures) sont absorbées par retry incrémental.
 * Never-throw : renvoie null si l'émission échoue (la capture ne
 * doit jamais être bloquée par la facturation).
 */
export async function issueEdlInvoice(
  input: IssueEdlInvoiceInput,
): Promise<{ id: string; invoiceNumber: string } | null> {
  const year = new Date().getFullYear();
  const yearStart = new Date(Date.UTC(year, 0, 1));
  let attempt =
    (await db.edlInvoice.count({ where: { issuedAt: { gte: yearStart } } })) + 1;

  for (let i = 0; i < 8; i += 1) {
    const invoiceNumber = `RS-${year}-${String(attempt).padStart(4, '0')}`;
    try {
      const created = await db.edlInvoice.create({
        data: {
          invoiceNumber,
          purchaseId: input.purchaseId ?? null,
          userId: input.userId ?? null,
          buyerName: input.buyerName.trim().slice(0, 120) || 'Client RoomScan',
          buyerEmail: input.buyerEmail.trim().toLowerCase(),
          planLabel: input.planLabel ?? edlPlanLabelForAmount(input.amountEur ?? 299),
          amountEur: input.amountEur ?? 299,
          currency: 'EUR',
          vatRate: 0,
          status: 'PAID',
          paidAt: input.paidAt ?? new Date(),
        },
        select: { id: true, invoiceNumber: true },
      });
      return created;
    } catch (error) {
      const code = (error as { code?: string })?.code;
      if (code === 'P2002') {
        // Numéro déjà pris (course) → incrément et nouvel essai.
        attempt += 1;
        continue;
      }
      console.error('[edl-fulfillment] issueEdlInvoice error:', error);
      return null;
    }
  }
  console.error('[edl-fulfillment] issueEdlInvoice: numéros épuisés');
  return null;
}

/**
 * Émet la facture de capture si l'achat n'en a pas encore une
 * (idempotent — la capture peut être relue après un refresh).
 */
async function issueInvoiceForPurchaseOnce(purchase: {
  id: string;
  userId: string | null;
  payerEmail: string | null;
  amountEur: number;
  paidAt: Date | null;
}): Promise<void> {
  try {
    const existing = await db.edlInvoice.findFirst({
      where: { purchaseId: purchase.id },
      select: { id: true },
    });
    if (existing) return;

    const buyerEmail = purchase.payerEmail?.trim();
    if (!buyerEmail) return;

    let buyerName = buyerEmail.split('@')[0] ?? 'Client';
    if (purchase.userId) {
      const u = await db.user.findUnique({
        where: { id: purchase.userId },
        select: { fullName: true },
      });
      if (u?.fullName?.trim()) buyerName = u.fullName.trim();
    }
    await issueEdlInvoice({
      purchaseId: purchase.id,
      userId: purchase.userId,
      buyerName,
      buyerEmail,
      amountEur: purchase.amountEur,
      paidAt: purchase.paidAt,
    });
  } catch (error) {
    // La facturation ne doit jamais casser la capture.
    console.error('[edl-fulfillment] invoice issue failed:', error);
  }
}

/**
 * LAZY-ISSUE (v5.3) — garantit que tout utilisateur éligible voit SA
 * facture payée : si aucune EdlInvoice ne lui est rattachée mais
 * qu'il possède un abonnement EDL actif OU un achat paid/activated,
 * la facture est créée à la volée (même format RS-ANNÉE-0001).
 * C'est ce qui rend la facture visible immédiatement sur les comptes
 * créés avant la mise en place de la facturation.
 */
export async function ensureUserEdlInvoices(userId: string): Promise<void> {
  try {
    const existingCount = await db.edlInvoice.count({ where: { userId } });
    if (existingCount > 0) return;

    const [user, subscription, purchase] = await Promise.all([
      db.user.findUnique({ where: { id: userId }, select: { email: true, fullName: true } }),
      db.inspectionSubscription.findFirst({
        where: { userId, status: 'active' },
        orderBy: { endDate: 'desc' },
      }),
      db.edlPurchase.findFirst({
        where: { userId, status: { in: ['paid', 'activated'] } },
        orderBy: { paidAt: 'desc' },
      }),
    ]);
    if (!user) return;
    if (!subscription && !purchase) return;

    const buyerName = user.fullName?.trim() || user.email.split('@')[0] || 'Client';

    // Un achat tracé prime : la facture est rattachée à la commande PayPal.
    if (purchase) {
      const linked = await db.edlInvoice.findFirst({
        where: { purchaseId: purchase.id },
        select: { id: true, userId: true },
      });
      if (linked) {
        // Facture émise à la capture (userId inconnu à l'époque) → rattachement.
        if (linked.userId !== userId) {
          await db.edlInvoice
            .update({ where: { id: linked.id }, data: { userId } })
            .catch(() => undefined);
        }
        return;
      }
      await issueEdlInvoice({
        purchaseId: purchase.id,
        userId,
        buyerName,
        buyerEmail: purchase.payerEmail?.trim() || user.email,
        amountEur: purchase.amountEur,
        paidAt: purchase.paidAt,
      });
      return;
    }

    // Abonnement actif sans commande tracée (compte de démonstration,
    // import) — facture adossée à l'abonnement seul.
    if (subscription) {
      await issueEdlInvoice({
        purchaseId: null,
        userId,
        buyerName,
        buyerEmail: user.email,
        paidAt: subscription.createdAt,
      });
    }
  } catch (error) {
    console.error('[edl-fulfillment] ensureUserEdlInvoices error:', error);
  }
}

// -------------------------------------------------------------
// CAPTURE (au retour PayPal — idempotent)
// -------------------------------------------------------------

export interface CaptureResult {
  ok: boolean;
  /** URL d'activation à ouvrir si la capture réussit. */
  activationUrl?: string;
  error?: 'introuvable' | 'capture_failed' | 'erreur';
  detail?: string;
}

/**
 * Capture la commande PayPal liée à orderRef et passe l'achat en
 * 'paid' (une seule fois — toute relecture renvoie le même résultat).
 */
export async function captureEdlPurchase(orderRef: string): Promise<CaptureResult> {
  try {
    const purchase = await db.edlPurchase.findUnique({ where: { orderRef } });
    if (!purchase) return { ok: false, error: 'introuvable' };

    // Déjà capturé (retour rafraîchi, double onglet…) → même lien.
    if (purchase.status === 'paid' || purchase.status === 'activated') {
      return { ok: true, activationUrl: `/edl/activer/${purchase.activationToken}` };
    }
    if (!purchase.paypalOrderId) {
      return { ok: false, error: 'capture_failed', detail: 'commande_sans_id' };
    }

    const capture = await captureEdlPayPalOrder(purchase.paypalOrderId);
    if (!capture.ok || !capture.data) {
      console.error('[edl-fulfillment] capture failed:', capture.error);
      return { ok: false, error: 'capture_failed', detail: capture.error };
    }

    const payerEmail = capture.data.payer?.email_address ?? purchase.payerEmail;
    const updated = await db.edlPurchase.update({
      where: { id: purchase.id },
      data: {
        status: 'paid',
        payerEmail,
        paidAt: new Date(),
      },
      select: { activationToken: true, status: true },
    });

    // Facture d'abonnement émise automatiquement (v5.3) — non bloquante.
    await issueInvoiceForPurchaseOnce({
      id: purchase.id,
      userId: purchase.userId,
      payerEmail,
      amountEur: purchase.amountEur,
      paidAt: new Date(),
    });

    return { ok: true, activationUrl: `/edl/activer/${updated.activationToken}` };
  } catch (error) {
    console.error('[edl-fulfillment] capture error:', error);
    return { ok: false, error: 'erreur' };
  }
}

// -------------------------------------------------------------
// ACTIVATION (création du compte EDL-only)
// -------------------------------------------------------------

export interface ActivateInput {
  token: string;
  email: string;
  password: string;
  fullName: string;
}

export interface ActivateResult {
  ok: boolean;
  status: 200 | 400 | 401 | 404 | 409 | 410 | 429 | 500;
  error?: string;
  /** Email existant + mot de passe correct → compte rattaché. */
  attachedToExisting?: boolean;
}

function normalizeEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

function validEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** Politique mot de passe identique à /api/auth/register. */
function validPassword(password: string): boolean {
  return typeof password === 'string' && password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password);
}

/**
 * Consomme le jeton d'activation d'un achat PAYÉ : crée le compte
 * (role 'user', limité au dashboard EDL) + l'abonnement EDL d'un an,
 * ou rattache l'abonnement à un compte existant (email + mot de passe
 * corrects). Idempotent côté achat : un achat 'activated' est refusé
 * (409) pour ne jamais créer de second compte.
 */
export async function activateEdlPurchase(input: ActivateInput): Promise<ActivateResult> {
  const email = normalizeEmail(input.email ?? '');
  const fullName = (input.fullName ?? '').trim();

  if (!input.token) return { ok: false, status: 400, error: 'Jeton manquant.' };
  if (!email || !validEmail(email)) {
    return { ok: false, status: 400, error: 'Indiquez une adresse email valide.' };
  }
  if (!validPassword(input.password)) {
    return {
      ok: false,
      status: 400,
      error: 'Mot de passe : 8 caractères minimum, avec lettres et chiffres.',
    };
  }
  if (!fullName || fullName.length < 2 || fullName.length > 80) {
    return { ok: false, status: 400, error: 'Indiquez votre nom complet.' };
  }

  const purchase = await db.edlPurchase.findUnique({ where: { activationToken: input.token } });
  if (!purchase) return { ok: false, status: 404, error: "Lien d'activation invalide." };
  if (purchase.status === 'activated') {
    return { ok: false, status: 409, error: 'Cet achat a déjà été activé. Connectez-vous.' };
  }
  if (purchase.status !== 'paid') {
    return { ok: false, status: 400, error: "Le paiement n'a pas été confirmé pour ce lien." };
  }
  if (purchase.activationExpiresAt.getTime() < Date.now()) {
    return {
      ok: false,
      status: 410,
      error: "Ce lien d'activation a expiré (72 h). Contactez le support pour un nouveau lien.",
    };
  }

  // Rattachement à un compte existant ? (email connu + mot de passe correct)
  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    if (!existing.passwordHash) {
      return {
        ok: false,
        status: 409,
        error: 'Un compte existe déjà avec cet email. Connectez-vous ou utilisez un autre email.',
      };
    }
    const match = await compare(input.password, existing.passwordHash).catch(() => false);
    if (!match) {
      return {
        ok: false,
        status: 401,
        error: 'Un compte existe déjà avec cet email — mot de passe incorrect.',
      };
    }

    // Compte existant vérifié : rattacher l'achat + (re)mettre
    // l'abonnement EDL actif un an (sans toucher aux autres champs).
    const endDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
    await db.$transaction([
      db.inspectionSubscription.upsert({
        where: { userId: existing.id },
        update: { status: 'active', plan: EDL_PLAN, endDate },
        create: { userId: existing.id, status: 'active', plan: EDL_PLAN, endDate },
      }),
      db.edlPurchase.update({
        where: { id: purchase.id },
        data: { status: 'activated', userId: existing.id, activatedAt: new Date() },
      }),
      // La facture émise à la capture (sans userId) est rattachée au compte.
      db.edlInvoice.updateMany({
        where: { purchaseId: purchase.id, userId: null },
        data: { userId: existing.id },
      }),
    ]);
    void queueWelcomeEmail(existing.email, fullName, false).catch(() => undefined);
    return { ok: true, status: 200, attachedToExisting: true };
  }

  // ── Création du compte EDL-only ──
  const passwordHash = await hash(input.password, 12);
  const endDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
  try {
    const user = await db.$transaction(async (tx) => {
      const created = await tx.user.create({
        data: {
          email,
          fullName,
          passwordHash,
          role: 'user',
          isActive: true,
          selectedPlan: 'edl_standalone',
        },
        select: { id: true, email: true },
      });
      await tx.inspectionSubscription.create({
        data: { userId: created.id, status: 'active', plan: EDL_PLAN, endDate },
      });
      await tx.edlPurchase.update({
        where: { id: purchase.id },
        data: { status: 'activated', userId: created.id, activatedAt: new Date() },
      });
      // Facture émise à la capture → rattachée au compte créé.
      await tx.edlInvoice.updateMany({
        where: { purchaseId: purchase.id, userId: null },
        data: { userId: created.id },
      });
      return created;
    });

    void queueWelcomeEmail(user.email, fullName, true).catch(() => undefined);
    return { ok: true, status: 200 };
  } catch (error) {
    // Course unique : le même email créé entre-temps.
    console.error('[edl-fulfillment] activation error:', error);
    return {
      ok: false,
      status: 409,
      error: 'Un compte existe déjà avec cet email. Connectez-vous.',
    };
  }
}

// -------------------------------------------------------------
// Email de bienvenue (file outbox → Resend) — fire-and-forget
// -------------------------------------------------------------

function queueWelcomeEmail(to: string, fullName: string, isNew: boolean): Promise<unknown> {
  const baseUrl =
    process.env.NEXT_PUBLIC_APP_URL?.replace(/\/+$/, '') ||
    process.env.NEXTAUTH_URL?.replace(/\/+$/, '') ||
    '';
  const dashboardUrl = `${baseUrl}/inspection/dashboard`;
  const prenom = fullName.split(' ')[0] || 'Bonjour';
  const html = `
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#0f172a">
      <h2 style="margin:0 0 4px">Bienvenue chez RoomScan, ${prenom} 👋</h2>
      <p style="color:#334155">Votre offre <strong>États des Lieux — 299 €/an</strong> est activée :
      créations illimitées, signature électronique et <strong>génération de PDF illimitée</strong>.</p>
      <table style="border-collapse:collapse;margin:16px 0">
        <tr><td style="padding:4px 12px 4px 0;color:#64748b">Votre espace</td><td><a href="${dashboardUrl}" style="color:#0052C4">Tableau de bord États des Lieux</a></td></tr>
        <tr><td style="padding:4px 12px 4px 0;color:#64748b">Validité</td><td>12 mois (jusqu'au ${new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toLocaleDateString('fr-FR')})</td></tr>
      </table>
      <p style="color:#334155">${isNew
        ? 'Connectez-vous avec l\'adresse et le mot de passe que vous venez de choisir.'
        : 'Votre espace existant a été prolongé d\'un an.'}</p>
      <p style="color:#94a3b8;font-size:12px">À très vite,<br/>L'équipe RoomScan</p>
    </div>`;
  return queueEmail({
    to,
    subject: '✅ Votre accès « États des Lieux » est activé — RoomScan',
    html,
    text: `Votre offre États des Lieux (299 €/an) est activée. Espace : ${dashboardUrl}`,
    template: 'custom',
    referenceType: 'edl_purchase',
  });
}

// -------------------------------------------------------------
// Rate limit partagé (route API)
// -------------------------------------------------------------

export async function edlActivateRateLimit(ip: string): Promise<boolean> {
  return rateLimit(`edl-activate:${ip}`, 6);
}
