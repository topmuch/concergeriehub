// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — RAPPORT DELTA (Executive Summary)
//
// Compare l'état d'ENTRÉE et de SORTIE, zone par zone, et produit
// le résumé exécutif affiché en tête du rapport de sortie (PDF) :
//   { totalRooms, conformes, anomalies, globalStatus, rooms, summary }
//
// Règle métier (identique au modèle client) :
//   · même statut entrée/sortie            → CONFORME ;
//   · statut différent                     → ANOMALIE ;
//   · anomalie IA sévère (HIGH) à la sortie → ANOMALIE (forcée,
//     même si l'agent a coché le même statut).
// 100 % pur (aucun accès DB) → utilisable côté serveur ET tests.
// =============================================================

export interface RoomStatus {
  entree: string;
  sortie: string;
  action: 'CONFORME' | 'ANOMALIE';
  comment?: string;
  /** Détail IA (si présent) : description + sévérité de l'anomalie. */
  aiSeverity?: 'LOW' | 'MEDIUM' | 'HIGH';
  aiDescription?: string;
}

export interface DeltaReport {
  totalRooms: number;
  conformes: number;
  anomalies: number;
  globalStatus: 'CONFORME' | 'ANOMALIE_DETECTED';
  rooms: Record<string, RoomStatus>;
  summary: string;
}

/** Photo de zone normalisée (contrat minimal, indépendant du schéma). */
export interface DeltaShotInput {
  zoneName: string;
  status: string;
  comment?: string | null;
  aiAnalysis?: unknown;
}

const isPositive = (status: string) => status === 'IMPECCABLE' || status === 'CORRECT';

/** Extrait la sévérité IA d'un champ Json (inconnu) de façon sûre. */
function aiSeverityOf(aiAnalysis: unknown): 'LOW' | 'MEDIUM' | 'HIGH' | undefined {
  if (!aiAnalysis || typeof aiAnalysis !== 'object') return undefined;
  const severity = (aiAnalysis as Record<string, unknown>).severity;
  return severity === 'LOW' || severity === 'MEDIUM' || severity === 'HIGH' ? severity : undefined;
}

function aiDescriptionOf(aiAnalysis: unknown): string | undefined {
  if (!aiAnalysis || typeof aiAnalysis !== 'object') return undefined;
  const d = (aiAnalysis as Record<string, unknown>).description;
  return typeof d === 'string' && d.trim() ? d.trim().slice(0, 300) : undefined;
}

/**
 * Rapport Delta à partir de deux « dictionnaires de zones »
 * { [room]: { status, comment? } } — contrat du modèle client.
 */
export function generateDeltaReport(
  checkInPhotos: Record<string, { status?: string; comment?: string } | undefined> | null | undefined,
  checkOutPhotos: Record<
    string,
    { status?: string; comment?: string; severity?: 'LOW' | 'MEDIUM' | 'HIGH'; aiDescription?: string } | undefined
  > | null | undefined,
): DeltaReport {
  const rooms: Record<string, RoomStatus> = {};
  let conformes = 0;
  let anomalies = 0;

  const inRec = checkInPhotos ?? {};
  const outRec = checkOutPhotos ?? {};
  const zoneNames = Array.from(new Set([...Object.keys(inRec), ...Object.keys(outRec)]));

  zoneNames.forEach((room) => {
    const entree = inRec[room]?.status || 'IMPECCABLE';
    const sortieRaw = outRec[room];
    const sortie = sortieRaw?.status || 'IMPECCABLE';
    const comment = sortieRaw?.comment || '';
    // Anomalie forcée si l'IA a détecté une dégât sévère à la sortie.
    const aiHigh = sortieRaw?.severity === 'HIGH';
    const action: 'CONFORME' | 'ANOMALIE' =
      (entree === sortie && !aiHigh) || (isPositive(entree) && isPositive(sortie) && !aiHigh)
        ? 'CONFORME'
        : 'ANOMALIE';

    if (action === 'CONFORME') conformes++;
    else anomalies++;

    rooms[room] = {
      entree,
      sortie,
      action,
      comment: comment || undefined,
      aiSeverity: sortieRaw?.severity,
      aiDescription: sortieRaw?.aiDescription,
    };
  });

  const totalRooms = zoneNames.length;
  const globalStatus: DeltaReport['globalStatus'] = anomalies > 0 ? 'ANOMALIE_DETECTED' : 'CONFORME';
  const summary =
    anomalies === 0
      ? `Toutes les ${totalRooms} zones sont conformes. Aucun dégât détecté.`
      : `${anomalies} anomalie${anomalies > 1 ? 's' : ''} détectée${anomalies > 1 ? 's' : ''} sur ${totalRooms} zones. ${conformes} zone${conformes > 1 ? 's' : ''} conforme${conformes > 1 ? 's' : ''}.`;

  return { totalRooms, conformes, anomalies, globalStatus, rooms, summary };
}

/**
 * Variante pratique PDF : deux listes de shots (entrée, sortie)
 * appariées par nom de zone → rapport Delta. Les zones absentes
 * d'un côté valent « IMPECCABLE » (règle de robustesse PDF).
 */
export function deltaReportFromShots(
  checkInShots: DeltaShotInput[] | null | undefined,
  checkOutShots: DeltaShotInput[] | null | undefined,
): DeltaReport {
  const toRecord = (shots: DeltaShotInput[] | null | undefined) => {
    const rec: Record<
      string,
      { status: string; comment?: string; severity?: 'LOW' | 'MEDIUM' | 'HIGH'; aiDescription?: string }
    > = {};
    for (const s of shots ?? []) {
      const name = String(s?.zoneName || '').trim();
      if (!name) continue;
      rec[name] = {
        status: String(s?.status || 'IMPECCABLE'),
        comment: s?.comment || undefined,
        severity: aiSeverityOf(s?.aiAnalysis),
        aiDescription: aiDescriptionOf(s?.aiAnalysis),
      };
    }
    return rec;
  };
  return generateDeltaReport(toRecord(checkInShots), toRecord(checkOutShots));
}
