// =============================================================
// DIGITAL CONCIERGE (V4.1) — Helpers des modules enrichis du Hub
// Invité. Source de vérité des formes JSON de Property :
//   accessCodes   → coffre-fort numérique (onglet/objet)
//   appliances    → guide des appareils (onglet Guide)
//   localSpots    → carte secrète de l'hôte (onglet Quartier)
//   emergencyInfo → SOS + pannes courantes (onglet Urgence)
// Parseurs tolérants (jamais de throw) — miroir du pattern
// parseBranding (src/lib/branding.ts). Importable partout.
// =============================================================

// ── 1. Coffre-fort numérique (accessCodes) ──────────────────
export interface GuestAccessCodes {
  /** Bâtiment / porte d'entrée. */
  building?: string;
  /** Boîte aux lettres. */
  letterbox?: string;
  /** Parking (place, code, niveau…). */
  parking?: string;
  /** Centrale d'alarme. */
  alarm?: string;
  /** Coffre-fort dans le logement. */
  safe?: string;
  /** Note libre de l'hôte (contexte, rotation de code…). */
  note?: string;
}

const CODE_LABELS: { key: keyof Omit<GuestAccessCodes, 'note'>; emoji: string; label: string }[] = [
  { key: 'building', emoji: '🏢', label: 'Bâtiment / Entrée' },
  { key: 'letterbox', emoji: '📮', label: 'Boîte aux lettres' },
  { key: 'parking', emoji: '🚗', label: 'Parking' },
  { key: 'alarm', emoji: '🚨', label: 'Alarme' },
  { key: 'safe', emoji: '🔐', label: 'Coffre-fort' },
];

export function accessCodeRows(codes: GuestAccessCodes): { emoji: string; label: string; value: string }[] {
  return CODE_LABELS.filter((c) => typeof codes[c.key] === 'string' && codes[c.key]!.trim())
    .map((c) => ({ emoji: c.emoji, label: c.label, value: codes[c.key]!.trim() }));
}

function cleanCode(v: unknown): string | undefined {
  return cleanText(v, 40);
}

/** Texte libre tronqué (jamais de throw). */
function cleanText(v: unknown, max: number): string | undefined {
  if (typeof v !== 'string') return undefined;
  const s = v.trim().slice(0, max);
  return s ? s : undefined;
}

export function parseAccessCodes(raw: unknown): GuestAccessCodes | null {
  const obj = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const parsed: GuestAccessCodes = {
    building: cleanCode(obj.building),
    letterbox: cleanCode(obj.letterbox),
    parking: cleanCode(obj.parking),
    alarm: cleanCode(obj.alarm),
    safe: cleanCode(obj.safe),
    // Note libre → 280 caractères (comme les messages de branding)
    note: cleanText(obj.note, 280),
  };
  const hasAny = Object.values(parsed).some((v) => typeof v === 'string');
  return hasAny ? parsed : null;
}

// ── 2. Guide des appareils (appliances) ─────────────────────
export interface GuestAppliance {
  id: string;
  name: string;
  emoji?: string;
  instructions: string;
  /** Lien YouTube (ouvre l'app/site) OU vidéo mp4 hébergée sur l'app (/uploads/...). */
  videoUrl?: string;
  /** Photo / GIF hébergé sur l'app (/uploads/...) ou data-URL. */
  imageUrl?: string;
}

export function parseAppliances(raw: unknown): GuestAppliance[] {
  if (!Array.isArray(raw)) return [];
  const out: GuestAppliance[] = [];
  for (const item of raw.slice(0, 40)) {
    if (!item || typeof item !== 'object') continue;
    const o = item as Record<string, unknown>;
    const name = typeof o.name === 'string' ? o.name.trim().slice(0, 80) : '';
    const instructions = typeof o.instructions === 'string' ? o.instructions.trim().slice(0, 4000) : '';
    if (!name || !instructions) continue;
    out.push({
      id: typeof o.id === 'string' && o.id.trim() ? o.id.trim().slice(0, 60) : `app-${out.length + 1}`,
      name,
      emoji: typeof o.emoji === 'string' && o.emoji.trim() ? o.emoji.trim().slice(0, 4) : '🛠️',
      instructions,
      videoUrl: typeof o.videoUrl === 'string' && /^https?:\/\/|^\//.test(o.videoUrl.trim()) ? o.videoUrl.trim().slice(0, 500) : undefined,
      imageUrl: typeof o.imageUrl === 'string' && /^(https?:\/\/|\/|data:image\/)/.test(o.imageUrl.trim()) ? o.imageUrl.trim().slice(0, 500) : undefined,
    });
  }
  return out;
}

// ── 3. Carte secrète de l'hôte (localSpots) ─────────────────
export type GuestSpotCategory = 'food' | 'bars' | 'groceries' | 'sport';

export interface GuestSpot {
  id: string;
  name: string;
  category: GuestSpotCategory;
  lat: number;
  lng: number;
  address?: string;
  /** Note perso de l'hôte ("Mon coup de cœur !"). */
  hostNote?: string;
}

export const SPOT_CATEGORY_META: Record<GuestSpotCategory, { emoji: string; label: string }> = {
  food: { emoji: '🍔', label: 'Food' },
  bars: { emoji: '🍹', label: 'Bars' },
  groceries: { emoji: '🛒', label: 'Courses' },
  sport: { emoji: '🏃', label: 'Sport' },
};

export function spotCategoryMeta(category: string): { emoji: string; label: string } {
  return SPOT_CATEGORY_META[category as GuestSpotCategory] ?? { emoji: '📍', label: 'Adresses' };
}

function cleanCoord(v: unknown): number | null {
  return typeof v === 'number' && Number.isFinite(v) ? v : null;
}

export function parseLocalSpots(raw: unknown): GuestSpot[] {
  if (!Array.isArray(raw)) return [];
  const out: GuestSpot[] = [];
  for (const item of raw.slice(0, 60)) {
    if (!item || typeof item !== 'object') continue;
    const o = item as Record<string, unknown>;
    const name = typeof o.name === 'string' ? o.name.trim().slice(0, 80) : '';
    const lat = cleanCoord(o.lat);
    const lng = cleanCoord(o.lng);
    if (!name || lat === null || lng === null) continue;
    if (Math.abs(lat) > 90 || Math.abs(lng) > 180) continue;
    const category =
      typeof o.category === 'string' && o.category in SPOT_CATEGORY_META
        ? (o.category as GuestSpotCategory)
        : 'food';
    out.push({
      id: typeof o.id === 'string' && o.id.trim() ? o.id.trim().slice(0, 60) : `spot-${out.length + 1}`,
      name,
      category,
      lat,
      lng,
      address: typeof o.address === 'string' && o.address.trim() ? o.address.trim().slice(0, 160) : undefined,
      hostNote: typeof o.hostNote === 'string' && o.hostNote.trim() ? o.hostNote.trim().slice(0, 280) : undefined,
    });
  }
  return out;
}

// ── 4. SOS (emergencyInfo) ──────────────────────────────────
export interface GuestCommonIssue {
  id: string;
  title: string;
  instructions: string;
  imageUrl?: string;
}

export interface GuestEmergencyInfo {
  /** Hôpital le plus proche (nom). */
  hospital?: string;
  hospitalLat?: number;
  hospitalLng?: number;
  /** Pharmacie de garde (nom). */
  pharmacy?: string;
  pharmacyPhone?: string;
  /** Police/secours local — défaut "17". */
  police?: string;
  /** Téléphone urgence logement (prioritaire sur le contact standard). */
  hostPhone?: string;
  /** Pannes courantes avec instructions. */
  commonIssues: GuestCommonIssue[];
}

export function parseEmergencyInfo(raw: unknown): GuestEmergencyInfo | null {
  const obj = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const commonIssues: GuestCommonIssue[] = [];
  if (Array.isArray(obj.commonIssues)) {
    for (const item of (obj.commonIssues as unknown[]).slice(0, 12)) {
      if (!item || typeof item !== 'object') continue;
      const o = item as Record<string, unknown>;
      const title = typeof o.title === 'string' ? o.title.trim().slice(0, 80) : '';
      const instructions = typeof o.instructions === 'string' ? o.instructions.trim().slice(0, 4000) : '';
      if (!title || !instructions) continue;
      commonIssues.push({
        id: typeof o.id === 'string' && o.id.trim() ? o.id.trim().slice(0, 60) : `issue-${commonIssues.length + 1}`,
        title,
        instructions,
        imageUrl: typeof o.imageUrl === 'string' && /^(https?:\/\/|\/|data:image\/)/.test(o.imageUrl.trim()) ? o.imageUrl.trim().slice(0, 500) : undefined,
      });
    }
  }

  const parsed: GuestEmergencyInfo = {
    hospital: cleanText(obj.hospital, 120),
    hospitalLat: cleanCoord(obj.hospitalLat) ?? undefined,
    hospitalLng: cleanCoord(obj.hospitalLng) ?? undefined,
    pharmacy: cleanText(obj.pharmacy, 120),
    pharmacyPhone: cleanCode(obj.pharmacyPhone),
    police: cleanCode(obj.police),
    hostPhone: cleanCode(obj.hostPhone),
    commonIssues,
  };

  const hasAny =
    Boolean(parsed.hospital || parsed.pharmacy || parsed.police || parsed.hostPhone) ||
    parsed.commonIssues.length > 0;
  return hasAny ? parsed : null;
}

// ── 5. Lien « 📍 Y aller » universel ────────────────────────
/** Apple Maps sur iOS (et Mac), Google Maps ailleurs — ouvre l'app native. */
export function geoDirectionsUrl(lat: number, lng: number): string {
  if (typeof navigator !== 'undefined' && /iPad|iPhone|iPod|Macintosh/.test(navigator.userAgent)) {
    return `https://maps.apple.com/?q=${lat},${lng}&dirflg=w`;
  }
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
}

/** YouTube ? → bouton lien (la CSP bloque les iframes externes, choix sécurité assumé). */
export function isYouTubeUrl(url: string): boolean {
  return /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)/.test(url);
}

/** Média affichable en local (CSP 'self'/data:) — sinon on proposera un lien. */
export function isLocalMediaUrl(url: string): boolean {
  return url.startsWith('/') || url.startsWith('data:');
}

// =============================================================
// PREMIUM « CONCIERGERIE 5 ÉTOILES » (V5) — modules premium du
// Hub Invité : vidéo de bienvenue, guide visuel pas à pas, upselling
// late check-out, bouclier d'avis, kit de survie.
// =============================================================

// ── 6. Features premium (premiumFeatures) ───────────────────
export interface GuestPremiumFeatures {
  /** Vidéo de bienvenue : lien YouTube/Vimeo/Loom OU vidéo locale (/uploads/…). */
  videoWelcomeUrl?: string;
  /** Late Check-out payant activé. */
  enableLateCheckout?: boolean;
  /** Prix du late check-out en € (0 < prix ≤ 1000). */
  lateCheckoutPrice?: number;
  /** Bouclier d'avis (Review Shield) activé. */
  enableReviewShield?: boolean;
  /** Lien de l'annonce (avis Airbnb/Booking) proposé aux invités ravis. */
  reviewUrl?: string;
}

/** URL http(s) ou chemin local (/uploads/…) — sinon undefined. */
function cleanUrl(v: unknown, max = 500): string | undefined {
  const s = cleanText(v, max);
  return s && (/^https?:\/\//.test(s) || s.startsWith('/')) ? s : undefined;
}

export function parsePremiumFeatures(raw: unknown): GuestPremiumFeatures | null {
  const obj = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const enableLateCheckout = obj.enableLateCheckout === true;
  const enableReviewShield = obj.enableReviewShield === true;
  const rawPrice = obj.lateCheckoutPrice;
  const lateCheckoutPrice =
    typeof rawPrice === 'number' && Number.isFinite(rawPrice) && rawPrice > 0 && rawPrice <= 1000
      ? Math.round(rawPrice * 100) / 100
      : undefined;
  const parsed: GuestPremiumFeatures = {
    videoWelcomeUrl: cleanUrl(obj.videoWelcomeUrl),
    ...(enableLateCheckout ? { enableLateCheckout: true, ...(lateCheckoutPrice !== undefined ? { lateCheckoutPrice } : {}) } : {}),
    ...(enableReviewShield ? { enableReviewShield: true } : {}),
    reviewUrl: /^https?:\/\//.test(cleanText(obj.reviewUrl, 500) ?? '') ? cleanText(obj.reviewUrl, 500) : undefined,
  };
  const hasAny = Boolean(parsed.videoWelcomeUrl || parsed.enableLateCheckout || parsed.enableReviewShield);
  return hasAny ? parsed : null;
}

// ── 7. Guide visuel d'arrivée (visualGuide) ─────────────────
export interface GuestVisualStep {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
}

export function parseVisualGuide(raw: unknown): GuestVisualStep[] {
  if (!Array.isArray(raw)) return [];
  const out: GuestVisualStep[] = [];
  for (const item of raw.slice(0, 12)) {
    if (!item || typeof item !== 'object') continue;
    const o = item as Record<string, unknown>;
    const title = cleanText(o.title, 80);
    if (!title) continue;
    out.push({
      id: typeof o.id === 'string' && o.id.trim() ? o.id.trim().slice(0, 60) : `vg-${out.length + 1}`,
      title,
      description: cleanText(o.description, 280),
      imageUrl: cleanUrl(o.imageUrl),
    });
  }
  return out;
}

// ── 8. Kit de survie (survivalKitItems) ─────────────────────
export interface GuestSurvivalItem {
  id: string;
  name: string;
  /** Où l'objet est rangé ("Tiroir de la cuisine"). */
  location?: string;
}

export function parseSurvivalKit(raw: unknown): GuestSurvivalItem[] {
  if (!Array.isArray(raw)) return [];
  const out: GuestSurvivalItem[] = [];
  for (const item of raw.slice(0, 30)) {
    if (!item || typeof item !== 'object') continue;
    const o = item as Record<string, unknown>;
    const name = cleanText(o.name, 60);
    if (!name) continue;
    out.push({
      id: typeof o.id === 'string' && o.id.trim() ? o.id.trim().slice(0, 60) : `kit-${out.length + 1}`,
      name,
      location: cleanText(o.location, 120),
    });
  }
  return out;
}
