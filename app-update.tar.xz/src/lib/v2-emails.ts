// =============================================================
// V2 « BOUCLIER » — ÉTAPE 7 : EMAILS AUTOMATIQUES (server only)
//
// Deux emails transactionnels du circuit Bouclier, envoyés via
// l'outbox V1 (lib/email.ts — queueEmail FIRE-AND-FORGET : un
// échec email ne casse JAMAIS le flux métier, mode démo en dev) :
//
//  1. sendCleanerLinkEmail  — dès la création d'un séjour (flux B),
//     le ménager reçoit son lien mobile /s/[token] (photos
//     fantômes 50 % + vidéo walk-through scellée SHA-256).
//  2. sendHostSealedEmail   — au scellement d'un état des lieux
//     (flux C, /api/s/[token]/complete), l'hôte reçoit la
//     confirmation horodatée avec l'empreinte SHA-256 de la
//     vidéo et le lien vers ses Documents (rapport PDF).
//
// HTML emails-safe : tableaux + styles inline (pas de CSS externe),
// bandeau bleu #1E3A8A, CTA rouge #C41E3A — charte V2.
// =============================================================
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { queueEmail } from '@/lib/email';

// -------------------------------------------------------------
// Origine absolue de l'app (liens cliquables dans les emails)
// -------------------------------------------------------------

/**
 * Origine publique dérivée de la requête entrante : derrière le
 * proxy Coolify/Caddy, req.url pointe vers l'origine interne — on
 * privilégie donc x-forwarded-proto / x-forwarded-host, puis Host,
 * puis req.url, puis le domaine de production en dernier recours.
 */
export function appOriginFromRequest(req: Request): string {
  const fwdProto = req.headers.get('x-forwarded-proto')?.split(',')[0]?.trim();
  const fwdHost =
    req.headers.get('x-forwarded-host')?.split(',')[0]?.trim() ||
    req.headers.get('host')?.trim();
  if (fwdHost) {
    const proto = fwdProto || (fwdHost.startsWith('localhost') || fwdHost.startsWith('127.0.0.1') ? 'http' : 'https');
    return `${proto}://${fwdHost}`;
  }
  try {
    return new URL(req.url).origin;
  } catch {
    return 'https://roomscan.pro';
  }
}

// -------------------------------------------------------------
// Squelette HTML commun (charte V2 : bleu marine + rouge)
// -------------------------------------------------------------

function emailShell(opts: {
  preheader: string;
  headerTitle: string;
  headerBadge: string;
  bodyHtml: string;
  ctaHref: string;
  ctaLabel: string;
  ctaNote?: string;
}): string {
  return `<!doctype html>
<html lang="fr"><body style="margin:0;padding:0;background-color:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">
<span style="display:none;max-height:0;overflow:hidden;">${opts.preheader}</span>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9;padding:24px 12px;">
<tr><td align="center">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background-color:#ffffff;border-radius:14px;overflow:hidden;box-shadow:0 1px 4px rgba(15,23,42,.12);">
    <tr><td style="background-color:#1e3a8a;padding:20px 28px;">
      <p style="margin:0;color:#ffffff;font-size:13px;letter-spacing:2px;font-weight:bold;">ROOMSCAN BOUCLIER</p>
      <p style="margin:6px 0 0;color:#c7d2fe;font-size:12px;">${opts.headerBadge}</p>
    </td></tr>
    <tr><td style="height:4px;background-color:#c41e3a;font-size:0;line-height:0;">&nbsp;</td></tr>
    <tr><td style="padding:26px 28px 8px;">
      <h1 style="margin:0;font-size:19px;line-height:1.35;color:#0f172a;">${opts.headerTitle}</h1>
    </td></tr>
    <tr><td style="padding:0 28px 24px;">${opts.bodyHtml}</td></tr>
    <tr><td style="padding:0 28px 28px;" align="center">
      <table role="presentation" cellpadding="0" cellspacing="0"><tr>
        <td style="background-color:#c41e3a;border-radius:10px;">
          <a href="${opts.ctaHref}" style="display:inline-block;padding:13px 30px;color:#ffffff;font-size:15px;font-weight:bold;text-decoration:none;border-radius:10px;">${opts.ctaLabel}</a>
        </td>
      </tr></table>
      ${opts.ctaNote ? `<p style="margin:12px 0 0;font-size:11px;color:#94a3b8;">${opts.ctaNote}</p>` : ''}
      <p style="margin:10px 0 0;font-size:12px;color:#64748b;word-break:break-all;">${opts.ctaHref}</p>
    </td></tr>
    <tr><td style="background-color:#f8fafc;border-top:1px solid #e2e8f0;padding:16px 28px;">
      <p style="margin:0;font-size:11px;color:#94a3b8;line-height:1.5;">
        RoomScan Bouclier — états des lieux photo + vidéo scellée SHA-256.<br />
        Email automatique, ne pas répondre.
      </p>
    </td></tr>
  </table>
</td></tr>
</table>
</body></html>`;
}

function infoTable(rows: Array<{ label: string; value: string }>): string {
  const trs = rows
    .map(
      (r) => `<tr>
        <td style="padding:6px 14px 6px 0;color:#64748b;font-size:13px;white-space:nowrap;vertical-align:top;">${r.label}</td>
        <td style="padding:6px 0;color:#0f172a;font-size:13px;font-weight:bold;">${r.value}</td>
      </tr>`,
    )
    .join('');
  return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:14px 0;">${trs}</table>`;
}

const TYPE_LABEL = { CHECKIN: 'Check-in — Entrée', CHECKOUT: 'Check-out — Sortie' } as const;

// -------------------------------------------------------------
// 1) Email MÉNAGER — lien mobile /s/[token]
// -------------------------------------------------------------

export interface CleanerLinkEmailParams {
  to: string;
  /** Origine absolue (appOriginFromRequest) pour construire le lien. */
  origin: string;
  publicToken: string;
  propertyName: string;
  type: 'CHECKIN' | 'CHECKOUT';
  scheduledAt: Date | null;
  cleanerName: string | null;
  userId: string;
  propertyId: string;
  sessionId: string;
}

/** Fire-and-forget (queueEmail ne lève jamais) : lien cleaner envoyé au ménager. */
export async function sendCleanerLinkEmail(p: CleanerLinkEmailParams) {
  const linkUrl = `${p.origin}/s/${p.publicToken}`;
  const when = p.scheduledAt
    ? format(p.scheduledAt, "EEEE d MMMM yyyy 'à' HH:mm", { locale: fr })
    : 'créneau à définir';
  const greeting = p.cleanerName ? `Bonjour ${p.cleanerName}` : 'Bonjour';

  const bodyHtml = `
    <p style="margin:0 0 12px;color:#334155;font-size:14px;line-height:1.6;">
      ${greeting},<br />
      l'hôte vous a confié l'état des lieux du logement
      <strong style="color:#0f172a;">« ${p.propertyName} »</strong>.
      La visite se fait sur votre téléphone, pièce par pièce :
      des <strong>photos fantômes</strong> vous guident pour reprendre exactement
      le même angle, puis une <strong>vidéo walk-through</strong> scellée de 2 minutes
      clôt le rapport. Aucun compte n'est nécessaire.
    </p>
    ${infoTable([
      { label: 'Logement', value: p.propertyName },
      { label: 'Intervention', value: TYPE_LABEL[p.type] },
      { label: 'Prévu le', value: when },
    ])}
    <p style="margin:0 0 6px;color:#334155;font-size:14px;font-weight:bold;">
      Ouvrez ce lien au moment de la visite :
    </p>`;

  return queueEmail({
    to: p.to,
    subject: `RoomScan — ${TYPE_LABEL[p.type]} « ${p.propertyName} » : votre visite guidée`,
    html: emailShell({
      preheader: `État des lieux « ${p.propertyName} » — photos fantômes guidées + vidéo scellée. Ouvrez le lien sur votre téléphone.`,
      headerBadge: TYPE_LABEL[p.type],
      headerTitle: `État des lieux « ${p.propertyName} »`,
      bodyHtml,
      ctaHref: linkUrl,
      ctaLabel: 'Ouvrir ma visite guidée',
      ctaNote: 'Sur mobile de préférence — la caméra est requise.',
    }),
    text: `RoomScan Bouclier — ${TYPE_LABEL[p.type]} « ${p.propertyName} » (prévu le ${when}). Ouvrez votre visite guidée : ${linkUrl}`,
    template: 'v2_cleaner_link',
    userId: p.userId,
    propertyId: p.propertyId,
    referenceType: 'session',
    referenceId: p.sessionId,
    meta: { kind: 'cleaner_link', sessionType: p.type, publicToken: p.publicToken },
  });
}

// -------------------------------------------------------------
// 2) Email HÔTE — état des lieux scellé (SHA-256)
// -------------------------------------------------------------

export interface HostSealedEmailParams {
  to: string;
  origin: string;
  propertyName: string;
  type: 'CHECKIN' | 'CHECKOUT';
  cleanerName: string | null;
  completedAt: Date;
  photoCount: number;
  videoHash: string;
  userId: string;
  propertyId: string;
  sessionId: string;
}

/** Fire-and-forget : confirmation de scellement envoyée à l'hôte. */
export async function sendHostSealedEmail(p: HostSealedEmailParams) {
  const docsUrl = `${p.origin}/airbnb/documents`;
  const sealedAt = format(p.completedAt, "d MMMM yyyy 'à' HH:mm", { locale: fr });

  const bodyHtml = `
    <p style="margin:0 0 12px;color:#334155;font-size:14px;line-height:1.6;">
      Bonjour,<br />
      l'état des lieux du logement <strong style="color:#0f172a;">« ${p.propertyName} »</strong>
      a été <strong>scellé</strong> : chaque pièce a été photographiée face à ses photos
      de référence et la vidéo walk-through a été empaquetée avec une empreinte
      <strong>SHA-256</strong> infalsifiable. Le rapport PDF est prêt dans vos Documents.
    </p>
    ${infoTable([
      { label: 'Logement', value: p.propertyName },
      { label: 'Intervention', value: TYPE_LABEL[p.type] },
      { label: 'Scellé le', value: sealedAt },
      { label: 'Réalisé par', value: p.cleanerName || '—' },
      { label: 'Photos', value: `${p.photoCount} pièce${p.photoCount > 1 ? 's' : ''} comparée${p.photoCount > 1 ? 's' : ''}` },
    ])}
    <p style="margin:16px 0 6px;color:#64748b;font-size:12px;font-weight:bold;">
      EMPREINTE VIDÉO SCELLÉE (SHA-256)
    </p>
    <p style="margin:0;padding:10px 12px;background-color:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;font-family:'Courier New',Courier,monospace;font-size:11px;color:#0f172a;word-break:break-all;">
      ${p.videoHash}
    </p>`;

  return queueEmail({
    to: p.to,
    subject: `✅ État des lieux scellé — ${p.propertyName} (${p.type === 'CHECKIN' ? 'Entrée' : 'Sortie'})`,
    html: emailShell({
      preheader: `${TYPE_LABEL[p.type]} « ${p.propertyName} » scellé le ${sealedAt} — empreinte SHA-256 ${p.videoHash.slice(0, 16)}…`,
      headerBadge: `SCELLÉ — ${TYPE_LABEL[p.type].toUpperCase()}`,
      headerTitle: `État des lieux scellé — « ${p.propertyName} »`,
      bodyHtml,
      ctaHref: docsUrl,
      ctaLabel: 'Voir le rapport PDF',
      ctaNote: 'Documents → bouton PDF pour télécharger le rapport complet.',
    }),
    text: `RoomScan Bouclier — ${TYPE_LABEL[p.type]} « ${p.propertyName} » scellé le ${sealedAt} par ${p.cleanerName || '—'}. Empreinte vidéo SHA-256 : ${p.videoHash}. Rapport PDF : ${docsUrl}`,
    template: 'v2_host_sealed',
    userId: p.userId,
    propertyId: p.propertyId,
    referenceType: 'session',
    referenceId: p.sessionId,
    meta: { kind: 'host_sealed', sessionType: p.type, videoHash: p.videoHash },
  });
}
