// =============================================================
// MODULE STANDALONE « ÉTAT DES LIEUX » — GARDE D'ACCÈS PARTAGÉE
// (circuit v2 — Task 4-a)
//
// Source unique de l'entitlement du module EDL pour les NOUVELLES
// routes du circuit « États des Lieux v2 » (/api/inspection/stay,
// /api/inspection/merged-pdf/[id], /api/inspection/properties).
//
// Deux sémantiques verbatim des routes historiques :
//   • ensureInspectionAccess()  → copie EXACTE de ensureSubscription
//     de /api/inspection/create (v4.107) — garde STRICTE utilisée
//     pour les écritures et les téléchargements :
//       - abonnement actif            → 'sub_active'
//       - compte Hub sans abonnement  → création à la volée
//         ('sub_created' — module inclus pour superadmin/
//         propriétaire/équipe, comportement v4.97 préservé) ;
//       - compte Hub abonnement expiré → 'expired' (403) ;
//       - tout autre compte           → 'no_access' (403 achat).
//   • resolveInspectionSubscription() → copie EXACTE de
//     ensureSubscription de /api/inspection/list — garde SOUPLE
//     (consultation) : l'abonnement est renvoyé TEL QUEL même
//     expiré (les documents existants restent consultables) ;
//     null → ni abonnement ni compte Hub (achat requis).
//
// ⚠️ Les routes historiques (create, list) conservent leur copie
// locale volontairement : aucun refactoring hors périmètre Task 4-a.
// =============================================================
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { isHubAccount } from '@/lib/edl-billing';
import type { InspectionSubscription } from '@prisma/client';

/** Garde de session — renvoie l'userId ou null (même forme que create). */
export function requireUserId(session: { user?: unknown } | null): string | null {
  const id = (session?.user as { id?: string } | undefined)?.id;
  return session?.user && id ? id : null;
}

/** Rôle de l'utilisateur de session (null si absent). */
export function sessionRole(session: { user?: unknown } | null): string | null {
  return (session?.user as { role?: string } | undefined)?.role ?? null;
}

/**
 * Résolution d'accès STRICTE (copie verbatim de create/route.ts v4.107) :
 *   'sub_active'  → abonnement EDL actif (achat ou création antérieure)
 *   'sub_created' → compte Hub : abonnement créé à la volée (inclus)
 *   'expired'     → abonnement expiré / résilié (compte Hub)
 *   'no_access'   → ni abonnement ni compte Hub → achat requis
 */
export async function ensureInspectionAccess(
  userId: string,
  role: string | null | undefined,
): Promise<'sub_active' | 'sub_created' | 'expired' | 'no_access'> {
  const now = new Date();
  const sub = await db.inspectionSubscription.findUnique({ where: { userId } });
  if (sub && sub.status === 'active' && sub.endDate >= now) return 'sub_active';

  // Hors abonnement : le module reste INCLUS pour les comptes Hub
  // (superadmin / propriétaire / équipe) — création à la volée.
  if (await isHubAccount(userId, role)) {
    if (!sub) {
      await db.inspectionSubscription.create({
        data: {
          userId,
          status: 'active',
          plan: 'edl_annual',
          endDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000),
        },
      });
      return 'sub_created';
    }
    return 'expired';
  }

  // Compte sans bien, sans équipe, sans abonnement payé → achat EDL.
  return 'no_access';
}

/**
 * Résolution SOUPLE (copie verbatim de list/route.ts) : l'abonnement
 * est renvoyé tel quel même expiré (consultation) ; création à la
 * volée UNIQUEMENT pour les comptes Hub. null → achat requis.
 */
export async function resolveInspectionSubscription(
  userId: string,
  role: string | null | undefined,
): Promise<InspectionSubscription | null> {
  const now = new Date();
  const sub = await db.inspectionSubscription.findUnique({ where: { userId } });
  if (sub) return sub;
  if (!(await isHubAccount(userId, role))) return null;
  return db.inspectionSubscription.create({
    data: {
      userId,
      status: 'active',
      plan: 'edl_annual',
      endDate: new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000),
    },
  });
}

/**
 * 403 standardisée pour la garde STRICTE — corps identique à
 * /api/inspection/create (contrat figé circuit v2) :
 *   expired   → message de renouvellement ;
 *   no_access → { error:'abonnement_requis', redirect:'/edl/abonnement' }.
 */
export function inspectionAccessError(
  state: 'expired' | 'no_access',
): { status: 403; body: Record<string, string> } {
  if (state === 'expired') {
    return {
      status: 403,
      body: { error: 'Votre abonnement au module État des Lieux a expiré.' },
    };
  }
  return {
    status: 403,
    body: {
      error: 'abonnement_requis',
      message: "L'offre États des Lieux (299 €/an, PDF illimités) est requise.",
      redirect: '/edl/abonnement',
    },
  };
}
