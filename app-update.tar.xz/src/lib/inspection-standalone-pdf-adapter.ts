// =============================================================
// v5.3 — ADAPTATEUR « HUB → NOUVEAU DESIGN PDF »
//
// Mappe les lignes Prisma du module Hub (CheckOutInspection —
// checkin/checkout, et MinibarCheck — preuve d'arrivée) vers la
// forme d'entrée de renderStandaloneInspectionPdf() (design
// certifié v4.111+ : bandeau rouge, QR, SHA-256, sections).
// L'ANCIEN générateur (inspection-pdf.ts) est supprimé : tous les
// documents EDL Hub passent désormais par le design unifié.
//
// Principes :
//  · mapping tolérant — roomsData / damagePhotos / minibarData
//    sont des Json SQLite : parse défensif, jamais de throw ;
//  · empreinte SHA-256 recalculée avec le canon officiel
//    (computeInspectionSha256) — même anti-fraude que le module
//    standalone ;
//  · white-label conservé (companyName → pied de page) et chemin
//    de vérification public du Hub (public/inspection/<token>).
// =============================================================

import { parseBranding } from '@/lib/branding';
import { computeInspectionSha256 } from '@/lib/inspection-hash';
import type { StandaloneInspectionPdfData, StandalonePdfRoom } from '@/lib/inspection-standalone-pdf';

// ---------- Selects Prisma partagés (routes PDF) ----------

/** Select complet du CheckOutInspection pour le rendu PDF (design unifié). */
export const CHECKOUT_INSPECTION_PDF_SELECT = {
  id: true,
  publicToken: true,
  guestName: true,
  guestEmail: true,
  ipAddress: true,
  signedAt: true,
  type: true,
  selfAssessment: true,
  issues: true,
  damages: true,
  roomsData: true,
  inventoryCheck: true,
  minibarData: true,
  damagePhotos: true,
  guestSignature: true,
  propertyId: true,
  bookingId: true,
  property: {
    select: {
      name: true,
      address: true,
      propertyType: true,
      branding: true,
      owner: {
        select: {
          fullName: true,
          email: true,
          profile: { select: { phone: true } },
        },
      },
    },
  },
  booking: { select: { checkIn: true, checkOut: true } },
} as const;

/** Select du MinibarCheck (preuve d'arrivée) pour le rendu PDF. */
export const MINIBAR_CHECK_PDF_SELECT = {
  id: true,
  publicToken: true,
  guestName: true,
  checkedAt: true,
  property: CHECKOUT_INSPECTION_PDF_SELECT.property,
  booking: { select: { checkIn: true, checkOut: true } },
} as const;

// ---------- Formes d'entrée (lignes Prisma allégées) ----------

interface HubPropertyLite {
  name: string;
  address: string | null;
  propertyType: string;
  branding: unknown;
  owner: { fullName: string | null; email: string; profile: { phone: string | null } | null } | null;
}

export interface CheckOutInspectionRow {
  id: string;
  publicToken: string;
  guestName: string;
  guestEmail: string | null;
  ipAddress: string | null;
  signedAt: Date;
  type: string; // 'checkin' | 'checkout'
  selfAssessment: number;
  issues: string | null;
  damages: string | null;
  roomsData: unknown;
  inventoryCheck: unknown;
  minibarData: unknown;
  damagePhotos: unknown;
  guestSignature: string | null;
  propertyId: string;
  bookingId: string | null;
  property: HubPropertyLite;
  booking: { checkIn: Date; checkOut: Date } | null;
}

export interface MinibarCheckRow {
  id: string;
  publicToken: string | null;
  guestName: string | null;
  checkedAt: Date;
  property: HubPropertyLite;
  booking: { checkIn: Date; checkOut: Date } | null;
}

// ---------- Parsing défensif des Json Hub ----------

interface HubRoom {
  id: string;
  label: string;
  status: string; // 'good' | 'dirty' | 'damaged'
  comment: string | null;
  photoCount: number;
}

const ROOM_FALLBACK_LABEL: Record<string, string> = {
  entrance: 'Entrée / Couloir',
  kitchen: 'Cuisine',
  livingRoom: 'Salon / Séjour',
  bedrooms: 'Chambres',
  bathroom: 'Salle de bain',
};

/** Parse roomsData (Json) — tolérant, jamais throw. */
function parseHubRooms(raw: unknown): HubRoom[] {
  if (!Array.isArray(raw)) return [];
  const rooms: HubRoom[] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const r = item as Record<string, unknown>;
    const id = typeof r.id === 'string' ? r.id : '';
    if (!id) continue;
    rooms.push({
      id,
      label: typeof r.label === 'string' && r.label.trim() ? r.label.trim() : ROOM_FALLBACK_LABEL[id] ?? id,
      status: typeof r.status === 'string' ? r.status : 'good',
      comment: typeof r.comment === 'string' && r.comment.trim() ? r.comment.trim() : null,
      photoCount: typeof r.photoCount === 'number' && Number.isFinite(r.photoCount) ? Math.max(0, Math.round(r.photoCount)) : 0,
    });
  }
  return rooms;
}

/** État Hub ('good'|'dirty'|'damaged') → état du design unifié. */
function hubStatusToState(status: string): string {
  switch (status) {
    case 'damaged':
      return 'MAUVAIS';
    case 'dirty':
      return 'MOYEN';
    default:
      return 'BON';
  }
}

/** Score de propreté dérivé des statuts de pièces (dirty → À nettoyer). */
function deriveCleanliness(rooms: HubRoom[]): string | null {
  if (rooms.length === 0) return null;
  return rooms.some((r) => r.status === 'dirty') ? 'A_NETTOYER' : 'IMPECCABLE';
}

/**
 * Convertit les pièces Hub + photos plates (damagePhotos, associées
 * par photoCount dans l'ordre) en pièces/items du design unifié.
 * Les pièces sans photo reçoivent une carte « État général ».
 */
function hubRoomsToStandaloneRooms(rooms: HubRoom[], flatPhotos: unknown): StandalonePdfRoom[] {
  const photos = Array.isArray(flatPhotos) ? flatPhotos : [];
  const out: StandalonePdfRoom[] = [];
  let cursor = 0;
  for (const room of rooms) {
    const state = hubStatusToState(room.status);
    const items: StandalonePdfRoom['items'] = [];
    let photoNo = 0;
    for (let i = 0; i < room.photoCount && cursor < photos.length; i++) {
      const dataUrl = photos[cursor];
      cursor += 1;
      if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) continue;
      photoNo += 1;
      items.push({
        name: photoNo === 1 ? 'Constat photo' : `Constat photo ${photoNo}`,
        state,
        comment: null,
        photoUrl: dataUrl,
      });
    }
    if (items.length === 0) {
      // Aucune photo : une carte « état général » porte le statut de la pièce.
      items.push({
        name: 'État général de la pièce',
        state,
        comment: null,
      });
    }
    out.push({ name: room.label, globalState: state, comment: room.comment, items });
  }
  // Photos orphelines (roomsData absent/ancien) — pièce générique.
  if (out.length === 0 && photos.length > 0) {
    const items: StandalonePdfRoom['items'] = [];
    let photoNo = 0;
    for (const dataUrl of photos.slice(0, 20)) {
      if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) continue;
      photoNo += 1;
      items.push({ name: photoNo === 1 ? 'Constat photo' : `Constat photo ${photoNo}`, state: 'MOYEN', comment: null, photoUrl: dataUrl });
    }
    if (items.length > 0) {
      out.push({ name: 'Constats & photos', globalState: 'MOYEN', comment: null, items });
    }
  }
  return out;
}

/** Inventaire de sortie {keys,remotes,towels} → pièce synthétique. */
function inventoryToRoom(raw: unknown): StandalonePdfRoom | null {
  if (!raw || typeof raw !== 'object') return null;
  const obj = raw as Record<string, unknown>;
  const rows: { name: string; value: number }[] = [
    { name: 'Clés remises', value: typeof obj.keys === 'number' ? obj.keys : NaN },
    { name: 'Télécommandes', value: typeof obj.remotes === 'number' ? obj.remotes : NaN },
    { name: 'Serviettes', value: typeof obj.towels === 'number' ? obj.towels : NaN },
  ].filter((r) => Number.isFinite(r.value)) as { name: string; value: number }[];
  if (rows.length === 0) return null;
  return {
    name: 'Inventaire de sortie',
    globalState: 'BON',
    comment: null,
    items: rows.map((r) => ({
      name: r.name,
      state: 'BON',
      comment: `Quantité : ${r.value}`,
    })),
  };
}

/** Minibar [{name,consumed}] → pièce synthétique (consommations). */
function minibarToRoom(raw: unknown): StandalonePdfRoom | null {
  if (!Array.isArray(raw)) return null;
  const items: StandalonePdfRoom['items'] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const r = item as Record<string, unknown>;
    const name = typeof r.name === 'string' ? r.name.trim().slice(0, 60) : '';
    const consumed = typeof r.consumed === 'number' && Number.isFinite(r.consumed) && r.consumed >= 0 ? Math.round(r.consumed) : 0;
    if (!name) continue;
    items.push({
      name,
      state: 'BON',
      comment: consumed > 0 ? `${consumed} consommé(s)` : 'Non consommé',
    });
  }
  if (items.length === 0) return null;
  return { name: 'Minibar — consommations', globalState: 'BON', comment: null, items };
}

// ---------- Mappings principaux ----------

/**
 * CheckOutInspection (Hub) → données du design unifié.
 * `linkedEntranceDate` : date de l'EDL d'entrée Hub lié (même
 * booking, type checkin) — affiche l'encart de comparaison.
 */
export function checkOutInspectionToStandalonePdfData(
  row: CheckOutInspectionRow,
  opts?: { linkedEntranceDate?: Date | null },
): StandaloneInspectionPdfData {
  const branding = parseBranding(row.property.branding);
  const isCheckout = row.type !== 'checkin';
  const rooms = parseHubRooms(row.roomsData);
  const standaloneRooms = hubRoomsToStandaloneRooms(rooms, row.damagePhotos);

  // Inventaire + minibar : pièces synthétiques en fin de document.
  const inventoryRoom = isCheckout ? inventoryToRoom(row.inventoryCheck) : null;
  const minibarRoom = isCheckout ? minibarToRoom(row.minibarData) : null;
  for (const extra of [inventoryRoom, minibarRoom]) {
    if (extra) standaloneRooms.push(extra);
  }

  const cleanScore = deriveCleanliness(rooms);
  // Commentaires libres + dégâts + auto-évaluation → section Ménage.
  const commentParts: string[] = [];
  if (row.issues?.trim()) commentParts.push(row.issues.trim());
  if (row.damages?.trim()) commentParts.push(`Dégâts constatés : ${row.damages.trim()}`);
  if (Number.isFinite(row.selfAssessment)) {
    commentParts.push(`Auto-évaluation de l'invité : ${row.selfAssessment}/5.`);
  }
  const cleanlinessComment = commentParts.length > 0 ? commentParts.join(' ') : null;

  const scheduledDate = isCheckout
    ? row.booking?.checkOut ?? row.signedAt
    : row.booking?.checkIn ?? row.signedAt;

  const data: StandaloneInspectionPdfData = {
    inspection: {
      publicToken: row.publicToken,
      propertyName: row.property.name,
      propertyAddress: row.property.address?.trim() || '—',
      ownerName:
        row.property.owner?.fullName?.trim() ||
        branding.companyName?.trim() ||
        'Propriétaire',
      guestName: row.guestName || 'Invité',
      type: isCheckout ? 'SORTIE' : 'ENTREE',
      scheduledDate,
      status: 'COMPLETED',
      signedAt: row.signedAt,
      completedAt: row.signedAt,
      cleanlinessScore: cleanScore,
      cleanlinessComment,
      cleanlinessPhotoUrl: null,
      guestSignature: row.guestSignature,
      linkedEntranceDate: isCheckout ? opts?.linkedEntranceDate ?? null : null,
      city: null, // non saisi dans le Hub → repli : 1re partie de l'adresse
      // Empreinte canonique officielle (même anti-fraude que le standalone).
      sha256Hash: computeInspectionSha256({
        publicToken: row.publicToken,
        propertyName: row.property.name,
        propertyAddress: row.property.address?.trim() || '—',
        ownerName: row.property.owner?.fullName?.trim() || 'Propriétaire',
        guestName: row.guestName || 'Invité',
        type: isCheckout ? 'SORTIE' : 'ENTREE',
        scheduledDate,
        status: 'COMPLETED',
        signedAt: row.signedAt,
        cleanlinessScore: cleanScore,
        cleanlinessComment,
        cleanlinessPhotoUrl: null,
        guestSignature: row.guestSignature,
        rooms: standaloneRooms,
      }),
      gpsLocation: null,
      ipAddress: row.ipAddress,
      brandLabel: branding.companyName, // white-label (défaut : RoomScan)
      verifyUrlPath: `public/inspection/${row.publicToken}`,
    },
    rooms: standaloneRooms,
  };
  return data;
}

/**
 * MinibarCheck (preuve d'inventaire d'arrivée) → design unifié
 * (attestation d'entrée : parties + QR + déclaration légale).
 */
export function minibarCheckToStandalonePdfData(row: MinibarCheckRow): StandaloneInspectionPdfData {
  const branding = parseBranding(row.property.branding);
  const guestName = row.guestName?.trim() || 'Invité';
  const propertyName = row.property.name;
  const propertyAddress = row.property.address?.trim() || '—';
  const ownerName = row.property.owner?.fullName?.trim() || branding.companyName?.trim() || 'Propriétaire';

  const data: StandaloneInspectionPdfData = {
    inspection: {
      publicToken: row.publicToken ?? row.id,
      propertyName,
      propertyAddress,
      ownerName,
      guestName,
      type: 'ENTREE',
      scheduledDate: row.booking?.checkIn ?? row.checkedAt,
      status: 'COMPLETED',
      signedAt: row.checkedAt,
      completedAt: row.checkedAt,
      cleanlinessScore: null,
      cleanlinessComment: null,
      cleanlinessPhotoUrl: null,
      guestSignature: null,
      linkedEntranceDate: null,
      city: null,
      sha256Hash: computeInspectionSha256({
        publicToken: row.publicToken ?? row.id,
        propertyName,
        propertyAddress,
        ownerName,
        guestName,
        type: 'ENTREE',
        scheduledDate: row.booking?.checkIn ?? row.checkedAt,
        status: 'COMPLETED',
        signedAt: row.checkedAt,
        cleanlinessScore: null,
        cleanlinessComment: null,
        cleanlinessPhotoUrl: null,
        guestSignature: null,
        rooms: [],
      }),
      gpsLocation: null,
      ipAddress: null,
      brandLabel: branding.companyName,
      verifyUrlPath: `public/inspection/${row.publicToken ?? row.id}`,
    },
    rooms: [],
  };
  return data;
}
