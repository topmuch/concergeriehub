// =============================================================
// v5.3 — FUSION PDF « ÉTAT DES LIEUX COMPLET — ENTRÉE + SORTIE »
//
// Demande client : « le document doit s'afficher déjà fusionné ».
// Une EDL de SORTIE liée à son ENTRÉE (Inspection.linkedInspectionId,
// ou couple checkin/checkout du même booking côté Hub) produit UN
// document unique : page de garde légère + PDF entrée + PDF sortie,
// assemblés avec pdf-lib (copie de pages, aucune re-génération).
//
// Contient aussi l'helper Content-Disposition RFC 5987 partagé par
// les routes PDF (filename accentué encodé proprement).
// =============================================================

import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';

// ---------- Palette (alignée sur le design unifié) ----------

const RED = rgb(0.76, 0.12, 0.15); // #C21F26 — rouge RoomScan
const DARK = rgb(0.09, 0.09, 0.1); // #17171A
const INK = rgb(0.12, 0.16, 0.22);
const MUTED = rgb(0.42, 0.45, 0.5);
const LIGHT_BG = rgb(0.965, 0.965, 0.97);
const CARD_BORDER = rgb(0.89, 0.89, 0.91);

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 40;

// ---------- Types publics ----------

export interface InspectionCoverInfo {
  /** Titre de la page de garde (défaut : « État des lieux complet — Entrée + Sortie »). */
  title?: string;
  propertyName: string;
  propertyAddress?: string | null;
  guestName: string;
  /** Date de référence (sortie signée / planifiée). */
  eventDate?: Date | null;
  /** Documents fusionnés, dans l'ordre (« 1. Attestation d'entrée », …). */
  parts: string[];
}

// ---------- Page de garde (pdf-lib, polices standard) ----------

const frDateLong = (d: Date) =>
  d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });

/** Texte WinAnsi-safe : les polices standard couvrent tous les caractères FR. */
function winAnsi(text: string): string {
  return text.replace(/\u2026/g, '...').replace(/[\u2018\u2019]/g, "'");
}

/** Construit la page de garde légère du document fusionné. */
async function buildCoverPdf(cover: InspectionCoverInfo): Promise<Buffer> {
  const doc = await PDFDocument.create();
  const page = doc.addPage([PAGE_W, PAGE_H]);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  const regular = await doc.embedFont(StandardFonts.Helvetica);

  // — Bandeau rouge pleine largeur (design unifié) —
  const bandH = 92;
  page.drawRectangle({ x: 0, y: PAGE_H - bandH, width: PAGE_W, height: bandH, color: RED });
  const title = winAnsi(cover.title ?? 'État des lieux complet — Entrée + Sortie');
  // Auto-fit du titre (28 → 16 pt) sur la largeur utile.
  let size = 26;
  while (size > 14 && bold.widthOfTextAtSize(title, size) > PAGE_W - MARGIN * 2) size -= 1;
  page.drawText(title, {
    x: (PAGE_W - bold.widthOfTextAtSize(title, size)) / 2,
    y: PAGE_H - bandH + 38,
    size,
    font: bold,
    color: rgb(1, 1, 1),
  });
  page.drawText(winAnsi('Dossier fusionné — document unique certifié'), {
    x: (PAGE_W - bold.widthOfTextAtSize('Dossier fusionné — document unique certifié', 10)) / 2,
    y: PAGE_H - bandH + 20,
    size: 10,
    font: regular,
    color: rgb(1, 0.92, 0.92),
  });

  // — Encadré parties —
  let y = PAGE_H - bandH - 46;
  const boxH = 148;
  page.drawRectangle({
    x: MARGIN,
    y: y - boxH,
    width: PAGE_W - MARGIN * 2,
    height: boxH,
    color: LIGHT_BG,
    borderColor: CARD_BORDER,
    borderWidth: 0.75,
  });
  const row = (label: string, value: string, ry: number) => {
    page.drawText(winAnsi(label), { x: MARGIN + 16, y: ry + 10, size: 6.6, font: bold, color: MUTED });
    page.drawText(winAnsi(value.slice(0, 72)), { x: MARGIN + 16, y: ry, size: 10.5, font: regular, color: INK });
  };
  row('LOGEMENT', cover.propertyName || '—', y - 34);
  row('ADRESSE', cover.propertyAddress?.trim() || '—', y - 62);
  row('INVITÉ', cover.guestName || '—', y - 90);
  row('DATE', cover.eventDate ? frDateLong(cover.eventDate) : '—', y - 118);

  // — Sommaire des documents fusionnés —
  y -= boxH + 40;
  page.drawText(winAnsi('Contenu du dossier'), {
    x: MARGIN,
    y,
    size: 12,
    font: bold,
    color: DARK,
  });
  y -= 26;
  for (const [i, part] of cover.parts.entries()) {
    page.drawRectangle({ x: MARGIN, y: y - 6, width: 22, height: 22, color: RED });
    page.drawText(String(i + 1), {
      x: MARGIN + (i + 1 < 10 ? 8 : 5),
      y: y,
      size: 11,
      font: bold,
      color: rgb(1, 1, 1),
    });
    page.drawText(winAnsi(part.replace(/^\d+\.\s*/, '')), {
      x: MARGIN + 34,
      y: y - 1,
      size: 11,
      font: regular,
      color: INK,
    });
    y -= 34;
  }

  // — Mention légale —
  page.drawText(
    winAnsi(
      'Les deux états des lieux (entrée et sortie) figurent intégralement dans le présent document. ' +
        'Chaque section conserve son QR code de vérification, son empreinte SHA-256 et sa déclaration légale.',
    ),
    { x: MARGIN, y: 96, size: 8.5, font: regular, color: MUTED, maxWidth: PAGE_W - MARGIN * 2, lineHeight: 12 },
  );
  page.drawText(winAnsi('Document officiel RoomScan • roomscan.pro'), {
    x: MARGIN,
    y: 52,
    size: 7.5,
    font: bold,
    color: DARK,
  });

  const bytes = await doc.save();
  return Buffer.from(bytes);
}

// ---------- Fusion ----------

/**
 * Fusionne N PDF (Buffers) derrière une page de garde.
 * Robuste : si une partie est illisible, elle est ignorée (jamais de
 * document vide) ; si TOUTES échouent, la fonction throw (la route
 * répondra 500 et retombera sur le document simple).
 */
export async function mergePdfsWithCoverPage(
  parts: Buffer[],
  cover: InspectionCoverInfo,
): Promise<Buffer> {
  const merged = await PDFDocument.create();
  const coverBuf = await buildCoverPdf(cover);
  const coverDoc = await PDFDocument.load(coverBuf, { ignoreEncryption: true });
  const coverPages = await merged.copyPages(coverDoc, coverDoc.getPageIndices());
  for (const p of coverPages) merged.addPage(p);

  for (const part of parts) {
    try {
      const sub = await PDFDocument.load(part, { ignoreEncryption: true });
      const pages = await merged.copyPages(sub, sub.getPageIndices());
      for (const p of pages) merged.addPage(p);
    } catch {
      // Partie illisible — ignorée, le reste du dossier reste valide.
    }
  }
  const bytes = await merged.save();
  return Buffer.from(bytes);
}

// ---------- Content-Disposition (RFC 5987) ----------

/**
 * En-tête Content-Disposition avec filename ASCII de repli +
 * filename* UTF-8 (accents français préservés — RFC 5987/6266).
 */
export function pdfContentDisposition(filename: string, mode: 'inline' | 'attachment' = 'inline'): string {
  const ascii = filename
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^\x20-\x7E]/g, '_')
    .replace(/"/g, '');
  const encoded = encodeURIComponent(filename).replace(
    /['()*]/g,
    (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`,
  );
  return `${mode}; filename="${ascii}"; filename*=UTF-8''${encoded}`;
}
