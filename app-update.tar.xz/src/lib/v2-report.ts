// =============================================================
// V2 « BOUCLIER » — RAPPORT PDF SCELLÉ (étape 6)
// Générateur server-only basé sur pdf-lib : polices standard
// embarquées dans le paquet (aucun accès fs, aucune police
// système) → compatible bundler Next.js.
//
// Contenu du rapport :
//   · bandeau RoomScan Bouclier + badge Entrée/Sortie ;
//   · fiche logement (type, adresse, pièces, équipements) et
//     fiche intervention horodatée (créneau, démarré, scellé,
//     réalisé par) ;
//   · bloc « scellement numérique » : empreinte SHA-256 de la
//     vidéo walk-through (+ chaîne de preuve vers le check-in
//     d'origine pour les check-outs) ;
//   · comparaison photo par photo pour CHAQUE pièce réelle du
//     bien — check-in : référence de bibliothèque vs photo
//     d'entrée · check-out : photo du check-in d'origine vs
//     photo de sortie ;
//   · pied de page horodaté + pagination sur toutes les pages.
//
// Toutes les chaînes sont assainies WinAnsi (accents français
// conservés, emoji retirés) pour éviter toute erreur d'encodage.
// =============================================================
import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFImage, type PDFPage, type RGB } from 'pdf-lib';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import {
  HOUSING_TYPE_LABELS,
  type HousingType,
  type ReferencePhotoLibrary,
  type ShieldSessionPhotos,
} from '@/lib/v2';

// ---------- Palette V2 (mêmes couleurs que l'app) ----------
const NAVY = rgb(30 / 255, 58 / 255, 138 / 255); // #1E3A8A
const RED = rgb(196 / 255, 30 / 255, 58 / 255); // #C41E3A
const INK = rgb(15 / 255, 23 / 255, 42 / 255); // slate-900
const SLATE_600 = rgb(71 / 255, 85 / 255, 105 / 255);
const SLATE_500 = rgb(100 / 255, 116 / 255, 139 / 255);
const SLATE_400 = rgb(148 / 255, 163 / 255, 184 / 255);
const SLATE_300 = rgb(203 / 255, 213 / 255, 225 / 255);
const SLATE_200 = rgb(226 / 255, 232 / 255, 240 / 255);
const SLATE_100 = rgb(241 / 255, 245 / 255, 249 / 255);
const SLATE_50 = rgb(248 / 255, 250 / 255, 252 / 255);
const EMERALD = rgb(4 / 255, 120 / 255, 87 / 255); // emerald-700
const WHITE = rgb(1, 1, 1);

// ---------- Géométrie A4 ----------
const PAGE_W = 595.28;
const PAGE_H = 841.89;
const M = 45; // marge
const CONTENT_W = PAGE_W - 2 * M; // ≈ 505
const IMG_W = 245; // colonne photo (2 colonnes + gouttière = CONTENT_W)
const IMG_H = 150;
const IMG_GAP = CONTENT_W - 2 * IMG_W; // gouttière ≈ 15

// ---------- Types d'entrée ----------
export interface ReportCheckInContext {
  completedAt: Date | null;
  cleanerName: string | null;
  videoHash: string | null;
  photos: ShieldSessionPhotos | null;
}

export interface ReportInput {
  property: {
    name: string;
    address: string | null;
    housingType: string | null;
    rooms: string[];
    appliances: string[];
  };
  session: {
    type: 'CHECKIN' | 'CHECKOUT';
    scheduledAt: Date | null;
    startedAt: Date | null;
    completedAt: Date | null;
    cleanerName: string | null;
    photos: ShieldSessionPhotos;
    videoHash: string | null;
    publicToken: string | null;
  };
  /** Check-out uniquement : le check-in d'origine (chaîne de preuve). */
  checkIn: ReportCheckInContext | null;
  /** Bibliothèque Bouclier de l'onboarding (photos de référence). */
  reference: ReferencePhotoLibrary;
  generatedAt: Date;
}

// ---------- Assainissement WinAnsi ----------
// Les polices standard PDF encodent en WinAnsi (cp1252) : accents
// français OK, mais emoji / espaces fines / flèches → exclus.
const WINANSI_EXTRA = new Set(
  [
    0x2013, 0x2014, 0x2018, 0x2019, 0x201a, 0x201c, 0x201d, 0x201e, 0x2020, 0x2021, 0x2022,
    0x2026, 0x2030, 0x2032, 0x2033, 0x2039, 0x203a, 0x203e, 0x20ac, 0x2122, 0x0160, 0x0161,
    0x0152, 0x0153, 0x0178, 0x017d, 0x017e, 0x0192, 0x02c6, 0x02dc, 0x2260,
  ].map((c) => String.fromCharCode(c)),
);

function san(input: string): string {
  let out = '';
  for (const ch of input.normalize('NFC').replace(/[\r\t\u200b]/g, ' ')) {
    const code = ch.codePointAt(0) ?? 0;
    if (ch === '\n' || (code >= 0x20 && code <= 0x7e) || (code >= 0xa0 && code <= 0xff) || WINANSI_EXTRA.has(ch)) {
      out += ch;
    } else if (code === 0x202f || code === 0x2009 || code === 0x2007) {
      out += ' '; // espaces fines → espace simple
    }
    // tout le reste (emoji, C1,…) est retiré silencieusement
  }
  return out;
}

// ---------- Dates en français ----------
function fmtDateTime(d: Date): string {
  return format(d, "d MMM yyyy 'à' HH:mm", { locale: fr });
}
function fmtDateShort(d: Date): string {
  return format(d, 'd MMM yyyy', { locale: fr });
}

// ---------- Wrap de texte (pdf-lib n'a pas de retour à la ligne auto) ----------
function wrap(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = '';
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, size) <= maxWidth) {
      line = candidate;
    } else {
      if (line) lines.push(line);
      line = word;
      // mot plus large que la colonne : coupe brut
      while (font.widthOfTextAtSize(line, size) > maxWidth && line.length > 2) {
        let cut = line.length - 1;
        while (cut > 2 && font.widthOfTextAtSize(line.slice(0, cut), size) > maxWidth) cut--;
        lines.push(line.slice(0, cut));
        line = line.slice(cut);
      }
    }
  }
  if (line) lines.push(line);
  return lines.length > 0 ? lines : [''];
}

/** Tronque une légende sur une seule ligne avec « … ». */
function fitLine(text: string, font: PDFFont, size: number, maxWidth: number): string {
  let t = text;
  while (font.widthOfTextAtSize(t, size) > maxWidth && t.length > 4) {
    t = `${t.slice(0, -2).trimEnd()}…`;
  }
  return t;
}

// ---------- dataURL → octets ----------
function decodeDataUrl(dataUrl: string): { mime: string; bytes: Uint8Array } | null {
  const comma = dataUrl.indexOf(',');
  if (comma < 0) return null;
  const mime = (dataUrl.slice(5, comma).split(';')[0] ?? '').toLowerCase();
  try {
    const buf = Buffer.from(dataUrl.slice(comma + 1), 'base64');
    // ⚠️ pdf-lib (JpegEmbedder) lit `new DataView(bytes.buffer)` SANS
    // tenir compte du byteOffset — or Node regroupe les petits Buffer
    // dans un pool partagé (offset ≠ 0) → « SOI not found in JPEG ».
    // On copie donc dans un Uint8Array de taille exacte (offset 0).
    const bytes = new Uint8Array(buf.byteLength);
    bytes.set(buf);
    return bytes.length > 0 ? { mime, bytes } : null;
  } catch {
    return null;
  }
}

async function embedImage(doc: PDFDocument, dataUrl: string): Promise<PDFImage | null> {
  const d = decodeDataUrl(dataUrl);
  if (!d) return null;
  try {
    if (d.mime === 'image/png') return await doc.embedPng(d.bytes);
    if (d.mime === 'image/jpeg' || d.mime === 'image/jpg') return await doc.embedJpg(d.bytes);
    return null;
  } catch {
    return null; // JPEG progressif / image corrompue → case « indisponible »
  }
}

// ---------- Nom de fichier du rapport ----------
export function reportFilename(
  type: 'CHECKIN' | 'CHECKOUT',
  propertyName: string,
  when: Date,
): string {
  const slug =
    propertyName
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-+|-+$)/g, '')
      .slice(0, 40) || 'logement';
  return `rapport-${type === 'CHECKIN' ? 'checkin' : 'checkout'}-${slug}-${format(when, 'yyyy-MM-dd')}.pdf`;
}

// =============================================================
// Générateur principal
// =============================================================
export async function buildSessionReportPdf(input: ReportInput): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  const helv = await doc.embedFont(StandardFonts.Helvetica);
  const helvB = await doc.embedFont(StandardFonts.HelveticaBold);
  const helvO = await doc.embedFont(StandardFonts.HelveticaOblique);
  const courierB = await doc.embedFont(StandardFonts.CourierBold);

  doc.setTitle(san(`Rapport d'état des lieux — ${input.property.name}`));
  doc.setAuthor('RoomScan Bouclier');
  doc.setSubject(
    san(
      input.session.type === 'CHECKIN'
        ? "État des lieux d'entrée (check-in) scellé SHA-256"
        : "État des lieux de sortie (check-out) scellé SHA-256",
    ),
  );
  doc.setCreator('RoomScan Bouclier');
  doc.setCreationDate(input.generatedAt);

  const isCheckin = input.session.type === 'CHECKIN';
  const rooms = input.property.rooms;

  const pages: PDFPage[] = [];
  let page = doc.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = 0;

  /** Nouvelle page (avec mini-en-tête de continuation). */
  function addPage(): void {
    page = doc.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = PAGE_H - 52;
    page.drawText(san(`${input.property.name} · ${isCheckin ? 'Check-in' : 'Check-out'}`), {
      x: M,
      y: PAGE_H - 30,
      size: 8,
      font: helvB,
      color: SLATE_400,
    });
    page.drawRectangle({ x: M, y: PAGE_H - 38, width: CONTENT_W, height: 0.75, color: SLATE_200 });
  }

  function ensure(need: number): void {
    if (y - need < 56) addPage();
  }

  // ── Bandeau bleu (page 1) ──────────────────────────────────
  const bandH = 64;
  page.drawRectangle({ x: 0, y: PAGE_H - bandH, width: PAGE_W, height: bandH, color: NAVY });
  page.drawText(san('ROOMSCAN BOUCLIER'), { x: M, y: PAGE_H - 30, size: 15, font: helvB, color: WHITE });
  page.drawText(san("Rapport d'état des lieux scellé"), {
    x: M,
    y: PAGE_H - 44,
    size: 8.5,
    font: helv,
    color: WHITE,
    opacity: 0.8,
  });
  const badgeLabel = isCheckin ? 'CHECK-IN — ENTRÉE' : 'CHECK-OUT — SORTIE';
  const badgeW = helvB.widthOfTextAtSize(badgeLabel, 9) + 16;
  page.drawRectangle({ x: PAGE_W - M - badgeW, y: PAGE_H - 33, width: badgeW, height: 18, color: RED });
  page.drawText(san(badgeLabel), {
    x: PAGE_W - M - badgeW + 8,
    y: PAGE_H - 27,
    size: 9,
    font: helvB,
    color: WHITE,
  });
  const sealTag = 'SCELLÉ SHA-256';
  page.drawText(sealTag, {
    x: PAGE_W - M - helvB.widthOfTextAtSize(sealTag, 7.5),
    y: PAGE_H - 45,
    size: 7.5,
    font: helvB,
    color: WHITE,
    opacity: 0.85,
  });
  page.drawRectangle({ x: 0, y: PAGE_H - bandH - 3, width: PAGE_W, height: 3, color: RED });
  y = PAGE_H - bandH - 3 - 28;

  // ── Titre : le logement ────────────────────────────────────
  page.drawText(san(input.property.name), { x: M, y, size: 16, font: helvB, color: INK });
  y -= 16;
  const housingLabel =
    input.property.housingType && input.property.housingType in HOUSING_TYPE_LABELS
      ? HOUSING_TYPE_LABELS[input.property.housingType as HousingType]
      : (input.property.housingType ?? 'Logement');
  const subtitle = san(
    [input.property.address, housingLabel].filter((v): v is string => Boolean(v)).join(' · '),
  );
  page.drawText(subtitle, { x: M, y, size: 9, font: helv, color: SLATE_500 });
  y -= 10;
  page.drawRectangle({ x: M, y, width: CONTENT_W, height: 0.75, color: SLATE_200 });
  y -= 22;

  // ── Deux colonnes : logement / intervention ────────────────
  interface InfoRow {
    label: string;
    value: string;
    valueColor?: RGB;
    valueFont?: PDFFont;
  }

  function drawColumn(x: number, w: number, title: string, rows: InfoRow[]): number {
    let cy = y;
    page.drawText(san(title), { x, y: cy, size: 8, font: helvB, color: SLATE_500 });
    cy -= 16;
    for (const row of rows) {
      page.drawText(san(row.label).toUpperCase(), { x, y: cy, size: 6.8, font: helv, color: SLATE_400 });
      cy -= 11;
      for (const line of wrap(san(row.value), helv, 9.5, w)) {
        page.drawText(line, {
          x,
          y: cy,
          size: 9.5,
          font: row.valueFont ?? helv,
          color: row.valueColor ?? INK,
        });
        cy -= 12;
      }
      cy -= 5;
    }
    return cy;
  }

  const yLeft = drawColumn(M, 245, 'LE LOGEMENT', [
    { label: 'Type', value: housingLabel },
    { label: 'Adresse', value: input.property.address ?? '—' },
    { label: 'Pièces', value: rooms.join(' · ') },
    {
      label: 'Équipements',
      value: input.property.appliances.length > 0 ? input.property.appliances.join(' · ') : '—',
    },
  ]);
  const yRight = drawColumn(M + 275, 230, "L'INTERVENTION", [
    { label: "État des lieux", value: isCheckin ? 'Entrée (check-in)' : 'Sortie (check-out)' },
    { label: 'Créneau prévu', value: input.session.scheduledAt ? fmtDateTime(input.session.scheduledAt) : '—' },
    { label: 'Démarré le', value: input.session.startedAt ? fmtDateTime(input.session.startedAt) : '—' },
    { label: 'Scellé le', value: input.session.completedAt ? fmtDateTime(input.session.completedAt) : '—' },
    { label: 'Réalisé par', value: input.session.cleanerName ?? '—' },
    { label: 'Statut', value: 'Terminé', valueColor: EMERALD, valueFont: helvB },
  ]);
  y = Math.min(yLeft, yRight) - 8;

  // ── Bloc scellement SHA-256 ────────────────────────────────
  const chainLines: string[] = [];
  if (!isCheckin && input.checkIn?.videoHash) {
    chainLines.push(
      san(
        `Rattaché au check-in d'origine scellé le ${
          input.checkIn.completedAt ? fmtDateTime(input.checkIn.completedAt) : '—'
        } — empreinte vidéo ${input.checkIn.videoHash.slice(0, 24)}…`,
      ),
    );
  }
  const genLine = san(
    `Rapport généré le ${fmtDateTime(input.generatedAt)}${
      input.session.publicToken ? ` · Référence dossier ${input.session.publicToken.slice(0, 16)}…` : ''
    }`,
  );
  const sealH = 12 + 11 + 5 + 9 + 3 + 11 + 7 + chainLines.length * 10 + 2 + 10 + 12;
  ensure(sealH + 10);
  page.drawRectangle({
    x: M,
    y: y - sealH,
    width: CONTENT_W,
    height: sealH,
    color: SLATE_50,
    borderColor: SLATE_300,
    borderWidth: 1,
  });
  let sy = y - 12 - 9; // pad haut + hauteur du titre
  page.drawText(san('SCELLEMENT NUMÉRIQUE — VIDÉO WALK-THROUGH'), {
    x: M + 12,
    y: sy,
    size: 9,
    font: helvB,
    color: RED,
  });
  sy -= 14;
  page.drawText(san('Empreinte SHA-256 des octets de la vidéo :'), {
    x: M + 12,
    y: sy,
    size: 7.5,
    font: helv,
    color: SLATE_500,
  });
  sy -= 14;
  page.drawText(input.session.videoHash ?? '—', {
    x: M + 12,
    y: sy,
    size: 9,
    font: courierB,
    color: INK,
  });
  sy -= 7 + chainLines.length * 10;
  for (const line of chainLines) {
    page.drawText(fitLine(line, helv, 7.5, CONTENT_W - 24), {
      x: M + 12,
      y: sy,
      size: 7.5,
      font: helv,
      color: SLATE_600,
    });
    sy -= 10;
  }
  page.drawText(genLine, { x: M + 12, y: sy, size: 7.5, font: helv, color: SLATE_500 });
  y = y - sealH - 22;

  // ── Photos : comparaison pièce par pièce ───────────────────
  ensure(46);
  page.drawText(san(`PIÈCES — COMPARAISON PHOTO PAR PHOTO (${rooms.length})`), {
    x: M,
    y,
    size: 11,
    font: helvB,
    color: NAVY,
  });
  y -= 13;
  page.drawText(
    san(
      isCheckin
        ? "Chaque photo d'entrée est confrontée à la photo de référence de la bibliothèque (même angle)."
        : "Chaque photo de sortie est confrontée au check-in d'origine — mêmes angles, comparaison directe.",
    ),
    { x: M, y, size: 8, font: helv, color: SLATE_500 },
  );
  y -= 18;

  /** Dessine une colonne photo (image ajustée ou case indisponible) + légende. */
  async function drawPhotoColumn(dataUrl: string | null, x: number, caption: string): Promise<void> {
    const boxY = y - IMG_H;
    page.drawRectangle({
      x,
      y: boxY,
      width: IMG_W,
      height: IMG_H,
      color: SLATE_100,
      borderColor: SLATE_200,
      borderWidth: 0.75,
    });
    const img = dataUrl ? await embedImage(doc, dataUrl) : null;
    if (img) {
      const scale = Math.min((IMG_W - 4) / img.width, (IMG_H - 4) / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      page.drawImage(img, { x: x + (IMG_W - w) / 2, y: boxY + (IMG_H - h) / 2, width: w, height: h });
    } else {
      const ph = 'Photo indisponible';
      page.drawText(ph, {
        x: x + (IMG_W - helvO.widthOfTextAtSize(ph, 8)) / 2,
        y: boxY + IMG_H / 2 - 3,
        size: 8,
        font: helvO,
        color: SLATE_400,
      });
    }
    const cap = fitLine(san(caption), helvB, 6.8, IMG_W);
    page.drawText(cap, {
      x: x + (IMG_W - helvB.widthOfTextAtSize(cap, 6.8)) / 2,
      y: boxY - 10,
      size: 6.8,
      font: helvB,
      color: SLATE_600,
    });
  }

  for (let i = 0; i < rooms.length; i++) {
    const room = rooms[i];
    ensure(15 + 6 + IMG_H + 12 + 16);
    const chipW = helvB.widthOfTextAtSize(san(room), 9) + 14;
    page.drawRectangle({ x: M, y: y - 15, width: chipW, height: 15, color: NAVY });
    page.drawText(san(room), { x: M + 7, y: y - 10.5, size: 9, font: helvB, color: WHITE });
    const counter = `${i + 1} / ${rooms.length}`;
    page.drawText(counter, {
      x: PAGE_W - M - helv.widthOfTextAtSize(counter, 7.5),
      y: y - 11,
      size: 7.5,
      font: helv,
      color: SLATE_400,
    });
    y -= 21; // chip + respiration

    // Colonne gauche : référence (check-in) / photos du check-in (check-out)
    const leftUrl =
      isCheckin
        ? (input.reference[room]?.[0]?.dataUrl ?? null)
        : (input.checkIn?.photos?.[room] ?? input.reference[room]?.[0]?.dataUrl ?? null);
    const leftCaption = isCheckin
      ? `RÉFÉRENCE${
          input.reference[room]?.[0]?.takenAt
            ? ` — ${fmtDateShort(new Date(input.reference[room][0].takenAt))}`
            : ' — BIBLIOTHÈQUE'
        }`
      : `AU CHECK-IN${
          input.checkIn?.completedAt ? ` — ${fmtDateTime(input.checkIn.completedAt)}` : ' — RÉFÉRENCE'
        }`;
    await drawPhotoColumn(leftUrl, M, leftCaption);

    // Colonne droite : la photo de la session scellée
    const rightCaption = isCheckin
      ? `PHOTO À L'ENTRÉE${
          input.session.completedAt ? ` — ${fmtDateTime(input.session.completedAt)}` : ''
        }`
      : `AU CHECK-OUT${
          input.session.completedAt ? ` — ${fmtDateTime(input.session.completedAt)}` : ''
        }`;
    await drawPhotoColumn(input.session.photos[room] ?? null, M + IMG_W + IMG_GAP, rightCaption);

    y -= IMG_H + 18;
  }

  // ── Note de sécurité ───────────────────────────────────────
  y -= 2;
  ensure(26);
  for (const line of wrap(
    san(
      "Sécurité : l'empreinte SHA-256 ci-dessus scelle la vidéo walk-through de l'intervention. Toute modification de la vidéo après scellement invaliderait cette empreinte — le rapport fait foi en l'état.",
    ),
    helv,
    7.5,
    CONTENT_W,
  )) {
    page.drawText(line, { x: M, y, size: 7.5, font: helv, color: SLATE_500 });
    y -= 10;
  }

  // ── Pied de page : toutes les pages ────────────────────────
  const total = pages.length;
  const footer = san(
    `RoomScan Bouclier — rapport généré automatiquement le ${fmtDateTime(input.generatedAt)}`,
  );
  for (let i = 0; i < total; i++) {
    const p = pages[i];
    p.drawRectangle({ x: M, y: 46, width: CONTENT_W, height: 0.75, color: SLATE_200 });
    p.drawText(footer, { x: M, y: 36, size: 7, font: helv, color: SLATE_400 });
    const pn = `Page ${i + 1} / ${total}`;
    p.drawText(pn, {
      x: PAGE_W - M - helv.widthOfTextAtSize(pn, 7),
      y: 36,
      size: 7,
      font: helv,
      color: SLATE_400,
    });
  }

  return doc.save();
}
