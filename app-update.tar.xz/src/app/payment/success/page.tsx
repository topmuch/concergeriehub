import type { Metadata } from 'next';
import { Suspense } from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import PaymentSuccess from '@/components/payment/payment-success';

export const metadata: Metadata = {
  title: 'Paiement confirmé — Certificat Anti-Dégâts | RoomScan',
  description:
    'Votre Certificat Anti-Dégâts est activé. Activez votre protection en 5 minutes avec le wizard d’onboarding guidé.',
};

// v4.124 (fusion v4.125) — CIRCUIT v2 (one-shot) : la page post-paiement
// s'affiche « une seule fois ». Si l'utilisateur a DÉJÀ complété
// l'onboarding (flag User.onboardingCompleted posé par
// /api/shield/onboarding), le CTA « Commencer l'onboarding » est
// remplacé par le mode « configuration déjà active — Aller à mon
// tableau de bord ». Sans session (visite directe), on garde le CTA
// d'onboarding.
export default async function PaymentSuccessPage() {
  let alreadyOnboarded = false;
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (userId) {
      const me = await db.user
        .findUnique({ where: { id: userId }, select: { onboardingCompleted: true } })
        .catch(() => null);
      alreadyOnboarded = Boolean(me?.onboardingCompleted);
    }
  } catch {
    alreadyOnboarded = false;
  }

  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-50">
          <div className="mx-auto w-full max-w-5xl px-4 py-16">
            <div className="h-64 animate-pulse rounded-3xl border border-gray-200 bg-gray-100 shadow-sm" aria-hidden="true" />
          </div>
        </div>
      }
    >
      <PaymentSuccess alreadyOnboarded={alreadyOnboarded} />
    </Suspense>
  );
}
