import type { Metadata } from 'next';
import { Suspense } from 'react';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import PaymentSuccess from '@/components/payment/payment-success';
import PaymentSuccessV2, { type V2PlanKey } from '@/components/payment/payment-success-v2';

// =============================================================
// ÉTAPE 8 (V2) — PAGE POST-PAIEMENT DOUBLE CIRCUIT (additif) :
//
// - `?plan=essentiel|pro` présent (tunnel « Abonnement » V2) →
//   composant V2 PaymentSuccessV2 : branding Bouclier, rappel de la
//   formule payée, gros CTA rouge vers l'onboarding V2
//   (/airbnb/onboarding) — ou, si au moins un bien possède déjà sa
//   bibliothèque (Property.onboardingDone), CTA direct
//   /airbnb/dashboard (la page ne s'affiche « qu'une fois »).
// - SANS ?plan= → circuits V1 inchangés (Stripe checkout, EDL
//   PayPal, gate /inspection) : composant PaymentSuccess V1 avec le
//   flag User.onboardingCompleted. Zéro régression.
// =============================================================

type SearchParams = { plan?: string | string[] };

function parsePlan(raw: string | string[] | undefined): V2PlanKey | null {
  const value = Array.isArray(raw) ? raw[0] : raw;
  return value === 'essentiel' || value === 'pro' ? value : null;
}

export async function generateMetadata({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}): Promise<Metadata> {
  const params = await searchParams.catch(() => ({}) as SearchParams);
  const plan = parsePlan(params?.plan);
  if (plan) {
    const label = plan === 'pro' ? 'Pro' : 'Essentiel';
    return {
      title: `Paiement confirmé — Formule ${label} | RoomScan Bouclier`,
      description:
        'Votre formule RoomScan Bouclier est activée. Configurez votre premier logement en 5 minutes avec l’onboarding guidé.',
    };
  }
  return {
    title: 'Paiement confirmé — Certificat Anti-Dégâts | RoomScan',
    description:
      'Votre Certificat Anti-Dégâts est activé. Activez votre protection en 5 minutes avec le wizard d’onboarding guidé.',
  };
}

async function V2SuccessContent({ plan }: { plan: V2PlanKey }) {
  // V2 : « déjà configuré » = au moins un bien du possesseur avec sa
  // bibliothèque de référence (onboarding V2 terminé). Sans session,
  // on garde le CTA d'onboarding (la route /airbnb/* demandera le login).
  let alreadyConfigured = false;
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (userId) {
      const count = await db.property.count({
        where: { ownerId: userId, onboardingDone: true },
      });
      alreadyConfigured = count > 0;
    }
  } catch {
    alreadyConfigured = false;
  }
  return <PaymentSuccessV2 plan={plan} alreadyConfigured={alreadyConfigured} />;
}

export default async function PaymentSuccessPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams.catch(() => ({}) as SearchParams);
  const plan = parsePlan(params?.plan);

  // Circuit V2 (tunnel Abonnement) — étape 8.
  if (plan) {
    return (
      <Suspense
        fallback={
          <div className="min-h-screen bg-slate-50">
            <div className="mx-auto w-full max-w-5xl px-4 py-16">
              <div
                className="h-64 animate-pulse rounded-3xl border border-slate-200 bg-slate-100 shadow-sm"
                aria-hidden="true"
              />
            </div>
          </div>
        }
      >
        <V2SuccessContent plan={plan} />
      </Suspense>
    );
  }

  // Circuit V1 inchangé (Stripe / EDL / gate inspection).
  let alreadyOnboarded = false;
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (userId) {
      const me = await db.user
        .findUnique({ where: { id: userId }, select: { onboardingCompleted: true } })
        .catch(() => null);
      alreadyOnboarded = Boolean(me?.onboardingCompleted);
    }
  } catch {
    alreadyOnboarded = false;
  }

  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-50">
          <div className="mx-auto w-full max-w-5xl px-4 py-16">
            <div className="h-64 animate-pulse rounded-3xl border border-gray-200 bg-gray-100 shadow-sm" aria-hidden="true" />
          </div>
        </div>
      }
    >
      <PaymentSuccess alreadyOnboarded={alreadyOnboarded} />
    </Suspense>
  );
}
