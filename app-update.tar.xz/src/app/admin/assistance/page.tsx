import type { Metadata } from 'next';
import { AdminAssistance } from '@/components/admin/admin-assistance';

export const metadata: Metadata = {
  title: 'Assistance — Superadmin RoomScan',
  description: 'Tickets d’assistance ouverts par les hôtes — réponses et suivi.',
  robots: { index: false, follow: false },
};

// v4.125 — ONGLET « ASSISTANCE » du Superadmin. Connecté à l'onglet
// Assistance du dashboard hôte (module États des Lieux) via les
// tables edl_support_tickets / edl_support_messages : l'hôte crée un
// ticket et échange dans son fil ; le Superadmin répond ici — les
// deux onglets communiquent en temps réel à chaque rechargement.
// La protection superadmin est faite par /admin/layout.tsx.
export default function AdminAssistancePage() {
  return <AdminAssistance />;
}
