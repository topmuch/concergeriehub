// =============================================================
// /s/[token] — V2 « BOUCLIER » flux C (étape 5)
// PAGE PUBLIQUE CLEANER — lien reçu par SMS/WhatsApp de l'hôte.
// Le token (32 hex) EST l'authentification : rien d'autre requis.
//
// État des lieux guidé, mobile d'abord :
//   · 1 photo par pièce RÉELLE du bien (zéro case vide) — fantôme de
//     référence en transparence 50 % pour reproduire l'angle exact
//     (check-in : bibliothèque d'onboarding · check-out : photos du
//     check-in d'origine, pour la comparaison photo par photo) ;
//   · vidéo walk-through d'une traversée continue, scellée SHA-256 ;
//   · à la fin : statut TERMINE — le rapport part côté hôte.
// =============================================================
import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { db } from '@/lib/db';
import type { ReferencePhoto, ShieldSessionPhotos } from '@/lib/v2';
import { ShieldSessionFlow, type SessionFlowProps } from '@/components/shield/session-flow';
import { SealedScreen } from '@/components/shield/session-flow';

export const dynamic = 'force-dynamic';

export async function generateMetadata({
  params,
}: {
  params: Promise<{ token: string }>;
}): Promise<Metadata> {
  const { token } = await params;
  const session = await db.session.findUnique({
    where: { publicToken: token },
    select: { type: true, property: { select: { name: true } } },
  });
  if (!session) return { title: 'Séjour introuvable — RoomScan Bouclier' };
  return {
    title:
      session.type === 'CHECKIN'
        ? `Check-in — ${session.property.name} | RoomScan Bouclier`
        : `Check-out — ${session.property.name} | RoomScan Bouclier`,
    robots: { index: false, follow: false },
  };
}

/** Fantôme d'une pièce : check-out → photo du check-in, sinon bibliothèque. */
function ghostFor(
  room: string,
  type: string,
  checkInPhotos: ShieldSessionPhotos | null,
  reference: Record<string, ReferencePhoto[]>,
): string | null {
  if (type === 'CHECKOUT' && checkInPhotos && checkInPhotos[room]) {
    return checkInPhotos[room];
  }
  return reference[room]?.[0]?.dataUrl ?? null;
}

export default async function CleanerSessionPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;

  const session = await db.session.findUnique({
    where: { publicToken: token },
    select: {
      id: true,
      type: true,
      status: true,
      cleanerName: true,
      scheduledAt: true,
      completedAt: true,
      photos: true,
      videoHash: true,
      checkInSession: { select: { photos: true } },
      property: {
        select: {
          name: true,
          address: true,
          shieldRooms: true,
          referencePhotos: true,
        },
      },
    },
  });

  if (!session) notFound();

  const rooms = Array.isArray(session.property.shieldRooms)
    ? (session.property.shieldRooms as string[])
    : [];
  const reference = (session.property.referencePhotos ?? {}) as unknown as Record<
    string,
    ReferencePhoto[]
  >;
  const checkInPhotos =
    session.checkInSession?.photos &&
    typeof session.checkInSession.photos === 'object'
      ? (session.checkInSession.photos as ShieldSessionPhotos)
      : null;

  const photos: ShieldSessionPhotos = {};
  if (session.photos && typeof session.photos === 'object') {
    for (const [k, v] of Object.entries(session.photos as Record<string, unknown>)) {
      if (typeof v === 'string') photos[k] = v;
    }
  }

  // ── Séjour déjà scellé : écran de confirmation en lecture seule ──
  if (session.status === 'TERMINE') {
    return (
      <SealedScreen
        type={session.type}
        propertyName={session.property.name}
        rooms={rooms}
        photos={photos}
        completedAt={session.completedAt?.toISOString() ?? null}
        videoHash={session.videoHash}
        cleanerName={session.cleanerName}
      />
    );
  }

  // ── Séjour annulé par l'hôte ──
  if (session.status === 'ANNULE') {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-6 text-center">
        <div className="w-full max-w-sm rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-2xl">
            🚫
          </div>
          <h1 className="text-lg font-bold text-slate-900">Séjour annulé</h1>
          <p className="mt-2 text-sm text-slate-500">
            L’hôte a annulé ce séjour. Vous pouvez fermer cette page.
          </p>
        </div>
      </main>
    );
  }

  // ── Flux de capture (À venir, même si le créneau est passé) ──
  const flow: SessionFlowProps = {
    token,
    type: session.type,
    propertyName: session.property.name,
    address: session.property.address,
    rooms,
    ghosts: Object.fromEntries(
      rooms.map((r) => [r, ghostFor(r, session.type, checkInPhotos, reference)]),
    ),
    initialPhotos: photos,
    initialCleanerName: session.cleanerName ?? '',
    scheduledAt: session.scheduledAt?.toISOString() ?? null,
  };
  return <ShieldSessionFlow {...flow} />;
}
