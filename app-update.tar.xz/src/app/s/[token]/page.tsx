import type { Metadata } from 'next';
import Link from 'next/link';
import { db } from '@/lib/db';
import { notFound } from 'next/navigation';
import {
  DoorClosed,
  DoorOpen,
  Lock,
  ShieldCheck,
  XCircle,
} from 'lucide-react';
import CleanerFlow, { type CleanerZone } from '@/components/shield/cleaner-flow';
import {
  APPLIANCE_LABELS,
  ROOM_LABELS,
  ROOM_ORDER,
} from '@/lib/shield-v2';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Session cleaner — RoomScan Bouclier',
  robots: { index: false, follow: false },
};

// =============================================================
// /s/[token] — LIEN MAGIQUE CLEANER (FLUX C, SANS LOGIN)
//
// Le token (uuid) EST l'autorisation. Selon la session :
//   · A_VENIR / EN_RETARD → parcours guidé (vidéo 120 s + photos
//     mode fantôme) ;
//   · CHECK-OUT → fantômes = photos du CHECK-IN lié (fallback
//     bibliothèque de référence) ;
//   · TERMINE → écran récapitulatif (déjà scellé) ;
//   · ANNULE → prévenu, lien mort.
// =============================================================

export default async function CleanerSessionPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const shieldSession = await db.session.findUnique({
    where: { publicToken: token },
    include: {
      property: {
        select: {
          id: true,
          name: true,
          city: true,
          shieldRooms: true,
          referencePhotos: true,
        },
      },
      checkInSession: { select: { id: true, photos: true } },
    },
  });
  if (!shieldSession) notFound();

  const property = shieldSession.property;
  const isCheckin = shieldSession.type === 'CHECKIN';
  const referencePhotos = (property.referencePhotos ?? {}) as Record<string, string>;

  // Zones = pièces cochées à l'onboarding (ordre de passage naturel).
  const roomKeys = (Array.isArray(property.shieldRooms)
    ? (property.shieldRooms as string[])
    : []
  ).slice().sort((a, b) => {
    const ia = ROOM_ORDER.indexOf(a);
    const ib = ROOM_ORDER.indexOf(b);
    return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
  });

  // Fantômes : CHECK-IN → bibliothèque verrouillée ;
  // CHECK-OUT → photos réelles du CHECK-IN lié (fallback bibliothèque).
  const checkinPhotos = (shieldSession.checkInSession?.photos ?? {}) as Record<string, string>;
  const zones: CleanerZone[] = roomKeys.map((key) => ({
    key,
    label: ROOM_LABELS[key] ?? key,
    ghostUrl: isCheckin
      ? referencePhotos[key]
        ? `/api/s/${token}/media/${referencePhotos[key]}`
        : undefined
      : checkinPhotos[key] ??
        (referencePhotos[key] ? `/api/s/${token}/media/${referencePhotos[key]}` : undefined),
  }));

  const guestName = shieldSession.guestName;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Barre de marque (identique au design system V2) */}
      <header className="bg-[#1e3a8a] px-4 py-3">
        <div className="mx-auto flex max-w-md items-center gap-2">
          <span
            aria-hidden="true"
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-white"
          >
            <ShieldCheck className="h-4.5 w-4.5 text-[#1e3a8a]" />
          </span>
          <div className="leading-tight">
            <p className="text-sm font-bold text-white">RoomScan</p>
            <p className="text-[8px] font-bold uppercase tracking-[0.28em] text-blue-200">
              Bouclier
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-md">
        {shieldSession.status === 'ANNULE' ? (
          <div className="px-4 pb-10 pt-8">
            <div className="rounded-xl border border-slate-200 bg-white p-6 text-center shadow-sm">
              <XCircle className="mx-auto h-10 w-10 text-slate-300" aria-hidden="true" />
              <h1 className="mt-3 text-lg font-extrabold text-slate-900">Session annulée</h1>
              <p className="mt-1 text-sm text-slate-500">
                Cette session a été annulée par l&apos;hôte. Aucune action nécessaire — vous pouvez
                fermer cette page.
              </p>
            </div>
          </div>
        ) : shieldSession.status === 'TERMINE' ? (
          <div className="px-4 pb-10 pt-6">
            <div className="rounded-xl border border-emerald-200 bg-white p-6 text-center shadow-sm">
              <span
                aria-hidden="true"
                className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100"
              >
                <ShieldCheck className="h-6 w-6 text-emerald-600" />
              </span>
              <h1 className="mt-3 text-lg font-extrabold text-slate-900">
                Session déjà terminée
              </h1>
              <p className="mt-1 text-sm text-slate-500">
                {isCheckin ? 'Le check-in' : 'Le check-out'} de {guestName} chez{' '}
                <strong>{property.name}</strong> a été scellé le{' '}
                {new Intl.DateTimeFormat('fr-FR', {
                  day: 'numeric',
                  month: 'long',
                  hour: '2-digit',
                  minute: '2-digit',
                }).format(shieldSession.completedAt ?? shieldSession.createdAt)}
                .
              </p>
              {shieldSession.videoHash ? (
                <p className="mt-3 break-all rounded-lg bg-slate-50 px-3 py-2 font-mono text-[10px] text-slate-500" dir="ltr">
                  <Lock className="mr-1 inline h-3 w-3" aria-hidden="true" />
                  SCELLÉ SHA-256 {shieldSession.videoHash.slice(0, 24)}…
                </p>
              ) : null}
            </div>

            {Object.keys((shieldSession.photos ?? {}) as Record<string, string>).length > 0 ? (
              <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
                <h2 className="mb-2 text-sm font-bold text-slate-900">Photos de la session</h2>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries((shieldSession.photos ?? {}) as Record<string, string>).map(
                    ([zone, url]) => (
                      <figure key={zone} className="overflow-hidden rounded-lg border border-slate-200">
                        { }
                        <img
                          src={url}
                          alt={`Photo ${ROOM_LABELS[zone] ?? APPLIANCE_LABELS[zone] ?? zone}`}
                          className="aspect-[4/3] w-full object-cover"
                          loading="lazy"
                        />
                        <figcaption className="truncate px-1.5 py-1 text-center text-[10px] font-semibold text-slate-500">
                          {ROOM_LABELS[zone] ?? zone}
                        </figcaption>
                      </figure>
                    ),
                  )}
                </div>
              </div>
            ) : null}
          </div>
        ) : (
          <CleanerFlow
            token={token}
            type={isCheckin ? 'CHECKIN' : 'CHECKOUT'}
            guestName={guestName}
            propertyName={property.name}
            city={property.city}
            zones={zones}
          />
        )}
      </main>

      <footer className="pb-[max(1rem,env(safe-area-inset-bottom))] pt-2">
        <p className="text-center text-[10px] text-slate-400">
          <Link href="/" className="hover:underline">
            Protégé par RoomScan Bouclier
          </Link>{' '}
          — l&apos;état des lieux certifié de vos locations
        </p>
      </footer>
    </div>
  );
}
