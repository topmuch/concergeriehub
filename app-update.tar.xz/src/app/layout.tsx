import type { Metadata } from "next";
import { Geist, Geist_Mono, Inter, Playfair_Display } from "next/font/google";
import { ThemeProvider } from "next-themes";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { GlobalErrorReporter } from "@/components/monitoring/global-error-reporter";
import { siteName, siteUrl } from "@/lib/site";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// DESIGN PREMIUM « LUXE TECH » — typographie signature :
//   • Playfair Display (serif) → titres display, touche luxe/hôtelier
//   • Inter (sans) → corps de texte, lisibilité maximale (SF Pro-like)
// Les deux sont exposés en variables CSS puis mappés dans globals.css
// (@theme : --font-serif / --font-sans) → classes font-serif & font-sans.
const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  style: ["normal", "italic"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  // metadataBase : résout les URLs relatives (og:image, canonical…)
  // sur TOUTES les routes — propage aux segments enfants.
  metadataBase: new URL(siteUrl),
  title: {
    default: `${siteName} — La conciergerie digitale des hôtes`,
    template: `%s | ${siteName}`,
  },
  description: "SaaS B2B pour hôtes Airbnb et gestionnaires de biens : Wi-Fi, guidebook, check-out, upselling et annuaire de prestataires via une seule plaque QR. Sans application.",
  applicationName: siteName,
  keywords: ["Conciergerie Hub", "conciergerie Airbnb", "QR codes", "hôtes", "location courte durée", "guidebook", "check-out", "prestataires", "property management"],
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: siteName,
  },
  icons: {
    icon: "/icon-512.png",
    apple: "/icon-512.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning className={`${geistSans.variable} ${geistMono.variable} ${playfair.variable} ${inter.variable}`}>
      <body className="antialiased bg-background text-foreground">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          {/* FIX-14 — monitoring d'erreurs client (invisible, 1 seul rendu racine) */}
          <GlobalErrorReporter />
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}