import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { hasEdlAccess } from '@/lib/edl-billing';
import { EdlConsole } from '@/components/inspection/dashboard/edl-console';

export const metadata: Metadata = {
  title: 'États des Lieux — RoomScan',
  description:
    'Module indépendant « État des Lieux » : créez, partagez et suivez vos états des lieux d’entrée et de sortie — générations illimitées, signature électronique et PDF.',
};

// Page DASHBOARD du module standalone « État des Lieux » (v4.97).
// Protection serveur : session NextAuth obligatoire (redirection vers
// l'accueil sinon) — même garde que les pages de l'espace hôte, mais
// en standalone (hors shell /airbnb) : le module vit à part du Hub.
//
// v4.107 — ENTITLEMENT : le dashboard est réservé
//   • aux abonnés EDL actifs (achat standalone 299 €/an OU
//     abonnement antérieur),
//   • aux comptes Hub (superadmin / propriétaire / équipe — module
//     inclus),
// tout autre compte connecté est renvoyé vers la page d'achat
// /edl/abonnement (offre 299 €/an via PayPal).
//
// v4.124 — CIRCUIT v2 (one-shot) : la 1re visite du dashboard
// redirige vers /payment/success (qui porte le CTA « Commencer
// l'onboarding » → /onboarding/wizard?step=1). Une fois le wizard
// complété (flag User.onboardingCompleted posé par
// /api/shield/onboarding), cette page n'est PLUS jamais montrée :
// l'utilisateur atterrit directement sur la console
// « Créer un nouveau séjour ». La page /payment/success détecte
// elle-même le flag et affiche « configuration déjà active ».
export default async function InspectionDashboardPage() {
  const session = await getServerSession(authOptions);
  const user = session?.user as
    | { id?: string; role?: string; name?: string | null; email?: string | null }
    | undefined;
  if (!session?.user || !user?.id) redirect('/');

  // Acheteur EDL sans abonnement valide ni compte Hub → page d'achat.
  if (!(await hasEdlAccess(user.id, user.role))) {
    redirect('/edl/abonnement');
  }

  // CIRCUIT v2 — porte d'entrée unique : tant que l'onboarding
  // n'a pas été complété, toute visite du dashboard est renvoyée
  // vers la page post-paiement (une seule fois de fait : le wizard
  // pose le flag). Les comptes sans ligne User correspondante
  // (cas théorique) passent directement.
  const me = await db.user
    .findUnique({
      where: { id: user.id },
      select: { onboardingCompleted: true },
    })
    .catch(() => null);
  if (me && !me.onboardingCompleted) {
    redirect('/payment/success');
  }

  return (
    <EdlConsole
      sessionUser={{
        id: user.id,
        name: user.name ?? null,
        email: user.email ?? null,
      }}
    />
  );
}
