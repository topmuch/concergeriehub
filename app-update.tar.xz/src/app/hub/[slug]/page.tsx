'use client';

import { Suspense } from 'react';
import { HubPageContent } from './hub-content';

export default function HubPage({ params }: { params: Promise<{ slug: string }> }) {
  return (
    <Suspense
      fallback={
        // Fond sombre immersif : cohérent avec l'écran d'accueil
        // « Luxe Tech » (photo villa) qui arrive juste après.
        <div className="min-h-screen bg-slate-950 flex items-center justify-center">
          <div className="flex flex-col items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center animate-pulse">
              <span className="text-xl">🗝️</span>
            </div>
            <p className="text-sm text-white/50 font-semibold">Chargement du Hub...</p>
          </div>
        </div>
      }
    >
      <HubPageContent params={params} />
    </Suspense>
  );
}
