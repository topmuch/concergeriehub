'use client';

import { use, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BadgePercent,
  BookOpen,
  CalendarCheck,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock4,
  Copy,
  Globe,
  ImagePlus,
  LifeBuoy,
  Loader2,
  Mail,
  MessageCircle,
  Mic,
  Moon,
  Package,
  PencilLine,
  Phone,
  Play,
  Plus,
  ShieldCheck,
  Square,
  Star,
  Sun,
  Trash2,
  TriangleAlert,
  Wrench,
  X,
} from 'lucide-react';
import { QRTNumericKeypad } from '@/components/qrtags';
// DESIGN PREMIUM « LUXE TECH » (phase 2) — fond animé + reveals +
// cartes d'accueil gradient + module Wi-Fi « carte de crédit ».
import { AnimatedMeshGradient } from '@/components/premium/animated-mesh-gradient';
import { Reveal } from '@/components/premium/reveal';
// REFONTE IMMERSIVE (Task 29) — page d'entrée du hub : fond photo
// villa + overlay, typographie Playfair, cartes glassmorphism.
import { HeroLanding } from '@/components/hub-premium/hero-landing';
import { WifiPremiumCard } from '@/components/hub-premium/wifi-credit-card';
import { BrandLogo } from '@/components/ui/brand-logo';
import { EmojiIcon } from '@/components/ui/emoji-icon';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Toaster } from '@/components/ui/sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
// v4.32 — onglets « Contact / Messages » du dialog Contacter l'hôte.
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
// v4.32 — toggle ACTIVER/DÉSACTIVER des prestataires (mode hôte).
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { formatDistance, formatEur } from '@/lib/b2b';
// FIX-VOCAL : lecture des audios via /api/uploads/voice (public/ n'est pas
// servi en standalone) + enregistrement compatible Safari/iOS (audio/mp4).
// v4.32 — voicePlaybackSrc privilégie la copie dataURL EN BASE (audio
// durable : les fichiers disque disparaissaient à chaque redéploiement).
import { voiceAudioSrc, voicePlaybackSrc, pickRecorderMime, extForMime } from '@/lib/voice-audio';
// BUG DASHBOARD→HUB — parité PWA : les modules remplis dans
// /airbnb/concierge (coffre-fort, SOS, bonnes adresses, guide des
// appareils) et l'Expérience Invité (guide visuel, vidéo bienvenue,
// late check-out, bouclier d'avis, kit de survie) partagent les
// mêmes parseurs tolérants.
import {
  accessCodeRows,
  geoDirectionsUrl,
  isLocalMediaUrl,
  isYouTubeUrl,
  SHOP_COMMISSION_RATE,
  spotCategoryMeta,
  type GuestAccessCodes,
  type GuestAppliance,
  type GuestEmergencyInfo,
  type GuestPremiumFeatures,
  type GuestShopItem,
  type GuestSpot,
  type GuestSurvivalItem,
  type GuestVisualStep,
} from '@/lib/concierge';
// RÉPONSE VOCALE HÔTE — bouton d'enregistrement (mode hôte) avec
// pré-écoute avant envoi (POST /api/airbnb/voice-reply).
import { VoiceReplyButton } from '@/components/airbnb/host/voice-reply-button';
// REFONTE SERVICES PREMIUM (V4.14) — le hub QR hérite de l'expérience
// « conciergerie de luxe » de la PWA (header serif, recherche, chips,
// carrousel populaires, panier flottant, checkout créneau, confettis).
import { TabServices } from '@/components/guest-app/tab-services';
import { ServiceCover } from '@/components/guest-app/service-visual';
import type { GuestServiceOffer } from '@/components/guest-app/types';
// v4.24 « HUB RÉEL » — photos curated des tuiles/modules de l'accueil
// invité (vérifiées visuellement, CDN OSS stable, CSP https: OK).
import { HUB_ARRIVAL_PHOTOS, HUB_VISUALS } from '@/lib/hub-visuals';
// v4.31 « PHOTOS DE MON HUB » + « POUR VOUS » — mapping des photos perso
// de l'hôte (clés allowlist, redimensionnement client, parse tolérant).
import {
  fileToHubPhotoDataUrl,
  HUB_PHOTO_SLOTS,
  MAX_HUB_PHOTO_CHARS,
  type HubPhotoKey,
  type HubPhotoMap,
} from '@/lib/hub-photos';
// v4.33 « TRADUCTION INSTANTANÉE IA » — i18n du Hub invité : détection
// de la langue du smartphone, dictionnaire statique 5 langues (FR source)
// + traduction IA dynamique (POST /api/public/translate, cache local).
import {
  HubLangContext,
  detectLang,
  getStoredLang,
  storeLang,
  translateBatchAi,
  translateText,
  useHubLang,
  HUB_LANGS,
  type HubLang,
} from '@/lib/hub-i18n';

// =============================================================
// ÉTAPE 5 — LE HUB QR CODE (expérience de scan, ultra-mobile-first)
//
// Écran d'accueil : 2 cartes principales
//   👤 MODE INVITÉ (libre) : Wi-Fi (copie MDP), Guidebook,
//      Commander un service, Signaler un problème / Contacter l'hôte
//   🔐 MODE HÔTE (PIN 4 chiffres via QRTNumericKeypad) :
//      grille de gestion rapide — Modifier le Wi-Fi, Réclamations
//      en attente, Gérer les prestataires.
//
// Design QRTags : fond dégradé subtil slate, cartes blanches
// border-slate-200 rounded-xl p-4 shadow-sm, emojis 24–32 px.
// PHASE 2 — refonte visuelle premium « LUXE TECH » : mesh gradient
// animé, glassmorphism avancé (.glass), chorégraphies framer-motion,
// carte Wi-Fi façon « carte de crédit » à mot de passe grattable.
// La LOGIQUE (auth PIN, appels API, états) reste STRICTEMENT inchangée.
// =============================================================

/** Easing expo partagé (même signature que <Reveal/>). */
const EASE_EXPO = [0.16, 1, 0.3, 1] as const;

interface GuestService {
  id: string;
  name: string;
  emoji: string;
  categoryLabel: string;
  description: string;
  priceLabel: string;
  /** REFONTE SERVICES PREMIUM (V4.14) — parité PWA : catalogue fin. */
  unitPrice: number | null;
  /** REFONTE SERVICES PREMIUM (V4.22) — démonstration sociale. */
  ratingAvg: number;
  totalReviews: number;
  /** v4.23 « hub réel » — photo de couverture (1re offre photographiée). */
  imageUrl?: string | null;
  offers: GuestServiceOffer[];
}

interface HubPayload {
  active: boolean;
  property: {
    id: string;
    name: string;
    propertyType: string;
    propertyTypeLabel: string;
    propertyTypeEmoji: string;
    address: string | null;
    hasPin: boolean;
    /** v4.31 — photos personnalisées par l'hôte ({ [cardKey]: dataURL }). */
    hubPhotos: HubPhotoMap;
  };
  ownerName: string | null;
  /** v4.31 « POUR VOUS » — moment du séjour dérivé côté serveur de la
   *  réservation en cours (aucune donnée personnelle : un simple enum).
   *  null = pas de réservation en cours → repli sur l'heure locale. */
  stayMoment: 'arrival' | 'midstay' | 'departure' | null;
  /** v4.33 « COMPTE À REBOURS CHECK-OUT » — jour du départ (J) + date de
   *  fin du séjour en cours (neutre : l'heure de départ est publique). */
  stay: { isCheckoutDay: boolean; checkOut: string | null };
  guest: {
    wifi: { networkName: string; password: string; securityType: string } | null;
    guidebookSlug: string | null;
    accessCodes: GuestAccessCodes | null;
    localSpots: GuestSpot[];
    visualGuide: GuestVisualStep[];
    emergency: GuestEmergencyInfo | null;
    // BUG DASHBOARD→HUB — parité PWA complète : guide des appareils,
    // modules premium (vidéo, late check-out, bouclier d'avis) et kit
    // de survie servis par /api/public/hub/[slug].
    appliances: GuestAppliance[];
    premiumFeatures: GuestPremiumFeatures | null;
    /** v4.33 « SHOP THE STAY » — catalogue de la boutique (serveur). */
    shopItems: GuestShopItem[];
    survivalKitItems: GuestSurvivalItem[];
    services: GuestService[];
    contact: { name: string; phone: string | null; email: string | null };
  };
}

interface HostProvider {
  id: string;
  name: string;
  emoji: string;
  categoryLabel: string;
  distanceKm: number;
  audience: string;
  priceLabel: string;
  /** v4.32 — false = désactivé par l'hôte (invisible côté invités). */
  enabled: boolean;
}

interface HostWrittenComplaint {
  id: string;
  category: string;
  categoryLabel: string;
  description: string;
  photos: string[];
  isUrgent: boolean;
  guestName: string | null;
  /** v4.32 — notification déjà vue (badge rouge éteint). */
  isRead?: boolean;
  createdAt: string;
}

interface HostGuidebook {
  qrCodeId: string | null;
  title: string;
  sections: string[];
}

/** Commande ServiceOrder sérialisée côté API /orders (montant TOTAL,
 *  jamais le split commission/hôte). */
interface HostOrder {
  id: string;
  status: string;
  statusLabel: string;
  statusBadge: string;
  statusEmoji: string;
  totalEur: string;
  itemsSummary: string;
  providerName: string;
  providerEmoji: string;
  guestName: string;
  createdAt: string;
}

interface HostData {
  wifi: {
    qrCodeId: string;
    networkName: string;
    password: string;
    securityType: string;
  } | null;
  unreadMessages: {
    id: string;
    senderName: string;
    audioUrl: string;
    /** v4.32 — copie dataURL en base (lecture durable). */
    audioData?: string | null;
    durationSec: number;
    createdAt: string;
  }[];
  complaints: HostWrittenComplaint[];
  openComplaints: number;
  /** v4.32 — réclamations OPEN non lues (badge rouge uniquement). */
  unreadComplaints?: number;
  pendingRequests: number;
  guidebook: HostGuidebook;
  providers: HostProvider[];
}

type HubView = 'loading' | 'error' | 'home' | 'guest' | 'host';

export function HubPageContent({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = use(params);

  const [view, setView] = useState<HubView>('loading');
  const [payload, setPayload] = useState<HubPayload | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [retryTick, setRetryTick] = useState(0);

  // Mode Hôte
  const [pinModal, setPinModal] = useState(false);
  const [pinError, setPinError] = useState('');
  const [pinLoading, setPinLoading] = useState(false);
  const [keypadKey, setKeypadKey] = useState(0); // remonte le clavier après un échec
  const [verifiedPin, setVerifiedPin] = useState('');
  const [hostData, setHostData] = useState<HostData | null>(null);

  // ----- THÈME DU HUB — bascule sombre / clair (demande client) -----
  // Le <html> peut porter la classe .dark (thème par défaut de l'app /
  // préférence système). Or les portails (overlay Services, dialogs
  // Radix, toasts) vivent au niveau <body> : ils héritent du thème de
  // <html>. Le hub gère donc SON propre thème : état local (clair par
  // défaut), persisté en localStorage('hub-theme') et appliqué sur
  // <html> via la classe .dark. Au démontage, la classe d'origine de
  // l'app est restituée (la PWA garde son thème sombre par défaut).
  const [hubTheme, setHubTheme] = useState<'light' | 'dark'>(() => {
    // État initial : préférence mémorisée du visiteur (clair par
    // défaut). Lu dès le premier rendu client — la vue invité n'étant
    // JAMAIS rendue côté serveur (elle apparaît après le fetch), il
    // ne peut pas y avoir de mismatch d'hydratation.
    if (typeof window === 'undefined') return 'light';
    try {
      const saved = window.localStorage.getItem('hub-theme');
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // Stockage indisponible (navigation privée stricte) → défaut clair.
    }
    return 'light';
  });
  const originalThemeRef = useRef<'light' | 'dark'>('light');

  // Montage : mémorise le thème d'origine de l'app pour le restituer
  // au démontage (écriture de ref uniquement, pas de setState).
  useEffect(() => {
    const root = document.documentElement;
    originalThemeRef.current = root.classList.contains('dark') ? 'dark' : 'light';
  }, []);

  // Applique le thème du hub sur <html> (portails et toasts inclus).
  useEffect(() => {
    const root = document.documentElement;
    if (hubTheme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
  }, [hubTheme]);

  // Démontage : restitue le thème d'origine de l'app.
  useEffect(() => {
    return () => {
      const root = document.documentElement;
      if (originalThemeRef.current === 'dark') root.classList.add('dark');
      else root.classList.remove('dark');
    };
  }, []);

  /** Bascule sombre ↔ clair + persistance localStorage. */
  const toggleHubTheme = useCallback(() => {
    setHubTheme((t) => {
      const next = t === 'dark' ? 'light' : 'dark';
      try {
        window.localStorage.setItem('hub-theme', next);
      } catch {
        // Stockage indisponible → la bascule fonctionne quand même.
      }
      return next;
    });
  }, []);

  // ----- Chargement du hub (fonction async déclarée DANS l'effet) -----
  useEffect(() => {
    async function run() {
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}`);
        const json = await res.json();
        if (res.status === 410) {
          setErrorMsg(json.message || 'Cette plaque QR a été désactivée.');
          setView('error');
          return;
        }
        if (!res.ok) {
          setErrorMsg(json.message || 'Ce hub est introuvable.');
          setView('error');
          return;
        }
        setPayload(json as HubPayload);
        setView('home');
      } catch {
        setErrorMsg('Impossible de charger le hub. Vérifiez votre connexion.');
        setView('error');
      }
    }
    run();
  }, [slug, retryTick]);

  /** Bouton Réessayer : retour au chargement + relance de l'effet. */
  const retryLoad = useCallback(() => {
    setView('loading');
    setRetryTick((t) => t + 1);
  }, []);

  /** v4.31 « PHOTOS DE MON HUB » — fusionne les photos sauvegardées par
   *  l'hôte dans le payload local : le passage en vue invité (ou le
   *  retour à l'accueil) montre immédiatement les nouvelles photos,
   *  sans rechargement. */
  const handleHubPhotosSaved = useCallback((map: HubPhotoMap) => {
    setPayload((p) =>
      p ? { ...p, property: { ...p.property, hubPhotos: map } } : p,
    );
  }, []);

  // ----- Vérification PIN + chargement des données hôte -----
  const verifyPin = useCallback(
    async (pin: string) => {
      setPinLoading(true);
      setPinError('');
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        const json = await res.json();
        if (!res.ok) {
          setPinError(json.error || 'PIN incorrect');
          setPinLoading(false);
          setKeypadKey((k) => k + 1); // clavier neuf pour la prochaine tentative
          return;
        }
        const hostRes = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/host`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        if (!hostRes.ok) {
          setPinError('Impossible de charger les données hôte.');
          setPinLoading(false);
          return;
        }
        setHostData((await hostRes.json()) as HostData);
        setVerifiedPin(pin);
        setPinModal(false);
        setPinLoading(false);
        setView('host');
      } catch {
        setPinError('Erreur réseau. Réessayez.');
        setPinLoading(false);
      }
    },
    [slug],
  );

  // ----- Copie presse-papier -----
  const copy = useCallback(async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} copié !`, { description: text });
    } catch {
      toast.error('Copie impossible sur ce navigateur.');
    }
  }, []);

  return (
    // `isolate` : crée un stacking context local pour que les fonds
    // premium fixés en -z-10 (mesh animé) restent AU-DESSUS du dégradé
    // de page mais SOUS tout le contenu.
    <div className="min-h-screen flex flex-col isolate bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-950 dark:to-slate-900">
      <Toaster position="top-center" richColors />

      {view === 'loading' && <LoadingScreen />}
      {view === 'error' && <ErrorScreen message={errorMsg} onRetry={retryLoad} />}

      {view === 'home' && payload && (
        <HomeView
          payload={payload}
          onGuestClick={() => setView('guest')}
          onHostClick={() => {
            setPinError('');
            setPinModal(true);
          }}
        />
      )}

      {view === 'guest' && payload && (
        <GuestView
          payload={payload}
          slug={slug}
          onBack={() => setView('home')}
          copy={copy}
          theme={hubTheme}
          onToggleTheme={toggleHubTheme}
        />
      )}

      {view === 'host' && payload && (
        <HostView
          payload={payload}
          hostData={hostData}
          slug={slug}
          pin={verifiedPin}
          onBack={() => setView('home')}
          onHostRefresh={(d) => setHostData(d)}
          onPinChanged={(p) => setVerifiedPin(p)}
          onHubPhotosSaved={handleHubPhotosSaved}
        />
      )}

      {/* ----- Modale PIN Mode Hôte ----- */}
      <Dialog open={pinModal} onOpenChange={(open) => !open && !pinLoading && setPinModal(false)}>
        <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl p-6 [&>button]:hidden">
          <DialogHeader className="items-center text-center">
            <span className="mx-auto" aria-hidden="true">
              <EmojiIcon emoji="🔐" size="lg" variant="dark" />
            </span>
            <DialogTitle className="text-lg font-bold text-slate-900 text-center">Mode Hôte</DialogTitle>
            <DialogDescription className="text-sm text-slate-600 text-center">
              Saisissez votre code à 4 chiffres pour accéder à la gestion du logement.
            </DialogDescription>
          </DialogHeader>

          {pinLoading ? (
            <div className="flex flex-col items-center gap-3 py-8" aria-busy="true">
              <Loader2 className="h-8 w-8 animate-spin text-emerald-600" aria-hidden="true" />
              <p className="text-sm text-slate-500">Vérification du code…</p>
            </div>
          ) : (
            <div className="mt-2">
              <QRTNumericKeypad key={keypadKey} onComplete={verifyPin} />
              {pinError && (
                <p role="alert" className="mt-4 text-center text-sm font-semibold text-red-600">
                  {pinError}
                </p>
              )}
              <Button
                type="button"
                variant="outline"
                className="mt-4 w-full h-11 border-slate-300 text-slate-600"
                onClick={() => setPinModal(false)}
              >
                Annuler
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =============================================================
// Écran de chargement
// =============================================================
function LoadingScreen() {
  return (
    <div className="flex-1 w-full max-w-lg mx-auto px-4 py-10 space-y-5" aria-busy="true" aria-label="Chargement du hub">
      {/* Fond sombre : cohérent avec l'accueil immersif qui suit
          (évite le flash blanc avant le hero photo). */}
      <div aria-hidden="true" className="fixed inset-0 -z-10 bg-slate-950" />
      <div className="flex justify-center">
        <BrandLogo variant="light" size="sm" />
      </div>
      <Skeleton className="h-32 w-full rounded-xl bg-white/10" />
      <Skeleton className="h-24 w-full rounded-xl bg-white/10" />
      <Skeleton className="h-24 w-full rounded-xl bg-white/10" />
    </div>
  );
}

// =============================================================
// Écran d'erreur (QR introuvable / inactif / réseau)
// =============================================================
function ErrorScreen({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex-1 w-full max-w-lg mx-auto px-4 py-16 flex flex-col items-center justify-center text-center">
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-8 w-full">
        <span className="text-5xl" aria-hidden="true">🔌</span>
        <h1 className="mt-4 text-xl font-bold text-slate-900">Hub indisponible</h1>
        <p className="mt-2 text-sm text-slate-600 leading-relaxed">{message}</p>
        <Button
          type="button"
          onClick={onRetry}
          className="mt-6 h-11 px-6 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
        >
          Réessayer
        </Button>
        <p className="mt-6 text-xs text-slate-400">
          Propulsé par 🗝️ <span className="font-semibold text-slate-500">Conciergerie Hub</span>
        </p>
      </div>
    </div>
  );
}

// =============================================================
// ÉCRAN D'ACCUEIL — REFONTE IMMERSIVE « LUXE TECH » (Task 29)
// Le rendu complet (fond photo villa + overlay, typographie
// Playfair, cartes glassmorphism, chorégraphie framer-motion)
// vit dans <HeroLanding/> ; toute la logique (navigation,
// ouverture du PIN hôte) reste ici, inchangée.
// =============================================================
function HomeView({
  payload,
  onGuestClick,
  onHostClick,
}: {
  payload: HubPayload;
  onGuestClick: () => void;
  onHostClick: () => void;
}) {
  const { property, ownerName } = payload;
  return (
    <HeroLanding
      propertyName={property.name}
      propertyTypeEmoji={property.propertyTypeEmoji}
      propertyTypeLabel={property.propertyTypeLabel}
      ownerName={ownerName}
      onGuestClick={onGuestClick}
      onHostClick={onHostClick}
    />
  );
}

// =============================================================
// MODE INVITÉ — « WALLET DE CARTES PREMIUM » (Task 30, itération 3)
// Retour client : « que tous les modules s'affichent comme le carré
// du module Wi-Fi ». La grille de petites tuiles disparaît : chaque
// module devient une CARTE PLEINE LARGEUR reprenant EXACTEMENT
// l'anatomie de la carte Wi-Fi (WifiPremiumCard) :
//   • carte blanche dégradé teinté (rounded-3xl, ombre douce)
//   • puce EMV colorée en haut à gauche + emoji filigrane géant
//   • eyebrow uppercase tracking-[0.25em] coloré par ton sémantique
//   • titre en font-serif (display-title) + aperçu inline (chips)
//   • ZÉRO animation framer-motion — transitions CSS discrètes.
//   • Thème CLAIR, 7 tons (émeraude, ambre, rose, violet, teal,
//     orange, rouge) — la couleur porte l'identité du module.
// itération 4 — bouton ☀️/🌙 dans le hero : bascule sombre/clair
// mémorisée par visiteur (localStorage 'hub-theme') ; la classe .dark
// de <html> pilote fond, cartes, dialogs et portails.
// Organisation : 2 flagship pleine largeur (Wi-Fi, Services) puis
// 3 sections « Votre logement » / « Pendant votre séjour » /
// « Besoin d'aide ? » — 1 colonne mobile, 2 colonnes sm+.
// Toute la LOGIQUE métier (états, API, portails, dialogs existants)
// reste STRICTEMENT identique.
// =============================================================

type TileTone = 'emerald' | 'amber' | 'rose' | 'violet' | 'teal' | 'orange' | 'red';

/** Palettes CLAIRES « carte bancaire » — un ton par module. La couleur
 * vit dans : la bordure teintée, le dégradé de fond, la puce EMV,
 * l'eyebrow et la tuile d'icône des dialogs — comme sur la carte Wi-Fi. */
const CARD_TONES: Record<
  TileTone,
  { border: string; wash: string; chip: string; eyebrow: string; iconTile: string }
> = {
  emerald: {
    border:
      'border-emerald-200/80 hover:border-emerald-300 dark:border-emerald-500/25 dark:hover:border-emerald-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-emerald-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/50',
    chip: 'border-emerald-700/40 bg-gradient-to-br from-emerald-200 via-emerald-400 to-emerald-600',
    eyebrow: 'text-emerald-500 dark:text-emerald-300',
    iconTile:
      'bg-gradient-to-br from-emerald-100 to-emerald-300 shadow-[0_10px_26px_-10px_rgba(16,185,129,0.6)]',
  },
  amber: {
    border:
      'border-amber-200/80 hover:border-amber-300 dark:border-amber-500/25 dark:hover:border-amber-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-amber-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-amber-950/50',
    chip: 'border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600',
    eyebrow: 'text-amber-500 dark:text-amber-300',
    iconTile:
      'bg-gradient-to-br from-amber-100 to-amber-300 shadow-[0_10px_26px_-10px_rgba(245,158,11,0.6)]',
  },
  rose: {
    border:
      'border-rose-200/80 hover:border-rose-300 dark:border-rose-500/25 dark:hover:border-rose-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-rose-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-rose-950/50',
    chip: 'border-rose-700/40 bg-gradient-to-br from-rose-200 via-rose-400 to-rose-600',
    eyebrow: 'text-rose-500 dark:text-rose-300',
    iconTile:
      'bg-gradient-to-br from-rose-100 to-rose-300 shadow-[0_10px_26px_-10px_rgba(244,63,94,0.55)]',
  },
  violet: {
    border:
      'border-violet-200/80 hover:border-violet-300 dark:border-violet-500/25 dark:hover:border-violet-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-violet-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-violet-950/50',
    chip: 'border-violet-700/40 bg-gradient-to-br from-violet-200 via-violet-400 to-violet-600',
    eyebrow: 'text-violet-500 dark:text-violet-300',
    iconTile:
      'bg-gradient-to-br from-violet-100 to-violet-300 shadow-[0_10px_26px_-10px_rgba(139,92,246,0.55)]',
  },
  teal: {
    border:
      'border-teal-200/80 hover:border-teal-300 dark:border-teal-500/25 dark:hover:border-teal-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-teal-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-teal-950/50',
    chip: 'border-teal-700/40 bg-gradient-to-br from-teal-200 via-teal-400 to-teal-600',
    eyebrow: 'text-teal-500 dark:text-teal-300',
    iconTile:
      'bg-gradient-to-br from-teal-100 to-teal-300 shadow-[0_10px_26px_-10px_rgba(20,184,166,0.6)]',
  },
  orange: {
    border:
      'border-orange-200/80 hover:border-orange-300 dark:border-orange-500/25 dark:hover:border-orange-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-orange-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-orange-950/50',
    chip: 'border-orange-700/40 bg-gradient-to-br from-orange-200 via-orange-400 to-orange-600',
    eyebrow: 'text-orange-500 dark:text-orange-300',
    iconTile:
      'bg-gradient-to-br from-orange-100 to-orange-300 shadow-[0_10px_26px_-10px_rgba(249,115,22,0.6)]',
  },
  red: {
    border:
      'border-red-200/80 hover:border-red-300 dark:border-red-500/25 dark:hover:border-red-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-red-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-red-950/50',
    chip: 'border-red-700/40 bg-gradient-to-br from-red-200 via-red-400 to-red-600',
    eyebrow: 'text-red-500 dark:text-red-300',
    iconTile:
      'bg-gradient-to-br from-red-100 to-red-300 shadow-[0_10px_26px_-10px_rgba(239,68,68,0.55)]',
  },
};

/** Carte module — v4.28 « PHOTO PLEINE CARTE » (Option A, retour client :
 * « toutes les cards comme le QR code, une GRANDE image ») :
 *   • la VRAIE photo remplit TOUTE la carte (object-cover, comme le héro) ;
 *   • voile dégradé noir + textes blancs posés en bas (eyebrow, titre serif,
 *     sous-titre, chips d'aperçu) — lisibilité garantie ;
 *   • puce EMV translucide en haut à gauche (identité « carte de crédit »
 *     conservée) + flèche blanche en haut à droite ;
 *   • onError ou photo absente → retour à l'anatomie « carte de crédit »
 *     historique (ton sémantique + filigrane emoji) — jamais de carte vide.
 * STATIQUE (demande client : zéro animation framer-motion) — uniquement
 * des transitions CSS discrètes (zoom photo au survol). */
function ModuleCard({
  emoji,
  tone,
  eyebrow,
  title,
  subtitle,
  onClick,
  disabled,
  imageUrl,
  children,
  urgentLabel,
}: {
  emoji: string;
  tone: TileTone;
  /** Petit libellé uppercase au-dessus du titre (ex. « Trousseau numérique »). */
  eyebrow: string;
  title: string;
  subtitle?: string;
  onClick?: () => void;
  disabled?: boolean;
  /** Vraie photo PLEINE CARTE (v4.28) — optionnelle, décorative (alt="") ;
   *  le fallback « carte de crédit » filigrane emoji reste le repli. */
  imageUrl?: string | null;
  children?: React.ReactNode;
  /** v4.32 « SIGNAUX DU SÉJOUR » — clignotement rouge d'urgence : pill
   *  rouge + anneau pulsé (CSS .hub-alert-blink). Ex. « Départ demain »
   *  (veille du départ) ou « Ce soir 20 h » (bouclier d'avis). */
  urgentLabel?: string;
}) {
  const t = CARD_TONES[tone];
  const interactive = !!onClick && !disabled;
  const [photoFailed, setPhotoFailed] = useState(false);
  const showPhoto = !!imageUrl && !photoFailed;

  // ── v4.33 « TRADUCTION INSTANTANÉE IA » — libellés traduits ──
  // Dictionnaire statique d'abord (0 requête), IA ensuite pour les
  // textes libres (sous-titres interpolés, contenus personnalisés hôte).
  // Le FR reste la source et le repli universel — jamais de carte vide.
  const { lang } = useHubLang();
  const [ai, setAi] = useState<Record<string, string>>({});
  useEffect(() => {
    if (lang === 'fr') return;
    const pending = [title, subtitle, eyebrow, urgentLabel].filter(
      (s): s is string => !!s && translateText(s, lang) === s && !ai[s],
    );
    if (pending.length === 0) return;
    let alive = true;
    void translateBatchAi(pending, lang).then((tr) => {
      if (alive && Object.keys(tr).length > 0) setAi((prev) => ({ ...prev, ...tr }));
    });
    return () => {
      alive = false;
    };
  }, [lang, title, subtitle, eyebrow, urgentLabel]);
  const T = (s: string) => {
    if (lang === 'fr') return s;
    const st = translateText(s, lang);
    return st !== s ? st : (ai[s] ?? s);
  };

  // ── FALLBACK (photo absente ou échouée) — carte de crédit historique ──
  if (!showPhoto) {
    return (
      <button
        type="button"
        onClick={interactive ? onClick : undefined}
        disabled={!interactive}
        aria-label={`${T(title)}${subtitle ? ` — ${T(subtitle)}` : ''}`}
        className={cn(
          'group relative flex h-full min-h-44 w-full flex-col overflow-hidden rounded-3xl border p-5 text-left text-slate-900 dark:text-slate-100',
          'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.28)] transition-[border-color,box-shadow] duration-300',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/25',
          urgentLabel && 'hub-alert-blink border-red-400/70',
          t.border,
          t.wash,
          interactive
            ? 'cursor-pointer hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.4)]'
            : 'cursor-default opacity-60 saturate-[0.4]',
        )}
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-2 -top-6 select-none text-[96px] leading-none opacity-[0.09]"
        >
          {emoji}
        </span>

        {/* Rangée 1 : puce EMV colorée + flèche */}
        <span className="relative flex items-start justify-between">
          <span
            aria-hidden="true"
            className={cn('relative mt-0.5 block h-8 w-11 rounded-md border shadow-inner', t.chip)}
          >
            <span className="absolute inset-x-0 top-1/2 h-px bg-black/15" />
            <span className="absolute inset-y-0 left-1/2 w-px bg-black/15" />
          </span>
          {interactive && (
            <ArrowRight
              aria-hidden="true"
              className="h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 group-hover:translate-x-1"
            />
          )}
        </span>

        {/* Eyebrow + titre serif (langage carte Wi-Fi) */}
        <span className={cn('relative mt-3.5 text-[10px] font-bold uppercase tracking-[0.25em]', t.eyebrow)}>
          <span aria-hidden="true" className="mr-1.5">{emoji}</span>
          {T(eyebrow)}
        </span>
        <span className="display-title font-serif! relative mt-0.5 text-xl font-bold leading-tight text-slate-900 dark:text-white">
          {T(title)}
        </span>
        {subtitle && (
          <span className="relative mt-1 line-clamp-2 text-xs leading-snug text-slate-500 dark:text-slate-400">{T(subtitle)}</span>
        )}

        {/* Aperçu inline optionnel (chips de contenu) */}
        {children != null && <span className="relative mt-3.5 block">{children}</span>}
      </button>
    );
  }

  // ── v4.28 « PHOTO PLEINE CARTE » — toute la carte est une photo ──
  return (
    <button
      type="button"
      onClick={interactive ? onClick : undefined}
      disabled={!interactive}
      aria-label={`${T(title)}${subtitle ? ` — ${T(subtitle)}` : ''}`}
      className={cn(
        'group relative flex h-44 w-full flex-col justify-between overflow-hidden rounded-3xl border border-black/10 text-left sm:h-52',
        'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.45)] transition-[border-color,box-shadow] duration-300',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80',
        urgentLabel && 'hub-alert-blink border-red-400/70',
        interactive
          ? 'cursor-pointer hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.6)]'
          : 'cursor-default opacity-60 saturate-[0.5]',
      )}
    >
      <img
        src={imageUrl ?? undefined}
        alt=""
        loading="lazy"
        decoding="async"
        className="hub-kenburns absolute inset-0 h-full w-full object-cover"
        onError={() => setPhotoFailed(true)}
      />
      {/* Voile dégradé — lisibilité du texte blanc en bas de la photo */}
      <span
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/15"
      />

      {/* v4.32 — pill rouge d'urgence centrée en haut (clignotement). */}
      {urgentLabel && (
        <span className="absolute left-1/2 top-3 z-10 -translate-x-1/2 inline-flex items-center gap-1 rounded-full bg-red-600 px-3 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-white shadow-[0_8px_22px_-6px_rgba(239,68,68,0.75)]">
          {T(urgentLabel)}
        </span>
      )}

      {/* Rangée 1 : puce EMV translucide (identité carte) + flèche blanche */}
      <span className="relative flex items-start justify-between p-4">
        <span
          aria-hidden="true"
          className="relative mt-0.5 block h-8 w-11 rounded-md border border-white/40 bg-white/25 shadow-inner backdrop-blur-sm"
        >
          <span className="absolute inset-x-0 top-1/2 h-px bg-white/50" />
          <span className="absolute inset-y-0 left-1/2 w-px bg-white/50" />
        </span>
        {interactive && (
          <ArrowRight
            aria-hidden="true"
            className="h-5 w-5 shrink-0 text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:translate-x-1"
          />
        )}
      </span>

      {/* Eyebrow + titre serif + sous-titre + chips — blancs sur la photo */}
      <span className="relative flex flex-col p-4 pt-0">
        <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/85 drop-shadow-sm">
          <span aria-hidden="true" className="mr-1.5">{emoji}</span>
          {T(eyebrow)}
        </span>
        <span className="display-title font-serif! mt-0.5 text-xl font-bold leading-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.55)]">
          {T(title)}
        </span>
        {subtitle && (
          <span className="mt-1 line-clamp-2 text-xs leading-snug text-white/85 drop-shadow-sm">{T(subtitle)}</span>
        )}

        {/* Aperçu inline optionnel (chips de contenu, verre blanc) */}
        {children != null && <span className="mt-3 block">{children}</span>}
      </span>
    </button>
  );
}

/** Chip d'aperçu inline dans une ModuleCard (non cliquable, purement
 * informative — le contenu réel reste dans les dialogs). */
function PreviewChip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1 truncate rounded-full border border-slate-200/90 bg-white/85 px-2.5 py-1 text-[11px] font-semibold text-slate-600 shadow-sm dark:border-white/10 dark:bg-white/10 dark:text-slate-200">
      {children}
    </span>
  );
}

/** Séparateur de section (lignes dégradées + libellé tracking). */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div aria-hidden="true" className="mt-7 mb-4 flex items-center gap-3">
      <span className="h-px flex-1 bg-gradient-to-r from-transparent to-slate-300 dark:to-white/15" />
      <span className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-slate-400 dark:text-slate-500">
        {children}
      </span>
      <span className="h-px flex-1 bg-gradient-to-l from-transparent to-slate-300 dark:to-white/15" />
    </div>
  );
}

// =============================================================
// v4.33 — LES 4 NOUVELLES FONCTIONNALITÉS CLIENT
//   🌐 LangSwitcher            (traduction instantanée IA)
//   🕦 CheckoutCountdownBanner (compte à rebours check-out automatisé)
//   🚨 SosAlertCard            (SOS Logement — urgence en 1 clic)
//   🛍️ ShopCard               (Shop the Stay — affiliation hôte)
// Tous les libellés passent par useHubLang() : dictionnaire statique
// (0 requête) puis traduction IA dynamique ; le FR reste le repli.
// =============================================================

/** 🌐 Sélecteur de langue (drapeaux) du Hub invité — auto-détecté du
 *  smartphone au 1er scan, choix mémorisé par hub. La liste s'ouvre
 *  INLINE dans le hero (pas de portal : le hero clippe les débords). */
function LangSwitcher({
  lang,
  onChange,
  className,
}: {
  lang: HubLang;
  onChange: (l: HubLang) => void;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const current = HUB_LANGS.find((l) => l.code === lang) ?? HUB_LANGS[0];
  return (
    <span className={cn('relative', className)}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Choisir la langue"
        aria-expanded={open}
        title="Language / Langue"
        className="h-11 min-w-11 inline-flex items-center justify-center gap-1 rounded-xl border border-white/40 bg-white/85 px-2 text-sm font-semibold text-slate-800 shadow-sm backdrop-blur-md transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
      >
        <Globe className="h-4 w-4" aria-hidden="true" />
        <span aria-hidden="true">{current.flag}</span>
      </button>
      {open && (
        <span className="absolute right-0 top-[52px] z-20 flex items-center gap-1 rounded-2xl border border-white/40 bg-white/95 p-1.5 shadow-[0_14px_34px_-14px_rgba(15,23,42,0.5)] backdrop-blur-md">
          {HUB_LANGS.map((l) => (
            <button
              key={l.code}
              type="button"
              onClick={() => {
                onChange(l.code);
                setOpen(false);
              }}
              aria-label={l.label}
              title={l.label}
              aria-pressed={l.code === lang}
              className={cn(
                'inline-flex h-9 w-9 items-center justify-center rounded-xl text-lg transition-colors hover:bg-slate-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/30',
                l.code === lang && 'bg-slate-900/10 ring-1 ring-slate-900/20',
              )}
            >
              <span aria-hidden="true">{l.flag}</span>
            </button>
          ))}
        </span>
      )}
    </span>
  );
}

/** 🕦 « COMPTE À REBOURS CHECK-OUT » — jour du départ uniquement :
 *  « Votre départ est prévu à 11 h. Besoin de plus de temps ? Prolongez
 *  jusqu'à 14 h pour 25 € » (meilleur moment pour vendre un late
 *  check-out). Compte à rebours live + CTA = demande de départ tardif
 *  (POST /late-checkout — le serveur vérifie le module). Le CTA disparaît
 *  après 14 h (message de remerciement). Zéro framer-motion. */
function CheckoutCountdownBanner({
  slug,
  enabled,
  price,
}: {
  slug: string;
  /** Late check-out activé par l'hôte (sinon le CTA est masqué). */
  enabled: boolean;
  price?: number;
}) {
  const { t } = useHubLang();
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1_000);
    return () => clearInterval(id);
  }, []);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const d = new Date(now);
  const deadline = new Date(d);
  deadline.setHours(11, 0, 0, 0);
  const lateUntil = new Date(d);
  lateUntil.setHours(14, 0, 0, 0);
  const before = now < deadline.getTime();
  const during = !before && now < lateUntil.getTime();
  const over = !before && !during;

  const remaining = Math.max(0, deadline.getTime() - now);
  const hh = Math.floor(remaining / 3_600_000);
  const mm = Math.floor((remaining % 3_600_000) / 60_000);
  const ss = Math.floor((remaining % 60_000) / 1_000);
  const pad = (n: number) => String(n).padStart(2, '0');

  const request = async () => {
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/late-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      toast.success(data.message || 'Demande envoyée — votre hôte vous confirme rapidement.');
      setSent(true);
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Demande impossible. Réessayez dans un instant.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div
      role="status"
      className="rounded-3xl bg-gradient-to-r from-rose-600 via-red-500 to-amber-500 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(190,18,60,0.55)]"
    >
      <div className="rounded-[22px] bg-white/95 p-5 backdrop-blur-sm dark:bg-slate-900/95">
        <p className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-red-600 dark:text-red-400">
          <span aria-hidden="true" className="animate-pulse">
            ⏰
          </span>
          {t('Jour du départ')}
        </p>
        <p className="display-title font-serif! mt-1.5 text-xl font-bold text-slate-900 dark:text-white">
          {before
            ? t('Votre départ est prévu à 11 h')
            : during
              ? t('L’heure limite de départ est passée')
              : t('Merci d’avoir rendu les clés 💙')}
        </p>
        {before && (
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {t('Il vous reste')}{' '}
            <span className="font-mono text-sm font-bold tabular-nums text-red-600 dark:text-red-400">
              {pad(hh)} h {pad(mm)} min {pad(ss)} s
            </span>
          </p>
        )}
        {enabled && !over && !sent && (
          <Button
            type="button"
            size="sm"
            className="mt-3 h-auto min-h-11 w-full whitespace-normal bg-slate-900 py-2.5 text-center font-semibold leading-snug text-white hover:bg-slate-800"
            onClick={request}
            disabled={sending}
            aria-label="Demander un départ tardif jusqu'à 14 h"
          >
            {sending ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
            ) : (
              <Clock4 className="h-3.5 w-3.5" aria-hidden="true" />
            )}
            {sending
              ? 'Envoi…'
              : `${t('Besoin de plus de temps ? Prolongez jusqu’à 14 h')}${price != null ? ` — ${formatEur(price)}` : ''}`}
          </Button>
        )}
        {sent && (
          <p className="mt-3 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
            ✅ {t('Demande envoyée — votre hôte vous confirme.')}
          </p>
        )}
      </div>
    </div>
  );
}

/** 🚨 « SOS LOGEMENT » — alerte urgence en 1 clic (fuite d'eau, panne de
 *  chauffage, clé bloquée, électricité). POST …/sos → réclamation urgente
 *  + notification IMMÉDIATE à l'hôte (heure + adresse). L'heure d'envoi
 *  est gardée en localStorage (chip « Hôte alerté à HH:MM »). */
const SOS_PROBLEMS = [
  { id: 'water', emoji: '💧', label: 'Fuite d’eau' },
  { id: 'heating', emoji: '🔥', label: 'Panne de chauffage' },
  { id: 'key', emoji: '🔑', label: 'Clé bloquée ou perdue' },
  { id: 'power', emoji: '⚡', label: 'Panne d’électricité' },
  { id: 'other', emoji: '🆘', label: 'Autre urgence' },
] as const;

function SosAlertCard({
  slug,
  photoOverride,
}: {
  slug: string;
  photoOverride?: string | null;
}) {
  const { t } = useHubLang();
  const [open, setOpen] = useState(false);
  const [problem, setProblem] = useState<(typeof SOS_PROBLEMS)[number]['id'] | null>(null);
  const [note, setNote] = useState('');
  const [sending, setSending] = useState(false);
  const [sentAt, setSentAt] = useState<string | null>(() => {
    try {
      return localStorage.getItem(`hub-sos-${slug}`);
    } catch {
      return null;
    }
  });

  const send = async () => {
    if (!problem || sending) return;
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/sos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problem, note: note.trim() || null }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        message?: string;
        timeLabel?: string;
      };
      if (!res.ok) throw new Error(data.error || 'http');
      const time =
        data.timeLabel ??
        new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
      setSentAt(time);
      try {
        localStorage.setItem(`hub-sos-${slug}`, time);
      } catch {
        /* stockage indisponible */
      }
      toast.success(data.message || `L’hôte a été alerté à ${time}.`);
      setNote('');
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Alerte impossible. Réessayez dans un instant.');
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <ModuleCard
        emoji="🚨"
        tone="red"
        eyebrow={t('Urgence en 1 clic')}
        title={t('SOS Logement')}
        subtitle={t('Fuite, panne, clé bloquée — alerte immédiate')}
        imageUrl={photoOverride ?? HUB_VISUALS.sosHome}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {sentAt ? (
            <PreviewChip>
              ✅ {t('Hôte alerté à')} {sentAt}
            </PreviewChip>
          ) : (
            <>
              <PreviewChip>💧 {t('Fuite d’eau')}</PreviewChip>
              <PreviewChip>⚡ {t('Alerte immédiate')}</PreviewChip>
            </>
          )}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🚨"
        tone="red"
        title={t('SOS Logement')}
        subtitle={t('L’hôte reçoit l’heure et l’adresse de l’appartement')}
      >
        {sentAt && (
          <p className="mb-3 rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-xs font-semibold text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
            ✅ {t('Hôte alerté à')} {sentAt} — {t('restez sur place si possible.')}{' '}
            <button
              type="button"
              className="underline underline-offset-2"
              onClick={() => setSentAt(null)}
            >
              {t('Re-signaler')}
            </button>
          </p>
        )}
        <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
          {t('Quel est le problème ?')}
        </p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {SOS_PROBLEMS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setProblem(p.id)}
              aria-pressed={problem === p.id}
              className={cn(
                'flex min-h-[44px] items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-xs font-semibold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500/60',
                problem === p.id
                  ? 'border-red-500 bg-red-50 text-red-700 dark:bg-red-500/15 dark:text-red-300'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 dark:border-white/10 dark:bg-white/5 dark:text-slate-200',
              )}
            >
              <span aria-hidden="true" className="text-base">
                {p.emoji}
              </span>
              {t(p.label)}
            </button>
          ))}
        </div>
        <Input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          maxLength={300}
          placeholder={t('Précisez si besoin (optionnel)')}
          className="mt-3 h-11"
          aria-label={t('Précisez si besoin (optionnel)')}
        />
        <Button
          type="button"
          className="mt-3 h-auto min-h-11 w-full whitespace-normal bg-red-600 py-2.5 text-center font-semibold leading-snug text-white hover:bg-red-700"
          onClick={send}
          disabled={!problem || sending}
        >
          {sending ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            <TriangleAlert className="h-4 w-4" aria-hidden="true" />
          )}
          {sending ? t('Envoi…') : t('🚨 Alerte immédiate')}
        </Button>
        <p className="mt-2 text-center text-[11px] text-slate-400 dark:text-slate-500">
          {t('En urgence vitale, appelez d’abord les secours (112).')}
        </p>
      </TileDialog>
    </>
  );
}

/** 🛍️ « SHOP THE STAY » — les produits de la maison à acheter (café
 *  local, parure de lit, savon…) : chaque commande notifie l'hôte avec
 *  la commission d'affiliation (10 %). Le règlement et la livraison se
 *  règlent ensuite avec l'hôte. État « commandé » en localStorage. */
function ShopCard({
  slug,
  items,
  photoOverride,
}: {
  slug: string;
  items: GuestShopItem[];
  photoOverride?: string | null;
}) {
  const { lang } = useHubLang();
  const [open, setOpen] = useState(false);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [ai, setAi] = useState<Record<string, string>>({});
  const [ordered, setOrdered] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(localStorage.getItem(`hub-shop-orders-${slug}`) ?? '{}') as Record<
        string,
        boolean
      >;
    } catch {
      return {};
    }
  });

  // Traduction IA des noms/descriptions produits (catalogue hôte libre).
  useEffect(() => {
    if (lang === 'fr' || !open) return;
    const pending = [
      ...new Set(
        items
          .flatMap((i) => [i.name, i.description ?? ''])
          .filter((s) => s && translateText(s, lang) === s && !ai[s]),
      ),
    ];
    if (pending.length === 0) return;
    let alive = true;
    void translateBatchAi(pending, lang).then((tr) => {
      if (alive && Object.keys(tr).length > 0) setAi((prev) => ({ ...prev, ...tr }));
    });
    return () => {
      alive = false;
    };
  }, [lang, items, open, ai]);
  const t = (s: string) => {
    if (lang === 'fr') return s;
    const st = translateText(s, lang);
    return st !== s ? st : (ai[s] ?? s);
  };

  const order = async (itemId: string) => {
    if (pendingId) return;
    setPendingId(itemId);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/shop-order`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId, qty: 1 }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      toast.success(data.message || 'Demande envoyée — votre hôte vous recontacte pour la livraison.');
      const next = { ...ordered, [itemId]: true };
      setOrdered(next);
      try {
        localStorage.setItem(`hub-shop-orders-${slug}`, JSON.stringify(next));
      } catch {
        /* stockage indisponible */
      }
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Demande impossible. Réessayez dans un instant.');
    } finally {
      setPendingId(null);
    }
  };

  return (
    <>
      <ModuleCard
        emoji="🛍️"
        tone="amber"
        eyebrow={t('Boutique de la maison')}
        title="Shop the Stay"
        subtitle={t('Les produits de la maison, livrés chez vous')}
        imageUrl={photoOverride ?? HUB_VISUALS.shop}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          <PreviewChip>
            🤝 {Math.round(SHOP_COMMISSION_RATE * 100)} % {t('reversés à votre hôte')}
          </PreviewChip>
          <PreviewChip>📦 {t('Livrés chez vous')}</PreviewChip>
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🛍️"
        tone="amber"
        title="Shop the Stay"
        subtitle={t('Achetez ce que vous avez aimé pendant votre séjour')}
      >
        <p className="rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs font-semibold text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
          🤝 {Math.round(SHOP_COMMISSION_RATE * 100)} % {t('du montant sont reversés à votre hôte — partenariat boutique.')}
        </p>
        <div className="mt-3 flex flex-col gap-2.5">
          {items.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl border border-slate-200 bg-white p-3 dark:border-white/10 dark:bg-white/5"
            >
              <div className="flex items-start gap-3">
                <span
                  aria-hidden="true"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-xl dark:bg-amber-500/15"
                >
                  {item.emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{t(item.name)}</p>
                    <p className="shrink-0 text-sm font-bold text-slate-900 dark:text-white">
                      {formatEur(item.price)}
                    </p>
                  </div>
                  {item.description && (
                    <p className="mt-0.5 text-xs leading-snug text-slate-500 dark:text-slate-400">
                      {t(item.description)}
                    </p>
                  )}
                  <div className="mt-2 flex items-center gap-2">
                    {ordered[item.id] ? (
                      <span className="inline-flex h-9 items-center rounded-xl bg-emerald-50 px-3 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
                        ✅ {t('Demande envoyée')}
                      </span>
                    ) : (
                      <Button
                        type="button"
                        size="sm"
                        className="h-9 bg-slate-900 font-semibold text-white hover:bg-slate-800"
                        onClick={() => order(item.id)}
                        disabled={pendingId === item.id}
                      >
                        {pendingId === item.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                        ) : (
                          <Package className="h-3.5 w-3.5" aria-hidden="true" />
                        )}
                        {t('Commander')}
                      </Button>
                    )}
                    {item.url && (
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs font-semibold text-slate-500 underline underline-offset-2 hover:text-slate-700 dark:text-slate-400"
                      >
                        {t('Voir en ligne')}
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 text-center text-[11px] text-slate-400 dark:text-slate-500">
          {t('Votre hôte reçoit la demande et vous recontacte pour organiser la livraison.')}
        </p>
      </TileDialog>
    </>
  );
}

// =============================================================
// v4.31 « POUR VOUS » — personnalisation intelligente du hub
// =============================================================
/** Moment du séjour : réservation en cours (serveur) sinon heure locale. */
type StayMoment = 'arrival' | 'midstay' | 'departure' | 'evening';

interface ForYouEntry {
  key: string;
  /** Photo de la mini-carte (perso de l'hôte sinon curated) ; null = repli emoji. */
  photo: string | null;
  emoji: string;
  title: string;
  /** Micro-raison contextuelle (« Vous arrivez aujourd'hui »). */
  reason: string;
  /** Carte cible : ancre à faire défiler OU dialog à ouvrir. */
  targetId?: string;
  openDialog?: 'video' | 'feedback' | 'contact';
}

/** Sélection « Pour vous » selon le moment — 2 à 3 mini-cartes. */
function forYouEntries(moment: StayMoment, photos: HubPhotoMap): ForYouEntry[] {
  const P = (k: HubPhotoKey, curated: string | null): string | null => photos[k] ?? curated;
  switch (moment) {
    case 'arrival':
      return [
        { key: 'arrival', photo: P('arrival', HUB_ARRIVAL_PHOTOS.facade), emoji: '🗺️', title: 'Arrivée pas à pas', reason: 'Vous arrivez aujourd’hui', targetId: 'hub-card-arrival' },
        { key: 'access', photo: P('access', HUB_VISUALS.access), emoji: '🔑', title: 'Accès & Codes', reason: 'Portail, serrure, boîte à clés', targetId: 'hub-card-access' },
        { key: 'video', photo: P('video', HUB_VISUALS.welcome), emoji: '🎬', title: 'Vidéo de bienvenue', reason: 'Bienvenue chez vous !', openDialog: 'video' },
      ];
    case 'departure':
      return [
        { key: 'lateCheckout', photo: P('lateCheckout', HUB_VISUALS.lateCheckout), emoji: '⏱️', title: 'Départ tardif', reason: 'Votre départ approche', targetId: 'hub-card-late' },
        { key: 'review', photo: P('review', HUB_VISUALS.review), emoji: '⭐', title: 'Bouclier d’avis', reason: 'Un mot sur votre séjour ?', openDialog: 'feedback' },
      ];
    case 'evening':
      return [
        { key: 'video', photo: P('video', HUB_VISUALS.welcome), emoji: '🎬', title: 'Vidéo de bienvenue', reason: 'Installez-vous confortablement', openDialog: 'video' },
        { key: 'host', photo: P('host', HUB_VISUALS.host), emoji: '📞', title: 'Contacter l’hôte', reason: 'Une question ce soir ?', openDialog: 'contact' },
      ];
    default: // midstay
      return [
        { key: 'spots', photo: P('spots', HUB_VISUALS.spots), emoji: '📍', title: 'Bonnes adresses', reason: 'La carte secrète de votre hôte', targetId: 'hub-card-spots' },
        { key: 'appliances', photo: P('appliances', HUB_VISUALS.appliances), emoji: '🛠️', title: 'Guide des appareils', reason: 'Maîtrisez toute la maison', targetId: 'hub-card-appliances' },
      ];
  }
}

/** Bandeau horizontal « ✨ Pour vous » — mini-cartes photo (Ken Burns)
 *  qui sautent à la carte ciblée ou ouvrent le dialog correspondant. */
function ForYouStrip({
  entries,
  onJump,
  onOpen,
}: {
  entries: ForYouEntry[];
  onJump: (id: string) => void;
  onOpen: (d: 'video' | 'feedback' | 'contact') => void;
}) {
  const [failed, setFailed] = useState<Record<string, boolean>>({});
  if (entries.length === 0) return null;
  return (
    <div className="mt-6" aria-label="Suggestions personnalisées">
      <p className="px-1 text-[11px] font-bold uppercase tracking-[0.22em] text-slate-400 dark:text-slate-500">
        ✨ Pour vous
      </p>
      <div className="mt-2.5 flex snap-x snap-mandatory gap-3 overflow-x-auto pb-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {entries.map((e) => (
          <button
            key={e.key}
            type="button"
            onClick={() => {
              if (e.targetId) onJump(e.targetId);
              else if (e.openDialog) onOpen(e.openDialog);
            }}
            className="group relative h-32 w-44 shrink-0 snap-start overflow-hidden rounded-2xl border border-black/10 text-left shadow-[0_14px_34px_-18px_rgba(15,23,42,0.5)] transition-shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/70 hover:shadow-[0_18px_40px_-18px_rgba(15,23,42,0.6)] dark:border-white/10"
          >
            {e.photo && !failed[e.key] ? (
              <img
                src={e.photo}
                alt=""
                loading="lazy"
                decoding="async"
                className="hub-kenburns absolute inset-0 h-full w-full object-cover"
                onError={() => setFailed((f) => ({ ...f, [e.key]: true }))}
              />
            ) : (
              <span
                aria-hidden="true"
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900 text-4xl"
              >
                {e.emoji}
              </span>
            )}
            <span
              aria-hidden="true"
              className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-black/10"
            />
            <span className="absolute left-2.5 top-2.5 inline-flex items-center gap-1 rounded-full border border-white/35 bg-black/35 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.18em] text-white/90 backdrop-blur-sm">
              ✨ Pour vous
            </span>
            <span className="absolute inset-x-0 bottom-0 flex flex-col p-3">
              <span className="text-sm font-bold leading-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.55)]">
                {e.title}
              </span>
              <span className="mt-0.5 text-[11px] leading-snug text-white/85">{e.reason}</span>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

/** Dialog clair ouvert par une tuile — remplace le contenu dépliable
 * inline des anciennes cartes (contenu métier inchangé). Version
 * claire : fond blanc, bordure slate, titre slate-900, tuile
 * d'icône toujours colorée. */
function TileDialog({
  open,
  onOpenChange,
  emoji,
  tone,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  emoji: string;
  tone: TileTone;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  const t = CARD_TONES[tone];
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md sm:max-w-md rounded-3xl border border-slate-200 bg-white p-5 text-slate-900 shadow-xl sm:p-6 dark:border-white/10 dark:bg-slate-900 dark:text-slate-100">
        <DialogHeader className="items-start text-left">
          <div className="flex items-center gap-3 pr-6">
            <span
              aria-hidden="true"
              className={cn(
                'inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl leading-none',
                t.iconTile,
              )}
            >
              {emoji}
            </span>
            <div className="min-w-0">
              <DialogTitle className="display-title font-serif! text-xl font-bold text-slate-900 dark:text-white">
                {title}
              </DialogTitle>
              <DialogDescription className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <div className="-mx-1 max-h-[60dvh] overflow-y-auto px-1 pb-1 custom-scrollbar">{children}</div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// v4.35 « ALERTE NOUVEAU MESSAGE » (demande client : « afficher une
// icône rouge et faire scintiller l'onglet contact pour signaler le
// message, mettre un bip sonore mp3 ») — la carte « Contacter l'hôte »
// clignote en rouge + bip sonore quand l'hôte a laissé une réponse
// vocale non vue. Polling léger (?meta=1, SANS audio) + journal des
// ids déjà vus en localStorage (par hub). Premier scan = baseline
// silencieuse (pas de bip pour d'anciens messages).
// =============================================================
const seenRepliesKey = (slug: string) => `hub-guest-seen-replies-${slug}`;

function readSeenReplies(slug: string): string[] {
  try {
    const raw = window.localStorage.getItem(seenRepliesKey(slug));
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed)
      ? parsed.filter((v): v is string => typeof v === 'string').slice(-200)
      : [];
  } catch {
    return [];
  }
}

function persistSeenReplies(slug: string, ids: string[]) {
  try {
    const merged = Array.from(new Set([...readSeenReplies(slug), ...ids])).slice(-200);
    window.localStorage.setItem(seenRepliesKey(slug), JSON.stringify(merged));
  } catch {
    // localStorage indisponible : l'alerte se réaffichera (bénin)
  }
}

function useHostReplyAlert(slug: string) {
  const [newReplyIds, setNewReplyIds] = useState<string[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  /** Bip sonore mp3 — tolérant à la politique d'autoplay : si le
   *  navigateur bloque la lecture, elle est re-jouée au 1er geste. */
  const playBeep = useCallback(() => {
    try {
      if (!audioRef.current) {
        audioRef.current = new Audio('/sounds/message-alert.mp3');
        audioRef.current.volume = 0.7;
      }
      audioRef.current.currentTime = 0;
      const playing = audioRef.current.play();
      if (playing && typeof playing.catch === 'function') {
        playing.catch(() => {
          const retry = () => {
            try {
              audioRef.current?.play().catch(() => undefined);
            } catch {
              // audio indisponible
            }
            window.removeEventListener('pointerdown', retry);
            window.removeEventListener('keydown', retry);
          };
          window.addEventListener('pointerdown', retry, { once: true });
          window.addEventListener('keydown', retry, { once: true });
        });
      }
    } catch {
      // Audio indisponible : l'alerte visuelle reste suffisante
    }
  }, []);

  useEffect(() => {
    let alive = true;
    const check = async () => {
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/voice-replies?meta=1`, {
          cache: 'no-store',
        });
        if (!res.ok || !alive) return;
        const data = (await res.json().catch(() => ({}))) as { replies?: { id: string }[] };
        const ids = (data.replies ?? []).map((r) => r.id).filter(Boolean);
        if (ids.length === 0 || !alive) return;
        let baseline = false;
        try {
          baseline = window.localStorage.getItem(seenRepliesKey(slug)) === null;
        } catch {
          baseline = false;
        }
        if (baseline) {
          // Premier passage sur ce hub : les réponses existantes deviennent
          // la référence — on n'alerte que sur les NOUVELLES ensuite.
          persistSeenReplies(slug, ids);
          return;
        }
        const seen = readSeenReplies(slug);
        const fresh = ids.filter((id) => !seen.includes(id));
        if (fresh.length > 0) {
          setNewReplyIds(fresh);
          playBeep();
        }
      } catch {
        // réseau indisponible : prochain tick
      }
    };
    void check();
    const timer = setInterval(check, 60_000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [slug, playBeep]);

  /** Marquer des réponses comme vues (ouverture de l'onglet Messages). */
  const markRepliesSeen = useCallback(
    (ids: string[]) => {
      if (ids.length === 0) return;
      persistSeenReplies(slug, ids);
      setNewReplyIds((prev) => prev.filter((id) => !ids.includes(id)));
    },
    [slug],
  );

  return { newReplyIds, markRepliesSeen };
}

// =============================================================
// v4.35 « RÉSERVATION DIRECTE » — bandeau PERMANENT de la page
// d'accueil du hub (stratégie B2B : la plateforme transforme les
// clients Airbnb en clients DIRECTS de l'hôte) :
//   « Vous avez aimé votre séjour ? Économisez 15 % sur votre
//    prochaine visite en réservant directement ici — sans les
//    frais d'Airbnb. »
// CTA : lien directBookingUrl de l'hôte (dashboard premium), sinon
// repli WhatsApp prérempli avec le message de réservation.
// =============================================================
function DirectBookingBanner({
  discount,
  url,
  waHref,
  propertyName,
}: {
  discount: number;
  url?: string | null;
  waHref: string | null;
  propertyName: string;
}) {
  const { t } = useHubLang();
  const bookHref = url
    ? url
    : waHref
      ? `${waHref}?text=${encodeURIComponent(
          `Bonjour ! J'ai adoré mon séjour à ${propertyName}. Je souhaite réserver à nouveau en direct — avec la remise de ${discount} % (sans frais de plateforme).`,
        )}`
      : null;
  return (
    <div className="mx-auto mt-4 w-full overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-600 via-emerald-500 to-amber-500 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(5,150,105,0.55)]">
      <div className="rounded-[22px] bg-white/95 p-4 sm:p-5 dark:bg-slate-900/95">
        <p className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-emerald-700 dark:text-emerald-400">
          <BadgePercent className="h-3.5 w-3.5" aria-hidden="true" />
          {t('Réservation directe')}
          <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold tracking-normal text-white">
            -{discount} %
          </span>
        </p>
        <p className="display-title font-serif! mt-1.5 text-lg font-bold leading-snug text-slate-900 dark:text-white">
          {t('Vous avez aimé votre séjour ?')}
        </p>
        <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
          {t(
            `Économisez ${discount} % sur votre prochaine visite en réservant directement ici — sans les frais d'Airbnb.`,
          )}
        </p>
        {bookHref && (
          <a
            href={bookHref}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-slate-900 text-sm font-semibold text-white transition-colors hover:bg-slate-800"
          >
            <CalendarCheck className="h-4 w-4" aria-hidden="true" />
            {t('Réserver en direct')}
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </a>
        )}
      </div>
    </div>
  );
}

// =============================================================
// v4.35 « REVIEW BOOSTER » — collecte d'avis automatisée (B2B) :
// la veille du départ (dès 18 h) et le jour J jusqu'à 14 h, un
// micro-questionnaire sonde la satisfaction :
//   👍 → « Aidez-nous à grandir, laissez un avis en 2 clics ! » +
//        lien DIRECT vers la page d'avis (Airbnb/Google) de l'hôte.
//   👎 → tout passe en PRIVÉ (bouclier d'avis) : signalement direct,
//        aucun avis public négatif — l'hôte est protégé.
// La réponse est mémorisée en localStorage (1 fois par séjour).
// =============================================================
const reviewBoosterKey = (slug: string) => `hub-review-booster-${slug}`;

function ReviewBoosterBanner({
  slug,
  reviewUrl,
  waHref,
  propertyName,
  onOpenComplaint,
}: {
  slug: string;
  reviewUrl?: string | null;
  waHref: string | null;
  propertyName: string;
  onOpenComplaint: () => void;
}) {
  const { t } = useHubLang();
  const [answer, setAnswer] = useState<'up' | 'down' | null>(() => {
    try {
      const v = window.localStorage.getItem(reviewBoosterKey(slug));
      return v === 'up' || v === 'down' ? v : null;
    } catch {
      return null;
    }
  });

  const pick = (v: 'up' | 'down') => {
    setAnswer(v);
    try {
      window.localStorage.setItem(reviewBoosterKey(slug), v);
    } catch {
      // localStorage indisponible : le questionnaire réapparaîtra
    }
  };

  const praiseHref = reviewUrl
    ? reviewUrl
    : waHref
      ? `${waHref}?text=${encodeURIComponent(`Bonjour ! Nous avons passé un superbe séjour à ${propertyName} 🙏`)}`
      : null;

  if (answer === 'up') {
    return (
      <div className="mx-auto mt-4 w-full overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-amber-400 to-emerald-500 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(217,119,6,0.5)]">
        <div className="rounded-[22px] bg-white/95 p-4 sm:p-5 dark:bg-slate-900/95">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-amber-600 dark:text-amber-400">
            ⭐ {t('Fin de séjour')}
          </p>
          <p className="display-title font-serif! mt-1.5 text-lg font-bold text-slate-900 dark:text-white">
            {t('Merci beaucoup ! 🙏')}
          </p>
          <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            {t('Aidez-nous à grandir, laissez un avis en 2 clics !')}
          </p>
          {praiseHref ? (
            <a
              href={praiseHref}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-3 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-amber-500 text-sm font-bold text-white transition-colors hover:bg-amber-600"
            >
              <Star className="h-4 w-4" aria-hidden="true" />
              {t('Laisser mon avis')}
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
          ) : (
            <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
              {t("Votre hôte prépare son lien d'avis — dites-lui votre enthousiasme via l'onglet Contact !")}
            </p>
          )}
        </div>
      </div>
    );
  }

  if (answer === 'down') {
    return (
      <div className="mx-auto mt-4 w-full overflow-hidden rounded-3xl bg-gradient-to-r from-slate-700 via-slate-600 to-emerald-600 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(15,23,42,0.5)]">
        <div className="rounded-[22px] bg-white/95 p-4 sm:p-5 dark:bg-slate-900/95">
          <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
            🔒 {t('En toute discrétion')}
          </p>
          <p className="display-title font-serif! mt-1.5 text-lg font-bold text-slate-900 dark:text-white">
            {t('Merci de nous le dire en privé')}
          </p>
          <p className="mt-1 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            {t("Dites-nous ce qui n'a pas été — on s'en occupe tout de suite, avant votre départ.")}
          </p>
          <Button
            type="button"
            className="mt-3 h-auto min-h-11 w-full whitespace-normal bg-slate-900 py-2.5 text-center text-sm font-semibold leading-snug text-white hover:bg-slate-800"
            onClick={onOpenComplaint}
          >
            🚨 {t('Le signaler maintenant')}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto mt-4 w-full overflow-hidden rounded-3xl bg-gradient-to-r from-amber-500 via-orange-400 to-emerald-500 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(217,119,6,0.5)]">
      <div className="rounded-[22px] bg-white/95 p-4 sm:p-5 dark:bg-slate-900/95">
        <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-amber-600 dark:text-amber-400">
          ⭐ {t('Fin de séjour')}
        </p>
        <p className="display-title font-serif! mt-1.5 text-lg font-bold text-slate-900 dark:text-white">
          {t('Comment se passe votre séjour ?')}
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2.5">
          <Button
            type="button"
            className="h-12 bg-emerald-600 text-base font-bold text-white hover:bg-emerald-700"
            onClick={() => pick('up')}
            aria-label="Tout va bien"
          >
            👍 {t('Super !')}
          </Button>
          <Button
            type="button"
            variant="outline"
            className="h-12 border-slate-300 bg-white text-base font-bold text-slate-700 hover:bg-slate-50 dark:border-white/20 dark:bg-transparent dark:text-slate-200 dark:hover:bg-white/10"
            onClick={() => pick('down')}
            aria-label="Un souci à signaler"
          >
            👎 {t('Ça ne va pas')}
          </Button>
        </div>
      </div>
    </div>
  );
}

function GuestView({
  payload,
  slug,
  onBack,
  copy,
  theme,
  onToggleTheme,
}: {
  payload: HubPayload;
  slug: string;
  onBack: () => void;
  copy: (text: string, label: string) => Promise<void>;
  /** Thème du hub (« light » par défaut, mémorisé par visiteur). */
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}) {
  const [contactOpen, setContactOpen] = useState(false);
  const [complaintFormOpen, setComplaintFormOpen] = useState(false);
  // Modules premium (dialogs vidéo / bouclier d'avis).
  const [videoOpen, setVideoOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const router = useRouter();
  const { property, guest } = payload;

  // ── v4.31 « POUR VOUS » + « PHOTOS DE MON HUB » ──
  // Photos personnalisées de l'hôte (fallback : visuels curated).
  const photos = payload.property.hubPhotos ?? {};
  // Moment du séjour : réservation en cours (serveur, sans données
  // personnelles) sinon repli sur l'heure locale du téléphone.
  // Lazy init client-only — la vue invité n'est jamais rendue en SSR.
  const [moment] = useState<StayMoment>(() => {
    if (payload.stayMoment) return payload.stayMoment;
    const h = new Date().getHours();
    return h >= 18 || h < 5 ? 'evening' : 'midstay';
  });
  const jumpTo = useCallback((id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);
  const openForYou = useCallback((d: 'video' | 'feedback' | 'contact') => {
    if (d === 'video') setVideoOpen(true);
    else if (d === 'feedback') setFeedbackOpen(true);
    else setContactOpen(true);
  }, []);
  // ── v4.33 « TRADUCTION INSTANTANÉE IA » — langue du voyageur ──
  // Auto-détection du smartphone au 1er scan ; choix mémorisé par hub
  // (localStorage). Lazy init client-only : la vue invité n'est JAMAIS
  // rendue en SSR (le composant n'apparaît qu'après le fetch du payload).
  const [lang, setLang] = useState<HubLang>(() => getStoredLang(slug) ?? detectLang());
  const changeLang = useCallback(
    (l: HubLang) => {
      setLang(l);
      storeLang(slug, l);
    },
    [slug],
  );
  const tL = useCallback((s: string) => translateText(s, lang), [lang]);

  const forYou = useMemo(
    () =>
      // v4.33 — libellés « Pour vous » traduits (dictionnaire statique).
      forYouEntries(moment, photos).map((e) => ({
        ...e,
        title: translateText(e.title, lang),
        reason: translateText(e.reason, lang),
      })),
    [moment, photos, lang],
  );

  // ── v4.32 « SIGNAUX DU SÉJOUR » ──
  // Départ tardif : clignote en rouge la VEILLE du départ ET le jour même
  // (stayMoment='departure' est calculé serveur : checkOut - aujourd'hui ≤ 1 j).
  const lateCheckoutUrgent = moment === 'departure';
  // Bouclier d'avis : clignote tous les jours à partir de 20 h (heure du
  // téléphone de l'invité) — rafraîchi chaque minute si la page reste ouverte.
  const [eveningBlink, setEveningBlink] = useState(false);
  useEffect(() => {
    const update = () => setEveningBlink(new Date().getHours() >= 20);
    update();
    const t = setInterval(update, 60_000);
    return () => clearInterval(t);
  }, []);

  // ── v4.35 « SOIR DE DÉPART » + « REVIEW BOOSTER » ──
  // Heure locale rafraîchie chaque minute. La veille du départ le soir
  // (≥ 18 h), « Départ tardif » et « Bouclier d'avis » passent EN TÊTE
  // DE PAGE (demande client : « en haut pour plus de visibilité ») ; le
  // Review Booster (👍/👎 → avis public ou privé) s'affiche dès 18 h la
  // veille et le jour J jusqu'à 14 h. Alerte « nouveau message hôte » :
  // la carte Contact clignote + bip mp3 quand une réponse vocale attend.
  const [nowHour, setNowHour] = useState(() => new Date().getHours());
  useEffect(() => {
    const update = () => setNowHour(new Date().getHours());
    update();
    const t = setInterval(update, 60_000);
    return () => clearInterval(t);
  }, []);
  const isCheckoutDay = !!payload.stay?.isCheckoutDay;
  const eveningBeforeDeparture = moment === 'departure' && !isCheckoutDay && nowHour >= 18;
  const reviewBoosterWindow = moment === 'departure' && (nowHour >= 18 || nowHour < 14);
  const { newReplyIds, markRepliesSeen } = useHostReplyAlert(slug);
  const waHostHref = useMemo(() => waMeHref(payload.guest.contact.phone), [payload.guest.contact.phone]);

  // ── SECTION 1 « Votre logement » — ordre adapté au moment ──
  // (jour d'arrivée, demande client : « Arrivée pas à pas » PUIS
  // « Accès & Codes » PUIS la vidéo de bienvenue, avant le reste).
  // Les divs id servent d'ancres au bandeau « Pour vous » (scroll fluide).
  // v4.32 — la carte vidéo vit en section 1 le jour d'arrivée (3e position
  // après Arrivée pas à pas + Accès & Codes), en section 2 les autres jours.
  const videoNode = guest.premiumFeatures?.videoWelcomeUrl ? (
    <WelcomeVideoCard
      key="video"
      url={guest.premiumFeatures.videoWelcomeUrl}
      propertyName={property.name}
      open={videoOpen}
      onOpenChange={setVideoOpen}
      photoOverride={photos.video}
    />
  ) : null;
  const sec1Items: { key: string; node: React.ReactNode }[] = [
    {
      key: 'access',
      node: guest.accessCodes ? (
        <div id="hub-card-access" key="access" className="flex h-full flex-col">
          <AccessCodesCard codes={guest.accessCodes} copy={copy} photoOverride={photos.access} />
        </div>
      ) : null,
    },
    {
      key: 'guidebook',
      node: guest.guidebookSlug ? (
        <div id="hub-card-guidebook" key="guidebook" className="flex h-full flex-col">
          <ModuleCard
            emoji="📖"
            tone="teal"
            eyebrow="Guide de la maison"
            title="Guidebook"
            subtitle="Accès, équipements, règles & bonnes adresses"
            imageUrl={photos.guidebook ?? HUB_VISUALS.guidebook}
            onClick={() => guest.guidebookSlug && router.push(`/view/${guest.guidebookSlug}`)}
          >
            <span className="flex flex-wrap gap-1.5">
              <PreviewChip>🗝️ Arrivée</PreviewChip>
              <PreviewChip>🛏️ Équipements</PreviewChip>
              <PreviewChip>📋 Règles</PreviewChip>
            </span>
          </ModuleCard>
        </div>
      ) : (
        <div id="hub-card-guidebook" key="guidebook" className="flex h-full flex-col">
          <ModuleCard
            emoji="📖"
            tone="teal"
            eyebrow="Guide de la maison"
            title="Guidebook"
            subtitle="Votre hôte prépare son guide"
            imageUrl={photos.guidebook ?? HUB_VISUALS.guidebook}
            disabled
          />
        </div>
      ),
    },
    {
      key: 'arrival',
      node:
        guest.visualGuide.length > 0 ? (
          <div id="hub-card-arrival" key="arrival" className="flex h-full flex-col">
            <VisualGuideCard steps={guest.visualGuide} photoOverride={photos.arrival} />
          </div>
        ) : null,
    },
    {
      key: 'video',
      node: moment === 'arrival' ? videoNode : null,
    },
    {
      key: 'appliances',
      node:
        guest.appliances.length > 0 ? (
          <div id="hub-card-appliances" key="appliances" className="flex h-full flex-col">
            <AppliancesCard appliances={guest.appliances} photoOverride={photos.appliances} />
          </div>
        ) : null,
    },
    {
      key: 'survival',
      node:
        guest.survivalKitItems.length > 0 ? (
          <SurvivalKitCard key="survival" items={guest.survivalKitItems} photoOverride={photos.survival} />
        ) : null,
    },
    {
      key: 'wifighost',
      node: !guest.wifi ? (
        <ModuleCard
          key="wifighost"
          emoji="📶"
          tone="teal"
          eyebrow="Connexion"
          title="Wi-Fi"
          subtitle="Informations en cours de préparation"
          imageUrl={HUB_VISUALS.wifi}
          disabled
        />
      ) : null,
    },
  ];
  const sec1Order =
    moment === 'arrival'
      ? ['arrival', 'access', 'video', 'guidebook', 'appliances', 'survival', 'wifighost']
      : ['access', 'guidebook', 'arrival', 'appliances', 'survival', 'wifighost'];
  const sec1Nodes = sec1Order
    .map((k) => sec1Items.find((i) => i.key === k)?.node)
    .filter((n): n is React.ReactNode => !!n);

  // ── SECTION 2 « Pendant votre séjour » — ordre adapté au moment ──
  // (veille du départ : Départ tardif + Bouclier d'avis passent devant).
  const sec2Items: { key: string; node: React.ReactNode }[] = [
    {
      key: 'video',
      node: moment === 'arrival' ? null : videoNode,
    },
    {
      key: 'late',
      node: guest.premiumFeatures?.enableLateCheckout ? (
        <div id="hub-card-late" key="late" className="flex h-full flex-col">
          <LateCheckoutCard
            slug={slug}
            price={guest.premiumFeatures.lateCheckoutPrice}
            propertyName={property.name}
            photoOverride={photos.lateCheckout}
            urgentLabel={lateCheckoutUrgent ? tL('⏰ Départ imminent') : undefined}
          />
        </div>
      ) : null,
    },
    {
      key: 'spots',
      node: guest.localSpots.length > 0 ? (
        <div id="hub-card-spots" key="spots" className="flex h-full flex-col">
          <LocalSpotsCard spots={guest.localSpots} photoOverride={photos.spots} />
        </div>
      ) : null,
    },
    {
      key: 'review',
      node: guest.premiumFeatures?.enableReviewShield ? (
        <ReviewShieldCard
          key="review"
          slug={slug}
          propertyName={property.name}
          reviewUrl={guest.premiumFeatures.reviewUrl}
          open={feedbackOpen}
          onOpenChange={setFeedbackOpen}
          photoOverride={photos.review}
          urgentLabel={eveningBlink ? tL('⭐ Ce soir 20 h') : undefined}
        />
      ) : null,
    },
    {
      // v4.33 « SHOP THE STAY » — boutique de la maison (affiliation hôte).
      key: 'shop',
      node: (
        <div id="hub-card-shop" key="shop" className="flex h-full flex-col">
          <ShopCard slug={slug} items={guest.shopItems ?? []} photoOverride={photos.shop} />
        </div>
      ),
    },
  ];
  const sec2BaseOrder =
    moment === 'departure'
      ? ['late', 'review', 'video', 'spots', 'shop']
      : ['video', 'shop', 'late', 'spots', 'review'];
  // v4.35 — le soir de la veille du départ, « Départ tardif » et
  // « Bouclier d'avis » SORTENT de la section 2 : ils sont remontés en
  // tête de page dans le bandeau « Ce soir : préparez votre départ ».
  const sec2Order = eveningBeforeDeparture
    ? sec2BaseOrder.filter((k) => k !== 'late' && k !== 'review')
    : sec2BaseOrder;
  const lateNode = sec2Items.find((i) => i.key === 'late')?.node ?? null;
  const reviewNode = sec2Items.find((i) => i.key === 'review')?.node ?? null;
  const sec2Nodes = sec2Order
    .map((k) => sec2Items.find((i) => i.key === k)?.node)
    .filter((n): n is React.ReactNode => !!n);

  return (
    // v4.33 — la langue choisie (auto-détectée/mémorisée) est fournie à
    // TOUTE l'arborescence invité via HubLangContext (ModuleCard, sections,
    // bandeaux et nouveaux modules traduisent via useHubLang()).
    <HubLangContext.Provider value={lang}>
      <div className="flex-1 w-full">
      {/* Fond fixe — dégradé statique très léger, zéro animation */}
      <div
        aria-hidden="true"
        className="fixed inset-0 -z-10 bg-gradient-to-b from-amber-50/70 via-white to-stone-100 dark:from-slate-950 dark:via-slate-950 dark:to-black"
      />

      {/* ── HERO PHOTO — carte arrondie premium (défile avec la page) ──
          Même image que l'accueil : continuité visuelle. */}
      <section
        aria-label="Espace invité"
        className="relative mx-auto w-full max-w-lg px-4 pt-5 sm:max-w-2xl lg:max-w-3xl xl:max-w-5xl 2xl:max-w-6xl"
      >
        <div className="relative h-44 overflow-hidden rounded-3xl shadow-[0_22px_50px_-22px_rgba(15,23,42,0.45)] sm:h-56 lg:h-72 xl:h-80">
          <Image
            src={photos.hero ?? '/hub-hero-villa.jpg'}
            alt=""
            fill
            priority
            unoptimized
            sizes="(max-width: 640px) 100vw, 1152px"
            className="hub-kenburns object-cover object-center"
          />
          {/* Voile sombre léger : lisibilité du titre blanc sur la photo */}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/20 to-black/55"
          />

          {/* Retour + pill signature + langue + thème — au-dessus de la photo */}
          <div className="absolute top-4 left-4 right-4 flex items-center">
            <button
              type="button"
              onClick={onBack}
              aria-label="Retour à l’accueil"
              className="h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl border border-white/40 bg-white/85 text-slate-800 shadow-sm backdrop-blur-md transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
            >
              <ChevronLeft className="h-5 w-5" aria-hidden="true" />
            </button>
            <span className="ml-3 hidden min-[420px]:inline-flex items-center gap-1.5 rounded-full border border-white/40 bg-white/80 px-3 py-1.5 text-[11px] font-medium tracking-wide text-slate-700 shadow-sm backdrop-blur-md">
              {tL('✨ Expérience Conciergerie')}
            </span>
            {/* v4.33 — langue (traduction instantanée IA) puis thème */}
            <LangSwitcher lang={lang} onChange={changeLang} className="ml-auto" />
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'Activer le mode clair' : 'Activer le mode sombre'}
              title={theme === 'dark' ? 'Mode clair' : 'Mode sombre'}
              className="ml-2 h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl border border-white/40 bg-white/85 text-slate-800 shadow-sm backdrop-blur-md transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
            >
              {theme === 'dark' ? (
                <Sun className="h-5 w-5" aria-hidden="true" />
              ) : (
                <Moon className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>

          {/* Titre du bien — bas du hero */}
          <div className="absolute bottom-4 left-4 right-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-white/75">
              {tL('👤 Espace Invité')}
            </p>
            <h1 className="display-title font-serif! mt-1 text-3xl font-bold leading-tight text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.5)] sm:text-4xl lg:text-5xl">
              {property.name}
            </h1>
          </div>
        </div>
      </section>

      {/* ── CONTENU — « wallet » de cartes premium (Task 30, itération 3) ── */}
      <div className="w-full max-w-lg sm:max-w-2xl lg:max-w-3xl xl:max-w-5xl 2xl:max-w-6xl mx-auto px-4 flex-1 flex flex-col">
        <p className="mt-5 text-center text-[13px] text-slate-500 dark:text-slate-400">
          {tL('✨ Tout votre séjour au même endroit.')}
        </p>

        {/* ── v4.33 « COMPTE À REBOURS CHECK-OUT » — jour du départ (J) :
            « Votre départ est prévu à 11 h. Besoin de plus de temps ?
            Prolongez jusqu'à 14 h pour 25 € » — le meilleur moment pour
            vendre un late check-out. Masqué les autres jours. */}
        {payload.stay?.isCheckoutDay ? (
          <div className="mx-auto mt-4 w-full">
            <CheckoutCountdownBanner
              slug={slug}
              enabled={!!guest.premiumFeatures?.enableLateCheckout}
              price={guest.premiumFeatures?.lateCheckoutPrice}
            />
          </div>
        ) : null}

        {/* ── v4.35 « REVIEW BOOSTER » — la veille du départ (soir) et le
            matin J : micro-questionnaire 👍/👎 → avis public 2 clics ou
            retour PRIVÉ (bouclier d'avis). Mémo localStorage. ── */}
        {reviewBoosterWindow ? (
          <ReviewBoosterBanner
            slug={slug}
            reviewUrl={guest.premiumFeatures?.reviewUrl}
            waHref={waHostHref}
            propertyName={property.name}
            onOpenComplaint={() => setComplaintFormOpen(true)}
          />
        ) : null}

        {/* ── v4.35 « SOIR DE DÉPART » — la veille au soir (≥ 18 h),
            « Départ tardif » et « Bouclier d'avis » montent EN TÊTE DE
            PAGE (demande client : plus de visibilité) avec habillage
            rouge « Ce soir : préparez votre départ ». ── */}
        {eveningBeforeDeparture && (lateNode || reviewNode) ? (
          <div className="mx-auto mt-4 w-full overflow-hidden rounded-3xl bg-gradient-to-r from-red-600 via-rose-500 to-amber-500 p-[1.5px] shadow-[0_18px_44px_-20px_rgba(190,18,60,0.55)]">
            <div className="rounded-[22px] bg-white/85 p-3 dark:bg-slate-900/85">
              <p className="flex items-center justify-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-red-600 dark:text-red-400">
                <span aria-hidden="true" className="animate-pulse">🌙</span>
                {tL('Ce soir : préparez votre départ')}
              </p>
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                {lateNode}
                {reviewNode}
              </div>
            </div>
          </div>
        ) : null}

        {/* ── v4.35 « RÉSERVATION DIRECTE » — bandeau PERMANENT (B2B) :
            transforme les invités Airbnb en clients directs de l'hôte
            (« -15 % sans les frais d'Airbnb »). ── */}
        <DirectBookingBanner
          discount={guest.premiumFeatures?.directBookingDiscount ?? 15}
          url={guest.premiumFeatures?.directBookingUrl}
          waHref={waHostHref}
          propertyName={property.name}
        />

        {/* ── FLAGSHIP 1+2 : 📶 Wi-Fi + 🥐 Services — côte à côte en desktop
            (responsive v4.36 : grille 2 colonnes ≥ lg, empilés en mobile) */}
        <div className="mx-auto grid w-full grid-cols-1 items-start gap-0 lg:grid-cols-2 lg:gap-5">
          {guest.wifi ? <WifiPremiumCard wifi={guest.wifi} copy={copy} /> : null}

          {/* ── FLAGSHIP 2 : 🥐 Services & Expériences — même anatomie carte ── */}
          <ServicesCard
            services={guest.services}
            contact={guest.contact}
            property={property}
            slug={slug}
            photoOverride={photos.services}
          />
        </div>

        {/* ── v4.31 « POUR VOUS » — sélection adaptée au moment du séjour ── */}
        <ForYouStrip entries={forYou} onJump={jumpTo} onOpen={openForYou} />

        {/* ── SECTION 1 : VOTRE LOGEMENT (ordre adapté au moment — v4.31) ── */}
        <SectionLabel>{tL('🏠 Votre logement')}</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 items-stretch">
          {sec1Nodes}
        </div>

        {/* ── SECTION 2 : PENDANT VOTRE SÉJOUR (ordre adapté au moment — v4.31) ── */}
        <SectionLabel>{tL('✨ Pendant votre séjour')}</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 items-stretch">
          {sec2Nodes}
        </div>

        {/* ── SECTION 3 : BESOIN D'AIDE ? ── */}
        <SectionLabel>{tL('🆘 Besoin d’aide ?')}</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 items-stretch">
          {/* 🚨 v4.33 SOS Logement — urgence en 1 clic (notification hôte
              immédiate : heure + adresse de l'appartement) */}
          <SosAlertCard slug={slug} photoOverride={photos.sos} />

          {/* 🆘 SOS & Urgences — toujours visible (numéros nationaux + DB) */}
          <SosCard emergency={guest.emergency} photoOverride={photos.sos} />

          {/* 🚨 Signaler un problème — formulaire écrit */}
          <ModuleCard
            emoji="🚨"
            tone="orange"
            eyebrow="Support réactif"
            title="Signaler un problème"
            subtitle="Fuite, électricité, ménage… avec photos"
            imageUrl={photos.issue ?? HUB_VISUALS.issue}
            onClick={() => setComplaintFormOpen(true)}
          >
            <span className="flex flex-wrap gap-1.5">
              <PreviewChip>📸 Avec photos</PreviewChip>
              <PreviewChip>⚡ Réponse rapide</PreviewChip>
            </span>
          </ModuleCard>

          {/* 📞 Contacter l'hôte — v4.35 : clignote en ROUGE + pill
              « Nouveau message ! » tant qu'une réponse vocale de l'hôte
              n'a pas été vue (plus bip mp3 au polling). */}
          <ModuleCard
            emoji="📞"
            tone="emerald"
            eyebrow="Votre hôte"
            title="Contacter l'hôte"
            subtitle={`${guest.contact.name} — appel, email, vocal`}
            imageUrl={photos.host ?? HUB_VISUALS.host}
            onClick={() => setContactOpen(true)}
            urgentLabel={newReplyIds.length > 0 ? tL('💬 Nouveau message !') : undefined}
          >
            <span className="flex flex-wrap gap-1.5">
              <PreviewChip>📞 Appel</PreviewChip>
              <PreviewChip>✉️ Email</PreviewChip>
              <PreviewChip>🎤 Vocal</PreviewChip>
            </span>
          </ModuleCard>
        </div>

      <footer className="mt-auto pt-10 pb-6 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500">
          {tL('Propulsé par')}{' '}
          <span className="font-semibold text-slate-500 dark:text-slate-400">Conciergerie Hub</span>
        </p>
      </footer>

      <ComplaintFormDialog
        open={complaintFormOpen}
        onClose={() => setComplaintFormOpen(false)}
        slug={slug}
        propertyName={property.name}
      />

      <ContactDialog
        open={contactOpen}
        onClose={() => setContactOpen(false)}
        slug={slug}
        contact={guest.contact}
        propertyName={property.name}
        newReplyCount={newReplyIds.length}
        onRepliesSeen={markRepliesSeen}
      />
      </div>
      </div>
    </HubLangContext.Provider>
  );
}

/** Carte « Commander un service » — REFONTE SERVICES PREMIUM (V4.14).
 * Tuile XXL flagship (icône 64 px ambre + promesse « 1 clic »)
 * qui ouvre un OVERLAY PLEIN ÉCRAN reprenant l'expérience complète de la
 * PWA : header serif, recherche, chips catégories, carrousel
 * « Les plus demandés », panier flottant, checkout créneau 30 min,
 * paiement Stripe et confirmation confettis. Fini le mailto ! */
function ServicesCard({
  services,
  contact,
  property,
  slug,
  photoOverride,
}: {
  services: GuestService[];
  contact: HubPayload['guest']['contact'];
  property: HubPayload['property'];
  slug: string;
  /** v4.31 — photo perso de l'hôte (sinon 1re offre photographiée sinon curated). */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);

  // Scroll lock du fond pendant l'overlay (comme les Dialog shadcn).
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const previews = services.slice(0, 4);
  const orderableCount = services.filter(
    (s) => s.offers.length > 0 || s.unitPrice != null,
  ).length;
  // v4.24 « HUB RÉEL » — la carte flagship porte la VRAIE photo du 1er
  // service photographié en filigrane (fallback : viennoiseries curated,
  // puis emoji 🥐 si la photo échoue — progressif).
  const cardPhoto =
    photoOverride ?? services.find((s) => s.imageUrl)?.imageUrl ?? HUB_VISUALS.breakfast;
  const [cardPhotoFailed, setCardPhotoFailed] = useState(false);

  return (
    <>
      {/* ── Carte flagship — v4.28 « PHOTO PLEINE CARTE » (Option A) :
          la photo du 1er service remplit TOUTE la carte ; onError →
          retour carte de crédit ambre historique (jamais de carte vide). ── */}
      {!cardPhotoFailed ? (
        <button
          type="button"
          onClick={() => services.length > 0 && setOpen(true)}
          disabled={services.length === 0}
          aria-label="Services & Expériences — commander"
          className={cn(
            'group relative mt-4 flex h-56 w-full flex-col justify-between overflow-hidden rounded-3xl border border-black/10 text-left sm:h-64 lg:mt-0',
            'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.45)] transition-[border-color,box-shadow] duration-300',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80',
            services.length === 0 && 'cursor-default opacity-60 saturate-[0.5]',
          )}
        >
          <img
            src={cardPhoto}
            alt=""
            loading="lazy"
            decoding="async"
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            onError={() => setCardPhotoFailed(true)}
          />
          <span
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/15"
          />
          {/* Rangée 1 : puce EMV dorée + flèche */}
          <span className="relative flex items-start justify-between p-4">
            <span
              aria-hidden="true"
              className="relative mt-0.5 block h-8 w-11 rounded-md border border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-inner"
            >
              <span className="absolute inset-x-0 top-1/2 h-px bg-amber-900/30" />
              <span className="absolute inset-y-0 left-1/2 w-px bg-amber-900/30" />
            </span>
            {services.length > 0 && (
              <ArrowRight
                aria-hidden="true"
                className="h-5 w-5 shrink-0 text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:translate-x-1"
              />
            )}
          </span>
          {/* Textes blancs posés sur la photo */}
          <span className="relative flex flex-col p-4 pt-0">
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-amber-200 drop-shadow-sm">
              <span aria-hidden="true" className="mr-1.5">🥐</span>
              Conciergerie · Commande en 1 clic
            </span>
            <span className="display-title font-serif! mt-0.5 text-xl font-bold leading-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.55)]">
              Services &amp; Expériences
            </span>
            <span className="mt-1 line-clamp-2 text-xs leading-snug text-white/85 drop-shadow-sm">
              {services.length > 0
                ? `Commandez en 1 clic, livré à votre porte — ${services.length} expérience${services.length > 1 ? 's' : ''} autour de ${property.name}`
                : 'Aucun service pour le moment'}
            </span>
            {services.length > 0 && (
              <span className="mt-3 flex flex-col gap-2.5 border-t border-white/25 pt-3">
                {/* Aperçus des couvertures — vignettes verre sur la photo */}
                <span className="flex flex-wrap items-center gap-2">
                  {previews.map((svc) => (
                    <ServiceCover
                      key={svc.id}
                      emoji={svc.emoji}
                      categoryLabel={svc.categoryLabel}
                      imageUrl={svc.imageUrl}
                      alt={`Photo — ${svc.name}`}
                      className="h-14 w-14 rounded-xl shrink-0"
                      emojiClassName="text-2xl"
                    />
                  ))}
                  {services.length > previews.length && (
                    <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-white/30 bg-white/20 backdrop-blur-sm">
                      <span className="text-xs font-bold text-white drop-shadow-sm">
                        +{services.length - previews.length}
                      </span>
                    </span>
                  )}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-semibold text-white/90 drop-shadow-sm">
                  {orderableCount > 0 ? (
                    <>
                      <span aria-hidden="true">⚡</span>
                      Paiement sécurisé · Créneau au choix · Suivi en direct
                    </>
                  ) : (
                    <>
                      <span aria-hidden="true">✉️</span>
                      Votre hôte organise la réservation pour vous
                    </>
                  )}
                </span>
              </span>
            )}
          </span>
        </button>
      ) : (
        /* FALLBACK — carte de crédit ambre historique (photo échouée) */
        <button
          type="button"
          onClick={() => services.length > 0 && setOpen(true)}
          disabled={services.length === 0}
          aria-label="Services & Expériences — commander"
          className={cn(
            'group relative mt-4 flex w-full flex-col overflow-hidden rounded-3xl border border-amber-200/80 p-5 text-left text-slate-900 dark:border-amber-500/25 dark:hover:border-amber-400/50 dark:text-slate-100 lg:mt-0',
            'bg-gradient-to-br from-white via-white to-amber-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-amber-950/50',
            'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.28)] transition-[border-color,box-shadow] duration-300',
            'hover:border-amber-300 hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.4)]',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/40',
            services.length === 0 && 'cursor-default opacity-60',
          )}
        >
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-2 -top-6 select-none text-[96px] leading-none opacity-[0.09]"
          >
            🥐
          </span>
        {/* Rangée 1 : puce EMV dorée + flèche */}
        <span className="relative flex items-start justify-between">
          <span
            aria-hidden="true"
            className="relative mt-0.5 block h-8 w-11 rounded-md border border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-inner"
          >
            <span className="absolute inset-x-0 top-1/2 h-px bg-amber-900/30" />
            <span className="absolute inset-y-0 left-1/2 w-px bg-amber-900/30" />
          </span>
          {services.length > 0 && (
            <ArrowRight
              aria-hidden="true"
              className="h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 group-hover:translate-x-1"
            />
          )}
        </span>

        {/* Eyebrow + titre serif */}
        <span className="relative mt-3.5 text-[10px] font-bold uppercase tracking-[0.25em] text-amber-500 dark:text-amber-300">
          <span aria-hidden="true" className="mr-1.5">🥐</span>
          Conciergerie · Commande en 1 clic
        </span>
        <span className="display-title font-serif! relative mt-0.5 text-xl font-bold leading-tight text-slate-900 dark:text-white">
          Services &amp; Expériences
        </span>
        <span className="relative mt-1 line-clamp-2 text-xs leading-snug text-slate-500 dark:text-slate-400">
          {services.length > 0
            ? `Commandez en 1 clic, livré à votre porte — ${services.length} expérience${services.length > 1 ? 's' : ''} autour de ${property.name}`
            : 'Aucun service pour le moment'}
        </span>

        {services.length > 0 && (
          <span className="relative mt-3.5 flex flex-col gap-2.5 border-t border-amber-200/60 pt-3.5 dark:border-white/10">
            {/* Aperçus des couvertures — VRAIES PHOTOS (v4.23 « hub réel »,
                fallback gradient+emoji si l'offre n'a pas de photo) */}
            <span className="flex items-center gap-2">
              {previews.map((svc) => (
                <ServiceCover
                  key={svc.id}
                  emoji={svc.emoji}
                  categoryLabel={svc.categoryLabel}
                  imageUrl={svc.imageUrl}
                  alt={`Photo — ${svc.name}`}
                  className="h-14 w-14 rounded-xl shrink-0"
                  emojiClassName="text-2xl"
                />
              ))}
              {services.length > previews.length && (
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    +{services.length - previews.length}
                  </span>
                </span>
              )}
            </span>
            <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-700 dark:text-amber-300">
              {orderableCount > 0 ? (
                <>
                  <span aria-hidden="true">⚡</span>
                  Paiement sécurisé · Créneau au choix · Suivi en direct
                </>
              ) : (
                <>
                  <span aria-hidden="true">✉️</span>
                  Votre hôte organise la réservation pour vous
                </>
              )}
            </span>
          </span>
        )}
      </button>
      )}

      {/* ── Overlay plein écran — expérience conciergerie complète ──
       * createPortal(document.body) : le portail rattache l'overlay
       * (panier flottant, checkout, bottom-sheet en fixed) au viewport,
       * indépendamment de l'arbre d'origine. */}
      {open &&
        createPortal(
          <div
            className="fixed inset-0 z-50 flex flex-col bg-background"
            role="dialog"
            aria-modal="true"
            aria-label="Services & Expériences"
          >
            {/* Header sticky : retour + titre serif */}
            <header className="shrink-0 border-b border-slate-200/70 dark:border-white/10 bg-background/85 backdrop-blur-xl">
              <div className="mx-auto max-w-lg sm:max-w-2xl px-4 h-14 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="h-9 w-9 -ml-1.5 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  aria-label="Retour au hub"
                >
                  <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                </button>
                <h1 className="font-serif text-lg font-bold text-slate-900 dark:text-white truncate">
                  🛎️ Services &amp; Expériences
                </h1>
              </div>
            </header>

            {/* Contenu scrollable = l'expérience PWA complète */}
            <div className="flex-1 overflow-y-auto overscroll-contain">
              <div className="mx-auto max-w-lg sm:max-w-2xl px-4 py-5 pb-40">
                <TabServices
                  slug={slug}
                  services={services}
                  contact={contact}
                  propertyName={property.name}
                  booking={null}
                  bookingId={null}
                  online={typeof navigator === 'undefined' ? true : navigator.onLine}
                  embedded
                  onNavigate={() => setOpen(false)}
                />
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}

// =============================================================
// MODULES PREMIUM (parité PWA) — vidéo bienvenue, guide des
// appareils, kit de survie, late check-out (upselling), bouclier
// d'avis. Données Expérience Invité + concierge servies par
// /api/public/hub/[slug] (propriétés Property.appliances /
// premiumFeatures / survivalKitItems).
// =============================================================

/** 🎬 Vidéo de bienvenue — média local → lecteur intégré (<video>) ;
 * YouTube/Vimeo/Loom → bouton d'ouverture (la CSP bloque les iframes
 * externes, choix sécurité assumé — cf. isYouTubeUrl()). */
function WelcomeVideoCard({
  url,
  propertyName,
  open,
  onOpenChange,
  photoOverride,
}: {
  url: string;
  propertyName: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const local = isLocalMediaUrl(url);
  const yt = isYouTubeUrl(url);
  return (
    <>
      <ModuleCard
        emoji="🎬"
        tone="rose"
        eyebrow="Message de votre hôte"
        title="Vidéo de bienvenue"
        subtitle="Votre hôte vous explique tout en vidéo"
        imageUrl={photoOverride ?? HUB_VISUALS.welcome}
        onClick={local ? () => onOpenChange(true) : () => window.open(url, '_blank', 'noopener,noreferrer')}
      >
        <span className="flex flex-wrap gap-1.5">
          <PreviewChip>{local ? '▶ Lecture intégrée' : '▶ Ouvrir la vidéo'}</PreviewChip>
        </span>
      </ModuleCard>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900">
              🎬 Vidéo de bienvenue — {propertyName}
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              {local ? 'Lecture intégrée.' : 'La vidéo est hébergée en externe (YouTube, Vimeo, Loom) — elle s’ouvre dans un nouvel onglet.'}
            </DialogDescription>
          </DialogHeader>
          {local ? (
            <video
              controls
              autoPlay
              playsInline
              className="w-full rounded-xl border border-slate-200 bg-black"
              src={url}
            />
          ) : (
            <Button
              type="button"
              className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
              onClick={() => window.open(url, '_blank', 'noopener,noreferrer')}
            >
              <Play className="h-4 w-4" aria-hidden="true" /> Ouvrir la vidéo
            </Button>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

/** 🛠️ Guide des appareils — Property.appliances (rempli dans
 * /airbnb/concierge) : instructions + photo + vidéo par appareil.
 * Task 30 : tuile grille + dialog immersif (accordéons inchangés). */
function AppliancesCard({
  appliances,
  photoOverride,
}: {
  appliances: GuestAppliance[];
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({});
  return (
    <>
      <ModuleCard
        emoji="🛠️"
        tone="violet"
        eyebrow="Équipements"
        title="Guide des appareils"
        subtitle={`${appliances.length} équipement${appliances.length > 1 ? 's' : ''} expliqué${appliances.length > 1 ? 's' : ''} par votre hôte`}
        imageUrl={photoOverride ?? HUB_VISUALS.appliances}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {appliances.slice(0, 3).map((app) => (
            <PreviewChip key={app.id}>
              <span aria-hidden="true">{app.emoji || '🛠️'}</span> {app.name}
            </PreviewChip>
          ))}
          {appliances.length > 3 && <PreviewChip>+{appliances.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🛠️"
        tone="violet"
        title="Guide des appareils"
        subtitle={`${appliances.length} équipement${appliances.length > 1 ? 's' : ''} expliqué${appliances.length > 1 ? 's' : ''} par votre hôte`}
      >
        <div className="space-y-2.5">
          {appliances.map((app) => {
            const isOpen = !!openIds[app.id];
            return (
              <div key={app.id} className="bg-slate-50 border border-slate-200 rounded-lg dark:bg-white/5 dark:border-white/10">
                <button
                  type="button"
                  className="w-full flex items-center gap-3 p-3 text-left"
                  onClick={() => setOpenIds((m) => ({ ...m, [app.id]: !m[app.id] }))}
                  aria-expanded={isOpen}
                >
                  <span className="text-2xl leading-none select-none" aria-hidden="true">{app.emoji || '🛠️'}</span>
                  <span className="flex-1 min-w-0 text-sm font-bold text-slate-900 dark:text-white">{app.name}</span>
                  <ChevronRight
                    className={cn('h-4 w-4 text-slate-400 transition-transform shrink-0', isOpen && 'rotate-90')}
                    aria-hidden="true"
                  />
                </button>
                {isOpen && (
                  <div className="px-3 pb-3">
                    <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap dark:text-slate-300">
                      {app.instructions}
                    </p>
                    {app.imageUrl && (
                      <img
                        src={app.imageUrl}
                        alt={`Photo de ${app.name}`}
                        loading="lazy"
                        decoding="async"
                        className="mt-2 w-full rounded-xl object-cover aspect-[4/3] border border-slate-200 dark:border-white/10"
                      />
                    )}
                    {app.videoUrl && (
                      isLocalMediaUrl(app.videoUrl) ? (
                        <video
                          controls
                          playsInline
                          preload="metadata"
                          className="mt-2 w-full rounded-xl border border-slate-200 bg-black dark:border-white/10"
                          src={app.videoUrl}
                        />
                      ) : (
                        <a
                          href={app.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                        >
                          <Play className="h-3.5 w-3.5" aria-hidden="true" /> Voir la vidéo {isYouTubeUrl(app.videoUrl) ? '(YouTube)' : ''}
                        </a>
                      )
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </TileDialog>
    </>
  );
}

/** 🧰 Kit de survie — Property.survivalKitItems (Expérience Invité) :
 * où sont rangés les objets utiles (trousse, parapluie, piles…).
 * Task 30 : tuile grille + dialog immersif (liste inchangée). */
function SurvivalKitCard({
  items,
  photoOverride,
}: {
  items: GuestSurvivalItem[];
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="🧰"
        tone="orange"
        eyebrow="Rangement malin"
        title="Kit de survie"
        subtitle={`${items.length} objet${items.length > 1 ? 's' : ''} indispensable${items.length > 1 ? 's' : ''} et leur emplacement`}
        imageUrl={photoOverride ?? HUB_VISUALS.survival}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {items.slice(0, 3).map((item) => (
            <PreviewChip key={item.id}>{item.name}</PreviewChip>
          ))}
          {items.length > 3 && <PreviewChip>+{items.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🧰"
        tone="orange"
        title="Kit de survie"
        subtitle={`${items.length} objet${items.length > 1 ? 's' : ''} indispensable${items.length > 1 ? 's' : ''} et leur emplacement`}
      >
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
              <span className="text-xl leading-none select-none" aria-hidden="true">🧰</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white">{item.name}</p>
                {item.location && (
                  <p className="text-xs text-slate-500 mt-0.5 dark:text-slate-400">📍 {item.location}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </TileDialog>
    </>
  );
}

/** ⏱️ Départ tardif (upselling) — demande POST /api/public/hub/[slug]/
 * late-checkout (le serveur vérifie que le service est activé).
 * Task 30 : tuile grille + dialog avec CTA (logique d'envoi inchangée). */
function LateCheckoutCard({
  slug,
  price,
  propertyName,
  photoOverride,
  urgentLabel,
}: {
  slug: string;
  price?: number;
  propertyName: string;
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
  /** v4.32 — clignotement rouge (veille/jour du départ). */
  urgentLabel?: string;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const request = async () => {
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/late-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      toast.success(data.message || 'Demande envoyée — votre hôte vous confirme rapidement.');
      setSent(true);
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Demande impossible. Réessayez dans un instant.');
    } finally {
      setSending(false);
    }
  };
  return (
    <>
      <ModuleCard
        emoji="⏱️"
        tone="amber"
        eyebrow="Extension de séjour"
        title="Départ tardif"
        subtitle={price != null ? `Restez jusqu’à 14 h — ${formatEur(price)}` : 'Restez jusqu’à 14 h'}
        imageUrl={photoOverride ?? HUB_VISUALS.lateCheckout}
        onClick={sent ? undefined : () => setOpen(true)}
        urgentLabel={urgentLabel}
      >
        <span className="flex flex-wrap gap-1.5">
          {sent ? (
            <PreviewChip>✅ Demande envoyée</PreviewChip>
          ) : (
            <PreviewChip>🕑 Jusqu’à 14 h</PreviewChip>
          )}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="⏱️"
        tone="amber"
        title="Départ tardif"
        subtitle={
          price != null
            ? `Restez jusqu’à 14 h — ${formatEur(price)} (proposé par votre hôte)`
            : 'Restez jusqu’à 14 h — proposé par votre hôte'
        }
      >
        <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
          Envie de profiter encore un peu de {propertyName} ? Demandez un départ tardif :
          votre hôte vous confirme rapidement par notification.
        </p>
        {!sent && (
          <Button
            type="button"
            size="sm"
            className="mt-3 w-full h-10 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
            onClick={request}
            disabled={sending}
            aria-label={`Demander un départ tardif pour ${propertyName}`}
          >
            {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Clock4 className="h-3.5 w-3.5" aria-hidden="true" />}
            {sending ? 'Envoi…' : 'Demander un départ tardif'}
          </Button>
        )}
        {sent && (
          <p className="mt-3 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
            ✅ Demande envoyée — votre hôte vous confirme.
          </p>
        )}
      </TileDialog>
    </>
  );
}

/** ⭐ Bouclier d'avis — l'invité ravi est dirigé vers l'avis public
 * (reviewUrl) ; l'invité déçu s'exprime EN PRIVÉ (POST …/private-feedback,
 * alerte immédiate hôte) — le mauvais avis n'atterrit jamais sur
 * Airbnb/Booking avant que l'hôte ait pu régler le souci. */
function ReviewShieldCard({
  slug,
  propertyName,
  reviewUrl,
  open,
  onOpenChange,
  photoOverride,
  urgentLabel,
}: {
  slug: string;
  propertyName: string;
  reviewUrl?: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
  /** v4.32 — clignotement rouge (tous les jours à partir de 20 h). */
  urgentLabel?: string;
}) {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [guestName, setGuestName] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (rating < 1) {
      toast.error('Choisissez une note (1 à 5 étoiles).');
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/private-feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating,
          comment: comment.trim() || undefined,
          guestName: guestName.trim() || undefined,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      setDone(true);
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Envoi impossible. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  const reset = () => {
    onOpenChange(false);
    setTimeout(() => {
      setDone(false);
      setRating(0);
      setComment('');
      setGuestName('');
    }, 300);
  };

  return (
    <>
      <ModuleCard
        emoji="⭐"
        tone="rose"
        eyebrow="Votre avis compte"
        title="Bouclier d’avis"
        subtitle="Dites-le d’abord à votre hôte, en privé"
        imageUrl={photoOverride ?? HUB_VISUALS.review}
        onClick={() => onOpenChange(true)}
        urgentLabel={urgentLabel}
      >
        <span className="flex flex-wrap gap-1.5">
          <PreviewChip>🔒 100 % privé</PreviewChip>
          <PreviewChip>⭐ 1 à 5 étoiles</PreviewChip>
        </span>
      </ModuleCard>
      <Dialog open={open} onOpenChange={(v) => !sending && (v ? onOpenChange(true) : reset())}>
        <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl dark:border-white/10 dark:bg-slate-900 dark:text-slate-100">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 dark:text-white">
              ⭐ Votre avis — {propertyName}
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500 dark:text-slate-400">
              {done
                ? 'Merci ! Votre retour a été transmis.'
                : 'Un souci ? Votre message arrive directement et en privé à votre hôte, qui pourra le corriger.'}
            </DialogDescription>
          </DialogHeader>

          {done ? (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                {rating >= 4
                  ? 'Merci beaucoup ! 🎉'
                  : 'Merci, votre hôte est prévenu et va vous répondre. 💬'}
              </p>
              {rating >= 4 && reviewUrl && (
                <Button
                  type="button"
                  className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                  onClick={() => window.open(reviewUrl, '_blank', 'noopener,noreferrer')}
                >
                  <Star className="h-4 w-4" aria-hidden="true" /> Laisser un avis public
                </Button>
              )}
              <Button
                type="button"
                variant="outline"
                className="w-full h-10 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300 dark:hover:bg-white/10"
                onClick={reset}
              >
                Fermer
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex justify-center gap-1.5" role="radiogroup" aria-label="Note de 1 à 5 étoiles">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    role="radio"
                    aria-checked={rating === n}
                    aria-label={`${n} étoile${n > 1 ? 's' : ''}`}
                    onMouseEnter={() => setHover(n)}
                    onMouseLeave={() => setHover(0)}
                    onClick={() => setRating(n)}
                    className="p-1 rounded-lg transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                  >
                    <Star
                      className={cn(
                        'h-8 w-8 transition-colors',
                        (hover || rating) >= n
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 dark:text-slate-600',
                      )}
                      aria-hidden="true"
                    />
                  </button>
                ))}
              </div>
              <Textarea
                placeholder="Votre message (optionnel) — ce qui vous a plu ou déplu"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                maxLength={2000}
                rows={3}
                className="resize-none text-sm"
              />
              <Input
                placeholder="Votre prénom (optionnel)"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                maxLength={80}
                className="h-10 text-sm"
              />
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="h-10 flex-1 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300 dark:hover:bg-white/10"
                  onClick={reset}
                  disabled={sending}
                >
                  Annuler
                </Button>
                <Button
                  type="button"
                  className="h-10 flex-1 bg-slate-900 hover:bg-slate-800 text-white font-semibold dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200"
                  onClick={submit}
                  disabled={sending || rating < 1}
                >
                  {sending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ShieldCheck className="h-4 w-4" aria-hidden="true" />}
                  Envoyer
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// =============================================================
// MODULES INVITÉS (parité PWA) — coffre-fort, guide visuel,
// quartier, SOS. Bug dashboard→hub : les données remplies dans
// /airbnb/concierge et l'Expérience Invité apparaissent désormais
// dans le hub QR, avec le même design premium glass.
// =============================================================

/** 🔑 Accès & Codes — coffre-fort numérique (bâtiment, boîte aux
 * lettres, parking, alarme, coffre). Valeur masquée par défaut,
 * révélation au clic + copie avec toast (même copy() que le Wi-Fi). */
function AccessCodesCard({
  codes,
  copy,
  photoOverride,
}: {
  codes: GuestAccessCodes;
  copy: (text: string, label: string) => Promise<void>;
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const rows = accessCodeRows(codes);

  return (
    <>
      <ModuleCard
        emoji="🔑"
        tone="emerald"
        eyebrow="Trousseau numérique"
        title="Accès & Codes"
        subtitle="Portes, coffre-fort, parking… vos codes en un clin d’œil"
        imageUrl={photoOverride ?? HUB_VISUALS.access}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {rows.slice(0, 3).map((row) => (
            <PreviewChip key={row.label}>
              <span aria-hidden="true">{row.emoji}</span> {row.label}
            </PreviewChip>
          ))}
          {rows.length > 3 && <PreviewChip>+{rows.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🔑"
        tone="emerald"
        title="Accès & Codes"
        subtitle="Bâtiment, coffre-fort, parking… votre trousseau numérique"
      >
        <div className="space-y-2.5">
          {rows.map((row) => {
            const shown = !!revealed[row.label];
            return (
              <div key={row.label} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <span className="text-xl leading-none select-none" aria-hidden="true">{row.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{row.label}</p>
                    <p className={cn(
                      'font-mono text-sm font-bold mt-0.5 truncate',
                      shown ? 'text-slate-900 dark:text-white' : 'text-slate-400 dark:text-slate-500',
                    )}>
                      {shown ? row.value : '••••••'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 px-2.5"
                      onClick={() => setRevealed((m) => ({ ...m, [row.label]: !m[row.label] }))}
                      aria-label={shown ? `Masquer ${row.label}` : `Révéler ${row.label}`}
                    >
                      <span aria-hidden="true">{shown ? '🙈' : '👁️'}</span>
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 px-2.5"
                      onClick={() => copy(row.value, row.label)}
                      aria-label={`Copier ${row.label}`}
                    >
                      <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
          {codes.note && (
            <p className="text-xs text-slate-500 leading-relaxed px-1 dark:text-slate-400">📝 {codes.note}</p>
          )}
          <p className="text-[11px] text-slate-400 text-center">
            Codes confidentiels — ne les partagez qu’avec vos compagnons de voyage.
          </p>
        </div>
      </TileDialog>
    </>
  );
}

/** 🗺️ Arrivée pas à pas — guide visuel (façade, digicode, porte…)
 * rempli dans l'Expérience Invité → Property.visualGuide.
 * Task 30 : tuile grille + dialog immersif (étapes inchangées). */
function VisualGuideCard({
  steps,
  photoOverride,
}: {
  steps: GuestVisualStep[];
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="🗺️"
        tone="emerald"
        eyebrow="Arrivée"
        title="Arrivée pas à pas"
        subtitle={`${steps.length} étape${steps.length > 1 ? 's' : ''} illustrée${steps.length > 1 ? 's' : ''} jusqu’à votre logement`}
        imageUrl={photoOverride ?? HUB_ARRIVAL_PHOTOS.facade}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {steps.slice(0, 2).map((step) => (
            <PreviewChip key={step.id}>{step.title}</PreviewChip>
          ))}
          {steps.length > 2 && <PreviewChip>+{steps.length - 2}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🗺️"
        tone="emerald"
        title="Arrivée pas à pas"
        subtitle={`${steps.length} étape${steps.length > 1 ? 's' : ''} illustrée${steps.length > 1 ? 's' : ''} jusqu’à votre logement`}
      >
        <div className="space-y-3">
          {steps.map((step, i) => (
            <div key={step.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
              <p className="text-sm font-bold text-slate-900 dark:text-white">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-slate-900 text-white text-[10px] font-bold mr-1.5 align-middle dark:bg-white dark:text-slate-900">
                  {i + 1}
                </span>
                {step.title}
              </p>
              {step.description && (
                <p className="text-xs text-slate-600 mt-1 leading-relaxed dark:text-slate-300">{step.description}</p>
              )}
              {step.imageUrl && (
                <img
                  src={step.imageUrl}
                  alt={step.title}
                  loading="lazy"
                  className="mt-2 w-full rounded-xl object-cover aspect-[4/3] border border-slate-200 dark:border-white/10"
                />
              )}
            </div>
          ))}
        </div>
      </TileDialog>
    </>
  );
}

/** 📍 Quartier & bonnes adresses — carte secrète de l’hôte
 * (Property.localSpots) avec lien « Y aller » natif (Apple/Google Maps).
 * Task 30 : tuile grille + dialog immersif (adresses inchangées). */
function LocalSpotsCard({
  spots,
  photoOverride,
}: {
  spots: GuestSpot[];
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="📍"
        tone="teal"
        eyebrow="Carte secrète"
        title="Bonnes adresses"
        subtitle={`${spots.length} adresse${spots.length > 1 ? 's' : ''} secrète${spots.length > 1 ? 's' : ''} de votre hôte`}
        imageUrl={photoOverride ?? HUB_VISUALS.spots}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {spots.slice(0, 3).map((spot) => (
            <PreviewChip key={spot.id}>
              <span aria-hidden="true">{spotCategoryMeta(spot.category).emoji}</span> {spot.name}
            </PreviewChip>
          ))}
          {spots.length > 3 && <PreviewChip>+{spots.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="📍"
        tone="teal"
        title="Quartier & bonnes adresses"
        subtitle={`${spots.length} adresse${spots.length > 1 ? 's' : ''} secrète${spots.length > 1 ? 's' : ''} de votre hôte`}
      >
        <div className="space-y-2.5">
          {spots.map((spot) => {
            const meta = spotCategoryMeta(spot.category);
            return (
              <div key={spot.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                <div className="flex items-start gap-3">
                  <span className="text-2xl leading-none select-none" aria-hidden="true">{meta.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <p className="text-sm font-bold text-slate-900 dark:text-white">{spot.name}</p>
                      <Badge className="bg-amber-50 border-amber-200 text-amber-700 font-semibold hover:bg-amber-50 shrink-0 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300 dark:hover:bg-amber-500/10">
                        {meta.label}
                      </Badge>
                    </div>
                    {spot.address && <p className="text-[11px] text-slate-400 mt-0.5">{spot.address}</p>}
                    {spot.hostNote && (
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed dark:text-slate-300">💬 {spot.hostNote}</p>
                    )}
                    <a
                      href={geoDirectionsUrl(spot.lat, spot.lng)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300 dark:hover:text-emerald-200"
                    >
                      <span aria-hidden="true">🧭</span> Y aller
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </TileDialog>
    </>
  );
}

/** 🆘 SOS & Urgences — TOUJOURS visible : numéros nationaux (112/15/18),
 * police (custom ou 17), urgence logement (emergencyInfo.hostPhone),
 * hôpital/pharmacie de garde (Property.emergencyInfo) et pannes courantes. */
function SosCard({
  emergency,
  photoOverride,
}: {
  emergency: GuestEmergencyInfo | null;
  /** v4.31 — photo perso de l'hôte. */
  photoOverride?: string | null;
}) {
  const [open, setOpen] = useState(false);
  const telHref = (n: string) => `tel:${n.replace(/[^+\d]/g, '')}`;
  const numbers = [
    { label: 'Urgences (UE)', number: '112', tone: 'red' as const },
    { label: 'SAMU', number: '15', tone: 'red' as const },
    { label: 'Pompiers', number: '18', tone: 'red' as const },
    { label: 'Police', number: emergency?.police ?? '17', tone: 'red' as const },
    ...(emergency?.hostPhone
      ? [{ label: 'Urgence logement', number: emergency.hostPhone, tone: 'emerald' as const }]
      : []),
  ];
  return (
    <>
      <ModuleCard
        emoji="🆘"
        tone="red"
        eyebrow="Urgences 24/7"
        title="SOS & Urgences"
        subtitle="Numéros, hôpital, pharmacie de garde"
        imageUrl={photoOverride ?? HUB_VISUALS.sos}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {numbers.slice(0, 4).map((n) => (
            <PreviewChip key={n.label}>☎️ {n.number}</PreviewChip>
          ))}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🆘"
        tone="red"
        title="SOS & Urgences"
        subtitle="Numéros d’urgence, hôpital, pharmacie de garde"
      >
        <div className="space-y-2.5">
          <div className="grid grid-cols-2 gap-2">
            {numbers.map((n) => (
              <a
                key={n.label}
                href={telHref(n.number)}
                className={cn(
                  'rounded-lg border p-3 flex items-center gap-2.5 transition-transform active:scale-[0.98]',
                  n.tone === 'emerald'
                    ? 'bg-emerald-50 border-emerald-200 dark:bg-emerald-500/10 dark:border-emerald-500/30'
                    : 'bg-red-50 border-red-200 dark:bg-red-500/10 dark:border-red-500/30',
                )}
              >
                <Phone
                  className={cn(
                    'h-4 w-4 shrink-0',
                    n.tone === 'emerald' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400',
                  )}
                  aria-hidden="true"
                />
                <span className="min-w-0">
                  <span className={cn(
                    'block text-[11px] font-semibold uppercase tracking-wide',
                    n.tone === 'emerald' ? 'text-emerald-500' : 'text-red-400',
                  )}>
                    {n.label}
                  </span>
                  <span className={cn(
                    'block text-sm font-bold truncate',
                    n.tone === 'emerald' ? 'text-emerald-700 dark:text-emerald-300' : 'text-red-700 dark:text-red-300',
                  )}>
                    {n.number}
                  </span>
                </span>
              </a>
            ))}
          </div>

          {(emergency?.hospital || emergency?.pharmacy) && (
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-3 dark:bg-white/5 dark:border-white/10">
              {emergency?.hospital && (
                <div className="flex items-start gap-2.5">
                  <span className="text-xl leading-none select-none" aria-hidden="true">🏥</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Hôpital le plus proche</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{emergency.hospital}</p>
                    {emergency.hospitalLat != null && emergency.hospitalLng != null && (
                      <a
                        href={geoDirectionsUrl(emergency.hospitalLat, emergency.hospitalLng)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 mt-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                      >
                        <span aria-hidden="true">🧭</span> Y aller
                      </a>
                    )}
                  </div>
                </div>
              )}
              {emergency?.pharmacy && (
                <div className="flex items-start gap-2.5">
                  <span className="text-xl leading-none select-none" aria-hidden="true">💊</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Pharmacie de garde</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{emergency.pharmacy}</p>
                    {emergency.pharmacyPhone && (
                      <a
                        href={telHref(emergency.pharmacyPhone)}
                        className="inline-flex items-center gap-1 mt-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                      >
                        <Phone className="h-3 w-3" aria-hidden="true" /> {emergency.pharmacyPhone}
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {(emergency?.commonIssues.length ?? 0) > 0 && (
            <div className="space-y-2">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Pannes courantes</p>
              {emergency!.commonIssues.map((issue) => (
                <details key={issue.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                  <summary className="text-sm font-bold text-slate-900 cursor-pointer dark:text-white">
                    <span className="mr-1.5" aria-hidden="true">🔧</span>{issue.title}
                  </summary>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed whitespace-pre-line dark:text-slate-300">
                    {issue.instructions}
                  </p>
                </details>
              ))}
            </div>
          )}
        </div>
      </TileDialog>
    </>
  );
}

// =============================================================
// MODE HÔTE — grille de gestion rapide (après PIN)
// =============================================================
function HostView({
  payload,
  hostData,
  slug,
  pin,
  onBack,
  onHostRefresh,
  onPinChanged,
  onHubPhotosSaved,
}: {
  payload: HubPayload;
  hostData: HostData | null;
  slug: string;
  pin: string;
  onBack: () => void;
  onHostRefresh: (d: HostData) => void;
  onPinChanged: (pin: string) => void;
  /** v4.31 — photos perso sauvegardées (répercutées sur le payload invité). */
  onHubPhotosSaved: (map: HubPhotoMap) => void;
}) {
  const [wifiEditOpen, setWifiEditOpen] = useState(false);
  const [complaintsOpen, setComplaintsOpen] = useState(false);
  const [providersOpen, setProvidersOpen] = useState(false);
  const [guidebookOpen, setGuidebookOpen] = useState(false);
  const [upsellingOpen, setUpsellingOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  // v4.31 « PHOTOS DE MON HUB » — état local initialisé depuis le payload.
  const [photosOpen, setPhotosOpen] = useState(false);
  const [photosMap, setPhotosMap] = useState<HubPhotoMap>(
    () => payload.property.hubPhotos ?? {},
  );
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  // ── v4.32 — BADGE « NON LUS » ──
  // Le badge rouge ne compte plus les réclamations OPEN mais les
  // notifications NON LUES (vocaux non écoutés + réclamations jamais
  // affichées). Une réclamation lue mais encore ouverte reste dans la
  // liste, sans allumer le badge. Les marques locales (seenVoiceIds /
  // complaintsSeen) décrémentent immédiatement sans retirer l'élément
  // de la liste affichée (pas de disparition en pleine écoute) ; un
  // refreshHost resynchronise sur la vérité serveur.
  const [seenVoiceIds, setSeenVoiceIds] = useState<Set<string>>(new Set());
  const [complaintsSeen, setComplaintsSeen] = useState(false);
  const unread = (hostData?.unreadMessages ?? []).filter((m) => !seenVoiceIds.has(m.id)).length;
  const written = hostData?.openComplaints ?? 0;
  const unreadComplaints = complaintsSeen ? 0 : (hostData?.unreadComplaints ?? written);
  const totalAlerts = unread + unreadComplaints;

  /** v4.32 — marque des vocaux « lus » côté serveur (POST host-read, PIN). */
  const markVoicesRead = useCallback(
    async (ids: string[]) => {
      if (ids.length === 0) return;
      setSeenVoiceIds((prev) => new Set([...prev, ...ids]));
      try {
        await fetch(`/api/public/hub/${encodeURIComponent(slug)}/host-read`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin, voiceIds: ids }),
        });
      } catch {
        // silencieux : la marque locale reste, re-synchronisée au refresh
      }
    },
    [slug, pin],
  );

  // Ouverture du dialog Réclamations = notifications vues (badge éteint),
  // y compris pour les messages vocaux listés dedans.
  useEffect(() => {
    if (!complaintsOpen) return;
    setComplaintsSeen(true);
    const ids = (hostData?.unreadMessages ?? []).map((m) => m.id);
    if (ids.length > 0) void markVoicesRead(ids);
  }, [complaintsOpen]);

  // ── Commandes ServiceOrder (badge Upselling + dialog) ──
  // Fetch au montage et à chaque refreshOrders() (après PATCH ou
  // réouverture du dialog) — le badge compte les PENDING.
  const [orders, setOrders] = useState<HostOrder[] | null>(null);
  const [ordersTick, setOrdersTick] = useState(0);
  const refreshOrders = useCallback(() => setOrdersTick((t) => t + 1), []);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        if (!res.ok || cancelled) return;
        const json = (await res.json()) as { orders: HostOrder[] };
        if (!cancelled) setOrders(json.orders);
      } catch {
        // Silencieux : le badge reste absent, une nouvelle tentative
        // est déclenchée à la réouverture du dialog.
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [slug, pin, ordersTick]);

  const pendingOrders = orders?.filter((o) => o.status === 'PENDING').length ?? 0;
  const [patching, setPatching] = useState<string | null>(null);

  /** Rafraîchit les données hôte (après édition guidebook / résolution). */
  const refreshHost = useCallback(async () => {
    try {
      const hostRes = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/host`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      });
      if (hostRes.ok) {
        onHostRefresh((await hostRes.json()) as HostData);
        // La vérité serveur remplace les marques locales.
        setSeenVoiceIds(new Set());
        setComplaintsSeen(false);
      }
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    }
  }, [slug, pin, onHostRefresh]);

  /** Marque une réclamation écrite résolue (garde PIN) puis rafraîchit. */
  const resolveComplaint = async (id: string) => {
    setResolvingId(id);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/complaint`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, id, status: 'RESOLVED' }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        toast.error(j.error || 'Impossible de marquer comme résolue.');
        return;
      }
      toast.success('Réclamation marquée résolue ✓');
      await refreshHost();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  };

  /** Confirme ou annule une commande PENDING (PATCH /orders, garde PIN). */
  const patchOrder = async (orderId: string, action: 'CONFIRM' | 'CANCEL') => {
    setPatching(orderId);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/orders`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, orderId, action }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Action impossible.');
        return;
      }
      toast.success(action === 'CONFIRM' ? 'Commande confirmée ✓' : 'Commande annulée.');
      refreshOrders();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setPatching(null);
    }
  };

  // ── v4.32 « PRESTATAIRES AUTOUR » — ACTIVER / DÉSACTIVER (demande client :
  // au cas où l'hôte ne veut pas activer un prestataire proposé). L'état
  // optimiste (providerOverrides) rend le toggle instantané ; un
  // refreshHost resynchronise ensuite sur la vérité serveur. Un
  // prestataire désactivé disparaît des services invités (hub + PWA).
  const [providerOverrides, setProviderOverrides] = useState<Record<string, boolean>>({});
  const [togglingProviderId, setTogglingProviderId] = useState<string | null>(null);
  const providerEnabled = (p: HostProvider) => providerOverrides[p.id] ?? p.enabled;
  const toggleProvider = async (p: HostProvider) => {
    const next = !providerEnabled(p);
    setTogglingProviderId(p.id);
    setProviderOverrides((prev) => ({ ...prev, [p.id]: next }));
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/providers-toggle`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, providerId: p.id, enabled: next }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Action impossible.');
        setProviderOverrides((prev) => ({ ...prev, [p.id]: !next }));
        return;
      }
      toast.success(
        next
          ? `${p.name} activé ✓ — visible côté invité.`
          : `${p.name} désactivé — masqué côté invité.`,
      );
      await refreshHost();
      setProviderOverrides((prev) => {
        const copy = { ...prev };
        delete copy[p.id];
        return copy;
      });
    } catch {
      toast.error('Erreur réseau. Réessayez.');
      setProviderOverrides((prev) => ({ ...prev, [p.id]: !next }));
    } finally {
      setTogglingProviderId(null);
    }
  };

  return (
    <div className="flex-1 w-full max-w-lg sm:max-w-2xl mx-auto px-4 py-8 flex flex-col">
      {/* Fond premium animé (fixed, -z-10) */}
      <AnimatedMeshGradient />

      {/* En-tête — fade-in + slide-down */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, ease: EASE_EXPO }}
        className="flex items-center gap-3 mb-2"
      >
        <button
          type="button"
          onClick={onBack}
          aria-label="Retour à l'accueil"
          className="h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] text-slate-600 hover:text-slate-900 transition-colors dark:text-slate-300 dark:hover:text-white"
        >
          <ChevronLeft className="h-5 w-5" aria-hidden="true" />
        </button>
        <div className="min-w-0">
          <h1 className="display-title font-serif! text-lg font-bold text-slate-900 leading-tight dark:text-white">🔐 Espace Hôte</h1>
          <p className="text-xs text-slate-500 truncate dark:text-slate-400">{payload.property.name}</p>
        </div>
        <Badge className="ml-auto bg-emerald-50 border-emerald-200 text-emerald-700 font-semibold hover:bg-emerald-50 shrink-0 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300 dark:hover:bg-emerald-500/10">
          ✓ Déverrouillé
        </Badge>
      </motion.div>
      <p className="text-sm text-slate-600 mb-5 dark:text-slate-400">Gestion rapide du logement</p>

      {!hostData ? (
        <div className="space-y-3" aria-busy="true">
          <Skeleton className="h-20 rounded-xl" />
          <Skeleton className="h-20 rounded-xl" />
          <Skeleton className="h-20 rounded-xl" />
        </div>
      ) : (
        <div className="grid gap-3">
          {/* 📶 Modifier le Wi-Fi */}
          <Reveal delay={0.05} y={20}>
            <HostActionCard
              emoji="📶"
              title="Modifier le Wi-Fi"
              subtitle={
                hostData.wifi?.networkName ? `Réseau : ${hostData.wifi.networkName}` : 'Aucun réseau configuré'
              }
              onClick={() => setWifiEditOpen(true)}
            />
          </Reveal>
          {/* 📖 Guidebook — édition (AUD-FULL ⑥) */}
          <Reveal delay={0.1} y={20}>
            <HostActionCard
              emoji="📖"
              title="Guidebook"
              subtitle={
                hostData.guidebook.sections.length > 0
                  ? `${hostData.guidebook.sections.length} section(s) — éditer le guide de bienvenue`
                  : 'Aucune section — écrire le guide de bienvenue'
              }
              onClick={() => setGuidebookOpen(true)}
            />
          </Reveal>
          {/* 🚨 Réclamations en attente (vocales + écrites) */}
          <Reveal delay={0.15} y={20}>
            <HostActionCard
              emoji="🚨"
              title="Réclamations en attente"
              subtitle={
                totalAlerts > 0
                  ? `${written} écrite(s) · ${unread} vocale(s)${
                      hostData.pendingRequests > 0 ? ` · ${hostData.pendingRequests} demande(s) de service` : ''
                    }`
                  : 'Aucune réclamation en attente ✓'
              }
              badge={totalAlerts > 0 ? String(totalAlerts) : undefined}
              onClick={() => setComplaintsOpen(true)}
            />
          </Reveal>
          {/* 💰 Upselling — commandes invitées (ServiceOrder) */}
          <Reveal delay={0.2} y={20}>
            <HostActionCard
              emoji="💰"
              title="Upselling — Commandes"
              subtitle={
                pendingOrders > 0
                  ? `${pendingOrders} commande(s) à confirmer`
                  : orders && orders.length > 0
                    ? `${orders.length} commande(s) — rien à confirmer ✓`
                    : 'Aucune commande pour le moment'
              }
              badge={pendingOrders > 0 ? String(pendingOrders) : undefined}
              onClick={() => {
                setUpsellingOpen(true);
                refreshOrders();
              }}
            />
          </Reveal>
          {/* 🧹 Gérer les prestataires */}
          <Reveal delay={0.25} y={20}>
            <HostActionCard
              emoji="🧹"
              title="Gérer les prestataires"
              subtitle={`${hostData.providers.length} intervenant(s) autour du bien`}
              onClick={() => setProvidersOpen(true)}
            />
          </Reveal>
          {/* 📸 Photos de mon hub (v4.31 — personnalisation des cartes photo) */}
          <Reveal delay={0.27} y={20}>
            <HostActionCard
              emoji="📸"
              title="Photos de mon hub"
              subtitle={
                Object.keys(photosMap).length > 0
                  ? `${Object.keys(photosMap).length} photo(s) personnalisée(s) — votre hub 100 % à vous`
                  : 'Remplacez les visuels par vos vraies photos'
              }
              onClick={() => setPhotosOpen(true)}
            />
          </Reveal>
          {/* ⚙️ Paramètres — changement de PIN */}
          <Reveal delay={0.3} y={20}>
            <HostActionCard
              emoji="⚙️"
              title="Paramètres"
              subtitle="Gérer le code PIN d'accès au mode hôte"
              onClick={() => setSettingsOpen(true)}
            />
          </Reveal>
        </div>
      )}

      <footer className="mt-auto pt-10 pb-6 text-center">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Propulsé par 🗝️ <span className="font-semibold text-slate-600 dark:text-slate-300">Conciergerie Hub</span>
        </p>
      </footer>

      {/* ----- Dialog : Modifier le Wi-Fi ----- */}
      {hostData && wifiEditOpen && (
        <WifiEditDialog
          onClose={() => setWifiEditOpen(false)}
          slug={slug}
          pin={pin}
          wifi={hostData.wifi}
          onSaved={(w) => onHostRefresh({ ...hostData, wifi: w })}
        />
      )}

      {/* ----- Dialog : Édition du Guidebook ----- */}
      {hostData && guidebookOpen && (
        <GuidebookEditDialog
          onClose={() => setGuidebookOpen(false)}
          slug={slug}
          pin={pin}
          guidebook={hostData.guidebook}
          onSaved={refreshHost}
        />
      )}

      {/* ----- Dialog : Upselling (commandes invitées) ----- */}
      {upsellingOpen && (
        <UpsellingDialog
          onClose={() => setUpsellingOpen(false)}
          orders={orders}
          patchingId={patching}
          onPatch={patchOrder}
        />
      )}

      {/* ----- Dialog : Paramètres (changement de PIN) ----- */}
      {settingsOpen && (
        <SettingsPinDialog
          onClose={() => setSettingsOpen(false)}
          slug={slug}
          pin={pin}
          onPinChanged={onPinChanged}
        />
      )}

      {/* ----- Dialog : 📸 Photos de mon hub (v4.31) ----- */}
      {photosOpen && (
        <HubPhotosDialog
          onClose={() => setPhotosOpen(false)}
          slug={slug}
          pin={pin}
          initial={photosMap}
          onSaved={(m) => {
            setPhotosMap(m);
            onHubPhotosSaved(m);
          }}
        />
      )}

      {/* ----- Dialog : Réclamations ----- */}
      <Dialog open={complaintsOpen} onOpenChange={setComplaintsOpen}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
              <TriangleAlert className="h-4 w-4 text-amber-500" aria-hidden="true" /> Réclamations en attente
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Réclamations écrites (formulaire Hub) et messages vocaux de vos voyageurs.
            </DialogDescription>
          </DialogHeader>

          {/* ── Section : réclamations écrites ── */}
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
              📝 Écrites ({hostData?.complaints.length ?? 0})
            </p>
            {!hostData || hostData.complaints.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">Aucune réclamation écrite en attente ✓</p>
            ) : (
              <div className="space-y-2.5">
                {hostData.complaints.map((c) => (
                  <div key={c.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <Badge className="bg-white border-slate-200 text-slate-700 font-semibold hover:bg-white shrink-0">
                          {c.categoryLabel}
                        </Badge>
                        {c.isUrgent && (
                          <Badge className="bg-red-50 border-red-200 text-red-700 font-bold hover:bg-red-50 shrink-0">
                            ⚠️ Urgent
                          </Badge>
                        )}
                        {/* v4.32 — badge « Nouvelle » si la notification n'est pas lue. */}
                        {c.isRead === false && (
                          <Badge className="bg-red-500 text-white font-bold hover:bg-red-500 shrink-0">
                            Nouvelle
                          </Badge>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 shrink-0">
                        {new Date(c.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-slate-700 leading-relaxed">{c.description}</p>
                    {c.guestName && (
                      <p className="mt-1 text-[11px] text-slate-400">De : {c.guestName}</p>
                    )}
                    {c.photos.length > 0 && (
                      <div className="mt-2 flex gap-2">
                        {c.photos.map((p, i) => (
                           
                          <img
                            key={i}
                            src={p}
                            alt={`Photo ${i + 1} de la réclamation`}
                            className="h-16 w-16 rounded-lg border border-slate-200 object-cover"
                            loading="lazy"
                            decoding="async"
                          />
                        ))}
                      </div>
                    )}
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={resolvingId === c.id}
                      className="mt-2.5 h-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50 font-semibold"
                      onClick={() => resolveComplaint(c.id)}
                    >
                      {resolvingId === c.id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                      ) : (
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      Marquer résolue
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Section : messages vocaux ── */}
          <div className="pt-2 border-t border-slate-100">
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2 mt-2">
              🎙️ Vocales ({unread})
            </p>
            {!hostData || hostData.unreadMessages.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">Aucun message vocal en attente ✓</p>
            ) : (
              <div className="space-y-2.5">
                {hostData.unreadMessages.map((m) => (
                  <div key={m.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-bold text-slate-900">
                        {m.senderName}
                        {seenVoiceIds.has(m.id) && (
                          <span className="ml-1.5 text-[10px] font-semibold text-slate-400">lu ✓</span>
                        )}
                      </p>
                      <span className="text-[11px] text-slate-400 shrink-0">
                        {new Date(m.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-2">
                      {m.audioData || (m.audioUrl && !m.audioUrl.startsWith('/demo/')) ? (
                        <audio
                          controls
                          preload="metadata"
                          src={voicePlaybackSrc(m.audioData, m.audioUrl)}
                          className="h-9 w-full max-w-[260px]"
                          aria-label={`Message de ${m.senderName}`}
                          onPlay={() => void markVoicesRead([m.id])}
                        />
                      ) : (
                        <span className="text-xs text-slate-400">
                          🎙️ Message vocal de {m.durationSec} s (audio indisponible en démo)
                        </span>
                      )}
                    </div>
                    {/* RÉPONSE VOCALE — le propriétaire répond d'un simple
                        tap (pré-écoute avant envoi) ; l'invité la retrouvera
                        dans « Contacter l'hôte » et le guidebook. */}
                    <div className="mt-2">
                      <VoiceReplyButton voiceMessageId={m.id} compact slug={slug} pin={pin} onSent={() => void refreshHost()} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* ----- Dialog : Prestataires ----- */}
      <Dialog open={providersOpen} onOpenChange={setProvidersOpen}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Wrench className="h-4 w-4 text-slate-500" aria-hidden="true" /> Prestataires autour du bien
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Dans leur rayon d&apos;intervention. Activez ou désactivez chaque prestataire —
              un prestataire désactivé est masqué pour vos invités.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {(['OWNER_SERVICE', 'GUEST_EXPERIENCE'] as const).map((aud) => {
              const list = hostData?.providers.filter((p) => p.audience === aud) ?? [];
              return (
                <div key={aud}>
                  <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
                    {aud === 'OWNER_SERVICE' ? '🔧 Services Propriétaire' : '🥂 Expériences Invité'} ({list.length})
                  </p>
                  {list.length === 0 ? (
                    <p className="text-xs text-slate-400">Aucun prestataire dans le rayon.</p>
                  ) : (
                    <div className="space-y-2">
                      {list.map((p) => {
                        const enabled = providerEnabled(p);
                        return (
                          <div
                            key={p.id}
                            className={cn(
                              'flex items-center gap-3 border rounded-lg p-2.5 transition-colors',
                              enabled
                                ? 'bg-slate-50 border-slate-200'
                                : 'bg-slate-100/70 border-slate-200 opacity-70',
                            )}
                          >
                            <span className="text-xl select-none" aria-hidden="true">
                              {p.emoji}
                            </span>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-bold text-slate-900 truncate">
                                {p.name}
                                {!enabled && (
                                  <span className="ml-1.5 inline-flex items-center rounded-full bg-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-slate-500 align-middle">
                                    Désactivé
                                  </span>
                                )}
                              </p>
                              <p className="text-[11px] text-slate-500">
                                {p.categoryLabel} · {formatDistance(p.distanceKm)}
                              </p>
                            </div>
                            <span className="text-[11px] font-semibold text-slate-600 shrink-0">{p.priceLabel}</span>
                            {/* v4.32 — bouton ACTIVER / DÉSACTIVER (demande client :
                                « au cas où l'hôte ne veut pas les activer »). */}
                            <span className="flex shrink-0 items-center">
                              <Switch
                                checked={enabled}
                                disabled={togglingProviderId === p.id}
                                onCheckedChange={() => void toggleProvider(p)}
                                aria-label={
                                  enabled
                                    ? `Désactiver ${p.name} pour ce bien`
                                    : `Activer ${p.name} pour ce bien`
                                }
                              />
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Carte d'action hôte — glassmorphism premium (phase 2). */
function HostActionCard({
  emoji,
  title,
  subtitle,
  badge,
  onClick,
}: {
  emoji: string;
  title: string;
  subtitle: string;
  badge?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="relative w-full text-left glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] rounded-2xl p-4 transition-all duration-500 hover:-translate-y-0.5 active:scale-[0.99] cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
    >
      {badge && (
        <span className="absolute top-3 right-3 inline-flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-red-500 text-white text-[11px] font-bold shadow-lg shadow-red-500/30">
          {badge}
        </span>
      )}
      <div className="flex items-center gap-3.5">
        <EmojiIcon emoji={emoji} size="lg" variant="default" />
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">{title}</h3>
          <p className="text-xs text-slate-500 mt-0.5 leading-relaxed dark:text-slate-400">{subtitle}</p>
        </div>
        <PencilLine className="h-4 w-4 text-slate-400 shrink-0 dark:text-slate-500" aria-hidden="true" />
      </div>
    </button>
  );
}

/** Dialog : modification des identifiants Wi-Fi (PUT update + PIN).
 * Monté uniquement quand ouvert → l'état initial repart du contenu courant. */
function WifiEditDialog({
  onClose,
  slug,
  pin,
  wifi,
  onSaved,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  wifi: HostData['wifi'];
  onSaved: (w: HostData['wifi']) => void;
}) {
  const [ssid, setSsid] = useState(wifi?.networkName ?? '');
  const [password, setPassword] = useState(wifi?.password ?? '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!wifi || !ssid.trim() || !password.trim()) {
      toast.error('Renseignez le nom du réseau et le mot de passe.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pin,
          updates: [
            {
              qrCodeId: wifi.qrCodeId,
              content: {
                network_name: ssid.trim(),
                password: password.trim(),
                security_type: wifi.securityType || 'WPA2',
              },
            },
          ],
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || 'Échec de la mise à jour.');
        setSaving(false);
        return;
      }
      onSaved({ ...wifi, networkName: ssid.trim(), password: password.trim() });
      toast.success('Wi-Fi mis à jour ✅', {
        description: 'Vos voyageurs voient le nouveau réseau immédiatement.',
      });
      setSaving(false);
      onClose();
    } catch {
      toast.error('Erreur réseau.');
      setSaving(false);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) onClose();
      }}
    >
      <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">📶 Modifier le Wi-Fi</DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Les nouveaux identifiants sont visibles immédiatement par vos voyageurs.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="wifi-ssid">Nom du réseau (SSID)</Label>
            <Input
              id="wifi-ssid"
              value={ssid}
              onChange={(e) => setSsid(e.target.value)}
              placeholder="MonLogement_5G"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wifi-pwd">Mot de passe</Label>
            <Input
              id="wifi-pwd"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <Button
            type="button"
            disabled={saving}
            onClick={save}
            className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Check className="h-4 w-4" aria-hidden="true" />}
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : édition du Guidebook (QrCode 'home_manual').
// Même schéma de contenu que l'affichage invité /view :
// { title, body } avec sections séparées par un double saut de ligne.
// Monté uniquement quand ouvert → l'état initial repart du contenu courant.
// =============================================================
function GuidebookEditDialog({
  onClose,
  slug,
  pin,
  guidebook,
  onSaved,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  guidebook: HostGuidebook;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(guidebook.title);
  const [sections, setSections] = useState<string[]>(
    guidebook.sections.length > 0 ? guidebook.sections : [''],
  );
  const [saving, setSaving] = useState(false);

  const updateSection = (i: number, value: string) =>
    setSections((prev) => prev.map((s, idx) => (idx === i ? value : s)));
  const addSection = () => setSections((prev) => [...prev, '']);
  const removeSection = (i: number) =>
    setSections((prev) => prev.filter((_, idx) => idx !== i));

  const save = async () => {
    if (!guidebook.qrCodeId) {
      toast.error('Aucun Guidebook actif pour ce bien. Créez-le depuis le dashboard hôte.');
      return;
    }
    const cleanSections = sections.map((s) => s.trim()).filter((s) => s.length > 0);
    if (!title.trim() || cleanSections.length === 0) {
      toast.error('Renseignez un titre et au moins une section.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pin,
          updates: [
            {
              qrCodeId: guidebook.qrCodeId,
              // Même schéma que /view : le body est découpé en sections
              // par double saut de ligne côté affichage invité.
              content: { title: title.trim(), body: cleanSections.join('\n\n') },
            },
          ],
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || 'Échec de la mise à jour.');
        setSaving(false);
        return;
      }
      toast.success('Guidebook mis à jour ✅', {
        description: 'Vos voyageurs voient le nouveau guide immédiatement.',
      });
      setSaving(false);
      onSaved();
      onClose();
    } catch {
      toast.error('Erreur réseau.');
      setSaving(false);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) onClose();
      }}
    >
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-emerald-600" aria-hidden="true" /> Éditer le Guidebook
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Le guide de bienvenue consulté par vos invités depuis le Hub.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="guidebook-title">Titre du guide</Label>
            <Input
              id="guidebook-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Guide de bienvenue"
              maxLength={120}
            />
          </div>

          <div className="space-y-2">
            <Label>Sections ({sections.length})</Label>
            {sections.map((section, i) => (
              <div key={i} className="relative">
                <Textarea
                  value={section}
                  onChange={(e) => updateSection(i, e.target.value)}
                  placeholder={`Section ${i + 1} — ex : 🔑 Accès, code de la boîte à clés…`}
                  className="min-h-[72px] pr-10 text-sm"
                  maxLength={2000}
                  aria-label={`Section ${i + 1} du guide`}
                />
                <button
                  type="button"
                  onClick={() => removeSection(i)}
                  aria-label={`Supprimer la section ${i + 1}`}
                  disabled={saving}
                  className="absolute top-2 right-2 h-7 w-7 inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 hover:text-red-600 hover:border-red-200 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={saving || sections.length >= 12}
              onClick={addSection}
              className="w-full h-9 border-dashed border-slate-300 text-slate-600"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Ajouter une section
            </Button>
          </div>

          <Button
            type="button"
            disabled={saving}
            onClick={save}
            className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Check className="h-4 w-4" aria-hidden="true" />
            )}
            {saving ? 'Enregistrement…' : 'Enregistrer le guide'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : Upselling — commandes ServiceOrder des invités.
// Liste + boutons Confirmer/Annuler sur les PENDING (le serveur
// revalide chaque transition). État vide honnête si aucune commande.
// =============================================================
function UpsellingDialog({
  onClose,
  orders,
  patchingId,
  onPatch,
}: {
  onClose: () => void;
  orders: HostOrder[] | null;
  patchingId: string | null;
  onPatch: (orderId: string, action: 'CONFIRM' | 'CANCEL') => void;
}) {
  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v) onClose();
      }}
    >
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Package className="h-4 w-4 text-emerald-600" aria-hidden="true" /> Commandes des invités
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Prestations commandées via l&apos;app invitée. Confirmez ou annulez les demandes en attente.
          </DialogDescription>
        </DialogHeader>

        {!orders ? (
          <div className="space-y-2.5 py-2" aria-busy="true">
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
          </div>
        ) : orders.length === 0 ? (
          <div className="py-8 text-center">
            <span className="text-3xl" aria-hidden="true">
              🧾
            </span>
            <p className="mt-2 text-sm font-semibold text-slate-700">Aucune commande pour l&apos;instant</p>
            <p className="mt-1 text-xs text-slate-400">
              Les commandes passées par vos invités depuis l&apos;app apparaîtront ici.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {orders.map((o) => (
              <div key={o.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <Badge
                    className={cn(
                      'text-white border-transparent font-semibold shrink-0',
                      o.statusBadge,
                    )}
                  >
                    {o.statusEmoji} {o.statusLabel}
                  </Badge>
                  <span className="text-[11px] text-slate-400 shrink-0">
                    {new Date(o.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="mt-2 text-sm font-bold text-slate-900 leading-snug">{o.itemsSummary}</p>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {o.providerEmoji} {o.providerName} · Invité : {o.guestName}
                </p>
                <div className="mt-2 flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm font-bold text-slate-900">{o.totalEur}</span>
                  {o.status === 'PENDING' && (
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={patchingId === o.id}
                        className="h-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50 font-semibold"
                        onClick={() => onPatch(o.id, 'CONFIRM')}
                      >
                        {patchingId === o.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                        ) : (
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                        )}
                        Confirmer
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={patchingId === o.id}
                        className="h-8 border-red-200 text-red-600 hover:bg-red-50 font-semibold"
                        onClick={() => onPatch(o.id, 'CANCEL')}
                      >
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                        Annuler
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : Paramètres — changement du code PIN hôte.
// Double saisie sur clavier numérique (nouveau PIN + confirmation,
// les 2 saisies doivent matcher) → PUT /update { pin, newPin }.
// Le PIN ne vit QUE le temps de la saisie en mémoire (jamais
// persisté, jamais affiché) ; après succès, le PIN de session
// (état parent, en mémoire) est mis à jour.
// =============================================================
function SettingsPinDialog({
  onClose,
  slug,
  pin,
  onPinChanged,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  onPinChanged: (pin: string) => void;
}) {
  const [step, setStep] = useState<'new' | 'confirm'>('new');
  const [hasFirst, setHasFirst] = useState(false); // affichage •••• uniquement
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [keypadKey, setKeypadKey] = useState(0);
  const firstPinRef = useRef('');

  /** Fermeture : purge immédiate de la première saisie en mémoire. */
  const close = () => {
    firstPinRef.current = '';
    onClose();
  };

  const handleComplete = async (entered: string) => {
    if (step === 'new') {
      firstPinRef.current = entered;
      setHasFirst(true);
      setStep('confirm');
      setError('');
      setKeypadKey((k) => k + 1); // clavier neuf pour la confirmation
      return;
    }
    if (entered !== firstPinRef.current) {
      setError('Les deux codes ne correspondent pas. Recommencez.');
      firstPinRef.current = '';
      setHasFirst(false);
      setStep('new');
      setKeypadKey((k) => k + 1);
      return;
    }
    // Confirmation OK → PUT /update { pin, newPin }
    setSaving(true);
    setError('');
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, newPin: entered }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Échec du changement de PIN.');
        setSaving(false);
        setKeypadKey((k) => k + 1);
        return;
      }
      firstPinRef.current = '';
      setHasFirst(false);
      toast.success('PIN modifié ✅', {
        description: 'Votre nouveau code est actif immédiatement.',
      });
      onPinChanged(entered); // le PIN de session (mémoire) passe au nouveau code
      setSaving(false);
      onClose();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
      setSaving(false);
      setKeypadKey((k) => k + 1);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) close();
      }}
    >
      <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl p-6 [&>button]:hidden">
        <DialogHeader className="items-center text-center">
          <span className="mx-auto" aria-hidden="true">
            <EmojiIcon emoji="⚙️" size="lg" variant="dark" />
          </span>
          <DialogTitle className="text-lg font-bold text-slate-900 text-center">
            Modifier le code PIN
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-600 text-center">
            {step === 'new'
              ? 'Saisissez votre nouveau code à 4 chiffres.'
              : 'Confirmez le nouveau code en le saisissant à nouveau.'}
          </DialogDescription>
        </DialogHeader>

        {saving ? (
          <div className="flex flex-col items-center gap-3 py-8" aria-busy="true">
            <Loader2 className="h-8 w-8 animate-spin text-emerald-600" aria-hidden="true" />
            <p className="text-sm text-slate-500">Enregistrement du nouveau code…</p>
          </div>
        ) : (
          <div className="mt-2">
            {hasFirst && (
              <p className="mb-3 text-center text-xs font-semibold text-slate-500" aria-live="polite">
                Code saisi : <span className="tracking-widest">••••</span>
              </p>
            )}
            <QRTNumericKeypad key={keypadKey} onComplete={handleComplete} />
            {error && (
              <p role="alert" className="mt-4 text-center text-sm font-semibold text-red-600">
                {error}
              </p>
            )}
            <Button
              type="button"
              variant="outline"
              className="mt-4 w-full h-11 border-slate-300 text-slate-600"
              onClick={close}
            >
              Annuler
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// v4.31 « PHOTOS DE MON HUB » — dialog hôte de personnalisation
// =============================================================
/** Dialog « 📸 Photos de mon hub » — l'hôte remplace chaque visuel
 *  d'illustration par une VRAIE photo du bien (redimensionnée côté
 *  client en dataURL JPEG ≤ 1280 px, stockée dans Property.hubPhotos
 *  via PUT /update, garde PIN). Sauvegarde immédiate par photo + reset.
 *  Le hub démo (demo-hub) ne persiste pas — comportement historique. */
function HubPhotosDialog({
  onClose,
  slug,
  pin,
  initial,
  onSaved,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  initial: HubPhotoMap;
  onSaved: (map: HubPhotoMap) => void;
}) {
  const [map, setMap] = useState<HubPhotoMap>(initial);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [failed, setFailed] = useState<Record<string, boolean>>({});
  const fileRef = useRef<HTMLInputElement | null>(null);
  const activeKeyRef = useRef<HubPhotoKey | null>(null);

  const openPicker = (key: HubPhotoKey) => {
    activeKeyRef.current = key;
    if (fileRef.current) {
      fileRef.current.value = '';
      fileRef.current.click();
    }
  };

  /** Image choisie → redimensionnement client → PUT immédiat (garde PIN). */
  const handlePick = async (file: File | undefined) => {
    const key = activeKeyRef.current;
    if (!file || !key) return;
    if (!file.type.startsWith('image/')) {
      toast.error('Choisissez une image (JPG, PNG…).');
      return;
    }
    setBusyKey(key);
    try {
      const dataUrl = await fileToHubPhotoDataUrl(file, 1280);
      if (!dataUrl) {
        toast.error('Impossible de lire cette image.');
        return;
      }
      if (dataUrl.length > MAX_HUB_PHOTO_CHARS) {
        toast.error('Photo trop lourde après compression — essayez une autre image.');
        return;
      }
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, hubPhotos: { [key]: dataUrl } }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Enregistrement impossible.');
        return;
      }
      const next: HubPhotoMap = { ...map, [key]: dataUrl };
      setMap(next);
      onSaved(next);
      toast.success('Photo enregistrée ✓ — visible immédiatement par vos invités.');
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setBusyKey(null);
    }
  };

  /** Retire la photo perso → retour au visuel curated. */
  const resetPhoto = async (key: HubPhotoKey) => {
    setBusyKey(key);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, hubPhotos: { [key]: null } }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Suppression impossible.');
        return;
      }
      const next: HubPhotoMap = { ...map };
      delete next[key];
      setMap(next);
      onSaved(next);
      toast.success('Visuel d’illustration restauré.');
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setBusyKey(null);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !busyKey) onClose();
      }}
    >
      <DialogContent className="max-w-lg bg-white border border-slate-200 rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">
            📸 Photos de mon hub
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Remplacez les visuels d’illustration par vos vraies photos — vos invités les voient immédiatement sur la page invitée.
          </DialogDescription>
        </DialogHeader>

        {/* Input fichier partagé (une seule ouverture à la fois) */}
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handlePick(e.target.files?.[0] ?? undefined)}
        />

        <div className="max-h-[58dvh] overflow-y-auto pr-0.5 custom-scrollbar">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {HUB_PHOTO_SLOTS.map((slot) => {
              const custom = map[slot.key];
              const busy = busyKey === slot.key;
              return (
                <div
                  key={slot.key}
                  className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm dark:border-white/10 dark:bg-white/5"
                >
                  <div className="relative h-24 w-full">
                    {custom && !failed[slot.key] ? (
                      <img
                        src={custom}
                        alt={`Photo actuelle — ${slot.label}`}
                        className="h-full w-full object-cover"
                        onError={() => setFailed((f) => ({ ...f, [slot.key]: true }))}
                      />
                    ) : (
                      <span
                        aria-hidden="true"
                        className="flex h-full w-full items-center justify-center bg-gradient-to-br from-amber-100 to-orange-100 text-3xl dark:from-amber-500/15 dark:to-orange-500/10"
                      >
                        {slot.emoji}
                      </span>
                    )}
                    {busy && (
                      <span className="absolute inset-0 flex items-center justify-center bg-black/45" aria-busy="true">
                        <Loader2 className="h-5 w-5 animate-spin text-white" aria-hidden="true" />
                      </span>
                    )}
                    {custom && (
                      <span className="absolute right-1.5 top-1.5 rounded-full bg-emerald-500 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white shadow">
                        Perso
                      </span>
                    )}
                  </div>
                  <div className="p-2">
                    <p className="truncate text-[11px] font-bold text-slate-800 dark:text-slate-100">
                      {slot.emoji} {slot.label}
                    </p>
                    <p className="mt-0.5 line-clamp-2 h-7 text-[10px] leading-snug text-slate-400 dark:text-slate-500">
                      {slot.hint}
                    </p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-7 flex-1 border-slate-300 text-[11px] dark:border-white/20"
                        disabled={!!busyKey}
                        onClick={() => openPicker(slot.key)}
                      >
                        {custom ? 'Changer' : 'Ajouter'}
                      </Button>
                      {custom && (
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-7 px-2 text-slate-400 hover:text-red-600"
                          disabled={!!busyKey}
                          aria-label={`Retirer la photo — ${slot.label}`}
                          onClick={() => resetPhoto(slot.key)}
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <p className="text-[11px] text-slate-400 dark:text-slate-500">
          Astuce : photos redimensionnées automatiquement (1280 px, JPEG). Format paysage conseillé.
        </p>
      </DialogContent>
    </Dialog>
  );
}

/**
 * FIX VOCAL « Contacter l'hôte » — lien WhatsApp wa.me dérivé du
 * téléphone de l'hôte (aucun champ dédié en base) :
 *  - chiffres uniquement ; préfixe international « 00 » retiré ;
 *  - numéro FR à 10 chiffres commençant par 0 → indicatif 33 ;
 *  - +33/+221… passés tels quels (wa.me accepte le format E.164
 *    sans le « + »).
 * Retourne null si aucun numéro exploitable (carte masquée).
 */
function waMeHref(phone: string | null | undefined): string | null {
  if (!phone) return null;
  let digits = phone.replace(/\D/g, '');
  if (!digits) return null;
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.length === 10 && digits.startsWith('0')) digits = `33${digits.slice(1)}`;
  return digits.length >= 6 && digits.length <= 15 ? `https://wa.me/${digits}` : null;
}

// Dialog contact hôte + message vocal (répondeur).
// FIX « TOUT BLANC » + UX : PRÉ-ÉCOUTE obligatoire avant envoi
// (lecteur local sur blob URL → Envoyer / Réenregistrer) et
// RÉPONSES VOCALES DE L'HÔTE affichées à l'invité
// (GET /api/public/hub/[slug]/voice-replies — uniquement les
// messages senderType='HOST').
// FIX-32 (v4.21) : BUG BLOQUANT — recorder.ondataavailable n'était
// JAMAIS assigné → chunksRef restait vide → blob vide → erreur
// « Enregistrement vide » systématique. Le handler est restauré
// (même pattern que le guidebook /view et VoiceReplyButton).
// =============================================================
interface HostVoiceReply {
  id: string;
  senderName: string;
  audioUrl: string;
  /** v4.32 — copie dataURL en base (lecture durable). */
  audioData?: string | null;
  durationSec: number;
  createdAt: string;
}

// v4.32 « ONGLET MESSAGES » — journal local des messages envoyés depuis
// CET appareil (localStorage, par slug) : l'invité voit ses messages en
// attente et leur statut (En attente / Lu par l'hôte). Aucune donnée
// personnelle : uniquement des ids de messages déjà envoyés.
interface SentMessageEntry {
  id: string;
  at: number;
}
const sentMessagesKey = (slug: string) => `hub-guest-msgs-${slug}`;

function readSentMessages(slug: string): SentMessageEntry[] {
  try {
    const raw = window.localStorage.getItem(sentMessagesKey(slug));
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((e): e is SentMessageEntry => !!e && typeof (e as SentMessageEntry).id === 'string')
      .slice(-20);
  } catch {
    return [];
  }
}

function rememberSentMessage(slug: string, id: string) {
  try {
    const list = readSentMessages(slug).filter((e) => e.id !== id);
    list.push({ id, at: Date.now() });
    window.localStorage.setItem(sentMessagesKey(slug), JSON.stringify(list.slice(-20)));
  } catch {
    // localStorage indisponible (navigation privée) : onglet Messages vide
  }
}

function ContactDialog({
  open,
  onClose,
  slug,
  contact,
  propertyName,
  newReplyCount = 0,
  onRepliesSeen,
}: {
  open: boolean;
  onClose: () => void;
  slug: string;
  contact: HubPayload['guest']['contact'];
  propertyName: string;
  /** v4.35 — nombre de réponses vocales de l'hôte NON VUES (badge). */
  newReplyCount?: number;
  /** v4.35 — marque les réponses comme vues (alerte carte Contact éteinte). */
  onRepliesSeen?: (ids: string[]) => void;
}) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [sending, setSending] = useState(false);
  // PRÉ-ÉCOUTE : blob local avant envoi (url révoquée au nettoyage).
  const [preview, setPreview] = useState<{ url: string; blob: Blob; mime: string; duration: number } | null>(null);
  // Réponses vocales de l'hôte (senderType='HOST').
  const [replies, setReplies] = useState<HostVoiceReply[] | null>(null);
  // v4.32 — onglet Messages : journal local + statuts serveur.
  const [sentMessages, setSentMessages] = useState<SentMessageEntry[]>([]);
  const [msgStatuses, setMsgStatuses] = useState<Record<string, 'pending' | 'read' | 'unknown'>>({});
  const [activeTab, setActiveTab] = useState<'contact' | 'messages'>('contact');
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const secondsRef = useRef(0);
  // FIX-VOCAL : mimeType réellement utilisé par le recorder (Safari/iOS
  // n'enregistre PAS en webm — il faut audio/mp4 → extension .m4a).
  const mimeRef = useRef('audio/webm');

  const stopTimers = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const cleanup = useCallback(() => {
    stopTimers();
    setRecording(false);
    setSeconds(0);
    secondsRef.current = 0;
    recorderRef.current?.stream?.getTracks?.().forEach((t) => t.stop());
    recorderRef.current = null;
    chunksRef.current = [];
    setPreview((prev) => {
      if (prev?.url) URL.revokeObjectURL(prev.url);
      return null;
    });
    setReplies(null);
    setActiveTab('contact');
  }, []);

  useEffect(() => {
    if (!open) cleanup();
  }, [open, cleanup]);

  // v4.35 — réponses vocales de l'hôte : POLLING toutes les 25 s tant que
  // le dialog est ouvert (avant : un seul chargement à l'ouverture → une
  // réponse arrivée pendant la conversation n'apparaissait JAMAIS sans
  // fermer/réouvrir — « la réponse n'est pas lisible dans la page contact »).
  // L'ouverture de l'onglet Messages marque les réponses comme vues.
  useEffect(() => {
    if (!open) return;
    let alive = true;
    const load = () => {
      fetch(`/api/public/hub/${encodeURIComponent(slug)}/voice-replies`, { cache: 'no-store' })
        .then((r) => (r.ok ? r.json() : { replies: [] }))
        .then((j: { replies?: HostVoiceReply[] }) => {
          if (!alive) return;
          const list = Array.isArray(j.replies) ? j.replies : [];
          setReplies(list);
          if (activeTab === 'messages' && list.length > 0) {
            onRepliesSeen?.(list.map((r) => r.id));
          }
        })
        .catch(() => undefined);
    };
    load();
    const timer = setInterval(load, 25_000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [open, slug, activeTab, onRepliesSeen]);

  // v4.32 — journal local des messages envoyés + statuts serveur.
  // Rechargé à l'ouverture et à chaque activation de l'onglet Messages.
  useEffect(() => {
    if (!open) return;
    const list = readSentMessages(slug);
    setSentMessages(list);
    if (list.length === 0) return;
    let cancelled = false;
    const ids = list.map((e) => e.id).join(',');
    fetch(`/api/public/hub/${encodeURIComponent(slug)}/guest-messages?ids=${encodeURIComponent(ids)}`, {
      cache: 'no-store',
    })
      .then((r) => (r.ok ? r.json() : { messages: [] }))
      .then((j: { messages?: { id: string; status: 'pending' | 'read' | 'unknown' }[] }) => {
        if (cancelled || !Array.isArray(j.messages)) return;
        const map: Record<string, 'pending' | 'read' | 'unknown'> = {};
        for (const m of j.messages) map[m.id] = m.status;
        setMsgStatuses((prev) => ({ ...prev, ...map }));
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [open, slug, activeTab]);

  const stopRecording = (send: boolean) => {
    const recorder = recorderRef.current;
    stopTimers();
    if (!recorder) return;
    const duration = secondsRef.current;
    recorder.onstop = async () => {
      recorder.stream.getTracks().forEach((t) => t.stop());
      recorderRef.current = null;
      setRecording(false);
      if (!send) {
        toast.info('Enregistrement annulé.');
        return;
      }
      // FIX-VOCAL : type MIME réel du recorder (jamais forcé en webm —
      // Safari/iOS produit de l'audio/mp4 ; l'étiqueter webm cassait la lecture).
      const mimeType = mimeRef.current.split(';')[0].trim() || 'audio/webm';
      const blob = new Blob(chunksRef.current, { type: mimeType });
      if (blob.size === 0) {
        toast.error('Enregistrement vide. Réessayez.');
        return;
      }
      // PRÉ-ÉCOUTE — on ne POSTe plus immédiatement : l'invité écoute
      // son message puis choisit « Envoyer » ou « Réenregistrer ».
      const url = URL.createObjectURL(blob);
      setPreview({ url, blob, mime: mimeType, duration });
    };
    recorder.stop();
  };

  const sendPreview = async () => {
    if (!preview) return;
    setSending(true);
    try {
      const fd = new FormData();
      fd.append('audio', new File([preview.blob], `message.${extForMime(preview.mime)}`, { type: preview.mime }));
      fd.append('senderName', 'Invité');
      fd.append('durationSec', String(preview.duration));
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/voice`, {
        method: 'POST',
        body: fd,
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; id?: string };
      if (!res.ok) {
        throw new Error(data.error || 'http');
      }
      // v4.32 — journalise l'envoi : l'onglet « Messages » affiche ce
      // message avec son statut (En attente / Lu par l'hôte).
      if (data.id) {
        rememberSentMessage(slug, data.id);
        setSentMessages((prev) => [...prev.filter((e) => e.id !== data.id!), { id: data.id!, at: Date.now() }]);
        setMsgStatuses((prev) => ({ ...prev, [data.id!]: 'pending' }));
      }
      toast.success('Message envoyé à votre hôte ✅');
      onClose();
    } catch (e) {
      const detail = e instanceof Error && e.message !== 'http' ? e.message : null;
      toast.error(detail || 'Envoi impossible. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // FIX-VOCAL : sélection du premier mimeType supporté par le navigateur
      // (webm/opus sur Chrome-Firefox, mp4/AAC sur Safari/iOS — avant, un
      // format non supporté levait une NotSupportedError ici).
      const mimeType = pickRecorderMime();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mimeRef.current = recorder.mimeType || mimeType || 'audio/webm';
      chunksRef.current = [];
      // FIX-32 : sans ce handler, les chunks audio ne sont JAMAIS
      // collectés → enregistrement vide à l'arrêt (bug bloquant).
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
      setSeconds(0);
      secondsRef.current = 0;
      timerRef.current = setInterval(() => {
        secondsRef.current += 1;
        setSeconds(secondsRef.current);
        if (secondsRef.current >= 30) {
          stopRecording(true);
        }
      }, 1000);
    } catch {
      toast.error('Micro inaccessible. Vérifiez les autorisations du navigateur.');
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !sending && onClose()}>
      <DialogContent className="max-w-sm overflow-hidden rounded-3xl border border-slate-200 bg-white p-0 sm:max-w-md dark:border-white/10 dark:bg-slate-900">
        <div className="max-h-[86dvh] overflow-y-auto custom-scrollbar">
          {/* ── v4.35 — EN-TÊTE « VOTRE HÔTE » : avatar initiales + nom +
              promesse de réponse (refonte : clarté du canal avant tout) ── */}
          <div className="sticky top-0 z-10 border-b border-emerald-100 bg-gradient-to-r from-emerald-600 to-teal-600 px-5 pb-4 pt-5 text-white dark:border-white/10 dark:from-emerald-700 dark:to-teal-800">
            <div className="flex items-center gap-3">
              <span
                aria-hidden="true"
                className="inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-white/40 bg-white/20 text-base font-bold uppercase backdrop-blur-sm"
              >
                {contact.name
                  .trim()
                  .split(/\s+/)
                  .map((p) => p[0])
                  .slice(0, 2)
                  .join('') || '🏠'}
              </span>
              <div className="min-w-0 flex-1">
                <DialogTitle className="display-title font-serif! truncate text-lg font-bold text-white">
                  {contact.name}
                </DialogTitle>
                <DialogDescription className="mt-0.5 flex items-center gap-1.5 text-[11px] font-medium text-emerald-50/95">
                  <span aria-hidden="true" className="inline-block h-2 w-2 rounded-full bg-emerald-300" />
                  Votre hôte · répond en quelques minutes
                </DialogDescription>
              </div>
            </div>
          </div>

          <div className="px-4 pb-5 pt-4 sm:px-5">
        {/* v4.32 — ONGLETS Contact / Messages (demande client : « créer un
            onglet messages dans contacter l'hôte et y loger les messages
            en attente »). v4.35 — le badge rouge compte désormais les
            réponses de l'hôte NON VUES (💬 n) avant les messages en attente. */}
        <Tabs
          value={activeTab}
          onValueChange={(v) => setActiveTab(v === 'messages' ? 'messages' : 'contact')}
        >
          <TabsList className="grid h-11 w-full grid-cols-2 rounded-2xl bg-slate-100 p-1 dark:bg-white/10">
            <TabsTrigger
              value="contact"
              className="rounded-xl text-[13px] font-semibold data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-slate-900"
            >
              📞 Contact
            </TabsTrigger>
            <TabsTrigger
              value="messages"
              className="rounded-xl text-[13px] font-semibold data-[state=active]:bg-white data-[state=active]:shadow-sm dark:data-[state=active]:bg-slate-900"
            >
              📨 Messages
              {(() => {
                const pending = sentMessages.filter((m) => (msgStatuses[m.id] ?? 'pending') === 'pending').length;
                return newReplyCount > 0 ? (
                  <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center gap-0.5 rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
                    💬 {newReplyCount}
                  </span>
                ) : pending > 0 ? (
                  <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-bold text-white">
                    {pending}
                  </span>
                ) : null;
              })()}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="contact" className="mt-4">
            <div className="space-y-3">
              {/* ÉTAPE 1 — joindre l'hôte tout de suite (3 canaux clairs) */}
              <p className="text-[10.5px] font-bold uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">
                1 · Joindre votre hôte maintenant
              </p>
              {contact.phone && (
                <a
                  href={`tel:${contact.phone.replace(/\s/g, '')}`}
                  className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-3 shadow-sm transition-colors hover:border-slate-300 hover:bg-slate-50 dark:border-white/10 dark:bg-white/5 dark:hover:bg-white/10"
                >
                  <span
                    aria-hidden="true"
                    className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-xl"
                  >
                    📞
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-bold text-slate-900 dark:text-white">
                      Appeler {contact.name}
                    </span>
                    <span className="block text-xs text-slate-500 dark:text-slate-400">{contact.phone}</span>
                  </span>
                  <Phone className="h-4 w-4 shrink-0 text-slate-400" aria-hidden="true" />
                </a>
              )}
              {/* FIX-32 — WhatsApp (wa.me) dérivé du téléphone de l'hôte */}
              {(() => {
                const waHref = waMeHref(contact.phone);
                return waHref ? (
                  <a
                    href={waHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`Contacter ${contact.name} sur WhatsApp`}
                    className="flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-3 shadow-sm transition-colors hover:border-emerald-300 hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-500/10"
                  >
                    <span
                      aria-hidden="true"
                      className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-xl text-white"
                    >
                      💬
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold text-emerald-900 dark:text-emerald-100">
                        WhatsApp — le plus rapide
                      </span>
                      <span className="block text-xs text-emerald-700 dark:text-emerald-300">
                        Écrire à {contact.name} sur WhatsApp
                      </span>
                    </span>
                    <MessageCircle className="h-4 w-4 shrink-0 text-emerald-500" aria-hidden="true" />
                  </a>
                ) : null;
              })()}
              {contact.email && (
                <a
                  href={`mailto:${contact.email}?subject=${encodeURIComponent(`Message du Hub — ${propertyName}`)}`}
                  className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-3 shadow-sm transition-colors hover:border-amber-300 hover:bg-amber-100 dark:border-amber-500/30 dark:bg-amber-500/10"
                >
                  <span
                    aria-hidden="true"
                    className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-xl text-white"
                  >
                    ✉️
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-bold text-amber-900 dark:text-amber-100">
                      Écrire un email
                    </span>
                    <span className="block truncate text-xs text-amber-700 dark:text-amber-300">{contact.email}</span>
                  </span>
                  <Mail className="h-4 w-4 shrink-0 text-amber-500" aria-hidden="true" />
                </a>
              )}

              {/* ÉTAPE 2 — répondeur vocal (pré-écoute avant envoi) */}
              <p className="pt-1 text-[10.5px] font-bold uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">
                2 · Ou laisser un message vocal
              </p>
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/10">
                <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                  🎙️ Répondeur de votre hôte
                </p>
                <p className="mt-0.5 text-[11px] leading-relaxed text-emerald-800 dark:text-emerald-200">
                  Décrivez votre demande en 30 s max — vous pouvez l&apos;écouter avant de l&apos;envoyer.
                </p>
                {sending ? (
                  <div className="mt-3 flex items-center gap-2 text-sm text-emerald-800 dark:text-emerald-200">
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Envoi en cours…
                  </div>
                ) : preview ? (
                  <div className="mt-3 space-y-2.5">
                    <p className="text-xs font-semibold text-emerald-900 dark:text-emerald-100">
                      🎧 Écoutez votre message ({preview.duration}s) avant de l&apos;envoyer
                    </p>
                    <audio
                      controls
                      autoPlay
                      src={preview.url}
                      className="h-9 w-full"
                      aria-label="Pré-écoute de votre message vocal"
                    />
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-9 flex-1 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300"
                        onClick={() => {
                          setPreview((prev) => {
                            if (prev?.url) URL.revokeObjectURL(prev.url);
                            return null;
                          });
                        }}
                      >
                        Réenregistrer
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        className="h-9 flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                        onClick={sendPreview}
                      >
                        Envoyer
                      </Button>
                    </div>
                  </div>
                ) : recording ? (
                  <div className="mt-3 flex items-center gap-2.5 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 text-sm font-bold text-red-600">
                      <span className="h-2.5 w-2.5 rounded-full bg-red-500 animate-pulse" aria-hidden="true" />
                      {String(Math.floor(seconds / 60)).padStart(2, '0')}:{String(seconds % 60).padStart(2, '0')}
                    </span>
                    <Button
                      type="button"
                      size="sm"
                      className="h-9 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                      onClick={() => stopRecording(true)}
                    >
                      <Square className="h-3.5 w-3.5" aria-hidden="true" /> Écouter avant envoi
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-9 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300"
                      onClick={() => stopRecording(false)}
                    >
                      Annuler
                    </Button>
                  </div>
                ) : (
                  <Button
                    type="button"
                    className="mt-3 w-full h-10 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                    onClick={startRecording}
                  >
                    <Mic className="h-4 w-4" aria-hidden="true" /> Démarrer l&apos;enregistrement
                  </Button>
                )}
              </div>
            </div>
          </TabsContent>

          {/* ── v4.32 — ONGLET « MESSAGES » : les messages EN ATTENTE de
              l'invité (journal de cet appareil) + les réponses de l'hôte.
              v4.35 — re-design clair + réponses ACTUALISÉES toutes les
              25 s (le propriétaire répond → visible sans fermer) ── */}
          <TabsContent value="messages" className="mt-4">
            <div className="space-y-3">
              <div className="rounded-2xl border border-slate-200 bg-white p-3.5 shadow-sm dark:border-white/10 dark:bg-white/5">
                <p className="text-sm font-bold text-slate-900 dark:text-white">📨 Vos messages</p>
                <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                  Envoyés depuis cet appareil — suivez leur statut.
                </p>
                {sentMessages.length === 0 ? (
                  <p className="mt-2 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                    Aucun message pour le moment. Laissez un vocal dans l&apos;onglet
                    <span className="font-semibold"> Contact</span> — il apparaîtra ici avec son statut.
                  </p>
                ) : (
                  <div className="mt-2.5 space-y-2 max-h-44 overflow-y-auto custom-scrollbar">
                    {[...sentMessages].reverse().map((m) => {
                      const status = msgStatuses[m.id] ?? 'pending';
                      return (
                        <div key={m.id} className="flex items-center gap-2.5 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 dark:bg-white/5 dark:border-white/10">
                          <span className="text-base shrink-0" aria-hidden="true">🎙️</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-slate-900 dark:text-white">Message vocal</p>
                            <p className="text-[10px] text-slate-400">
                              {new Date(m.at).toLocaleDateString('fr-FR', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </p>
                          </div>
                          {status === 'read' ? (
                            <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] font-bold text-emerald-700">
                              ✓ Lu par l&apos;hôte
                            </span>
                          ) : status === 'unknown' ? (
                            <span className="shrink-0 text-[10px] font-semibold text-slate-400">—</span>
                          ) : (
                            <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-amber-50 border border-amber-200 px-2 py-0.5 text-[10px] font-bold text-amber-700">
                              ⏳ En attente
                            </span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Réponses vocales de votre hôte — v4.35 : actualisation auto */}
              <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-3.5 dark:border-emerald-500/30 dark:bg-emerald-500/10">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-bold text-emerald-900 dark:text-emerald-100">
                    💬 Réponses de votre hôte
                  </p>
                  <span className="shrink-0 text-[10px] font-medium text-emerald-700/80 dark:text-emerald-300/80">
                    Actualisé auto
                  </span>
                </div>
                {replies === null ? (
                  <p className="mt-2 flex items-center gap-2 text-xs text-emerald-800/70 dark:text-emerald-200/70">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> Chargement…
                  </p>
                ) : replies.length === 0 ? (
                  <p className="mt-2 text-xs leading-relaxed text-emerald-800/80 dark:text-emerald-200/80">
                    Votre hôte n&apos;a pas encore laissé de réponse vocale — il vous répondra ici.
                  </p>
                ) : (
                  <div className="mt-2 space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
                    {replies.map((r) => (
                      <div key={r.id} className="bg-white border border-slate-200 rounded-lg p-2.5 dark:bg-slate-900 dark:border-white/10">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-bold text-slate-900 truncate dark:text-white">{r.senderName}</p>
                          <span className="text-[10px] text-slate-400 shrink-0">
                            {new Date(r.createdAt).toLocaleDateString('fr-FR', {
                              day: 'numeric',
                              month: 'short',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                            {r.durationSec > 0 ? ` · ${r.durationSec}s` : ''}
                          </span>
                        </div>
                        <audio
                          controls
                          preload="metadata"
                          src={voicePlaybackSrc(r.audioData, r.audioUrl)}
                          className="mt-1.5 h-9 w-full"
                          aria-label={`Réponse vocale de ${r.senderName}`}
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Formulaire écrit de réclamation (module 🚨 invité)
// Catégorie + description + photos (≤ 3, 500 Ko, PNG/JPEG/WebP)
// + checkbox Urgent + nom optionnel → POST /api/public/hub/[slug]/complaint
// =============================================================
const COMPLAINT_CATEGORIES = [
  { value: 'PLUMBING', label: '🚰 Fuite / Plomberie' },
  { value: 'ELECTRICAL', label: '⚡ Électricité' },
  { value: 'CLEANING', label: '🧹 Ménage' },
  { value: 'OTHER', label: '📝 Autre' },
] as const;

const MAX_PHOTO_BYTES = 500 * 1024;
const MAX_PHOTOS = 3;

function ComplaintFormDialog({
  open,
  onClose,
  slug,
  propertyName,
}: {
  open: boolean;
  onClose: () => void;
  slug: string;
  propertyName: string;
}) {
  const [category, setCategory] = useState<string>('OTHER');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [isUrgent, setIsUrgent] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [sending, setSending] = useState(false);

  const reset = useCallback(() => {
    setCategory('OTHER');
    setDescription('');
    setPhotos([]);
    setIsUrgent(false);
    setGuestName('');
  }, []);

  const addPhotos = useCallback(
    (files: FileList | null) => {
      if (!files) return;
      const remaining = MAX_PHOTOS - photos.length;
      if (remaining <= 0) {
        toast.error(`Maximum ${MAX_PHOTOS} photos.`);
        return;
      }
      for (const file of Array.from(files).slice(0, remaining)) {
        if (!['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type)) {
          toast.error(`« ${file.name} » : format non supporté (PNG, JPEG ou WebP).`);
          continue;
        }
        if (file.size > MAX_PHOTO_BYTES) {
          toast.error(`« ${file.name} » dépasse 500 Ko.`);
          continue;
        }
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            setPhotos((prev) => (prev.length >= MAX_PHOTOS ? prev : [...prev, reader.result as string]));
          }
        };
        reader.readAsDataURL(file);
      }
    },
    [photos.length],
  );

  const submit = async () => {
    if (description.trim().length < 5) {
      toast.error('Décrivez le problème (5 caractères minimum).');
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/complaint`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          description: description.trim(),
          photos,
          isUrgent,
          guestName: guestName.trim() || undefined,
        }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Envoi impossible. Réessayez.');
        return;
      }
      toast.success('✅ Réclamation envoyée. L’hôte vous contactera bientôt.');
      reset();
      onClose();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !sending && !v && onClose()}>
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">🚨 Signaler un problème</DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Un souci dans {propertyName} ? Décrivez-le — l&apos;hôte est notifié immédiatement.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Catégorie */}
          <div>
            <Label htmlFor="complaint-category" className="text-xs font-semibold text-slate-700">
              Catégorie
            </Label>
            <select
              id="complaint-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1.5 w-full h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              {COMPLAINT_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="complaint-description" className="text-xs font-semibold text-slate-700">
              Description
            </Label>
            <Textarea
              id="complaint-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Décrivez le problème constaté, sa localisation dans le logement…"
              rows={4}
              maxLength={2000}
              className="mt-1.5 rounded-xl border-slate-300 text-sm focus-visible:ring-emerald-500"
            />
          </div>

          {/* Photos */}
          <div>
            <Label className="text-xs font-semibold text-slate-700">
              Photos <span className="font-normal text-slate-400">(optionnel — max {MAX_PHOTOS}, 500 Ko)</span>
            </Label>
            <div className="mt-1.5 flex items-center gap-2 flex-wrap">
              {photos.map((p, i) => (
                <div key={i} className="relative">
                  <img
                    src={p}
                    alt={`Photo ${i + 1}`}
                    className="h-16 w-16 rounded-lg border border-slate-200 object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <button
                    type="button"
                    aria-label={`Retirer la photo ${i + 1}`}
                    className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-slate-900 text-white inline-flex items-center justify-center shadow-sm hover:bg-slate-700"
                    onClick={() => setPhotos((prev) => prev.filter((_, j) => j !== i))}
                  >
                    <X className="h-3 w-3" aria-hidden="true" />
                  </button>
                </div>
              ))}
              {photos.length < MAX_PHOTOS && (
                <label className="h-16 w-16 rounded-lg border-2 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:border-slate-400 hover:text-slate-600 transition-colors">
                  <ImagePlus className="h-5 w-5" aria-hidden="true" />
                  <span className="text-[9px] font-semibold mt-0.5">Ajouter</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    multiple
                    className="sr-only"
                    onChange={(e) => {
                      addPhotos(e.target.files);
                      e.target.value = '';
                    }}
                  />
                </label>
              )}
            </div>
          </div>

          {/* Urgent + nom */}
          <div className="flex items-center gap-2">
            <Checkbox
              id="complaint-urgent"
              checked={isUrgent}
              onCheckedChange={(v) => setIsUrgent(v === true)}
              className="border-slate-400"
            />
            <Label htmlFor="complaint-urgent" className="text-sm font-semibold text-red-600 cursor-pointer">
              ⚠️ Urgent
            </Label>
          </div>
          <div>
            <Label htmlFor="complaint-name" className="text-xs font-semibold text-slate-700">
              Votre nom <span className="font-normal text-slate-400">(optionnel)</span>
            </Label>
            <Input
              id="complaint-name"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Ex : Camille, appartement 12…"
              maxLength={80}
              className="mt-1.5 h-11 rounded-xl border-slate-300 text-sm focus-visible:ring-emerald-500"
            />
          </div>

          <Button
            type="button"
            disabled={sending}
            className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl"
            onClick={submit}
          >
            {sending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Envoi en cours…
              </>
            ) : (
              '🚨 Envoyer à l’hôte'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
