'use client';

import { use, useCallback, useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { createPortal } from 'react-dom';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronLeft,
  ChevronRight,
  Clock4,
  Copy,
  ImagePlus,
  LifeBuoy,
  Loader2,
  Mail,
  MessageCircle,
  Mic,
  Moon,
  Package,
  PencilLine,
  Phone,
  Play,
  Plus,
  ShieldCheck,
  Square,
  Star,
  Sun,
  Trash2,
  TriangleAlert,
  Wrench,
  X,
} from 'lucide-react';
import { QRTNumericKeypad } from '@/components/qrtags';
// DESIGN PREMIUM « LUXE TECH » (phase 2) — fond animé + reveals +
// cartes d'accueil gradient + module Wi-Fi « carte de crédit ».
import { AnimatedMeshGradient } from '@/components/premium/animated-mesh-gradient';
import { Reveal } from '@/components/premium/reveal';
// REFONTE IMMERSIVE (Task 29) — page d'entrée du hub : fond photo
// villa + overlay, typographie Playfair, cartes glassmorphism.
import { HeroLanding } from '@/components/hub-premium/hero-landing';
import { WifiPremiumCard } from '@/components/hub-premium/wifi-credit-card';
import { BrandLogo } from '@/components/ui/brand-logo';
import { EmojiIcon } from '@/components/ui/emoji-icon';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Toaster } from '@/components/ui/sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { formatDistance, formatEur } from '@/lib/b2b';
// FIX-VOCAL : lecture des audios via /api/uploads/voice (public/ n'est pas
// servi en standalone) + enregistrement compatible Safari/iOS (audio/mp4).
import { voiceAudioSrc, pickRecorderMime, extForMime } from '@/lib/voice-audio';
// BUG DASHBOARD→HUB — parité PWA : les modules remplis dans
// /airbnb/concierge (coffre-fort, SOS, bonnes adresses, guide des
// appareils) et l'Expérience Invité (guide visuel, vidéo bienvenue,
// late check-out, bouclier d'avis, kit de survie) partagent les
// mêmes parseurs tolérants.
import {
  accessCodeRows,
  geoDirectionsUrl,
  isLocalMediaUrl,
  isYouTubeUrl,
  spotCategoryMeta,
  type GuestAccessCodes,
  type GuestAppliance,
  type GuestEmergencyInfo,
  type GuestPremiumFeatures,
  type GuestSpot,
  type GuestSurvivalItem,
  type GuestVisualStep,
} from '@/lib/concierge';
// RÉPONSE VOCALE HÔTE — bouton d'enregistrement (mode hôte) avec
// pré-écoute avant envoi (POST /api/airbnb/voice-reply).
import { VoiceReplyButton } from '@/components/airbnb/host/voice-reply-button';
// REFONTE SERVICES PREMIUM (V4.14) — le hub QR hérite de l'expérience
// « conciergerie de luxe » de la PWA (header serif, recherche, chips,
// carrousel populaires, panier flottant, checkout créneau, confettis).
import { TabServices } from '@/components/guest-app/tab-services';
import { ServiceCover } from '@/components/guest-app/service-visual';
import type { GuestServiceOffer } from '@/components/guest-app/types';
// v4.24 « HUB RÉEL » — photos curated des tuiles/modules de l'accueil
// invité (vérifiées visuellement, CDN OSS stable, CSP https: OK).
import { HUB_ARRIVAL_PHOTOS, HUB_VISUALS } from '@/lib/hub-visuals';

// =============================================================
// ÉTAPE 5 — LE HUB QR CODE (expérience de scan, ultra-mobile-first)
//
// Écran d'accueil : 2 cartes principales
//   👤 MODE INVITÉ (libre) : Wi-Fi (copie MDP), Guidebook,
//      Commander un service, Signaler un problème / Contacter l'hôte
//   🔐 MODE HÔTE (PIN 4 chiffres via QRTNumericKeypad) :
//      grille de gestion rapide — Modifier le Wi-Fi, Réclamations
//      en attente, Gérer les prestataires.
//
// Design QRTags : fond dégradé subtil slate, cartes blanches
// border-slate-200 rounded-xl p-4 shadow-sm, emojis 24–32 px.
// PHASE 2 — refonte visuelle premium « LUXE TECH » : mesh gradient
// animé, glassmorphism avancé (.glass), chorégraphies framer-motion,
// carte Wi-Fi façon « carte de crédit » à mot de passe grattable.
// La LOGIQUE (auth PIN, appels API, états) reste STRICTEMENT inchangée.
// =============================================================

/** Easing expo partagé (même signature que <Reveal/>). */
const EASE_EXPO = [0.16, 1, 0.3, 1] as const;

interface GuestService {
  id: string;
  name: string;
  emoji: string;
  categoryLabel: string;
  description: string;
  priceLabel: string;
  /** REFONTE SERVICES PREMIUM (V4.14) — parité PWA : catalogue fin. */
  unitPrice: number | null;
  /** REFONTE SERVICES PREMIUM (V4.22) — démonstration sociale. */
  ratingAvg: number;
  totalReviews: number;
  /** v4.23 « hub réel » — photo de couverture (1re offre photographiée). */
  imageUrl?: string | null;
  offers: GuestServiceOffer[];
}

interface HubPayload {
  active: boolean;
  property: {
    id: string;
    name: string;
    propertyType: string;
    propertyTypeLabel: string;
    propertyTypeEmoji: string;
    address: string | null;
    hasPin: boolean;
  };
  ownerName: string | null;
  guest: {
    wifi: { networkName: string; password: string; securityType: string } | null;
    guidebookSlug: string | null;
    accessCodes: GuestAccessCodes | null;
    localSpots: GuestSpot[];
    visualGuide: GuestVisualStep[];
    emergency: GuestEmergencyInfo | null;
    // BUG DASHBOARD→HUB — parité PWA complète : guide des appareils,
    // modules premium (vidéo, late check-out, bouclier d'avis) et kit
    // de survie servis par /api/public/hub/[slug].
    appliances: GuestAppliance[];
    premiumFeatures: GuestPremiumFeatures | null;
    survivalKitItems: GuestSurvivalItem[];
    services: GuestService[];
    contact: { name: string; phone: string | null; email: string | null };
  };
}

interface HostProvider {
  id: string;
  name: string;
  emoji: string;
  categoryLabel: string;
  distanceKm: number;
  audience: string;
  priceLabel: string;
}

interface HostWrittenComplaint {
  id: string;
  category: string;
  categoryLabel: string;
  description: string;
  photos: string[];
  isUrgent: boolean;
  guestName: string | null;
  createdAt: string;
}

interface HostGuidebook {
  qrCodeId: string | null;
  title: string;
  sections: string[];
}

/** Commande ServiceOrder sérialisée côté API /orders (montant TOTAL,
 *  jamais le split commission/hôte). */
interface HostOrder {
  id: string;
  status: string;
  statusLabel: string;
  statusBadge: string;
  statusEmoji: string;
  totalEur: string;
  itemsSummary: string;
  providerName: string;
  providerEmoji: string;
  guestName: string;
  createdAt: string;
}

interface HostData {
  wifi: {
    qrCodeId: string;
    networkName: string;
    password: string;
    securityType: string;
  } | null;
  unreadMessages: {
    id: string;
    senderName: string;
    audioUrl: string;
    durationSec: number;
    createdAt: string;
  }[];
  complaints: HostWrittenComplaint[];
  openComplaints: number;
  pendingRequests: number;
  guidebook: HostGuidebook;
  providers: HostProvider[];
}

type HubView = 'loading' | 'error' | 'home' | 'guest' | 'host';

export function HubPageContent({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = use(params);

  const [view, setView] = useState<HubView>('loading');
  const [payload, setPayload] = useState<HubPayload | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [retryTick, setRetryTick] = useState(0);

  // Mode Hôte
  const [pinModal, setPinModal] = useState(false);
  const [pinError, setPinError] = useState('');
  const [pinLoading, setPinLoading] = useState(false);
  const [keypadKey, setKeypadKey] = useState(0); // remonte le clavier après un échec
  const [verifiedPin, setVerifiedPin] = useState('');
  const [hostData, setHostData] = useState<HostData | null>(null);

  // ----- THÈME DU HUB — bascule sombre / clair (demande client) -----
  // Le <html> peut porter la classe .dark (thème par défaut de l'app /
  // préférence système). Or les portails (overlay Services, dialogs
  // Radix, toasts) vivent au niveau <body> : ils héritent du thème de
  // <html>. Le hub gère donc SON propre thème : état local (clair par
  // défaut), persisté en localStorage('hub-theme') et appliqué sur
  // <html> via la classe .dark. Au démontage, la classe d'origine de
  // l'app est restituée (la PWA garde son thème sombre par défaut).
  const [hubTheme, setHubTheme] = useState<'light' | 'dark'>(() => {
    // État initial : préférence mémorisée du visiteur (clair par
    // défaut). Lu dès le premier rendu client — la vue invité n'étant
    // JAMAIS rendue côté serveur (elle apparaît après le fetch), il
    // ne peut pas y avoir de mismatch d'hydratation.
    if (typeof window === 'undefined') return 'light';
    try {
      const saved = window.localStorage.getItem('hub-theme');
      if (saved === 'dark' || saved === 'light') return saved;
    } catch {
      // Stockage indisponible (navigation privée stricte) → défaut clair.
    }
    return 'light';
  });
  const originalThemeRef = useRef<'light' | 'dark'>('light');

  // Montage : mémorise le thème d'origine de l'app pour le restituer
  // au démontage (écriture de ref uniquement, pas de setState).
  useEffect(() => {
    const root = document.documentElement;
    originalThemeRef.current = root.classList.contains('dark') ? 'dark' : 'light';
  }, []);

  // Applique le thème du hub sur <html> (portails et toasts inclus).
  useEffect(() => {
    const root = document.documentElement;
    if (hubTheme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
  }, [hubTheme]);

  // Démontage : restitue le thème d'origine de l'app.
  useEffect(() => {
    return () => {
      const root = document.documentElement;
      if (originalThemeRef.current === 'dark') root.classList.add('dark');
      else root.classList.remove('dark');
    };
  }, []);

  /** Bascule sombre ↔ clair + persistance localStorage. */
  const toggleHubTheme = useCallback(() => {
    setHubTheme((t) => {
      const next = t === 'dark' ? 'light' : 'dark';
      try {
        window.localStorage.setItem('hub-theme', next);
      } catch {
        // Stockage indisponible → la bascule fonctionne quand même.
      }
      return next;
    });
  }, []);

  // ----- Chargement du hub (fonction async déclarée DANS l'effet) -----
  useEffect(() => {
    async function run() {
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}`);
        const json = await res.json();
        if (res.status === 410) {
          setErrorMsg(json.message || 'Cette plaque QR a été désactivée.');
          setView('error');
          return;
        }
        if (!res.ok) {
          setErrorMsg(json.message || 'Ce hub est introuvable.');
          setView('error');
          return;
        }
        setPayload(json as HubPayload);
        setView('home');
      } catch {
        setErrorMsg('Impossible de charger le hub. Vérifiez votre connexion.');
        setView('error');
      }
    }
    run();
  }, [slug, retryTick]);

  /** Bouton Réessayer : retour au chargement + relance de l'effet. */
  const retryLoad = useCallback(() => {
    setView('loading');
    setRetryTick((t) => t + 1);
  }, []);

  // ----- Vérification PIN + chargement des données hôte -----
  const verifyPin = useCallback(
    async (pin: string) => {
      setPinLoading(true);
      setPinError('');
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        const json = await res.json();
        if (!res.ok) {
          setPinError(json.error || 'PIN incorrect');
          setPinLoading(false);
          setKeypadKey((k) => k + 1); // clavier neuf pour la prochaine tentative
          return;
        }
        const hostRes = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/host`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        if (!hostRes.ok) {
          setPinError('Impossible de charger les données hôte.');
          setPinLoading(false);
          return;
        }
        setHostData((await hostRes.json()) as HostData);
        setVerifiedPin(pin);
        setPinModal(false);
        setPinLoading(false);
        setView('host');
      } catch {
        setPinError('Erreur réseau. Réessayez.');
        setPinLoading(false);
      }
    },
    [slug],
  );

  // ----- Copie presse-papier -----
  const copy = useCallback(async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success(`${label} copié !`, { description: text });
    } catch {
      toast.error('Copie impossible sur ce navigateur.');
    }
  }, []);

  return (
    // `isolate` : crée un stacking context local pour que les fonds
    // premium fixés en -z-10 (mesh animé) restent AU-DESSUS du dégradé
    // de page mais SOUS tout le contenu.
    <div className="min-h-screen flex flex-col isolate bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-950 dark:to-slate-900">
      <Toaster position="top-center" richColors />

      {view === 'loading' && <LoadingScreen />}
      {view === 'error' && <ErrorScreen message={errorMsg} onRetry={retryLoad} />}

      {view === 'home' && payload && (
        <HomeView
          payload={payload}
          onGuestClick={() => setView('guest')}
          onHostClick={() => {
            setPinError('');
            setPinModal(true);
          }}
        />
      )}

      {view === 'guest' && payload && (
        <GuestView
          payload={payload}
          slug={slug}
          onBack={() => setView('home')}
          copy={copy}
          theme={hubTheme}
          onToggleTheme={toggleHubTheme}
        />
      )}

      {view === 'host' && payload && (
        <HostView
          payload={payload}
          hostData={hostData}
          slug={slug}
          pin={verifiedPin}
          onBack={() => setView('home')}
          onHostRefresh={(d) => setHostData(d)}
          onPinChanged={(p) => setVerifiedPin(p)}
        />
      )}

      {/* ----- Modale PIN Mode Hôte ----- */}
      <Dialog open={pinModal} onOpenChange={(open) => !open && !pinLoading && setPinModal(false)}>
        <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl p-6 [&>button]:hidden">
          <DialogHeader className="items-center text-center">
            <span className="mx-auto" aria-hidden="true">
              <EmojiIcon emoji="🔐" size="lg" variant="dark" />
            </span>
            <DialogTitle className="text-lg font-bold text-slate-900 text-center">Mode Hôte</DialogTitle>
            <DialogDescription className="text-sm text-slate-600 text-center">
              Saisissez votre code à 4 chiffres pour accéder à la gestion du logement.
            </DialogDescription>
          </DialogHeader>

          {pinLoading ? (
            <div className="flex flex-col items-center gap-3 py-8" aria-busy="true">
              <Loader2 className="h-8 w-8 animate-spin text-emerald-600" aria-hidden="true" />
              <p className="text-sm text-slate-500">Vérification du code…</p>
            </div>
          ) : (
            <div className="mt-2">
              <QRTNumericKeypad key={keypadKey} onComplete={verifyPin} />
              {pinError && (
                <p role="alert" className="mt-4 text-center text-sm font-semibold text-red-600">
                  {pinError}
                </p>
              )}
              <Button
                type="button"
                variant="outline"
                className="mt-4 w-full h-11 border-slate-300 text-slate-600"
                onClick={() => setPinModal(false)}
              >
                Annuler
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =============================================================
// Écran de chargement
// =============================================================
function LoadingScreen() {
  return (
    <div className="flex-1 w-full max-w-lg mx-auto px-4 py-10 space-y-5" aria-busy="true" aria-label="Chargement du hub">
      {/* Fond sombre : cohérent avec l'accueil immersif qui suit
          (évite le flash blanc avant le hero photo). */}
      <div aria-hidden="true" className="fixed inset-0 -z-10 bg-slate-950" />
      <div className="flex justify-center">
        <BrandLogo variant="light" size="sm" />
      </div>
      <Skeleton className="h-32 w-full rounded-xl bg-white/10" />
      <Skeleton className="h-24 w-full rounded-xl bg-white/10" />
      <Skeleton className="h-24 w-full rounded-xl bg-white/10" />
    </div>
  );
}

// =============================================================
// Écran d'erreur (QR introuvable / inactif / réseau)
// =============================================================
function ErrorScreen({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="flex-1 w-full max-w-lg mx-auto px-4 py-16 flex flex-col items-center justify-center text-center">
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-8 w-full">
        <span className="text-5xl" aria-hidden="true">🔌</span>
        <h1 className="mt-4 text-xl font-bold text-slate-900">Hub indisponible</h1>
        <p className="mt-2 text-sm text-slate-600 leading-relaxed">{message}</p>
        <Button
          type="button"
          onClick={onRetry}
          className="mt-6 h-11 px-6 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
        >
          Réessayer
        </Button>
        <p className="mt-6 text-xs text-slate-400">
          Propulsé par 🗝️ <span className="font-semibold text-slate-500">Conciergerie Hub</span>
        </p>
      </div>
    </div>
  );
}

// =============================================================
// ÉCRAN D'ACCUEIL — REFONTE IMMERSIVE « LUXE TECH » (Task 29)
// Le rendu complet (fond photo villa + overlay, typographie
// Playfair, cartes glassmorphism, chorégraphie framer-motion)
// vit dans <HeroLanding/> ; toute la logique (navigation,
// ouverture du PIN hôte) reste ici, inchangée.
// =============================================================
function HomeView({
  payload,
  onGuestClick,
  onHostClick,
}: {
  payload: HubPayload;
  onGuestClick: () => void;
  onHostClick: () => void;
}) {
  const { property, ownerName } = payload;
  return (
    <HeroLanding
      propertyName={property.name}
      propertyTypeEmoji={property.propertyTypeEmoji}
      propertyTypeLabel={property.propertyTypeLabel}
      ownerName={ownerName}
      onGuestClick={onGuestClick}
      onHostClick={onHostClick}
    />
  );
}

// =============================================================
// MODE INVITÉ — « WALLET DE CARTES PREMIUM » (Task 30, itération 3)
// Retour client : « que tous les modules s'affichent comme le carré
// du module Wi-Fi ». La grille de petites tuiles disparaît : chaque
// module devient une CARTE PLEINE LARGEUR reprenant EXACTEMENT
// l'anatomie de la carte Wi-Fi (WifiPremiumCard) :
//   • carte blanche dégradé teinté (rounded-3xl, ombre douce)
//   • puce EMV colorée en haut à gauche + emoji filigrane géant
//   • eyebrow uppercase tracking-[0.25em] coloré par ton sémantique
//   • titre en font-serif (display-title) + aperçu inline (chips)
//   • ZÉRO animation framer-motion — transitions CSS discrètes.
//   • Thème CLAIR, 7 tons (émeraude, ambre, rose, violet, teal,
//     orange, rouge) — la couleur porte l'identité du module.
// itération 4 — bouton ☀️/🌙 dans le hero : bascule sombre/clair
// mémorisée par visiteur (localStorage 'hub-theme') ; la classe .dark
// de <html> pilote fond, cartes, dialogs et portails.
// Organisation : 2 flagship pleine largeur (Wi-Fi, Services) puis
// 3 sections « Votre logement » / « Pendant votre séjour » /
// « Besoin d'aide ? » — 1 colonne mobile, 2 colonnes sm+.
// Toute la LOGIQUE métier (états, API, portails, dialogs existants)
// reste STRICTEMENT identique.
// =============================================================

type TileTone = 'emerald' | 'amber' | 'rose' | 'violet' | 'teal' | 'orange' | 'red';

/** Palettes CLAIRES « carte bancaire » — un ton par module. La couleur
 * vit dans : la bordure teintée, le dégradé de fond, la puce EMV,
 * l'eyebrow et la tuile d'icône des dialogs — comme sur la carte Wi-Fi. */
const CARD_TONES: Record<
  TileTone,
  { border: string; wash: string; chip: string; eyebrow: string; iconTile: string }
> = {
  emerald: {
    border:
      'border-emerald-200/80 hover:border-emerald-300 dark:border-emerald-500/25 dark:hover:border-emerald-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-emerald-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-emerald-950/50',
    chip: 'border-emerald-700/40 bg-gradient-to-br from-emerald-200 via-emerald-400 to-emerald-600',
    eyebrow: 'text-emerald-500 dark:text-emerald-300',
    iconTile:
      'bg-gradient-to-br from-emerald-100 to-emerald-300 shadow-[0_10px_26px_-10px_rgba(16,185,129,0.6)]',
  },
  amber: {
    border:
      'border-amber-200/80 hover:border-amber-300 dark:border-amber-500/25 dark:hover:border-amber-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-amber-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-amber-950/50',
    chip: 'border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600',
    eyebrow: 'text-amber-500 dark:text-amber-300',
    iconTile:
      'bg-gradient-to-br from-amber-100 to-amber-300 shadow-[0_10px_26px_-10px_rgba(245,158,11,0.6)]',
  },
  rose: {
    border:
      'border-rose-200/80 hover:border-rose-300 dark:border-rose-500/25 dark:hover:border-rose-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-rose-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-rose-950/50',
    chip: 'border-rose-700/40 bg-gradient-to-br from-rose-200 via-rose-400 to-rose-600',
    eyebrow: 'text-rose-500 dark:text-rose-300',
    iconTile:
      'bg-gradient-to-br from-rose-100 to-rose-300 shadow-[0_10px_26px_-10px_rgba(244,63,94,0.55)]',
  },
  violet: {
    border:
      'border-violet-200/80 hover:border-violet-300 dark:border-violet-500/25 dark:hover:border-violet-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-violet-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-violet-950/50',
    chip: 'border-violet-700/40 bg-gradient-to-br from-violet-200 via-violet-400 to-violet-600',
    eyebrow: 'text-violet-500 dark:text-violet-300',
    iconTile:
      'bg-gradient-to-br from-violet-100 to-violet-300 shadow-[0_10px_26px_-10px_rgba(139,92,246,0.55)]',
  },
  teal: {
    border:
      'border-teal-200/80 hover:border-teal-300 dark:border-teal-500/25 dark:hover:border-teal-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-teal-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-teal-950/50',
    chip: 'border-teal-700/40 bg-gradient-to-br from-teal-200 via-teal-400 to-teal-600',
    eyebrow: 'text-teal-500 dark:text-teal-300',
    iconTile:
      'bg-gradient-to-br from-teal-100 to-teal-300 shadow-[0_10px_26px_-10px_rgba(20,184,166,0.6)]',
  },
  orange: {
    border:
      'border-orange-200/80 hover:border-orange-300 dark:border-orange-500/25 dark:hover:border-orange-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-orange-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-orange-950/50',
    chip: 'border-orange-700/40 bg-gradient-to-br from-orange-200 via-orange-400 to-orange-600',
    eyebrow: 'text-orange-500 dark:text-orange-300',
    iconTile:
      'bg-gradient-to-br from-orange-100 to-orange-300 shadow-[0_10px_26px_-10px_rgba(249,115,22,0.6)]',
  },
  red: {
    border:
      'border-red-200/80 hover:border-red-300 dark:border-red-500/25 dark:hover:border-red-400/50',
    wash:
      'bg-gradient-to-br from-white via-white to-red-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-red-950/50',
    chip: 'border-red-700/40 bg-gradient-to-br from-red-200 via-red-400 to-red-600',
    eyebrow: 'text-red-500 dark:text-red-300',
    iconTile:
      'bg-gradient-to-br from-red-100 to-red-300 shadow-[0_10px_26px_-10px_rgba(239,68,68,0.55)]',
  },
};

/** Carte module — v4.28 « PHOTO PLEINE CARTE » (Option A, retour client :
 * « toutes les cards comme le QR code, une GRANDE image ») :
 *   • la VRAIE photo remplit TOUTE la carte (object-cover, comme le héro) ;
 *   • voile dégradé noir + textes blancs posés en bas (eyebrow, titre serif,
 *     sous-titre, chips d'aperçu) — lisibilité garantie ;
 *   • puce EMV translucide en haut à gauche (identité « carte de crédit »
 *     conservée) + flèche blanche en haut à droite ;
 *   • onError ou photo absente → retour à l'anatomie « carte de crédit »
 *     historique (ton sémantique + filigrane emoji) — jamais de carte vide.
 * STATIQUE (demande client : zéro animation framer-motion) — uniquement
 * des transitions CSS discrètes (zoom photo au survol). */
function ModuleCard({
  emoji,
  tone,
  eyebrow,
  title,
  subtitle,
  onClick,
  disabled,
  imageUrl,
  children,
}: {
  emoji: string;
  tone: TileTone;
  /** Petit libellé uppercase au-dessus du titre (ex. « Trousseau numérique »). */
  eyebrow: string;
  title: string;
  subtitle?: string;
  onClick?: () => void;
  disabled?: boolean;
  /** Vraie photo PLEINE CARTE (v4.28) — optionnelle, décorative (alt="") ;
   *  le fallback « carte de crédit » filigrane emoji reste le repli. */
  imageUrl?: string | null;
  children?: React.ReactNode;
}) {
  const t = CARD_TONES[tone];
  const interactive = !!onClick && !disabled;
  const [photoFailed, setPhotoFailed] = useState(false);
  const showPhoto = !!imageUrl && !photoFailed;

  // ── FALLBACK (photo absente ou échouée) — carte de crédit historique ──
  if (!showPhoto) {
    return (
      <button
        type="button"
        onClick={interactive ? onClick : undefined}
        disabled={!interactive}
        aria-label={`${title}${subtitle ? ` — ${subtitle}` : ''}`}
        className={cn(
          'group relative flex h-full min-h-44 w-full flex-col overflow-hidden rounded-3xl border p-5 text-left text-slate-900 dark:text-slate-100',
          'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.28)] transition-[border-color,box-shadow] duration-300',
          'focus:outline-none focus-visible:ring-2 focus-visible:ring-slate-900/25',
          t.border,
          t.wash,
          interactive
            ? 'cursor-pointer hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.4)]'
            : 'cursor-default opacity-60 saturate-[0.4]',
        )}
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-2 -top-6 select-none text-[96px] leading-none opacity-[0.09]"
        >
          {emoji}
        </span>

        {/* Rangée 1 : puce EMV colorée + flèche */}
        <span className="relative flex items-start justify-between">
          <span
            aria-hidden="true"
            className={cn('relative mt-0.5 block h-8 w-11 rounded-md border shadow-inner', t.chip)}
          >
            <span className="absolute inset-x-0 top-1/2 h-px bg-black/15" />
            <span className="absolute inset-y-0 left-1/2 w-px bg-black/15" />
          </span>
          {interactive && (
            <ArrowRight
              aria-hidden="true"
              className="h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 group-hover:translate-x-1"
            />
          )}
        </span>

        {/* Eyebrow + titre serif (langage carte Wi-Fi) */}
        <span className={cn('relative mt-3.5 text-[10px] font-bold uppercase tracking-[0.25em]', t.eyebrow)}>
          <span aria-hidden="true" className="mr-1.5">{emoji}</span>
          {eyebrow}
        </span>
        <span className="display-title font-serif! relative mt-0.5 text-xl font-bold leading-tight text-slate-900 dark:text-white">
          {title}
        </span>
        {subtitle && (
          <span className="relative mt-1 line-clamp-2 text-xs leading-snug text-slate-500 dark:text-slate-400">{subtitle}</span>
        )}

        {/* Aperçu inline optionnel (chips de contenu) */}
        {children != null && <span className="relative mt-3.5 block">{children}</span>}
      </button>
    );
  }

  // ── v4.28 « PHOTO PLEINE CARTE » — toute la carte est une photo ──
  return (
    <button
      type="button"
      onClick={interactive ? onClick : undefined}
      disabled={!interactive}
      aria-label={`${title}${subtitle ? ` — ${subtitle}` : ''}`}
      className={cn(
        'group relative flex h-44 w-full flex-col justify-between overflow-hidden rounded-3xl border border-black/10 text-left sm:h-52',
        'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.45)] transition-[border-color,box-shadow] duration-300',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80',
        interactive
          ? 'cursor-pointer hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.6)]'
          : 'cursor-default opacity-60 saturate-[0.5]',
      )}
    >
      <img
        src={imageUrl ?? undefined}
        alt=""
        loading="lazy"
        decoding="async"
        className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
        onError={() => setPhotoFailed(true)}
      />
      {/* Voile dégradé — lisibilité du texte blanc en bas de la photo */}
      <span
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/15"
      />

      {/* Rangée 1 : puce EMV translucide (identité carte) + flèche blanche */}
      <span className="relative flex items-start justify-between p-4">
        <span
          aria-hidden="true"
          className="relative mt-0.5 block h-8 w-11 rounded-md border border-white/40 bg-white/25 shadow-inner backdrop-blur-sm"
        >
          <span className="absolute inset-x-0 top-1/2 h-px bg-white/50" />
          <span className="absolute inset-y-0 left-1/2 w-px bg-white/50" />
        </span>
        {interactive && (
          <ArrowRight
            aria-hidden="true"
            className="h-5 w-5 shrink-0 text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:translate-x-1"
          />
        )}
      </span>

      {/* Eyebrow + titre serif + sous-titre + chips — blancs sur la photo */}
      <span className="relative flex flex-col p-4 pt-0">
        <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-white/85 drop-shadow-sm">
          <span aria-hidden="true" className="mr-1.5">{emoji}</span>
          {eyebrow}
        </span>
        <span className="display-title font-serif! mt-0.5 text-xl font-bold leading-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.55)]">
          {title}
        </span>
        {subtitle && (
          <span className="mt-1 line-clamp-2 text-xs leading-snug text-white/85 drop-shadow-sm">{subtitle}</span>
        )}

        {/* Aperçu inline optionnel (chips de contenu, verre blanc) */}
        {children != null && <span className="mt-3 block">{children}</span>}
      </span>
    </button>
  );
}

/** Chip d'aperçu inline dans une ModuleCard (non cliquable, purement
 * informative — le contenu réel reste dans les dialogs). */
function PreviewChip({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1 truncate rounded-full border border-slate-200/90 bg-white/85 px-2.5 py-1 text-[11px] font-semibold text-slate-600 shadow-sm dark:border-white/10 dark:bg-white/10 dark:text-slate-200">
      {children}
    </span>
  );
}

/** Séparateur de section (lignes dégradées + libellé tracking). */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div aria-hidden="true" className="mt-7 mb-4 flex items-center gap-3">
      <span className="h-px flex-1 bg-gradient-to-r from-transparent to-slate-300 dark:to-white/15" />
      <span className="text-[10.5px] font-bold uppercase tracking-[0.24em] text-slate-400 dark:text-slate-500">
        {children}
      </span>
      <span className="h-px flex-1 bg-gradient-to-l from-transparent to-slate-300 dark:to-white/15" />
    </div>
  );
}

/** Dialog clair ouvert par une tuile — remplace le contenu dépliable
 * inline des anciennes cartes (contenu métier inchangé). Version
 * claire : fond blanc, bordure slate, titre slate-900, tuile
 * d'icône toujours colorée. */
function TileDialog({
  open,
  onOpenChange,
  emoji,
  tone,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  emoji: string;
  tone: TileTone;
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  const t = CARD_TONES[tone];
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md sm:max-w-md rounded-3xl border border-slate-200 bg-white p-5 text-slate-900 shadow-xl sm:p-6 dark:border-white/10 dark:bg-slate-900 dark:text-slate-100">
        <DialogHeader className="items-start text-left">
          <div className="flex items-center gap-3 pr-6">
            <span
              aria-hidden="true"
              className={cn(
                'inline-flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl leading-none',
                t.iconTile,
              )}
            >
              {emoji}
            </span>
            <div className="min-w-0">
              <DialogTitle className="display-title font-serif! text-xl font-bold text-slate-900 dark:text-white">
                {title}
              </DialogTitle>
              <DialogDescription className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{subtitle}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <div className="-mx-1 max-h-[60dvh] overflow-y-auto px-1 pb-1 custom-scrollbar">{children}</div>
      </DialogContent>
    </Dialog>
  );
}

function GuestView({
  payload,
  slug,
  onBack,
  copy,
  theme,
  onToggleTheme,
}: {
  payload: HubPayload;
  slug: string;
  onBack: () => void;
  copy: (text: string, label: string) => Promise<void>;
  /** Thème du hub (« light » par défaut, mémorisé par visiteur). */
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}) {
  const [contactOpen, setContactOpen] = useState(false);
  const [complaintFormOpen, setComplaintFormOpen] = useState(false);
  // Modules premium (dialogs vidéo / bouclier d'avis).
  const [videoOpen, setVideoOpen] = useState(false);
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const router = useRouter();
  const { property, guest } = payload;

  return (
    // Thème du hub piloté par le bouton ☀️/🌙 (clair par défaut) :
    // fond, cartes et dialogs suivent la classe .dark de <html>.
    <div className="flex-1 w-full">
      {/* Fond fixe — dégradé statique très léger, zéro animation */}
      <div
        aria-hidden="true"
        className="fixed inset-0 -z-10 bg-gradient-to-b from-amber-50/70 via-white to-stone-100 dark:from-slate-950 dark:via-slate-950 dark:to-black"
      />

      {/* ── HERO PHOTO — carte arrondie premium (défile avec la page) ──
          Même image que l'accueil : continuité visuelle. */}
      <section
        aria-label="Espace invité"
        className="relative mx-auto w-full max-w-lg px-4 pt-5 sm:max-w-2xl lg:max-w-3xl"
      >
        <div className="relative h-44 overflow-hidden rounded-3xl shadow-[0_22px_50px_-22px_rgba(15,23,42,0.45)] sm:h-56">
          <Image
            src="/hub-hero-villa.jpg"
            alt=""
            fill
            priority
            unoptimized
            sizes="(max-width: 640px) 100vw, 768px"
            className="object-cover object-center"
          />
          {/* Voile sombre léger : lisibilité du titre blanc sur la photo */}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-b from-black/35 via-black/20 to-black/55"
          />

          {/* Retour + pill signature + bascule thème — au-dessus de la photo */}
          <div className="absolute top-4 left-4 right-4 flex items-center">
            <button
              type="button"
              onClick={onBack}
              aria-label="Retour à l'accueil"
              className="h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl border border-white/40 bg-white/85 text-slate-800 shadow-sm backdrop-blur-md transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
            >
              <ChevronLeft className="h-5 w-5" aria-hidden="true" />
            </button>
            <span className="ml-3 hidden min-[420px]:inline-flex items-center gap-1.5 rounded-full border border-white/40 bg-white/80 px-3 py-1.5 text-[11px] font-medium tracking-wide text-slate-700 shadow-sm backdrop-blur-md">
              ✨ Expérience Conciergerie
            </span>
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={theme === 'dark' ? 'Activer le mode clair' : 'Activer le mode sombre'}
              title={theme === 'dark' ? 'Mode clair' : 'Mode sombre'}
              className="ml-auto h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl border border-white/40 bg-white/85 text-slate-800 shadow-sm backdrop-blur-md transition-colors hover:bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white active:scale-95"
            >
              {theme === 'dark' ? (
                <Sun className="h-5 w-5" aria-hidden="true" />
              ) : (
                <Moon className="h-5 w-5" aria-hidden="true" />
              )}
            </button>
          </div>

          {/* Titre du bien — bas du hero */}
          <div className="absolute bottom-4 left-4 right-4">
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-white/75">
              👤 Espace Invité
            </p>
            <h1 className="display-title font-serif! mt-1 text-3xl font-bold leading-tight text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.5)] sm:text-4xl">
              {property.name}
            </h1>
          </div>
        </div>
      </section>

      {/* ── CONTENU — « wallet » de cartes premium (Task 30, itération 3) ── */}
      <div className="w-full max-w-lg sm:max-w-2xl lg:max-w-3xl mx-auto px-4 flex-1 flex flex-col">
        <p className="mt-5 text-center text-[13px] text-slate-500 dark:text-slate-400">
          ✨ Tout votre séjour au même endroit.
        </p>

        {/* ── FLAGSHIP 1 : 📶 Wi-Fi « carte de crédit » à gratter ──
            (larges largeurs : les 2 flagship restent contenu-lg centré) */}
        <div className="mx-auto w-full max-w-lg">
          {guest.wifi ? <WifiPremiumCard wifi={guest.wifi} copy={copy} /> : null}

          {/* ── FLAGSHIP 2 : 🥐 Services & Expériences — même anatomie carte ── */}
          <ServicesCard services={guest.services} contact={guest.contact} property={property} slug={slug} />
        </div>

        {/* ── SECTION 1 : VOTRE LOGEMENT ── */}
        <SectionLabel>🏠 Votre logement</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">
          {/* 🔑 Accès & Codes (coffre-fort numérique) */}
          {guest.accessCodes && (
            <AccessCodesCard codes={guest.accessCodes} copy={copy} />
          )}

          {/* 📖 Guidebook */}
          {guest.guidebookSlug ? (
            <ModuleCard
              emoji="📖"
              tone="teal"
              eyebrow="Guide de la maison"
              title="Guidebook"
              subtitle="Accès, équipements, règles & bonnes adresses"
              imageUrl={HUB_VISUALS.guidebook}
              onClick={() => guest.guidebookSlug && router.push(`/view/${guest.guidebookSlug}`)}
            >
              <span className="flex flex-wrap gap-1.5">
                <PreviewChip>🗝️ Arrivée</PreviewChip>
                <PreviewChip>🛏️ Équipements</PreviewChip>
                <PreviewChip>📋 Règles</PreviewChip>
              </span>
            </ModuleCard>
          ) : (
            <ModuleCard
              emoji="📖"
              tone="teal"
              eyebrow="Guide de la maison"
              title="Guidebook"
              subtitle="Votre hôte prépare son guide"
              imageUrl={HUB_VISUALS.guidebook}
              disabled
            />
          )}

          {/* 🗺️ Arrivée pas à pas (guide visuel — Expérience Invité) */}
          {guest.visualGuide.length > 0 && (
            <VisualGuideCard steps={guest.visualGuide} />
          )}

          {/* 🛠️ Guide des appareils (concierge → Property.appliances) */}
          {guest.appliances.length > 0 && (
            <AppliancesCard appliances={guest.appliances} />
          )}

          {/* 🧰 Kit de survie (Expérience Invité → survivalKitItems) */}
          {guest.survivalKitItems.length > 0 && (
            <SurvivalKitCard items={guest.survivalKitItems} />
          )}

          {/* 📶 Wi-Fi indisponible — carte fantôme (si pas de Wi-Fi) */}
          {!guest.wifi && (
            <ModuleCard
              emoji="📶"
              tone="teal"
              eyebrow="Connexion"
              title="Wi-Fi"
              subtitle="Informations en cours de préparation"
              imageUrl={HUB_VISUALS.wifi}
              disabled
            />
          )}
        </div>

        {/* ── SECTION 2 : PENDANT VOTRE SÉJOUR ── */}
        <SectionLabel>✨ Pendant votre séjour</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">
          {/* 🎬 Vidéo de bienvenue (Expérience Invité → premiumFeatures) */}
          {guest.premiumFeatures?.videoWelcomeUrl && (
            <WelcomeVideoCard
              url={guest.premiumFeatures.videoWelcomeUrl}
              propertyName={property.name}
              open={videoOpen}
              onOpenChange={setVideoOpen}
            />
          )}

          {/* ⏱️ Départ tardif (upselling → premiumFeatures.enableLateCheckout) */}
          {guest.premiumFeatures?.enableLateCheckout && (
            <LateCheckoutCard
              slug={slug}
              price={guest.premiumFeatures.lateCheckoutPrice}
              propertyName={property.name}
            />
          )}

          {/* 📍 Quartier & bonnes adresses (carte secrète de l'hôte) */}
          {guest.localSpots.length > 0 && (
            <LocalSpotsCard spots={guest.localSpots} />
          )}

          {/* ⭐ Bouclier d'avis (premiumFeatures.enableReviewShield) */}
          {guest.premiumFeatures?.enableReviewShield && (
            <ReviewShieldCard
              slug={slug}
              propertyName={property.name}
              reviewUrl={guest.premiumFeatures.reviewUrl}
              open={feedbackOpen}
              onOpenChange={setFeedbackOpen}
            />
          )}
        </div>

        {/* ── SECTION 3 : BESOIN D'AIDE ? ── */}
        <SectionLabel>🆘 Besoin d&apos;aide ?</SectionLabel>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-stretch">
          {/* 🆘 SOS & Urgences — toujours visible (numéros nationaux + DB) */}
          <SosCard emergency={guest.emergency} />

          {/* 🚨 Signaler un problème — formulaire écrit */}
          <ModuleCard
            emoji="🚨"
            tone="orange"
            eyebrow="Support réactif"
            title="Signaler un problème"
            subtitle="Fuite, électricité, ménage… avec photos"
            imageUrl={HUB_VISUALS.issue}
            onClick={() => setComplaintFormOpen(true)}
          >
            <span className="flex flex-wrap gap-1.5">
              <PreviewChip>📸 Avec photos</PreviewChip>
              <PreviewChip>⚡ Réponse rapide</PreviewChip>
            </span>
          </ModuleCard>

          {/* 📞 Contacter l'hôte */}
          <ModuleCard
            emoji="📞"
            tone="emerald"
            eyebrow="Votre hôte"
            title="Contacter l'hôte"
            subtitle={`${guest.contact.name} — appel, email, vocal`}
            imageUrl={HUB_VISUALS.host}
            onClick={() => setContactOpen(true)}
          >
            <span className="flex flex-wrap gap-1.5">
              <PreviewChip>📞 Appel</PreviewChip>
              <PreviewChip>✉️ Email</PreviewChip>
              <PreviewChip>🎤 Vocal</PreviewChip>
            </span>
          </ModuleCard>
        </div>

      <footer className="mt-auto pt-10 pb-6 text-center">
        <p className="text-xs text-slate-400 dark:text-slate-500">
          Propulsé par <span className="font-semibold text-slate-500 dark:text-slate-400">Conciergerie Hub</span>
        </p>
      </footer>

      <ComplaintFormDialog
        open={complaintFormOpen}
        onClose={() => setComplaintFormOpen(false)}
        slug={slug}
        propertyName={property.name}
      />

      <ContactDialog
        open={contactOpen}
        onClose={() => setContactOpen(false)}
        slug={slug}
        contact={guest.contact}
        propertyName={property.name}
      />
      </div>
    </div>
  );
}

/** Carte « Commander un service » — REFONTE SERVICES PREMIUM (V4.14).
 * Tuile XXL flagship (icône 64 px ambre + promesse « 1 clic »)
 * qui ouvre un OVERLAY PLEIN ÉCRAN reprenant l'expérience complète de la
 * PWA : header serif, recherche, chips catégories, carrousel
 * « Les plus demandés », panier flottant, checkout créneau 30 min,
 * paiement Stripe et confirmation confettis. Fini le mailto ! */
function ServicesCard({
  services,
  contact,
  property,
  slug,
}: {
  services: GuestService[];
  contact: HubPayload['guest']['contact'];
  property: HubPayload['property'];
  slug: string;
}) {
  const [open, setOpen] = useState(false);

  // Scroll lock du fond pendant l'overlay (comme les Dialog shadcn).
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  const previews = services.slice(0, 4);
  const orderableCount = services.filter(
    (s) => s.offers.length > 0 || s.unitPrice != null,
  ).length;
  // v4.24 « HUB RÉEL » — la carte flagship porte la VRAIE photo du 1er
  // service photographié en filigrane (fallback : viennoiseries curated,
  // puis emoji 🥐 si la photo échoue — progressif).
  const cardPhoto = services.find((s) => s.imageUrl)?.imageUrl ?? HUB_VISUALS.breakfast;
  const [cardPhotoFailed, setCardPhotoFailed] = useState(false);

  return (
    <>
      {/* ── Carte flagship — v4.28 « PHOTO PLEINE CARTE » (Option A) :
          la photo du 1er service remplit TOUTE la carte ; onError →
          retour carte de crédit ambre historique (jamais de carte vide). ── */}
      {!cardPhotoFailed ? (
        <button
          type="button"
          onClick={() => services.length > 0 && setOpen(true)}
          disabled={services.length === 0}
          aria-label="Services & Expériences — commander"
          className={cn(
            'group relative mt-4 flex h-56 w-full flex-col justify-between overflow-hidden rounded-3xl border border-black/10 text-left sm:h-64',
            'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.45)] transition-[border-color,box-shadow] duration-300',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80',
            services.length === 0 && 'cursor-default opacity-60 saturate-[0.5]',
          )}
        >
          <img
            src={cardPhoto}
            alt=""
            loading="lazy"
            decoding="async"
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            onError={() => setCardPhotoFailed(true)}
          />
          <span
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/15"
          />
          {/* Rangée 1 : puce EMV dorée + flèche */}
          <span className="relative flex items-start justify-between p-4">
            <span
              aria-hidden="true"
              className="relative mt-0.5 block h-8 w-11 rounded-md border border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-inner"
            >
              <span className="absolute inset-x-0 top-1/2 h-px bg-amber-900/30" />
              <span className="absolute inset-y-0 left-1/2 w-px bg-amber-900/30" />
            </span>
            {services.length > 0 && (
              <ArrowRight
                aria-hidden="true"
                className="h-5 w-5 shrink-0 text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.6)] transition-transform duration-300 group-hover:translate-x-1"
              />
            )}
          </span>
          {/* Textes blancs posés sur la photo */}
          <span className="relative flex flex-col p-4 pt-0">
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-amber-200 drop-shadow-sm">
              <span aria-hidden="true" className="mr-1.5">🥐</span>
              Conciergerie · Commande en 1 clic
            </span>
            <span className="display-title font-serif! mt-0.5 text-xl font-bold leading-tight text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.55)]">
              Services &amp; Expériences
            </span>
            <span className="mt-1 line-clamp-2 text-xs leading-snug text-white/85 drop-shadow-sm">
              {services.length > 0
                ? `Commandez en 1 clic, livré à votre porte — ${services.length} expérience${services.length > 1 ? 's' : ''} autour de ${property.name}`
                : 'Aucun service pour le moment'}
            </span>
            {services.length > 0 && (
              <span className="mt-3 flex flex-col gap-2.5 border-t border-white/25 pt-3">
                {/* Aperçus des couvertures — vignettes verre sur la photo */}
                <span className="flex items-center gap-2">
                  {previews.map((svc) => (
                    <ServiceCover
                      key={svc.id}
                      emoji={svc.emoji}
                      categoryLabel={svc.categoryLabel}
                      imageUrl={svc.imageUrl}
                      alt={`Photo — ${svc.name}`}
                      className="h-14 w-14 rounded-xl shrink-0"
                      emojiClassName="text-2xl"
                    />
                  ))}
                  {services.length > previews.length && (
                    <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-white/30 bg-white/20 backdrop-blur-sm">
                      <span className="text-xs font-bold text-white drop-shadow-sm">
                        +{services.length - previews.length}
                      </span>
                    </span>
                  )}
                </span>
                <span className="flex items-center gap-1 text-[11px] font-semibold text-white/90 drop-shadow-sm">
                  {orderableCount > 0 ? (
                    <>
                      <span aria-hidden="true">⚡</span>
                      Paiement sécurisé · Créneau au choix · Suivi en direct
                    </>
                  ) : (
                    <>
                      <span aria-hidden="true">✉️</span>
                      Votre hôte organise la réservation pour vous
                    </>
                  )}
                </span>
              </span>
            )}
          </span>
        </button>
      ) : (
        /* FALLBACK — carte de crédit ambre historique (photo échouée) */
        <button
          type="button"
          onClick={() => services.length > 0 && setOpen(true)}
          disabled={services.length === 0}
          aria-label="Services & Expériences — commander"
          className={cn(
            'group relative mt-4 flex w-full flex-col overflow-hidden rounded-3xl border border-amber-200/80 p-5 text-left text-slate-900 dark:border-amber-500/25 dark:hover:border-amber-400/50 dark:text-slate-100',
            'bg-gradient-to-br from-white via-white to-amber-50/80 dark:from-slate-900 dark:via-slate-900 dark:to-amber-950/50',
            'shadow-[0_18px_44px_-20px_rgba(15,23,42,0.28)] transition-[border-color,box-shadow] duration-300',
            'hover:border-amber-300 hover:shadow-[0_24px_52px_-20px_rgba(15,23,42,0.4)]',
            'focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/40',
            services.length === 0 && 'cursor-default opacity-60',
          )}
        >
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-2 -top-6 select-none text-[96px] leading-none opacity-[0.09]"
          >
            🥐
          </span>
        {/* Rangée 1 : puce EMV dorée + flèche */}
        <span className="relative flex items-start justify-between">
          <span
            aria-hidden="true"
            className="relative mt-0.5 block h-8 w-11 rounded-md border border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-inner"
          >
            <span className="absolute inset-x-0 top-1/2 h-px bg-amber-900/30" />
            <span className="absolute inset-y-0 left-1/2 w-px bg-amber-900/30" />
          </span>
          {services.length > 0 && (
            <ArrowRight
              aria-hidden="true"
              className="h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 group-hover:translate-x-1"
            />
          )}
        </span>

        {/* Eyebrow + titre serif */}
        <span className="relative mt-3.5 text-[10px] font-bold uppercase tracking-[0.25em] text-amber-500 dark:text-amber-300">
          <span aria-hidden="true" className="mr-1.5">🥐</span>
          Conciergerie · Commande en 1 clic
        </span>
        <span className="display-title font-serif! relative mt-0.5 text-xl font-bold leading-tight text-slate-900 dark:text-white">
          Services &amp; Expériences
        </span>
        <span className="relative mt-1 line-clamp-2 text-xs leading-snug text-slate-500 dark:text-slate-400">
          {services.length > 0
            ? `Commandez en 1 clic, livré à votre porte — ${services.length} expérience${services.length > 1 ? 's' : ''} autour de ${property.name}`
            : 'Aucun service pour le moment'}
        </span>

        {services.length > 0 && (
          <span className="relative mt-3.5 flex flex-col gap-2.5 border-t border-amber-200/60 pt-3.5 dark:border-white/10">
            {/* Aperçus des couvertures — VRAIES PHOTOS (v4.23 « hub réel »,
                fallback gradient+emoji si l'offre n'a pas de photo) */}
            <span className="flex items-center gap-2">
              {previews.map((svc) => (
                <ServiceCover
                  key={svc.id}
                  emoji={svc.emoji}
                  categoryLabel={svc.categoryLabel}
                  imageUrl={svc.imageUrl}
                  alt={`Photo — ${svc.name}`}
                  className="h-14 w-14 rounded-xl shrink-0"
                  emojiClassName="text-2xl"
                />
              ))}
              {services.length > previews.length && (
                <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-slate-100 dark:bg-white/10">
                  <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    +{services.length - previews.length}
                  </span>
                </span>
              )}
            </span>
            <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-700 dark:text-amber-300">
              {orderableCount > 0 ? (
                <>
                  <span aria-hidden="true">⚡</span>
                  Paiement sécurisé · Créneau au choix · Suivi en direct
                </>
              ) : (
                <>
                  <span aria-hidden="true">✉️</span>
                  Votre hôte organise la réservation pour vous
                </>
              )}
            </span>
          </span>
        )}
      </button>
      )}

      {/* ── Overlay plein écran — expérience conciergerie complète ──
       * createPortal(document.body) : le portail rattache l'overlay
       * (panier flottant, checkout, bottom-sheet en fixed) au viewport,
       * indépendamment de l'arbre d'origine. */}
      {open &&
        createPortal(
          <div
            className="fixed inset-0 z-50 flex flex-col bg-background"
            role="dialog"
            aria-modal="true"
            aria-label="Services & Expériences"
          >
            {/* Header sticky : retour + titre serif */}
            <header className="shrink-0 border-b border-slate-200/70 dark:border-white/10 bg-background/85 backdrop-blur-xl">
              <div className="mx-auto max-w-lg px-4 h-14 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="h-9 w-9 -ml-1.5 rounded-full flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                  aria-label="Retour au hub"
                >
                  <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                </button>
                <h1 className="font-serif text-lg font-bold text-slate-900 dark:text-white truncate">
                  🛎️ Services &amp; Expériences
                </h1>
              </div>
            </header>

            {/* Contenu scrollable = l'expérience PWA complète */}
            <div className="flex-1 overflow-y-auto overscroll-contain">
              <div className="mx-auto max-w-lg px-4 py-5 pb-40">
                <TabServices
                  slug={slug}
                  services={services}
                  contact={contact}
                  propertyName={property.name}
                  booking={null}
                  bookingId={null}
                  online={typeof navigator === 'undefined' ? true : navigator.onLine}
                  embedded
                  onNavigate={() => setOpen(false)}
                />
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}

// =============================================================
// MODULES PREMIUM (parité PWA) — vidéo bienvenue, guide des
// appareils, kit de survie, late check-out (upselling), bouclier
// d'avis. Données Expérience Invité + concierge servies par
// /api/public/hub/[slug] (propriétés Property.appliances /
// premiumFeatures / survivalKitItems).
// =============================================================

/** 🎬 Vidéo de bienvenue — média local → lecteur intégré (<video>) ;
 * YouTube/Vimeo/Loom → bouton d'ouverture (la CSP bloque les iframes
 * externes, choix sécurité assumé — cf. isYouTubeUrl()). */
function WelcomeVideoCard({
  url,
  propertyName,
  open,
  onOpenChange,
}: {
  url: string;
  propertyName: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const local = isLocalMediaUrl(url);
  const yt = isYouTubeUrl(url);
  return (
    <>
      <ModuleCard
        emoji="🎬"
        tone="rose"
        eyebrow="Message de votre hôte"
        title="Vidéo de bienvenue"
        subtitle="Votre hôte vous explique tout en vidéo"
        imageUrl={HUB_VISUALS.welcome}
        onClick={local ? () => onOpenChange(true) : () => window.open(url, '_blank', 'noopener,noreferrer')}
      >
        <span className="flex flex-wrap gap-1.5">
          <PreviewChip>{local ? '▶ Lecture intégrée' : '▶ Ouvrir la vidéo'}</PreviewChip>
        </span>
      </ModuleCard>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900">
              🎬 Vidéo de bienvenue — {propertyName}
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              {local ? 'Lecture intégrée.' : 'La vidéo est hébergée en externe (YouTube, Vimeo, Loom) — elle s’ouvre dans un nouvel onglet.'}
            </DialogDescription>
          </DialogHeader>
          {local ? (
            <video
              controls
              autoPlay
              playsInline
              className="w-full rounded-xl border border-slate-200 bg-black"
              src={url}
            />
          ) : (
            <Button
              type="button"
              className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
              onClick={() => window.open(url, '_blank', 'noopener,noreferrer')}
            >
              <Play className="h-4 w-4" aria-hidden="true" /> Ouvrir la vidéo
            </Button>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

/** 🛠️ Guide des appareils — Property.appliances (rempli dans
 * /airbnb/concierge) : instructions + photo + vidéo par appareil.
 * Task 30 : tuile grille + dialog immersif (accordéons inchangés). */
function AppliancesCard({ appliances }: { appliances: GuestAppliance[] }) {
  const [open, setOpen] = useState(false);
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({});
  return (
    <>
      <ModuleCard
        emoji="🛠️"
        tone="violet"
        eyebrow="Équipements"
        title="Guide des appareils"
        subtitle={`${appliances.length} équipement${appliances.length > 1 ? 's' : ''} expliqué${appliances.length > 1 ? 's' : ''} par votre hôte`}
        imageUrl={HUB_VISUALS.appliances}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {appliances.slice(0, 3).map((app) => (
            <PreviewChip key={app.id}>
              <span aria-hidden="true">{app.emoji || '🛠️'}</span> {app.name}
            </PreviewChip>
          ))}
          {appliances.length > 3 && <PreviewChip>+{appliances.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🛠️"
        tone="violet"
        title="Guide des appareils"
        subtitle={`${appliances.length} équipement${appliances.length > 1 ? 's' : ''} expliqué${appliances.length > 1 ? 's' : ''} par votre hôte`}
      >
        <div className="space-y-2.5">
          {appliances.map((app) => {
            const isOpen = !!openIds[app.id];
            return (
              <div key={app.id} className="bg-slate-50 border border-slate-200 rounded-lg dark:bg-white/5 dark:border-white/10">
                <button
                  type="button"
                  className="w-full flex items-center gap-3 p-3 text-left"
                  onClick={() => setOpenIds((m) => ({ ...m, [app.id]: !m[app.id] }))}
                  aria-expanded={isOpen}
                >
                  <span className="text-2xl leading-none select-none" aria-hidden="true">{app.emoji || '🛠️'}</span>
                  <span className="flex-1 min-w-0 text-sm font-bold text-slate-900 dark:text-white">{app.name}</span>
                  <ChevronRight
                    className={cn('h-4 w-4 text-slate-400 transition-transform shrink-0', isOpen && 'rotate-90')}
                    aria-hidden="true"
                  />
                </button>
                {isOpen && (
                  <div className="px-3 pb-3">
                    <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-wrap dark:text-slate-300">
                      {app.instructions}
                    </p>
                    {app.imageUrl && (
                      <img
                        src={app.imageUrl}
                        alt={`Photo de ${app.name}`}
                        loading="lazy"
                        decoding="async"
                        className="mt-2 w-full rounded-xl object-cover aspect-[4/3] border border-slate-200 dark:border-white/10"
                      />
                    )}
                    {app.videoUrl && (
                      isLocalMediaUrl(app.videoUrl) ? (
                        <video
                          controls
                          playsInline
                          preload="metadata"
                          className="mt-2 w-full rounded-xl border border-slate-200 bg-black dark:border-white/10"
                          src={app.videoUrl}
                        />
                      ) : (
                        <a
                          href={app.videoUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                        >
                          <Play className="h-3.5 w-3.5" aria-hidden="true" /> Voir la vidéo {isYouTubeUrl(app.videoUrl) ? '(YouTube)' : ''}
                        </a>
                      )
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </TileDialog>
    </>
  );
}

/** 🧰 Kit de survie — Property.survivalKitItems (Expérience Invité) :
 * où sont rangés les objets utiles (trousse, parapluie, piles…).
 * Task 30 : tuile grille + dialog immersif (liste inchangée). */
function SurvivalKitCard({ items }: { items: GuestSurvivalItem[] }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="🧰"
        tone="orange"
        eyebrow="Rangement malin"
        title="Kit de survie"
        subtitle={`${items.length} objet${items.length > 1 ? 's' : ''} indispensable${items.length > 1 ? 's' : ''} et leur emplacement`}
        imageUrl={HUB_VISUALS.survival}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {items.slice(0, 3).map((item) => (
            <PreviewChip key={item.id}>{item.name}</PreviewChip>
          ))}
          {items.length > 3 && <PreviewChip>+{items.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🧰"
        tone="orange"
        title="Kit de survie"
        subtitle={`${items.length} objet${items.length > 1 ? 's' : ''} indispensable${items.length > 1 ? 's' : ''} et leur emplacement`}
      >
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
              <span className="text-xl leading-none select-none" aria-hidden="true">🧰</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900 dark:text-white">{item.name}</p>
                {item.location && (
                  <p className="text-xs text-slate-500 mt-0.5 dark:text-slate-400">📍 {item.location}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </TileDialog>
    </>
  );
}

/** ⏱️ Départ tardif (upselling) — demande POST /api/public/hub/[slug]/
 * late-checkout (le serveur vérifie que le service est activé).
 * Task 30 : tuile grille + dialog avec CTA (logique d'envoi inchangée). */
function LateCheckoutCard({
  slug,
  price,
  propertyName,
}: {
  slug: string;
  price?: number;
  propertyName: string;
}) {
  const [open, setOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const request = async () => {
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/late-checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      toast.success(data.message || 'Demande envoyée — votre hôte vous confirme rapidement.');
      setSent(true);
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Demande impossible. Réessayez dans un instant.');
    } finally {
      setSending(false);
    }
  };
  return (
    <>
      <ModuleCard
        emoji="⏱️"
        tone="amber"
        eyebrow="Extension de séjour"
        title="Départ tardif"
        subtitle={price != null ? `Restez jusqu’à 14 h — ${formatEur(price)}` : 'Restez jusqu’à 14 h'}
        imageUrl={HUB_VISUALS.lateCheckout}
        onClick={sent ? undefined : () => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {sent ? (
            <PreviewChip>✅ Demande envoyée</PreviewChip>
          ) : (
            <PreviewChip>🕑 Jusqu’à 14 h</PreviewChip>
          )}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="⏱️"
        tone="amber"
        title="Départ tardif"
        subtitle={
          price != null
            ? `Restez jusqu’à 14 h — ${formatEur(price)} (proposé par votre hôte)`
            : 'Restez jusqu’à 14 h — proposé par votre hôte'
        }
      >
        <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300">
          Envie de profiter encore un peu de {propertyName} ? Demandez un départ tardif :
          votre hôte vous confirme rapidement par notification.
        </p>
        {!sent && (
          <Button
            type="button"
            size="sm"
            className="mt-3 w-full h-10 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
            onClick={request}
            disabled={sending}
            aria-label={`Demander un départ tardif pour ${propertyName}`}
          >
            {sending ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Clock4 className="h-3.5 w-3.5" aria-hidden="true" />}
            {sending ? 'Envoi…' : 'Demander un départ tardif'}
          </Button>
        )}
        {sent && (
          <p className="mt-3 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
            ✅ Demande envoyée — votre hôte vous confirme.
          </p>
        )}
      </TileDialog>
    </>
  );
}

/** ⭐ Bouclier d'avis — l'invité ravi est dirigé vers l'avis public
 * (reviewUrl) ; l'invité déçu s'exprime EN PRIVÉ (POST …/private-feedback,
 * alerte immédiate hôte) — le mauvais avis n'atterrit jamais sur
 * Airbnb/Booking avant que l'hôte ait pu régler le souci. */
function ReviewShieldCard({
  slug,
  propertyName,
  reviewUrl,
  open,
  onOpenChange,
}: {
  slug: string;
  propertyName: string;
  reviewUrl?: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [guestName, setGuestName] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(false);

  const submit = async () => {
    if (rating < 1) {
      toast.error('Choisissez une note (1 à 5 étoiles).');
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/private-feedback`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rating,
          comment: comment.trim() || undefined,
          guestName: guestName.trim() || undefined,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || 'http');
      setDone(true);
    } catch (e) {
      const detail = e instanceof Error && !e.message.startsWith('http') ? e.message : null;
      toast.error(detail || 'Envoi impossible. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  const reset = () => {
    onOpenChange(false);
    setTimeout(() => {
      setDone(false);
      setRating(0);
      setComment('');
      setGuestName('');
    }, 300);
  };

  return (
    <>
      <ModuleCard
        emoji="⭐"
        tone="rose"
        eyebrow="Votre avis compte"
        title="Bouclier d’avis"
        subtitle="Dites-le d’abord à votre hôte, en privé"
        imageUrl={HUB_VISUALS.review}
        onClick={() => onOpenChange(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          <PreviewChip>🔒 100 % privé</PreviewChip>
          <PreviewChip>⭐ 1 à 5 étoiles</PreviewChip>
        </span>
      </ModuleCard>
      <Dialog open={open} onOpenChange={(v) => !sending && (v ? onOpenChange(true) : reset())}>
        <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl dark:border-white/10 dark:bg-slate-900 dark:text-slate-100">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 dark:text-white">
              ⭐ Votre avis — {propertyName}
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500 dark:text-slate-400">
              {done
                ? 'Merci ! Votre retour a été transmis.'
                : 'Un souci ? Votre message arrive directement et en privé à votre hôte, qui pourra le corriger.'}
            </DialogDescription>
          </DialogHeader>

          {done ? (
            <div className="space-y-3">
              <p className="text-sm font-semibold text-emerald-700 dark:text-emerald-300">
                {rating >= 4
                  ? 'Merci beaucoup ! 🎉'
                  : 'Merci, votre hôte est prévenu et va vous répondre. 💬'}
              </p>
              {rating >= 4 && reviewUrl && (
                <Button
                  type="button"
                  className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                  onClick={() => window.open(reviewUrl, '_blank', 'noopener,noreferrer')}
                >
                  <Star className="h-4 w-4" aria-hidden="true" /> Laisser un avis public
                </Button>
              )}
              <Button
                type="button"
                variant="outline"
                className="w-full h-10 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300 dark:hover:bg-white/10"
                onClick={reset}
              >
                Fermer
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex justify-center gap-1.5" role="radiogroup" aria-label="Note de 1 à 5 étoiles">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    role="radio"
                    aria-checked={rating === n}
                    aria-label={`${n} étoile${n > 1 ? 's' : ''}`}
                    onMouseEnter={() => setHover(n)}
                    onMouseLeave={() => setHover(0)}
                    onClick={() => setRating(n)}
                    className="p-1 rounded-lg transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
                  >
                    <Star
                      className={cn(
                        'h-8 w-8 transition-colors',
                        (hover || rating) >= n
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 dark:text-slate-600',
                      )}
                      aria-hidden="true"
                    />
                  </button>
                ))}
              </div>
              <Textarea
                placeholder="Votre message (optionnel) — ce qui vous a plu ou déplu"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                maxLength={2000}
                rows={3}
                className="resize-none text-sm"
              />
              <Input
                placeholder="Votre prénom (optionnel)"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                maxLength={80}
                className="h-10 text-sm"
              />
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="h-10 flex-1 border-slate-300 text-slate-600 dark:border-white/20 dark:text-slate-300 dark:hover:bg-white/10"
                  onClick={reset}
                  disabled={sending}
                >
                  Annuler
                </Button>
                <Button
                  type="button"
                  className="h-10 flex-1 bg-slate-900 hover:bg-slate-800 text-white font-semibold dark:bg-white dark:text-slate-900 dark:hover:bg-slate-200"
                  onClick={submit}
                  disabled={sending || rating < 1}
                >
                  {sending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <ShieldCheck className="h-4 w-4" aria-hidden="true" />}
                  Envoyer
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// =============================================================
// MODULES INVITÉS (parité PWA) — coffre-fort, guide visuel,
// quartier, SOS. Bug dashboard→hub : les données remplies dans
// /airbnb/concierge et l'Expérience Invité apparaissent désormais
// dans le hub QR, avec le même design premium glass.
// =============================================================

/** 🔑 Accès & Codes — coffre-fort numérique (bâtiment, boîte aux
 * lettres, parking, alarme, coffre). Valeur masquée par défaut,
 * révélation au clic + copie avec toast (même copy() que le Wi-Fi). */
function AccessCodesCard({
  codes,
  copy,
}: {
  codes: GuestAccessCodes;
  copy: (text: string, label: string) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [revealed, setRevealed] = useState<Record<string, boolean>>({});
  const rows = accessCodeRows(codes);

  return (
    <>
      <ModuleCard
        emoji="🔑"
        tone="emerald"
        eyebrow="Trousseau numérique"
        title="Accès & Codes"
        subtitle="Portes, coffre-fort, parking… vos codes en un clin d’œil"
        imageUrl={HUB_VISUALS.access}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {rows.slice(0, 3).map((row) => (
            <PreviewChip key={row.label}>
              <span aria-hidden="true">{row.emoji}</span> {row.label}
            </PreviewChip>
          ))}
          {rows.length > 3 && <PreviewChip>+{rows.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🔑"
        tone="emerald"
        title="Accès & Codes"
        subtitle="Bâtiment, coffre-fort, parking… votre trousseau numérique"
      >
        <div className="space-y-2.5">
          {rows.map((row) => {
            const shown = !!revealed[row.label];
            return (
              <div key={row.label} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <span className="text-xl leading-none select-none" aria-hidden="true">{row.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">{row.label}</p>
                    <p className={cn(
                      'font-mono text-sm font-bold mt-0.5 truncate',
                      shown ? 'text-slate-900 dark:text-white' : 'text-slate-400 dark:text-slate-500',
                    )}>
                      {shown ? row.value : '••••••'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 px-2.5"
                      onClick={() => setRevealed((m) => ({ ...m, [row.label]: !m[row.label] }))}
                      aria-label={shown ? `Masquer ${row.label}` : `Révéler ${row.label}`}
                    >
                      <span aria-hidden="true">{shown ? '🙈' : '👁️'}</span>
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-8 px-2.5"
                      onClick={() => copy(row.value, row.label)}
                      aria-label={`Copier ${row.label}`}
                    >
                      <Copy className="h-3.5 w-3.5" aria-hidden="true" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
          {codes.note && (
            <p className="text-xs text-slate-500 leading-relaxed px-1 dark:text-slate-400">📝 {codes.note}</p>
          )}
          <p className="text-[11px] text-slate-400 text-center">
            Codes confidentiels — ne les partagez qu’avec vos compagnons de voyage.
          </p>
        </div>
      </TileDialog>
    </>
  );
}

/** 🗺️ Arrivée pas à pas — guide visuel (façade, digicode, porte…)
 * rempli dans l'Expérience Invité → Property.visualGuide.
 * Task 30 : tuile grille + dialog immersif (étapes inchangées). */
function VisualGuideCard({ steps }: { steps: GuestVisualStep[] }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="🗺️"
        tone="emerald"
        eyebrow="Arrivée"
        title="Arrivée pas à pas"
        subtitle={`${steps.length} étape${steps.length > 1 ? 's' : ''} illustrée${steps.length > 1 ? 's' : ''} jusqu’à votre logement`}
        imageUrl={HUB_ARRIVAL_PHOTOS.facade}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {steps.slice(0, 2).map((step) => (
            <PreviewChip key={step.id}>{step.title}</PreviewChip>
          ))}
          {steps.length > 2 && <PreviewChip>+{steps.length - 2}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🗺️"
        tone="emerald"
        title="Arrivée pas à pas"
        subtitle={`${steps.length} étape${steps.length > 1 ? 's' : ''} illustrée${steps.length > 1 ? 's' : ''} jusqu’à votre logement`}
      >
        <div className="space-y-3">
          {steps.map((step, i) => (
            <div key={step.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
              <p className="text-sm font-bold text-slate-900 dark:text-white">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-slate-900 text-white text-[10px] font-bold mr-1.5 align-middle dark:bg-white dark:text-slate-900">
                  {i + 1}
                </span>
                {step.title}
              </p>
              {step.description && (
                <p className="text-xs text-slate-600 mt-1 leading-relaxed dark:text-slate-300">{step.description}</p>
              )}
              {step.imageUrl && (
                <img
                  src={step.imageUrl}
                  alt={step.title}
                  loading="lazy"
                  className="mt-2 w-full rounded-xl object-cover aspect-[4/3] border border-slate-200 dark:border-white/10"
                />
              )}
            </div>
          ))}
        </div>
      </TileDialog>
    </>
  );
}

/** 📍 Quartier & bonnes adresses — carte secrète de l’hôte
 * (Property.localSpots) avec lien « Y aller » natif (Apple/Google Maps).
 * Task 30 : tuile grille + dialog immersif (adresses inchangées). */
function LocalSpotsCard({ spots }: { spots: GuestSpot[] }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <ModuleCard
        emoji="📍"
        tone="teal"
        eyebrow="Carte secrète"
        title="Bonnes adresses"
        subtitle={`${spots.length} adresse${spots.length > 1 ? 's' : ''} secrète${spots.length > 1 ? 's' : ''} de votre hôte`}
        imageUrl={HUB_VISUALS.spots}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {spots.slice(0, 3).map((spot) => (
            <PreviewChip key={spot.id}>
              <span aria-hidden="true">{spotCategoryMeta(spot.category).emoji}</span> {spot.name}
            </PreviewChip>
          ))}
          {spots.length > 3 && <PreviewChip>+{spots.length - 3}</PreviewChip>}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="📍"
        tone="teal"
        title="Quartier & bonnes adresses"
        subtitle={`${spots.length} adresse${spots.length > 1 ? 's' : ''} secrète${spots.length > 1 ? 's' : ''} de votre hôte`}
      >
        <div className="space-y-2.5">
          {spots.map((spot) => {
            const meta = spotCategoryMeta(spot.category);
            return (
              <div key={spot.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                <div className="flex items-start gap-3">
                  <span className="text-2xl leading-none select-none" aria-hidden="true">{meta.emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <p className="text-sm font-bold text-slate-900 dark:text-white">{spot.name}</p>
                      <Badge className="bg-amber-50 border-amber-200 text-amber-700 font-semibold hover:bg-amber-50 shrink-0 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300 dark:hover:bg-amber-500/10">
                        {meta.label}
                      </Badge>
                    </div>
                    {spot.address && <p className="text-[11px] text-slate-400 mt-0.5">{spot.address}</p>}
                    {spot.hostNote && (
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed dark:text-slate-300">💬 {spot.hostNote}</p>
                    )}
                    <a
                      href={geoDirectionsUrl(spot.lat, spot.lng)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 mt-2 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300 dark:hover:text-emerald-200"
                    >
                      <span aria-hidden="true">🧭</span> Y aller
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </TileDialog>
    </>
  );
}

/** 🆘 SOS & Urgences — TOUJOURS visible : numéros nationaux (112/15/18),
 * police (custom ou 17), urgence logement (emergencyInfo.hostPhone),
 * hôpital/pharmacie de garde (Property.emergencyInfo) et pannes courantes. */
function SosCard({ emergency }: { emergency: GuestEmergencyInfo | null }) {
  const [open, setOpen] = useState(false);
  const telHref = (n: string) => `tel:${n.replace(/[^+\d]/g, '')}`;
  const numbers = [
    { label: 'Urgences (UE)', number: '112', tone: 'red' as const },
    { label: 'SAMU', number: '15', tone: 'red' as const },
    { label: 'Pompiers', number: '18', tone: 'red' as const },
    { label: 'Police', number: emergency?.police ?? '17', tone: 'red' as const },
    ...(emergency?.hostPhone
      ? [{ label: 'Urgence logement', number: emergency.hostPhone, tone: 'emerald' as const }]
      : []),
  ];
  return (
    <>
      <ModuleCard
        emoji="🆘"
        tone="red"
        eyebrow="Urgences 24/7"
        title="SOS & Urgences"
        subtitle="Numéros, hôpital, pharmacie de garde"
        imageUrl={HUB_VISUALS.sos}
        onClick={() => setOpen(true)}
      >
        <span className="flex flex-wrap gap-1.5">
          {numbers.slice(0, 4).map((n) => (
            <PreviewChip key={n.label}>☎️ {n.number}</PreviewChip>
          ))}
        </span>
      </ModuleCard>
      <TileDialog
        open={open}
        onOpenChange={setOpen}
        emoji="🆘"
        tone="red"
        title="SOS & Urgences"
        subtitle="Numéros d’urgence, hôpital, pharmacie de garde"
      >
        <div className="space-y-2.5">
          <div className="grid grid-cols-2 gap-2">
            {numbers.map((n) => (
              <a
                key={n.label}
                href={telHref(n.number)}
                className={cn(
                  'rounded-lg border p-3 flex items-center gap-2.5 transition-transform active:scale-[0.98]',
                  n.tone === 'emerald'
                    ? 'bg-emerald-50 border-emerald-200 dark:bg-emerald-500/10 dark:border-emerald-500/30'
                    : 'bg-red-50 border-red-200 dark:bg-red-500/10 dark:border-red-500/30',
                )}
              >
                <Phone
                  className={cn(
                    'h-4 w-4 shrink-0',
                    n.tone === 'emerald' ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400',
                  )}
                  aria-hidden="true"
                />
                <span className="min-w-0">
                  <span className={cn(
                    'block text-[11px] font-semibold uppercase tracking-wide',
                    n.tone === 'emerald' ? 'text-emerald-500' : 'text-red-400',
                  )}>
                    {n.label}
                  </span>
                  <span className={cn(
                    'block text-sm font-bold truncate',
                    n.tone === 'emerald' ? 'text-emerald-700 dark:text-emerald-300' : 'text-red-700 dark:text-red-300',
                  )}>
                    {n.number}
                  </span>
                </span>
              </a>
            ))}
          </div>

          {(emergency?.hospital || emergency?.pharmacy) && (
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-3 dark:bg-white/5 dark:border-white/10">
              {emergency?.hospital && (
                <div className="flex items-start gap-2.5">
                  <span className="text-xl leading-none select-none" aria-hidden="true">🏥</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Hôpital le plus proche</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{emergency.hospital}</p>
                    {emergency.hospitalLat != null && emergency.hospitalLng != null && (
                      <a
                        href={geoDirectionsUrl(emergency.hospitalLat, emergency.hospitalLng)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 mt-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                      >
                        <span aria-hidden="true">🧭</span> Y aller
                      </a>
                    )}
                  </div>
                </div>
              )}
              {emergency?.pharmacy && (
                <div className="flex items-start gap-2.5">
                  <span className="text-xl leading-none select-none" aria-hidden="true">💊</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Pharmacie de garde</p>
                    <p className="text-sm font-bold text-slate-900 dark:text-white">{emergency.pharmacy}</p>
                    {emergency.pharmacyPhone && (
                      <a
                        href={telHref(emergency.pharmacyPhone)}
                        className="inline-flex items-center gap-1 mt-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 dark:text-emerald-300"
                      >
                        <Phone className="h-3 w-3" aria-hidden="true" /> {emergency.pharmacyPhone}
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {(emergency?.commonIssues.length ?? 0) > 0 && (
            <div className="space-y-2">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">Pannes courantes</p>
              {emergency!.commonIssues.map((issue) => (
                <details key={issue.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3 dark:bg-white/5 dark:border-white/10">
                  <summary className="text-sm font-bold text-slate-900 cursor-pointer dark:text-white">
                    <span className="mr-1.5" aria-hidden="true">🔧</span>{issue.title}
                  </summary>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed whitespace-pre-line dark:text-slate-300">
                    {issue.instructions}
                  </p>
                </details>
              ))}
            </div>
          )}
        </div>
      </TileDialog>
    </>
  );
}

// =============================================================
// MODE HÔTE — grille de gestion rapide (après PIN)
// =============================================================
function HostView({
  payload,
  hostData,
  slug,
  pin,
  onBack,
  onHostRefresh,
  onPinChanged,
}: {
  payload: HubPayload;
  hostData: HostData | null;
  slug: string;
  pin: string;
  onBack: () => void;
  onHostRefresh: (d: HostData) => void;
  onPinChanged: (pin: string) => void;
}) {
  const [wifiEditOpen, setWifiEditOpen] = useState(false);
  const [complaintsOpen, setComplaintsOpen] = useState(false);
  const [providersOpen, setProvidersOpen] = useState(false);
  const [guidebookOpen, setGuidebookOpen] = useState(false);
  const [upsellingOpen, setUpsellingOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const unread = hostData?.unreadMessages.length ?? 0;
  const written = hostData?.openComplaints ?? 0;
  const totalAlerts = unread + written;

  // ── Commandes ServiceOrder (badge Upselling + dialog) ──
  // Fetch au montage et à chaque refreshOrders() (après PATCH ou
  // réouverture du dialog) — le badge compte les PENDING.
  const [orders, setOrders] = useState<HostOrder[] | null>(null);
  const [ordersTick, setOrdersTick] = useState(0);
  const refreshOrders = useCallback(() => setOrdersTick((t) => t + 1), []);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      try {
        const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ pin }),
        });
        if (!res.ok || cancelled) return;
        const json = (await res.json()) as { orders: HostOrder[] };
        if (!cancelled) setOrders(json.orders);
      } catch {
        // Silencieux : le badge reste absent, une nouvelle tentative
        // est déclenchée à la réouverture du dialog.
      }
    }
    run();
    return () => {
      cancelled = true;
    };
  }, [slug, pin, ordersTick]);

  const pendingOrders = orders?.filter((o) => o.status === 'PENDING').length ?? 0;
  const [patching, setPatching] = useState<string | null>(null);

  /** Rafraîchit les données hôte (après édition guidebook / résolution). */
  const refreshHost = useCallback(async () => {
    try {
      const hostRes = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/host`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      });
      if (hostRes.ok) onHostRefresh((await hostRes.json()) as HostData);
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    }
  }, [slug, pin, onHostRefresh]);

  /** Marque une réclamation écrite résolue (garde PIN) puis rafraîchit. */
  const resolveComplaint = async (id: string) => {
    setResolvingId(id);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/complaint`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, id, status: 'RESOLVED' }),
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        toast.error(j.error || 'Impossible de marquer comme résolue.');
        return;
      }
      toast.success('Réclamation marquée résolue ✓');
      await refreshHost();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  };

  /** Confirme ou annule une commande PENDING (PATCH /orders, garde PIN). */
  const patchOrder = async (orderId: string, action: 'CONFIRM' | 'CANCEL') => {
    setPatching(orderId);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/orders`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, orderId, action }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Action impossible.');
        return;
      }
      toast.success(action === 'CONFIRM' ? 'Commande confirmée ✓' : 'Commande annulée.');
      refreshOrders();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setPatching(null);
    }
  };

  return (
    <div className="flex-1 w-full max-w-lg mx-auto px-4 py-8 flex flex-col">
      {/* Fond premium animé (fixed, -z-10) */}
      <AnimatedMeshGradient />

      {/* En-tête — fade-in + slide-down */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, ease: EASE_EXPO }}
        className="flex items-center gap-3 mb-2"
      >
        <button
          type="button"
          onClick={onBack}
          aria-label="Retour à l'accueil"
          className="h-11 w-11 shrink-0 inline-flex items-center justify-center rounded-xl glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] text-slate-600 hover:text-slate-900 transition-colors dark:text-slate-300 dark:hover:text-white"
        >
          <ChevronLeft className="h-5 w-5" aria-hidden="true" />
        </button>
        <div className="min-w-0">
          <h1 className="display-title font-serif! text-lg font-bold text-slate-900 leading-tight dark:text-white">🔐 Espace Hôte</h1>
          <p className="text-xs text-slate-500 truncate dark:text-slate-400">{payload.property.name}</p>
        </div>
        <Badge className="ml-auto bg-emerald-50 border-emerald-200 text-emerald-700 font-semibold hover:bg-emerald-50 shrink-0 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300 dark:hover:bg-emerald-500/10">
          ✓ Déverrouillé
        </Badge>
      </motion.div>
      <p className="text-sm text-slate-600 mb-5 dark:text-slate-400">Gestion rapide du logement</p>

      {!hostData ? (
        <div className="space-y-3" aria-busy="true">
          <Skeleton className="h-20 rounded-xl" />
          <Skeleton className="h-20 rounded-xl" />
          <Skeleton className="h-20 rounded-xl" />
        </div>
      ) : (
        <div className="grid gap-3">
          {/* 📶 Modifier le Wi-Fi */}
          <Reveal delay={0.05} y={20}>
            <HostActionCard
              emoji="📶"
              title="Modifier le Wi-Fi"
              subtitle={
                hostData.wifi?.networkName ? `Réseau : ${hostData.wifi.networkName}` : 'Aucun réseau configuré'
              }
              onClick={() => setWifiEditOpen(true)}
            />
          </Reveal>
          {/* 📖 Guidebook — édition (AUD-FULL ⑥) */}
          <Reveal delay={0.1} y={20}>
            <HostActionCard
              emoji="📖"
              title="Guidebook"
              subtitle={
                hostData.guidebook.sections.length > 0
                  ? `${hostData.guidebook.sections.length} section(s) — éditer le guide de bienvenue`
                  : 'Aucune section — écrire le guide de bienvenue'
              }
              onClick={() => setGuidebookOpen(true)}
            />
          </Reveal>
          {/* 🚨 Réclamations en attente (vocales + écrites) */}
          <Reveal delay={0.15} y={20}>
            <HostActionCard
              emoji="🚨"
              title="Réclamations en attente"
              subtitle={
                totalAlerts > 0
                  ? `${written} écrite(s) · ${unread} vocale(s)${
                      hostData.pendingRequests > 0 ? ` · ${hostData.pendingRequests} demande(s) de service` : ''
                    }`
                  : 'Aucune réclamation en attente ✓'
              }
              badge={totalAlerts > 0 ? String(totalAlerts) : undefined}
              onClick={() => setComplaintsOpen(true)}
            />
          </Reveal>
          {/* 💰 Upselling — commandes invitées (ServiceOrder) */}
          <Reveal delay={0.2} y={20}>
            <HostActionCard
              emoji="💰"
              title="Upselling — Commandes"
              subtitle={
                pendingOrders > 0
                  ? `${pendingOrders} commande(s) à confirmer`
                  : orders && orders.length > 0
                    ? `${orders.length} commande(s) — rien à confirmer ✓`
                    : 'Aucune commande pour le moment'
              }
              badge={pendingOrders > 0 ? String(pendingOrders) : undefined}
              onClick={() => {
                setUpsellingOpen(true);
                refreshOrders();
              }}
            />
          </Reveal>
          {/* 🧹 Gérer les prestataires */}
          <Reveal delay={0.25} y={20}>
            <HostActionCard
              emoji="🧹"
              title="Gérer les prestataires"
              subtitle={`${hostData.providers.length} intervenant(s) autour du bien`}
              onClick={() => setProvidersOpen(true)}
            />
          </Reveal>
          {/* ⚙️ Paramètres — changement de PIN */}
          <Reveal delay={0.3} y={20}>
            <HostActionCard
              emoji="⚙️"
              title="Paramètres"
              subtitle="Gérer le code PIN d'accès au mode hôte"
              onClick={() => setSettingsOpen(true)}
            />
          </Reveal>
        </div>
      )}

      <footer className="mt-auto pt-10 pb-6 text-center">
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Propulsé par 🗝️ <span className="font-semibold text-slate-600 dark:text-slate-300">Conciergerie Hub</span>
        </p>
      </footer>

      {/* ----- Dialog : Modifier le Wi-Fi ----- */}
      {hostData && wifiEditOpen && (
        <WifiEditDialog
          onClose={() => setWifiEditOpen(false)}
          slug={slug}
          pin={pin}
          wifi={hostData.wifi}
          onSaved={(w) => onHostRefresh({ ...hostData, wifi: w })}
        />
      )}

      {/* ----- Dialog : Édition du Guidebook ----- */}
      {hostData && guidebookOpen && (
        <GuidebookEditDialog
          onClose={() => setGuidebookOpen(false)}
          slug={slug}
          pin={pin}
          guidebook={hostData.guidebook}
          onSaved={refreshHost}
        />
      )}

      {/* ----- Dialog : Upselling (commandes invitées) ----- */}
      {upsellingOpen && (
        <UpsellingDialog
          onClose={() => setUpsellingOpen(false)}
          orders={orders}
          patchingId={patching}
          onPatch={patchOrder}
        />
      )}

      {/* ----- Dialog : Paramètres (changement de PIN) ----- */}
      {settingsOpen && (
        <SettingsPinDialog
          onClose={() => setSettingsOpen(false)}
          slug={slug}
          pin={pin}
          onPinChanged={onPinChanged}
        />
      )}

      {/* ----- Dialog : Réclamations ----- */}
      <Dialog open={complaintsOpen} onOpenChange={setComplaintsOpen}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
              <TriangleAlert className="h-4 w-4 text-amber-500" aria-hidden="true" /> Réclamations en attente
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Réclamations écrites (formulaire Hub) et messages vocaux de vos voyageurs.
            </DialogDescription>
          </DialogHeader>

          {/* ── Section : réclamations écrites ── */}
          <div>
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
              📝 Écrites ({hostData?.complaints.length ?? 0})
            </p>
            {!hostData || hostData.complaints.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">Aucune réclamation écrite en attente ✓</p>
            ) : (
              <div className="space-y-2.5">
                {hostData.complaints.map((c) => (
                  <div key={c.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <Badge className="bg-white border-slate-200 text-slate-700 font-semibold hover:bg-white shrink-0">
                          {c.categoryLabel}
                        </Badge>
                        {c.isUrgent && (
                          <Badge className="bg-red-50 border-red-200 text-red-700 font-bold hover:bg-red-50 shrink-0">
                            ⚠️ Urgent
                          </Badge>
                        )}
                      </div>
                      <span className="text-[11px] text-slate-400 shrink-0">
                        {new Date(c.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <p className="mt-2 text-sm text-slate-700 leading-relaxed">{c.description}</p>
                    {c.guestName && (
                      <p className="mt-1 text-[11px] text-slate-400">De : {c.guestName}</p>
                    )}
                    {c.photos.length > 0 && (
                      <div className="mt-2 flex gap-2">
                        {c.photos.map((p, i) => (
                           
                          <img
                            key={i}
                            src={p}
                            alt={`Photo ${i + 1} de la réclamation`}
                            className="h-16 w-16 rounded-lg border border-slate-200 object-cover"
                            loading="lazy"
                            decoding="async"
                          />
                        ))}
                      </div>
                    )}
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={resolvingId === c.id}
                      className="mt-2.5 h-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50 font-semibold"
                      onClick={() => resolveComplaint(c.id)}
                    >
                      {resolvingId === c.id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                      ) : (
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                      Marquer résolue
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── Section : messages vocaux ── */}
          <div className="pt-2 border-t border-slate-100">
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2 mt-2">
              🎙️ Vocales ({hostData?.unreadMessages.length ?? 0})
            </p>
            {!hostData || hostData.unreadMessages.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">Aucun message vocal en attente ✓</p>
            ) : (
              <div className="space-y-2.5">
                {hostData.unreadMessages.map((m) => (
                  <div key={m.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-bold text-slate-900">{m.senderName}</p>
                      <span className="text-[11px] text-slate-400 shrink-0">
                        {new Date(m.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center gap-2">
                      {m.audioUrl && !m.audioUrl.startsWith('/demo/') ? (
                        <audio
                          controls
                          preload="none"
                          src={voiceAudioSrc(m.audioUrl)}
                          className="h-9 w-full max-w-[260px]"
                          aria-label={`Message de ${m.senderName}`}
                        />
                      ) : (
                        <span className="text-xs text-slate-400">
                          🎙️ Message vocal de {m.durationSec} s (audio indisponible en démo)
                        </span>
                      )}
                    </div>
                    {/* RÉPONSE VOCALE — le propriétaire répond d'un simple
                        tap (pré-écoute avant envoi) ; l'invité la retrouvera
                        dans « Contacter l'hôte » et le guidebook. */}
                    <div className="mt-2">
                      <VoiceReplyButton voiceMessageId={m.id} compact slug={slug} pin={pin} onSent={() => void refreshHost()} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* ----- Dialog : Prestataires ----- */}
      <Dialog open={providersOpen} onOpenChange={setProvidersOpen}>
        <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Wrench className="h-4 w-4 text-slate-500" aria-hidden="true" /> Prestataires autour du bien
            </DialogTitle>
            <DialogDescription className="text-xs text-slate-500">
              Dans leur rayon d&apos;intervention. Gestion complète depuis le dashboard hôte.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {(['OWNER_SERVICE', 'GUEST_EXPERIENCE'] as const).map((aud) => {
              const list = hostData?.providers.filter((p) => p.audience === aud) ?? [];
              return (
                <div key={aud}>
                  <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
                    {aud === 'OWNER_SERVICE' ? '🔧 Services Propriétaire' : '🥂 Expériences Invité'} ({list.length})
                  </p>
                  {list.length === 0 ? (
                    <p className="text-xs text-slate-400">Aucun prestataire dans le rayon.</p>
                  ) : (
                    <div className="space-y-2">
                      {list.map((p) => (
                        <div
                          key={p.id}
                          className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-lg p-2.5"
                        >
                          <span className="text-xl select-none" aria-hidden="true">
                            {p.emoji}
                          </span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-slate-900 truncate">{p.name}</p>
                            <p className="text-[11px] text-slate-500">
                              {p.categoryLabel} · {formatDistance(p.distanceKm)}
                            </p>
                          </div>
                          <span className="text-[11px] font-semibold text-slate-600 shrink-0">{p.priceLabel}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Carte d'action hôte — glassmorphism premium (phase 2). */
function HostActionCard({
  emoji,
  title,
  subtitle,
  badge,
  onClick,
}: {
  emoji: string;
  title: string;
  subtitle: string;
  badge?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="relative w-full text-left glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] rounded-2xl p-4 transition-all duration-500 hover:-translate-y-0.5 active:scale-[0.99] cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500"
    >
      {badge && (
        <span className="absolute top-3 right-3 inline-flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-red-500 text-white text-[11px] font-bold shadow-lg shadow-red-500/30">
          {badge}
        </span>
      )}
      <div className="flex items-center gap-3.5">
        <EmojiIcon emoji={emoji} size="lg" variant="default" />
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">{title}</h3>
          <p className="text-xs text-slate-500 mt-0.5 leading-relaxed dark:text-slate-400">{subtitle}</p>
        </div>
        <PencilLine className="h-4 w-4 text-slate-400 shrink-0 dark:text-slate-500" aria-hidden="true" />
      </div>
    </button>
  );
}

/** Dialog : modification des identifiants Wi-Fi (PUT update + PIN).
 * Monté uniquement quand ouvert → l'état initial repart du contenu courant. */
function WifiEditDialog({
  onClose,
  slug,
  pin,
  wifi,
  onSaved,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  wifi: HostData['wifi'];
  onSaved: (w: HostData['wifi']) => void;
}) {
  const [ssid, setSsid] = useState(wifi?.networkName ?? '');
  const [password, setPassword] = useState(wifi?.password ?? '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!wifi || !ssid.trim() || !password.trim()) {
      toast.error('Renseignez le nom du réseau et le mot de passe.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pin,
          updates: [
            {
              qrCodeId: wifi.qrCodeId,
              content: {
                network_name: ssid.trim(),
                password: password.trim(),
                security_type: wifi.securityType || 'WPA2',
              },
            },
          ],
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || 'Échec de la mise à jour.');
        setSaving(false);
        return;
      }
      onSaved({ ...wifi, networkName: ssid.trim(), password: password.trim() });
      toast.success('Wi-Fi mis à jour ✅', {
        description: 'Vos voyageurs voient le nouveau réseau immédiatement.',
      });
      setSaving(false);
      onClose();
    } catch {
      toast.error('Erreur réseau.');
      setSaving(false);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) onClose();
      }}
    >
      <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">📶 Modifier le Wi-Fi</DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Les nouveaux identifiants sont visibles immédiatement par vos voyageurs.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="wifi-ssid">Nom du réseau (SSID)</Label>
            <Input
              id="wifi-ssid"
              value={ssid}
              onChange={(e) => setSsid(e.target.value)}
              placeholder="MonLogement_5G"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wifi-pwd">Mot de passe</Label>
            <Input
              id="wifi-pwd"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>
          <Button
            type="button"
            disabled={saving}
            onClick={save}
            className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Check className="h-4 w-4" aria-hidden="true" />}
            {saving ? 'Enregistrement…' : 'Enregistrer'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : édition du Guidebook (QrCode 'home_manual').
// Même schéma de contenu que l'affichage invité /view :
// { title, body } avec sections séparées par un double saut de ligne.
// Monté uniquement quand ouvert → l'état initial repart du contenu courant.
// =============================================================
function GuidebookEditDialog({
  onClose,
  slug,
  pin,
  guidebook,
  onSaved,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  guidebook: HostGuidebook;
  onSaved: () => void;
}) {
  const [title, setTitle] = useState(guidebook.title);
  const [sections, setSections] = useState<string[]>(
    guidebook.sections.length > 0 ? guidebook.sections : [''],
  );
  const [saving, setSaving] = useState(false);

  const updateSection = (i: number, value: string) =>
    setSections((prev) => prev.map((s, idx) => (idx === i ? value : s)));
  const addSection = () => setSections((prev) => [...prev, '']);
  const removeSection = (i: number) =>
    setSections((prev) => prev.filter((_, idx) => idx !== i));

  const save = async () => {
    if (!guidebook.qrCodeId) {
      toast.error('Aucun Guidebook actif pour ce bien. Créez-le depuis le dashboard hôte.');
      return;
    }
    const cleanSections = sections.map((s) => s.trim()).filter((s) => s.length > 0);
    if (!title.trim() || cleanSections.length === 0) {
      toast.error('Renseignez un titre et au moins une section.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pin,
          updates: [
            {
              qrCodeId: guidebook.qrCodeId,
              // Même schéma que /view : le body est découpé en sections
              // par double saut de ligne côté affichage invité.
              content: { title: title.trim(), body: cleanSections.join('\n\n') },
            },
          ],
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || 'Échec de la mise à jour.');
        setSaving(false);
        return;
      }
      toast.success('Guidebook mis à jour ✅', {
        description: 'Vos voyageurs voient le nouveau guide immédiatement.',
      });
      setSaving(false);
      onSaved();
      onClose();
    } catch {
      toast.error('Erreur réseau.');
      setSaving(false);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) onClose();
      }}
    >
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-emerald-600" aria-hidden="true" /> Éditer le Guidebook
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Le guide de bienvenue consulté par vos invités depuis le Hub.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="guidebook-title">Titre du guide</Label>
            <Input
              id="guidebook-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Guide de bienvenue"
              maxLength={120}
            />
          </div>

          <div className="space-y-2">
            <Label>Sections ({sections.length})</Label>
            {sections.map((section, i) => (
              <div key={i} className="relative">
                <Textarea
                  value={section}
                  onChange={(e) => updateSection(i, e.target.value)}
                  placeholder={`Section ${i + 1} — ex : 🔑 Accès, code de la boîte à clés…`}
                  className="min-h-[72px] pr-10 text-sm"
                  maxLength={2000}
                  aria-label={`Section ${i + 1} du guide`}
                />
                <button
                  type="button"
                  onClick={() => removeSection(i)}
                  aria-label={`Supprimer la section ${i + 1}`}
                  disabled={saving}
                  className="absolute top-2 right-2 h-7 w-7 inline-flex items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 hover:text-red-600 hover:border-red-200 transition-colors"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                </button>
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={saving || sections.length >= 12}
              onClick={addSection}
              className="w-full h-9 border-dashed border-slate-300 text-slate-600"
            >
              <Plus className="h-3.5 w-3.5" aria-hidden="true" /> Ajouter une section
            </Button>
          </div>

          <Button
            type="button"
            disabled={saving}
            onClick={save}
            className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
            ) : (
              <Check className="h-4 w-4" aria-hidden="true" />
            )}
            {saving ? 'Enregistrement…' : 'Enregistrer le guide'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : Upselling — commandes ServiceOrder des invités.
// Liste + boutons Confirmer/Annuler sur les PENDING (le serveur
// revalide chaque transition). État vide honnête si aucune commande.
// =============================================================
function UpsellingDialog({
  onClose,
  orders,
  patchingId,
  onPatch,
}: {
  onClose: () => void;
  orders: HostOrder[] | null;
  patchingId: string | null;
  onPatch: (orderId: string, action: 'CONFIRM' | 'CANCEL') => void;
}) {
  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v) onClose();
      }}
    >
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Package className="h-4 w-4 text-emerald-600" aria-hidden="true" /> Commandes des invités
          </DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Prestations commandées via l&apos;app invitée. Confirmez ou annulez les demandes en attente.
          </DialogDescription>
        </DialogHeader>

        {!orders ? (
          <div className="space-y-2.5 py-2" aria-busy="true">
            <Skeleton className="h-20 rounded-lg" />
            <Skeleton className="h-20 rounded-lg" />
          </div>
        ) : orders.length === 0 ? (
          <div className="py-8 text-center">
            <span className="text-3xl" aria-hidden="true">
              🧾
            </span>
            <p className="mt-2 text-sm font-semibold text-slate-700">Aucune commande pour l&apos;instant</p>
            <p className="mt-1 text-xs text-slate-400">
              Les commandes passées par vos invités depuis l&apos;app apparaîtront ici.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {orders.map((o) => (
              <div key={o.id} className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <Badge
                    className={cn(
                      'text-white border-transparent font-semibold shrink-0',
                      o.statusBadge,
                    )}
                  >
                    {o.statusEmoji} {o.statusLabel}
                  </Badge>
                  <span className="text-[11px] text-slate-400 shrink-0">
                    {new Date(o.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
                <p className="mt-2 text-sm font-bold text-slate-900 leading-snug">{o.itemsSummary}</p>
                <p className="mt-0.5 text-[11px] text-slate-500">
                  {o.providerEmoji} {o.providerName} · Invité : {o.guestName}
                </p>
                <div className="mt-2 flex items-center justify-between gap-2 flex-wrap">
                  <span className="text-sm font-bold text-slate-900">{o.totalEur}</span>
                  {o.status === 'PENDING' && (
                    <div className="flex items-center gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={patchingId === o.id}
                        className="h-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50 font-semibold"
                        onClick={() => onPatch(o.id, 'CONFIRM')}
                      >
                        {patchingId === o.id ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                        ) : (
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                        )}
                        Confirmer
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={patchingId === o.id}
                        className="h-8 border-red-200 text-red-600 hover:bg-red-50 font-semibold"
                        onClick={() => onPatch(o.id, 'CANCEL')}
                      >
                        <X className="h-3.5 w-3.5" aria-hidden="true" />
                        Annuler
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Dialog : Paramètres — changement du code PIN hôte.
// Double saisie sur clavier numérique (nouveau PIN + confirmation,
// les 2 saisies doivent matcher) → PUT /update { pin, newPin }.
// Le PIN ne vit QUE le temps de la saisie en mémoire (jamais
// persisté, jamais affiché) ; après succès, le PIN de session
// (état parent, en mémoire) est mis à jour.
// =============================================================
function SettingsPinDialog({
  onClose,
  slug,
  pin,
  onPinChanged,
}: {
  onClose: () => void;
  slug: string;
  pin: string;
  onPinChanged: (pin: string) => void;
}) {
  const [step, setStep] = useState<'new' | 'confirm'>('new');
  const [hasFirst, setHasFirst] = useState(false); // affichage •••• uniquement
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [keypadKey, setKeypadKey] = useState(0);
  const firstPinRef = useRef('');

  /** Fermeture : purge immédiate de la première saisie en mémoire. */
  const close = () => {
    firstPinRef.current = '';
    onClose();
  };

  const handleComplete = async (entered: string) => {
    if (step === 'new') {
      firstPinRef.current = entered;
      setHasFirst(true);
      setStep('confirm');
      setError('');
      setKeypadKey((k) => k + 1); // clavier neuf pour la confirmation
      return;
    }
    if (entered !== firstPinRef.current) {
      setError('Les deux codes ne correspondent pas. Recommencez.');
      firstPinRef.current = '';
      setHasFirst(false);
      setStep('new');
      setKeypadKey((k) => k + 1);
      return;
    }
    // Confirmation OK → PUT /update { pin, newPin }
    setSaving(true);
    setError('');
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/update`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin, newPin: entered }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Échec du changement de PIN.');
        setSaving(false);
        setKeypadKey((k) => k + 1);
        return;
      }
      firstPinRef.current = '';
      setHasFirst(false);
      toast.success('PIN modifié ✅', {
        description: 'Votre nouveau code est actif immédiatement.',
      });
      onPinChanged(entered); // le PIN de session (mémoire) passe au nouveau code
      setSaving(false);
      onClose();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
      setSaving(false);
      setKeypadKey((k) => k + 1);
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(v) => {
        if (!v && !saving) close();
      }}
    >
      <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl p-6 [&>button]:hidden">
        <DialogHeader className="items-center text-center">
          <span className="mx-auto" aria-hidden="true">
            <EmojiIcon emoji="⚙️" size="lg" variant="dark" />
          </span>
          <DialogTitle className="text-lg font-bold text-slate-900 text-center">
            Modifier le code PIN
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-600 text-center">
            {step === 'new'
              ? 'Saisissez votre nouveau code à 4 chiffres.'
              : 'Confirmez le nouveau code en le saisissant à nouveau.'}
          </DialogDescription>
        </DialogHeader>

        {saving ? (
          <div className="flex flex-col items-center gap-3 py-8" aria-busy="true">
            <Loader2 className="h-8 w-8 animate-spin text-emerald-600" aria-hidden="true" />
            <p className="text-sm text-slate-500">Enregistrement du nouveau code…</p>
          </div>
        ) : (
          <div className="mt-2">
            {hasFirst && (
              <p className="mb-3 text-center text-xs font-semibold text-slate-500" aria-live="polite">
                Code saisi : <span className="tracking-widest">••••</span>
              </p>
            )}
            <QRTNumericKeypad key={keypadKey} onComplete={handleComplete} />
            {error && (
              <p role="alert" className="mt-4 text-center text-sm font-semibold text-red-600">
                {error}
              </p>
            )}
            <Button
              type="button"
              variant="outline"
              className="mt-4 w-full h-11 border-slate-300 text-slate-600"
              onClick={close}
            >
              Annuler
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
/**
 * FIX VOCAL « Contacter l'hôte » — lien WhatsApp wa.me dérivé du
 * téléphone de l'hôte (aucun champ dédié en base) :
 *  - chiffres uniquement ; préfixe international « 00 » retiré ;
 *  - numéro FR à 10 chiffres commençant par 0 → indicatif 33 ;
 *  - +33/+221… passés tels quels (wa.me accepte le format E.164
 *    sans le « + »).
 * Retourne null si aucun numéro exploitable (carte masquée).
 */
function waMeHref(phone: string | null | undefined): string | null {
  if (!phone) return null;
  let digits = phone.replace(/\D/g, '');
  if (!digits) return null;
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.length === 10 && digits.startsWith('0')) digits = `33${digits.slice(1)}`;
  return digits.length >= 6 && digits.length <= 15 ? `https://wa.me/${digits}` : null;
}

// Dialog contact hôte + message vocal (répondeur).
// FIX « TOUT BLANC » + UX : PRÉ-ÉCOUTE obligatoire avant envoi
// (lecteur local sur blob URL → Envoyer / Réenregistrer) et
// RÉPONSES VOCALES DE L'HÔTE affichées à l'invité
// (GET /api/public/hub/[slug]/voice-replies — uniquement les
// messages senderType='HOST').
// FIX-32 (v4.21) : BUG BLOQUANT — recorder.ondataavailable n'était
// JAMAIS assigné → chunksRef restait vide → blob vide → erreur
// « Enregistrement vide » systématique. Le handler est restauré
// (même pattern que le guidebook /view et VoiceReplyButton).
// =============================================================
interface HostVoiceReply {
  id: string;
  senderName: string;
  audioUrl: string;
  durationSec: number;
  createdAt: string;
}

function ContactDialog({
  open,
  onClose,
  slug,
  contact,
  propertyName,
}: {
  open: boolean;
  onClose: () => void;
  slug: string;
  contact: HubPayload['guest']['contact'];
  propertyName: string;
}) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [sending, setSending] = useState(false);
  // PRÉ-ÉCOUTE : blob local avant envoi (url révoquée au nettoyage).
  const [preview, setPreview] = useState<{ url: string; blob: Blob; mime: string; duration: number } | null>(null);
  // Réponses vocales de l'hôte (senderType='HOST').
  const [replies, setReplies] = useState<HostVoiceReply[] | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const secondsRef = useRef(0);
  // FIX-VOCAL : mimeType réellement utilisé par le recorder (Safari/iOS
  // n'enregistre PAS en webm — il faut audio/mp4 → extension .m4a).
  const mimeRef = useRef('audio/webm');

  const stopTimers = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const cleanup = useCallback(() => {
    stopTimers();
    setRecording(false);
    setSeconds(0);
    secondsRef.current = 0;
    recorderRef.current?.stream?.getTracks?.().forEach((t) => t.stop());
    recorderRef.current = null;
    chunksRef.current = [];
    setPreview((prev) => {
      if (prev?.url) URL.revokeObjectURL(prev.url);
      return null;
    });
    setReplies(null);
  }, []);

  useEffect(() => {
    if (!open) cleanup();
  }, [open, cleanup]);

  // Réponses vocales de l'hôte — chargées à l'ouverture du dialog.
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    fetch(`/api/public/hub/${encodeURIComponent(slug)}/voice-replies`, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : { replies: [] }))
      .then((j: { replies?: HostVoiceReply[] }) => {
        if (!cancelled) setReplies(j.replies ?? []);
      })
      .catch(() => {
        if (!cancelled) setReplies([]);
      });
    return () => {
      cancelled = true;
    };
  }, [open, slug]);

  const stopRecording = (send: boolean) => {
    const recorder = recorderRef.current;
    stopTimers();
    if (!recorder) return;
    const duration = secondsRef.current;
    recorder.onstop = async () => {
      recorder.stream.getTracks().forEach((t) => t.stop());
      recorderRef.current = null;
      setRecording(false);
      if (!send) {
        toast.info('Enregistrement annulé.');
        return;
      }
      // FIX-VOCAL : type MIME réel du recorder (jamais forcé en webm —
      // Safari/iOS produit de l'audio/mp4 ; l'étiqueter webm cassait la lecture).
      const mimeType = mimeRef.current.split(';')[0].trim() || 'audio/webm';
      const blob = new Blob(chunksRef.current, { type: mimeType });
      if (blob.size === 0) {
        toast.error('Enregistrement vide. Réessayez.');
        return;
      }
      // PRÉ-ÉCOUTE — on ne POSTe plus immédiatement : l'invité écoute
      // son message puis choisit « Envoyer » ou « Réenregistrer ».
      const url = URL.createObjectURL(blob);
      setPreview({ url, blob, mime: mimeType, duration });
    };
    recorder.stop();
  };

  const sendPreview = async () => {
    if (!preview) return;
    setSending(true);
    try {
      const fd = new FormData();
      fd.append('audio', new File([preview.blob], `message.${extForMime(preview.mime)}`, { type: preview.mime }));
      fd.append('senderName', 'Invité');
      fd.append('durationSec', String(preview.duration));
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/voice`, {
        method: 'POST',
        body: fd,
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error || 'http');
      }
      toast.success('Message envoyé à votre hôte ✅');
      onClose();
    } catch (e) {
      const detail = e instanceof Error && e.message !== 'http' ? e.message : null;
      toast.error(detail || 'Envoi impossible. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // FIX-VOCAL : sélection du premier mimeType supporté par le navigateur
      // (webm/opus sur Chrome-Firefox, mp4/AAC sur Safari/iOS — avant, un
      // format non supporté levait une NotSupportedError ici).
      const mimeType = pickRecorderMime();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mimeRef.current = recorder.mimeType || mimeType || 'audio/webm';
      chunksRef.current = [];
      // FIX-32 : sans ce handler, les chunks audio ne sont JAMAIS
      // collectés → enregistrement vide à l'arrêt (bug bloquant).
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.start();
      recorderRef.current = recorder;
      setRecording(true);
      setSeconds(0);
      secondsRef.current = 0;
      timerRef.current = setInterval(() => {
        secondsRef.current += 1;
        setSeconds(secondsRef.current);
        if (secondsRef.current >= 30) {
          stopRecording(true);
        }
      }, 1000);
    } catch {
      toast.error('Micro inaccessible. Vérifiez les autorisations du navigateur.');
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !sending && onClose()}>
      <DialogContent className="max-w-sm bg-white border border-slate-200 rounded-xl">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">🚨 Contacter votre hôte</DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Un souci dans {propertyName} ? {contact.name} vous répond rapidement.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2.5">
          {contact.phone && (
            <a
              href={`tel:${contact.phone.replace(/\s/g, '')}`}
              className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3.5 hover:bg-slate-100 transition-colors"
            >
              <span className="text-2xl select-none" aria-hidden="true">
                📞
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900">Appeler {contact.name}</p>
                <p className="text-xs text-slate-500">{contact.phone}</p>
              </div>
              <Phone className="h-4 w-4 text-slate-400" aria-hidden="true" />
            </a>
          )}
          {/* FIX-32 — WhatsApp (wa.me) dérivé du téléphone de l'hôte */}
          {(() => {
            const waHref = waMeHref(contact.phone);
            return waHref ? (
              <a
                href={waHref}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 hover:bg-emerald-100 transition-colors"
                aria-label={`Contacter ${contact.name} sur WhatsApp`}
              >
                <span className="text-2xl select-none" aria-hidden="true">
                  💬
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-emerald-900">WhatsApp — {contact.name}</p>
                  <p className="text-xs text-emerald-700">Ouvrir la conversation WhatsApp</p>
                </div>
                <MessageCircle className="h-4 w-4 text-emerald-500" aria-hidden="true" />
              </a>
            ) : null;
          })()}
          {contact.email && (
            <a
              href={`mailto:${contact.email}?subject=${encodeURIComponent(`Message du Hub — ${propertyName}`)}`}
              className="flex items-center gap-3 bg-slate-50 border border-slate-200 rounded-xl p-3.5 hover:bg-slate-100 transition-colors"
            >
              <span className="text-2xl select-none" aria-hidden="true">
                ✉️
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-slate-900">Écrire un email</p>
                <p className="text-xs text-slate-500 truncate">{contact.email}</p>
              </div>
              <Mail className="h-4 w-4 text-slate-400" aria-hidden="true" />
            </a>
          )}

          {/* Répondeur vocal — avec pré-écoute avant envoi */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5">
            <p className="text-sm font-bold text-emerald-900">🎙️ Laisser un message vocal</p>
            <p className="text-[11px] text-emerald-800 mt-0.5">
              Décrivez le problème en 30 s max — vous pouvez l&apos;écouter avant de l&apos;envoyer.
            </p>
            {sending ? (
              <div className="mt-3 flex items-center gap-2 text-sm text-emerald-800">
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Envoi en cours…
              </div>
            ) : preview ? (
              <div className="mt-3 space-y-2.5">
                <p className="text-xs font-semibold text-emerald-900">
                  🎧 Écoutez votre message ({preview.duration}s) avant de l&apos;envoyer
                </p>
                <audio
                  controls
                  autoPlay
                  src={preview.url}
                  className="h-9 w-full"
                  aria-label="Pré-écoute de votre message vocal"
                />
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-9 flex-1 border-slate-300 text-slate-600"
                    onClick={() => {
                      setPreview((prev) => {
                        if (prev?.url) URL.revokeObjectURL(prev.url);
                        return null;
                      });
                    }}
                  >
                    Réenregistrer
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    className="h-9 flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                    onClick={sendPreview}
                  >
                    Envoyer
                  </Button>
                </div>
              </div>
            ) : recording ? (
              <div className="mt-3 flex items-center gap-2.5 flex-wrap">
                <span className="inline-flex items-center gap-1.5 text-sm font-bold text-red-600">
                  <span className="h-2.5 w-2.5 rounded-full bg-red-500 animate-pulse" aria-hidden="true" />
                  {String(Math.floor(seconds / 60)).padStart(2, '0')}:{String(seconds % 60).padStart(2, '0')}
                </span>
                <Button
                  type="button"
                  size="sm"
                  className="h-9 bg-slate-900 hover:bg-slate-800 text-white font-semibold"
                  onClick={() => stopRecording(true)}
                >
                  <Square className="h-3.5 w-3.5" aria-hidden="true" /> Écouter avant envoi
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-9 border-slate-300 text-slate-600"
                  onClick={() => stopRecording(false)}
                >
                  Annuler
                </Button>
              </div>
            ) : (
              <Button
                type="button"
                className="mt-3 w-full h-10 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold"
                onClick={startRecording}
              >
                <Mic className="h-4 w-4" aria-hidden="true" /> Démarrer l&apos;enregistrement
              </Button>
            )}
          </div>

          {/* Réponses vocales de votre hôte */}
          {replies && replies.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <p className="text-sm font-bold text-slate-900">💬 Réponses de votre hôte</p>
              <div className="mt-2 space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
                {replies.map((r) => (
                  <div key={r.id} className="bg-white border border-slate-200 rounded-lg p-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-bold text-slate-900 truncate">{r.senderName}</p>
                      <span className="text-[10px] text-slate-400 shrink-0">
                        {new Date(r.createdAt).toLocaleDateString('fr-FR', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                        {r.durationSec > 0 ? ` · ${r.durationSec}s` : ''}
                      </span>
                    </div>
                    <audio
                      controls
                      preload="none"
                      src={voiceAudioSrc(r.audioUrl)}
                      className="mt-1.5 h-9 w-full"
                      aria-label={`Réponse vocale de ${r.senderName}`}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// Formulaire écrit de réclamation (module 🚨 invité)
// Catégorie + description + photos (≤ 3, 500 Ko, PNG/JPEG/WebP)
// + checkbox Urgent + nom optionnel → POST /api/public/hub/[slug]/complaint
// =============================================================
const COMPLAINT_CATEGORIES = [
  { value: 'PLUMBING', label: '🚰 Fuite / Plomberie' },
  { value: 'ELECTRICAL', label: '⚡ Électricité' },
  { value: 'CLEANING', label: '🧹 Ménage' },
  { value: 'OTHER', label: '📝 Autre' },
] as const;

const MAX_PHOTO_BYTES = 500 * 1024;
const MAX_PHOTOS = 3;

function ComplaintFormDialog({
  open,
  onClose,
  slug,
  propertyName,
}: {
  open: boolean;
  onClose: () => void;
  slug: string;
  propertyName: string;
}) {
  const [category, setCategory] = useState<string>('OTHER');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [isUrgent, setIsUrgent] = useState(false);
  const [guestName, setGuestName] = useState('');
  const [sending, setSending] = useState(false);

  const reset = useCallback(() => {
    setCategory('OTHER');
    setDescription('');
    setPhotos([]);
    setIsUrgent(false);
    setGuestName('');
  }, []);

  const addPhotos = useCallback(
    (files: FileList | null) => {
      if (!files) return;
      const remaining = MAX_PHOTOS - photos.length;
      if (remaining <= 0) {
        toast.error(`Maximum ${MAX_PHOTOS} photos.`);
        return;
      }
      for (const file of Array.from(files).slice(0, remaining)) {
        if (!['image/png', 'image/jpeg', 'image/jpg', 'image/webp'].includes(file.type)) {
          toast.error(`« ${file.name} » : format non supporté (PNG, JPEG ou WebP).`);
          continue;
        }
        if (file.size > MAX_PHOTO_BYTES) {
          toast.error(`« ${file.name} » dépasse 500 Ko.`);
          continue;
        }
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') {
            setPhotos((prev) => (prev.length >= MAX_PHOTOS ? prev : [...prev, reader.result as string]));
          }
        };
        reader.readAsDataURL(file);
      }
    },
    [photos.length],
  );

  const submit = async () => {
    if (description.trim().length < 5) {
      toast.error('Décrivez le problème (5 caractères minimum).');
      return;
    }
    setSending(true);
    try {
      const res = await fetch(`/api/public/hub/${encodeURIComponent(slug)}/complaint`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category,
          description: description.trim(),
          photos,
          isUrgent,
          guestName: guestName.trim() || undefined,
        }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        toast.error(json.error || 'Envoi impossible. Réessayez.');
        return;
      }
      toast.success('✅ Réclamation envoyée. L’hôte vous contactera bientôt.');
      reset();
      onClose();
    } catch {
      toast.error('Erreur réseau. Réessayez.');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !sending && !v && onClose()}>
      <DialogContent className="max-w-md bg-white border border-slate-200 rounded-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base font-bold text-slate-900">🚨 Signaler un problème</DialogTitle>
          <DialogDescription className="text-xs text-slate-500">
            Un souci dans {propertyName} ? Décrivez-le — l&apos;hôte est notifié immédiatement.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Catégorie */}
          <div>
            <Label htmlFor="complaint-category" className="text-xs font-semibold text-slate-700">
              Catégorie
            </Label>
            <select
              id="complaint-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1.5 w-full h-11 rounded-xl border border-slate-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              {COMPLAINT_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="complaint-description" className="text-xs font-semibold text-slate-700">
              Description
            </Label>
            <Textarea
              id="complaint-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Décrivez le problème constaté, sa localisation dans le logement…"
              rows={4}
              maxLength={2000}
              className="mt-1.5 rounded-xl border-slate-300 text-sm focus-visible:ring-emerald-500"
            />
          </div>

          {/* Photos */}
          <div>
            <Label className="text-xs font-semibold text-slate-700">
              Photos <span className="font-normal text-slate-400">(optionnel — max {MAX_PHOTOS}, 500 Ko)</span>
            </Label>
            <div className="mt-1.5 flex items-center gap-2 flex-wrap">
              {photos.map((p, i) => (
                <div key={i} className="relative">
                  <img
                    src={p}
                    alt={`Photo ${i + 1}`}
                    className="h-16 w-16 rounded-lg border border-slate-200 object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <button
                    type="button"
                    aria-label={`Retirer la photo ${i + 1}`}
                    className="absolute -top-1.5 -right-1.5 h-5 w-5 rounded-full bg-slate-900 text-white inline-flex items-center justify-center shadow-sm hover:bg-slate-700"
                    onClick={() => setPhotos((prev) => prev.filter((_, j) => j !== i))}
                  >
                    <X className="h-3 w-3" aria-hidden="true" />
                  </button>
                </div>
              ))}
              {photos.length < MAX_PHOTOS && (
                <label className="h-16 w-16 rounded-lg border-2 border-dashed border-slate-300 flex flex-col items-center justify-center cursor-pointer text-slate-400 hover:border-slate-400 hover:text-slate-600 transition-colors">
                  <ImagePlus className="h-5 w-5" aria-hidden="true" />
                  <span className="text-[9px] font-semibold mt-0.5">Ajouter</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    multiple
                    className="sr-only"
                    onChange={(e) => {
                      addPhotos(e.target.files);
                      e.target.value = '';
                    }}
                  />
                </label>
              )}
            </div>
          </div>

          {/* Urgent + nom */}
          <div className="flex items-center gap-2">
            <Checkbox
              id="complaint-urgent"
              checked={isUrgent}
              onCheckedChange={(v) => setIsUrgent(v === true)}
              className="border-slate-400"
            />
            <Label htmlFor="complaint-urgent" className="text-sm font-semibold text-red-600 cursor-pointer">
              ⚠️ Urgent
            </Label>
          </div>
          <div>
            <Label htmlFor="complaint-name" className="text-xs font-semibold text-slate-700">
              Votre nom <span className="font-normal text-slate-400">(optionnel)</span>
            </Label>
            <Input
              id="complaint-name"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Ex : Camille, appartement 12…"
              maxLength={80}
              className="mt-1.5 h-11 rounded-xl border-slate-300 text-sm focus-visible:ring-emerald-500"
            />
          </div>

          <Button
            type="button"
            disabled={sending}
            className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl"
            onClick={submit}
          >
            {sending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Envoi en cours…
              </>
            ) : (
              '🚨 Envoyer à l’hôte'
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
