import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { normalizeMemberRole } from '@/lib/team';
import { hasActiveEdlSubscription } from '@/lib/edl-billing';
import { ShellV2 } from '@/components/airbnb/host/shell-v2';

// =============================================================
// Layout racine de l'Espace Hôte (/airbnb/*) — Dashboard Client
//
// • Session NextAuth OBLIGATOIRE (sinon retour accueil).
// • Les comptes superadmin sont renvoyés vers leur console.
// • v4.107 — Les comptes « EDL seul » (acheteurs du module standalone
//   299 €/an : abonnement actif, AUCUN bien, AUCUNE équipe) sont
//   redirigés vers LEUR tableau de bord : /inspection/dashboard —
//   ils n'accèdent JAMAIS au Hub classique.
// • Calcule le niveau d'accès réel en base :
//   'full'  → possède un bien OU manager accepté d'au moins un bien
//   'team'  → uniquement CLEANER / MAINTENANCE (navigation réduite)
// • V2 « BOUCLIER » : le shell est désormais ShellV2 (sidebar bleu
//   marine #1e3a8a, 8 rubriques, fond slate-50).
// =============================================================

export default async function AirbnbLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string; role?: string; name?: string | null } | undefined;

  if (!session?.user || !user?.id) {
    redirect('/');
  }
  if (user.role === 'superadmin') {
    // La console Superadmin vit dans /admin — pas de double espace.
    redirect('/admin/dashboard');
  }

  const userId = user.id;

  const [ownedCount, memberships] = await Promise.all([
    db.property.count({ where: { ownerId: userId } }),
    db.propertyMember.findMany({
      where: { userId, acceptedAt: { not: null } },
      select: { role: true },
    }),
  ]);

  const isManagerSomewhere = memberships.some((m) => {
    const role = normalizeMemberRole(m.role);
    return role === 'OWNER' || role === 'MANAGER';
  });

  const accessLevel: 'full' | 'team' = ownedCount > 0 || isManagerSomewhere ? 'full' : 'team';

  // v4.107 — Compte « EDL seul » → son dashboard dédié, jamais le Hub.
  if (ownedCount === 0 && memberships.length === 0) {
    const edlOnly = await hasActiveEdlSubscription(userId);
    if (edlOnly) {
      redirect('/inspection/dashboard');
    }
  }

  return (
    <ShellV2
      userName={session.user?.name ?? null}
      userEmail={session.user?.email ?? null}
      accessLevel={accessLevel}
    >
      {children}
    </ShellV2>
  );
}
