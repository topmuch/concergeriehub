import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { RestrictedAccess } from '@/components/airbnb/host/restricted-access';
import {
  SubscriptionContent,
  type CurrentOfferView,
} from '@/components/airbnb/host/subscription-content';

export const metadata: Metadata = {
  title: 'Gérer mon abonnement — RoomScan',
  description:
    'Votre offre RoomScan, sans engagement : Abonnement 1 (1 à 3 biens, 299 €/an), Abonnement 2 (4 à 20 biens, 499 €/an) et offre sur devis.',
};

// v5.4 — Page « Gérer mon abonnement » de l'Espace Hôte.
// Même pattern que /airbnb/billing : garde de session côté serveur,
// lecture de l'offre EDL en cours (InspectionSubscription : plan
// 'edl_annual' + endDate, croisée avec l'achat PayPal éventuel pour
// distinguer les paliers 299 € / 499 €) puis rendu client.
// Le shell (sidebar + header) est fourni par /airbnb/layout.tsx.
export default async function SubscriptionPage() {
  const session = await getServerSession(authOptions);
  const role = (session?.user as { role?: string } | undefined)?.role;
  const userId = (session?.user as { id?: string } | undefined)?.id;

  if (!session?.user || !userId) redirect('/');
  if (role !== 'user') redirect('/admin/dashboard');

  // Garde de rôle : réservé au propriétaire du compte (comme la
  // facturation) — les membres d'équipe voient l'écran d'accès restreint.
  const ownedCount = await db.property.count({ where: { ownerId: userId } });
  if (ownedCount === 0) {
    return <RestrictedAccess feature="la gestion de votre abonnement" />;
  }

  // Offre en cours : abonnement EDL actif non expiré. Le palier
  // (299 € / 499 €) est déduit du montant de l'achat PayPal rattaché.
  const [subscription, purchase] = await Promise.all([
    db.inspectionSubscription.findUnique({ where: { userId } }),
    db.edlPurchase.findFirst({
      where: { userId, status: { in: ['paid', 'activated'] } },
      orderBy: { paidAt: 'desc' },
    }),
  ]);

  let currentOffer: CurrentOfferView | null = null;
  if (
    subscription &&
    subscription.status === 'active' &&
    subscription.endDate.getTime() > Date.now()
  ) {
    const isPro = (purchase?.amountEur ?? 0) >= 499;
    currentOffer = {
      planLabel: isPro ? 'Abonnement 2 (4 à 20 biens)' : 'Abonnement 1 (1 à 3 biens)',
      isEssential: !isPro,
      isPro,
      endDateIso: subscription.endDate.toISOString(),
    };
  }

  return <SubscriptionContent currentOffer={currentOffer} />;
}
