import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { ZeroStateDashboard } from '@/components/airbnb/host/zero-state-dashboard';

export const metadata: Metadata = {
  title: "Vue d'ensemble — RoomScan",
  description:
    "Tableau de bord remis à zéro : aucun appartement, aucun onboarding — on reprend à zéro sur une base propre.",
};

// =============================================================
// v4.135 « REMISE À ZÉRO » (ÉTAPE 1, demande client) — le tableau de
// bord hôte n'affiche PLUS les anciennes KPIs / courbes / rubriques.
// Une seule vue : l'état zéro (aucun appartement, aucun onboarding),
// avec un unique CTA « Créer mon premier logement ». La session et
// le shell restent garantis par /airbnb/layout.tsx.
// =============================================================
export default async function DashboardPage() {
  await getServerSession(authOptions); // garantit le rendu dynamique (session)
  return <ZeroStateDashboard />;
}
