import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { MenageContent } from '@/components/airbnb/host/menage-content';

export const metadata: Metadata = {
  title: 'Ménage — RoomScan',
  description:
    'Onglet dédié au ménage : checklist de nettoyage, consigne vocale pour l’équipe et preuves des passages (photos + vocaux).',
};

// Onglet MÉNAGE du Dashboard Client (v4.43) :
//   1. Checklist de nettoyage — l'hôte garde la checklist générale ou
//      crée la sienne (visible par la femme de ménage dans le Hub) ;
//   2. Message vocal pour la femme de ménage (micro ou voix IA) ;
//   3. Preuves de ménage — rapports des passages : horaires, agent,
//      checklist validée, photos de l'appartement propre et vocal de
//      l'équipe (déplacés depuis l'onglet Messages).
// Session et shell garantis par /airbnb/layout.tsx.
export default async function MenagePage() {
  await getServerSession(authOptions); // garantit le rendu dynamique (session)
  return <MenageContent />;
}
