import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { FileText } from 'lucide-react';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { DocumentsContent } from '@/components/airbnb/host/documents-content';

export const metadata: Metadata = {
  title: 'Documents — RoomScan',
  description: 'Bibliothèque des PDF d’inspection (entrées, sorties, documents fusionnés).',
};

// v5.3 — Page « Documents » de l'Espace Hôte (Task 3-b).
// Bibliothèque unifiée des PDF d'inspection : module EDL standalone
// + états des lieux du Hub, avec filtres, recherche et poids fichier.
// GARDE DE RÔLE : copie du pattern de /airbnb/billing (audit 4-c) —
// session requise, comptes hôtes uniquement, documents réservés au
// PROPRIÉTAIRE du compte (Property.ownerId) ; un MANAGER membre
// d'équipe (CLEANER / MAINTENANCE) retourne vers son espace.
// Le shell (sidebar + header) est fourni par /airbnb/layout.tsx.
export default async function DocumentsPage() {
  const session = await getServerSession(authOptions);
  const role = (session?.user as { role?: string } | undefined)?.role;
  const userId = (session?.user as { id?: string } | undefined)?.id;

  if (!session?.user || !userId) {
    redirect('/');
  }
  if (role !== 'user') {
    // La console Superadmin a sa propre section /admin
    redirect('/admin/dashboard');
  }

  // ── Garde de rôle : documents réservés au propriétaire du compte ──
  const ownedCount = await db.property.count({ where: { ownerId: userId } });
  if (ownedCount === 0) {
    return <OwnerOnlyDocuments />;
  }

  return <DocumentsContent />;
}

// ── Écran de garde owner-only : carte élégante, pas d'erreur brute ──
function OwnerOnlyDocuments() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center">
      <div className="max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <span
          aria-hidden="true"
          className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100"
        >
          <FileText className="h-7 w-7 text-slate-500" />
        </span>
        <h1 className="mt-4 text-lg font-bold text-slate-900">
          Documents réservés au propriétaire du compte
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-600">
          La bibliothèque d&apos;états des lieux est gérée par le propriétaire des biens. Votre rôle
          dans l&apos;équipe vous donne accès à vos tâches et aux informations de terrain, mais pas
          aux documents.
        </p>
        <p className="mt-1 text-xs text-slate-400">
          Besoin d&apos;un document ? Contactez le propriétaire du compte.
        </p>
        <Link
          href="/airbnb/dashboard"
          className="mt-5 inline-flex h-10 items-center justify-center rounded-lg bg-[#0066EF] px-4 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#0052C4]"
        >
          ← Retour à la vue d&apos;ensemble
        </Link>
      </div>
    </div>
  );
}
