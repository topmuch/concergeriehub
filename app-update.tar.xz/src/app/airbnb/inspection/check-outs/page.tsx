import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { SessionsView } from '@/components/airbnb/host/v2/sessions-view';

export const metadata: Metadata = {
  title: 'Check-outs — RoomScan Bouclier',
  description:
    'États des lieux de sortie comparés photo par photo au check-in d’origine (fantômes 50 %).',
};

// V2 (étape 1) — Liste des check-outs.
export default async function CheckOutsPage() {
  await getServerSession(authOptions);
  return <SessionsView type="CHECKOUT" />;
}
