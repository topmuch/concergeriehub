import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { MenageView } from '@/components/airbnb/host/v2/menage-view';

export const metadata: Metadata = {
  title: 'Ménage à faire — RoomScan Bouclier',
  description: 'Séjours planifiés en attente : check-in et check-out, avec bouton « Nouveau Séjour ».',
};

// V2 (étape 1) — Ménage à faire + bouton « Nouveau Séjour ».
export default async function MenagePage() {
  await getServerSession(authOptions); // garantit le rendu dynamique (session)
  return <MenageView />;
}
