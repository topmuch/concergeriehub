import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { normalizeMemberRole } from '@/lib/team';
import { ShellV2 } from '@/components/airbnb/host/shell-v2';

// =============================================================
// Layout du portail ÉTATS DES LIEUX (/airbnb/inspection/*) —
// 3ᵉ dashboard de l'architecture (superadmin / admin hôte / admin
// états des lieux) : le rebuild V2 « BOUCLIER » vit ICI, dans son
// espace indépendant, pendant que l'admin hôte (conciergerie QR +
// Hub) occupe de nouveau /airbnb/* via le groupe (espace-hote).
//
// • Session NextAuth OBLIGATOIRE (sinon retour accueil).
// • Les comptes superadmin sont renvoyés vers leur console.
// • PAS de redirection « EDL seul » ici : c'est LEUR tableau de bord
//   (contrairement au groupe (espace-hote) qui la conserve).
// =============================================================

export default async function InspectionLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string; role?: string; name?: string | null } | undefined;

  if (!session?.user || !user?.id) {
    redirect('/');
  }
  if (user.role === 'superadmin') {
    // La console Superadmin vit dans /admin — pas de double espace.
    redirect('/admin/dashboard');
  }

  const userId = user.id;

  const [ownedCount, memberships] = await Promise.all([
    db.property.count({ where: { ownerId: userId } }),
    db.propertyMember.findMany({
      where: { userId, acceptedAt: { not: null } },
      select: { role: true },
    }),
  ]);

  const isManagerSomewhere = memberships.some((m) => {
    const role = normalizeMemberRole(m.role);
    return role === 'OWNER' || role === 'MANAGER';
  });

  const accessLevel: 'full' | 'team' = ownedCount > 0 || isManagerSomewhere ? 'full' : 'team';

  return (
    <ShellV2
      userName={session.user?.name ?? null}
      userEmail={session.user?.email ?? null}
      accessLevel={accessLevel}
    >
      {children}
    </ShellV2>
  );
}
