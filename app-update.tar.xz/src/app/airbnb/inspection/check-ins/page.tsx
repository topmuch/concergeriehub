import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { SessionsView } from '@/components/airbnb/host/v2/sessions-view';

export const metadata: Metadata = {
  title: 'Check-ins — RoomScan Bouclier',
  description: 'États des lieux d’entrée : 6 photos aux angles fixes + vidéo scellée SHA-256.',
};

// V2 (étape 1) — Liste des check-ins.
export default async function CheckInsPage() {
  await getServerSession(authOptions);
  return <SessionsView type="CHECKIN" />;
}
