import { redirect } from 'next/navigation';

// /airbnb/inspection → le 3ᵉ dashboard (admin états des lieux).
// URL demandée par le client — redirige vers le tableau de bord V2.
export default function InspectionIndexPage() {
  redirect('/airbnb/inspection/dashboard');
}
