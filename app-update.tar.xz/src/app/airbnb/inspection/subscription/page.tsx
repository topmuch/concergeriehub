import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { SubscriptionView } from '@/components/airbnb/host/v2/subscription-view';

export const metadata: Metadata = {
  title: 'Abonnement — RoomScan Bouclier',
  description: 'Essentiel 299 €/mois (3 logements) · Pro 499 €/mois (20 logements).',
};

// V2 (étape 1) — Abonnement : les deux formules demandées.
export default async function SubscriptionPage() {
  await getServerSession(authOptions);
  return <SubscriptionView />;
}
