import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { OnboardingWizard } from '@/components/airbnb/host/v2/onboarding-wizard';

export const metadata: Metadata = {
  title: 'Onboarding logement — RoomScan Bouclier',
  description:
    'Wizard en 3 étapes : type de logement → pièces & équipements → bibliothèque de photos de référence.',
};

// =============================================================
// V2 (étape 3 / flux A) — Wizard d'onboarding par logement.
// ?property=<id> → mode reconfiguration (pré-rempli, PATCH).
// Session et shell V2 garantis par /airbnb/layout.tsx.
// =============================================================
export default async function OnboardingPage({
  searchParams,
}: {
  searchParams: Promise<{ property?: string }>;
}) {
  await getServerSession(authOptions);
  const params = await searchParams;
  return <OnboardingWizard initialPropertyId={params.property} />;
}
