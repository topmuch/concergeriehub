import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { PropertiesView } from '@/components/airbnb/host/v2/properties-view';

export const metadata: Metadata = {
  title: 'Mes biens — RoomScan Bouclier',
  description:
    'Chaque logement avec son état d’onboarding — le bouton « Configurer » lance le wizard en 3 étapes.',
};

// V2 (étapes 1 + 3) — Mes biens : « Configurer » démarre l'onboarding.
// ?new=1 (lien partagé) ouvre directement le wizard sur un bien vierge.
export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: Promise<{ new?: string }>;
}) {
  await getServerSession(authOptions);
  const params = await searchParams;
  return <PropertiesView openWizardOnInit={params.new === '1'} />;
}
