import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { BouclierView } from '@/components/airbnb/host/v2/bouclier-view';

export const metadata: Metadata = {
  title: 'Bouclier — RoomScan Bouclier',
  description:
    'Bibliothèque de photos de référence par logement, réutilisée en fantômes 50 % lors des contrôles.',
};

// V2 (étape 1) — Bouclier : la bibliothèque de référence.
export default async function BouclierPage() {
  await getServerSession(authOptions);
  return <BouclierView />;
}
