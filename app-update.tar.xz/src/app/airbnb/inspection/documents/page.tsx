import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { DocumentsView } from '@/components/airbnb/host/v2/documents-view';

export const metadata: Metadata = {
  title: 'Documents — RoomScan Bouclier',
  description: 'Rapports PDF scellés (SHA-256) générés après chaque check-in et check-out.',
};

// V2 (étape 1) — Documents : rapports PDF des séjours terminés.
export default async function DocumentsPage() {
  await getServerSession(authOptions);
  return <DocumentsView />;
}
