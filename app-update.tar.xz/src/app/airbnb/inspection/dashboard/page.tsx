import type { Metadata } from 'next';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { DashboardView } from '@/components/airbnb/host/v2/dashboard-view';

export const metadata: Metadata = {
  title: 'Tableau de bord — RoomScan Bouclier',
  description:
    'Vue d’ensemble V2 : biens configurés, ménages à faire, check-ins, check-outs et documents scellés.',
};

// =============================================================
// V2 « BOUCLIER » (étape 1 du rebuild) — Tableau de bord :
// compteurs réels + état zéro avec CTA onboarding.
// Session et shell V2 garantis par /airbnb/layout.tsx.
// =============================================================
export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const firstName = session?.user?.name?.trim().split(/\s+/)[0] ?? 'Hôte';
  return <DashboardView firstName={firstName} />;
}
