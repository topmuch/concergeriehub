// =============================================================
// GET /api/uploads/voice/[file] — lecture des messages vocaux
//
// POURQUOI CETTE ROUTE (bug production) :
//  Les audios étaient écrits dans public/uploads/voice/ à l'exécution.
//  En build standalone (Docker), Next.js ne sert PAS les fichiers
//  apparus dans public/ après le build → <audio src="/uploads/…"> = 404
//  = « l'enregistrement vocal ne marche pas ».
//  Cette route sert le fichier depuis :
//   1. <cwd>/data/uploads/voice  (volume persistant Docker, avec la DB)
//   2. public/uploads/voice      (anciens fichiers déjà sur disque)
//  Content-Type correct par extension (allowlist stricte, basename
//  uniquement → aucune traversée de chemin possible).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { readFile, stat } from 'fs/promises';
import { join, basename } from 'path';
import { VOICE_ALLOWED_EXT, VOICE_CONTENT_TYPES, type VoiceAudioExt } from '@/lib/voice-audio';

function resolveUploadDirs(): string[] {
  const cwd = process.cwd();
  const dirs = [join(cwd, 'data', 'uploads', 'voice')];
  if (process.env.VOICE_UPLOAD_DIR) dirs.unshift(process.env.VOICE_UPLOAD_DIR);
  // Répertoire historique : fichiers écrits avant la migration.
  dirs.push(join(cwd, 'public', 'uploads', 'voice'));
  return dirs;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ file: string }> },
) {
  try {
    const { file: rawFile } = await params;
    // Sanitisation : basename uniquement + allowlist de caractères.
    let name: string;
    try {
      name = basename(decodeURIComponent(rawFile));
    } catch {
      return NextResponse.json({ error: 'Fichier invalide' }, { status: 404 });
    }
    if (!/^[A-Za-z0-9._-]+$/.test(name) || name.startsWith('.')) {
      return NextResponse.json({ error: 'Fichier invalide' }, { status: 404 });
    }
    const ext = (name.split('.').pop() ?? '').toLowerCase() as VoiceAudioExt;
    if (!(VOICE_ALLOWED_EXT as readonly string[]).includes(ext)) {
      return NextResponse.json({ error: 'Format audio non supporté' }, { status: 404 });
    }

    for (const dir of resolveUploadDirs()) {
      const filePath = join(dir, name);
      try {
        const info = await stat(filePath);
        if (!info.isFile()) continue;
        const bytes = await readFile(filePath);
        return new NextResponse(new Uint8Array(bytes), {
          status: 200,
          headers: {
            'Content-Type': VOICE_CONTENT_TYPES[ext] ?? 'application/octet-stream',
            'Content-Length': String(info.size),
            // Audio privé (voix d'invités) : cache navigateur court, jamais
            // de cache intermédiaire/CDN.
            'Cache-Control': 'private, max-age=3600',
            'X-Content-Type-Options': 'nosniff',
            'Accept-Ranges': 'none',
          },
        });
      } catch {
        // Fichier absent dans ce répertoire → candidat suivant.
      }
    }

    return NextResponse.json(
      { error: 'Audio introuvable (fichier expiré ou supprimé)' },
      { status: 404 },
    );
  } catch (error) {
    console.error('[uploads/voice GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
