// =============================================================
// /api/admin/assistance/[id] — ASSISTANCE EDL (v4.125) — SUPERADMIN
//
// GET   : détail d'un ticket + fil complet (tous comptes).
// POST  : réponse du Superadmin {body} → message 'ADMIN' + statut
//         ANSWERED. L'hôte voit la réponse dans son onglet
//         « Assistance » (mêmes tables — onglets CONNECTÉS).
// PATCH : changement de statut {status} par l'admin.
// =============================================================
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';

const STATUSES = ['OPEN', 'ANSWERED', 'RESOLVED', 'CLOSED'] as const;

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireSuperadmin();
    if (!admin) return adminUnauthorized();

    const { id } = await params;
    const ticket = await db.edlSupportTicket.findUnique({
      where: { id },
      include: { messages: { orderBy: { createdAt: 'asc' } } },
    });
    if (!ticket) return bad('Ticket introuvable.', 404);

    return NextResponse.json(
      {
        ticket: {
          id: ticket.id,
          subject: ticket.subject,
          category: ticket.category,
          priority: ticket.priority,
          status: ticket.status,
          userName: ticket.userName,
          userEmail: ticket.userEmail,
          userId: ticket.userId,
          createdAt: ticket.createdAt.toISOString(),
          updatedAt: ticket.updatedAt.toISOString(),
          messages: ticket.messages.map((m) => ({
            id: m.id,
            author: m.author,
            authorName: m.authorName,
            body: m.body,
            createdAt: m.createdAt.toISOString(),
          })),
        },
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    console.error('[admin/assistance/:id GET] Error:', error);
    return bad('Impossible de charger le ticket.', 500);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireSuperadmin();
    if (!admin) return adminUnauthorized();

    const { id } = await params;
    const ticket = await db.edlSupportTicket.findUnique({ where: { id }, select: { id: true } });
    if (!ticket) return bad('Ticket introuvable.', 404);

    const body = (await req.json().catch(() => null)) as { body?: unknown } | null;
    const text = typeof body?.body === 'string' ? body.body.trim() : '';
    if (text.length < 2 || text.length > 5000) {
      return bad('invalid_body', 400, 'La réponse doit contenir entre 2 et 5000 caractères.');
    }

    const adminName = admin.name ?? admin.email ?? 'Support RoomScan';
    const [, updated] = await db.$transaction([
      db.edlSupportMessage.create({
        data: {
          ticketId: ticket.id,
          author: 'ADMIN',
          authorName: adminName,
          body: text,
        },
      }),
      db.edlSupportTicket.update({
        where: { id: ticket.id },
        data: { status: 'ANSWERED' },
      }),
    ]);

    return NextResponse.json({ id: ticket.id, status: updated.status }, { status: 201 });
  } catch (error) {
    console.error('[admin/assistance/:id POST] Error:', error);
    return bad('Impossible d’envoyer la réponse.', 500);
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireSuperadmin();
    if (!admin) return adminUnauthorized();

    const { id } = await params;
    const ticket = await db.edlSupportTicket.findUnique({ where: { id }, select: { id: true } });
    if (!ticket) return bad('Ticket introuvable.', 404);

    const body = (await req.json().catch(() => null)) as { status?: unknown } | null;
    const status = typeof body?.status === 'string' ? body.status : '';
    if (!(STATUSES as readonly string[]).includes(status)) {
      return bad('invalid_status', 400, 'Statut non autorisé.');
    }

    const updated = await db.edlSupportTicket.update({
      where: { id: ticket.id },
      data: { status },
      select: { id: true, status: true },
    });
    return NextResponse.json(updated);
  } catch (error) {
    console.error('[admin/assistance/:id PATCH] Error:', error);
    return bad('Impossible de mettre à jour le ticket.', 500);
  }
}
