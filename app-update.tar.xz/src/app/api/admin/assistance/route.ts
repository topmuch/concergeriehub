// =============================================================
// /api/admin/assistance — ASSISTANCE EDL (v4.125) — CÔTÉ SUPERADMIN
//
// GET : liste de TOUS les tickets d'assistance (tous comptes),
//       avec compteur de messages + dernier message. Filtre
//       optionnel ?status=OPEN|ANSWERED|RESOLVED|CLOSED.
//       L'onglet « Assistance » du Superadmin (/admin/assistance)
//       consomme cette route — connecté à l'onglet hôte via les
//       tables edl_support_tickets / edl_support_messages.
// =============================================================
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';

const STATUSES = ['OPEN', 'ANSWERED', 'RESOLVED', 'CLOSED'] as const;

export async function GET(req: Request) {
  try {
    const admin = await requireSuperadmin();
    if (!admin) return adminUnauthorized();

    const url = new URL(req.url);
    const statusFilter = url.searchParams.get('status') ?? '';
    const where =
      statusFilter && (STATUSES as readonly string[]).includes(statusFilter)
        ? { status: statusFilter }
        : {};

    const tickets = await db.edlSupportTicket.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      take: 300,
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          select: { author: true, body: true, createdAt: true },
        },
      },
    });

    const counts = {
      total: tickets.length,
      open: tickets.filter((t) => t.status === 'OPEN').length,
      answered: tickets.filter((t) => t.status === 'ANSWERED').length,
      resolved: tickets.filter((t) => t.status === 'RESOLVED').length,
      closed: tickets.filter((t) => t.status === 'CLOSED').length,
    };

    return NextResponse.json(
      {
        counts,
        tickets: tickets.map((t) => {
          const last = t.messages[t.messages.length - 1] ?? null;
          return {
            id: t.id,
            subject: t.subject,
            category: t.category,
            priority: t.priority,
            status: t.status,
            userName: t.userName,
            userEmail: t.userEmail,
            userId: t.userId,
            createdAt: t.createdAt.toISOString(),
            updatedAt: t.updatedAt.toISOString(),
            messagesCount: t.messages.length,
            lastMessage: last
              ? { author: last.author, body: last.body, createdAt: last.createdAt.toISOString() }
              : null,
          };
        }),
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    console.error('[admin/assistance GET] Error:', error);
    return NextResponse.json({ error: 'Impossible de charger les tickets.' }, { status: 500 });
  }
}
