import type { NextRequest } from 'next/server';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';
import { purgeBusinessData } from '@/lib/reset-business-data';

// =============================================================
// v4.135 « REMISE À ZÉRO » — route admin de purge métier complète
//
// POST /api/admin/reset-business-data
//   • Réservée au Superadmin (requireSuperadmin — même garde que
//     toutes les routes /api/admin/*).
//   • Double garde-fou : body JSON { "confirm": "RESET" } OBLIGATOIRE.
//   • Purge TOUTES les données métier (biens, onboarding, séjours,
//     EDL/Bouclier, photos/vidéos, QR, hub, marketplace…) — les
//     COMPTES (superadmin, hôtes) sont conservés.
//   • Trace l'opération dans l'AuditLog.
// =============================================================

export async function POST(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  let body: { confirm?: string } = {};
  try {
    body = (await request.json()) as { confirm?: string };
  } catch {
    body = {};
  }
  if (body?.confirm !== 'RESET') {
    return Response.json(
      { error: 'Confirmation manquante — envoyer { "confirm": "RESET" }' },
      { status: 400 },
    );
  }

  try {
    const result = await purgeBusinessData({ id: admin.id, email: admin.email });
    console.log(
      `[reset-business-data] purge effectuée par ${admin.email} — ${result.totalRows} lignes, ${result.filesRemoved} fichiers`,
    );
    return Response.json({ ok: true, ...result });
  } catch (error) {
    console.error('[reset-business-data] échec de la purge :', error);
    return Response.json(
      { error: error instanceof Error ? error.message : 'Échec de la remise à zéro' },
      { status: 500 },
    );
  }
}
