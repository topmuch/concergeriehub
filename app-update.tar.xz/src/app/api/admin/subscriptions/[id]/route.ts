// =============================================================
// /api/admin/subscriptions/[id] — Module 4 : actions abonnement
//
// PATCH ?action=cancel   → status 'cancelled' (fin de période non
//                          forcée : arrêt administratif immédiat)
// PATCH ?action=reactivate → status 'active'
// PATCH ?action=mark-paid  → status 'active' (régularisation impayé)
// PATCH ?action=edit       → v4.71 ÉDITION COMPLÈTE (body JSON) :
//   { plan?: 'airbnb_solo'|'airbnb_pro'|'custom', billingCycle?,
//     amount?, maxProperties?, status? } — changement de plan avec
//     RECALCUL IMMÉDIAT du prix (HOST_PLANS) et des biens inclus.
//
// Chaque action est journalisée (audit). Sans clé Stripe, les
// changements restent locaux (source de vérité = base + webhook
// Stripe mettra à jour à la prochaine synchronisation).
// 🔒 Superadmin.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';
import { db } from '@/lib/db';
import { logAudit, clientIp } from '@/lib/audit';
import { mutationGuard, mutationKey, MUTATIONS_LIMIT_ADMIN } from '@/lib/mutation-guard';
import { HOST_PLANS } from '@/lib/billing';

// v4.71 — schéma d'édition d'un abonnement (superadmin).
const editSchema = z.object({
  plan: z.enum(['airbnb_solo', 'airbnb_pro', 'custom']).optional(),
  billingCycle: z.enum(['monthly', 'annual']).optional(),
  amount: z.number().min(0).max(100_000).optional(),
  maxProperties: z.number().int().min(1).max(1000).optional(),
  status: z.enum(['active', 'past_due', 'cancelled', 'trialing']).optional(),
});

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

const ACTIONS = {
  cancel: { status: 'cancelled' },
  reactivate: { status: 'active' },
  'mark-paid': { status: 'active' },
} as const;

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  // FIX-15 — anti-abus : 60 mutations/min par admin (Console Superadmin).
  const mutGuard = await mutationGuard(mutationKey('admin-mut', req, admin.id), MUTATIONS_LIMIT_ADMIN);
  if (mutGuard) return mutGuard;

  try {
    const { id } = await params;
    const action = req.nextUrl.searchParams.get('action') ?? '';

    // ── v4.71 — ÉDITION COMPLÈTE (plan / cycle / montant / statut) ──
    if (action === 'edit') {
      const body = (await req.json().catch(() => null)) as unknown;
      const parsed = editSchema.safeParse(body ?? {});
      if (!parsed.success) {
        return NextResponse.json(
          { error: 'Formulaire invalide — vérifiez plan, cycle, montant et statut.' },
          { status: 400 },
        );
      }
      const d = parsed.data;
      const sub = await db.subscription.findUnique({
        where: { id },
        select: { id: true, plan: true, status: true, amount: true, billingCycle: true, maxProperties: true },
      });
      if (!sub) {
        return NextResponse.json({ error: 'Abonnement introuvable' }, { status: 404 });
      }

      const data: Record<string, unknown> = {};
      if (d.plan && d.plan !== 'custom') {
        const hp = HOST_PLANS.find((p) => p.id === d.plan);
        if (hp) {
          data.plan = hp.id;
          data.maxProperties = hp.maxProperties;
          const cycle = d.billingCycle ?? (sub.billingCycle as 'monthly' | 'annual');
          const price = hp.prices[cycle] ?? hp.prices.annual; // Pro : mensuel absent → annual
          data.billingCycle = hp.prices[cycle] != null ? cycle : 'annual';
          data.amount = price;
        }
      } else {
        // Édition libre (plan conservé ou « custom ») : on applique les
        // champs fournis sans recalcul forcé.
        if (d.plan === 'custom') data.plan = sub.plan; // plan inchangé, édition manuelle
        if (d.billingCycle) data.billingCycle = d.billingCycle;
        if (d.amount != null) data.amount = round2(d.amount);
        if (d.maxProperties != null) data.maxProperties = d.maxProperties;
      }
      if (d.status) data.status = d.status;

      if (Object.keys(data).length === 0) {
        return NextResponse.json({ error: 'Aucune modification fournie.' }, { status: 400 });
      }

      await db.subscription.update({ where: { id }, data });
      await logAudit({
        actor: admin,
        action: 'subscription.edit',
        entityType: 'subscription',
        entityId: id,
        details: {
          plan: (data.plan as string) ?? sub.plan,
          from: { plan: sub.plan, amount: sub.amount, cycle: sub.billingCycle, status: sub.status, max: sub.maxProperties },
          to: data,
        },
        ip: clientIp(req.headers),
      });

      return NextResponse.json({ ok: true, message: 'Abonnement mis à jour ✓' });
    }

    const mapping = (ACTIONS as Record<string, { status: string }>)[action];
    if (!mapping) {
      return NextResponse.json(
        { error: 'Action inconnue (cancel | reactivate | mark-paid | edit)' },
        { status: 400 },
      );
    }

    const sub = await db.subscription.findUnique({
      where: { id },
      select: { id: true, plan: true, status: true, userId: true, subscriberId: true },
    });
    if (!sub) {
      return NextResponse.json({ error: 'Abonnement introuvable' }, { status: 404 });
    }

    await db.subscription.update({ where: { id }, data: { status: mapping.status } });
    await logAudit({
      actor: admin,
      action: `subscription.${action.replace('-', '_')}`,
      entityType: 'subscription',
      entityId: id,
      details: { plan: sub.plan, from: sub.status, to: mapping.status },
      ip: clientIp(req.headers),
    });

    return NextResponse.json({ ok: true, message: `Abonnement ${action === 'cancel' ? 'annulé' : 'réactivé'}` });
  } catch (error) {
    console.error('[PATCH /api/admin/subscriptions/[id]] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
