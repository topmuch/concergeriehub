// =============================================================
// /api/admin/emails/config — Configuration e-mail (v4.56)
//
// GET  : état effectif de la config (expéditeur + boîte de
//        réception des notifications) avec la SOURCE de chaque
//        valeur : 'database' (config Superadmin) | 'env' | 'default'.
// PUT  : sauvegarde { from?, systemInbox? } en base (table
//        system_settings). Valeur vide = suppression de l'override
//        (retour à la variable d'environnement / au défaut).
//
// 🔒 Réservé au Superadmin (role 'superadmin').
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';
import {
  emailFromAddress,
  emailProviderConfigured,
  invalidateEmailConfigCache,
  saveEmailSetting,
  systemNotificationEmail,
  EMAIL_SETTING_KEYS,
} from '@/lib/email';
import { db } from '@/lib/db';

type Source = 'database' | 'env' | 'default';

function providerName(): string {
  if (process.env.RESEND_API_KEY?.trim()) return 'resend';
  if (process.env.SMTP_HOST?.trim() && process.env.SMTP_PORT?.trim()) return 'smtp';
  return 'none';
}

async function readDbOverrides(): Promise<{ from: string | null; inbox: string | null }> {
  try {
    const rows = await db.systemSetting.findMany({
      where: { key: { in: [EMAIL_SETTING_KEYS.FROM, EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX] } },
      select: { key: true, value: true },
    });
    return {
      from: rows.find((r) => r.key === EMAIL_SETTING_KEYS.FROM)?.value ?? null,
      inbox: rows.find((r) => r.key === EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX)?.value ?? null,
    };
  } catch {
    return { from: null, inbox: null };
  }
}

function buildPayload(
  effectiveFrom: string,
  effectiveInbox: string,
  overrides: { from: string | null; inbox: string | null },
) {
  return {
    from: effectiveFrom,
    fromSource: overrides.from?.trim()
      ? ('database' as Source)
      : process.env.EMAIL_FROM?.trim()
        ? ('env' as Source)
        : ('default' as Source),
    fromOverride: overrides.from ?? '',
    systemInbox: effectiveInbox,
    systemInboxSource:
      overrides.inbox !== null && overrides.inbox.trim()
        ? ('database' as Source)
        : process.env.NOTIFICATIONS_EMAIL?.trim()
          ? ('env' as Source)
          : ('default' as Source),
    systemInboxOverride: overrides.inbox ?? '',
    provider: providerName(),
    providerConfigured: emailProviderConfigured(),
  };
}

export async function GET() {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    const [effectiveFrom, effectiveInbox, overrides] = await Promise.all([
      emailFromAddress(),
      systemNotificationEmail(),
      readDbOverrides(),
    ]);
    return NextResponse.json(buildPayload(effectiveFrom, effectiveInbox, overrides));
  } catch (error) {
    console.error('[admin/emails/config] GET failed:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    const body = (await request.json().catch(() => null)) as
      | { from?: string; systemInbox?: string }
      | null;
    if (!body) {
      return NextResponse.json({ error: 'Requête invalide' }, { status: 400 });
    }

    if (typeof body.from === 'string') {
      const res = await saveEmailSetting('from', body.from);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.systemInbox === 'string') {
      const res = await saveEmailSetting('inbox', body.systemInbox);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }

    invalidateEmailConfigCache();

    const [effectiveFrom, effectiveInbox, overrides] = await Promise.all([
      emailFromAddress(),
      systemNotificationEmail(),
      readDbOverrides(),
    ]);
    return NextResponse.json({ ok: true, ...buildPayload(effectiveFrom, effectiveInbox, overrides) });
  } catch (error) {
    console.error('[admin/emails/config] PUT failed:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
