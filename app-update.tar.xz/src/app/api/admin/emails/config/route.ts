// =============================================================
// /api/admin/emails/config — Configuration e-mail (v4.56 → v4.57)
//
// GET  : état effectif de la config (expéditeur, boîte de réception
//        des notifications, provider d'envoi) avec la SOURCE de
//        chaque valeur : 'database' (config Superadmin) | 'env' |
//        'default'. Les secrets ne sont JAMAIS renvoyés en clair
//        (masqués, 4 derniers caractères).
// PUT  : sauvegarde { from?, systemInbox?, provider?, resendApiKey?,
//        smtpHost?, smtpPort?, smtpUser?, smtpPass? } en base (table
//        system_settings). Valeur vide = suppression de l'override
//        (retour à la variable d'environnement / au défaut). Les
//        champs secrets non fournis (undefined) sont laissés tels quels.
// POST : envoi d'un email de TEST { to? } (défaut = boîte système).
//
// 🔒 Réservé au Superadmin (role 'superadmin').
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';
import {
  emailFromAddress,
  emailProviderConfigured,
  invalidateEmailConfigCache,
  resolveEmailProvider,
  saveEmailSetting,
  sendTestEmail,
  systemNotificationEmail,
  EMAIL_SETTING_KEYS,
} from '@/lib/email';
import { db } from '@/lib/db';

type Source = 'database' | 'env' | 'default';

function maskSecret(value: string): string {
  if (!value) return '';
  return value.length <= 8 ? '••••••' : `••••••••${value.slice(-4)}`;
}

async function readDbOverrides(): Promise<{
  from: string | null;
  inbox: string | null;
  provider: string | null;
  resendKey: string | null;
  smtpHost: string | null;
  smtpPort: string | null;
  smtpUser: string | null;
  smtpPass: string | null;
}> {
  const empty = {
    from: null,
    inbox: null,
    provider: null,
    resendKey: null,
    smtpHost: null,
    smtpPort: null,
    smtpUser: null,
    smtpPass: null,
  };
  try {
    const rows = await db.systemSetting.findMany({
      where: {
        key: {
          in: [
            EMAIL_SETTING_KEYS.FROM,
            EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX,
            EMAIL_SETTING_KEYS.PROVIDER,
            EMAIL_SETTING_KEYS.RESEND_API_KEY,
            EMAIL_SETTING_KEYS.SMTP_HOST,
            EMAIL_SETTING_KEYS.SMTP_PORT,
            EMAIL_SETTING_KEYS.SMTP_USER,
            EMAIL_SETTING_KEYS.SMTP_PASS,
          ],
        },
      },
      select: { key: true, value: true },
    });
    return {
      from: rows.find((r) => r.key === EMAIL_SETTING_KEYS.FROM)?.value ?? null,
      inbox: rows.find((r) => r.key === EMAIL_SETTING_KEYS.NOTIFICATIONS_INBOX)?.value ?? null,
      provider: rows.find((r) => r.key === EMAIL_SETTING_KEYS.PROVIDER)?.value ?? null,
      resendKey: rows.find((r) => r.key === EMAIL_SETTING_KEYS.RESEND_API_KEY)?.value ?? null,
      smtpHost: rows.find((r) => r.key === EMAIL_SETTING_KEYS.SMTP_HOST)?.value ?? null,
      smtpPort: rows.find((r) => r.key === EMAIL_SETTING_KEYS.SMTP_PORT)?.value ?? null,
      smtpUser: rows.find((r) => r.key === EMAIL_SETTING_KEYS.SMTP_USER)?.value ?? null,
      smtpPass: rows.find((r) => r.key === EMAIL_SETTING_KEYS.SMTP_PASS)?.value ?? null,
    };
  } catch {
    return empty;
  }
}

async function buildPayload() {
  const [effectiveFrom, effectiveInbox, resolved, overrides, configured] = await Promise.all([
    emailFromAddress(),
    systemNotificationEmail(),
    resolveEmailProvider(),
    readDbOverrides(),
    emailProviderConfigured(),
  ]);

  const envSmtp = Boolean(process.env.SMTP_HOST?.trim());

  return {
    from: effectiveFrom,
    fromSource: overrides.from?.trim()
      ? ('database' as Source)
      : process.env.EMAIL_FROM?.trim()
        ? ('env' as Source)
        : ('default' as Source),
    fromOverride: overrides.from ?? '',
    systemInbox: effectiveInbox,
    systemInboxSource:
      overrides.inbox !== null && overrides.inbox.trim()
        ? ('database' as Source)
        : process.env.NOTIFICATIONS_EMAIL?.trim()
          ? ('env' as Source)
          : ('default' as Source),
    systemInboxOverride: overrides.inbox ?? '',
    provider: resolved.type,
    providerSource: resolved.source,
    providerConfigured: configured,
    // Resend (secret masqué, jamais en clair)
    resendKeySet: Boolean(resolved.resendApiKey),
    resendKeyMasked: maskSecret(resolved.resendApiKey),
    resendKeyFromDb: Boolean(overrides.resendKey),
    // SMTP (hôte/port/utilisateur lisibles, mot de passe masqué)
    smtpHost: overrides.smtpHost ?? (envSmtp ? (process.env.SMTP_HOST ?? '') : ''),
    smtpPort: overrides.smtpPort ?? process.env.SMTP_PORT?.trim() ?? '',
    smtpUser: overrides.smtpUser ?? process.env.SMTP_USER?.trim() ?? '',
    smtpPassSet: Boolean(resolved.smtp.pass),
    smtpPassMasked: maskSecret(resolved.smtp.pass),
    smtpFromDb: Boolean(overrides.smtpHost || overrides.smtpPort || overrides.smtpUser || overrides.smtpPass),
  };
}

export async function GET() {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    return NextResponse.json(await buildPayload());
  } catch (error) {
    console.error('[admin/emails/config] GET failed:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    const body = (await request.json().catch(() => null)) as
      | {
          from?: string;
          systemInbox?: string;
          provider?: string;
          resendApiKey?: string;
          smtpHost?: string;
          smtpPort?: string;
          smtpUser?: string;
          smtpPass?: string;
        }
      | null;
    if (!body) {
      return NextResponse.json({ error: 'Requête invalide' }, { status: 400 });
    }

    if (typeof body.from === 'string') {
      const res = await saveEmailSetting('from', body.from);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.systemInbox === 'string') {
      const res = await saveEmailSetting('inbox', body.systemInbox);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.provider === 'string') {
      if (body.provider.trim() === '') {
        const res = await saveEmailSetting('provider', '');
        if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
      } else {
        const res = await saveEmailSetting('provider', body.provider);
        if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
      }
    }
    if (typeof body.resendApiKey === 'string') {
      const res = await saveEmailSetting('resend_api_key', body.resendApiKey);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.smtpHost === 'string') {
      const res = await saveEmailSetting('smtp_host', body.smtpHost);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.smtpPort === 'string') {
      const res = await saveEmailSetting('smtp_port', body.smtpPort);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.smtpUser === 'string') {
      const res = await saveEmailSetting('smtp_user', body.smtpUser);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }
    if (typeof body.smtpPass === 'string') {
      const res = await saveEmailSetting('smtp_pass', body.smtpPass);
      if (!res.ok) return NextResponse.json({ error: res.error }, { status: 400 });
    }

    // Cohérence : un provider choisi doit avoir ses identifiants.
    const resolved = await resolveEmailProvider();
    if (resolved.type === 'resend' && !resolved.resendApiKey) {
      return NextResponse.json(
        { error: 'Clé API Resend manquante — renseignez-la avant d’enregistrer' },
        { status: 400 },
      );
    }
    if (resolved.type === 'smtp' && (!resolved.smtp.host || !resolved.smtp.port)) {
      return NextResponse.json(
        { error: 'Serveur et port SMTP requis (ex : smtp.gmail.com / 587)' },
        { status: 400 },
      );
    }

    invalidateEmailConfigCache();
    return NextResponse.json({ ok: true, ...(await buildPayload()) });
  } catch (error) {
    console.error('[admin/emails/config] PUT failed:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    const body = (await request.json().catch(() => null)) as { to?: string } | null;
    const to = body?.to?.trim() || (await systemNotificationEmail());
    if (!to || !to.includes('@')) {
      return NextResponse.json(
        { error: 'Indiquez une adresse de destination (ou configurez la boîte de réception)' },
        { status: 400 },
      );
    }
    const result = await sendTestEmail(to);
    return NextResponse.json({
      ok: result.status === 'SENT',
      status: result.status,
      provider: result.provider,
      to,
      error: result.error,
    });
  } catch (error) {
    console.error('[admin/emails/config] POST (test) failed:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
