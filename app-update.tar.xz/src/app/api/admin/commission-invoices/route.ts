// =============================================================
// /api/admin/commission-invoices — v4.69 PHASE 5
// « COMMISSION, CRM SUPERADMIN & FACTURATION MENSUELLE »
//
// GET    ?status= &month= &year= &search=   → factures + KPIs
// POST   { month, year, hostId? }           → génère (1 hôte ou tous
//          les hôtes actifs du mois). Idempotent : upsert — une facture
//          PAID n'est jamais écrasée ; une facture PENDING est
//          recalculée. Taux = HostSettings.commissionRate (défaut 0.20).
// PATCH  { id, status }                     → statut (paid → paidAt now)
//        { hostId, commissionRate }         → taux de commission hôte
// DELETE ?id=                               → suppression (si non payée)
//
// 🔒 Superadmin. Mutations journalisées (audit) + rate limit admin.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { requireSuperadmin, adminUnauthorized } from '@/lib/admin';
import { db } from '@/lib/db';
import { logAudit } from '@/lib/audit';
import { mutationGuard, mutationKey, MUTATIONS_LIMIT_ADMIN } from '@/lib/mutation-guard';
import {
  computeHostMonthlyTotals,
  findActiveOwnerIds,
  getOrCreateHostSettings,
  monthDueDate,
  round2,
  DEFAULT_HOST_COMMISSION_RATE,
} from '@/lib/commission';

const monthYearSchema = z.object({
  month: z.number().int().min(1).max(12),
  year: z.number().int().min(2024).max(2100),
});

export async function GET(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();

  try {
    const { searchParams } = request.nextUrl;
    const status = searchParams.get('status');
    const month = searchParams.get('month') ? Number(searchParams.get('month')) : null;
    const year = searchParams.get('year') ? Number(searchParams.get('year')) : null;
    const search = searchParams.get('search')?.trim().toLowerCase() || '';

    const where: {
      status?: string;
      month?: number;
      year?: number;
      host?: { OR: Array<{ email?: object; fullName?: object }> };
    } = {};
    if (status && ['pending', 'paid', 'overdue'].includes(status)) where.status = status;
    if (month && month >= 1 && month <= 12) where.month = month;
    if (year && year >= 2024) where.year = year;
    if (search) {
      where.host = {
        OR: [{ email: { contains: search } }, { fullName: { contains: search } }],
      };
    }

    const [invoices, all] = await Promise.all([
      db.monthlyCommissionInvoice.findMany({
        where,
        orderBy: [{ year: 'desc' }, { month: 'desc' }, { createdAt: 'desc' }],
        take: 300,
        include: { host: { select: { id: true, email: true, fullName: true } } },
      }),
      db.monthlyCommissionInvoice.findMany({ select: { status: true, commissionOwed: true } }),
    ]);

    const kpis = {
      pendingTotal: round2(all.filter((i) => i.status === 'pending').reduce((s, i) => s + i.commissionOwed, 0)),
      paidTotal: round2(all.filter((i) => i.status === 'paid').reduce((s, i) => s + i.commissionOwed, 0)),
      overdueTotal: round2(all.filter((i) => i.status === 'overdue').reduce((s, i) => s + i.commissionOwed, 0)),
      pendingCount: all.filter((i) => i.status === 'pending').length,
      overdueCount: all.filter((i) => i.status === 'overdue').length,
      paidCount: all.filter((i) => i.status === 'paid').length,
    };

    return NextResponse.json({ invoices, kpis });
  } catch {
    return NextResponse.json({ error: 'Erreur lors du chargement des factures.' }, { status: 500 });
  }
}

const generateSchema = monthYearSchema.extend({ hostId: z.string().min(1).max(60).optional() });

export async function POST(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();
  const mutGuard = await mutationGuard(mutationKey('admin-mut', request, admin.id), MUTATIONS_LIMIT_ADMIN);
  if (mutGuard) return mutGuard; // null = autorisé

  try {
    const body: unknown = await request.json();
    const parsed = generateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Mois/année invalide.' }, { status: 400 });
    }
    const { month, year, hostId } = parsed.data;

    const hostIds = hostId ? [hostId] : await findActiveOwnerIds(month, year);
    let created = 0;
    let updated = 0;
    let skipped = 0;

    for (const hid of hostIds) {
      try {
        const settings = await getOrCreateHostSettings(hid);
        const rate = typeof settings.commissionRate === 'number' && settings.commissionRate > 0
          ? settings.commissionRate
          : DEFAULT_HOST_COMMISSION_RATE;
        const totals = await computeHostMonthlyTotals(hid, month, year);

        const existing = await db.monthlyCommissionInvoice.findUnique({
          where: { hostId_month_year: { hostId: hid, month, year } },
        });

        if (existing?.status === 'paid') {
          skipped += 1; // facture réglée → jamais écrasée
          continue;
        }
        if (totals.total <= 0) {
          // Aucune activité : supprime une facture pending vide éventuelle.
          if (existing && existing.status !== 'paid') {
            await db.monthlyCommissionInvoice.delete({ where: { id: existing.id } });
          }
          skipped += 1;
          continue;
        }

        const data = {
          totalOrdersAmount: totals.total,
          commissionRate: rate,
          commissionOwed: round2(totals.total * rate),
          ordersCount: totals.count,
          breakdown: { minibar: totals.minibar, services: totals.services, laundry: totals.laundry },
          dueDate: monthDueDate(month, year),
          status: 'pending' as const,
          paidAt: null,
        };

        if (existing) {
          await db.monthlyCommissionInvoice.update({ where: { id: existing.id }, data });
          updated += 1;
        } else {
          await db.monthlyCommissionInvoice.create({ data: { hostId: hid, month, year, ...data } });
          created += 1;
        }
      } catch {
        skipped += 1;
      }
    }

    await logAudit({
      actor: admin,
      action: 'commission_invoice.generate',
      entityType: 'monthly_commission_invoice',
      details: { month, year, hostId: hostId ?? 'all', created, updated, skipped },
    });

    return NextResponse.json({ ok: true, created, updated, skipped });
  } catch {
    return NextResponse.json({ error: 'Erreur lors de la génération des factures.' }, { status: 500 });
  }
}

const patchStatusSchema = z.object({
  id: z.string().min(1).max(60),
  status: z.enum(['pending', 'paid', 'overdue']),
});

const patchRateSchema = z.object({
  hostId: z.string().min(1).max(60),
  commissionRate: z.number().min(0.01, 'Taux trop bas').max(0.5, 'Taux trop élevé (max 50 %)'),
});

export async function PATCH(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();
  const mutGuard = await mutationGuard(mutationKey('admin-mut', request, admin.id), MUTATIONS_LIMIT_ADMIN);
  if (mutGuard) return mutGuard; // null = autorisé

  try {
    const body: unknown = await request.json();

    // 1) Changement de STATUT d'une facture.
    const asStatus = patchStatusSchema.safeParse(body);
    if (asStatus.success) {
      const { id, status } = asStatus.data;
      const invoice = await db.monthlyCommissionInvoice.findUnique({ where: { id } });
      if (!invoice) return NextResponse.json({ error: 'Facture introuvable.' }, { status: 404 });
      const updated = await db.monthlyCommissionInvoice.update({
        where: { id },
        data: { status, paidAt: status === 'paid' ? new Date() : null },
      });
      await logAudit({ actor: admin, action: 'commission_invoice.status', entityType: 'monthly_commission_invoice', entityId: id, details: { status } });
      return NextResponse.json({ ok: true, invoice: updated });
    }

    // 2) Changement du TAUX de commission d'un hôte.
    const asRate = patchRateSchema.safeParse(body);
    if (asRate.success) {
      const { hostId, commissionRate } = asRate.data;
      await getOrCreateHostSettings(hostId);
      const settings = await db.hostSettings.update({
        where: { userId: hostId },
        data: { commissionRate: round2(commissionRate * 100) / 100 },
      });
      await logAudit({ actor: admin, action: 'commission_invoice.rate', entityType: 'host_settings', entityId: hostId, details: { commissionRate } });
      return NextResponse.json({ ok: true, settings: { commissionRate: settings.commissionRate } });
    }

    return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
  } catch {
    return NextResponse.json({ error: 'Erreur lors de la mise à jour.' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const admin = await requireSuperadmin();
  if (!admin) return adminUnauthorized();
  const mutGuard = await mutationGuard(mutationKey('admin-mut', request, admin.id), MUTATIONS_LIMIT_ADMIN);
  if (mutGuard) return mutGuard; // null = autorisé

  try {
    const id = request.nextUrl.searchParams.get('id');
    if (!id || !/^[A-Za-z0-9_-]{6,60}$/.test(id)) {
      return NextResponse.json({ error: 'Identifiant invalide.' }, { status: 400 });
    }
    const invoice = await db.monthlyCommissionInvoice.findUnique({ where: { id } });
    if (!invoice) return NextResponse.json({ error: 'Facture introuvable.' }, { status: 404 });
    if (invoice.status === 'paid') {
      return NextResponse.json({ error: 'Impossible de supprimer une facture payée.' }, { status: 400 });
    }
    await db.monthlyCommissionInvoice.delete({ where: { id } });
    await logAudit({ actor: admin, action: 'commission_invoice.delete', entityType: 'monthly_commission_invoice', entityId: id });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: 'Erreur lors de la suppression.' }, { status: 500 });
  }
}
