// =============================================================
// /api/s/{token}/media/{file} — ROOMSCAN BOUCLIER V2 (FLUX C, PUBLIC)
//
// Sert les médias d'une session via le LIEN MAGIQUE (sans login) :
//   · ref_{ZONE}.jpg            — bibliothèque de référence du bien
//     (fantôme du check-in) ;
//   · {sessionId}_photo_*.jpg / {sessionId}_video.webm — médias de
//     CETTE session uniquement.
// Le token (uuid non devinable) EST l'autorisation. Le page /s/[token]
// construit aussi les fantômes CHECK-OUT à partir des photos du
// CHECK-IN — servies par le route du token DU CHECK-IN (URL complète).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import {
  isRefFilename,
  isSessionFilename,
  mimeForFilename,
  readShieldFile,
} from '@/lib/shield-storage';

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ token: string; file: string }> },
) {
  const { token, file: rawFile } = await params;
  const filename = decodeURIComponent(rawFile);

  const shieldSession = await db.session.findUnique({
    where: { publicToken: token },
    select: { id: true, propertyId: true },
  });
  if (!shieldSession) return new NextResponse(null, { status: 404 });

  // Garde stricte : bibliothèque du bien OU fichiers de CETTE session.
  const allowed =
    isRefFilename(filename) || isSessionFilename(filename, shieldSession.id);
  if (!allowed) return new NextResponse(null, { status: 400 });

  const data = await readShieldFile(shieldSession.propertyId, filename);
  if (!data) return new NextResponse(null, { status: 404 });

  return new NextResponse(new Uint8Array(data), {
    status: 200,
    headers: {
      'Content-Type': mimeForFilename(filename),
      'Cache-Control': isRefFilename(filename)
        ? 'private, max-age=86400'
        : 'private, no-cache',
    },
  });
}

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
