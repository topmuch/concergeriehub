// =============================================================
// /api/s/[token]/complete — V2 « BOUCLIER » flux C (étape 5 + 7)
// API PUBLIQUE — scellement final de l'état des lieux.
//
// POST { video, cleanerName? } :
//   · TOUTES les pièces du bien doivent avoir une photo (409 sinon)
//   · la vidéo (data:video/…) est obligatoire — traversée continue
//   · le hash SHA-256 est recalculé SERVEUR sur les octets bruts
//     (non falsifiable) puis scellé dans videoHash
//   · statut → TERMINE + completedAt (startedAt = 1re photo)
//   · ÉTAPE 7 : l'hôte reçoit automatiquement l'email « état des
//     lieux scellé » (empreinte SHA-256 + lien Documents) — via
//     l'outbox V1, fire-and-forget : jamais bloquant.
//
// Idempotence refusée : une session TERMINE ne peut être rescellée.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { appOriginFromRequest, sendHostSealedEmail } from '@/lib/v2-emails';
import {
  sha256OfDataUrl,
  validateSessionVideo,
  type ShieldSessionPhotos,
} from '@/lib/v2';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }
  const b = body as { video?: unknown; cleanerName?: unknown };

  const session = await db.session.findUnique({
    where: { publicToken: token },
    select: {
      id: true,
      type: true,
      status: true,
      photos: true,
      cleanerName: true,
      startedAt: true,
      property: {
        select: {
          id: true,
          name: true,
          shieldRooms: true,
          owner: { select: { id: true, email: true } },
        },
      },
    },
  });
  if (!session) return NextResponse.json({ error: 'Séjour introuvable' }, { status: 404 });
  if (session.status === 'TERMINE') {
    return NextResponse.json({ error: 'Cet état des lieux est déjà scellé' }, { status: 409 });
  }
  if (session.status === 'ANNULE') {
    return NextResponse.json({ error: 'Ce séjour a été annulé' }, { status: 409 });
  }

  // Zéro case vide : TOUTES les pièces du bien doivent être photographiées.
  const rooms = Array.isArray(session.property.shieldRooms)
    ? (session.property.shieldRooms as string[])
    : [];
  const photos: ShieldSessionPhotos = {};
  if (session.photos && typeof session.photos === 'object') {
    for (const [k, v] of Object.entries(session.photos as Record<string, unknown>)) {
      if (typeof v === 'string') photos[k] = v;
    }
  }
  const missing = rooms.filter((r) => !photos[r]);
  if (missing.length > 0) {
    return NextResponse.json(
      { error: `Photos manquantes : ${missing.join(', ')}` },
      { status: 409 },
    );
  }

  const videoError = validateSessionVideo(b.video);
  if (videoError || typeof b.video !== 'string') {
    return NextResponse.json({ error: videoError ?? 'Vidéo invalide' }, { status: 400 });
  }

  // Scellement : hash SHA-256 recalculé côté serveur sur les octets bruts.
  const videoHash = await sha256OfDataUrl(b.video);

  const cleanerName =
    typeof b.cleanerName === 'string' && b.cleanerName.trim().length > 0
      ? b.cleanerName.trim().slice(0, 60)
      : session.cleanerName;

  const now = new Date();
  const updated = await db.session.update({
    where: { id: session.id },
    data: {
      photos: photos as unknown as import('@prisma/client').Prisma.InputJsonValue,
      videoData: b.video,
      videoHash,
      ...(cleanerName ? { cleanerName } : {}),
      status: 'TERMINE',
      ...(session.startedAt ? {} : { startedAt: now }),
      completedAt: now,
    },
    select: { id: true, status: true, completedAt: true, videoHash: true },
  });

  // Étape 7 — email automatique à l'hôte (hors transaction scellement :
  // en cas d'erreur inattendue, la réponse du ménager reste 200 OK).
  try {
    await notifyHostSealed(req, {
      sessionId: session.id,
      type: session.type,
      propertyName: session.property.name,
      ownerId: session.property.owner.id,
      ownerEmail: session.property.owner.email,
      propertyId: session.property.id,
      cleanerName,
      completedAt: now,
      photoCount: Object.keys(photos).length,
      videoHash,
    });
  } catch (emailError) {
    console.error('[v2:complete] host sealed email failed (non-blocking):', emailError);
  }

  return NextResponse.json({
    ok: true,
    status: updated.status,
    completedAt: updated.completedAt?.toISOString() ?? null,
    videoHash: updated.videoHash,
  });
}

/**
 * Étape 7 — email automatique à l'hôte au scellement (outbox V1,
 * fire-and-forget : une erreur email ne casse JAMAIS la réponse du
 * ménager). Séparé en fonction pour garder POST lisible.
 */
async function notifyHostSealed(
  req: NextRequest,
  input: {
    sessionId: string;
    type: string;
    propertyName: string;
    ownerId: string;
    ownerEmail: string | null;
    propertyId: string;
    cleanerName: string | null;
    completedAt: Date;
    photoCount: number;
    videoHash: string;
  },
): Promise<void> {
  if (!input.ownerEmail) return;
  await sendHostSealedEmail({
    to: input.ownerEmail,
    origin: appOriginFromRequest(req),
    propertyName: input.propertyName,
    type: input.type === 'CHECKOUT' ? 'CHECKOUT' : 'CHECKIN',
    cleanerName: input.cleanerName,
    completedAt: input.completedAt,
    photoCount: input.photoCount,
    videoHash: input.videoHash,
    userId: input.ownerId,
    propertyId: input.propertyId,
    sessionId: input.sessionId,
  });
}
