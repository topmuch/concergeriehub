// =============================================================
// /api/s/{token}/complete — ROOMSCAN BOUCLIER V2 (FLUX C, PUBLIC)
//
// Clôture de la session cleaner :
//   { photos: { [ZONE]: url }, videoUrl?, videoHash? }
// → statut TERMINE + completedAt. Les URLs sont VÉRIFIÉES : elles
// doivent pointer vers les médias de CETTE session (préfixe exact)
// — le cleaner ne peut pas sceller des fichiers étrangers.
// L'envoi des emails + la génération PDF arrivent à l'étape 3.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;
  if (!(await rateLimit(`shield-v2-complete:${token}`, 12))) {
    return NextResponse.json({ error: 'trop_de_requetes' }, { status: 429 });
  }

  const shieldSession = await db.session.findUnique({
    where: { publicToken: token },
    select: { id: true, status: true },
  });
  if (!shieldSession) return NextResponse.json({ error: 'session_introuvable' }, { status: 404 });
  if (shieldSession.status === 'ANNULE') {
    return NextResponse.json({ error: 'session_annulee' }, { status: 409 });
  }

  let body: { photos?: Record<string, string>; videoUrl?: string; videoHash?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'bad_json' }, { status: 400 });
  }

  const photos = body.photos ?? {};
  const zones = Object.keys(photos);
  if (zones.length === 0) {
    return NextResponse.json({ error: 'aucune_photo' }, { status: 400 });
  }

  // Toutes les URLs doivent appartenir à CETTE session (préfixe exact).
  const prefix = `/api/s/${token}/media/${shieldSession.id}_photo_`;
  for (const zone of zones) {
    const urlValue = photos[zone];
    if (typeof urlValue !== 'string' || !urlValue.startsWith(prefix)) {
      return NextResponse.json({ error: 'url_etrangere', zone }, { status: 400 });
    }
  }

  const data: {
    photos: Record<string, string>;
    status: string;
    completedAt: Date;
    videoUrl?: string;
    videoHash?: string;
  } = {
    photos,
    status: 'TERMINE',
    completedAt: new Date(),
  };
  const videoPrefix = `/api/s/${token}/media/${shieldSession.id}_video`;
  if (typeof body.videoUrl === 'string' && body.videoUrl.startsWith(videoPrefix)) {
    data.videoUrl = body.videoUrl;
  }
  if (typeof body.videoHash === 'string' && /^[a-f0-9]{64}$/i.test(body.videoHash)) {
    data.videoHash = body.videoHash.toUpperCase();
  }

  const updated = await db.session.update({
    where: { id: shieldSession.id },
    data,
    select: { id: true, status: true, completedAt: true },
  });

  return NextResponse.json({ ok: true, session: updated });
}

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
