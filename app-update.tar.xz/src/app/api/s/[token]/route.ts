// =============================================================
// /api/s/[token] — V2 « BOUCLIER » flux C (étape 5)
// API PUBLIQUE du page cleaner mobile — le token EST l'authentification.
//
// PATCH { zone, photo } : sauvegarde progressive d'une photo par pièce.
//   · la pièce doit exister dans le bien (zéro case vide)
//   · startedAt est horodaté à la 1re photo (durée d'intervention)
//   · refaire une photo remplace l'ancienne
//
// Aucune écriture après TERMINE / ANNULE (409).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { validateSessionPhoto, type ShieldSessionPhotos } from '@/lib/v2';

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }
  const b = body as { zone?: unknown; photo?: unknown };
  const zone = typeof b.zone === 'string' ? b.zone.trim().slice(0, 40) : '';
  if (!zone) return NextResponse.json({ error: 'Pièce manquante' }, { status: 400 });

  const session = await db.session.findUnique({
    where: { publicToken: token },
    select: {
      id: true,
      status: true,
      photos: true,
      startedAt: true,
      property: { select: { shieldRooms: true } },
    },
  });
  if (!session) return NextResponse.json({ error: 'Séjour introuvable' }, { status: 404 });
  if (session.status === 'TERMINE') {
    return NextResponse.json({ error: 'Cet état des lieux est déjà scellé' }, { status: 409 });
  }
  if (session.status === 'ANNULE') {
    return NextResponse.json({ error: 'Ce séjour a été annulé' }, { status: 409 });
  }

  const rooms = Array.isArray(session.property.shieldRooms)
    ? (session.property.shieldRooms as string[])
    : [];
  if (!rooms.includes(zone)) {
    return NextResponse.json({ error: 'Pièce inconnue pour ce logement' }, { status: 400 });
  }

  const photoError = validateSessionPhoto(b.photo);
  if (photoError || typeof b.photo !== 'string') {
    return NextResponse.json({ error: photoError ?? 'Photo invalide' }, { status: 400 });
  }

  const photos: ShieldSessionPhotos = {};
  if (session.photos && typeof session.photos === 'object') {
    for (const [k, v] of Object.entries(session.photos as Record<string, unknown>)) {
      if (typeof v === 'string') photos[k] = v;
    }
  }
  photos[zone] = b.photo;

  await db.session.update({
    where: { id: session.id },
    data: {
      photos: photos as unknown as import('@prisma/client').Prisma.InputJsonValue,
      ...(session.startedAt ? {} : { startedAt: new Date() }),
    },
  });

  return NextResponse.json({ ok: true, savedZones: Object.keys(photos).length });
}
