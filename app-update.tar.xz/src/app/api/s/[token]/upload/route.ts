// =============================================================
// /api/s/{token}/upload — ROOMSCAN BOUCLIER V2 (FLUX C, PUBLIC)
//
// Upload des médias du cleaner via le LIEN MAGIQUE /s/[token]
// (sans login). Chaque média est envoyé INDIVIDUELLEMENT dès sa
// capture → si le réseau lâche, un seul média est à renvoyer
// (« upload failure can be retried » du master prompt).
//
// · PHOTO  (JSON { zone, dataUrl }) → {sessionId}_photo_{ZONE}.jpg
//   (dataURL compressé côté client, ≤ 500 Ko — cf. shield-photo.ts)
// · VIDÉO  (multipart/form-data, champ « file ») →
//   {sessionId}_video.webm ; le hash SHA-256 est RECALCULÉ ICI
//   (intégrité non falsifiable) et stocké immédiatement.
//
// Garde : token valide + session non ANNULE + rate limit.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import {
  dataUrlToBuffer,
  saveShieldFile,
  sha256Hex,
} from '@/lib/shield-storage';
import { isValidZoneKey } from '@/lib/shield-v2';

const MAX_VIDEO_BYTES = 80_000_000; // 80 Mo (120 s webm ≈ 25–35 Mo)

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ token: string }> },
) {
  const { token } = await params;
  if (!(await rateLimit(`shield-v2-upload:${token}`, 80))) {
    return NextResponse.json({ error: 'trop_de_requetes' }, { status: 429 });
  }

  const shieldSession = await db.session.findUnique({
    where: { publicToken: token },
    select: {
      id: true,
      status: true,
      type: true,
      propertyId: true,
      property: { select: { shieldRooms: true } },
    },
  });
  if (!shieldSession) return NextResponse.json({ error: 'session_introuvable' }, { status: 404 });
  if (shieldSession.status === 'ANNULE') {
    return NextResponse.json({ error: 'session_annulee' }, { status: 409 });
  }

  const contentType = req.headers.get('content-type') ?? '';

  // ------------------------- PHOTO -------------------------
  if (contentType.includes('application/json')) {
    let body: { zone?: string; dataUrl?: string };
    try {
      body = await req.json();
    } catch {
      return NextResponse.json({ error: 'bad_json' }, { status: 400 });
    }
    const zone = body.zone ?? '';
    if (!isValidZoneKey(zone)) {
      return NextResponse.json({ error: 'zone_invalide' }, { status: 400 });
    }
    // La zone doit faire partie des PIÈCES du bien (onboarding).
    const rooms = Array.isArray(shieldSession.property.shieldRooms)
      ? (shieldSession.property.shieldRooms as string[])
      : [];
    if (!rooms.includes(zone)) {
      return NextResponse.json({ error: 'zone_hors_bien' }, { status: 400 });
    }
    const buffer = dataUrlToBuffer(body.dataUrl ?? '');
    if (!buffer) return NextResponse.json({ error: 'photo_invalide' }, { status: 400 });

    const filename = `${shieldSession.id}_photo_${zone}.jpg`;
    await saveShieldFile(shieldSession.propertyId, filename, buffer);
    return NextResponse.json({
      ok: true,
      url: `/api/s/${token}/media/${filename}`,
      bytes: buffer.length,
    });
  }

  // ------------------------- VIDÉO -------------------------
  if (contentType.includes('multipart/form-data')) {
    const form = await req.formData();
    const file = form.get('file');
    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'fichier_manquant' }, { status: 400 });
    }
    if (file.size > MAX_VIDEO_BYTES) {
      return NextResponse.json({ error: 'video_trop_lourde' }, { status: 413 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const hash = sha256Hex(buffer);
    const filename = `${shieldSession.id}_video.webm`;
    await saveShieldFile(shieldSession.propertyId, filename, buffer);

    const videoUrl = `/api/s/${token}/media/${filename}`;
    // Scellement immédiat : URL + hash conservés même si le cleaner
    // ferme la page avant la fin (reprise possible sans perte).
    await db.session.update({
      where: { id: shieldSession.id },
      data: { videoUrl, videoHash: hash },
    });
    return NextResponse.json({ ok: true, url: videoUrl, hash });
  }

  return NextResponse.json({ error: 'content_type_inattendu' }, { status: 400 });
}

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
