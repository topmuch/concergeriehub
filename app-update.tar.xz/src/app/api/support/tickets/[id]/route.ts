// =============================================================
// /api/support/tickets/[id] — ASSISTANCE EDL (v4.125) — CÔTÉ HÔTE
//
// GET   : détail d'un ticket + fil de messages chronologique.
// POST  : réponse de l'hôte {body} → message 'HOST' + statut
//         repassé à OPEN (le ticket attend de nouveau l'équipe).
// PATCH : l'hôte clôture/réouvre {status: 'RESOLVED' | 'CLOSED'}.
//
// Garde de propriété stricte : le ticket doit appartenir à
// l'utilisateur connecté (sinon 404, pas de fuite d'existence).
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';

const HOST_SETTABLE = ['RESOLVED', 'CLOSED', 'OPEN'] as const;

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

/** Vérifie la propriété du ticket → {ticket} ou {error}. */
async function ownedTicket(ticketId: string, userId: string) {
  return db.edlSupportTicket.findFirst({
    where: { id: ticketId, userId },
    include: {
      messages: { orderBy: { createdAt: 'asc' } },
    },
  });
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) return bad('Non autorisé', 401);

    const { id } = await params;
    const ticket = await ownedTicket(id, userId);
    if (!ticket) return bad('Ticket introuvable.', 404);

    return NextResponse.json(
      {
        ticket: {
          id: ticket.id,
          subject: ticket.subject,
          category: ticket.category,
          priority: ticket.priority,
          status: ticket.status,
          createdAt: ticket.createdAt.toISOString(),
          updatedAt: ticket.updatedAt.toISOString(),
          messages: ticket.messages.map((m) => ({
            id: m.id,
            author: m.author,
            authorName: m.authorName,
            body: m.body,
            createdAt: m.createdAt.toISOString(),
          })),
        },
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    console.error('[support/tickets/:id GET] Error:', error);
    return bad('Impossible de charger le ticket.', 500);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    const userName = (session?.user as { name?: string | null } | undefined)?.name ?? null;
    if (!session?.user || !userId) return bad('Non autorisé', 401);
    if (!(await rateLimit(`support-msg:${userId}`, 30))) {
      return bad('rate_limited', 429, 'Trop de messages envoyés — patientez un instant.');
    }

    const { id } = await params;
    const ticket = await ownedTicket(id, userId);
    if (!ticket) return bad('Ticket introuvable.', 404);
    if (ticket.status === 'CLOSED') {
      return bad('ticket_closed', 409, 'Ce ticket est fermé — ouvrez un nouveau ticket si besoin.');
    }

    const body = (await req.json().catch(() => null)) as { body?: unknown } | null;
    const text = typeof body?.body === 'string' ? body.body.trim() : '';
    if (text.length < 2 || text.length > 5000) {
      return bad('invalid_body', 400, 'Votre message doit contenir entre 2 et 5000 caractères.');
    }

    const [, updated] = await db.$transaction([
      db.edlSupportMessage.create({
        data: {
          ticketId: ticket.id,
          author: 'HOST',
          authorName: userName ?? ticket.userName,
          body: text,
        },
      }),
      db.edlSupportTicket.update({
        where: { id: ticket.id },
        data: { status: 'OPEN' },
      }),
    ]);

    return NextResponse.json({ id: ticket.id, status: updated.status }, { status: 201 });
  } catch (error) {
    console.error('[support/tickets/:id POST] Error:', error);
    return bad('Impossible d’envoyer le message.', 500);
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) return bad('Non autorisé', 401);

    const { id } = await params;
    const ticket = await ownedTicket(id, userId);
    if (!ticket) return bad('Ticket introuvable.', 404);

    const body = (await req.json().catch(() => null)) as { status?: unknown } | null;
    const status = typeof body?.status === 'string' ? body.status : '';
    if (!(HOST_SETTABLE as readonly string[]).includes(status)) {
      return bad('invalid_status', 400, 'Statut non autorisé.');
    }

    const updated = await db.edlSupportTicket.update({
      where: { id: ticket.id },
      data: { status },
      select: { id: true, status: true },
    });
    return NextResponse.json(updated);
  } catch (error) {
    console.error('[support/tickets/:id PATCH] Error:', error);
    return bad('Impossible de mettre à jour le ticket.', 500);
  }
}
