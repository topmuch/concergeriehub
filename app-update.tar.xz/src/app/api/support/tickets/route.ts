// =============================================================
// /api/support/tickets — ASSISTANCE EDL (v4.125) — CÔTÉ HÔTE
//
// GET  : liste des tickets de l'utilisateur connecté (avec le
//        nombre de messages + dernier message, pour l'aperçu).
// POST : création d'un ticket {subject, category, priority, body}
//        → ticket + 1er message (author 'HOST').
//
// Garde : session obligatoire ; l'entitlement EDL n'est PAS requis
// (un client en attente d'aide facturation doit pouvoir écrire).
// Rate limit : 10 créations / 5 min par utilisateur.
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';

const CATEGORIES = ['GENERAL', 'TECHNIQUE', 'FACTURATION', 'SEJOUR', 'AUTRE'] as const;
const PRIORITIES = ['LOW', 'NORMAL', 'HIGH', 'URGENT'] as const;

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return bad('Non autorisé', 401);
    }

    const tickets = await db.edlSupportTicket.findMany({
      where: { userId },
      orderBy: { updatedAt: 'desc' },
      take: 100,
      include: {
        messages: {
          orderBy: { createdAt: 'asc' },
          select: { body: true, author: true, createdAt: true },
        },
      },
    });

    return NextResponse.json(
      {
        tickets: tickets.map((t) => {
          const last = t.messages[t.messages.length - 1] ?? null;
          return {
            id: t.id,
            subject: t.subject,
            category: t.category,
            priority: t.priority,
            status: t.status,
            createdAt: t.createdAt.toISOString(),
            updatedAt: t.updatedAt.toISOString(),
            messagesCount: t.messages.length,
            lastMessage: last
              ? { author: last.author, body: last.body, createdAt: last.createdAt.toISOString() }
              : null,
          };
        }),
      },
      { headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    console.error('[support/tickets GET] Error:', error);
    return bad('Impossible de charger vos tickets.', 500);
  }
}

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    const userName = (session?.user as { name?: string | null } | undefined)?.name ?? null;
    const userEmail = (session?.user as { email?: string | null } | undefined)?.email ?? null;
    if (!session?.user || !userId) {
      return bad('Non autorisé', 401);
    }
    if (!(await rateLimit(`support-new:${userId}`, 10))) {
      return bad('rate_limited', 429, 'Trop de tickets créés — patientez quelques minutes.');
    }

    const body = (await req.json().catch(() => null)) as {
      subject?: unknown;
      category?: unknown;
      priority?: unknown;
      body?: unknown;
    } | null;

    const subject = typeof body?.subject === 'string' ? body.subject.trim() : '';
    const firstMessage = typeof body?.body === 'string' ? body.body.trim() : '';
    const category =
      typeof body?.category === 'string' && (CATEGORIES as readonly string[]).includes(body.category)
        ? body.category
        : 'GENERAL';
    const priority =
      typeof body?.priority === 'string' && (PRIORITIES as readonly string[]).includes(body.priority)
        ? body.priority
        : 'NORMAL';

    if (subject.length < 4 || subject.length > 160) {
      return bad('invalid_subject', 400, 'Le sujet doit contenir entre 4 et 160 caractères.');
    }
    if (firstMessage.length < 10 || firstMessage.length > 5000) {
      return bad('invalid_body', 400, 'Décrivez votre problème en 10 caractères minimum (5000 max).');
    }

    const ticket = await db.edlSupportTicket.create({
      data: {
        userId,
        userName: userName ?? userEmail ?? 'Hôte',
        userEmail: userEmail ?? '',
        subject,
        category,
        priority,
        status: 'OPEN',
        messages: {
          create: {
            author: 'HOST',
            authorName: userName ?? userEmail ?? 'Hôte',
            body: firstMessage,
          },
        },
      },
      select: { id: true },
    });

    return NextResponse.json({ id: ticket.id }, { status: 201 });
  } catch (error) {
    console.error('[support/tickets POST] Error:', error);
    return bad('Impossible de créer le ticket.', 500);
  }
}
