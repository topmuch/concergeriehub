// =============================================================
// GET /api/airbnb/dashboard-kpis  —  Task 3-a « KPI lisibles »
// Remplace l'ancien shape « SAPHIR LUXE » (minibar/stay/calendar…)
// par 4 indicateurs EXPLICITES + les prochains événements :
//  - checkinsDone/checkinsTotal   : « 2/2 Check-ins terminés » (jamais
//                                   un pourcentage nu) — semaine civile
//  - checkoutsDone/checkoutsTotal : idem pour les départs
//  - protectedRevenueEur          : cautions sécurisées = séjours
//                                   terminés (90 j) SANS dégât × 500 €
//  - minutesSaved                 : EDL complétés ce mois × 45 min
//  - damagesCount                 : dégâts non résolus (alertes actives)
//  - upcomingEvents               : 3 prochains événements (check-in /
//                                   check-out / ménage) + badge litige
// Même logique d'accès que /api/airbnb/dashboard-stats : scope un bien
// ou agrégat 'all', ids TOUJOURS issus de resolveUserProperties.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { resolveUserProperties } from '@/lib/b2b-server';

// TODO: remplacer par le vrai montant de caution par bien quand le champ existera (Property.depositEur)
const CAUTION_ESTIMEE_EUR = 500;
// TODO: durée moyenne d'un EDL papier mesurée à ajuster après retour terrain
const MINUTES_PAR_EDL = 45;

const MS_PER_DAY = 86_400_000;

/** Lundi 00:00 de la semaine civile courante (heure locale serveur). */
function startOfWeek(now: Date): Date {
  const d = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const shift = (d.getDay() + 6) % 7; // dim. → 6, lun. → 0
  d.setDate(d.getDate() - shift);
  return d;
}

/** Une inspection comporte-t-elle des dégâts (colonnes de statut ou résumé) ? */
const DAMAGED_OR = [
  { damages: { not: null } },
  { entranceStatus: 'damaged' },
  { kitchenStatus: 'damaged' },
  { livingRoomStatus: 'damaged' },
  { bedroomsStatus: 'damaged' },
  { bathroomStatus: 'damaged' },
];

interface UpcomingEvent {
  id: string;
  kind: 'checkin' | 'checkout' | 'housekeeping';
  title: string;
  propertyName: string;
  at: string;
  bookingId: string | null;
  hasDispute: boolean;
}

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const userId = (session.user as { id: string }).id;

    const properties = await resolveUserProperties(userId);
    if (properties.length === 0) {
      return NextResponse.json({
        scope: 'all' as const,
        property: null,
        checkinsDone: 0,
        checkinsTotal: 0,
        checkoutsDone: 0,
        checkoutsTotal: 0,
        protectedRevenueEur: 0,
        protectedStaysCount: 0,
        minutesSaved: 0,
        inspectionsThisMonth: 0,
        damagesCount: 0,
        upcomingEvents: [] as UpcomingEvent[],
      });
    }

    const { searchParams } = new URL(req.url);
    const requestedId = searchParams.get('propertyId');
    const scopeAll = !requestedId || requestedId === 'all';
    const target = scopeAll ? null : properties.find((p) => p.id === requestedId) ?? properties[0];
    const targetIds = target ? [target.id] : properties.map((p) => p.id);
    const propertyNameOf = (id: string) => properties.find((p) => p.id === id)?.name ?? 'Bien';

    const now = new Date();
    const weekStart = startOfWeek(now);
    const weekEnd = new Date(weekStart.getTime() + 7 * MS_PER_DAY);
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOf90d = new Date(now.getTime() - 90 * MS_PER_DAY);

    const [
      weekBookings,
      completedStays90d,
      damagedInspections,
      pendingDamaged,
      inspectionsThisMonth,
      upcomingBookings,
      upcomingHousekeeping,
    ] = await Promise.all([
      // ── Séjours de la semaine (arrivées ET départs, hors annulées) ──
      db.booking.findMany({
        where: {
          propertyId: { in: targetIds },
          status: { not: 'CANCELLED' },
          OR: [
            { checkIn: { gte: weekStart, lt: weekEnd } },
            { checkOut: { gte: weekStart, lt: weekEnd } },
          ],
        },
        select: { checkIn: true, checkOut: true },
      }),
      // ── Séjours terminés sur 90 j (base « cautions sécurisées ») ──
      db.booking.findMany({
        where: {
          propertyId: { in: targetIds },
          status: { not: 'CANCELLED' },
          checkOut: { gte: startOf90d, lt: now },
        },
        select: { id: true },
      }),
      // ── Inspections AVEC dégâts (exclues des cautions sécurisées) ──
      db.checkOutInspection.findMany({
        where: { propertyId: { in: targetIds }, OR: DAMAGED_OR },
        select: { bookingId: true },
      }),
      // ── Dégâts NON résolus (badge critique des cartes / cloche) ──
      db.checkOutInspection.findMany({
        where: { propertyId: { in: targetIds }, status: 'pending', OR: DAMAGED_OR },
        select: { bookingId: true },
      }),
      // ── EDL complétés ce mois (check-in + check-out confondus) ──
      db.checkOutInspection.count({
        where: { propertyId: { in: targetIds }, signedAt: { gte: startOfMonth } },
      }),
      // ── Prochains check-ins / check-outs (fenêtre 60 j) ──
      db.booking.findMany({
        where: {
          propertyId: { in: targetIds },
          status: { not: 'CANCELLED' },
          OR: [{ checkIn: { gt: now, lte: new Date(now.getTime() + 60 * MS_PER_DAY) } }, { checkOut: { gt: now } }],
        },
        orderBy: { checkIn: 'asc' },
        take: 20,
        select: { id: true, guestName: true, checkIn: true, checkOut: true, propertyId: true },
      }),
      // ── Ménages planifiés à venir ──
      db.housekeepingTask.findMany({
        where: {
          propertyId: { in: targetIds },
          scheduledAt: { gt: now },
          status: { in: ['PENDING', 'IN_PROGRESS'] },
        },
        orderBy: { scheduledAt: 'asc' },
        take: 6,
        select: { id: true, scheduledAt: true, propertyId: true, bookingId: true },
      }),
    ]);

    // ----- Ratios check-in / check-out de la semaine (jamais un %) -----
    let checkinsDone = 0, checkinsTotal = 0, checkoutsDone = 0, checkoutsTotal = 0;
    for (const b of weekBookings) {
      if (b.checkIn >= weekStart && b.checkIn < weekEnd) {
        checkinsTotal += 1;
        if (b.checkIn <= now) checkinsDone += 1;
      }
      if (b.checkOut >= weekStart && b.checkOut < weekEnd) {
        checkoutsTotal += 1;
        if (b.checkOut <= now) checkoutsDone += 1;
      }
    }

    // ----- Revenus protégés : séjours terminés SANS dégât × caution estimée -----
    const damagedBookingIds = new Set(
      damagedInspections.map((i) => i.bookingId).filter((id): id is string => Boolean(id)),
    );
    const protectedStaysCount = completedStays90d.filter((b) => !damagedBookingIds.has(b.id)).length;
    const protectedRevenueEur = protectedStaysCount * CAUTION_ESTIMEE_EUR;

    // ----- Temps gagné : EDL digitaux du mois × 45 min -----
    const minutesSaved = inspectionsThisMonth * MINUTES_PAR_EDL;

    // ----- Dégâts non résolus (alertes critiques actives) -----
    const damagesCount = pendingDamaged.length;

    // ----- 3 prochains événements (check-in / check-out / ménage) -----
    const pendingDamagedBookingIds = new Set(
      pendingDamaged.map((i) => i.bookingId).filter((id): id is string => Boolean(id)),
    );
    const events: UpcomingEvent[] = [];
    for (const b of upcomingBookings) {
      const hasDispute = pendingDamagedBookingIds.has(b.id);
      if (b.checkIn > now) {
        events.push({
          id: `${b.id}-in`,
          kind: 'checkin',
          title: `Check-in de ${b.guestName}`,
          propertyName: propertyNameOf(b.propertyId),
          at: b.checkIn.toISOString(),
          bookingId: b.id,
          hasDispute,
        });
      }
      if (b.checkOut > now) {
        events.push({
          id: `${b.id}-out`,
          kind: 'checkout',
          title: `Check-out de ${b.guestName}`,
          propertyName: propertyNameOf(b.propertyId),
          at: b.checkOut.toISOString(),
          bookingId: b.id,
          hasDispute,
        });
      }
    }
    for (const t of upcomingHousekeeping) {
      events.push({
        id: `hk-${t.id}`,
        kind: 'housekeeping',
        title: 'Ménage à prévoir',
        propertyName: propertyNameOf(t.propertyId),
        at: t.scheduledAt.toISOString(),
        bookingId: t.bookingId,
        hasDispute: t.bookingId ? pendingDamagedBookingIds.has(t.bookingId) : false,
      });
    }
    const upcomingEvents = events
      .sort((a, b) => a.at.localeCompare(b.at))
      .slice(0, 3);

    return NextResponse.json({
      scope: target ? ('single' as const) : ('all' as const),
      property: target ? { id: target.id, name: target.name } : null,
      checkinsDone,
      checkinsTotal,
      checkoutsDone,
      checkoutsTotal,
      protectedRevenueEur,
      protectedStaysCount,
      minutesSaved,
      inspectionsThisMonth,
      damagesCount,
      upcomingEvents,
    });
  } catch (error) {
    console.error('[airbnb/dashboard-kpis GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
