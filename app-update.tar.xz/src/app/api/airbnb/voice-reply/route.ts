import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { writeFile, mkdir } from 'fs/promises';
import { join, basename } from 'path';
import { db } from '@/lib/db';
import { authOptions } from '@/lib/auth';
import { canAccessProperty } from '@/lib/b2b-server';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { captureError } from '@/lib/error-monitor';
import crypto from 'crypto';

// =============================================================
// RÉPONSE VOCALE DE L'HÔTE — POST /api/airbnb/voice-reply
//
// Le propriétaire répond par message vocal enregistré à un message
// de son invité. Le vocal est enregistré dans la MÊME table
// VoiceMessage avec senderType='HOST' :
//   → il apparaît dans le guidebook (/view) via GET /api/public/qr-voice
//     (liste déjà publique) et dans le Hub Invité via la nouvelle route
//     GET /api/public/hub/[slug]/voice-replies.
//
// Sécurité : session NextAuth + canAccessProperty (anti-IDOR) ;
// anti-abus mutationGuard (20 réponses/min/hôte) ; allowlist extensions
// + magic numbers audio ; 500 Ko max ; nommage serveur ; never-throw.
// =============================================================

const UPLOAD_DIR = join(process.cwd(), 'data', 'uploads', 'voice');
const MAX_FILE_SIZE_KB = 500;
const MAX_DURATION_SEC = 60;

const ALLOWED_AUDIO_EXT = new Set(['webm', 'ogg', 'mp3', 'm4a', 'wav']);

/** Magic numbers audio — l'extension CLIENT n'est JAMAIS de confiance. */
function sniffAudioExt(bytes: Uint8Array): string | null {
  const b = bytes;
  const ascii = (start: number, text: string) =>
    b.length >= start + text.length &&
    String.fromCharCode(...b.slice(start, start + text.length)) === text;
  // WebM/Matroska (EBML)
  if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return 'webm';
  // OGG
  if (ascii(0, 'OggS')) return 'ogg';
  // MP3 (ID3 tag ou frame sync MPEG)
  if (ascii(0, 'ID3')) return 'mp3';
  if (b[0] === 0xff && (b[1] & 0xe0) === 0xe0) return 'mp3';
  // WAV (RIFF....WAVE)
  if (ascii(0, 'RIFF') && ascii(8, 'WAVE')) return 'wav';
  // MP4/M4A — 'ftyp' à l'offset 4
  if (ascii(4, 'ftyp')) return 'm4a';
  return null;
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;

    const formData = await req.formData().catch(() => null);
    if (!formData) {
      return NextResponse.json({ error: 'Formulaire invalide.' }, { status: 400 });
    }
    const audio = formData.get('audio');
    const voiceMessageId = String(formData.get('voiceMessageId') ?? '').trim();

    if (!audio || !(audio instanceof File)) {
      return NextResponse.json({ error: 'Fichier audio requis.' }, { status: 400 });
    }
    if (audio.size === 0) {
      return NextResponse.json({ error: 'Enregistrement vide.' }, { status: 400 });
    }
    if (!audio.type.startsWith('audio/')) {
      return NextResponse.json({ error: 'Format audio uniquement.' }, { status: 400 });
    }
    const fileSizeKb = Math.round(audio.size / 1024);
    if (fileSizeKb > MAX_FILE_SIZE_KB) {
      return NextResponse.json(
        { error: `Fichier trop volumineux (max ${MAX_FILE_SIZE_KB} Ko).` },
        { status: 400 },
      );
    }
    const durationSec = parseInt(String(formData.get('durationSec') ?? ''), 10) || 0;
    if (durationSec > MAX_DURATION_SEC) {
      return NextResponse.json({ error: `Max ${MAX_DURATION_SEC} secondes.` }, { status: 400 });
    }

    // ── Message d'origine : propriété cible (validée, jamais cru côté client) ──
    const origin = voiceMessageId
      ? await db.voiceMessage.findUnique({
          where: { id: voiceMessageId },
          select: { propertyId: true },
        })
      : null;
    if (voiceMessageId && !origin) {
      return NextResponse.json({ error: 'Message vocal introuvable.' }, { status: 404 });
    }

    let propertyId: string | null = origin?.propertyId ?? null;
    if (!propertyId) {
      // Fallback : propertyId passé directement (réponse générale).
      const direct = String(formData.get('propertyId') ?? '').trim();
      if (direct && (await canAccessProperty(userId, direct))) propertyId = direct;
    }
    if (!propertyId) {
      return NextResponse.json({ error: 'Bien cible manquant.' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ error: 'Accès refusé.' }, { status: 403 });
    }

    // ── Validation binaire : magic numbers OBLIGATOIRES ──
    const bytes = new Uint8Array(await audio.arrayBuffer());
    const sniffed = sniffAudioExt(bytes);
    if (!sniffed || !ALLOWED_AUDIO_EXT.has(sniffed)) {
      return NextResponse.json(
        { error: 'Format audio non supporté (webm, ogg, mp3, m4a ou wav).' },
        { status: 400 },
      );
    }

    // ── Écriture fichier (nommage serveur, répertoire persistant) ──
    const filename = `${propertyId}-${crypto.randomBytes(8).toString('hex')}.${sniffed}`;
    await mkdir(UPLOAD_DIR, { recursive: true });
    await writeFile(join(UPLOAD_DIR, basename(filename)), bytes);

    // ── Enregistrement DB : senderType='HOST' ──
    const owner = await db.user.findUnique({
      where: { id: userId },
      select: { fullName: true },
    });
    const hostName = (owner?.fullName || 'Votre hôte').trim().slice(0, 50);
    const voiceMsg = await db.voiceMessage.create({
      data: {
        propertyId,
        senderName: hostName,
        senderType: 'HOST',
        audioUrl: `/uploads/voice/${filename}`,
        durationSec: Math.min(Math.max(durationSec, 0), MAX_DURATION_SEC),
        fileSizeKb,
      },
    });

    return NextResponse.json(
      { ok: true, id: voiceMsg.id, audioUrl: voiceMsg.audioUrl },
      { status: 201 },
    );
  } catch (error) {
    await captureError('voice-reply.post', error, undefined, req);
    return NextResponse.json(
      { error: "Impossible d'envoyer la réponse vocale. Réessayez." },
      { status: 500 },
    );
  }
}
