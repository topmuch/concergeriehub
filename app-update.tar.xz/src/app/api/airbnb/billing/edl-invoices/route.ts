// =============================================================
// /api/airbnb/billing/edl-invoices — FACTURES D'ABONNEMENT EDL (v5.3)
//
// GET : liste des factures EdlInvoice de l'utilisateur (session
// obligatoire). LAZY-ISSUE : si l'utilisateur n'a AUCUNE facture mais
// possède un abonnement InspectionSubscription actif OU un achat
// EdlPurchase paid/activated → sa facture PAYÉE est créée à la volée
// (même format RS-ANNÉE-0001). C'est ce qui garantit que les comptes
// créés avant la facturation voient immédiatement LEUR facture.
//
// Réponse : { invoices: [{ id, invoiceNumber, amountEur, planLabel,
// status, issuedAt, paidAt, pdfUrl }] }
// Anti-IDOR : uniquement les factures rattachées à l'utilisateur.
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { ensureUserEdlInvoices } from '@/lib/edl-fulfillment';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }

    // Lazy-issue : crée la facture manquante si l'utilisateur est éligible.
    await ensureUserEdlInvoices(userId);

    const invoices = await db.edlInvoice.findMany({
      where: { userId },
      orderBy: [{ issuedAt: 'desc' }, { createdAt: 'desc' }],
      select: {
        id: true,
        invoiceNumber: true,
        amountEur: true,
        planLabel: true,
        status: true,
        issuedAt: true,
        paidAt: true,
      },
    });

    return NextResponse.json({
      invoices: invoices.map((i) => ({
        id: i.id,
        invoiceNumber: i.invoiceNumber,
        amountEur: i.amountEur,
        planLabel: i.planLabel,
        status: i.status,
        issuedAt: i.issuedAt.toISOString(),
        paidAt: i.paidAt ? i.paidAt.toISOString() : null,
        pdfUrl: `/api/airbnb/billing/edl-invoices/${i.id}/pdf`,
      })),
    });
  } catch (error) {
    console.error('[airbnb/billing/edl-invoices GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
