// =============================================================
// /api/airbnb/billing/edl-invoices/[id]/pdf — PDF DE FACTURE (v5.3)
//
// GET : rend le PDF de la facture (renderEdlInvoicePdf — en-tête
// bleu nuit, badge PAYÉ, TVA art. 293 B). Session obligatoire ;
// la facture doit appartenir à l'utilisateur (directement, ou via
// l'achat EdlPurchase lié) — sinon 404 sans divulgation.
// Réponse : application/octet-stream (téléchargement),
// filename « facture-RS-2025-0001.pdf » (RFC 5987).
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { renderEdlInvoicePdf } from '@/lib/edl-invoice-pdf';
import { pdfContentDisposition } from '@/lib/inspection-merge-pdf';

export const dynamic = 'force-dynamic';

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }

    const { id } = await params;
    const cleanId = id.trim().slice(0, 64);

    const invoice = await db.edlInvoice.findUnique({
      where: { id: cleanId },
      include: { purchase: { select: { userId: true } } },
    });
    // Anti-IDOR : propriétaire direct OU via l'achat lié — 404 sinon
    // (jamais 403, pour ne pas révéler l'existence d'une facture étrangère).
    const ownerId = invoice?.userId ?? invoice?.purchase?.userId ?? null;
    if (!invoice || !ownerId || ownerId !== userId) {
      return NextResponse.json({ error: 'Facture introuvable.' }, { status: 404 });
    }

    const buffer = await renderEdlInvoicePdf({
      invoiceNumber: invoice.invoiceNumber,
      buyerName: invoice.buyerName,
      buyerEmail: invoice.buyerEmail,
      planLabel: invoice.planLabel,
      amountEur: invoice.amountEur,
      currency: invoice.currency,
      status: invoice.status,
      issuedAt: invoice.issuedAt,
      paidAt: invoice.paidAt,
    });

    return new Response(new Uint8Array(buffer), {
      status: 200,
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': pdfContentDisposition(`facture-${invoice.invoiceNumber}.pdf`, 'attachment'),
        'Cache-Control': 'private, no-store',
      },
    });
  } catch (error) {
    console.error('[airbnb/billing/edl-invoices/pdf GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
