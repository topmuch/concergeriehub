// =============================================================
// /api/airbnb/documents — v5.3 « DOCUMENTS » (Task 3-b)
//
// GET : bibliothèque unifiée des états des lieux de l'utilisateur
// connecté, en fusionnant les DEUX sources existantes :
//   1. Module EDL standalone (model Inspection, possession via
//      InspectionSubscription.userId) — types ENTREE | SORTIE,
//      statuts PENDING | IN_PROGRESS | COMPLETED ;
//   2. Hub (model CheckOutInspection, possession via
//      Property.userId / équipe acceptée) — types checkin |
//      checkout, statuts pending | reviewed | resolved.
//
// Réponse : { documents: [{ id, source, title, propertyName,
//   guestName, kind, statusLabel, status, createdAt, pdfUrl,
//   publicPageUrl, pdfSizeBytes, linked, complete, hasLitige }] }
// Tri : createdAt desc (les deux sources fusionnées puis triées).
//
// • complete = « Complet (Entrée + Sortie) » :
//   - edl  : l'inspection a linkedInspectionId (sortie → entrée) OU
//     est référencée par linkedBy (entrée → sortie) — le lien
//     existe des deux côtés (onDelete: SetNull préserve l'intégrité) ;
//   - hub  : un checkin ET un checkout existent pour le même bookingId.
// • hasLitige : damages non vide (hub) — l'EDL standalone n'a pas
//   de champ damages textuel (les dégradations passent par les
//   items de pièces) → toujours false côté edl.
// • pdfSizeBytes : poids du dernier PDF généré (null = « — » côté
//   UI, le poids se remplit à la 1re génération — comportement voulu,
//   pas de fetch HEAD).
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { resolveUserProperties } from '@/lib/b2b-server';

const TAKE = 200;

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }

    // ── Source 1 : EDL standalone (module « États des Lieux ») ──
    // Possession via l'abonnement EDL (anti IDOR) — pas de 403 si
    // l'abonnement n'existe pas : la liste ressort simplement vide.
    const edlRows = await db.inspection.findMany({
      where: { subscription: { userId } },
      orderBy: { createdAt: 'desc' },
      take: TAKE,
      select: {
        id: true,
        propertyName: true,
        guestName: true,
        type: true,
        status: true,
        createdAt: true,
        publicToken: true,
        linkedInspectionId: true,
        pdfSizeBytes: true,
        linkedBy: { select: { id: true } },
      },
    });

    // ── Source 2 : Hub (CheckOutInspection par bien accessible) ──
    const properties = await resolveUserProperties(userId);
    const hubRows =
      properties.length > 0
        ? await db.checkOutInspection.findMany({
            where: { propertyId: { in: properties.map((p) => p.id) } },
            orderBy: { createdAt: 'desc' },
            take: TAKE,
            select: {
              id: true,
              type: true,
              status: true,
              createdAt: true,
              guestName: true,
              damages: true,
              bookingId: true,
              publicToken: true,
              propertyId: true,
            },
          })
        : [];

    // ── Complétude Hub : checkin + checkout du même booking ──
    // Clé bookingId → ensemble des types présents (1 requête, 0 N+1).
    const typesByBooking = new Map<string, Set<string>>();
    for (const h of hubRows) {
      if (!h.bookingId) continue;
      const set = typesByBooking.get(h.bookingId) ?? new Set<string>();
      set.add(h.type);
      typesByBooking.set(h.bookingId, set);
    }

    const nameByProperty = new Map(properties.map((p) => [p.id, p.name]));

    // ── Libellés métier (FR) ──
    const edlStatusLabel: Record<string, string> = {
      PENDING: 'Planifié',
      IN_PROGRESS: 'En cours',
      COMPLETED: 'Terminé',
    };
    const hubStatusLabel: Record<string, string> = {
      pending: 'À traiter',
      reviewed: 'Consultée',
      resolved: 'Traitée',
    };

    const documents: Array<{
      id: string;
      source: 'edl' | 'hub';
      title: string;
      propertyName: string;
      guestName: string;
      kind: 'ENTREE' | 'SORTIE';
      statusLabel: string;
      status: string;
      createdAt: string;
      pdfUrl: string;
      publicPageUrl: string;
      pdfSizeBytes: number | null;
      linked: boolean;
      complete: boolean;
      hasLitige: boolean;
    }> = [];

    for (const i of edlRows) {
      // Lien entrée <-> sortie : la SORTIE porte linkedInspectionId,
      // l'ENTRÉE est référencée par linkedBy — les deux sens prouvent
      // que la paire existe (complète).
      const linked = Boolean(i.linkedInspectionId) || i.linkedBy.length > 0;
      documents.push({
        id: i.id,
        source: 'edl',
        title: `${i.propertyName} — ${i.guestName}`,
        propertyName: i.propertyName,
        guestName: i.guestName,
        kind: i.type === 'SORTIE' ? 'SORTIE' : 'ENTREE',
        statusLabel: edlStatusLabel[i.status] ?? i.status,
        status: i.status,
        createdAt: i.createdAt.toISOString(),
        pdfUrl: `/api/inspection/pdf/${i.publicToken}`,
        publicPageUrl: `/i/${i.publicToken}`,
        pdfSizeBytes: i.pdfSizeBytes ?? null,
        linked,
        complete: linked,
        // Le module standalone n'expose pas de champ « damages » texte.
        hasLitige: false,
      });
    }

    for (const h of hubRows) {
      const types = h.bookingId ? typesByBooking.get(h.bookingId) : undefined;
      // Complet : les DEUX types du même booking existent (le doc
      // courant étant l'un des deux, l'opposé doit être présent).
      const complete = Boolean(h.bookingId && types && types.size === 2);
      documents.push({
        id: h.id,
        source: 'hub',
        title: `${nameByProperty.get(h.propertyId) ?? 'Logement'} — ${h.guestName}`,
        propertyName: nameByProperty.get(h.propertyId) ?? 'Logement',
        guestName: h.guestName,
        kind: h.type === 'checkin' ? 'ENTREE' : 'SORTIE',
        statusLabel: hubStatusLabel[h.status] ?? h.status,
        status: h.status,
        createdAt: h.createdAt.toISOString(),
        pdfUrl: `/api/public/inspection/${h.publicToken}/pdf`,
        publicPageUrl: `/public/inspection/${h.publicToken}`,
        // Le PDF Hub est généré à la demande → poids inconnu ici (« — »).
        pdfSizeBytes: null,
        linked: complete,
        complete,
        // Litige : résumé de dégâts renseigné (texte non vide).
        hasLitige: Boolean(h.damages && h.damages.trim().length > 0),
      });
    }

    // ── Tri unifié : plus récents d'abord ──
    documents.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));

    return NextResponse.json({ documents });
  } catch (error) {
    console.error('[airbnb/documents GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
