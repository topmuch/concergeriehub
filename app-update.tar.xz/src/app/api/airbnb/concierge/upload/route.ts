import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { writeFile, mkdir } from 'fs/promises';
import { join, basename } from 'path';
import { db } from '@/lib/db';
import { authOptions } from '@/lib/auth';
import { canAccessProperty } from '@/lib/b2b-server';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { captureError } from '@/lib/error-monitor';
import crypto from 'crypto';

// =============================================================
// UPLOAD PHOTOS CONCIERGERIE — POST /api/airbnb/concierge/upload
//   ?propertyId=…  (multipart, champ « file »)
//
// Photos du Guide des Appareils + des Pannes courantes (SOS).
// Écrit dans <cwd>/data/uploads/concierge (volume persistant Docker
// /app/data — public/ n'est PAS servi en build standalone) et lu par
// la route GET /api/uploads/concierge/[file] (déjà en production).
//
// ⚠️ ROUTE PERDUE DEUX FOIS par le pipeline de déploiement tar
// (worklog Task 20 puis Task 25) → POST-DÉPLOIEMENT : vérifier que
// ce fichier existe dans le build servi (curl -I POST → 401/403/400
// et NON 404).
//
// Sécurité : session NextAuth + canAccessProperty (anti-IDOR) ;
// mutationGuard (10 uploads/min/hôte) ; 500 Ko max ; magic numbers
// PNG/JPEG/WebP/GIF (l'extension CLIENT n'est jamais de confiance) ;
// nommage serveur (propertyId + random hex) ; never-throw.
// =============================================================

const UPLOAD_DIR = join(process.cwd(), 'data', 'uploads', 'concierge');
const MAX_BYTES = 500 * 1024;

/** Magic numbers images — retourne l'extension canonique ou null. */
function sniffImageExt(bytes: Uint8Array): string | null {
  const b = bytes;
  const ascii = (start: number, text: string) =>
    b.length >= start + text.length &&
    String.fromCharCode(...b.slice(start, start + text.length)) === text;
  // PNG
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  // JPEG
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
  // GIF87a / GIF89a
  if (ascii(0, 'GIF8')) return 'gif';
  // WebP (RIFF....WEBP)
  if (ascii(0, 'RIFF') && ascii(8, 'WEBP')) return 'webp';
  return null;
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    // Anti-abus : 10 uploads/min par hôte.
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;

    const { searchParams } = new URL(req.url);
    const propertyId = (searchParams.get('propertyId') || '').trim();
    if (!propertyId) {
      return NextResponse.json({ error: 'Bien manquant' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 });
    }

    const formData = await req.formData().catch(() => null);
    const file = formData?.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });
    }
    if (file.size === 0) {
      return NextResponse.json({ error: 'Fichier vide.' }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: 'Image trop lourde (500 Ko max).' }, { status: 400 });
    }

    // Validation binaire : magic numbers OBLIGATOIRES (pas de confiance
    // dans le MIME client, ni dans l'extension).
    const bytes = new Uint8Array(await file.arrayBuffer());
    const ext = sniffImageExt(bytes);
    if (!ext) {
      return NextResponse.json(
        { error: 'Format non supporté (PNG, JPEG, WebP ou GIF attendu).' },
        { status: 400 },
      );
    }

    // Écriture : nommage serveur + répertoire persistant (volume Docker).
    const filename = `${propertyId}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
    await mkdir(UPLOAD_DIR, { recursive: true });
    await writeFile(join(UPLOAD_DIR, basename(filename)), bytes);

    return NextResponse.json({ ok: true, url: `/api/uploads/concierge/${filename}` });
  } catch (error) {
    await captureError('concierge.upload', error, undefined, req);
    return NextResponse.json(
      { error: "Impossible de téléverser cette image. Réessayez." },
      { status: 500 },
    );
  }
}
