import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { rateLimit } from '@/lib/rate-limit';
import { canAccessProperty } from '@/lib/b2b-server';
import { mkdir, writeFile } from 'fs/promises';
import { join, basename } from 'path';
import crypto from 'crypto';

// =============================================================
// UPLOAD PHOTOS CONCIERGERIE (Guide Visuel + SOS / pannes) —
// route recréée (Task 25-b) : l'original créé en Task 20 avait été
// perdu dans le pipeline tar (audit 24-c/24-e : 404 en prod).
//
//   POST /api/airbnb/concierge/upload?propertyId=…  (multipart, file)
//     → { ok: true, url: '/api/uploads/concierge/<nom>' }
//
// Consommateurs (contrat figé) :
//   - src/components/airbnb/host/guest-experience-content.tsx
//   - src/components/airbnb/host/concierge-content.tsx
//   Les deux lisent res.ok + json.ok + json.url (FormData 'file').
//
// Écriture disque : <cwd>/data/uploads/concierge — le MÊME dossier
// que la route de lecture GET /api/uploads/concierge/[file] (volume
// persistant Docker /app/data ; public/ n'est pas servi après un
// build standalone). L'URL retournée est donc servie par cette route.
//
// Sécurité (miroir voice + branding/logo) : session NextAuth,
// mutationGuard airbnb (30/min) + quota uploads dédié 10/min,
// accès bien vérifié (canAccessProperty), IMAGES SEULEMENT,
// 500 Ko max, MIME déclaré + MAGIC NUMBERS vérifiés (le type
// annoncé par le client n'est jamais cru), extension issue d'une
// allowlist dérivée du contenu détecté, nommage serveur
// `${propertyId}-${crypto.randomBytes(8)}.${ext}` (aucun
// concat de l'entrée utilisateur). Never-throw.
// =============================================================

const UPLOAD_DIR = join(process.cwd(), 'data', 'uploads', 'concierge');
const MAX_BYTES = 500 * 1024; // 500 Ko — cohérent avec la route voice

/** MIME images autorisés (allowlist stricte, alignée sur lib/concierge-media). */
const ALLOWED_MIME = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);

/** Extension canonique par MIME détecté (toutes servies par le GET). */
const MIME_TO_EXT: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
};

/**
 * Détecte le VRAI type d'une image par magic numbers (pas par le
 * Content-Type annoncé ni l'extension du nom de fichier) :
 *   JPEG : FF D8 FF
 *   PNG  : 89 50 4E 47 0D 0A 1A 0A
 *   GIF  : 'GIF87a' | 'GIF89a'
 *   WebP : 'RIFF' … 'WEBP'
 */
function detectImageMime(bytes: Uint8Array): string | null {
  if (bytes.length < 12) return null;
  const ascii = (offset: number, s: string): boolean => {
    for (let i = 0; i < s.length; i++) {
      if (bytes[offset + i] !== s.charCodeAt(i)) return false;
    }
    return true;
  };
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return 'image/jpeg';
  if (
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0d &&
    bytes[5] === 0x0a &&
    bytes[6] === 0x1a &&
    bytes[7] === 0x0a
  ) {
    return 'image/png';
  }
  if (ascii(0, 'GIF87a') || ascii(0, 'GIF89a')) return 'image/gif';
  if (ascii(0, 'RIFF') && ascii(8, 'WEBP')) return 'image/webp';
  return null;
}

export async function POST(req: NextRequest) {
  try {
    // ── 1. Session obligatoire (pattern branding/logo) ──
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }

    // ── 2. Anti-abus : guard mutations airbnb (30/min) + uploads 10/min ──
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;
    if (!(await rateLimit(`concierge-upload:${userId}`, 10))) {
      return NextResponse.json(
        { error: 'Trop de photos envoyées. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    // ── 3. Bien scoppé (query param, règle sandbox) ──
    const { searchParams } = new URL(req.url);
    const propertyId = (searchParams.get('propertyId') || '').trim();
    if (!propertyId) {
      return NextResponse.json({ error: 'Bien manquant.' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ error: 'Accès refusé.' }, { status: 403 });
    }

    // ── 4. Fichier reçu (FormData 'file') ──
    const form = await req.formData().catch(() => null);
    const file = form?.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });
    }
    if (file.size <= 0) {
      return NextResponse.json({ error: 'Fichier vide.' }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { error: 'Image trop lourde (500 Ko maximum).' },
        { status: 413 },
      );
    }

    // ── 5. Images seulement : MIME déclaré + magic numbers ──
    if (!ALLOWED_MIME.has(file.type)) {
      return NextResponse.json(
        { error: 'Format non supporté (PNG, JPEG, WebP ou GIF attendu).' },
        { status: 415 },
      );
    }
    const bytes = new Uint8Array(await file.arrayBuffer());
    const detectedMime = detectImageMime(bytes);
    if (!detectedMime) {
      return NextResponse.json(
        { error: 'Fichier invalide : ce contenu n’est pas une image reconnue (PNG, JPEG, WebP ou GIF).' },
        { status: 415 },
      );
    }

    // ── 6. Nommage serveur : extension dérivée du contenu détecté ──
    const ext = MIME_TO_EXT[detectedMime];
    const filename = `${propertyId}-${crypto.randomBytes(8).toString('hex')}.${ext}`;
    const filePath = join(UPLOAD_DIR, basename(filename));

    // ── 7. Écriture disque (même dossier que la route de lecture) ──
    await mkdir(UPLOAD_DIR, { recursive: true });
    await writeFile(filePath, bytes);

    // ── 8. Réponse au contrat des 2 éditeurs hôtes { ok, url } ──
    return NextResponse.json({
      ok: true,
      url: `/api/uploads/concierge/${filename}`,
    });
  } catch (error) {
    console.error('[airbnb/concierge/upload POST] Error:', error);
    return NextResponse.json(
      { error: 'Impossible d’enregistrer cette photo. Réessayez.' },
      { status: 500 },
    );
  }
}
