// =============================================================
// POST /api/airbnb/concierge/upload?propertyId=…  (multipart, file)
//
// v4.73 — FIX « impossible d'insérer des images » : le composant
// Expérience Invité (photos du minibar + arrivée + étapes du guide)
// et la page Conciergerie (appareils + pannes SOS) appelaient cette
// route depuis v4.47 mais elle N'EXISTAIT PAS → chaque upload
// recevait un 404 et affichait « Upload impossible ».
//
// Stockage : <cwd>/data/uploads/concierge (volume persistant Docker
// /app/data, avec la base) — Écrire dans public/ ne fonctionne PAS
// en build standalone (fichiers ajoutés après build non servis) et
// n'est pas persisté. Lecture publique via GET /api/uploads/concierge/[file].
//
// Sécurité : session + accès bien ; allowlist MIME + extension réelle
// déduite du Content-Type (jamais du nom fourni) ; max 5 Mo ;
// nom de fichier aléatoire (jamais fourni par le client) → pas de
// traversée de chemin. IDs en QUERY PARAM (règle sandbox). Never-throw.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { canAccessProperty } from '@/lib/b2b-server';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { mkdir, writeFile } from 'fs/promises';
import { join } from 'path';
import { randomBytes } from 'crypto';
import {
  CONCIERGE_MEDIA_EXT,
  type ConciergeMediaExt,
} from '@/lib/concierge-media';

const UPLOAD_DIR = 'data/uploads/concierge';
const MAX_BYTES = 5 * 1024 * 1024; // 5 Mo — photos smartphone en clair

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    // FIX-15 — anti-abus : 30 mutations/min par hôte (userId, sinon IP).
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;

    const { searchParams } = new URL(req.url);
    const propertyId = (searchParams.get('propertyId') || '').trim();
    if (!propertyId) {
      return NextResponse.json({ error: 'Bien manquant' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 });
    }
    // Le bien doit exister (défense en profondeur).
    const property = await db.property.findUnique({
      where: { id: propertyId },
      select: { id: true },
    });
    if (!property) {
      return NextResponse.json({ error: 'Bien introuvable' }, { status: 404 });
    }

    const form = await req.formData().catch(() => null);
    const file = form?.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });
    }
    if (file.size <= 0) {
      return NextResponse.json({ error: 'Fichier vide.' }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: 'Image trop lourde (5 Mo max).' }, { status: 400 });
    }

    // Extension déduite du Content-Type réel (allowlist stricte —
    // identique à la route de lecture /api/uploads/concierge/[file]).
    const typeToExt: Record<string, ConciergeMediaExt> = {
      'image/png': 'png',
      'image/jpeg': 'jpg',
      'image/webp': 'webp',
      'image/gif': 'gif',
    };
    const ext = typeToExt[file.type];
    if (!ext || !(CONCIERGE_MEDIA_EXT as readonly string[]).includes(ext)) {
      return NextResponse.json(
        { error: 'Format non supporté (PNG, JPEG, WebP ou GIF attendu).' },
        { status: 400 },
      );
    }

    // Nom aléatoire serveur (timestamp + entropy) — le nom client n'est
    // JAMAIS réutilisé (pas de traversée, pas d'écrasement imprévisible).
    const name = `${Date.now()}-${randomBytes(6).toString('hex')}.${ext}`;
    const dir = join(process.cwd(), UPLOAD_DIR);
    await mkdir(dir, { recursive: true });
    await writeFile(join(dir, name), Buffer.from(await file.arrayBuffer()));

    // URL servie par la route publique de lecture (cache long).
    const url = `/api/uploads/concierge/${name}`;

    return NextResponse.json({ ok: true, url });
  } catch (error) {
    console.error('[airbnb/concierge/upload POST] Error:', error);
    return NextResponse.json({ error: 'Impossible de traiter cette image.' }, { status: 500 });
  }
}
