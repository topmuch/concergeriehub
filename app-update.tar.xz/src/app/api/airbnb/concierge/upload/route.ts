import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { mkdir, writeFile } from 'fs/promises';
import { join } from 'path';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { canAccessProperty } from '@/lib/b2b-server';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { rateLimit } from '@/lib/rate-limit';
import { captureError } from '@/lib/error-monitor';

// =============================================================
// AUDIT PRÉ-PROD — BLOQUANT FONCTIONNEL CORRIGÉ
// POST /api/airbnb/concierge/upload?propertyId=<id>
//   FormData : file (image)
//
// Le Dashboard Hôte (concierge-content.tsx) appelait cette route pour
// joindre une photo aux appareils du Guide et aux pannes courantes du
// SOS — mais elle N'EXISTAIT PAS (404 silencieux côté invité : aucune
// image ne s'affichait jamais dans le Guide/SOS).
//
// Contrat (côté client) : { ok: true, url: '/api/uploads/concierge/<fichier>' }
// Les fichiers sont écrits dans <cwd>/data/uploads/concierge (volume
// persistant Docker) et servis par GET /api/uploads/concierge/[file]
// (allowlist + basename — voir concierge-media.ts).
//
// Sécurité :
//  - session NextAuth + canAccessProperty (owner OU membre accepté) ;
//  - mutation guard 30/min + rate limit 10/min par utilisateur ;
//  - MIME/extension allowlist stricte (webp/png/jpg/jpeg/gif) ;
//  - taille max 500 Ko (spéc photos) ;
//  - nom de fichier SERVEUR (timestamp + random) — jamais le nom client
//    → aucun path traversal possible ; extension contrôlée.
// =============================================================

const MAX_BYTES = 500 * 1024; // 500 Ko — spéc « photos ≤ 500 KB »
const UPLOAD_DIR = 'data/uploads/concierge';

/** MIME → extension allowlist (mêmes extensions que la route de lecture). */
const MIME_TO_EXT: Record<string, 'webp' | 'png' | 'jpg' | 'jpeg' | 'gif'> = {
  'image/webp': 'webp',
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/gif': 'gif',
};

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ ok: false, error: 'Non autorisé.' }, { status: 401 });
    }

    // Anti-abus : 10 uploads/min par utilisateur + mutation guard global
    if (!(await rateLimit(`conciergeupload:${userId}`, 10))) {
      return NextResponse.json({ ok: false, error: 'Trop de photos envoyées. Réessayez dans un instant.' }, { status: 429 });
    }
    const guard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (guard) return guard;

    const url = new URL(req.url);
    const propertyId = (url.searchParams.get('propertyId') || '').trim();
    if (!propertyId) {
      return NextResponse.json({ ok: false, error: 'propertyId requis.' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ ok: false, error: 'Accès refusé.' }, { status: 403 });
    }

    const formData = await req.formData().catch(() => null);
    const file = formData?.get('file');
    if (!file || typeof file === 'string') {
      return NextResponse.json({ ok: false, error: 'Aucune image reçue.' }, { status: 400 });
    }
    if (!(file instanceof File)) {
      return NextResponse.json({ ok: false, error: 'Fichier invalide.' }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json(
        { ok: false, error: 'Image trop lourde (500 Ko maximum).' },
        { status: 413 },
      );
    }
    const ext = MIME_TO_EXT[file.type];
    if (!ext) {
      return NextResponse.json(
        { ok: false, error: 'Format non supporté (webp, png, jpg ou gif).' },
        { status: 415 },
      );
    }

    // Nom SERVEUR : timestamp + 6 octets aléatoires + extension contrôlée.
    // Le nom client n'est JAMAIS utilisé (pas de traversal, pas de collision).
    const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

    const bytes = new Uint8Array(await file.arrayBuffer());
    // Vérification du magic number (2e barrière si le MIME ment) :
    if (!looksLikeImage(bytes, ext)) {
      return NextResponse.json({ ok: false, error: 'Le contenu ne semble pas être une image valide.' }, { status: 415 });
    }

    const dir = join(process.cwd(), UPLOAD_DIR);
    await mkdir(dir, { recursive: true });
    await writeFile(join(dir, filename), bytes);

    return NextResponse.json({ ok: true, url: `/api/uploads/concierge/${filename}` }, { status: 201 });
  } catch (error) {
    await captureError('concierge.upload', error, undefined, req);
    return NextResponse.json({ ok: false, error: 'Erreur serveur. Réessayez dans un instant.' }, { status: 500 });
  }
}

/** Magic numbers minimaux : PNG, JPEG, GIF, WEBP (RIFF). */
function looksLikeImage(b: Uint8Array, ext: string): boolean {
  if (b.length < 12) return false;
  switch (ext) {
    case 'png':
      return b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
    case 'jpg':
    case 'jpeg':
      return b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
    case 'gif':
      return b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46;
    case 'webp':
      return (
        b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 &&
        b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50
      );
    default:
      return false;
  }
}
