// =============================================================
// POST /api/airbnb/concierge/upload?propertyId=… — UPLOAD PHOTOS
// DE LA CONCIERGERIE (multipart, champ 'file').
//
// v4.47 — ROUTE RECRÉÉE : l'éditeur hôte (concierge-content.tsx —
// Guide des appareils + SOS pannes courantes — et guest-experience-
// content.tsx — Guide visuel + v4.47 photos du Minibar) appelle
// `/api/airbnb/concierge/upload` depuis la v4.0, mais le fichier de
// route avait disparu du dépôt → tout upload échouait en 404 et les
// guides d'appareils ne pouvaient plus être remplis.
//
// Stockage : <cwd>/data/uploads/concierge/<propertyId>-<ts>.webp
//  (volume persistant Docker /app/data) — servi par la route
//  GET /api/uploads/concierge/[file] (allowlist, cache immutable).
//  Écrire dans public/ ne fonctionne PAS en build standalone.
//
// Sécurité : session + accès bien (canAccessProperty) ; extension
// réelle validée par sharp (ré-encodage WebP = pas de SVG/polyglot,
// EXIF neutralisé) ; max 8 Mo ; mutationGuard anti-abus.
// IDs en QUERY PARAM (règle sandbox). Never-throw.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { authOptions } from '@/lib/auth';
import { canAccessProperty } from '@/lib/b2b-server';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';
import sharp from 'sharp';

const UPLOAD_DIR = path.join(process.cwd(), 'data', 'uploads', 'concierge');
const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    // FIX-15 — anti-abus : 30 mutations/min par hôte (userId, sinon IP).
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;

    const { searchParams } = new URL(req.url);
    const propertyId = (searchParams.get('propertyId') || '').trim();
    if (!propertyId || propertyId.length > 40 || !/^[A-Za-z0-9_-]+$/.test(propertyId)) {
      return NextResponse.json({ error: 'Bien manquant ou invalide' }, { status: 400 });
    }
    if (!(await canAccessProperty(userId, propertyId))) {
      return NextResponse.json({ error: 'Accès refusé' }, { status: 403 });
    }

    const form = await req.formData().catch(() => null);
    const file = form?.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });
    }
    if (!ALLOWED.includes(file.type)) {
      return NextResponse.json(
        { error: 'Format non supporté (PNG, JPEG, WebP ou GIF attendu).' },
        { status: 400 },
      );
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: 'Image trop lourde (8 Mo max).' }, { status: 400 });
    }

    const bytes = Buffer.from(await file.arrayBuffer());
    // Ré-encodage systématique en WebP (max 1600 px) — neutralise tout
    // contenu malveillant (SVG actif, EXIF, polyglot) et allège le poids.
    // NB : un GIF animé devient statique (comportement accepté pour les
    // photos de guide).
    const webp = await sharp(bytes)
      .resize(1600, 1600, { fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer();

    await mkdir(UPLOAD_DIR, { recursive: true });
    // Nom unique (propertyId + timestamp) → cache public immutable OK.
    const name = `${propertyId}-${Date.now()}.webp`;
    await writeFile(path.join(UPLOAD_DIR, name), webp);

    // URL servie par GET /api/uploads/concierge/[file] (le lecteur
    // partagé de la conciergerie — data/uploads/concierge).
    return NextResponse.json({ ok: true, url: `/api/uploads/concierge/${name}` });
  } catch (error) {
    console.error('[airbnb/concierge/upload POST] Error:', error);
    return NextResponse.json({ error: 'Impossible de traiter cette image.' }, { status: 500 });
  }
}
