import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getUserRoleForProperty } from '@/lib/b2b-server';
import { canManageTeam } from '@/lib/team';
import { mutationGuard, mutationKey } from '@/lib/mutation-guard';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';
import sharp from 'sharp';

// =============================================================
// DIGITAL CONCIERGE (V4.1) — Upload des photos / GIF des modules
// (appareils du Guide + pannes courantes du SOS).
//   POST /api/airbnb/concierge/upload?propertyId=… (multipart, file)
//     → <cwd>/data/uploads/concierge/<nom>.webp|gif
//     → URL retournée : /api/uploads/concierge/<nom>
//
// POURQUOI data/ ET PAS public/ :
//  En build standalone (Docker), Next.js ne sert PAS les fichiers
//  ajoutés dans public/ après le build, et le volume ne persiste pas
//  public/ — même correctif que les messages vocaux (voice-audio).
//  L'URL /api/uploads/concierge/… est servie dynamiquement + autorisée
//  par la CSP de l'app invitée (img-src 'self').
//
// Sécurité : session + OWNER/MANAGER ; ré-encodage sharp (orientation
// EXIF appliquée, métadonnées retirées, 1600px max) — les GIF animés
// sont conservés tels quels après validation sharp (pas de ré-encodage
// qui casserait l'animation). Max 5 Mo. Never-throw.
// =============================================================

const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'];

function uploadDir(): string {
  return path.join(process.cwd(), 'data', 'uploads', 'concierge');
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    const userId = (session?.user as { id?: string } | undefined)?.id;
    if (!session?.user || !userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    // FIX-15 — anti-abus : 30 mutations/min par hôte (userId, sinon IP).
    const mutGuard = await mutationGuard(mutationKey('airbnb-mut', req, userId));
    if (mutGuard) return mutGuard;

    const { searchParams } = new URL(req.url);
    const propertyId = (searchParams.get('propertyId') || '').trim();
    if (!propertyId) {
      return NextResponse.json({ error: 'Bien manquant' }, { status: 400 });
    }
    const role = await getUserRoleForProperty(userId, propertyId);
    if (!role || !canManageTeam(role)) {
      return NextResponse.json(
        { error: 'Seuls le propriétaire et le co-hôte peuvent ajouter des photos.' },
        { status: 403 },
      );
    }

    const form = await req.formData().catch(() => null);
    const file = form?.get('file');
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: 'Aucun fichier reçu.' }, { status: 400 });
    }
    if (!ALLOWED.includes(file.type)) {
      return NextResponse.json(
        { error: 'Format non supporté (PNG, JPEG, WebP ou GIF attendu).' },
        { status: 400 },
      );
    }
    if (file.size > MAX_BYTES) {
      return NextResponse.json({ error: 'Image trop lourde (5 Mo max).' }, { status: 400 });
    }

    const bytes = Buffer.from(await file.arrayBuffer());
    let out: Buffer;
    let ext: string;
    if (file.type === 'image/gif') {
      // GIF : validation par sharp (jette si ce n'est pas une image)
      // mais octets originaux conservés — le ré-encodage tuerait
      // l'animation.
      try {
        await sharp(bytes).metadata();
      } catch {
        return NextResponse.json({ error: 'Image illisible ou corrompue.' }, { status: 400 });
      }
      out = bytes;
      ext = 'gif';
    } else {
      // PNG/JPEG/WebP → WebP optimisé (EXIF retiré, orientation
      // appliquée, 1600px max) — neutralise tout contenu actif.
      try {
        out = await sharp(bytes)
          .rotate()
          .resize(1600, 1600, { fit: 'inside', withoutEnlargement: true })
          .webp({ quality: 85 })
          .toBuffer();
      } catch {
        return NextResponse.json({ error: 'Image illisible ou corrompue.' }, { status: 400 });
      }
      ext = 'webp';
    }

    // Nom imprévisible + extension contrôlée (allowlist lecture).
    const name = `c-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    await mkdir(uploadDir(), { recursive: true });
    await writeFile(path.join(uploadDir(), name), out);

    return NextResponse.json({ ok: true, url: `/api/uploads/concierge/${name}` });
  } catch (error) {
    console.error('[airbnb/concierge/upload POST] Error:', error);
    return NextResponse.json({ error: 'Impossible de traiter cette image.' }, { status: 500 });
  }
}
