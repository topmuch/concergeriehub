// =============================================================
// /api/airbnb/v2/sessions/[id]/report — V2 « BOUCLIER » (étape 6)
// RAPPORT PDF SCELLÉ d'un état des lieux terminé.
//
// GET : génère le PDF (pdf-lib) côté serveur et le renvoie en
// inline (ouvrable dans un onglet / téléchargeable par le client).
//   · 🔒 session hôte requise — bien possédé uniquement (404) ;
//   · 409 tant que l'état des lieux n'est pas scellé (TERMINE) ;
//   · check-out : rapport de comparaison avec le check-in
//     d'origine (photos + empreinte vidéo chaînées).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import {
  buildSessionReportPdf,
  reportFilename,
} from '@/lib/v2-report';
import type { ReferencePhotoLibrary, ShieldSessionPhotos } from '@/lib/v2';

export const runtime = 'nodejs';

/** Session.photos Json → ShieldSessionPhotos (valeurs string uniquement). */
function parsePhotos(raw: unknown): ShieldSessionPhotos {
  const photos: ShieldSessionPhotos = {};
  if (raw && typeof raw === 'object') {
    for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
      if (typeof v === 'string') photos[k] = v;
    }
  }
  return photos;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const { id } = await params;

  const row = await db.session.findUnique({
    where: { id },
    select: {
      id: true,
      type: true,
      status: true,
      scheduledAt: true,
      startedAt: true,
      completedAt: true,
      cleanerName: true,
      photos: true,
      videoHash: true,
      publicToken: true,
      checkInSession: {
        select: { completedAt: true, cleanerName: true, videoHash: true, photos: true },
      },
      property: {
        select: {
          ownerId: true,
          name: true,
          address: true,
          housingType: true,
          shieldRooms: true,
          shieldAppliances: true,
          referencePhotos: true,
        },
      },
    },
  });
  if (!row || row.property.ownerId !== user.id) {
    return NextResponse.json({ error: 'Séjour introuvable' }, { status: 404 });
  }
  if (row.status !== 'TERMINE') {
    return NextResponse.json(
      { error: "Le rapport PDF est disponible une fois l'état des lieux scellé" },
      { status: 409 },
    );
  }

  const rooms = Array.isArray(row.property.shieldRooms)
    ? (row.property.shieldRooms as string[])
    : [];
  const appliances = Array.isArray(row.property.shieldAppliances)
    ? (row.property.shieldAppliances as string[])
    : [];

  const pdf = await buildSessionReportPdf({
    property: {
      name: row.property.name,
      address: row.property.address,
      housingType: row.property.housingType,
      rooms,
      appliances,
    },
    session: {
      type: row.type === 'CHECKOUT' ? 'CHECKOUT' : 'CHECKIN',
      scheduledAt: row.scheduledAt,
      startedAt: row.startedAt,
      completedAt: row.completedAt,
      cleanerName: row.cleanerName,
      photos: parsePhotos(row.photos),
      videoHash: row.videoHash,
      publicToken: row.publicToken,
    },
    checkIn: row.checkInSession
      ? {
          completedAt: row.checkInSession.completedAt,
          cleanerName: row.checkInSession.cleanerName,
          videoHash: row.checkInSession.videoHash,
          photos: parsePhotos(row.checkInSession.photos),
        }
      : null,
    reference: (row.property.referencePhotos ?? {}) as unknown as ReferencePhotoLibrary,
    generatedAt: new Date(),
  });

  const filename = reportFilename(
    row.type === 'CHECKOUT' ? 'CHECKOUT' : 'CHECKIN',
    row.property.name,
    row.completedAt ?? new Date(),
  );

  return new NextResponse(pdf as unknown as BodyInit, {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `inline; filename="${filename}"`,
      'Cache-Control': 'no-store',
    },
  });
}
