// =============================================================
// /api/airbnb/v2/sessions/[id]/send-link — V2 « BOUCLIER » (étape 7)
//
// POST : (re)envoie l'email du lien cleaner /s/[token] au ménager
// d'un séjour à venir. Utilisé après la création (le lien part
// déjà automatiquement quand un email ménager est renseigné) ou
// pour une relance manuelle depuis « Ménage à faire ».
//
// Gardes : session hôte requise (401), séjour possédé (404),
// email ménager renseigné à la création (409), séjour non clos
// (409 TERMINE/ANNULE). L'envoi passe par l'outbox V1 —
// fire-and-forget : ne lève jamais.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { appOriginFromRequest, sendCleanerLinkEmail } from '@/lib/v2-emails';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const { id } = await params;

  const existing = await db.session.findUnique({
    where: { id },
    select: {
      id: true,
      type: true,
      status: true,
      scheduledAt: true,
      cleanerName: true,
      cleanerEmail: true,
      publicToken: true,
      propertyId: true,
      property: { select: { ownerId: true, name: true } },
    },
  });
  if (!existing || existing.property.ownerId !== user.id) {
    return NextResponse.json({ error: 'Séjour introuvable' }, { status: 404 });
  }
  if (existing.status === 'TERMINE') {
    return NextResponse.json(
      { error: 'Cet état des lieux est déjà scellé — le lien cleaner n’est plus utile.' },
      { status: 409 },
    );
  }
  if (existing.status === 'ANNULE') {
    return NextResponse.json(
      { error: 'Ce séjour est annulé — réactivez en créant un nouveau séjour.' },
      { status: 409 },
    );
  }
  if (!existing.publicToken) {
    return NextResponse.json({ error: 'Lien cleaner indisponible' }, { status: 409 });
  }
  if (!existing.cleanerEmail) {
    return NextResponse.json(
      { error: 'Aucun email ménager sur ce séjour — recréez-le avec l’email, ou partagez le lien copié.' },
      { status: 409 },
    );
  }

  const result = await sendCleanerLinkEmail({
    to: existing.cleanerEmail,
    origin: appOriginFromRequest(req),
    publicToken: existing.publicToken,
    propertyName: existing.property.name,
    type: existing.type === 'CHECKOUT' ? 'CHECKOUT' : 'CHECKIN',
    scheduledAt: existing.scheduledAt,
    cleanerName: existing.cleanerName,
    userId: user.id,
    propertyId: existing.propertyId,
    sessionId: existing.id,
  });

  return NextResponse.json({ ok: true, emailStatus: result.status, provider: result.provider });
}
