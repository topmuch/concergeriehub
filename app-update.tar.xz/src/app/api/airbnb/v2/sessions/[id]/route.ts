// =============================================================
// /api/airbnb/v2/sessions/[id] — V2 « BOUCLIER » (étape 4)
//
// PATCH { action: 'CANCEL' } : annulation d'un séjour planifié.
// Seules les sessions à venir (statut stocké A_VENIR — EN_RETARD
// n'est qu'un statut d'affichage) peuvent être annulées.
//
// 🔒 Session hôte requise — bien possédé uniquement (404 sinon).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const { id } = await params;

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }
  const action = (body as { action?: unknown })?.action;
  if (action !== 'CANCEL') {
    return NextResponse.json({ error: 'Action inconnue' }, { status: 400 });
  }

  const existing = await db.session.findUnique({
    where: { id },
    select: { id: true, status: true, property: { select: { ownerId: true } } },
  });
  if (!existing || existing.property.ownerId !== user.id) {
    return NextResponse.json({ error: 'Séjour introuvable' }, { status: 404 });
  }
  if (existing.status === 'ANNULE') {
    return NextResponse.json({ error: 'Ce séjour est déjà annulé' }, { status: 409 });
  }
  if (existing.status !== 'A_VENIR') {
    return NextResponse.json(
      { error: 'Seuls les séjours à venir peuvent être annulés' },
      { status: 409 },
    );
  }

  await db.session.update({ where: { id }, data: { status: 'ANNULE' } });
  return NextResponse.json({ ok: true });
}
