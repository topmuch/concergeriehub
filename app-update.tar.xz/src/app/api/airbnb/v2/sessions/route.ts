// =============================================================
// /api/airbnb/v2/sessions — V2 « BOUCLIER » (étape 4 — flux B)
//
// GET  : liste des séjours (sessions) des biens de l'hôte.
//        ?type=CHECKIN|CHECKOUT — filtre par type
//        Le statut d'affichage est calculé (A_VENIR dont la date
//        est passée ⇒ EN_RETARD) sans écriture en base.
//
// POST : création d'un séjour planifié (flux B).
//        Règles de cycle Bouclier (appliquées côté serveur) :
//        • CHECKIN refusé si cycle ouvert (dernier TERMINE = CHECKIN)
//        • CHECKOUT refusé hors cycle ouvert, et refusé si un check-out
//          non annulé est déjà rattaché au check-in ouvert
//        Un token public (lien cleaner /s/[token] — étape 5) est généré
//        à la création. Un créneau passé reste admis : la session
//        s'affiche alors EN_RETARD.
//
// 🔒 Session hôte requise (biens possédés uniquement).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { randomUUID } from 'crypto';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { appOriginFromRequest, sendCleanerLinkEmail } from '@/lib/v2-emails';
import {
  displayStatus,
  validateCreateSessionPayload,
  type SessionType,
  type V2SessionDto,
} from '@/lib/v2';

const SELECT = {
  id: true,
  type: true,
  status: true,
  scheduledAt: true,
  completedAt: true,
  propertyId: true,
  property: { select: { name: true } },
  checkInSessionId: true,
  publicToken: true,
  cleanerEmail: true,
  createdAt: true,
} as const;

type Selected = {
  id: string;
  type: string;
  status: string;
  scheduledAt: Date | null;
  completedAt: Date | null;
  propertyId: string;
  property: { name: string };
  checkInSessionId: string | null;
  publicToken: string | null;
  cleanerEmail: string | null;
  createdAt: Date;
};

function toDto(s: Selected): V2SessionDto {
  return {
    id: s.id,
    type: s.type as SessionType,
    status: displayStatus(
      s.status,
      s.scheduledAt ? s.scheduledAt.toISOString() : null,
    ),
    scheduledAt: s.scheduledAt ? s.scheduledAt.toISOString() : null,
    completedAt: s.completedAt ? s.completedAt.toISOString() : null,
    propertyId: s.propertyId,
    propertyName: s.property.name,
    checkInSessionId: s.checkInSessionId,
    publicToken: s.publicToken,
    cleanerEmail: s.cleanerEmail,
    createdAt: s.createdAt.toISOString(),
  };
}

async function requireUser() {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  return user?.id ?? null;
}

export async function GET(req: NextRequest) {
  const userId = await requireUser();
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const typeParam = req.nextUrl.searchParams.get('type');
  const typeFilter =
    typeParam === 'CHECKIN' || typeParam === 'CHECKOUT' ? (typeParam as SessionType) : null;

  const owned = await db.property.findMany({
    where: { ownerId: userId },
    select: { id: true },
  });
  const propertyIds = owned.map((p) => p.id);
  if (propertyIds.length === 0) return NextResponse.json({ sessions: [] });

  const sessions = await db.session.findMany({
    where: {
      propertyId: { in: propertyIds },
      ...(typeFilter ? { type: typeFilter } : {}),
    },
    orderBy: { createdAt: 'desc' },
    select: SELECT,
  });

  return NextResponse.json({ sessions: sessions.map(toDto) });
}

export async function POST(req: NextRequest) {
  const userId = await requireUser();
  if (!userId) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }

  const parsed = validateCreateSessionPayload(body);
  if (!parsed.ok) return NextResponse.json({ error: parsed.error }, { status: 400 });
  const { propertyId, type, scheduledAt, cleanerName, cleanerEmail } = parsed.value;

  // Bien possédé + onboardé uniquement.
  const property = await db.property.findUnique({
    where: { id: propertyId },
    select: { id: true, ownerId: true, onboardingDone: true },
  });
  if (!property || property.ownerId !== userId) {
    return NextResponse.json({ error: 'Logement introuvable' }, { status: 404 });
  }
  if (!property.onboardingDone) {
    return NextResponse.json(
      { error: 'Terminez d’abord l’onboarding de ce logement (photos de référence).' },
      { status: 409 },
    );
  }

  // Règles de cycle Bouclier — calculées sur les séjours réels du bien.
  const propSessions = await db.session.findMany({
    where: { propertyId },
    select: { id: true, type: true, status: true, checkInSessionId: true, completedAt: true, createdAt: true },
  });
  const lastTermine = propSessions
    .filter((s) => s.status === 'TERMINE')
    .sort(
      (a, b) =>
        (b.completedAt?.getTime() ?? b.createdAt.getTime()) -
        (a.completedAt?.getTime() ?? a.createdAt.getTime()),
    )[0];
  const openCycle = lastTermine?.type === 'CHECKIN';

  if (type === 'CHECKIN' && openCycle) {
    return NextResponse.json(
      { error: 'Un check-in est déjà en cours pour ce logement : terminez d’abord son check-out.' },
      { status: 409 },
    );
  }
  if (type === 'CHECKOUT') {
    if (!openCycle) {
      return NextResponse.json(
        { error: 'Le check-out s’ouvre après un check-in terminé.' },
        { status: 409 },
      );
    }
    const alreadyLinked = propSessions.some(
      (s) => s.type === 'CHECKOUT' && s.status !== 'ANNULE' && s.checkInSessionId === lastTermine.id,
    );
    if (alreadyLinked) {
      return NextResponse.json(
        { error: 'Un check-out est déjà prévu ou réalisé pour ce check-in.' },
        { status: 409 },
      );
    }
  }

  const created = await db.session.create({
    data: {
      propertyId,
      type,
      status: 'A_VENIR',
      scheduledAt,
      cleanerName,
      cleanerEmail,
      publicToken: randomUUID().replace(/-/g, ''),
      ...(type === 'CHECKOUT' ? { checkInSessionId: lastTermine.id } : {}),
    },
    select: SELECT,
  });

  // Étape 7 — email automatique au ménager avec le lien /s/[token].
  // Fire-and-forget : queueEmail ne lève jamais — un échec email ne
  // casse pas la création du séjour (consultable dans l'outbox).
  if (created.cleanerEmail && created.publicToken) {
    await sendCleanerLinkEmail({
      to: created.cleanerEmail,
      origin: appOriginFromRequest(req),
      publicToken: created.publicToken,
      propertyName: created.property.name,
      type,
      scheduledAt,
      cleanerName,
      userId,
      propertyId,
      sessionId: created.id,
    });
  }

  return NextResponse.json(
    { session: toDto(created), cleanerLinkSent: Boolean(created.cleanerEmail) },
    { status: 201 },
  );
}
