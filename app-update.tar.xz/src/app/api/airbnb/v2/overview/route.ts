// =============================================================
// /api/airbnb/v2/overview — V2 « BOUCLIER » : compteurs du
// Tableau de bord (mes biens, ménage à faire, check-ins,
// check-outs, documents/rapports terminés).
// 🔒 Session hôte requise (biens possédés uniquement).
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import type { V2OverviewDto } from '@/lib/v2';

export async function GET() {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
  }

  const owned = await db.property.findMany({
    where: { ownerId: user.id },
    select: { id: true, onboardingDone: true },
  });
  const propertyIds = owned.map((p) => p.id);

  const [onboarded, aVenir, enRetard, checkins, checkouts, documents] = await Promise.all([
    db.property.count({ where: { ownerId: user.id, onboardingDone: true } }),
    propertyIds.length
      ? db.session.count({ where: { propertyId: { in: propertyIds }, status: 'A_VENIR' } })
      : Promise.resolve(0),
    propertyIds.length
      ? db.session.count({ where: { propertyId: { in: propertyIds }, status: 'EN_RETARD' } })
      : Promise.resolve(0),
    propertyIds.length
      ? db.session.count({ where: { propertyId: { in: propertyIds }, type: 'CHECKIN' } })
      : Promise.resolve(0),
    propertyIds.length
      ? db.session.count({ where: { propertyId: { in: propertyIds }, type: 'CHECKOUT' } })
      : Promise.resolve(0),
    propertyIds.length
      ? db.session.count({ where: { propertyId: { in: propertyIds }, status: 'TERMINE' } })
      : Promise.resolve(0),
  ]);

  const dto: V2OverviewDto = {
    properties: owned.length,
    onboarded,
    menageAFaire: aVenir + enRetard,
    checkins,
    checkouts,
    documents,
  };
  return NextResponse.json(dto);
}
