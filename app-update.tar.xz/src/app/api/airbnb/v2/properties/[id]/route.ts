// =============================================================
// /api/airbnb/v2/properties/[id] — V2 « BOUCLIER »
//
// GET   : détail d'un bien (pré-remplissage du wizard).
// PATCH : reconfiguration de l'onboarding (wizard en mode édition).
//
// 🔒 Session hôte requise — bien possédé uniquement (404 sinon).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import {
  countReferencePhotos,
  validateOnboardingPayload,
  type HousingType,
  type V2PropertyDto,
} from '@/lib/v2';

const SELECT = {
  id: true,
  name: true,
  address: true,
  housingType: true,
  onboardingDone: true,
  shieldRooms: true,
  shieldAppliances: true,
  referencePhotos: true,
  createdAt: true,
} as const;

type Selected = {
  id: string;
  name: string;
  address: string | null;
  housingType: string | null;
  onboardingDone: boolean;
  shieldRooms: unknown;
  shieldAppliances: unknown;
  referencePhotos: unknown;
  createdAt: Date;
};

function toDto(p: Selected): V2PropertyDto & {
  referencePhotos: unknown;
} {
  return {
    id: p.id,
    name: p.name,
    address: p.address,
    housingType: (p.housingType as HousingType | null) ?? null,
    onboardingDone: p.onboardingDone,
    rooms: Array.isArray(p.shieldRooms) ? (p.shieldRooms as string[]) : [],
    appliances: Array.isArray(p.shieldAppliances) ? (p.shieldAppliances as string[]) : [],
    referencePhotoCount: countReferencePhotos(p.referencePhotos),
    createdAt: p.createdAt.toISOString(),
    // Bibliothèque brute (pré-remplissage du wizard en mode édition)
    referencePhotos: p.referencePhotos ?? null,
  };
}

async function requireOwned(userId: string, id: string) {
  const property = await db.property.findUnique({ where: { id }, select: { ...SELECT, ownerId: true } });
  if (!property || property.ownerId !== userId) return null;
  return property;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const { id } = await params;
  const property = await requireOwned(user.id, id);
  if (!property) return NextResponse.json({ error: 'Bien introuvable' }, { status: 404 });

  return NextResponse.json({ property: toDto(property) });
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });

  const { id } = await params;
  const owned = await requireOwned(user.id, id);
  if (!owned) return NextResponse.json({ error: 'Bien introuvable' }, { status: 404 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }

  const parsed = validateOnboardingPayload(body);
  if (!parsed.ok) return NextResponse.json({ error: parsed.error }, { status: 400 });
  const v = parsed.value;

  const updated = await db.property.update({
    where: { id },
    data: {
      name: v.name,
      address: v.address,
      housingType: v.housingType,
      shieldRooms: v.rooms,
      shieldAppliances: v.appliances,
      referencePhotos: v.referencePhotos as unknown as Prisma.InputJsonValue,
      onboardingDone: true,
    },
    select: SELECT,
  });

  return NextResponse.json({ property: toDto(updated) });
}
