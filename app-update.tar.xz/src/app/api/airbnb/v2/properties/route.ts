// =============================================================
// /api/airbnb/v2/properties — V2 « BOUCLIER »
//
// GET  : liste des biens de l'hôte (possédés) avec l'état
//        d'onboarding V2 (type, pièces, équipements, bibliothèque).
// POST : création d'un bien directement depuis le wizard
//        d'onboarding 3 étapes (payload validé par src/lib/v2.ts).
//
// 🔒 Session hôte requise.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import {
  countReferencePhotos,
  validateOnboardingPayload,
  type HousingType,
  type V2PropertyDto,
} from '@/lib/v2';

function toDto(p: {
  id: string;
  name: string;
  address: string | null;
  housingType: string | null;
  onboardingDone: boolean;
  shieldRooms: unknown;
  shieldAppliances: unknown;
  referencePhotos: unknown;
  createdAt: Date;
}): V2PropertyDto {
  return {
    id: p.id,
    name: p.name,
    address: p.address,
    housingType: (p.housingType as HousingType | null) ?? null,
    onboardingDone: p.onboardingDone,
    rooms: Array.isArray(p.shieldRooms) ? (p.shieldRooms as string[]) : [],
    appliances: Array.isArray(p.shieldAppliances) ? (p.shieldAppliances as string[]) : [],
    referencePhotoCount: countReferencePhotos(p.referencePhotos),
    createdAt: p.createdAt.toISOString(),
  };
}

export async function GET() {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
  }

  const properties = await db.property.findMany({
    where: { ownerId: user.id },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      name: true,
      address: true,
      housingType: true,
      onboardingDone: true,
      shieldRooms: true,
      shieldAppliances: true,
      referencePhotos: true,
      createdAt: true,
    },
  });

  return NextResponse.json({ properties: properties.map(toDto) });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const user = session?.user as { id?: string } | undefined;
  if (!user?.id) {
    return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'JSON invalide' }, { status: 400 });
  }

  const parsed = validateOnboardingPayload(body);
  if (!parsed.ok) {
    return NextResponse.json({ error: parsed.error }, { status: 400 });
  }
  const v = parsed.value;

  const created = await db.property.create({
    data: {
      ownerId: user.id,
      name: v.name,
      address: v.address,
      housingType: v.housingType,
      shieldRooms: v.rooms,
      shieldAppliances: v.appliances,
      referencePhotos: v.referencePhotos as unknown as Prisma.InputJsonValue,
      onboardingDone: true,
    },
    select: {
      id: true,
      name: true,
      address: true,
      housingType: true,
      onboardingDone: true,
      shieldRooms: true,
      shieldAppliances: true,
      referencePhotos: true,
      createdAt: true,
    },
  });

  return NextResponse.json({ property: toDto(created) }, { status: 201 });
}
