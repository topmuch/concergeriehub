// =============================================================
// /api/inspection/merged-pdf/[id] — CIRCUIT « EDL v2 » (Task 4-a)
//
// GET : télécharge le PDF FUSIONNÉ du séjour (pages ENTRÉE puis
// pages SORTIE, aucune page de garde) — disponible UNIQUEMENT après
// la complétion du check-out (décision client EDL-CIRCUIT-1 Q3/Q6).
//
// `id` = id d'une Inspection du couple (ENTREE ou SORTIE) — le
// couple est résolu dans les deux sens via linkedInspectionId.
//
// ENTITLEMENT : session obligatoire + garde STRICTE (identique
// create/route.ts) ; l'inspection demandée doit appartenir à
// l'abonnement du demandeur (garde en base ci-dessous).
//
// Erreurs typées buildMergedStayPdf :
//   • 'not_found'  → 404 (inspection inconnue / hors abonnement) ;
//   • 'incomplete' → 409 { error:'sortie_non_completee', … }.
// Réponse 200 : binaire application/pdf en téléchargement
// (Content-Disposition attachment), Cache-Control no-store.
// =============================================================
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { clientIp } from '@/lib/audit';
import { rateLimit } from '@/lib/rate-limit';
import { buildMergedStayPdf, MergedStayPdfError } from '@/lib/inspection-merged';
import {
  requireUserId,
  sessionRole,
  ensureInspectionAccess,
  inspectionAccessError,
} from '@/lib/inspection-access';

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  try {
    const { id } = await params;
    if (!id || typeof id !== 'string' || id.length < 6) {
      return NextResponse.json({ error: 'Inspection introuvable.' }, { status: 404 });
    }

    // ── Session + entitlement strict (identique create/route.ts) ──
    const session = await getServerSession(authOptions);
    const userId = requireUserId(session);
    if (!userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const access = await ensureInspectionAccess(userId, sessionRole(session));
    if (access === 'no_access' || access === 'expired') {
      const { status, body } = inspectionAccessError(access);
      return NextResponse.json(body, { status });
    }

    // Génération coûteuse (2 rendus pdfkit + fusion) : 10/min par user+IP.
    const ip = clientIp(req.headers) ?? 'local';
    if (!(await rateLimit(`inspmerged:${userId}:${ip}`, 10))) {
      return NextResponse.json(
        { error: 'Trop de téléchargements. Merci de patienter une minute.' },
        { status: 429 },
      );
    }

    // ── Garde de propriété : l'inspection doit appartenir à
    // l'abonnement du demandeur (vérifiée avant toute génération). ──
    const sub = await db.inspectionSubscription.findUnique({
      where: { userId },
      select: { id: true },
    });
    const base = await db.inspection.findUnique({
      where: { id },
      select: { id: true, subscriptionId: true },
    });
    if (!sub || !base || base.subscriptionId !== sub.id) {
      return NextResponse.json({ error: 'Inspection introuvable.' }, { status: 404 });
    }

    // ── Génération du PDF fusionné (couple + statuts vérifiés dedans) ──
    let result: Awaited<ReturnType<typeof buildMergedStayPdf>>;
    try {
      result = await buildMergedStayPdf(id);
    } catch (error) {
      if (error instanceof MergedStayPdfError) {
        if (error.code === 'not_found') {
          return NextResponse.json({ error: 'Inspection introuvable.' }, { status: 404 });
        }
        return NextResponse.json(
          {
            error: 'sortie_non_completee',
            message: 'Le PDF fusionné est disponible après la complétion du check-out.',
          },
          { status: 409 },
        );
      }
      throw error;
    }

    // ── Réponse binaire (téléchargement) ──
    return new Response(new Uint8Array(result.bytes), {
      headers: {
        'Content-Type': 'application/pdf',
        // fileName est ASCII pur (slug) ; filename* (RFC 5987) fournit
        // la variante encodée (encodeURIComponent) pour les clients
        // stricts sur les caractères non-ASCII.
        'Content-Disposition': `attachment; filename="${result.fileName}"; filename*=UTF-8''${encodeURIComponent(result.fileName)}`,
        'Cache-Control': 'no-store, max-age=0, must-revalidate',
      },
    });
  } catch (error) {
    console.error('[inspection/merged-pdf GET] Error:', error);
    return NextResponse.json(
      { error: 'Impossible de générer le PDF fusionné pour le moment. Merci de réessayer.' },
      { status: 500 },
    );
  }
}
