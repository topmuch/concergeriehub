// =============================================================
// /api/inspection/stay — CIRCUIT « ÉTATS DES LIEUX v2 » (Task 4-a)
// (offre 299 €/an — décisions client EDL-CIRCUIT-1 Q1/Q2/Q4)
//
// POST : crée D'UN COUP le SÉJOUR complet de l'utilisateur connecté :
//   • l'EDL d'ENTRÉE  (status PENDING, scheduledDate = entryDate) ;
//   • l'EDL de SORTIE (status PENDING, scheduledDate = exitDate,
//     linkedInspectionId → entrée).
// L'hôte remplit les deux ; l'invité ne fait que signer via le lien
// public. AUCUN email n'est envoyé à la création (circuit v2 —
// envoi UNIQUE final à la complétion de la SORTIE, PDF fusionné).
//
// ENTITLEMENT : identique à /api/inspection/create (v4.107) —
// abonnement EDL actif OU compte Hub (abonnement créé à la volée) ;
// sinon 403 { error:'abonnement_requis', redirect:'/edl/abonnement' }.
//
// Pré-remplissage des pièces/équipements :
//   • propertyId fourni → ShieldProperty de l'abonnement :
//       rooms = property.pieces (JSON stringifié, ex ["SALON","CHAMBRE 1"]),
//       items = property.equipementsCoches (kinds → noms métier,
//       répartis dans les pièces par heuristique de nom) ;
//       propertyName/propertyAddress/ownerName du BIEN font foi ;
//   • sinon (ou pièces inexploitables) → template juridique FR
//     INSPECTION_TEMPLATE (même construction que create/route.ts).
//
// Corps JSON :
// { propertyId?, propertyName, propertyAddress, city?,
//   guestName, guestEmail?, guestPhone?, entryDate, exitDate }
// Réponse 201 : { entry: { id, publicToken, shareUrl },
//                 exit:  { id, publicToken, shareUrl } }
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import { resolveOrigin } from '@/lib/site';
import { INSPECTION_TEMPLATE, inspectionShareUrl, type InspectionTemplateRoom } from '@/lib/inspection-template';
import {
  requireUserId,
  sessionRole,
  ensureInspectionAccess,
  inspectionAccessError,
} from '@/lib/inspection-access';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const MAX_ROOMS = 12; // même plafond que le wizard Bouclier (MAX_ZONES)
const MAX_ITEMS_PER_ROOM = 30; // garde défensive (template = 18 max)

// ── Kinds d'équipements Bouclier → noms métier EDL + pièce cible ──
// Les noms calquent EXACTEMENT ceux d'INSPECTION_TEMPLATE quand un
// équivalent existe (match isElectronicItem → preuves ON/OFF OK).
const DEVICE_ITEM_BY_KIND: Record<string, { name: string; roomHint: RegExp }> = {
  PLQ: { name: 'Plaque de cuisson', roomHint: /CUISINE|KITCHEN/i },
  MO: { name: 'Micro-ondes', roomHint: /CUISINE|KITCHEN/i },
  FRIGO: { name: 'Réfrigérateur', roomHint: /CUISINE|KITCHEN/i },
  LV: { name: 'Lave-vaisselle', roomHint: /CUISINE|KITCHEN/i },
  FOUR: { name: 'Four', roomHint: /CUISINE|KITCHEN/i },
  CLMS: { name: 'Climatiseur (salon)', roomHint: /SALON|S[EÉ]JOUR|LIVING/i },
  CLC1: { name: 'Climatiseur (chambre 1)', roomHint: /CHAMBRE\s*1|CH\.?\s*1|CH1/i },
  CLC2: { name: 'Climatiseur (chambre 2)', roomHint: /CHAMBRE\s*2|CH\.?\s*2|CH2/i },
  LAV: { name: 'Lave-linge', roomHint: /CUISINE|BUANDERIE|LAVAGE|SDB|BAIN|TOILETTE/i },
  SEC: { name: 'Sèche-linge', roomHint: /CUISINE|BUANDERIE|LAVAGE|SDB|BAIN|TOILETTE/i },
  TV: { name: 'Télévision', roomHint: /SALON|S[EÉ]JOUR|LIVING|CHAMBRE/i },
  SCH: { name: 'Sèche-cheveux', roomHint: /SDB|BAIN|TOILETTE|CHAMBRE/i },
  COFFRE: { name: 'Coffre-fort', roomHint: /CHAMBRE|SALON/i },
  BUIL: { name: 'Bouilloire', roomHint: /CUISINE/i },
};

/**
 * Parse un champ JSON stringifié du ShieldProperty (pieces,
 * equipementsCoches) → tableau de chaînes nettoyées et dédupliquées.
 * Renvoie [] si absent / illisible / vide (→ fallback template).
 */
function parseJsonStringArray(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const out: string[] = [];
    for (const v of parsed) {
      if (typeof v !== 'string') continue;
      const t = v.trim().slice(0, 60);
      if (t && !out.some((s) => s.toLowerCase() === t.toLowerCase())) out.push(t);
    }
    return out;
  } catch {
    return [];
  }
}

/**
 * Pré-remplissage rooms/items pour un séjour :
 *   • bien avec pièces exploitables → 1 room par pièce (max 12) +
 *     items équipements répartis par heuristique de nom de pièce ;
 *   • sinon → template juridique FR (construction create/route.ts).
 */
function buildPrefillRooms(
  pieces: string | null,
  equipementsCoches: string | null,
): InspectionTemplateRoom[] {
  const pieceNames = parseJsonStringArray(pieces);
  if (pieceNames.length === 0) {
    // Fallback : template juridique FR complet.
    return INSPECTION_TEMPLATE;
  }
  const rooms: InspectionTemplateRoom[] = pieceNames
    .slice(0, MAX_ROOMS)
    .map((name) => ({ name, items: [] }));

  // Équipements cochés au wizard (kinds Bouclier) → items répartis.
  for (const kind of parseJsonStringArray(equipementsCoches)) {
    const spec = DEVICE_ITEM_BY_KIND[kind.toUpperCase()];
    if (!spec) continue; // kind inconnu (CUSTOM…) → ignoré (non exploitable)
    const room = rooms.find((r) => spec.roomHint.test(r.name)) ?? rooms[0]; // fallback : 1re pièce
    if (!room || room.items.length >= MAX_ITEMS_PER_ROOM) continue;
    if (!room.items.some((i) => i.name === spec.name)) {
      room.items.push({ name: spec.name, electronic: true });
    }
  }
  return rooms;
}

/** Token public 24 caractères — copie verbatim de create/route.ts. */
function randomToken(): string {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const uuid = crypto.randomUUID().replace(/-/g, '');
  let token = '';
  for (let i = 0; i < 24; i++) {
    const c = alphabet[Math.floor(Math.random() * alphabet.length)];
    token += c ?? uuid[i % uuid.length];
  }
  return token;
}

/** Génère un token dont l'unicité est vérifiée en base (create parity). */
async function uniquePublicToken(): Promise<string> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const candidate = randomToken();
    const exists = await db.inspection.findUnique({
      where: { publicToken: candidate },
      select: { id: true },
    });
    if (!exists) return candidate;
  }
  // Probabilité négligeable — dernier recours : suffixe horodaté.
  return `${randomToken().slice(0, 16)}${Date.now().toString(36).slice(-8)}`;
}

export async function POST(req: NextRequest) {
  try {
    // ── Session (obligatoire) ──
    const session = await getServerSession(authOptions);
    const userId = requireUserId(session);
    if (!userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const role = sessionRole(session);

    // ── Entitlement strict (identique create/route.ts) ──
    const access = await ensureInspectionAccess(userId, role);
    if (access === 'no_access' || access === 'expired') {
      const { status, body } = inspectionAccessError(access);
      return NextResponse.json(body, { status });
    }
    const subscription = await db.inspectionSubscription.findUniqueOrThrow({
      where: { userId },
    });

    // ── Corps JSON ──
    const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
    if (!body || typeof body !== 'object') {
      return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const str = (key: string): string =>
      typeof body[key] === 'string' ? (body[key] as string).trim() : '';

    const propertyId = str('propertyId') || undefined;
    const bodyPropertyName = str('propertyName');
    const bodyPropertyAddress = str('propertyAddress');
    const bodyCity = str('city');
    const guestName = str('guestName');
    const guestEmail = str('guestEmail') || undefined;
    const guestPhone = str('guestPhone') || undefined;

    // ── Validation invité (identique create/route.ts) ──
    if (guestName.length < 1 || guestName.length > 120) {
      return NextResponse.json(
        { error: "Le nom de l'invité est requis (120 caractères maximum)." },
        { status: 400 },
      );
    }
    if (guestEmail && !EMAIL_RE.test(guestEmail)) {
      return NextResponse.json({ error: 'Adresse email de l’invité invalide.' }, { status: 400 });
    }

    // ── Validation des dates du séjour (ISO) ──
    const entryDate = str('entryDate') ? new Date(str('entryDate')) : null;
    const exitDate = str('exitDate') ? new Date(str('exitDate')) : null;
    if (!entryDate || Number.isNaN(entryDate.getTime())) {
      return NextResponse.json(
        { error: "La date d'entrée est requise (format de date valide)." },
        { status: 400 },
      );
    }
    if (!exitDate || Number.isNaN(exitDate.getTime())) {
      return NextResponse.json(
        { error: 'La date de sortie est requise (format de date valide).' },
        { status: 400 },
      );
    }
    if (exitDate.getTime() <= entryDate.getTime()) {
      return NextResponse.json(
        { error: "La date de sortie doit être postérieure à la date d'entrée." },
        { status: 400 },
      );
    }

    // ── Bien onboardé optionnel (source du pré-remplissage) ──
    let property: {
      propertyName: string;
      propertyAddress: string;
      city: string;
      ownerName: string;
      pieces: string;
      equipementsCoches: string;
    } | null = null;
    if (propertyId) {
      const found = await db.shieldProperty.findFirst({
        where: { id: propertyId, subscriptionId: subscription.id },
        select: {
          propertyName: true,
          propertyAddress: true,
          city: true,
          ownerName: true,
          pieces: true,
          equipementsCoches: true,
        },
      });
      if (!found) {
        return NextResponse.json(
          {
            error: 'bien_introuvable',
            message: 'Le bien sélectionné est introuvable dans votre module États des Lieux.',
          },
          { status: 404 },
        );
      }
      property = found;
    }

    // ── Champs logement : le BIEN fait foi, sinon champs libres ──
    const propertyName = property?.propertyName ?? bodyPropertyName;
    const propertyAddress = property?.propertyAddress ?? bodyPropertyAddress;
    if (propertyName.length < 1 || propertyName.length > 160) {
      return NextResponse.json(
        { error: 'Le nom du logement est requis (160 caractères maximum).' },
        { status: 400 },
      );
    }
    if (propertyAddress.length < 1 || propertyAddress.length > 300) {
      return NextResponse.json(
        { error: "L'adresse du logement est requise (300 caractères maximum)." },
        { status: 400 },
      );
    }
    if (bodyCity && bodyCity.length > 120) {
      return NextResponse.json(
        { error: 'La ville est trop longue (120 caractères maximum).' },
        { status: 400 },
      );
    }

    // ownerName = celui du bien, sinon nom de session (fallback email).
    let ownerName = property?.ownerName ?? '';
    if (!ownerName) {
      const user = await db.user.findUnique({
        where: { id: userId },
        select: { fullName: true, email: true },
      });
      ownerName = user?.fullName?.trim() || user?.email || '';
    }
    if (ownerName.length < 1 || ownerName.length > 120) {
      return NextResponse.json(
        { error: 'Le nom du propriétaire est requis (120 caractères maximum).' },
        { status: 400 },
      );
    }

    // Ville légale (« Fait à … ») : saisie libre prioritaire, sinon bien.
    const city = bodyCity || property?.city || undefined;

    // ── Pré-remplissage partagé (mêmes rooms/items pour les 2 EDL) ──
    const roomsData = buildPrefillRooms(
      property?.pieces ?? null,
      property?.equipementsCoches ?? null,
    );

    // ── Création ATOMIQUE du séjour : ENTREE puis SORTIE liée ──
    const [entryToken, exitToken] = await Promise.all([uniquePublicToken(), uniquePublicToken()]);

    const { entry, exit } = await db.$transaction(async (tx) => {
      const entry = await tx.inspection.create({
        data: {
          subscriptionId: subscription.id,
          propertyName,
          propertyAddress,
          ownerName,
          guestName,
          guestEmail: guestEmail || null,
          guestPhone: guestPhone || null,
          type: 'ENTREE',
          scheduledDate: entryDate,
          status: 'PENDING',
          publicToken: entryToken,
          city: city ?? null,
          rooms: {
            create: roomsData.map((room, roomIndex) => ({
              name: room.name,
              sortOrder: roomIndex,
              items: {
                create: room.items.map((item, itemIndex) => ({
                  name: item.name,
                  state: 'BON',
                  sortOrder: itemIndex,
                })),
              },
            })),
          },
        },
        select: { id: true, publicToken: true },
      });
      const exit = await tx.inspection.create({
        data: {
          subscriptionId: subscription.id,
          propertyName,
          propertyAddress,
          ownerName,
          guestName,
          guestEmail: guestEmail || null,
          guestPhone: guestPhone || null,
          type: 'SORTIE',
          scheduledDate: exitDate,
          status: 'PENDING',
          publicToken: exitToken,
          city: city ?? null,
          linkedInspectionId: entry.id,
          rooms: {
            create: roomsData.map((room, roomIndex) => ({
              name: room.name,
              sortOrder: roomIndex,
              items: {
                create: room.items.map((item, itemIndex) => ({
                  name: item.name,
                  state: 'BON',
                  sortOrder: itemIndex,
                })),
              },
            })),
          },
        },
        select: { id: true, publicToken: true },
      });
      return { entry, exit };
    });

    // ── Circuit v2 : AUCUN email ici — l'envoi unique (PDF fusionné
    // hôte + invité) n'intervient qu'à la complétion de la SORTIE. ──

    const origin = resolveOrigin(req);
    return NextResponse.json(
      {
        entry: {
          id: entry.id,
          publicToken: entry.publicToken,
          shareUrl: inspectionShareUrl(entry.publicToken, origin),
        },
        exit: {
          id: exit.id,
          publicToken: exit.publicToken,
          shareUrl: inspectionShareUrl(exit.publicToken, origin),
        },
      },
      { status: 201 },
    );
  } catch (error) {
    console.error('[inspection/stay POST] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
