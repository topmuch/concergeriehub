// =============================================================
// /api/inspection/properties — CIRCUIT « ÉTATS DES LIEUX v2 »
// (Task 4-a — biens onboardés du compte)
//
// GET : liste des biens onboardés (ShieldProperty) rattachés à
// l'abonnement EDL de l'utilisateur connecté — alimente le sélecteur
// de biens du formulaire « Créer un nouveau séjour » du dashboard.
//
// ENTITLEMENT : identique à /api/inspection/list (garde SOUPLE) —
// l'abonnement est créé à la volée pour les comptes Hub, renvoyé
// tel quel même expiré (consultation) ; 403
// { error:'abonnement_requis', redirect:'/edl/abonnement' } sinon.
//
// NOTE SCHÉMA : ShieldProperty.subscriptionId référence DIRECTEMENT
// InspectionSubscription (relation confirmée dans prisma/schema.prisma)
// → filtre par l'id de cette abonnement, aucune adaptation requise.
//
// Réponse 200 :
// { properties: [{ id, propertyName, propertyAddress, nbChambres,
//   pieces, equipementsCoches, onboardingRef, onboardedAt }] }
//   • pieces / equipementsCoches = strings JSON BRUTES (ex '["SALON"]')
//     — le FRONT les parse (SQLite : pas de listes Prisma natives) ;
//   • onboardedAt = ISO string.
// Cache-Control : no-store.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';
import {
  requireUserId,
  sessionRole,
  resolveInspectionSubscription,
} from '@/lib/inspection-access';

export async function GET(req: NextRequest) {
  try {
    // ── Session (obligatoire) ──
    const session = await getServerSession(authOptions);
    const userId = requireUserId(session);
    if (!userId) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }

    // ── Entitlement souple (identique list/route.ts) ──
    const subscription = await resolveInspectionSubscription(userId, sessionRole(session));
    if (!subscription) {
      return NextResponse.json(
        {
          error: 'abonnement_requis',
          message: "L'offre États des Lieux (299 €/an, PDF illimités) est requise.",
          redirect: '/edl/abonnement',
        },
        { status: 403 },
      );
    }

    // ── Biens onboardés de CET abonnement (plus récents d'abord) ──
    const properties = await db.shieldProperty.findMany({
      where: { subscriptionId: subscription.id },
      orderBy: { onboardedAt: 'desc' },
      select: {
        id: true,
        propertyName: true,
        propertyAddress: true,
        nbChambres: true,
        pieces: true,
        equipementsCoches: true,
        onboardingRef: true,
        onboardedAt: true,
      },
    });

    return NextResponse.json(
      {
        properties: properties.map((p) => ({
          id: p.id,
          propertyName: p.propertyName,
          propertyAddress: p.propertyAddress,
          nbChambres: p.nbChambres,
          // Strings JSON brutes — parsing côté front (contrat figé).
          pieces: p.pieces,
          equipementsCoches: p.equipementsCoches,
          onboardingRef: p.onboardingRef,
          onboardedAt: p.onboardedAt.toISOString(),
        })),
      },
      { headers: { 'Cache-Control': 'no-store, max-age=0, must-revalidate' } },
    );
  } catch (error) {
    console.error('[inspection/properties GET] Error:', error);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
