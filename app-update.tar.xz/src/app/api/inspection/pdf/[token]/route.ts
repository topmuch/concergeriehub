import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { clientIp } from '@/lib/audit';
import { captureError } from '@/lib/error-monitor';
import {
  renderStandaloneInspectionPdf,
  type StandaloneInspectionPdfData,
} from '@/lib/inspection-standalone-pdf';
import { computeInspectionSha256 } from '@/lib/inspection-hash';
import { mergePdfsWithCoverPage, pdfContentDisposition } from '@/lib/inspection-merge-pdf';

// =============================================================
// v4.97 MODULE STANDALONE « ÉTAT DES LIEUX » — PDF PUBLIC
// GET /api/inspection/pdf/[token]
//   → 200 application/pdf (inline) — document juridique signé
//   → 404 si le token est inconnu, 500 si le rendu échoue.
//
// v5.3 — FUSION AUTOMATIQUE (demande client : « le document doit
// s'afficher déjà fusionné ») : une EDL de SORTIE liée à son ENTRÉE
// (linkedInspectionId) renvoie UN document « complet » = page de
// garde + PDF entrée + PDF sortie (pdf-lib). Sinon : document simple.
// Le poids du PDF généré est persisté (Inspection.pdfSizeBytes).
// Sécurité : rate limit 20/min par token+IP ; token unique ;
// filename accentué encodé RFC 5987 ; never-throw.
// =============================================================

/** Shape structurel minimal requis pour le rendu (ligne Prisma + pièces). */
type InspectionRowLike = {
  publicToken: string;
  propertyName: string;
  propertyAddress: string;
  ownerName: string;
  guestName: string;
  type: string;
  scheduledDate: Date;
  status: string;
  signedAt: Date | null;
  completedAt: Date | null;
  cleanlinessScore: string | null;
  cleanlinessComment: string | null;
  cleanlinessPhotoUrl: string | null;
  guestSignature: string | null;
  city: string | null;
  ipAddress: string | null;
  gpsLocation: string | null;
  sha256Hash: string | null;
  /** EDL d'entrée lié (SORTIE uniquement — include de la route). */
  linkedInspection?: { scheduledDate: Date } | null;
  rooms: {
    name: string;
    globalState: string;
    comment: string | null;
    items: {
      name: string;
      state: string;
      comment: string | null;
      photoUrl: string | null;
      photoOnUrl: string | null;
      photoOffUrl: string | null;
    }[];
  }[];
};

/** Ligne Prisma → données du générateur (empreinte recalculée si absente). */
function buildStandaloneData(inspection: InspectionRowLike): StandaloneInspectionPdfData {
  return {
    inspection: {
      publicToken: inspection.publicToken,
      propertyName: inspection.propertyName,
      propertyAddress: inspection.propertyAddress,
      ownerName: inspection.ownerName,
      guestName: inspection.guestName,
      type: inspection.type,
      scheduledDate: inspection.scheduledDate,
      status: inspection.status,
      signedAt: inspection.signedAt,
      completedAt: inspection.completedAt,
      cleanlinessScore: inspection.cleanlinessScore,
      cleanlinessComment: inspection.cleanlinessComment,
      // Photo de propreté incluse (dataURL) — décodage tolérant côté PDF.
      cleanlinessPhotoUrl: inspection.cleanlinessPhotoUrl,
      guestSignature: inspection.guestSignature,
      linkedEntranceDate:
        inspection.type === 'SORTIE' ? inspection.linkedInspection?.scheduledDate ?? null : null,
      // Preuve & anti-fraude (v4.110). Empreinte : stockée à la
      // signature ; pour les documents signés avant v4.110 (sans
      // empreinte en base) elle est recalculée à la volée — le
      // contenu d'un document COMPLETED étant figé, elle est stable.
      city: inspection.city,
      ipAddress: inspection.ipAddress,
      gpsLocation: inspection.gpsLocation,
      sha256Hash:
        inspection.sha256Hash ??
        (inspection.status === 'COMPLETED'
          ? computeInspectionSha256({
              publicToken: inspection.publicToken,
              propertyName: inspection.propertyName,
              propertyAddress: inspection.propertyAddress,
              ownerName: inspection.ownerName,
              guestName: inspection.guestName,
              type: inspection.type,
              scheduledDate: inspection.scheduledDate,
              status: inspection.status,
              signedAt: inspection.signedAt,
              cleanlinessScore: inspection.cleanlinessScore,
              cleanlinessComment: inspection.cleanlinessComment,
              cleanlinessPhotoUrl: inspection.cleanlinessPhotoUrl,
              guestSignature: inspection.guestSignature,
              rooms: inspection.rooms.map((room) => ({
                name: room.name,
                globalState: room.globalState,
                comment: room.comment,
                items: room.items.map((item) => ({
                  name: item.name,
                  state: item.state,
                  comment: item.comment,
                  photoUrl: item.photoUrl,
                  photoOnUrl: item.photoOnUrl,
                  photoOffUrl: item.photoOffUrl,
                })),
              })),
            })
          : null),
    },
    rooms: inspection.rooms.map((room) => ({
      name: room.name,
      globalState: room.globalState,
      comment: room.comment,
      items: room.items.map((item) => ({
        name: item.name,
        state: item.state,
        comment: item.comment,
        photoUrl: item.photoUrl,
        photoOnUrl: item.photoOnUrl,
        photoOffUrl: item.photoOffUrl,
      })),
    })),
  };
}

/** Poids du dernier PDF généré (affichage Documents) — never-throw. */
async function persistPdfSize(inspectionId: string, sizeBytes: number): Promise<void> {
  try {
    await db.inspection.update({ where: { id: inspectionId }, data: { pdfSizeBytes: sizeBytes } });
  } catch (error) {
    console.error('[inspection.pdf] persist pdfSizeBytes failed:', error);
  }
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ token: string }> },
): Promise<Response> {
  try {
    const { token } = await params;
    if (!token || typeof token !== 'string' || token.length < 6) {
      return NextResponse.json({ error: 'Lien invalide ou expiré.' }, { status: 404 });
    }

    // Génération coûteuse (pdfkit + QR) : 20/min par token+IP.
    const ip = clientIp(req.headers) ?? 'local';
    if (!(await rateLimit(`insppdf:${token}:${ip}`, 20))) {
      return NextResponse.json(
        { error: 'Trop de téléchargements. Merci de patienter une minute.' },
        { status: 429 },
      );
    }

    // Chargement complet : pièces + EDL lié (pour la fusion entrée/sortie).
    const inspection = await db.inspection.findUnique({
      where: { publicToken: token },
      include: {
        rooms: {
          orderBy: { sortOrder: 'asc' },
          include: { items: { orderBy: { sortOrder: 'asc' } } },
        },
        linkedInspection: {
          include: {
            rooms: {
              orderBy: { sortOrder: 'asc' },
              include: { items: { orderBy: { sortOrder: 'asc' } } },
            },
          },
        },
      },
    });
    if (!inspection) {
      return NextResponse.json({ error: 'Lien invalide ou expiré.' }, { status: 404 });
    }

    const token6 = inspection.publicToken.slice(-6).toUpperCase();

    // ── FUSION : SORTIE liée à son ENTRÉE → document complet ──
    if (inspection.type === 'SORTIE' && inspection.linkedInspection) {
      const linked = inspection.linkedInspection;
      const [entranceBuf, exitBuf] = await Promise.all([
        renderStandaloneInspectionPdf(buildStandaloneData(linked)),
        renderStandaloneInspectionPdf(buildStandaloneData(inspection)),
      ]);
      const buffer = await mergePdfsWithCoverPage([entranceBuf, exitBuf], {
        propertyName: inspection.propertyName,
        propertyAddress: inspection.propertyAddress,
        guestName: inspection.guestName,
        eventDate: inspection.scheduledDate,
        parts: [
          `Attestation d'état des lieux d'entrée${linked.scheduledDate ? ` — ${linked.scheduledDate.toLocaleDateString('fr-FR')}` : ''}`,
          `Rapport de sortie — comparatif entrée / sortie${inspection.scheduledDate ? ` — ${inspection.scheduledDate.toLocaleDateString('fr-FR')}` : ''}`,
        ],
      });

      await persistPdfSize(inspection.id, buffer.length);

      return new Response(new Uint8Array(buffer), {
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': pdfContentDisposition(`état-des-lieux-complet-${token6}.pdf`),
          'Cache-Control': 'no-store',
        },
      });
    }

    // ── Document simple (ENTRÉE, SORTIE non liée, brouillon…) ──
    const buffer = await renderStandaloneInspectionPdf(buildStandaloneData(inspection));

    await persistPdfSize(inspection.id, buffer.length);

    const typeSlug = inspection.type === 'SORTIE' ? 'sortie' : 'entrée';
    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': pdfContentDisposition(`état-des-lieux-${typeSlug}-${token6}.pdf`),
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    captureError('inspection.public_pdf', error);
    return NextResponse.json(
      { error: 'Impossible de générer le PDF pour le moment. Merci de réessayer.' },
      { status: 500 },
    );
  }
}
