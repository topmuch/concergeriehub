// =============================================================
// /api/shield/ai/analyze — ROOMSCAN BOUCLIER PREMIUM (v5.4)
// POST : DÉTECTION SMART d'une photo de zone (vision IA serveur).
//   corps : { roomName: string, photo: dataURL image/jpeg|png }
//   réponse : { ok:true, analysis:{ hasAnomaly, description,
//     severity 'LOW'|'MEDIUM'|'HIGH', suggestedAction,
//     boundingBox?, model, analyzedAt } }
// Le résultat est renvoyé au cleaner pour CONFIRMATION (l'humain
// garde la main) puis scellé dans la session via /api/shield/session.
// Auth : abonnement Shield actif · rate-limit anti-abus.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { resolveShieldAccess } from '@/lib/shield-access';
import { rateLimit } from '@/lib/rate-limit';
import { analyzeRoomPhoto } from '@/lib/ai-vision';

const MAX_PHOTO_B64 = 4_200_000; // ~3,1 Mo décodés (photos compressées client ≈ 500 Ko)

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

export async function POST(req: NextRequest) {
  try {
    const access = await resolveShieldAccess();
    if (!access.ok) {
      return NextResponse.json(
        { error: access.error, message: access.message },
        { status: access.status },
      );
    }
    // 20 analyses / minute / utilisateur (6 zones + marge de reprise).
    if (!(await rateLimit(`shield-ai:${access.userId}`, 20))) {
      return bad('rate_limited', 429, 'Trop d\u2019analyses — patientez une minute.');
    }

    const body = (await req.json().catch(() => null)) as {
      roomName?: unknown;
      photo?: unknown;
    } | null;
    if (!body) return bad('corps_invalide');

    const roomName =
      typeof body.roomName === 'string' && body.roomName.trim()
        ? body.roomName.trim().slice(0, 80)
        : 'Zone';
    const photo = typeof body.photo === 'string' ? body.photo : '';
    if (!photo.startsWith('data:image/')) return bad('photo_manquante');
    if (photo.length > MAX_PHOTO_B64) {
      return bad('photo_trop_lourde', 413, 'Photo trop lourde pour l\u2019analyse.');
    }

    const analysis = await analyzeRoomPhoto(photo, roomName);
    return NextResponse.json({ ok: true, analysis });
  } catch (err) {
    console.error('[shield/ai/analyze] POST failed:', err);
    return NextResponse.json(
      {
        ok: true,
        analysis: {
          hasAnomaly: false,
          description: 'Erreur d\u2019analyse IA — vérification manuelle requise.',
          severity: 'LOW',
          suggestedAction: 'Vérification manuelle requise',
          model: 'fallback',
          analyzedAt: new Date().toISOString(),
        },
      },
      { status: 200 },
    );
  }
}
