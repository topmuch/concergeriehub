// =============================================================
// /api/shield/properties — ROOMSCAN BOUCLIER AUTOMATISÉ (v5.1)
// GET : liste des logements onboardés de l'abonnement + état de
// l'abonnement (pour la bannière d'expiration du dashboard).
// v5.3 (Task 3-b) : lastSessionType (verrou entrée/sortie par carte)
// + lastCheckinAt (widget « Dernier check-in ») — champs ADDITIFS,
// la réponse existante reste inchangée.
// =============================================================
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { resolveShieldAccess } from '@/lib/shield-access';

export async function GET() {
  try {
    const access = await resolveShieldAccess();
    if (!access.ok) {
      return NextResponse.json(
        { error: access.error, message: access.message },
        { status: access.status },
      );
    }

    const properties = await db.shieldProperty.findMany({
      where: { subscriptionId: access.subscriptionId },
      orderBy: { onboardedAt: 'desc' },
      select: {
        id: true,
        propertyName: true,
        propertyAddress: true,
        city: true,
        ownerName: true,
        onboardingRef: true,
        onboardedAt: true,
        _count: { select: { devices: true, zones: true, sessions: true } },
        sessions: {
          orderBy: { completedAt: 'desc' },
          take: 1,
          select: { completedAt: true, type: true },
        },
      },
    });
    const subscription = await db.inspectionSubscription.findUnique({
      where: { id: access.subscriptionId },
      select: { status: true, endDate: true },
    });

    // v5.3 (Task 3-b) — dernier CHECK_IN par logement (widget carte) :
    // distinct propertyId sur un tri desc → la 1re occurrence = la plus
    // récente (dédupliqué côté Prisma, compatible SQLite).
    const ids = properties.map((p) => p.id);
    const lastCheckins =
      ids.length > 0
        ? await db.shieldSession.findMany({
            where: { propertyId: { in: ids }, type: 'CHECK_IN' },
            orderBy: { completedAt: 'desc' },
            select: { propertyId: true, completedAt: true },
            distinct: ['propertyId'],
          })
        : [];
    const lastCheckinById = new Map(lastCheckins.map((s) => [s.propertyId, s.completedAt]));

    return NextResponse.json({
      properties: properties.map((p) => ({
        id: p.id,
        propertyName: p.propertyName,
        propertyAddress: p.propertyAddress,
        city: p.city,
        ownerName: p.ownerName,
        onboardingRef: p.onboardingRef,
        onboardedAt: p.onboardedAt.toISOString(),
        devicesCount: p._count.devices,
        zonesCount: p._count.zones,
        sessionsCount: p._count.sessions,
        lastSessionAt: p.sessions[0]?.completedAt?.toISOString() ?? null,
        // v5.3 (Task 3-b) — type de la dernière session ('CHECK_IN' | 'CHECK_OUT' | null)
        // → verrou « entrée générée » calculable directement sur la carte.
        lastSessionType: p.sessions[0]?.type ?? null,
        // Date du dernier CHECK_IN (widget « Dernier check-in »).
        lastCheckinAt: lastCheckinById.get(p.id)?.toISOString() ?? null,
      })),
      subscription: subscription
        ? { status: subscription.status, endDate: subscription.endDate.toISOString() }
        : null,
    });
  } catch (err) {
    console.error('[shield/properties] GET failed:', err);
    return NextResponse.json({ error: 'server_error' }, { status: 500 });
  }
}
