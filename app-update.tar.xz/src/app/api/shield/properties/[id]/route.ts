// =============================================================
// /api/shield/properties/[id] — ROOMSCAN BOUCLIER AUTOMATISÉ
// GET : détail d'un logement onboardé — bibliothèque de référence
// (appareils + QR + hash), zones (photos fantômes) et historique
// des sessions (check-in / check-out) avec liens PDF + vidéo.
//
// PATCH (v4.125, fusion) — ONGLET « PARAMÈTRES » (ex-Bouclier) :
// l'hôte met à jour son bien quand il a refait la peinture /
// changé la décoration ou renouvelé un appareil :
//   • zoneCreates / zoneUpdates (nom + photo de référence) /
//     zoneDeletes — les photos de l'appartement (zones) ;
//   • deviceCreates / deviceUpdates (nom + kind + photo) /
//     deviceDeletes — électroménagers, électroniques, divers.
// Chaque nouvelle photo reçoit un SHA-256 (referenceHash) et un
// code REF-{KIND}-{date} unique ; les sessions passées restent
// intactes (shots dénormalisés).
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { createHash, randomUUID } from 'crypto';
import { db } from '@/lib/db';
import {
  resolveShieldAccess,
  shieldPropertyOwned,
  decodePhotoDataUrl,
} from '@/lib/shield-access';
import { deviceRefCode } from '@/lib/shield-refs';

const MAX_ZONES = 12;
const MAX_DEVICES = 24;

// Kinds autorisés : codes métier existants + catégories de l'onglet
// Paramètres (ELECTRO / ELECTRONIQUE / DIVERS pour les libres).
const KINDS = new Set([
  'PLQ', 'MO', 'FRIGO', 'LV', 'FOUR', 'CLMS', 'CLC1', 'CLC2',
  'LAV', 'SEC', 'TV', 'SCH', 'COFFRE', 'BUIL',
  'ELECTRO', 'ELECTRONIQUE', 'DIVERS', 'CUSTOM',
]);

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

function cleanName(value: unknown, min: number, max: number): string | null {
  if (typeof value !== 'string') return null;
  const name = value.replace(/\s+/g, ' ').trim();
  if (name.length < min || name.length > max) return null;
  return name.toUpperCase();
}

/** Code REF unique (retry avec suffixe aléatoire en cas de collision). */
async function uniqueRefCode(kind: string): Promise<string> {
  const now = new Date();
  for (let attempt = 0; attempt < 6; attempt++) {
    const base = deviceRefCode(kind, now);
    const code = attempt === 0 ? base : `${base.slice(0, 12)}${randomUUID().slice(0, 4).toUpperCase()}`;
    const exists = await db.shieldDevice.findUnique({ where: { referenceCode: code }, select: { id: true } });
    if (!exists) return code;
  }
  return `REF-${kind.slice(0, 8)}-${randomUUID().slice(0, 10).toUpperCase()}`;
}

function photoHash(dataUrl: string): string {
  const buf = Buffer.from(dataUrl.replace(/^data:image\/\w+;base64,/, ''), 'base64');
  return createHash('sha256').update(buf).digest('hex');
}

interface ZoneOp { id?: unknown; name?: unknown; referencePhoto?: unknown }
interface DeviceOp { id?: unknown; name?: unknown; kind?: unknown; referencePhoto?: unknown }

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const access = await resolveShieldAccess();
    if (!access.ok) {
      return NextResponse.json({ error: access.error, message: access.message }, { status: access.status });
    }
    const { id } = await params;
    const property = await shieldPropertyOwned(id, access.subscriptionId);
    if (!property) {
      return NextResponse.json({ error: 'not_found' }, { status: 404 });
    }

    const body = (await req.json().catch(() => null)) as {
      zoneUpdates?: ZoneOp[];
      zoneCreates?: ZoneOp[];
      zoneDeletes?: unknown;
      deviceUpdates?: DeviceOp[];
      deviceCreates?: DeviceOp[];
      deviceDeletes?: unknown;
    } | null;
    if (!body) return bad('invalid_body');

    const zoneUpdates = Array.isArray(body.zoneUpdates) ? body.zoneUpdates : [];
    const zoneCreates = Array.isArray(body.zoneCreates) ? body.zoneCreates : [];
    const zoneDeletes = Array.isArray(body.zoneDeletes)
      ? body.zoneDeletes.filter((x): x is string => typeof x === 'string')
      : [];
    const deviceUpdates = Array.isArray(body.deviceUpdates) ? body.deviceUpdates : [];
    const deviceCreates = Array.isArray(body.deviceCreates) ? body.deviceCreates : [];
    const deviceDeletes = Array.isArray(body.deviceDeletes)
      ? body.deviceDeletes.filter((x): x is string => typeof x === 'string')
      : [];

    if (
      zoneUpdates.length + zoneCreates.length + zoneDeletes.length +
        deviceUpdates.length + deviceCreates.length + deviceDeletes.length ===
      0
    ) {
      return bad('empty_operations', 400, 'Aucune modification détectée.');
    }

    // ── Validation zoneCreates (photo obligatoire) ──
    const parsedZoneCreates: { name: string; photo: string }[] = [];
    for (const op of zoneCreates) {
      const name = cleanName(op.name, 2, 60);
      if (!name) return bad('invalid_zone_name', 400, 'Nom de pièce invalide (2 à 60 caractères).');
      if (typeof op.referencePhoto !== 'string' || !decodePhotoDataUrl(op.referencePhoto)) {
        return bad('invalid_zone_photo', 400, 'Photo de la pièce invalide ou trop lourde.');
      }
      parsedZoneCreates.push({ name, photo: op.referencePhoto });
    }
    // ── Validation zoneUpdates (nom obligatoire, photo optionnelle) ──
    const parsedZoneUpdates: { id: string; name: string; photo: string | null }[] = [];
    for (const op of zoneUpdates) {
      if (typeof op.id !== 'string') return bad('invalid_zone_id');
      const name = cleanName(op.name, 2, 60);
      if (!name) return bad('invalid_zone_name', 400, 'Nom de pièce invalide (2 à 60 caractères).');
      let photo: string | null = null;
      if (op.referencePhoto != null) {
        if (typeof op.referencePhoto !== 'string' || !decodePhotoDataUrl(op.referencePhoto)) {
          return bad('invalid_zone_photo', 400, 'Photo de la pièce invalide ou trop lourde.');
        }
        photo = op.referencePhoto;
      }
      parsedZoneUpdates.push({ id: op.id, name, photo });
    }

    // ── Validation devices ──
    const parsedDeviceCreates: { name: string; kind: string; photo: string }[] = [];
    for (const op of deviceCreates) {
      const name = cleanName(op.name, 2, 80);
      if (!name) return bad('invalid_device_name', 400, 'Nom d’appareil invalide (2 à 80 caractères).');
      const kind = typeof op.kind === 'string' && KINDS.has(op.kind) ? op.kind : 'DIVERS';
      if (typeof op.referencePhoto !== 'string' || !decodePhotoDataUrl(op.referencePhoto)) {
        return bad('invalid_device_photo', 400, 'Photo de l’appareil invalide ou trop lourde.');
      }
      parsedDeviceCreates.push({ name, kind, photo: op.referencePhoto });
    }
    const parsedDeviceUpdates: { id: string; name: string | null; kind: string | null; photo: string | null }[] = [];
    for (const op of deviceUpdates) {
      if (typeof op.id !== 'string') return bad('invalid_device_id');
      const name = op.name != null ? cleanName(op.name, 2, 80) : null;
      if (op.name != null && !name) {
        return bad('invalid_device_name', 400, 'Nom d’appareil invalide (2 à 80 caractères).');
      }
      const kind =
        op.kind != null
          ? typeof op.kind === 'string' && KINDS.has(op.kind)
            ? op.kind
            : null
          : null;
      let photo: string | null = null;
      if (op.referencePhoto != null) {
        if (typeof op.referencePhoto !== 'string' || !decodePhotoDataUrl(op.referencePhoto)) {
          return bad('invalid_device_photo', 400, 'Photo de l’appareil invalide ou trop lourde.');
        }
        photo = op.referencePhoto;
      }
      parsedDeviceUpdates.push({ id: op.id, name, kind, photo });
    }

    // ── Limites de volume ──
    const zonesCount = await db.shieldZone.count({ where: { propertyId: property.id } });
    if (zonesCount - zoneDeletes.length + parsedZoneCreates.length > MAX_ZONES) {
      return bad('too_many_zones', 400, `Maximum ${MAX_ZONES} pièces.`);
    }
    const devicesCount = await db.shieldDevice.count({ where: { propertyId: property.id } });
    if (devicesCount - deviceDeletes.length + parsedDeviceCreates.length > MAX_DEVICES) {
      return bad('too_many_devices', 400, `Maximum ${MAX_DEVICES} appareils.`);
    }

    // ── Application (transaction) ──
    const result = await db.$transaction(async (tx) => {
      // Zones — suppression
      if (zoneDeletes.length) {
        await tx.shieldZone.deleteMany({
          where: { id: { in: zoneDeletes }, propertyId: property.id },
        });
      }
      // Zones — mise à jour (nom + photo optionnelle)
      for (const z of parsedZoneUpdates) {
        await tx.shieldZone.updateMany({
          where: { id: z.id, propertyId: property.id },
          data: {
            name: z.name,
            ...(z.photo ? { referencePhoto: z.photo } : {}),
          },
        });
      }
      // Zones — création
      const createdZones: string[] = [];
      for (const z of parsedZoneCreates) {
        const zone = await tx.shieldZone.create({
          data: {
            propertyId: property.id,
            name: z.name,
            referencePhoto: z.photo,
            sortOrder: zonesCount + parsedZoneCreates.length,
          },
          select: { id: true },
        });
        createdZones.push(zone.id);
      }
      // Devices — suppression
      if (deviceDeletes.length) {
        await tx.shieldDevice.deleteMany({
          where: { id: { in: deviceDeletes }, propertyId: property.id },
        });
      }
      // Devices — mise à jour
      for (const d of parsedDeviceUpdates) {
        const existing = await tx.shieldDevice.findFirst({
          where: { id: d.id, propertyId: property.id },
          select: { id: true, kind: true },
        });
        if (!existing) continue;
        let referenceHash: string | undefined;
        let referenceCode: string | undefined;
        if (d.photo) {
          referenceHash = photoHash(d.photo);
          referenceCode = await uniqueRefCode(d.kind ?? existing.kind);
        }
        await tx.shieldDevice.update({
          where: { id: existing.id },
          data: {
            ...(d.name ? { name: d.name } : {}),
            ...(d.kind ? { kind: d.kind } : {}),
            ...(d.photo ? { referencePhoto: d.photo, referenceHash, referenceCode, referenceDate: new Date() } : {}),
          },
        });
      }
      // Devices — création
      const createdDevices: string[] = [];
      for (const d of parsedDeviceCreates) {
        const device = await tx.shieldDevice.create({
          data: {
            propertyId: property.id,
            name: d.name,
            kind: d.kind,
            referencePhoto: d.photo,
            referenceHash: photoHash(d.photo),
            referenceCode: await uniqueRefCode(d.kind),
            referenceDate: new Date(),
            sortOrder: devicesCount + parsedDeviceCreates.length,
          },
          select: { id: true },
        });
        createdDevices.push(device.id);
      }
      await tx.shieldProperty.update({
        where: { id: property.id },
        data: { updatedAt: new Date() },
      });
      return { createdZones, createdDevices };
    });

    return NextResponse.json({
      ok: true,
      createdZones: result.createdZones,
      createdDevices: result.createdDevices,
    });
  } catch (err) {
    console.error('[shield/properties/:id PATCH] failed:', err);
    return NextResponse.json({ error: 'server_error' }, { status: 500 });
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const access = await resolveShieldAccess();
    if (!access.ok) {
      return NextResponse.json(
        { error: access.error, message: access.message },
        { status: access.status },
      );
    }
    const { id } = await params;

    const property = await shieldPropertyOwned(id, access.subscriptionId);
    if (!property) {
      return NextResponse.json({ error: 'not_found' }, { status: 404 });
    }

    const sessions = await db.shieldSession.findMany({
      where: { propertyId: property.id },
      orderBy: { completedAt: 'desc' },
      take: 100,
      include: {
        video: { select: { publicToken: true, sha256: true, durationSec: true } },
        shots: { select: { status: true, aiAnalysis: true } },
      },
    });

    return NextResponse.json({
      property: {
        id: property.id,
        propertyName: property.propertyName,
        propertyAddress: property.propertyAddress,
        city: property.city,
        ownerName: property.ownerName,
        onboardingRef: property.onboardingRef,
        onboardedAt: property.onboardedAt.toISOString(),
      },
      zones: property.zones.map((z) => ({
        id: z.id,
        name: z.name,
        referencePhoto: z.referencePhoto,
        sortOrder: z.sortOrder,
      })),
      devices: (await db.shieldDevice.findMany({
        where: { propertyId: property.id },
        orderBy: { sortOrder: 'asc' },
      })).map((d) => ({
        id: d.id,
        name: d.name,
        kind: d.kind,
        referenceCode: d.referenceCode,
        referenceHash: d.referenceHash,
        referencePhoto: d.referencePhoto,
        referenceDate: d.referenceDate.toISOString(),
        sortOrder: d.sortOrder,
      })),
      sessions: sessions.map((s) => ({
        id: s.id,
        type: s.type,
        agentName: s.agentName,
        sessionRef: s.sessionRef,
        linkedSessionId: s.linkedSessionId, // v4.120 — verrouillage lecture seule côté UI
        completedAt: s.completedAt.toISOString(),
        videoToken: s.video?.publicToken ?? null,
        videoSha256: s.video?.sha256 ?? null,
        durationSec: s.video?.durationSec ?? null,
        impeccableCount: s.shots.filter((x) => x.status === 'IMPECCABLE').length,
        degradationCount: s.shots.filter((x) => x.status === 'DEGRADATION').length,
        shotsCount: s.shots.length,
        // PREMIUM v5.4 — Détection Smart (badge IA dans l'historique)
        aiAnomalyCount: s.shots.filter(
          (x) =>
            x.aiAnalysis &&
            typeof x.aiAnalysis === 'object' &&
            (x.aiAnalysis as { hasAnomaly?: unknown }).hasAnomaly === true,
        ).length,
        aiGlobalState:
          s.aiAnalysis && typeof s.aiAnalysis === 'object'
            ? ((s.aiAnalysis as { globalState?: string }).globalState ?? null)
            : null,
      })),
    });
  } catch (err) {
    console.error('[shield/properties/:id] GET failed:', err);
    return NextResponse.json({ error: 'server_error' }, { status: 500 });
  }
}
