// =============================================================
// /api/shield/session — ROOMSCAN BOUCLIER AUTOMATISÉ (v5.1 + PREMIUM v5.4)
//
// POST : CHECK-IN ou CHECK-OUT en 90 secondes.
//   · 6 photos de zones aux mêmes angles (fantômes de référence) ;
//   · 1 vidéo walkthrough (jusqu'à 60 s — traversée continue des
//     zones, ≤ 22 Mo) dont le hash SHA-256 est calculé SERVEUR
//     (intégrité non falsifiable) ;
//   · PREMIUM — Détection Smart : chaque photo peut porter son
//     analyse IA (anomalie, sévérité, boundingBox) validée par
//     l'agent ; la synthèse globale est recalculée SERVEUR ;
//   · PREMIUM — traçabilité légale : GPS (lat,lng) + IP de l'agent
//     + hash SHA-256 GLOBAL de la session (photos + vidéo + méta).
// Un CHECK_OUT est automatiquement LIÉ au dernier CHECK_IN du
// logement (PDF comparatif entrée vs sortie + RAPPORT DELTA).
//
// Corps JSON :
// {
//   propertyId, type: 'CHECK_IN'|'CHECK_OUT', agentName,
//   guestName?, guestEmail?,              // optionnel — destinataires du PDF
//   gpsLocation?,                          // « lat,lng » (optionnel)
//   shots: [{ zoneId, photo(dataURL), status, comment?,
//             aiAnalysis? { hasAnomaly, description, severity,
//                           suggestedAction, boundingBox? } } × 6],
//   video: { mimeType, durationSec, dataBase64 }
// }
// Réponse 201 : { ok:true, session:{ id, sessionRef, type,
//   completedAt, videoToken, videoSha256, sha256Hash, aiAnalysis },
//   pdfUrl, emailsQueued }
// Effet : le PDF final (bibliothèque + certificat + rapport Delta)
// est envoyé AUTOMATIQUEMENT par email à l'hôte + à l'invité.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { createHash } from 'crypto';
import { Prisma } from '@prisma/client';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import {
  resolveShieldAccess,
  shieldPropertyOwned,
  decodePhotoDataUrl,
  decodeVideoBase64,
  MAX_VIDEO_BYTES,
} from '@/lib/shield-access';
import { sessionRef, randomPublicToken, SHIELD_ZONE_STATUSES } from '@/lib/shield-refs';
import { sendShieldSessionCertificateEmails } from '@/lib/shield-emails';
import { summarizeSessionAnalysis, type RoomPhotoAnalysis } from '@/lib/ai-vision';

function bad(error: string, status = 400, message?: string) {
  return NextResponse.json({ error, message }, { status });
}

/**
 * PREMIUM — Valide/normalise l'analyse IA fournie par le client
 * (défense en profondeur : seuls les champs connus sont conservés,
 * coordonnées bornées 0–1). null si absente/illisible.
 */
function sanitizeShotAiAnalysis(raw: unknown): RoomPhotoAnalysis | null {
  if (!raw || typeof raw !== 'object') return null;
  const a = raw as Record<string, unknown>;
  if (typeof a.hasAnomaly !== 'boolean') return null;
  const bb =
    a.boundingBox && typeof a.boundingBox === 'object'
      ? (a.boundingBox as Record<string, unknown>)
      : null;
  const num = (v: unknown) =>
    typeof v === 'number' && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : null;
  const bx = bb ? num(bb.x) : null;
  const by = bb ? num(bb.y) : null;
  const bw = bb ? num(bb.width) : null;
  const bh = bb ? num(bb.height) : null;
  return {
    hasAnomaly: a.hasAnomaly,
    description: typeof a.description === 'string' ? a.description.trim().slice(0, 400) : '',
    severity: a.severity === 'MEDIUM' || a.severity === 'HIGH' ? a.severity : 'LOW',
    suggestedAction:
      typeof a.suggestedAction === 'string' ? a.suggestedAction.trim().slice(0, 300) : '',
    boundingBox:
      a.hasAnomaly && bx !== null && by !== null && bw !== null && bh !== null && bw > 0 && bh > 0
        ? { x: bx, y: by, width: bw, height: bh }
        : undefined,
    model: typeof a.model === 'string' ? a.model.slice(0, 40) : 'unknown',
    analyzedAt:
      typeof a.analyzedAt === 'string' ? a.analyzedAt.slice(0, 40) : new Date().toISOString(),
  };
}

export async function POST(req: NextRequest) {
  try {
    const access = await resolveShieldAccess();
    if (!access.ok) {
      return NextResponse.json(
        { error: access.error, message: access.message },
        { status: access.status },
      );
    }
    if (!(await rateLimit(`shield-session:${access.userId}`, 12))) {
      return bad('rate_limited', 429, 'Trop de tentatives — réessayez dans une minute.');
    }

    const body = (await req.json().catch(() => null)) as {
      propertyId?: unknown;
      type?: unknown;
      agentName?: unknown;
      guestName?: unknown;
      guestEmail?: unknown;
      gpsLocation?: unknown;
      shots?: unknown;
      video?: unknown;
    } | null;
    if (!body) return bad('corps_invalide');

    const propertyId = typeof body.propertyId === 'string' ? body.propertyId : '';
    const type = body.type === 'CHECK_OUT' ? 'CHECK_OUT' : body.type === 'CHECK_IN' ? 'CHECK_IN' : '';
    const agentName = typeof body.agentName === 'string' ? body.agentName.trim().slice(0, 80) : '';
    const guestName =
      typeof body.guestName === 'string' && body.guestName.trim()
        ? body.guestName.trim().slice(0, 80)
        : null;
    const guestEmailRaw =
      typeof body.guestEmail === 'string' && body.guestEmail.trim()
        ? body.guestEmail.trim().slice(0, 160)
        : '';
    const guestEmail = guestEmailRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guestEmailRaw) ? guestEmailRaw : null;
    if (!propertyId) return bad('logement_manquant');
    if (!type) return bad('type_invalide');
    if (!agentName) return bad('agent_manquant', 400, "Le nom de l'agent est obligatoire (traçabilité).");

    // ── Logement + zones ──
    const property = await shieldPropertyOwned(propertyId, access.subscriptionId);
    if (!property) return bad('not_found', 404);

    // ── LECTURE SEULE (v4.120) : document généré = logement verrouillé ──
    // Dès qu'un certificat est généré, on ne peut plus refaire le même
    // contrôle : CHECK-IN bloqué tant que le cycle (entrée→sortie) n'est
    // pas terminé ; CHECK-OUT bloqué dès que la sortie de ce cycle existe.
    // Un nouveau CHECK-IN (nouveau séjour) rouvre un cycle après la sortie.
    const lastCheckIn = await db.shieldSession.findFirst({
      where: { propertyId, type: 'CHECK_IN' },
      orderBy: { completedAt: 'desc' },
      select: { id: true },
    });
    if (lastCheckIn) {
      const outLinked = await db.shieldSession.findFirst({
        where: { propertyId, type: 'CHECK_OUT', linkedSessionId: lastCheckIn.id },
        select: { id: true },
      });
      if (type === 'CHECK_IN' && !outLinked) {
        return bad(
          'lecture_seule',
          409,
          "Le document d'entrée de ce logement a déjà été généré — lecture seule. Un nouveau CHECK-IN sera possible après le CHECK-OUT.",
        );
      }
      if (type === 'CHECK_OUT' && outLinked) {
        return bad(
          'lecture_seule',
          409,
          'Le rapport de sortie a déjà été généré pour ce cycle — lecture seule. Faites un nouveau CHECK-IN pour démarrer un nouveau cycle.',
        );
      }
    }

    const zonesById = new Map(property.zones.map((z) => [z.id, z]));

    // ── Photos des zones : les 6 zones du logement, chacune une fois ──
    const shotsRaw = Array.isArray(body.shots) ? body.shots : [];
    if (shotsRaw.length !== property.zones.length) {
      return bad(
        'zones_manquantes',
        400,
        `Les ${property.zones.length} zones doivent être photographiées (${shotsRaw.length}/${property.zones.length}).`,
      );
    }
    const seenZoneIds = new Set<string>();
    const shots: {
      zoneId: string;
      zoneName: string;
      photo: string;
      status: string;
      comment: string | null;
      aiAnalysis: RoomPhotoAnalysis | null;
    }[] = [];
    for (const s of shotsRaw) {
      const st = s as {
        zoneId?: unknown;
        photo?: unknown;
        status?: unknown;
        comment?: unknown;
        aiAnalysis?: unknown;
      };
      const zoneId = typeof st?.zoneId === 'string' ? st.zoneId : '';
      const zone = zonesById.get(zoneId);
      if (!zone) return bad('zone_inconnue');
      if (seenZoneIds.has(zoneId)) return bad('zone_dupliquee');
      seenZoneIds.add(zoneId);
      const photo = typeof st?.photo === 'string' ? st.photo : '';
      if (!decodePhotoDataUrl(photo)) return bad(`photo_invalide:${zone.name}`);
      const status =
        typeof st?.status === 'string' && (SHIELD_ZONE_STATUSES as readonly string[]).includes(st.status)
          ? st.status
          : 'IMPECCABLE';
      const aiAnalysis = sanitizeShotAiAnalysis(st?.aiAnalysis);
      let comment =
        typeof st?.comment === 'string' && st.comment.trim() ? st.comment.trim().slice(0, 500) : null;
      // Filet de sécurité « zéro blocage » : statut non impeccable sans
      // commentaire, mais analyse IA présente → la description IA sert
      // de constat (l'agent a validé l'encadrement + la description).
      if (status !== 'IMPECCABLE' && !comment && aiAnalysis?.description) {
        comment = `[IA] ${aiAnalysis.description}`.slice(0, 500);
      }
      if (status !== 'IMPECCABLE' && !comment) {
        return bad(
          'commentaire_requis',
          400,
          `Zone ${zone.name} : un commentaire est obligatoire si l'état n'est pas impeccable.`,
        );
      }
      shots.push({ zoneId, zoneName: zone.name, photo, status, comment, aiAnalysis });
    }

    // ── Vidéo walkthrough (preuve reine) ──
    const v = (body.video ?? {}) as { mimeType?: unknown; durationSec?: unknown; dataBase64?: unknown };
    const videoBuf = decodeVideoBase64(v.dataBase64, v.mimeType);
    if (!videoBuf) {
      return bad(
        'video_invalide',
        400,
        `Vidéo obligatoire (jusqu'à 60 s). Formats : webm/mp4 — max ${Math.round(MAX_VIDEO_BYTES / 1_000_000)} Mo.`,
      );
    }
    const durationSec =
      typeof v.durationSec === 'number' && Number.isFinite(v.durationSec)
        ? Math.min(180, Math.max(3, Math.round(v.durationSec)))
        : 60;

    // ── PREMIUM — Traçabilité légale (GPS + IP de l'agent) ──
    const gpsLocation =
      typeof body.gpsLocation === 'string' && /^[-0-9.,\s]{5,64}$/.test(body.gpsLocation.trim())
        ? body.gpsLocation.trim().slice(0, 64)
        : null;
    const agentIp = (
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip')?.trim() ||
      ''
    ).slice(0, 64) || null;

    // ── PREMIUM — Hash SHA-256 GLOBAL de la session (photos + vidéo + méta) ──
    // Recalculé SERVEUR sur les octets réels reçus — non falsifiable.
    const hashInput: Buffer[] = [
      Buffer.from(`RS1|${propertyId}|${type}|${agentName}|${shots.length}|`),
    ];
    for (const s of shots) {
      hashInput.push(Buffer.from(s.photo.split(',')[1] ?? '', 'base64'));
    }
    hashInput.push(videoBuf);
    const sessionSha256 = createHash('sha256').update(Buffer.concat(hashInput)).digest('hex');

    // ── PREMIUM — Synthèse IA globale (recalculée SERVEUR) ──
    const photoAnalyses = shots
      .map((s) => s.aiAnalysis)
      .filter((a): a is RoomPhotoAnalysis => a !== null);
    const sessionAi =
      photoAnalyses.length > 0 ? summarizeSessionAnalysis(photoAnalyses) : null;

    // ── Liaison automatique au dernier CHECK_IN (pour comparatif) ──
    let linkedSessionId: string | null = null;
    if (type === 'CHECK_OUT') {
      const lastCheckIn = await db.shieldSession.findFirst({
        where: { propertyId, type: 'CHECK_IN' },
        orderBy: { completedAt: 'desc' },
        select: { id: true },
      });
      linkedSessionId = lastCheckIn?.id ?? null;
    }

    // ── Référence session (séquence du jour) + création ──
    const now = new Date();
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const dayCount = await db.shieldSession.count({
      where: { propertyId, createdAt: { gte: dayStart } },
    });

    let created: {
      id: string;
      sessionRef: string;
      type: string;
      completedAt: Date;
      sha256Hash: string | null;
      aiAnalysis: Prisma.JsonValue | null;
    } | null = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      const videoToken = randomPublicToken();
      const ref = sessionRef(property.city, now, dayCount + 1 + attempt);
      try {
        created = await db.$transaction(async (tx) => {
          const sess = await tx.shieldSession.create({
            data: {
              propertyId,
              type,
              agentName,
              guestName,
              guestEmail,
              sessionRef: ref,
              linkedSessionId,
              status: 'COMPLETED',
              // Les interfaces RoomPhotoAnalysis/SessionAiSummary n'ont pas de
              // signature d'index → cast explicite vers InputJsonValue (JSON
              // colonne Prisma). Aucun changement de valeur à l'exécution.
              aiAnalysis: sessionAi
                ? (sessionAi as unknown as Prisma.InputJsonValue)
                : undefined,
              gpsLocation,
              ipAddress: agentIp,
              sha256Hash: sessionSha256,
            },
          });
          await tx.shieldZoneShot.createMany({
            data: shots.map((s) => ({
              sessionId: sess.id,
              zoneId: s.zoneId,
              zoneName: s.zoneName,
              photo: s.photo,
              status: s.status,
              comment: s.comment,
              aiAnalysis: s.aiAnalysis
                ? (s.aiAnalysis as unknown as Prisma.InputJsonValue)
                : undefined,
            })),
          });
          await tx.shieldVideo.create({
            data: {
              sessionId: sess.id,
              publicToken: videoToken,
              mimeType: typeof v.mimeType === 'string' ? v.mimeType : 'video/webm',
              data: new Uint8Array(videoBuf),
              sizeBytes: videoBuf.length,
              durationSec,
              sha256: createHash('sha256').update(videoBuf).digest('hex'),
            },
          });
          return sess;
        });
        break;
      } catch (e) {
        const code = (e as { code?: string })?.code;
        if (code !== 'P2002' || attempt === 4) throw e;
      }
    }

    const video = await db.shieldVideo.findUnique({
      where: { sessionId: created!.id },
      select: { publicToken: true, sha256: true },
    });

    // Envoi AUTOMATIQUE du PDF final à l'hôte + à l'invité (pièce
    // jointe) — fire-and-forget : ne bloque JAMAIS la réponse et ne
    // lève jamais (lib blindé).
    void sendShieldSessionCertificateEmails(created!.id, access.subscriptionId);

    return NextResponse.json(
      {
        ok: true,
        session: {
          id: created!.id,
          sessionRef: created!.sessionRef,
          type: created!.type,
          completedAt: created!.completedAt.toISOString(),
          videoToken: video?.publicToken ?? null,
          videoSha256: video?.sha256 ?? null,
          sha256Hash: created!.sha256Hash ?? null,
          aiAnalysis: created!.aiAnalysis ?? null,
        },
        pdfUrl: `/api/shield/pdf/session/${created!.id}`,
        emailsQueued: true,
      },
      { status: 201 },
    );
  } catch (err) {
    console.error('[shield/session] POST failed:', err);
    return NextResponse.json({ error: 'server_error' }, { status: 500 });
  }
}
