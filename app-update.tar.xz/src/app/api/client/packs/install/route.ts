import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PACKS } from '@/lib/packs-config';
import crypto from 'crypto';

// POST: Install a pack into a home
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { propertyId, packId, userId } = body as {
      propertyId: string;
      packId: string;
      userId?: string;
    };

    if (!propertyId || !packId) {
      return NextResponse.json(
        { error: 'Champs requis: propertyId, packId' },
        { status: 400 }
      );
    }

    // Find pack definition
    const pack = PACKS.find((p) => p.id === packId);
    if (!pack) {
      return NextResponse.json(
        { error: 'Pack introuvable' },
        { status: 404 }
      );
    }

    // Verify home exists
    const home = await db.property.findUnique({ where: { id: propertyId } });
    if (!home) {
      return NextResponse.json(
        { error: 'Maison introuvable' },
        { status: 404 }
      );
    }

    // Resolve userId for activity logs
    let resolvedUserId = userId;
    if (!resolvedUserId) {
      const member = await db.propertyMember.findFirst({
        where: { propertyId },
      });
      resolvedUserId = member?.userId;
    }

    // Fetch existing QR codes to skip already-installed ones
    const existingQrCodes = await db.qrCode.findMany({
      where: { propertyId, isActive: true },
      select: { type: true, name: true },
    });
    const installedKeys = new Set(
      existingQrCodes.map((qr) => `${qr.type}::${qr.name}`)
    );

    // Collect unique roomNames from the pack
    const roomNames = [...new Set(pack.qrCodes.map((qr) => qr.roomName))];

    let installed = 0;

    await db.$transaction(async (tx) => {
      // Find or create rooms
      const roomMap = new Map<string, string>();

      for (const roomName of roomNames) {
        const existingRoom = await tx.room.findFirst({
          where: { propertyId, name: roomName },
        });

        if (existingRoom) {
          roomMap.set(roomName, existingRoom.id);
        } else {
          const newRoom = await tx.room.create({
            data: { propertyId, name: roomName },
          });
          roomMap.set(roomName, newRoom.id);
        }
      }

      // Create each QR code (skip already installed)
      for (const qrDef of pack.qrCodes) {
        const key = `${qrDef.moduleType}::${qrDef.name}`;
        if (installedKeys.has(key)) continue;

        const roomId = roomMap.get(qrDef.roomName);
        const publicSlug = crypto.randomUUID().slice(0, 8);

        const qrCode = await tx.qrCode.create({
          data: {
            propertyId,
            roomId: roomId || null,
            name: qrDef.name,
            type: qrDef.moduleType,
            publicSlug,
            isActive: true,
          },
        });

        await tx.qrContent.create({
          data: {
            qrCodeId: qrCode.id,
            contentJson: JSON.stringify(qrDef.defaultContent),
          },
        });

        // Activity log
        if (resolvedUserId) {
          await tx.activityLog.create({
            data: {
              propertyId,
              qrCodeId: qrCode.id,
              userId: resolvedUserId,
              actionType: 'qr_activated',
              detailsJson: JSON.stringify({
                qrCodeName: qrDef.name,
                moduleType: qrDef.moduleType,
                packId: pack.id,
                packName: pack.name,
              }),
            },
          });
        }

        installed++;
      }
    });

    return NextResponse.json({
      success: true,
      installed,
      packName: pack.name,
    });
  } catch (error) {
    console.error('[packs install POST] Error:', error);
    const message =
      error instanceof Error ? error.message : 'Erreur interne du serveur';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
