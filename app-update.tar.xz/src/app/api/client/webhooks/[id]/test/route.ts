// =============================================================
// POST /api/client/webhooks/[id]/test — TEST MANUEL D'UN WEBHOOK
//
// v4.73 — FIX « le webhook côté admin hôte n'est pas développé » :
// le composant webhooks-manager appelait cette route mais elle
// N'EXISTAIT PAS → bouton Tester mort. Envoie un payload d'exemple
// à l'URL du webhook (timeout 6 s), met à jour les compteurs
// success/fail + lastTriggerAt, et renvoie le statut HTTP + un
// extrait de la réponse pour l'affichage dans l'UI.
// 🔒 Session + accès au bien rattaché.
// =============================================================
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 401 });
    }
    const userId = (session.user as { id: string }).id;
    const { id } = await params;

    const webhook = await db.webhook.findUnique({
      where: { id },
      include: { property: { select: { id: true, name: true } } },
    });
    if (!webhook) {
      return NextResponse.json({ error: 'Webhook introuvable' }, { status: 404 });
    }
    const home = await db.property.findFirst({
      where: {
        id: webhook.propertyId,
        OR: [{ ownerId: userId }, { members: { some: { userId } } }],
      },
      select: { id: true },
    });
    if (!home) {
      return NextResponse.json({ error: 'Non autorisé' }, { status: 403 });
    }

    // Payload d'exemple — même enveloppe que le dispatcher réel.
    const payload = {
      event: 'test',
      timestamp: new Date().toISOString(),
      source: 'roomscan.hub',
      data: {
        webhookId: webhook.id,
        propertyName: webhook.property?.name ?? null,
        message: 'Ceci est un test envoyé depuis votre espace RoomScan.',
      },
    };

    let success = false;
    let statusCode: number | null = null;
    let response: string;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);
      const res = await fetch(webhook.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-RoomScan-Event': 'test',
          ...(webhook.secret
            ? { 'X-RoomScan-Signature': webhook.secret }
            : {}),
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      clearTimeout(timeout);
      statusCode = res.status;
      success = res.ok;
      const text = await res.text().catch(() => '');
      response = text.slice(0, 240) || `HTTP ${res.status}`;
    } catch (err) {
      response =
        err instanceof Error && err.name === 'AbortError'
          ? 'Délai dépassé (6 s) — le serveur ne répond pas.'
          : 'Connexion impossible — vérifiez l\'URL du webhook.';
    }

    await db.webhook.update({
      where: { id },
      data: {
        lastTriggerAt: new Date(),
        ...(success
          ? { successCount: { increment: 1 } }
          : { failCount: { increment: 1 } }),
      },
    });

    return NextResponse.json({ success, statusCode, response });
  } catch (error) {
    console.error('[webhooks test POST] Error:', error);
    return NextResponse.json(
      { success: false, statusCode: null, response: 'Erreur interne du serveur' },
      { status: 500 },
    );
  }
}
