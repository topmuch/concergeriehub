import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { db } from '@/lib/db';

const VALID_ROLES = ['owner', 'cohost', 'staff', 'cleaner', 'member'];

/**
 * Garde : l'utilisateur doit être propriétaire de la maison ou Superadmin.
 * Retourne la maison si autorisé, sinon null (404/403 déjà envoyés).
 */
async function getAuthorizedHome(id: string): Promise<{ home: { id: string } | null; error?: NextResponse }> {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return { home: null, error: NextResponse.json({ error: 'Non autorisé' }, { status: 401 }) };
  }

  const userId = (session.user as { id?: string }).id;
  const role = (session.user as { role?: string }).role;

  const home = await db.property.findUnique({ where: { id } });
  if (!home) {
    return { home: null, error: NextResponse.json({ error: 'Maison introuvable' }, { status: 404 }) };
  }

  if (home.ownerId !== userId && role !== 'superadmin') {
    return { home: null, error: NextResponse.json({ error: 'Non autorisé' }, { status: 403 }) };
  }

  return { home };
}

// GET: List all members of a home (propriétaire ou Superadmin)
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const { error } = await getAuthorizedHome(id);
    if (error) return error;

    const members = await db.propertyMember.findMany({
      where: { propertyId: id },
      include: {
        user: {
          select: { id: true, email: true, fullName: true },
        },
      },
      orderBy: { joinedAt: 'desc' },
    });

    return NextResponse.json({ members });
  } catch (error) {
    console.error('[homes members GET] Error:', error);
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}

// POST: Invite a new member to a home (propriétaire ou Superadmin)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { email, role, nickname } = body as {
      email: string;
      role?: string;
      nickname?: string;
    };

    if (!email) {
      return NextResponse.json(
        { error: 'L\'email est requis' },
        { status: 400 }
      );
    }

    const memberRole = role || 'member';
    if (!VALID_ROLES.includes(memberRole)) {
      return NextResponse.json(
        { error: 'Rôle invalide. Valeurs autorisées : owner, admin, member, child' },
        { status: 400 }
      );
    }

    if (memberRole === 'owner') {
      return NextResponse.json(
        { error: 'Impossible d\'inviter un membre avec le rôle propriétaire' },
        { status: 400 }
      );
    }

    // Garde d'accès : le propriétaire de la maison (ou Superadmin) seul peut inviter
    const { error } = await getAuthorizedHome(id);
    if (error) return error;

    // Find or create the invited user
    let invitedUser = await db.user.findUnique({ where: { email } });

    if (!invitedUser) {
      invitedUser = await db.user.create({
        data: {
          email,
          fullName: nickname ?? email.split('@')[0],
          role: 'user',
        },
      });
    }

    // Check if already a member
    const existingMember = await db.propertyMember.findUnique({
      where: {
        propertyId_userId: { propertyId: id, userId: invitedUser.id },
      },
    });

    if (existingMember) {
      return NextResponse.json(
        { error: 'Cet utilisateur est déjà membre de cette maison' },
        { status: 409 }
      );
    }

    // Create the PropertyMember record
    const member = await db.propertyMember.create({
      data: {
        propertyId: id,
        userId: invitedUser.id,
        role: memberRole,
        nickname: nickname ?? null,
      },
      include: {
        user: {
          select: { id: true, email: true, fullName: true },
        },
      },
    });

    return NextResponse.json(member, { status: 201 });
  } catch (error) {
    console.error('[homes members POST] Error:', error);
    return NextResponse.json(
      { error: 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}
