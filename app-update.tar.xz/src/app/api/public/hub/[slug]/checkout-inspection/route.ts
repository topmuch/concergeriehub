import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { captureError } from '@/lib/error-monitor';
import { resolveHubPropertyId } from '@/lib/hub-resolve';
import { queueEmail } from '@/lib/email';
import { siteUrl } from '@/lib/site';

// =============================================================
// v5.0 « ÉTAT DES LIEUX DE SORTIE » — route publique du Hub
//
// GET  ?b=<bookingId> : contexte du formulaire — inspection
//      d'ENTRÉE (MinibarCheck) du séjour si elle existe (encart
//      « Votre état des lieux d'entrée a été enregistré le … »)
//      + inventaire d'arrivée connu.
// POST : enregistre l'inspection signée par l'invité :
//   • rooms[] → 5 colonnes de statut + roomsData (détail) ;
//   • photos de dégâts (dataURL compressées client) → damagePhotos ;
//   • inventaire rendu, auto-évaluation, commentaires, signature ;
//   • publicToken UUID → preuve publique /public/inspection/[token] ;
//   • emails invité + hôte (outbox, fire-and-forget) ;
//   • notification hôte (1, plus si dégâts).
// Le PDF est généré À LA DEMANDE par /api/public/inspection/[token]/pdf.
//
// Sécurité : rate limit 3/min par slug+IP ; zod strict (dataURL) ;
// bookingId re-validé par bien (anti IDOR, dégrade sans échouer) ;
// never-throw ; mode démo (slug demo-hub) = succès sans écriture.
// =============================================================

const DEMO_SLUG = 'demo-hub';
const isDemo = (slug: string) => slug === DEMO_SLUG;

/** dataURL image (PNG signature / JPEG photo) — plafond ~700 Ko par image. */
const DATA_URL_MAX = 700_000;
const dataUrlSchema = z
  .string()
  .max(DATA_URL_MAX)
  .regex(/^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=\r\n]+$/, 'Image invalide');

const roomSchema = z.object({
  id: z.enum(['entrance', 'kitchen', 'livingRoom', 'bedrooms', 'bathroom']),
  label: z.string().trim().min(1).max(60),
  status: z.enum(['good', 'dirty', 'damaged']),
  comment: z.string().trim().max(600).optional().nullable(),
  photos: z.array(dataUrlSchema).max(4).optional().nullable(),
});

const inventorySchema = z.object({
  keys: z.number().int().min(0).max(50),
  remotes: z.number().int().min(0).max(50),
  towels: z.number().int().min(0).max(200),
});

const submitSchema = z.object({
  bookingId: z.string().trim().max(60).optional().nullable(),
  guestName: z.string().trim().min(1).max(80),
  guestEmail: z
    .string()
    .trim()
    .max(120)
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]+$/, 'Email invalide')
    .optional()
    .or(z.literal('').transform(() => undefined)),
  rooms: z.array(roomSchema).length(5),
  inventory: inventorySchema,
  selfAssessment: z.number().int().min(1).max(5),
  comments: z.string().trim().max(1000).optional().nullable(),
  signature: dataUrlSchema,
  checkInPublicToken: z.string().trim().max(80).optional().nullable(),
});

function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for');
  if (fwd) return fwd.split(',')[0].trim();
  return req.headers.get('x-real-ip')?.trim() || 'local';
}

/** Statut lisible (emails — accents OK, jamais d'émoji dans le PDF). */
const STATUS_LABEL: Record<string, string> = {
  good: 'Bon état',
  dirty: 'Sale',
  damaged: 'Endommagé',
};

// -------------------------------------------------------------
// GET — contexte du formulaire (inspection d'entrée du séjour)
// -------------------------------------------------------------
export async function GET(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;
    const url = new URL(req.url);
    const rawBookingId = url.searchParams.get('b')?.trim().slice(0, 60) || null;

    if (isDemo(slug)) {
      return NextResponse.json({ demo: true, checkIn: null, inventory: null });
    }

    const resolved = await resolveHubPropertyId(slug);
    if (!resolved.ok) {
      return NextResponse.json({ error: resolved.message }, { status: resolved.status });
    }

    let checkIn: { checkedAt: string; publicToken: string | null } | null = null;
    if (rawBookingId) {
      const booking = await db.booking.findFirst({
        where: { id: rawBookingId, propertyId: resolved.propertyId },
        select: { id: true },
      });
      if (booking) {
        const entry = await db.minibarCheck.findFirst({
          where: { bookingId: booking.id },
          orderBy: { checkedAt: 'desc' },
          select: { checkedAt: true, publicToken: true },
        });
        if (entry) {
          checkIn = { checkedAt: entry.checkedAt.toISOString(), publicToken: entry.publicToken };
        }
      }
    }

    return NextResponse.json({ demo: false, checkIn, inventory: null });
  } catch (error) {
    await captureError('hub.checkout-inspection.GET', error, undefined, req);
    return NextResponse.json({ error: 'Erreur serveur. Réessayez dans un instant.' }, { status: 500 });
  }
}

// -------------------------------------------------------------
// POST — enregistrement de l'inspection de sortie
// -------------------------------------------------------------
export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;

    if (!(await rateLimit(`hubcoi:${slug}:${clientIp(req)}`, 3))) {
      return NextResponse.json(
        { error: 'Trop d’envois rapprochés. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    const rawBody = await req.json().catch(() => null);
    if (!rawBody || typeof rawBody !== 'object') {
      return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const parsed = submitSchema.safeParse(rawBody);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Formulaire invalide.' },
        { status: 400 },
      );
    }
    const data = parsed.data;

    // ── DEMO MODE : succès sans écriture (le formulaire dégrade) ──
    if (isDemo(slug)) {
      return NextResponse.json({ success: true, demo: true });
    }

    // ── Résolution du bien (plaque V1 OU hub du bien) ──
    const resolved = await resolveHubPropertyId(slug);
    if (!resolved.ok) {
      return NextResponse.json({ error: resolved.message }, { status: resolved.status });
    }

    const property = await db.property.findUnique({
      where: { id: resolved.propertyId },
      select: {
        id: true,
        name: true,
        address: true,
        owner: { select: { id: true, email: true, fullName: true } },
      },
    });
    if (!property) {
      return NextResponse.json({ error: 'Ce hub est introuvable.' }, { status: 404 });
    }

    // ── bookingId re-validé par bien (anti IDOR) — dégrade sans échouer ──
    let bookingId: string | null = null;
    let bookingEmail: string | null = null;
    let bookingDates: { checkIn: Date; checkOut: Date } | null = null;
    const rawBookingId = data.bookingId?.trim().slice(0, 60) || null;
    if (rawBookingId) {
      const booking = await db.booking.findFirst({
        where: { id: rawBookingId, propertyId: property.id },
        select: { id: true, guestEmail: true, checkIn: true, checkOut: true },
      });
      if (booking) {
        bookingId = booking.id;
        bookingEmail = booking.guestEmail;
        bookingDates = { checkIn: booking.checkIn, checkOut: booking.checkOut };
      }
    }

    // ── Mapping rooms[] → colonnes + détail JSON ──
    const byId = new Map(data.rooms.map((r) => [r.id, r]));
    const statusOf = (id: 'entrance' | 'kitchen' | 'livingRoom' | 'bedrooms' | 'bathroom') =>
      byId.get(id)?.status ?? 'good';
    const roomsData = data.rooms.map((r) => ({
      id: r.id,
      label: r.label,
      status: r.status,
      comment: r.comment ?? null,
      photoCount: (r.photos ?? []).length,
    }));
    const photos = data.rooms.flatMap((r) => r.photos ?? []);
    const notGood = data.rooms.filter((r) => r.status !== 'good');
    const damagesSummary =
      notGood.length === 0
        ? null
        : notGood
            .map((r) => `${r.label} : ${STATUS_LABEL[r.status]}${r.comment ? ` — ${r.comment}` : ''}`)
            .join('\n');
    const issuesSummary =
      [
        ...data.rooms
          .filter((r) => r.comment && r.status === 'good')
          .map((r) => `${r.label} : ${r.comment}`),
        data.comments ? `Commentaires : ${data.comments}` : '',
      ]
        .filter(Boolean)
        .join('\n') || null;

    const publicToken = crypto.randomUUID();
    const inspection = await db.checkOutInspection.create({
      data: {
        propertyId: property.id,
        bookingId,
        guestName: data.guestName.slice(0, 80),
        guestEmail: (data.guestEmail ?? bookingEmail) || null,
        entranceStatus: statusOf('entrance'),
        kitchenStatus: statusOf('kitchen'),
        livingRoomStatus: statusOf('livingRoom'),
        bedroomsStatus: statusOf('bedrooms'),
        bathroomStatus: statusOf('bathroom'),
        issues: issuesSummary,
        damages: damagesSummary,
        ...(photos.length > 0 ? { damagePhotos: photos } : {}),
        roomsData,
        inventoryCheck: data.inventory,
        selfAssessment: data.selfAssessment,
        guestSignature: data.signature,
        signedAt: new Date(),
        ipAddress: clientIp(req),
        publicToken,
        status: 'pending',
      },
      select: { id: true, signedAt: true },
    });

    const publicPath = `/public/inspection/${publicToken}`;
    const publicUrl = `${siteUrl}${publicPath}`;
    const pdfUrl = `${siteUrl}/api/public/inspection/${publicToken}/pdf`;

    // ── Inspection d'entrée liée au séjour (comparaison / preuve) ──
    let checkInPublicToken: string | null = null;
    let checkInCheckedAt: string | null = null;
    if (bookingId) {
      const entry = await db.minibarCheck.findFirst({
        where: { bookingId },
        orderBy: { checkedAt: 'desc' },
        select: { checkedAt: true, publicToken: true },
      });
      if (entry) {
        checkInPublicToken = entry.publicToken;
        checkInCheckedAt = entry.checkedAt.toISOString();
      }
    }

    // ── Emails (outbox, fire-and-forget — jamais bloquant) ──
    const frDate = (d: Date) =>
      d.toLocaleString('fr-FR', {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    const stayLabel = bookingDates
      ? `Séjour du ${frDate(bookingDates.checkIn)} au ${frDate(bookingDates.checkOut)}`
      : null;
    const roomsSummaryHtml = data.rooms
      .map(
        (r) =>
          `<tr><td style="padding:4px 12px 4px 0;color:#64748b">${r.label}</td>` +
          `<td style="padding:4px 0;font-weight:${r.status === 'good' ? '400' : '700'};color:${
            r.status === 'good' ? '#059669' : r.status === 'dirty' ? '#b45309' : '#b91c1c'
          }">${STATUS_LABEL[r.status]}${r.comment ? ` — ${r.comment.replace(/</g, '&lt;')}` : ''}</td></tr>`,
      )
      .join('');
    const linksHtml =
      `<p style="margin:18px 0">` +
      `<a href="${publicUrl}" style="display:inline-block;background:#059669;color:#ffffff;padding:10px 18px;border-radius:10px;text-decoration:none;font-weight:bold;margin-right:10px">Voir la preuve publique</a>` +
      `<a href="${pdfUrl}" style="display:inline-block;background:#ffffff;color:#059669;border:2px solid #059669;padding:8px 16px;border-radius:10px;text-decoration:none;font-weight:bold">Télécharger le PDF</a>` +
      `</p>`;
    const inventoryLine = `${data.inventory.keys} clé(s), ${data.inventory.remotes} télécommande(s), ${data.inventory.towels} serviette(s)`;

    if (data.guestEmail) {
      void queueEmail({
        to: data.guestEmail,
        subject: `Votre état des lieux de sortie — ${property.name}`,
        html:
          `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">` +
          `<h2 style="color:#0f172a">État des lieux de sortie enregistré</h2>` +
          `<p style="color:#334155">Merci <strong>${data.guestName.replace(/</g, '&lt;')}</strong> — votre document signé pour « ${property.name} » a bien été enregistré le ${frDate(inspection.signedAt)}.</p>` +
          (stayLabel ? `<p style="color:#64748b;font-size:13px">${stayLabel}</p>` : '') +
          `<table style="border-collapse:collapse;margin:16px 0">${roomsSummaryHtml}` +
          `<tr><td style="padding:4px 12px 4px 0;color:#64748b">Inventaire rendu</td><td style="padding:4px 0">${inventoryLine}</td></tr>` +
          `<tr><td style="padding:4px 12px 4px 0;color:#64748b">Auto-évaluation</td><td style="padding:4px 0">${data.selfAssessment}/5</td></tr>` +
          `</table>` +
          linksHtml +
          `<p style="color:#94a3b8;font-size:12px">Document horodaté et signé électroniquement — preuve publique : ${publicUrl}</p>` +
          `</div>`,
        text: `État des lieux de sortie enregistré pour ${property.name}. Preuve publique : ${publicUrl} — PDF : ${pdfUrl}`,
        template: 'custom',
        propertyId: property.id,
        referenceType: 'check_out_inspection',
        referenceId: inspection.id,
      });
    }

    const hasDamages = notGood.length > 0;

    if (property.owner?.email) {
      void queueEmail({
        to: property.owner.email,
        subject: hasDamages
          ? `⚠️ Dégâts signalés — état des lieux de sortie — ${property.name}`
          : `✅ État des lieux de sortie reçu — ${property.name}`,
        html:
          `<div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px">` +
          `<h2 style="color:${hasDamages ? '#b45309' : '#059669'}">${hasDamages ? '⚠️ Dégâts signalés par l’invité' : 'État des lieux de sortie reçu'}</h2>` +
          `<p style="color:#334155"><strong>${data.guestName.replace(/</g, '&lt;')}</strong> a signé l'état des lieux de sortie de « ${property.name} » le ${frDate(inspection.signedAt)}.</p>` +
          (stayLabel ? `<p style="color:#64748b;font-size:13px">${stayLabel}</p>` : '') +
          `<table style="border-collapse:collapse;margin:16px 0">${roomsSummaryHtml}` +
          `<tr><td style="padding:4px 12px 4px 0;color:#64748b">Auto-évaluation</td><td style="padding:4px 0">${data.selfAssessment}/5</td></tr>` +
          `</table>` +
          (data.comments
            ? `<p style="color:#334155;background:#f8fafc;padding:10px;border-radius:8px">« ${data.comments.replace(/</g, '&lt;')} »</p>`
            : '') +
          linksHtml +
          `<p style="color:#94a3b8;font-size:12px">Retrouvez la liste dans le Dashboard → Ménage &amp; Stock → États des lieux de sortie.</p>` +
          `</div>`,
        text: `${hasDamages ? 'Dégâts signalés' : 'État des lieux de sortie reçu'} — ${property.name} (${data.guestName}). Preuve : ${publicUrl}`,
        template: 'custom',
        propertyId: property.id,
        referenceType: 'check_out_inspection',
        referenceId: inspection.id,
      });
    }

    // ── Notification hôte (format cloche : dataJson.url → preuve) ──
    const damagedLabels = notGood.map((r) => r.label).join(', ');
    await db.notification
      .create({
        data: {
          userId: property.owner.id,
          type: 'checkout_inspection',
          title: hasDamages
            ? `⚠️ Dégâts signalés — état des lieux de sortie — ${property.name}`
            : `🧾 État des lieux de sortie reçu — ${property.name}`,
          body: hasDamages
            ? `${data.guestName} a signalé : ${damagedLabels}. Auto-évaluation ${data.selfAssessment}/5.`
            : `${data.guestName} a signé l'état des lieux de sortie (aucun dégât signalé). Auto-évaluation ${data.selfAssessment}/5.`,
          dataJson: JSON.stringify({
            source: 'hub',
            url: publicPath,
            publicToken,
            inspectionId: inspection.id,
            propertyId: property.id,
            propertyName: property.name,
            bookingId,
            guestName: data.guestName,
            hasDamages,
            damagedRooms: notGood.map((r) => r.id),
            selfAssessment: data.selfAssessment,
            hubSlug: slug,
          }),
        },
      })
      .catch(() => undefined);

    return NextResponse.json({
      success: true,
      publicToken,
      publicUrl,
      checkInPublicToken,
      checkInCheckedAt,
    });
  } catch (error) {
    await captureError('hub.checkout-inspection.POST', error, undefined, req);
    return NextResponse.json(
      { error: 'Erreur serveur. Réessayez dans un instant.' },
      { status: 500 },
    );
  }
}
