import { NextResponse } from 'next/server';
import { compare } from 'bcryptjs';
import { db } from '@/lib/db';
import {
  parseAccessCodes,
  parseAppliances,
  parseEmergencyInfo,
  parseLocalSpots,
  parsePremiumFeatures,
  parseSurvivalKit,
  parseVisualGuide,
} from '@/lib/concierge';
import { haversineKm, providerCategoryMeta, formatEur, propertyTypeMeta } from '@/lib/b2b';
import { rateLimit } from '@/lib/rate-limit';
// FIX-14 — monitoring d'erreurs : trace AuditLog (action='runtime.error').
import { captureError } from '@/lib/error-monitor';
// FIX-15 (B) — clientIp pour le rate-limit PIN IP-scopé (anti-lockout).
import { clientIp } from '@/lib/audit';

// =============================================================
// Hub public Conciergerie Hub — /hub/[slug]
// GET  : payload de l'écran d'accueil + données Mode Invité.
//        Le slug est le hubSlug de la PLAQUE QR (PhysicalQrCode).
// POST : vérification du PIN Mode Hôte (bcrypt sur property.pinHash)
//
// Sécurité : la GET n'expose QUE les données invité (Wi-Fi, codes
// d'accès, bonnes adresses, guide visuel, SOS, services, contact) —
// les mêmes modules que la PWA invitée. Les données hôte (QRs privés,
// prestataires, messages) sont servies par /host après vérification
// du PIN.
// =============================================================

const DEMO_SLUG = 'demo-hub';
const isDemo = (slug: string) => slug === DEMO_SLUG;

interface GuestServiceOffer {
  id: string;
  name: string;
  description: string | null;
  unitPrice: number;
  unit: string;
}

// REFONTE SERVICES PREMIUM (V4.14) — parité totale avec la PWA :
// le hub QR sert le même catalogue fin (offers[]) + unitPrice que
// /api/public/guest-app → expérience de commande identique.
interface GuestService {
  id: string;
  name: string;
  emoji: string;
  categoryLabel: string;
  description: string;
  priceLabel: string;
  unitPrice: number | null;
  offers: GuestServiceOffer[];
}

const DEMO_PAYLOAD = {
  active: true,
  property: {
    id: 'demo-home-001',
    name: 'Le Petit Nid',
    propertyType: 'AIRBNB',
    propertyTypeLabel: 'Airbnb',
    propertyTypeEmoji: '🏠',
    address: '12 Rue de la Paix, 75002 Paris',
    hasPin: true,
  },
  ownerName: 'Marie Dupont',
  guest: {
    wifi: { networkName: 'LePetitNid_5G', password: 'Demo2025!', securityType: 'WPA2' },
    guidebookSlug: null as string | null,
    accessCodes: {
      building: 'B1234#', safe: '0000', parking: 'Place 7 - sous-sol',
      note: 'Le code du portail change chaque saison — voyez la note de bienvenue.',
    },
    localSpots: [
      { id: 'spot-1', name: 'Chez Alfonso', category: 'food', lat: 48.8686, lng: 2.3366, address: '4 Rue Saint-Roch, 75001 Paris', hostNote: 'Meilleure pasta du quartier — réservez, c’est petit !' },
      { id: 'spot-2', name: 'Marché Saint-Honoré', category: 'groceries', lat: 48.8672, lng: 2.3275 },
    ] as { id: string; name: string; category: string; lat: number; lng: number; address?: string; hostNote?: string }[],
    visualGuide: [],
    emergency: { police: '17', hospital: 'Hôpital Européen Georges-Pompidou', pharmacy: 'Pharmacie Britannique — 10 place Edmond Rostand', pharmacyPhone: '+33 1 44 41 97 60', hostPhone: '+33 6 12 34 56 78', commonIssues: [] },
    // REFONTE SERVICES PREMIUM (V4.14) — même vitrine riche que la PWA
    // (6 prestataires, 9 formules) pour démontrer l'expérience complète.
    services: [
      {
        id: 'demo-svc-1',
        name: 'Morning Box Paris',
        emoji: '🥐',
        categoryLabel: 'Petit-déjeuner',
        description: 'Petit-déjeuner gourmand livré avant 8 h : viennoiseries artisanales, jus pressés.',
        priceLabel: 'dès 12,00 €',
        unitPrice: null,
        offers: [
          { id: 'demo-off-1', name: 'Box Solo', description: 'Croissant, pain au chocolat, jus d’orange pressé, café.', unitPrice: 12, unit: 'box' },
          { id: 'demo-off-2', name: 'Box Duo', description: 'Le petit-déjeuner complet pour deux — viennoiseries x4, jus, fruits.', unitPrice: 22, unit: 'box' },
        ],
      },
      {
        id: 'demo-svc-2',
        name: 'Champagne & Célébration',
        emoji: '🍾',
        categoryLabel: 'Sommelier',
        description: 'Champagne refroidi, fleurs et gourmandises pour marquer l’événement — livré en 1 h.',
        priceLabel: 'dès 45,00 €',
        unitPrice: null,
        offers: [
          { id: 'demo-off-3', name: 'Champagne Brut Premier Cru', description: 'Bouteille 75 cl + 2 flûtes offertes.', unitPrice: 45, unit: 'bouteille' },
          { id: 'demo-off-4', name: 'Pack Célébration', description: 'Champagne, 6 macarons, bouquet de saison.', unitPrice: 79, unit: 'pack' },
        ],
      },
      {
        id: 'demo-svc-3',
        name: 'Pressing Express',
        emoji: '🧺',
        categoryLabel: 'Pressing',
        description: 'Retour en 24 h, rendu sur cintre. Le linge quotidien devient un détail.',
        priceLabel: 'dès 10,00 €',
        unitPrice: null,
        offers: [
          { id: 'demo-off-5', name: 'Pièce à l’unité', description: 'Chemise, pantalon ou robe — rendu sur cintre.', unitPrice: 10, unit: 'pièce' },
          { id: 'demo-off-6', name: 'Sac de 5 kg', description: 'Linge quotidien lavé, séché, plié.', unitPrice: 35, unit: 'sac' },
        ],
      },
      {
        id: 'demo-svc-4',
        name: 'Chef à domicile',
        emoji: '👨‍🍳',
        categoryLabel: 'Chef à domicile',
        description: 'Menu signature en 4 services préparé chez vous, dressage inclus.',
        priceLabel: 'Sur devis',
        unitPrice: null,
        offers: [],
      },
      {
        id: 'demo-svc-5',
        name: 'Transfert Aéroport',
        emoji: '🚐',
        categoryLabel: 'Transferts',
        description: 'Chauffeur privé, suivi de vol, attente incluse. Portes à portes sans stress.',
        priceLabel: 'dès 65,00 €',
        unitPrice: null,
        offers: [
          { id: 'demo-off-7', name: 'CDG ⇄ Paris (berline)', description: 'Jusqu’à 3 passagers, 2 valises.', unitPrice: 65, unit: 'trajet' },
          { id: 'demo-off-8', name: 'CDG ⇄ Paris (van)', description: 'Jusqu’à 7 passagers, 6 valises.', unitPrice: 89, unit: 'trajet' },
        ],
      },
      {
        id: 'demo-svc-6',
        name: 'Massage bien-être',
        emoji: '💆',
        categoryLabel: 'Bien-être',
        description: 'Praticien certifié, table installée dans votre salon. Réservation sous 2 h.',
        priceLabel: 'dès 90,00 €',
        unitPrice: null,
        offers: [
          { id: 'demo-off-9', name: 'Massage relaxant 60 min', description: 'Dos, nuque, jambes — huiles bio.', unitPrice: 90, unit: 'séance' },
        ],
      },
    ] as GuestService[],
    contact: { name: 'Marie Dupont', phone: '+33 6 12 34 56 78', email: 'marie@conciergerie-hub.fr' },
    // FIX DASHBOARD→HUB — parité complète : modules premium servis
    // comme en PWA (guide appareils, vidéo, upselling, kit de survie).
    appliances: [
      {
        id: 'demo-app-1',
        name: 'Machine à laver',
        emoji: '🧺',
        instructions:
          'Programme express : tournez le bouton sur « 30 min », ajoutez la lessive dans le bac gauche et appuyez sur Départ.',
      },
      {
        id: 'demo-app-2',
        name: 'Machine à café',
        emoji: '☕',
        instructions: 'Capsules dans le tiroir du haut, appuyez sur le bouton ovale. Le premier café chauffe 40 s.',
      },
    ],
    premiumFeatures: {
      videoWelcomeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
      enableLateCheckout: true,
      lateCheckoutPrice: 25,
      enableReviewShield: true,
    },
    survivalKitItems: [
      { id: 'demo-kit-1', name: 'Trousse de secours', location: 'Meuble bas de la cuisine' },
      { id: 'demo-kit-2', name: 'Parapluie', location: 'Portemanteau de l’entrée' },
      { id: 'demo-kit-3', name: 'Piles de rechange (AA/AAA)', location: 'Tiroir du salon' },
    ],
  },
};

function parseContent(json: string | null | undefined): Record<string, unknown> {
  if (!json) return {};
  try {
    return JSON.parse(json) as Record<string, unknown>;
  } catch {
    return {};
  }
}

// GET: Public hub info — QR actif ? + écran d'accueil + Mode Invité
export async function GET(
  req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    if (!slug || slug.length < 2) {
      return NextResponse.json(
        { error: 'not_found', message: 'Adresse du hub invalide.' },
        { status: 400 }
      );
    }

    // ── DEMO MODE ──
    if (isDemo(slug)) {
      return NextResponse.json(DEMO_PAYLOAD);
    }

    // ── 1a. La plaque (QR physique) derrière ce slug — flux V1 ──
    const plaque = await db.physicalQrCode.findUnique({
      where: { hubSlug: slug },
      include: { claimedBy: { select: { id: true, fullName: true } } },
    });

    if (!plaque) {
      // ── 1b. ÉTAPE 12 : fallback Hub QR du BIEN (Property.qrHubSlug) ──
      const propertyBySlug = await db.property.findUnique({
        where: { qrHubSlug: slug },
        select: { id: true, isActive: true },
      });
      if (!propertyBySlug) {
        return NextResponse.json(
          {
            error: 'not_found',
            message: 'Ce hub est introuvable ou la plaque n’a pas encore été activée par son hôte.',
          },
          { status: 404 }
        );
      }
      if (!propertyBySlug.isActive) {
        return NextResponse.json(
          {
            error: 'inactive',
            message: 'Ce bien a été désactivé par son hôte.',
          },
          { status: 410 }
        );
      }
      const payload = await buildPropertyPayload(propertyBySlug.id, null);
      if (!payload) {
        return NextResponse.json(
          { error: 'not_found', message: 'Le logement lié à ce hub est introuvable.' },
          { status: 404 }
        );
      }
      return NextResponse.json(payload);
    }

    if (!plaque.isClaimed || !plaque.propertyId) {
      return NextResponse.json(
        {
          error: 'not_found',
          message: 'Ce hub est introuvable ou la plaque n’a pas encore été activée par son hôte.',
        },
        { status: 404 }
      );
    }

    // ── 2. Le QR est-il actif ? ──
    if (plaque.status !== 'active') {
      return NextResponse.json(
        {
          error: 'inactive',
          message:
            plaque.status === 'lost'
              ? 'Cette plaque a été signalée perdue par son hôte.'
              : 'Cette plaque QR a été désactivée par son hôte.',
        },
        { status: 410 }
      );
    }

    const payload = await buildPropertyPayload(
      plaque.propertyId,
      plaque.claimedBy?.fullName ?? null,
    );
    if (!payload) {
      return NextResponse.json(
        { error: 'not_found', message: 'Le logement lié à cette plaque est introuvable.' },
        { status: 404 }
      );
    }

    return NextResponse.json(payload);
  } catch (error) {
    // FIX-14 — captureError console.error + trace AuditLog, ne jette jamais.
    await captureError('hub.get', error, undefined, req);
    return NextResponse.json(
      { error: 'server', message: 'Erreur serveur. Réessayez dans un instant.' },
      { status: 500 }
    );
  }
}

/**
 * Construit le payload invité d'un bien (Wi-Fi, guidebook,
 * services géolocalisés, contact). ÉTAPE 12 : partagé entre le
 * flux PLAQUE (V1) et le flux HUB DU BIEN (Property.qrHubSlug).
 */
async function buildPropertyPayload(
  propertyId: string,
  claimedByName: string | null,
) {
  // ── Le bien + son propriétaire ──
  const property = await db.property.findUnique({
    where: { id: propertyId },
    select: {
      id: true,
      name: true,
      propertyType: true,
      address: true,
      latitude: true,
      longitude: true,
      isActive: true,
      pinHash: true,
      // AUDIT PRÉ-PROD — l'email de contact invité vient du SOS (hostEmail)
      emergencyInfo: true,
      // BUG DASHBOARD→HUB — modules invités remplis depuis /airbnb/concierge
      // (Coffre-fort, SOS, bonnes adresses, GUIDE DES APPAREILS) et
      // l'Expérience Invité (guide visuel, vidéo bienvenue, late check-out,
      // bouclier d'avis, kit de survie) : ils doivent apparaître dans le
      // hub QR, comme en PWA.
      accessCodes: true,
      localSpots: true,
      visualGuide: true,
      appliances: true,
      premiumFeatures: true,
      survivalKitItems: true,
      owner: {
        select: {
          fullName: true,
          profile: { select: { phone: true } },
        },
      },
    },
  });

  if (!property || !property.isActive) return null;

  // ── QRs actifs publics → Wi-Fi + Guidebook ──
  const activeQrs = await db.qrCode.findMany({
    where: { propertyId: property.id, isActive: true, isPrivate: false },
    orderBy: { createdAt: 'asc' },
    include: { content: { select: { contentJson: true } } },
  });

  const wifiQr = activeQrs.find((qr) => qr.type === 'wifi');
  const guidebookQr = activeQrs.find((qr) => qr.type === 'home_manual' && qr.publicSlug);
  const wifiContent = wifiQr ? parseContent(wifiQr.content?.contentJson) : {};

  const wifi =
    wifiQr && (wifiContent.network_name || wifiContent.password)
      ? {
          networkName: (wifiContent.network_name as string) || 'Wi-Fi du logement',
          password: (wifiContent.password as string) || '',
          securityType: (wifiContent.security_type as string) || 'WPA2',
        }
      : null;

  // ── Services invité = prestataires GUEST_EXPERIENCE dans le rayon ──
  // REFONTE SERVICES PREMIUM (V4.14) — parité PWA : pré-filtre SQL
  // bounding box (200 km) + catalogue fin ServiceOffer par bien.
  const services: GuestService[] = [];
  if (property.latitude != null && property.longitude != null) {
    const RADIUS_MAX_KM = 200;
    const geoProviders = await db.provider.findMany({
      where: {
        isActive: true,
        audience: 'GUEST_EXPERIENCE',
        latitude: { gte: property.latitude - RADIUS_MAX_KM / 111, lte: property.latitude + RADIUS_MAX_KM / 111 },
        longitude: { gte: property.longitude - RADIUS_MAX_KM / 74, lte: property.longitude + RADIUS_MAX_KM / 74 },
      },
      take: 200,
    });
    const inRadius = geoProviders.filter((p) => {
      if (p.latitude == null || p.longitude == null) return false;
      const d = haversineKm(property.latitude!, property.longitude!, p.latitude, p.longitude);
      return d <= p.serviceRadiusKm;
    });

    const offersByProvider = new Map<string, GuestServiceOffer[]>();
    if (inRadius.length > 0) {
      const offers = await db.serviceOffer.findMany({
        where: {
          propertyId: property.id,
          providerId: { in: inRadius.map((p) => p.id) },
          isActive: true,
        },
        orderBy: [{ sortOrder: 'asc' }, { unitPrice: 'asc' }, { name: 'asc' }],
        select: {
          id: true,
          providerId: true,
          name: true,
          description: true,
          unitPrice: true,
          unit: true,
        },
      });
      for (const o of offers) {
        const list = offersByProvider.get(o.providerId) ?? [];
        list.push({
          id: o.id,
          name: o.name,
          description: o.description,
          unitPrice: o.unitPrice,
          unit: o.unit,
        });
        offersByProvider.set(o.providerId, list);
      }
    }

    for (const p of inRadius) {
      const offers = offersByProvider.get(p.id) ?? [];
      const minOffer = offers.length > 0 ? offers[0].unitPrice : null;
      const priceLabel =
        minOffer != null
          ? `dès ${formatEur(minOffer)}`
          : p.hourlyRate != null
            ? `dès ${formatEur(p.hourlyRate)}`
            : 'Sur devis';
      const cat = providerCategoryMeta(p.category);
      services.push({
        id: p.id,
        name: p.businessName,
        emoji: cat.emoji,
        categoryLabel: cat.label,
        description: p.description ?? 'Service proposé par un partenaire local vérifié.',
        priceLabel,
        unitPrice: p.hourlyRate ?? null,
        offers,
      });
    }
    services.sort((a, b) => a.name.localeCompare(b.name));
  }

  return {
    active: true,
    property: {
      id: property.id,
      name: property.name,
      propertyType: property.propertyType,
      propertyTypeLabel: propertyTypeMeta(property.propertyType).label,
      propertyTypeEmoji: propertyTypeMeta(property.propertyType).emoji,
      address: property.address,
      hasPin: !!property.pinHash,
    },
    ownerName: claimedByName || property.owner?.fullName || null,
    guest: {
      wifi,
      guidebookSlug: guidebookQr?.publicSlug ?? null,
      // BUG DASHBOARD→HUB — parité complète avec la PWA invitée :
      // coffre-fort, bonnes adresses, guide visuel, SOS, guide des
      // appareils, modules premium (vidéo, late check-out, bouclier
      // d'avis) et kit de survie servis par les mêmes parseurs
      // tolérants (jamais de throw).
      accessCodes: parseAccessCodes(property.accessCodes),
      localSpots: parseLocalSpots(property.localSpots),
      visualGuide: parseVisualGuide(property.visualGuide),
      emergency: parseEmergencyInfo(property.emergencyInfo),
      appliances: parseAppliances(property.appliances),
      premiumFeatures: parsePremiumFeatures(property.premiumFeatures),
      survivalKitItems: parseSurvivalKit(property.survivalKitItems),
      services,
      contact: {
        name: property.owner?.fullName || 'Votre hôte',
        // FIX-32 : téléphone de contact = profil hôte, SINON téléphone SOS
        // (emergencyInfo.hostPhone) — « Contacter l'hôte » affiche ainsi
        // Appel + WhatsApp dès qu'un numéro est renseigné où que ce soit.
        phone:
          property.owner?.profile?.phone ??
          parseEmergencyInfo(property.emergencyInfo)?.hostPhone ??
          null,
        // AUDIT PRÉ-PROD — SÉCURITÉ : email de contact DÉDIÉ (SOS), plus
        // jamais l'email de LOGIN du compte hôte (anti-phishing).
        email: parseEmergencyInfo(property.emergencyInfo)?.hostEmail ?? null,
      },
    },
  };
}

// POST: Verify PIN for host mode
export async function POST(
  req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const body = await req.json();
    const { pin } = body;

    if (!pin || !/^\d{4}$/.test(pin)) {
      return NextResponse.json({ error: 'PIN invalide' }, { status: 400 });
    }

    // FIX-15 (B) — Anti brute-force par IP (10 essais/min, PIN 4 chiffres) ;
    // le quota slug global serait un vecteur de DoS du mode hôte : un tiers
    // pouvait épuiser `hubpin:<slug>` et empêcher l'hôte légitime de se
    // connecter au MODE HÔTE.
    if (!(await rateLimit(`hubpin:${slug}:${clientIp(req.headers) ?? 'local'}`, 10))) {
      return NextResponse.json({ error: 'Trop de tentatives. Réessayez dans un instant.' }, { status: 429 });
    }

    // ── DEMO MODE: any 4-digit PIN works ──
    if (isDemo(slug)) {
      return NextResponse.json({ success: true, propertyId: 'demo-home-001' });
    }

    // Find the plaque and home
    const plaque = await db.physicalQrCode.findUnique({
      where: { hubSlug: slug },
    });

    if (plaque && (!plaque.isClaimed || !plaque.propertyId)) {
      return NextResponse.json({ error: 'Hub non trouvé' }, { status: 404 });
    }

    if (plaque && plaque.status !== 'active') {
      return NextResponse.json(
        { error: 'Cette plaque QR est désactivée.' },
        { status: 410 }
      );
    }

    // ÉTAPE 12 : résolution du bien via la plaque OU le slug du bien
    const home = plaque?.propertyId
      ? await db.property.findUnique({
          where: { id: plaque.propertyId },
          select: { id: true, pinHash: true },
        })
      : await db.property.findUnique({
          where: { qrHubSlug: slug },
          select: { id: true, pinHash: true },
        });

    if (!home || !home.pinHash) {
      return NextResponse.json({ error: 'Aucun PIN configuré' }, { status: 400 });
    }

    const isValid = await compare(pin, home.pinHash);
    if (!isValid) {
      return NextResponse.json({ error: 'PIN incorrect' }, { status: 401 });
    }

    return NextResponse.json({ success: true, propertyId: home.id });
  } catch (error) {
    // FIX-14 — captureError console.error + trace AuditLog, ne jette jamais.
    await captureError('hub.pin', error, undefined, req);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
