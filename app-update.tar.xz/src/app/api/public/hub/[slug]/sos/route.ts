import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { captureError } from '@/lib/error-monitor';
import { dispatchWebhooks } from '@/lib/webhook-dispatcher';
import { sendSms } from '@/lib/sms';
import {
  sendNotificationToMany,
  propertyOwnerAndManagers,
} from '@/lib/notifications';

// =============================================================
// v4.33 « SOS LOGEMENT » — POST /api/public/hub/[slug]/sos
//
// Demande client : « Un bouton qui permet au voyageur de signaler un
// problème urgent (fuite d'eau, panne de chauffage, clé bloquée) en
// un clic. L'application envoie une notification immédiate à l'hôte
// avec l'heure et le numéro de l'appartement. »
//
// POST   (invité, libre) : { problem, note? }
//   - problem : 'water' | 'heating' | 'key' | 'power' | 'other'
//   Effets :
//   1. GuestComplaint (isUrgent: true) → visible « Réclamations en
//      attente » (mode hôte du hub + dashboard /airbnb/messages) ;
//   2. Notification IMMÉDIATE à l'hôte + managers (cloche + email +
//      push selon préférences) avec l'HEURE du signalement et le
//      nom/adresse de l'appartement ;
//   3. SMS hôte (fire-and-forget) ;
//   4. Webhook sortant 'sos'.
// Sécurité : rate limit 3/min par slug+IP ; zod ; never-throw ;
// mode démo = succès sans écriture.
// =============================================================

const DEMO_SLUG = 'demo-hub';
const isDemo = (slug: string) => slug === DEMO_SLUG;

const PROBLEMS = ['water', 'heating', 'key', 'power', 'other'] as const;
type Problem = (typeof PROBLEMS)[number];

const PROBLEM_LABELS: Record<Problem, string> = {
  water: 'Fuite d’eau',
  heating: 'Panne de chauffage',
  key: 'Clé bloquée ou perdue',
  power: 'Panne d’électricité',
  other: 'Autre urgence',
};

/** Category GuestComplaint (enum documenté : PLUMBING|ELECTRICAL|CLEANING|OTHER). */
const PROBLEM_CATEGORY: Record<Problem, string> = {
  water: 'PLUMBING',
  heating: 'OTHER',
  key: 'OTHER',
  power: 'ELECTRICAL',
  other: 'OTHER',
};

const sosSchema = z.object({
  problem: z.enum(PROBLEMS, { message: 'Type d’urgence invalide.' }),
  note: z.string().trim().max(300).optional().nullable(),
  guestName: z.string().trim().max(80).optional().nullable(),
});

function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for');
  return (fwd ? fwd.split(',')[0].trim() : null) || 'local';
}

async function resolvePropertyId(
  slug: string,
): Promise<{ ok: true; propertyId: string } | { ok: false; status: number; message: string }> {
  if (isDemo(slug)) return { ok: true, propertyId: 'demo-home-001' };
  const property = await db.property.findUnique({
    where: { qrHubSlug: slug },
    select: { id: true, isActive: true },
  });
  if (!property) return { ok: false, status: 404, message: 'Ce hub est introuvable.' };
  if (!property.isActive) return { ok: false, status: 410, message: 'Ce bien a été désactivé par son hôte.' };
  return { ok: true, propertyId: property.id };
}

/** SMS hôte (fire-and-forget, fail-closed) — heure + appartement inclus. */
async function notifyHostBySms(
  propertyId: string,
  data: { label: string; timeLabel: string; place: string },
): Promise<void> {
  try {
    const property = await db.property.findUnique({
      where: { id: propertyId },
      select: { owner: { select: { profile: { select: { phone: true } } } } },
    });
    const phone = property?.owner?.profile?.phone?.trim();
    if (!phone) return;
    const body =
      `🚨 SOS LOGEMENT — ${data.place} : ${data.label} signalé à ${data.timeLabel}. ` +
      `Merci d’agir immédiatement (Conciergerie Hub).`;
    const result = await sendSms(phone, body);
    if (!result.sent) {
      console.warn(`[sos] SMS hôte non envoyé (${propertyId}) :`, result.reason ?? result.error);
    }
  } catch (error) {
    console.error('[sos] notification SMS hôte failed:', error);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;

    // Anti-spam : 3 alertes / minute / slug+IP
    if (!(await rateLimit(`hubsos:${slug}:${clientIp(req)}`, 3))) {
      return NextResponse.json(
        { error: 'Trop d’alertes rapprochées. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    const rawBody = await req.json().catch(() => null);
    if (!rawBody || typeof rawBody !== 'object') {
      return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const parsed = sosSchema.safeParse(rawBody);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Requête invalide.' },
        { status: 400 },
      );
    }

    const { problem, note, guestName } = parsed.data;

    // Heure du signalement (locale serveur = heure du bien en pratique)
    const now = new Date();
    const timeLabel = now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

    // ── DEMO MODE : succès sans écriture ──
    if (isDemo(slug)) {
      return NextResponse.json({
        success: true,
        id: `demo-sos-${Date.now()}`,
        timeLabel,
        message: `Alerte envoyée (mode démo) — l’hôte a été prévenu à ${timeLabel}.`,
      });
    }

    const resolved = await resolvePropertyId(slug);
    if (!resolved.ok) {
      return NextResponse.json({ error: resolved.message }, { status: resolved.status });
    }

    const property = await db.property.findUnique({
      where: { id: resolved.propertyId },
      select: {
        id: true,
        name: true,
        address: true,
        owner: { select: { id: true } },
      },
    });
    if (!property?.owner?.id) {
      return NextResponse.json({ error: 'Ce hub est introuvable.' }, { status: 404 });
    }

    const label = PROBLEM_LABELS[problem];
    // « heure + numéro de l'appartement » : nom du bien + adresse si renseignée.
    const place = property.address ? `${property.name} (${property.address})` : property.name;
    const description =
      `🚨 SOS LOGEMENT — ${label}${note ? ` — ${note}` : ''} (signalé à ${timeLabel})`;

    // 1) Réclamation urgente → files « Réclamations en attente »
    const complaint = await db.guestComplaint.create({
      data: {
        propertyId: property.id,
        category: PROBLEM_CATEGORY[problem],
        description,
        photos: '[]',
        isUrgent: true,
        guestName: guestName ?? null,
      },
      select: { id: true },
    });

    // 2) Notification IMMÉDIATE unifiée (hôte + managers) :
    //    cloche in-app TOUJOURS + email + push selon préférences.
    const audience = await propertyOwnerAndManagers(property.id);
    const body = `${label} — signalé à ${timeLabel} — ${place}. Agissez immédiatement.`;
    if (audience.length > 0) {
      await sendNotificationToMany(audience, 'sos_logement', {
        title: `🚨 SOS Logement — ${property.name}`,
        body,
        propertyId: property.id,
        propertyName: property.name,
        url: '/airbnb/messages',
        meta: {
          source: 'hub',
          sos: true,
          problem,
          problemLabel: label,
          timeLabel,
          place,
          complaintId: complaint.id,
          hubSlug: slug,
          guestName: guestName ?? null,
        },
      });
    } else {
      // Filet de sécurité : jamais sans trace.
      await db.notification.create({
        data: {
          userId: property.owner.id,
          type: 'guest_sos',
          title: `🚨 SOS Logement — ${property.name}`,
          body,
          dataJson: JSON.stringify({
            source: 'hub',
            problem,
            problemLabel: label,
            timeLabel,
            place,
            complaintId: complaint.id,
            hubSlug: slug,
          }),
        },
      });
    }

    // 3) SMS hôte (fire-and-forget)
    void notifyHostBySms(property.id, { label, timeLabel, place }).catch(() => undefined);

    // 4) Webhook sortant (audit pré-prod, HMAC)
    void dispatchWebhooks(property.id, 'complaint', {
      event: 'sos.created',
      complaintId: complaint.id,
      problem,
      problemLabel: label,
      timeLabel,
      place,
    });

    return NextResponse.json({
      success: true,
      id: complaint.id,
      timeLabel,
      message: `L’hôte a été alerté à ${timeLabel}.`,
    });
  } catch (error) {
    await captureError('hub.sos', error, undefined, req);
    return NextResponse.json(
      { error: 'Erreur serveur. Réessayez dans un instant.' },
      { status: 500 },
    );
  }
}
