import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { captureError } from '@/lib/error-monitor';
import { parsePremiumFeatures } from '@/lib/concierge';

// =============================================================
// PREMIUM « CONCIERGERIE 5 ÉTOILES » (V5) — 2.4 LATE CHECK-OUT
//
// POST /api/public/hub/[slug]/late-checkout
//   body: { guestName?, bookingId? }
//
// L'invité demande un départ tardif (14 h au lieu de 11 h) proposé
// par l'hôte (premiumFeatures.enableLateCheckout). Le serveur
// VÉRIFIE que le service est bien activé sur CE bien (jamais cru
// côté client) et crée une notification hôte (type
// 'guest_latecheckout'). Le règlement se fait ensuite avec l'hôte.
//
// Sécurité : rate limit 3/min par slug+IP ; zod ; never-throw ;
// mode démo = succès sans écriture.
// =============================================================

const DEMO_SLUG = 'demo-hub';
const isDemo = (slug: string) => slug === DEMO_SLUG;

const requestSchema = z.object({
  guestName: z.string().trim().max(80).optional().nullable(),
  bookingId: z.string().trim().max(60).optional().nullable(),
});

function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for');
  return (fwd ? fwd.split(',')[0].trim() : null) || 'local';
}

export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;

    // Anti-spam : 3 demandes / minute / slug+IP
    if (!(await rateLimit(`hublatecheckout:${slug}:${clientIp(req)}`, 3))) {
      return NextResponse.json(
        { error: 'Trop de demandes rapprochées. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    const rawBody = await req.json().catch(() => null);
    if (rawBody !== null && typeof rawBody !== 'object') {
      return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const parsed = requestSchema.safeParse(rawBody ?? {});
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Requête invalide.' },
        { status: 400 },
      );
    }

    // ── DEMO MODE : succès sans écriture ──
    if (isDemo(slug)) {
      return NextResponse.json({
        success: true,
        message: 'Demande envoyée (mode démo) — votre hôte vous répondra rapidement.',
      });
    }

    // ── Résolution du bien ──
    const plaque = await db.physicalQrCode.findUnique({
      where: { hubSlug: slug },
      select: { propertyId: true, isClaimed: true, status: true },
    });

    let propertyId: string | null = null;
    if (plaque && plaque.isClaimed && plaque.propertyId && plaque.status === 'active') {
      propertyId = plaque.propertyId;
    } else if (!plaque) {
      const bySlug = await db.property.findUnique({
        where: { qrHubSlug: slug },
        select: { id: true, isActive: true },
      });
      if (bySlug?.isActive) propertyId = bySlug.id;
    }

    if (!propertyId) {
      return NextResponse.json(
        { error: 'Ce hub est introuvable ou a été désactivé.' },
        { status: 404 },
      );
    }

    // ── Garde serveur : le service DOIT être activé sur CE bien ──
    const property = await db.property.findUnique({
      where: { id: propertyId },
      select: {
        id: true,
        name: true,
        premiumFeatures: true,
        owner: { select: { id: true } },
      },
    });
    if (!property?.owner?.id) {
      return NextResponse.json({ error: 'Ce hub est introuvable.' }, { status: 404 });
    }

    const premium = parsePremiumFeatures(property.premiumFeatures);
    if (!premium?.enableLateCheckout) {
      return NextResponse.json(
        { error: "Le départ tardif n'est pas proposé pour ce logement." },
        { status: 403 },
      );
    }

    // ── Invité : nom depuis le booking (?b= filtré par bien, jamais cru) ──
    let guestName = parsed.data.guestName?.trim().slice(0, 80) || null;
    const bookingId = parsed.data.bookingId?.trim().slice(0, 60) || null;
    if (bookingId) {
      const booking = await db.booking.findFirst({
        where: { id: bookingId, propertyId: property.id, status: { not: 'CANCELLED' } },
        select: { guestName: true },
      });
      if (booking?.guestName) guestName = booking.guestName.slice(0, 80);
    }

    const priceLabel = premium.lateCheckoutPrice
      ? `${premium.lateCheckoutPrice.toLocaleString('fr-FR', { style: 'currency', currency: 'EUR' })}`
      : 'à convenir';

    await db.notification.create({
      data: {
        userId: property.owner.id,
        type: 'guest_latecheckout',
        title: `⏱️ Demande de late check-out — ${property.name}`,
        body: guestName
          ? `${guestName} souhaite partir à 14 h au lieu de 11 h (tarif : ${priceLabel}). Confirmez la disponibilité puis encaissez le supplément.`
          : `Un invité souhaite partir à 14 h au lieu de 11 h (tarif : ${priceLabel}). Confirmez la disponibilité puis encaissez le supplément.`,
        dataJson: JSON.stringify({
          source: 'guest_app',
          propertyId: property.id,
          propertyName: property.name,
          price: premium.lateCheckoutPrice ?? null,
          bookingId,
          guestName,
          hubSlug: slug,
        }),
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Demande envoyée — votre hôte vous répondra rapidement.',
    });
  } catch (error) {
    await captureError('hub.late-checkout', error, undefined, req);
    return NextResponse.json(
      { error: 'Erreur serveur. Réessayez dans un instant.' },
      { status: 500 },
    );
  }
}
