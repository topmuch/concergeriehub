import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { captureError } from '@/lib/error-monitor';
import { rateLimit } from '@/lib/rate-limit';
import { clientIp } from '@/lib/audit';

// =============================================================
// RÉPONSES VOCALES DE L'HÔTE — GET /api/public/hub/[slug]/voice-replies
//
// Le Hub Invité affiche les réponses vocales ENREGISTRÉES PAR
// L'HÔTE (VoiceMessage.senderType='HOST') : ce sont des messages
// destinés aux invités par définition → consultation publique
// volontaire, STRICTEMENT limitée aux messages de type HOST (jamais
// les vocaux des autres invités — vie privée).
//
// Sécurité : rate limit 30/min par slug+IP ; take 20 ; select
// minimal ; never-throw (captureError).
// =============================================================

const DEMO_SLUG = 'demo-hub';

export async function GET(
  req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    if (
      !(await rateLimit(`hubvoicereplies:${slug}:${clientIp(req.headers) ?? 'local'}`, 30))
    ) {
      return NextResponse.json(
        { error: 'Trop de requêtes. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    // ── DEMO MODE : aucune écriture ni lecture DB (pas de bien réellement lié) ──
    if (slug === DEMO_SLUG) {
      return NextResponse.json({ replies: [] });
    }

    // ── Résolution du bien : plaque V1 OU hub du bien (property.qrHubSlug) ──
    let propertyId: string | null = null;
    let isActive = true;
    const plaque = await db.physicalQrCode.findUnique({
      where: { hubSlug: slug },
      select: { propertyId: true, isClaimed: true },
    });
    if (plaque) {
      if (!plaque.isClaimed || !plaque.propertyId) {
        return NextResponse.json({ error: 'Hub non trouvé' }, { status: 404 });
      }
      propertyId = plaque.propertyId;
    } else {
      const propertyBySlug = await db.property.findUnique({
        where: { qrHubSlug: slug },
        select: { id: true, isActive: true },
      });
      if (!propertyBySlug) {
        return NextResponse.json({ error: 'Hub non trouvé' }, { status: 404 });
      }
      propertyId = propertyBySlug.id;
      isActive = propertyBySlug.isActive;
    }
    if (!isActive) {
      return NextResponse.json(
        { error: 'Ce bien a été désactivé par son hôte.' },
        { status: 410 },
      );
    }

    // ── UNIQUEMENT les réponses de l'hôte (vie privée des invités) ──
    // v4.32 — audioData inclus (lecture durable après redéploiement).
    const replies = await db.voiceMessage.findMany({
      where: { propertyId, senderType: 'HOST' },
      orderBy: { createdAt: 'desc' },
      take: 20,
      select: {
        id: true,
        senderName: true,
        senderType: true,
        audioUrl: true,
        audioData: true,
        durationSec: true,
        createdAt: true,
      },
    });

    return NextResponse.json({ replies });
  } catch (error) {
    await captureError('hub.voice-replies', error, undefined, req);
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 });
  }
}
