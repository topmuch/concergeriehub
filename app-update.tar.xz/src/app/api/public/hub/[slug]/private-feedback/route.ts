import { NextResponse } from 'next/server';
import { z } from 'zod';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { captureError } from '@/lib/error-monitor';

// =============================================================
// PREMIUM « CONCIERGERIE 5 ÉTOILES » (V5) — 2.3 BOUCLIER D'AVIS
//
// POST /api/public/hub/[slug]/private-feedback
//   body: { rating: 1..5, comment?: string, guestName?: string }
//
// L'invité mécontent (1-3 étoiles dans le Hub Invité) écrit son
// retour EN PRIVÉ → notification immédiate dans la cloche de
// l'Espace Hôte (type 'guest_feedback'). L'hôte peut ainsi corriger
// le tir AVANT qu'un avis public négatif ne soit publié.
//
// Sécurité : rate limit 5/min par slug+IP (anti-spam) ; validation
// zod ; never-throw (captureError) ; mode démo = succès sans écriture.
// =============================================================

const DEMO_SLUG = 'demo-hub';
const isDemo = (slug: string) => slug === DEMO_SLUG;

const MAX_COMMENT = 2000;

const feedbackSchema = z.object({
  rating: z
    .number({ message: 'Note invalide.' })
    .int({ message: 'Note invalide.' })
    .min(1, { message: 'Note invalide (1 à 5 étoiles).' })
    .max(5, { message: 'Note invalide (1 à 5 étoiles).' }),
  comment: z.string().trim().max(MAX_COMMENT, { message: `Message trop long (max ${MAX_COMMENT} caractères).` }).optional().nullable(),
  guestName: z.string().trim().max(80).optional().nullable(),
});

function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for');
  return (fwd ? fwd.split(',')[0].trim() : null) || 'local';
}

/** Résout le bien derrière un slug (plaque V1 OU hub du bien) — même pattern que complaint. */
async function resolveProperty(
  slug: string,
): Promise<{ ok: true; propertyId: string; ownerId: string; propertyName: string } | { ok: false; status: number; message: string }> {
  if (isDemo(slug)) {
    return { ok: true, propertyId: 'demo-home-001', ownerId: 'demo', propertyName: 'Le Petit Nid' };
  }

  const plaque = await db.physicalQrCode.findUnique({
    where: { hubSlug: slug },
    select: { propertyId: true, isClaimed: true, status: true },
  });

  let propertyId: string | null = null;
  if (plaque && plaque.isClaimed && plaque.propertyId && plaque.status === 'active') {
    propertyId = plaque.propertyId;
  } else if (!plaque) {
    const bySlug = await db.property.findUnique({
      where: { qrHubSlug: slug },
      select: { id: true, isActive: true },
    });
    if (bySlug?.isActive) propertyId = bySlug.id;
  }

  if (!propertyId) {
    return { ok: false, status: 404, message: 'Ce hub est introuvable ou a été désactivé.' };
  }

  const property = await db.property.findUnique({
    where: { id: propertyId },
    select: { id: true, name: true, owner: { select: { id: true } } },
  });
  if (!property?.owner?.id) {
    return { ok: false, status: 404, message: 'Ce hub est introuvable.' };
  }

  return { ok: true, propertyId: property.id, ownerId: property.owner.id, propertyName: property.name };
}

const RATING_LABELS: Record<number, string> = {
  1: 'Très déçu',
  2: 'Déçu',
  3: 'Moyen',
  4: 'Très bien',
  5: 'Excellent',
};

export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params;

    // Anti-spam : 5 retours / minute / slug+IP
    if (!(await rateLimit(`hubfeedback:${slug}:${clientIp(req)}`, 5))) {
      return NextResponse.json(
        { error: 'Trop de messages rapprochés. Réessayez dans un instant.' },
        { status: 429 },
      );
    }

    const rawBody = await req.json().catch(() => null);
    if (!rawBody || typeof rawBody !== 'object') {
      return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
    }
    const parsed = feedbackSchema.safeParse(rawBody);
    if (!parsed.success) {
      return NextResponse.json(
        { error: parsed.error.issues[0]?.message ?? 'Requête invalide.' },
        { status: 400 },
      );
    }

    const rating = parsed.data.rating;
    const comment = (parsed.data.comment || '').trim().slice(0, MAX_COMMENT);
    const guestName = parsed.data.guestName?.trim().slice(0, 80) || null;

    const resolved = await resolveProperty(slug);
    if (!resolved.ok) {
      return NextResponse.json({ error: resolved.message }, { status: resolved.status });
    }

    // ── DEMO MODE : succès sans écriture ──
    if (isDemo(slug)) {
      return NextResponse.json({
        success: true,
        message: 'Feedback envoyé (mode démo) — votre hôte a été prévenu.',
      });
    }

    await db.notification.create({
      data: {
        userId: resolved.ownerId,
        type: 'guest_feedback',
        title: `⭐ Avis privé ${rating}/5 — ${resolved.propertyName}`,
        body: comment
          ? `${RATING_LABELS[rating]}${guestName ? ` · ${guestName}` : ''} : « ${comment.slice(0, 480)} »`
          : `Un invité a évalué son séjour « ${RATING_LABELS[rating]} »${guestName ? ` (${guestName})` : ''} sans message.`,
        dataJson: JSON.stringify({
          source: 'review_shield',
          propertyId: resolved.propertyId,
          propertyName: resolved.propertyName,
          rating,
          comment: comment || null,
          guestName,
          hubSlug: slug,
        }),
      },
    });

    return NextResponse.json({ success: true, message: 'Merci, votre hôte a été prévenu.' });
  } catch (error) {
    await captureError('hub.private-feedback', error, undefined, req);
    return NextResponse.json(
      { error: 'Erreur serveur. Réessayez dans un instant.' },
      { status: 500 },
    );
  }
}
