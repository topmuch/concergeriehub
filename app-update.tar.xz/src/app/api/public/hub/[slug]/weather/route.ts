// =============================================================
// GET /api/public/hub/[slug]/weather — WIDGET MÉTÉO (v4.49)
// -------------------------------------------------------------
// Demande client : « mettre un widget météo » sur le hub invité.
//
// → Météo ACTUELLE + 3 jours à venir du logement, affichée en tête
//   du hub invité (carte « Météo sur place »).
//
// Source : Open-Meteo (https://open-meteo.com) — GRATUIT, SANS CLÉ,
// usage non commercial autorisé. Zéro coût, zéro inscription.
// Cache mémoire 30 min par slug (les apps météo rafraîchissent
// rarement plus vite ; protège l'API et répond en < 1 ms).
// Sécurité : route publique (données non sensibles), coordonnées
// lues depuis le bien (Property.latitude/longitude) — jamais de
// paramètre lat/lng arbitraire depuis le client (pas d'open proxy).
// =============================================================
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { resolveHubPropertyId } from '@/lib/hub-resolve';

export const dynamic = 'force-dynamic';

/** Coordonnées du hub de démonstration (Paris, cohérentes avec le payload démo). */
const DEMO_COORDS = { lat: 48.8686, lng: 2.3366 };
const DEMO_SLUG = 'demo-hub';

interface DailyItem {
  date: string;
  code: number;
  tmax: number;
  tmin: number;
}

interface WeatherPayload {
  ok: true;
  current: { temp: number; code: number; wind: number };
  daily: DailyItem[];
  fetchedAt: string;
}

/** Réponse Open-Meteo (champs utilisés uniquement). */
interface OpenMeteoResponse {
  current?: { temperature_2m?: number; weather_code?: number; wind_speed_10m?: number };
  daily?: {
    time?: string[];
    weather_code?: number[];
    temperature_2m_max?: number[];
    temperature_2m_min?: number[];
  };
}

/** Cache mémoire (par slug) — TTL 30 min. Reset volontaire au redeploy. */
const CACHE_TTL_MS = 30 * 60 * 1000;
const cache = new Map<string, { at: number; data: WeatherPayload }>();

// NB (v4.97) : le mapping WMO → emoji/libellé est porté côté client
// (hub-content.tsx). Une ancienne version exportait `weatherMeta` depuis ce
// route file : les route files Next.js n'acceptent que les handlers HTTP +
// leurs options d'export → erreur de type au build
// (« Property 'weatherMeta' is incompatible with index signature »). L'export
// (code mort, jamais importé) est supprimé pour rétablir le contrat.

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;
    if (!slug || slug.length > 120) {
      return NextResponse.json({ ok: false, error: 'Slug invalide' }, { status: 400 });
    }

    // ── Cache ──
    const hit = cache.get(slug);
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) {
      return NextResponse.json(hit.data);
    }

    // ── Coordonnées du bien (ou démo) ──
    let lat: number | null = null;
    let lng: number | null = null;
    if (slug === DEMO_SLUG) {
      lat = DEMO_COORDS.lat;
      lng = DEMO_COORDS.lng;
    } else {
      const resolved = await resolveHubPropertyId(slug);
      if (!resolved.ok) {
        return NextResponse.json(
          { ok: false, error: resolved.message ?? 'Hub introuvable' },
          { status: resolved.status || 404 },
        );
      }
      const property = await db.property.findUnique({
        where: { id: resolved.propertyId },
        select: { latitude: true, longitude: true },
      });
      lat = property?.latitude ?? null;
      lng = property?.longitude ?? null;
    }
    if (lat == null || lng == null) {
      return NextResponse.json(
        { ok: false, error: 'Coordonnées du logement non renseignées' },
        { status: 404 },
      );
    }

    // ── Open-Meteo (timeout 6 s) ──
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
      '&current=temperature_2m,weather_code,wind_speed_10m' +
      '&daily=weather_code,temperature_2m_max,temperature_2m_min' +
      '&timezone=auto&forecast_days=4';
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 6000);
    let json: OpenMeteoResponse | null = null;
    try {
      const res = await fetch(url, { signal: ctrl.signal, cache: 'no-store' });
      json = res.ok ? ((await res.json()) as OpenMeteoResponse) : null;
    } finally {
      clearTimeout(timer);
    }
    const cur = json?.current;
    if (!json || typeof cur?.temperature_2m !== 'number' || typeof cur.weather_code !== 'number') {
      return NextResponse.json({ ok: false, error: 'Météo indisponible' }, { status: 502 });
    }

    const daily: DailyItem[] = [];
    const times = json.daily?.time ?? [];
    for (let i = 0; i < times.length && i < 4; i++) {
      const tmax = json.daily?.temperature_2m_max?.[i];
      const tmin = json.daily?.temperature_2m_min?.[i];
      const code = json.daily?.weather_code?.[i];
      if (typeof tmax === 'number' && typeof tmin === 'number' && typeof code === 'number') {
        daily.push({ date: times[i], code, tmax: Math.round(tmax), tmin: Math.round(tmin) });
      }
    }

    const payload: WeatherPayload = {
      ok: true,
      current: {
        temp: Math.round(cur.temperature_2m),
        code: cur.weather_code,
        wind: typeof cur.wind_speed_10m === 'number' ? Math.round(cur.wind_speed_10m) : 0,
      },
      daily,
      fetchedAt: new Date().toISOString(),
    };
    cache.set(slug, { at: Date.now(), data: payload });
    return NextResponse.json(payload);
  } catch (error) {
    console.error('[GET /api/public/hub/[slug]/weather] Error:', error);
    return NextResponse.json({ ok: false, error: 'Erreur serveur' }, { status: 500 });
  }
}
