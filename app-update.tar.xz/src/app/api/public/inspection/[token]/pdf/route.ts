import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { rateLimit } from '@/lib/rate-limit';
import { clientIp } from '@/lib/audit';
import { captureError } from '@/lib/error-monitor';
import { renderStandaloneInspectionPdf } from '@/lib/inspection-standalone-pdf';
import {
  CHECKOUT_INSPECTION_PDF_SELECT,
  MINIBAR_CHECK_PDF_SELECT,
  checkOutInspectionToStandalonePdfData,
  minibarCheckToStandalonePdfData,
  type CheckOutInspectionRow,
} from '@/lib/inspection-standalone-pdf-adapter';
import { mergePdfsWithCoverPage, pdfContentDisposition } from '@/lib/inspection-merge-pdf';

// =============================================================
// v5.0 « ÉTAT DES LIEUX » — PDF PUBLIC À LA DEMANDE (sans auth)
// GET /api/public/inspection/[token]/pdf
//
// v5.3 — UNIFICATION DU DESIGN (demande client : « le pdf généré
// affiche toujours l'ancien design ») : TOUS les documents passent
// par le design certifié unifié (renderStandaloneInspectionPdf —
// bandeau rouge, QR, SHA-256, sections numérotées). L'ancien
// générateur (inspection-pdf.ts) est supprimé.
//
// Résout le token public :
//   1. CheckOutInspection (checkin/checkout Hub) → design unifié ;
//      FUSION : si un EDL d'entrée (type checkin) existe pour le
//      même booking, le PDF renvoie « État des lieux complet —
//      Entrée + Sortie » (page de garde + entrée + sortie) ;
//   2. MinibarCheck → attestation d'entrée (design unifié).
// Réponse : application/pdf inline — filename accentué RFC 5987.
// 404 si token inconnu. Rate limit 20/min par token+IP.
// =============================================================

export const dynamic = 'force-dynamic';

/** Slug lisible (espaces → tirets) en conservant les accents FR. */
function frSlug(raw: string, max = 40): string {
  return (
    raw
      .normalize('NFC')
      .toLowerCase()
      .replace(/[^a-z0-9àâäéèêëïîôöùûüçñœ\s-]/gi, '')
      .replace(/[\s_]+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, max) || 'invite'
  );
}

const frDateShort = (d: Date) =>
  d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });

export async function GET(req: Request, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params;
    const cleanToken = token.trim().slice(0, 80);
    if (!cleanToken) {
      return NextResponse.json({ error: 'Jeton manquant.' }, { status: 400 });
    }

    // Génération coûteuse (pdfkit + QR) — même garde que le PDF standalone.
    const ip = clientIp(req.headers) ?? 'local';
    if (!(await rateLimit(`insppdf:${cleanToken}:${ip}`, 20))) {
      return NextResponse.json(
        { error: 'Trop de téléchargements. Merci de patienter une minute.' },
        { status: 429 },
      );
    }

    // ── 1. État des lieux Hub (checkin / checkout) ──
    const inspection = await db.checkOutInspection.findUnique({
      where: { publicToken: cleanToken },
      select: CHECKOUT_INSPECTION_PDF_SELECT,
    });

    if (inspection) {
      const row = inspection as unknown as CheckOutInspectionRow;
      const isCheckout = row.type !== 'checkin';

      // FUSION : EDL d'entrée du même booking (couple checkin/checkout).
      const linkedEntrance =
        isCheckout && row.bookingId
          ? await db.checkOutInspection.findFirst({
              where: { bookingId: row.bookingId, type: 'checkin' },
              select: CHECKOUT_INSPECTION_PDF_SELECT,
            })
          : null;

      const guestSlug = frSlug(row.guestName);
      const doc6 = row.id.slice(-6).toUpperCase();

      if (linkedEntrance) {
        const entranceRow = linkedEntrance as unknown as CheckOutInspectionRow;
        const [entranceBuf, exitBuf] = await Promise.all([
          renderStandaloneInspectionPdf(
            checkOutInspectionToStandalonePdfData(entranceRow),
          ),
          renderStandaloneInspectionPdf(
            checkOutInspectionToStandalonePdfData(row, {
              linkedEntranceDate: entranceRow.booking?.checkIn ?? entranceRow.signedAt,
            }),
          ),
        ]);
        const buffer = await mergePdfsWithCoverPage([entranceBuf, exitBuf], {
          propertyName: row.property.name,
          propertyAddress: row.property.address,
          guestName: row.guestName,
          eventDate: row.signedAt,
          parts: [
            `Attestation d'état des lieux d'entrée — ${frDateShort(entranceRow.signedAt)}`,
            `Rapport de sortie — comparatif entrée / sortie — ${frDateShort(row.signedAt)}`,
          ],
        });
        return new NextResponse(new Uint8Array(buffer), {
          status: 200,
          headers: {
            'Content-Type': 'application/pdf',
            'Content-Disposition': pdfContentDisposition(
              `état-des-lieux-complet-${guestSlug}-${doc6}.pdf`,
            ),
            'Cache-Control': 'private, no-store',
          },
        });
      }

      // Document simple (sortie sans entrée liée, ou entrée seule).
      const buffer = await renderStandaloneInspectionPdf(
        checkOutInspectionToStandalonePdfData(row),
      );
      const typeSlug = isCheckout ? 'sortie' : 'entrée';
      return new NextResponse(new Uint8Array(buffer), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': pdfContentDisposition(
            `état-des-lieux-${typeSlug}-${guestSlug}-${doc6}.pdf`,
          ),
          'Cache-Control': 'private, no-store',
        },
      });
    }

    // ── 2. Preuve d'ARRIVÉE (inventaire validé) ──
    const check = await db.minibarCheck.findUnique({
      where: { publicToken: cleanToken },
      select: MINIBAR_CHECK_PDF_SELECT,
    });

    if (check) {
      const buffer = await renderStandaloneInspectionPdf(minibarCheckToStandalonePdfData(check));
      const guestSlug = frSlug(check.guestName ?? 'invite');
      return new NextResponse(new Uint8Array(buffer), {
        status: 200,
        headers: {
          'Content-Type': 'application/pdf',
          'Content-Disposition': pdfContentDisposition(
            `preuve-arrivee-${guestSlug}-${check.id.slice(-6).toUpperCase()}.pdf`,
          ),
          'Cache-Control': 'private, no-store',
        },
      });
    }

    return NextResponse.json({ error: 'Preuve introuvable.' }, { status: 404 });
  } catch (error) {
    await captureError('public.inspection-pdf', error, undefined, req);
    return NextResponse.json({ error: 'Erreur serveur.' }, { status: 500 });
  }
}
