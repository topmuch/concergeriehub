// =============================================================
// /api/health — « TOUR DE CONTRÔLE » (v5.6, Phase 1)
//
// Health-check production robuste : DB (ping mesuré) + Stripe +
// Resend (pings 3 s max) + disque (best effort). Public — utilisé
// par les sondes Coolify/UptimeRobot/K8s ET par le moteur de
// monitoring (tick 5 min). Aucune donnée sensible exposée.
//
// Réponse : { status: "OK" | "DEGRADED" | "DOWN", checks: { db,
// stripe, resend, disk }, totalMs, timestamp }
//   • DOWN     → HTTP 503 (DB injoignable = site inutilisable)
//   • DEGRADED → HTTP 200 (Stripe/Resend en échec ou DB lente)
//   • OK       → HTTP 200
// Compatibilité historique : champs `database` + `latencyMs`
// conservés pour les anciennes sondes.
// =============================================================
import { NextResponse } from 'next/server';
import { fetchHealthData } from '@/lib/health-check';

export const dynamic = 'force-dynamic';

export async function GET() {
  let report;
  try {
    report = await fetchHealthData();
  } catch (error) {
    // Le rapport lui-même a échoué (ex. process HS) → DOWN franc.
    console.error('[health] fetchHealthData failed:', error);
    return NextResponse.json(
      {
        status: 'DOWN',
        database: 'down',
        timestamp: new Date().toISOString(),
      },
      { status: 503 },
    );
  }

  const httpStatus = report.status === 'DOWN' ? 503 : 200;
  return NextResponse.json(
    {
      // Nouvelle forme canonique (Tour de Contrôle).
      status: report.status,
      checks: report.checks,
      totalMs: report.totalMs,
      timestamp: report.timestamp,
      // Alias historiques (sondes existantes).
      database: report.checks.db.status === 'up' ? 'up' : 'down',
      latencyMs: report.checks.db.latencyMs,
    },
    { status: httpStatus },
  );
}
