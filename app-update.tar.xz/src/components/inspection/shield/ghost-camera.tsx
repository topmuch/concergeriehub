'use client';

// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — MODE FANTÔME (v5.4)
//
// Caméra plein écran pour le CHECK-OUT : la photo de RÉFÉRENCE du
// check-in est superposée en transparence pour reproduire EXACTEMENT
// le même angle (slider d'opacité 0 → 1 + ON/OFF).
//
// INTÉGRITÉ JURIDIQUE : le fantôme est un guide de cadrage AFFICHÉ À
// L'ÉCRAN uniquement — la photo enregistrée est TOUJOURS PROPRE
// (aucun pixel du fantôme n'est incrusté). Une preuve « trouée » par
// un calque semi-transparent serait contestable devant un assureur.
// =============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import { Camera, Ghost, ImagePlus, Loader2, RotateCcw, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { canvasToCompressedDataUrl, fileToShieldPhotoDataUrl } from './shield-photo';

interface GhostCameraProps {
  roomName: string;
  /** Photo de référence du check-in (dataURL) — superposée en filigrane. */
  referencePhotoUrl?: string;
  /** Appelé avec la photo PROPRE compressée (dataURL JPEG). */
  onPhotoTaken: (photoBase64: string) => void;
  onClose: () => void;
}

export default function GhostCamera({
  roomName,
  referencePhotoUrl,
  onPhotoTaken,
  onClose,
}: GhostCameraProps) {
  const [ghostOpacity, setGhostOpacity] = useState(0.5);
  const [showGhost, setShowGhost] = useState(true);
  const [camError, setCamError] = useState(false);
  const [busy, setBusy] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Démarrage caméra arrière (une seule fois au montage).
  useEffect(() => {
    let cancelled = false;
    const startCamera = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('indisponible');
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play().catch(() => undefined);
        }
      } catch {
        if (!cancelled) setCamError(true);
      }
    };
    void startCamera();
    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, []);

  /**
   * Capture la photo RÉELLE (sans le fantôme incrusté — preuve
   * juridique incontestable) puis compression serveur-compatible.
   */
  const capturePhoto = useCallback(() => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvasToCompressedDataUrl(canvas);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    onPhotoTaken(dataUrl);
  }, [onPhotoTaken]);

  const onPickFile = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    const dataUrl = await fileToShieldPhotoDataUrl(file);
    setBusy(false);
    if (!dataUrl) return;
    onPhotoTaken(dataUrl);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black" role="dialog" aria-modal="true" aria-label={`Mode fantôme — ${roomName}`}>
      {/* Header */}
      <div className="flex items-center justify-between bg-black/80 p-3 sm:p-4">
        <button
          type="button"
          onClick={onClose}
          className="flex size-11 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          aria-label="Fermer le mode fantôme"
        >
          <X className="size-6" aria-hidden="true" />
        </button>
        <h3 className="truncate text-sm font-bold text-white sm:text-base">
          <Ghost className="mr-1.5 inline size-4 text-[#FF6B6B]" aria-hidden="true" />
          {roomName} — Mode Fantôme
        </h3>
        <div aria-hidden="true" className="size-11" />
      </div>

      {/* Zone caméra + fantôme */}
      <div className="relative flex-1 overflow-hidden bg-black">
        {camError ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <Camera className="size-10 text-white/40" aria-hidden="true" />
            <p className="text-sm text-white/80">Caméra indisponible — choisissez une photo depuis vos fichiers.</p>
            <label className="inline-flex min-h-[44px] cursor-pointer items-center gap-2 rounded-full bg-white px-5 text-sm font-bold text-black">
              <ImagePlus className="size-4" aria-hidden="true" /> Choisir une photo
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="sr-only"
                onChange={(e) => {
                  void onPickFile(e.target.files?.[0]);
                  e.currentTarget.value = '';
                }}
              />
            </label>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="absolute inset-0 h-full w-full object-cover"
              aria-label="Aperçu caméra — mode fantôme"
            />
            {/* Overlay fantôme (guide d'angle, jamais incrusté) */}
            {showGhost && referencePhotoUrl ? (
              <img
                src={referencePhotoUrl}
                alt=""
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 h-full w-full object-cover"
                style={{ opacity: ghostOpacity }}
              />
            ) : null}
            {/* Repères d'angle */}
            <div aria-hidden="true" className="pointer-events-none absolute inset-4 rounded-2xl border-2 border-dashed border-white/25" />

            {/* Déclencheur */}
            <div className="absolute inset-x-0 bottom-5 flex items-center justify-center">
              <button
                type="button"
                onClick={capturePhoto}
                disabled={camError}
                className="flex size-16 items-center justify-center rounded-full border-4 border-white/90 bg-[#C21F26] shadow-[0_0_0_8px_rgba(194,31,38,0.25)] transition-transform active:scale-95 disabled:opacity-50"
                aria-label="Capturer la photo"
              >
                <Camera className="size-7 text-white" aria-hidden="true" />
              </button>
            </div>
          </>
        )}
      </div>

      {/* Contrôles fantôme */}
      <div className="space-y-3 bg-black/80 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6">
        <div className="flex items-center gap-3">
          <Ghost className="size-5 shrink-0 text-[#FF6B6B]" aria-hidden="true" />
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={ghostOpacity}
            onChange={(e) => setGhostOpacity(parseFloat(e.target.value))}
            className="h-2 flex-1 accent-[#C21F26]"
            aria-label="Opacité du fantôme de référence"
            disabled={!showGhost || !referencePhotoUrl}
          />
          <button
            type="button"
            onClick={() => setShowGhost((v) => !v)}
            className={cn(
              'min-h-[44px] rounded-full px-4 text-xs font-bold uppercase tracking-[0.08em] transition-colors',
              showGhost ? 'bg-white text-black' : 'bg-white/20 text-white/70',
            )}
            aria-pressed={showGhost}
            aria-label={showGhost ? 'Masquer le fantôme' : 'Afficher le fantôme'}
          >
            {showGhost ? 'ON' : 'OFF'}
          </button>
        </div>

        <p className="text-center text-[11px] leading-relaxed text-white/60">
          Superposez la référence pour retrouver l&apos;angle exact du check-in. La photo enregistrée
          reste <span className="font-bold text-white/85">propre</span> (preuve juridique).
        </p>

        <div className="flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-white/25 bg-transparent px-4 text-xs font-semibold text-white/80 transition-colors hover:text-white"
          >
            <RotateCcw className="size-3.5" aria-hidden="true" /> Annuler
          </button>
          {!camError ? (
            <label className="inline-flex min-h-[44px] cursor-pointer items-center gap-2 rounded-full border border-white/25 px-4 text-xs font-semibold text-white/80 transition-colors hover:text-white">
              <ImagePlus className="size-4" aria-hidden="true" /> Depuis les fichiers
              <input
                type="file"
                accept="image/*"
                capture="environment"
                className="sr-only"
                disabled={busy}
                onChange={(e) => {
                  void onPickFile(e.target.files?.[0]);
                  e.currentTarget.value = '';
                }}
              />
            </label>
          ) : (
            <span aria-hidden="true" />
          )}
        </div>
        {busy ? (
          <p className="flex items-center justify-center gap-2 text-[11px] text-white/70" role="status">
            <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> Compression de la photo…
          </p>
        ) : null}
      </div>
    </div>
  );
}
