'use client';

// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — VIDÉO WALKTHROUGH (v5.4 + V2)
//
// Enregistrement d'UNE TRAVERSÉE CONTINUE (preuve reine) :
//   · durée max paramétrable (60 s V1 / 120 s V2), arrêt
//     automatique, badge REC + compte à rebours ;
//   · hash SHA-256 calculé DANS LE NAVIGATEUR dès l'aperçu
//     (double contrôle — le serveur recalcule le sien, non
//     falsifiable, avant scellement du certificat) ;
//   · aperçu + « Utiliser » / « Refaire » avant tout envoi.
// =============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import { Check, FileVideo, Loader2, Square, Video, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { generateSHA256Hash, shortHash } from '@/lib/crypto-utils';
import { blobToBase64 } from './shield-photo';

interface VideoRecorderProps {
  /** Appelé à la confirmation : blob brut, base64 SANS préfixe, durée (s). */
  onVideoRecorded: (videoBlob: Blob, videoBase64: string, duration: number) => void;
  onClose: () => void;
  /** V2 : durée max (défaut 60 s — rétro-compatible circuit v5.4). */
  maxDuration?: number;
  /** V2 : garde-fou taille (défaut 20 Mo). */
  maxBytes?: number;
}

/** webm vp8 d'abord (compatibilité maximale, même choix que v5.1). */
function pickVideoMimeType(): string | undefined {
  if (typeof MediaRecorder === 'undefined') return undefined;
  const candidates = ['video/webm;codecs=vp8', 'video/mp4', 'video/webm'];
  for (const c of candidates) {
    if (MediaRecorder.isTypeSupported(c)) return c;
  }
  return undefined;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.max(0, seconds % 60);
  return `${mins}:${String(secs).padStart(2, '0')}`;
}

export default function VideoRecorder({
  onVideoRecorded,
  onClose,
  maxDuration = 60,
  maxBytes = 20_000_000,
}: VideoRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [duration, setDuration] = useState(0);
  const [countdown, setCountdown] = useState(maxDuration);
  const [camError, setCamError] = useState(false);
  const [preview, setPreview] = useState<{ url: string; blob: Blob; elapsed: number; hash: string | null } | null>(null);
  const [hashBusy, setHashBusy] = useState(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedAtRef = useRef(0);
  const previewUrlRef = useRef<string | null>(null);

  const stopStream = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  }, []);

  const clearTimer = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = null;
  }, []);

  const stopRecording = useCallback(() => {
    const rec = mediaRecorderRef.current;
    if (rec && rec.state !== 'inactive') {
      try {
        rec.stop();
      } catch {
        /* déjà arrêté */
      }
    }
    clearTimer();
  }, [clearTimer]);

  // Démarrage caméra + micro au montage.
  useEffect(() => {
    let cancelled = false;
    const startCamera = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
          throw new Error('indisponible');
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: true,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          void videoRef.current.play().catch(() => undefined);
        }
      } catch {
        if (!cancelled) setCamError(true);
      }
    };
    void startCamera();
    return () => {
      cancelled = true;
      clearTimer();
      stopStream();
      if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
    };
  }, [clearTimer, stopStream]);

  const finalize = useCallback(
    async (blob: Blob, elapsed: number) => {
      if (blob.size > maxBytes) {
        setCamError(false);
        setIsRecording(false);
        // L'aperçu d'erreur est géré par le parent via un blob vide →
        // on ferme et on laisse le toast du parent repartir proprement.
        onClose();
        return;
      }
      setHashBusy(true);
      const base64 = await blobToBase64(blob).catch(() => '');
      const url = URL.createObjectURL(blob);
      previewUrlRef.current = url;
      const hash = await generateSHA256Hash(blob);
      setHashBusy(false);
      setPreview({ url, blob, elapsed, hash });
    },
    [onClose],
  );

  const startRecording = () => {
    const stream = streamRef.current;
    if (!stream) {
      setCamError(true);
      return;
    }
    const mimeType = pickVideoMimeType();
    const mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    mediaRecorderRef.current = mediaRecorder;
    chunksRef.current = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
    };
    mediaRecorder.onstop = () => {
      const elapsed = Math.max(3, Math.round((Date.now() - startedAtRef.current) / 1000));
      const blob = new Blob(chunksRef.current, {
        type: mediaRecorder.mimeType || mimeType || 'video/webm',
      });
      stopStream();
      setIsRecording(false);
      void finalize(blob, elapsed);
    };

    mediaRecorder.start(1000);
    startedAtRef.current = Date.now();
    setIsRecording(true);
    setDuration(0);
    setCountdown(maxDuration);
    timerRef.current = setInterval(() => {
      const elapsed = Math.round((Date.now() - startedAtRef.current) / 1000);
      setDuration(elapsed);
      const left = maxDuration - elapsed;
      setCountdown(Math.max(0, left));
      if (left <= 0) stopRecording();
    }, 1000);
  };

  const confirm = () => {
    if (!preview) return;
    const { blob, elapsed } = preview;
    void (async () => {
      const base64 = await blobToBase64(blob);
      onVideoRecorded(blob, base64, elapsed);
    })();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black" role="dialog" aria-modal="true" aria-label="Enregistrement vidéo walkthrough">
      {/* Header */}
      <div className="flex items-center justify-between bg-black/80 p-3 sm:p-4">
        <button
          type="button"
          onClick={() => {
            stopRecording();
            onClose();
          }}
          className="flex size-11 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          aria-label="Fermer l'enregistrement vidéo"
        >
          <X className="size-6" aria-hidden="true" />
        </button>
        <h3 className="text-sm font-bold text-white sm:text-base">
          <Video className="mr-1.5 inline size-4 text-[#FF6B6B]" aria-hidden="true" />
          Vidéo Walkthrough
        </h3>
        <div aria-hidden="true" className="size-11" />
      </div>

      {/* Zone vidéo */}
      <div className="relative flex-1 overflow-hidden bg-black">
        {preview ? (
          <video
            src={preview.url}
            controls
            playsInline
            className="absolute inset-0 h-full w-full object-contain"
            aria-label="Aperçu de la vidéo enregistrée"
          />
        ) : camError ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-6 text-center">
            <FileVideo className="size-10 text-white/40" aria-hidden="true" />
            <p className="text-sm text-white/80">
              Caméra vidéo indisponible — revenez en arrière et choisissez une vidéo depuis vos fichiers.
            </p>
          </div>
        ) : (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="absolute inset-0 h-full w-full object-cover"
            aria-label="Aperçu caméra — vidéo walkthrough"
          />
        )}

        {/* Badge REC */}
        {isRecording ? (
          <div className="absolute left-4 top-4 flex items-center gap-2 rounded-full bg-[#C21F26] px-4 py-2 text-xs font-bold text-white">
            <span className="size-3 animate-pulse rounded-full bg-white" aria-hidden="true" />
            REC {formatTime(duration)}
          </div>
        ) : null}

        {/* Compte à rebours */}
        {isRecording ? (
          <div className="absolute right-4 top-4 rounded-full bg-black/70 px-4 py-2 text-xs font-semibold text-white">
            ⏱ {countdown}s restants
          </div>
        ) : null}
      </div>

      {/* Contrôles */}
      <div className="space-y-3 bg-black/80 p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6">
        {preview ? (
          <>
            <div className="rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-center" role="status">
              {hashBusy ? (
                <p className="flex items-center justify-center gap-2 text-xs text-white/70">
                  <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> Calcul de l&apos;empreinte SHA-256…
                </p>
              ) : (
                <p className="font-mono text-[11px] leading-relaxed text-white/80">
                  <span className="font-bold text-emerald-400">HASH SHA-256 VIDÉO :</span>
                  <br />
                  {preview.hash ? shortHash(preview.hash, 32) : 'indisponible (recalculé par le serveur)'}
                </p>
              )}
            </div>
            <div className="flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  if (previewUrlRef.current) URL.revokeObjectURL(previewUrlRef.current);
                  previewUrlRef.current = null;
                  setPreview(null);
                  void navigator.mediaDevices
                    ?.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: true })
                    .then((stream) => {
                      streamRef.current = stream;
                      if (videoRef.current) {
                        videoRef.current.srcObject = stream;
                        void videoRef.current.play().catch(() => undefined);
                      }
                    })
                    .catch(() => setCamError(true));
                }}
                className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-white/25 px-4 text-xs font-semibold text-white/80 transition-colors hover:text-white"
              >
                <FileVideo className="size-3.5" aria-hidden="true" /> Refaire
              </button>
              <Button
                type="button"
                size="sm"
                onClick={confirm}
                className={cn('min-h-[44px] rounded-full bg-[#C21F26] px-6 font-bold text-white hover:bg-[#a81a20]')}
                aria-label="Utiliser cette vidéo"
              >
                <Check className="size-4" aria-hidden="true" /> Utiliser cette vidéo
              </Button>
            </div>
          </>
        ) : !isRecording ? (
          <>
            <button
              type="button"
              onClick={startRecording}
              disabled={camError}
              className="flex min-h-[56px] w-full items-center justify-center gap-2 rounded-2xl bg-[#C21F26] font-bold text-white transition-colors hover:bg-[#a81a20] disabled:opacity-50"
              aria-label={`Commencer l'enregistrement (${maxDuration} secondes maximum)`}
            >
              <Video className="size-6" aria-hidden="true" />
              COMMENCER L&apos;ENREGISTREMENT ({maxDuration}s max)
            </button>
            <p className="text-center text-sm text-white/60">
              Parcourez toutes les pièces en continu pour la preuve juridique.
            </p>
          </>
        ) : (
          <>
            <button
              type="button"
              onClick={stopRecording}
              className="flex min-h-[56px] w-full items-center justify-center gap-2 rounded-2xl bg-white/15 font-bold text-white transition-colors hover:bg-white/25"
              aria-label="Arrêter l'enregistrement"
            >
              <Square className="size-5 fill-white" aria-hidden="true" />
              ARRÊTER L&apos;ENREGISTREMENT
            </button>
            <p className="text-center text-sm text-white/60">
              Traversez salon → couloir → chambres → cuisine → SDB sans interruption.
            </p>
          </>
        )}
      </div>
    </div>
  );
}
