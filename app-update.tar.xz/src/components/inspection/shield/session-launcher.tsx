'use client';

// =============================================================
// BOUCLIER SESSION LAUNCHER (v5.5) — Circuit client depuis le
// tableau de bord de la console EDL :
//   1. Aucun logement onboardé → CTA « Onboarder un logement »
//      (onboarding 10 min : type de logement + équipements + photos
//      de référence → bibliothèque verrouillée). OBLIGATOIRE avant
//      tout check-in — un logement jamais onboardé ne peut pas
//      lancer de session.
//   2. Logement(s) onboardé(s) → choix du logement + type de session
//      (CHECK_IN / CHECK_OUT) → la session 90 s s'ouvre dans
//      l'onglet Bouclier : 6 photos aux angles fixes (fantômes) +
//      vidéo walkthrough 30 s → certificat PDF scellé SHA-256.
// =============================================================
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { Building2, Lock, LogIn, LogOut, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

export interface LauncherProperty {
  id: string;
  propertyName: string;
  propertyAddress: string;
  city: string;
  /** Type de la dernière session — CHECK_IN = cycle ouvert (sortie dispo). */
  lastSessionType: 'CHECK_IN' | 'CHECK_OUT' | null;
}

interface BouclierSessionLauncherProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  /** Aucun logement onboardé → l'hôte doit d'abord faire l'onboarding. */
  onLaunchOnboarding: () => void;
  /** Logement onboardé sélectionné → ouvre la session 90 s. */
  onLaunchSession: (propertyId: string, type: 'CHECK_IN' | 'CHECK_OUT') => void;
}

export function BouclierSessionLauncher({
  open,
  onOpenChange,
  onLaunchOnboarding,
  onLaunchSession,
}: BouclierSessionLauncherProps) {
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [subRequired, setSubRequired] = useState(false);
  const [props, setProps] = useState<LauncherProperty[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [type, setType] = useState<'CHECK_IN' | 'CHECK_OUT'>('CHECK_IN');

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    setSubRequired(false);
    try {
      const res = await fetch('/api/shield/properties', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as
        | { properties?: LauncherProperty[]; error?: string; message?: string }
        | null;
      if (!res.ok) {
        if (res.status === 403 && json?.error === 'abonnement_requis') {
          setSubRequired(true);
          return;
        }
        throw new Error(json?.error ?? `HTTP ${res.status}`);
      }
      setProps(json?.properties ?? []);
    } catch {
      setLoadError('Chargement impossible — vérifiez votre connexion puis réessayez.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    setProps(null);
    setSelectedId(null);
    setType('CHECK_IN');
    void load();
  }, [open, load]);

  const selected = props?.find((p) => p.id === selectedId) ?? null;
  // Verrou cycle (v4.120) : CHECK_IN ouvert → sortie disponible, entrée
  // bloquée ; sinon nouvelle entrée disponible, sortie indisponible.
  const cycleOpen = selected?.lastSessionType === 'CHECK_IN';

  const choose = (id: string) => {
    setSelectedId(id);
    const p = props?.find((x) => x.id === id);
    // Si le cycle est ouvert (dernière session = CHECK_IN), le check-out
    // est l'action naturelle ; sinon on propose le check-in.
    setType(p?.lastSessionType === 'CHECK_IN' ? 'CHECK_OUT' : 'CHECK_IN');
  };

  const launch = () => {
    if (!selected) return;
    onLaunchSession(selected.id, type);
  };

  const checkInBlocked = cycleOpen;
  const checkOutBlocked = !cycleOpen;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-2xl sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg font-black text-gray-900">
            <ShieldCheck className="size-5 text-[#C21F26]" aria-hidden="true" /> Nouveau check-in /
            check-out
          </DialogTitle>
          <DialogDescription className="text-xs text-gray-500">
            Circuit Bouclier : onboarding une seule fois par logement, puis 90 secondes par session
            (6 photos aux angles fixes + vidéo 30 s → certificat PDF scellé).
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="space-y-3" role="status" aria-label="Chargement des logements">
            <Skeleton className="h-16 w-full rounded-2xl bg-gray-200 dark:bg-gray-200" />
            <Skeleton className="h-16 w-full rounded-2xl bg-gray-200 dark:bg-gray-200" />
          </div>
        ) : loadError ? (
          <div role="alert" className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <p className="font-semibold">{loadError}</p>
            <Button type="button" size="sm" variant="outline" onClick={() => void load()} className="mt-2 min-h-[44px] rounded-full px-5">
              Réessayer
            </Button>
          </div>
        ) : subRequired ? (
          <div role="alert" className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <p className="font-semibold">Abonnement requis</p>
            <p className="mt-1 text-xs">
              Le module Bouclier est inclus dans l&apos;offre États des Lieux (299 €/an, PDF
              illimités).
            </p>
            <Link
              href="/edl/abonnement"
              className="mt-3 inline-flex min-h-[44px] items-center rounded-full bg-[#C21F26] px-5 text-sm font-bold text-white hover:bg-[#a81a20]"
            >
              Voir l&apos;abonnement
            </Link>
          </div>
        ) : props && props.length === 0 ? (
          /* ── Aucun logement onboardé → ONBOARDING OBLIGATOIRE ── */
          <div className="flex flex-col items-center gap-4 rounded-2xl border border-gray-200 bg-white p-6 text-center">
            <span className="flex size-14 items-center justify-center rounded-full bg-red-50">
              <Lock className="size-7 text-[#C21F26]" aria-hidden="true" />
            </span>
            <h3 className="text-base font-black uppercase tracking-wide text-gray-900">
              Aucun logement onboardé
            </h3>
            <p className="max-w-sm text-sm text-gray-500">
              Avant le premier check-in, chaque logement passe par l&apos;onboarding (10 min, une
              seule fois) : type de logement (studio, 2 chambres-salon…), équipements réels, photos
              de référence → bibliothèque verrouillée.
            </p>
            <Button
              type="button"
              onClick={() => {
                onOpenChange(false);
                onLaunchOnboarding();
              }}
              className="mt-1 min-h-[48px] rounded-full bg-[#C21F26] px-6 text-sm font-bold text-white shadow-[0_14px_36px_-14px_rgba(194,31,38,0.8)] hover:bg-[#a81a20]"
              aria-label="Onboarder un logement maintenant (10 minutes, une seule fois)"
            >
              Onboarder un logement (10 min — une seule fois)
            </Button>
          </div>
        ) : props ? (
          /* ── Sélection du logement + type de session ── */
          <div className="space-y-4">
            <fieldset>
              <legend className="text-xs font-black uppercase tracking-[0.14em] text-gray-500">
                1 · Logement concerné
              </legend>
              <div className="mt-2 space-y-2">
                {props.map((p) => {
                  const active = p.id === selectedId;
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => choose(p.id)}
                      aria-pressed={active}
                      className={cn(
                        'flex w-full min-h-[60px] items-center gap-3 rounded-2xl border-2 px-4 py-3 text-left transition-all',
                        active
                          ? 'border-[#C21F26] bg-red-50 text-gray-900'
                          : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50',
                      )}
                    >
                      <span
                        className={cn(
                          'flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2',
                          active ? 'border-[#C21F26] bg-[#C21F26]' : 'border-gray-300',
                        )}
                      >
                        {active && (
                          <span className="block h-2 w-2 rounded-full bg-white" aria-hidden="true" />
                        )}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-bold">{p.propertyName}</span>
                        <span className="block truncate text-xs text-gray-500">
                          {p.propertyAddress}
                        </span>
                      </span>
                      {p.lastSessionType === 'CHECK_IN' ? (
                        <span className="shrink-0 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-700">
                          cycle ouvert
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </fieldset>

            <fieldset disabled={!selected}>
              <legend className="text-xs font-black uppercase tracking-[0.14em] text-gray-500">
                2 · Type de session
              </legend>
              <div className="mt-2 grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => setType('CHECK_IN')}
                  disabled={!selected || checkInBlocked}
                  title={
                    selected && checkInBlocked
                      ? 'Entrée déjà générée pour ce séjour — lancez le check-out pour clôturer le cycle.'
                      : undefined
                  }
                  aria-pressed={type === 'CHECK_IN'}
                  className={cn(
                    'flex min-h-[60px] flex-col items-start gap-1 rounded-2xl border-2 px-4 py-3 text-left transition-all disabled:cursor-not-allowed disabled:opacity-50',
                    type === 'CHECK_IN'
                      ? 'border-[#C21F26] bg-red-50 text-gray-900'
                      : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50',
                  )}
                >
                  <span className="flex items-center gap-2 text-sm font-bold">
                    <LogIn className="size-4" aria-hidden="true" /> Check-in (entrée)
                  </span>
                  <span className="text-xs text-gray-500">
                    {selected && checkInBlocked
                      ? 'Entrée déjà générée — lecture seule'
                      : '6 photos impeccables + vidéo 30 s'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setType('CHECK_OUT')}
                  disabled={!selected || checkOutBlocked}
                  aria-pressed={type === 'CHECK_OUT'}
                  title={
                    selected && checkOutBlocked
                      ? 'Le check-out clôture le check-in ouvert — aucun cycle ouvert pour ce logement.'
                      : undefined
                  }
                  className={cn(
                    'flex min-h-[60px] flex-col items-start gap-1 rounded-2xl border-2 px-4 py-3 text-left transition-all disabled:cursor-not-allowed disabled:opacity-50',
                    type === 'CHECK_OUT'
                      ? 'border-[#C21F26] bg-red-50 text-gray-900'
                      : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50',
                  )}
                >
                  <span className="flex items-center gap-2 text-sm font-bold">
                    <LogOut className="size-4" aria-hidden="true" /> Check-out (sortie)
                  </span>
                  <span className="text-xs text-gray-500">
                    {selected && cycleOpen
                      ? '6 photos état laissé + comparatif PDF'
                      : 'Disponible après un check-in'}
                  </span>
                </button>
              </div>
            </fieldset>

            <Button
              type="button"
              disabled={!selected}
              onClick={launch}
              className="min-h-[48px] w-full rounded-full bg-[#C21F26] text-sm font-bold text-white shadow-[0_14px_36px_-14px_rgba(194,31,38,0.8)] hover:bg-[#a81a20] disabled:cursor-not-allowed disabled:opacity-40"
              aria-label="Démarrer la session 90 secondes"
            >
              <Building2 className="size-4" aria-hidden="true" />
              {selected
                ? `Démarrer la session 90 s — ${type === 'CHECK_IN' ? 'check-in' : 'check-out'}`
                : 'Sélectionnez un logement'}
            </Button>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
