'use client';

// =============================================================
// ROOMSCAN BOUCLIER PREMIUM — ANNOTATEUR DE DÉGÂTS (v5.4)
//
// Encadrement d'anomalie sur la photo : glisser doigt/souris pour
// dessiner le rectangle rouge (coordonnées 0–1 relatives à l'image).
// Le cadre proposé par la DÉTECTION SMART est pré-affiché et reste
// AJUSTABLE par l'agent (l'IA propose, l'humain confirme — valeur
// juridique supérieure). Support souris ET tactile (pointer events).
// =============================================================
import { useRef, useState } from 'react';
import { Eraser, Move } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface DamageAnnotatorProps {
  imageUrl: string;
  /** Cadre proposé par l'IA (0–1) — pré-affiché, ajustable. */
  boundingBox?: BoundingBox;
  /** Appelé dès qu'un cadre valide (> 5 % de l'image) est dessiné. */
  onAnnotation: (box: BoundingBox) => void;
  /** Description de l'anomalie (IA + ajustements agent). */
  description: string;
  className?: string;
}

/** Cadre minimal viable : 5 % de largeur/hauteur (anti-bruit). */
const MIN_BOX = 0.05;

export default function DamageAnnotator({
  imageUrl,
  boundingBox,
  onAnnotation,
  description,
  className,
}: DamageAnnotatorProps) {
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [currentBox, setCurrentBox] = useState<BoundingBox | undefined>(boundingBox);
  const [justDrawn, setJustDrawn] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const pointFromEvent = (e: React.PointerEvent) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return null;
    return {
      x: Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)),
      y: Math.min(1, Math.max(0, (e.clientY - rect.top) / rect.height)),
    };
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    const p = pointFromEvent(e);
    if (!p) return;
    e.currentTarget.setPointerCapture?.(e.pointerId);
    setIsDrawing(true);
    setJustDrawn(false);
    setStartPos(p);
    setCurrentBox({ x: p.x, y: p.y, width: 0, height: 0 });
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDrawing) return;
    const p = pointFromEvent(e);
    if (!p) return;
    setCurrentBox({
      x: Math.min(startPos.x, p.x),
      y: Math.min(startPos.y, p.y),
      width: Math.abs(p.x - startPos.x),
      height: Math.abs(p.y - startPos.y),
    });
  };

  const handlePointerUp = () => {
    if (isDrawing && currentBox && currentBox.width >= MIN_BOX && currentBox.height >= MIN_BOX) {
      onAnnotation(currentBox);
      setJustDrawn(true);
    }
    setIsDrawing(false);
  };

  const clearBox = () => {
    setCurrentBox(undefined);
    setJustDrawn(false);
  };

  return (
    <div className={cn('space-y-3', className)}>
      <div
        ref={containerRef}
        className="relative cursor-crosshair touch-none select-none overflow-hidden rounded-lg border-2 border-red-500 bg-black"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        role="img"
        aria-label="Photo de la zone — glissez pour encadrer le dégât"
      >
        <img src={imageUrl} alt="Photo de la zone avec anomalie" className="block w-full" draggable={false} />

        {/* Rectangle rouge */}
        {currentBox ? (
          <div
            className={cn(
              'pointer-events-none absolute border-4 border-red-600 bg-red-600/20 transition-opacity',
              isDrawing ? 'opacity-80' : 'opacity-100',
            )}
            style={{
              left: `${currentBox.x * 100}%`,
              top: `${currentBox.y * 100}%`,
              width: `${currentBox.width * 100}%`,
              height: `${currentBox.height * 100}%`,
            }}
          >
            {!isDrawing && currentBox.width >= MIN_BOX ? (
              <span className="absolute -top-0.5 left-0 -translate-y-full whitespace-nowrap rounded-t bg-red-600 px-2 py-1 text-[10px] font-bold text-white">
                ⚠ DÉGÂT{justDrawn ? ' — cadre validé' : ''}
              </span>
            ) : null}
          </div>
        ) : null}
      </div>

      {/* Description IA */}
      <div className="rounded-lg border border-red-200 bg-red-50 p-3">
        <p className="text-sm font-medium text-red-900">📝 Description IA :</p>
        <p className="mt-1 text-sm leading-relaxed text-red-700">{description}</p>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-xs text-gray-500">
          <Move className="size-3.5" aria-hidden="true" />
          Glissez sur la photo pour ajuster le cadre du dégât.
        </p>
        {currentBox && !isDrawing ? (
          <button
            type="button"
            onClick={clearBox}
            className="inline-flex min-h-[44px] items-center gap-1.5 rounded-full border border-gray-300 bg-white px-3 text-xs font-semibold text-gray-700 transition-colors hover:bg-gray-50 hover:text-gray-900"
            aria-label="Effacer le cadre du dégât"
          >
            <Eraser className="size-3.5" aria-hidden="true" /> Effacer le cadre
          </button>
        ) : null}
      </div>
    </div>
  );
}
