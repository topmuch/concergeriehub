// =============================================================
// EDL CONSOLE — types partagés entre les onglets (v4.125).
// Évite les imports circulaires entre edl-console.tsx et les
// sous-composants (settings / support / guide).
// =============================================================

/** Clés de vue de la console (sidebar). */
export type ViewKey =
  | 'dashboard'
  | 'sejours'
  | 'biens'
  | 'documents'
  | 'parametres'
  | 'assistance'
  | 'guide'
  | 'abonnement';

/** Utilisateur de session transmis aux vues. */
export interface SessionUser {
  id: string;
  name: string | null;
  email: string | null;
}
