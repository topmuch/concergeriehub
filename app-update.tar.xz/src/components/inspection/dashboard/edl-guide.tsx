'use client';

// =============================================================
// EDL GUIDE — ONGLET « MODE D'EMPLOI » (v4.125)
// Guide du module États des Lieux : le circuit complet pas à pas
// (souscription → onboarding → séjour → check-in → check-out →
// PDF fusionné) + explication de CHAQUE onglet du tableau de bord
// (à quoi il sert, comment ça marche). Statique, sans appel API.
// =============================================================
import { useState } from 'react';
import Link from 'next/link';
import {
  BookOpen,
  Building2,
  CalendarDays,
  ChevronDown,
  CreditCard,
  FileText,
  LayoutDashboard,
  LifeBuoy,
  Plus,
  Settings,
  ShieldCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import type { ViewKey } from './edl-types';

const C = {
  blueDeep: '#2464C2',
  ink: '#1E2A3B',
  muted: '#6B7A93',
  line: '#E3E9F4',
  cta: '#C21F26',
  violet: '#8B5CF6',
} as const;

/** Une carte blanche, même style que le reste de la console. */
function GuideCard({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={cn('rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5', className)}
      style={{ borderColor: C.line }}
    >
      {children}
    </section>
  );
}

// ---------- Circuit en 5 étapes ----------

const STEPS: { n: string; title: string; desc: string }[] = [
  {
    n: '1',
    title: 'Souscrire à l’offre',
    desc: 'Vous avez souscrit à l’offre États des Lieux (299 €/an) — générations illimitées. Le paiement se fait en ligne (PayPal) et votre compte est activé immédiatement.',
  },
  {
    n: '2',
    title: 'Configurer votre bien (onboarding, 1 seule fois)',
    desc: 'Après le paiement, la page « Configuration » s’ouvre automatiquement : choisissez le type de logement (studio, 2 ou 3 chambres), les pièces et les équipements à afficher, puis prenez la photo de référence de chaque pièce. Cette étape n’apparaît qu’une seule fois — vous pourrez toujours tout modifier dans l’onglet « Paramètres ».',
  },
  {
    n: '3',
    title: 'Créer un nouveau séjour',
    desc: 'Dans le tableau de bord, cliquez sur « Créer un nouveau séjour » : choisissez le bien (ou saisissez-en un librement), indiquez le nom de l’invité, ses dates d’entrée et de sortie. Le check-in ET le check-out sont créés ensemble et restent liés.',
  },
  {
    n: '4',
    title: 'Remplir le check-in puis le check-out',
    desc: 'Partagez le lien public à l’invité (bouton « Lien » — aucune inscription, aucun mot de passe) : l’invité vérifie chaque pièce, note l’état des équipements, ajoute des photos et signe électroniquement. Vous pouvez aussi remplir vous-même en ouvrant le lien.',
  },
  {
    n: '5',
    title: 'Recevoir le PDF fusionné (entrée + sortie)',
    desc: 'Dès que le check-out est signé, le système génère automatiquement UN document unique (pages « ENTRÉE » puis pages « SORTIE », empreinte SHA-256 anti-fraude) et l’envoie par email à l’hôte ET à l’invité. Il reste téléchargeable à tout moment dans « Documents ».',
  },
];

// ---------- Explication onglet par onglet ----------

const TABS: {
  key: ViewKey;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  what: string;
  how: string;
}[] = [
  {
    key: 'dashboard',
    icon: LayoutDashboard,
    title: 'Tableau de bord',
    what: 'Vue d’ensemble de votre activité : compteurs (check-ins complétés, check-outs, documents scellés, séjours complets), graphiques d’activité et derniers séjours.',
    how: 'Tout se met à jour automatiquement. Le bouton rouge « Créer un nouveau séjour » (en haut) et « Nouveau séjour » (carte volumétrie) ouvrent le formulaire de création.',
  },
  {
    key: 'sejours',
    icon: CalendarDays,
    title: 'Séjours',
    what: 'La liste complète de vos états des lieux (check-ins et check-outs), avec leur statut et leurs actions.',
    how: 'Chaque ligne propose : « Lien » (ouvre le lien public à transmettre à l’invité — sans mot de passe), la copie du lien, « Email » ou « WhatsApp » pour l’envoyer, « PDF » (document individuel), « Fusionné » (PDF complet entrée + sortie, disponible dès que le check-out est signé) et la suppression (double clic pour confirmer). La barre de recherche filtre par logement ou invité.',
  },
  {
    key: 'biens',
    icon: Building2,
    title: 'Mes biens',
    what: 'Les logements que vous avez configurés lors de l’onboarding (nom, adresse, pièces, référence d’onboarding).',
    how: 'La carte « Ajouter un bien » relance l’onboarding guidé pour configurer un nouveau logement (photos de référence + équipements).',
  },
  {
    key: 'documents',
    icon: FileText,
    title: 'Documents',
    what: 'Vos séjours présentés DÉJÀ FUSIONNÉS : chaque carte regroupe le check-in et le check-out du même séjour.',
    how: 'Séjour complet → le PDF fusionné (entrée puis sortie) se télécharge en un clic. Séjour en cours → les PDF individuels disponibles sont proposés. La recherche filtre par logement ou invité.',
  },
  {
    key: 'parametres',
    icon: Settings,
    title: 'Paramètres',
    what: 'Le contenu de référence de votre logement, réparti en 4 onglets : « Mon appartement » (photos des pièces), « Électroménagers », « Électroniques » et « Divers & accessoires ».',
    how: 'Vous avez refait la peinture, changé la décoration ou remplacé un appareil ? Remplacez simplement la photo, renommez, ajoutez ou supprimez : les nouvelles photos de référence sont horodatées et scellées (SHA-256) et servent aux prochains états des lieux.',
  },
  {
    key: 'assistance',
    icon: LifeBuoy,
    title: 'Assistance',
    what: 'Un problème, une question ? Ouvrez un ticket : votre demande arrive directement chez l’équipe RoomScan (onglet Assistance du centre de supervision).',
    how: 'Créez un ticket (sujet, catégorie, priorité), puis échangez dans le fil de discussion. Vous recevez la réponse de l’équipe ici même ; vous pouvez clôturer un ticket résolu en un clic.',
  },
  {
    key: 'abonnement',
    icon: CreditCard,
    title: 'Abonnement',
    what: 'Le récapitulatif de votre offre : formule, statut, date d’expiration.',
    how: 'Si l’abonnement expire, un bandeau vous invite à le renouveler — vos documents restent consultables, mais la création de nouveaux séjours nécessite un abonnement actif.',
  },
];

export function GuideView({ setView }: { setView: (v: ViewKey) => void }) {
  const [openTab, setOpenTab] = useState<string | null>('dashboard');

  return (
    <div className="grid gap-4">
      {/* ── Intro ── */}
      <GuideCard>
        <div className="flex items-start gap-3">
          <span
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
            style={{ background: '#EFEAFE', color: C.violet }}
            aria-hidden="true"
          >
            <BookOpen className="h-5 w-5" />
          </span>
          <div>
            <h2 className="text-base font-black" style={{ color: C.ink }}>
              Bienvenue dans le module États des Lieux
            </h2>
            <p className="mt-1 text-sm leading-relaxed" style={{ color: C.muted }}>
              Ce mode d’emploi explique le circuit complet, étape par étape, puis détaille
              chaque onglet du tableau de bord : à quoi il sert et comment ça marche.
            </p>
          </div>
        </div>
      </GuideCard>

      {/* ── Le circuit en 5 étapes ── */}
      <GuideCard>
        <p className="text-sm font-bold" style={{ color: C.blueDeep }}>
          Le circuit complet — 5 étapes
        </p>
        <ol className="mt-3 space-y-3">
          {STEPS.map((s) => (
            <li key={s.n} className="flex gap-3">
              <span
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-black text-white"
                style={{ background: C.blueDeep }}
                aria-hidden="true"
              >
                {s.n}
              </span>
              <div className="min-w-0">
                <p className="text-sm font-bold" style={{ color: C.ink }}>
                  {s.title}
                </p>
                <p className="mt-0.5 text-[13px] leading-relaxed" style={{ color: C.muted }}>
                  {s.desc}
                </p>
              </div>
            </li>
          ))}
        </ol>
        <div className="mt-4 flex flex-wrap items-center gap-2 rounded-lg border px-3 py-2.5 text-xs" style={{ borderColor: C.line, color: C.muted }}>
          <ShieldCheck className="h-4 w-4 shrink-0" style={{ color: C.blueDeep }} aria-hidden="true" />
          <span>
            <strong style={{ color: C.ink }}>Bon à savoir :</strong> le lien public envoyé à l’invité
            fonctionne <strong style={{ color: C.ink }}>sans compte ni mot de passe</strong> — la signature
            électronique et l’empreinte SHA-256 donnent au document sa valeur juridique.
          </span>
        </div>
      </GuideCard>

      {/* ── Les onglets, un par un (accordéon) ── */}
      <GuideCard>
        <p className="text-sm font-bold" style={{ color: C.blueDeep }}>
          Les onglets du tableau de bord, expliqués un par un
        </p>
        <p className="mt-1 text-xs" style={{ color: C.muted }}>
          Cliquez sur un onglet pour découvrir son rôle et son fonctionnement.
        </p>
        <div className="mt-3 space-y-2">
          {TABS.map((t) => {
            const Icon = t.icon;
            const open = openTab === t.key;
            return (
              <div key={t.key} className="overflow-hidden rounded-lg border" style={{ borderColor: C.line }}>
                <button
                  type="button"
                  onClick={() => setOpenTab(open ? null : t.key)}
                  aria-expanded={open}
                  className="flex min-h-[44px] w-full items-center gap-3 px-3 py-2 text-left transition-colors hover:bg-[#F4F7FD]"
                >
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg"
                    style={{ background: '#E2F1FB', color: C.blueDeep }}
                    aria-hidden="true"
                  >
                    <Icon className="h-4 w-4" />
                  </span>
                  <span className="flex-1 text-sm font-bold" style={{ color: C.ink }}>
                    {t.title}
                  </span>
                  <ChevronDown
                    className={cn('h-4 w-4 shrink-0 transition-transform', open && 'rotate-180')}
                    style={{ color: C.muted }}
                    aria-hidden="true"
                  />
                </button>
                {open ? (
                  <div className="border-t px-3 py-3" style={{ borderColor: C.line }}>
                    <p className="text-[13px] leading-relaxed" style={{ color: C.ink }}>
                      <strong style={{ color: C.blueDeep }}>À quoi ça sert :</strong> {t.what}
                    </p>
                    <p className="mt-2 text-[13px] leading-relaxed" style={{ color: C.muted }}>
                      <strong style={{ color: C.ink }}>Comment ça marche :</strong> {t.how}
                    </p>
                    <button
                      type="button"
                      onClick={() => setView(t.key)}
                      className="mt-2.5 inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-bold transition-colors hover:bg-[#F4F7FD]"
                      style={{ borderColor: C.line, color: C.blueDeep }}
                    >
                      Ouvrir {t.title} →
                    </button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      </GuideCard>

      {/* ── Rappel circuit PDF ── */}
      <GuideCard>
        <p className="text-sm font-bold" style={{ color: C.blueDeep }}>
          Questions fréquentes
        </p>
        <div className="mt-3 space-y-3 text-[13px] leading-relaxed">
          <p style={{ color: C.muted }}>
            <strong style={{ color: C.ink }}>L’invité doit-il créer un compte ?</strong> Non — le lien
            public s’ouvre directement dans son navigateur, sans inscription ni mot de passe.
          </p>
          <p style={{ color: C.muted }}>
            <strong style={{ color: C.ink }}>Quand le PDF est-il envoyé ?</strong> Uniquement à la fin du
            check-out : l’hôte ET l’invité reçoivent alors le document fusionné (entrée puis sortie) en
            pièce jointe, avec son empreinte SHA-256. Rien n’est envoyé avant.
          </p>
          <p style={{ color: C.muted }}>
            <strong style={{ color: C.ink }}>Le PDF d’onboarding est-il envoyé à l’invité ?</strong> Non —
            il s’agit d’un certificat interne de configuration (bibliothèque de référence), jamais transmis
            à l’invité.
          </p>
          <p style={{ color: C.muted }}>
            <strong style={{ color: C.ink }}>Je refais ma décoration ?</strong> Onglet « Paramètres » →
            « Mon appartement » : remplacez les photos des pièces concernées, elles deviennent la nouvelle
            référence.
          </p>
          <p style={{ color: C.muted }}>
            <strong style={{ color: C.ink }}>Un problème technique ?</strong> Onglet « Assistance » :
            ouvrez un ticket, l’équipe vous répond dans le fil.
          </p>
        </div>
      </GuideCard>

      {/* ── CTA final ── */}
      <div className="flex flex-wrap gap-2">
        <Link
          href="/onboarding/wizard?step=1"
          className="inline-flex min-h-[44px] items-center gap-2 rounded-lg px-4 text-sm font-bold text-white transition-opacity hover:opacity-90"
          style={{ background: C.cta }}
        >
          <Plus className="h-4 w-4" /> Configurer un nouveau bien
        </Link>
        <button
          type="button"
          onClick={() => setView('sejours')}
          className="inline-flex min-h-[44px] items-center rounded-lg border px-4 text-sm font-bold transition-colors hover:bg-white"
          style={{ borderColor: C.line, color: C.ink, background: '#fff' }}
        >
          Aller à mes séjours
        </button>
      </div>
    </div>
  );
}
