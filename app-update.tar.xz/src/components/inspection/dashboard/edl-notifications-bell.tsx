'use client';

// =============================================================
// EdlNotificationsBell — cloche de notifications du NOUVEAU tableau
// de bord EDL (console v2). Demande client : « une cloche de
// notifications en haut à droite, à côté du bouton "Créer un
// nouveau séjour", avec un badge rouge pour les alertes critiques ».
//
// THÈME CLAIR : la console EDL a un header blanc (contrairement au
// shell hôte sombre) → composant dédié plutôt que réutiliser
// NotificationsBell (thème nuit). Mêmes APIs session-scoped :
//   GET   /api/airbnb/notifications?limit=25
//   PATCH /api/airbnb/notifications?notificationId=…  (marquer lu)
//   PUT   /api/airbnb/notifications                   (tout marquer lu)
// Badge ROUGE #E11D2E avec compte (9+ au-delà), pulsation + halo
// si alerte CRITIQUE non lue (type 'damage_alert' / severity
// 'critical' = dégâts signalés), alertes critiques remontées en
// tête du panneau. Polling 45 s + refresh à l'ouverture.
// =============================================================
import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import { useRouter } from 'next/navigation';
import { Bell } from 'lucide-react';
import { toast } from 'sonner';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { relativeFrTime } from '@/lib/automations';

interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  data: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

/** Alerte CRITIQUE : dégâts signalés (type dédié ou severity). */
function isCritical(n: NotificationItem): boolean {
  return n.type === 'damage_alert' || n.data?.severity === 'critical';
}

const RED_CRIT = '#E11D2E';

export function EdlNotificationsBell() {
  const router = useRouter();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [markingAll, setMarkingAll] = useState(false);

  const hasCritical = useMemo(() => items.some((n) => !n.isRead && isCritical(n)), [items]);
  const sortedItems = useMemo(
    () =>
      [...items].sort((a, b) => {
        const ca = !a.isRead && isCritical(a) ? 0 : 1;
        const cb = !b.isRead && isCritical(b) ? 0 : 1;
        if (ca !== cb) return ca - cb;
        return b.createdAt.localeCompare(a.createdAt);
      }),
    [items],
  );

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/airbnb/notifications?limit=25', { cache: 'no-store' });
      if (!res.ok) return; // 401 visiteur / erreur passagère : on retente
      const data = (await res.json()) as { notifications: NotificationItem[]; unreadCount: number };
      setItems(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch {
      // réseau indisponible : retente au prochain cycle
    }
  }, []);

  useEffect(() => {
    const initial = setTimeout(() => void load(), 0);
    const poll = setInterval(() => void load(), 45_000);
    return () => {
      clearTimeout(initial);
      clearInterval(poll);
    };
  }, [load]);

  const markRead = async (id: string) => {
    // Optimiste
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
    try {
      const res = await fetch(`/api/airbnb/notifications?notificationId=${encodeURIComponent(id)}`, {
        method: 'PATCH',
      });
      if (res.ok) {
        const data = (await res.json()) as { unreadCount: number };
        setUnreadCount(data.unreadCount);
      }
    } catch {
      // silencieux — l'état optimiste reste
    }
  };

  const markAllRead = async () => {
    if (markingAll || unreadCount === 0) return;
    setMarkingAll(true);
    setItems((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
    try {
      const res = await fetch('/api/airbnb/notifications', { method: 'PUT' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      toast.success('Toutes les notifications sont marquées comme lues');
    } catch {
      toast.error('Impossible de tout marquer comme lu');
      await load();
    } finally {
      setMarkingAll(false);
    }
  };

  // Deep-link éventuel : marque lu puis navigue (URLs internes uniquement).
  const openNotification = (id: string) => {
    void markRead(id);
    const target = items.find((n) => n.id === id);
    const url = typeof target?.data?.url === 'string' ? target.data.url : '';
    if (url && url.startsWith('/')) {
      setOpen(false);
      router.push(url);
    }
  };

  // Monté uniquement après hydratation (IDs Radix SSR/client stables).
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  if (!mounted) {
    return <span aria-hidden="true" className="inline-block h-10 w-10 rounded-full" />;
  }

  return (
    <Popover
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (next) void load();
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={
            unreadCount > 0
              ? `Notifications (${unreadCount} non lue${unreadCount > 1 ? 's' : ''}${hasCritical ? ', dont des alertes critiques' : ''})`
              : 'Notifications'
          }
          className="relative inline-flex h-10 w-10 items-center justify-center rounded-full border transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: 'transparent', color: '#47566B' }}
        >
          <Bell className="h-[18px] w-[18px]" aria-hidden="true" />
          {unreadCount > 0 && (
            <span
              aria-hidden="true"
              className={cn(
                'absolute -right-0.5 -top-0.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full px-1 text-[10px] font-bold leading-none text-white',
                hasCritical && 'animate-pulse',
              )}
              style={{
                backgroundColor: RED_CRIT,
                ...(hasCritical ? { boxShadow: `0 0 0 3px ${RED_CRIT}33` } : {}),
              }}
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
      </PopoverTrigger>

      <PopoverContent
        align="end"
        className="w-[min(24rem,calc(100vw-2rem))] border bg-white p-0"
        style={{ borderColor: '#E3E9F4' }}
      >
        <div
          className="flex items-center justify-between gap-2 border-b px-4 py-3"
          style={{ borderColor: '#E3E9F4' }}
        >
          <p className="text-sm font-black" style={{ color: '#1E2A3B' }}>
            Notifications
            {hasCritical && (
              <span
                className="ml-2 inline-flex items-center rounded-full px-2 py-0.5 align-middle text-[10px] font-bold uppercase tracking-wide text-white"
                style={{ backgroundColor: RED_CRIT }}
              >
                Critique
              </span>
            )}
          </p>
          {unreadCount > 0 && (
            <button
              type="button"
              onClick={() => void markAllRead()}
              disabled={markingAll}
              aria-label="Tout marquer comme lu"
              className="inline-flex items-center rounded-full px-3 py-2 text-xs font-semibold transition-colors hover:bg-[#F4F7FD] disabled:cursor-wait disabled:opacity-60"
              style={{ color: '#2464C2' }}
            >
              {markingAll && (
                <span
                  className="mr-1.5 inline-block h-2 w-2 animate-pulse rounded-full"
                  style={{ backgroundColor: '#2464C2' }}
                  aria-hidden="true"
                />
              )}
              Tout marquer comme lu
            </button>
          )}
        </div>

        <div className="max-h-96 overflow-y-auto">
          {items.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <p className="text-sm font-semibold" style={{ color: '#1E2A3B' }}>
                Aucune notification
              </p>
              <p className="mt-1 text-xs" style={{ color: '#6B7A93' }}>
                Les alertes de dégâts et les rappels de séjours arriveront ici.
              </p>
            </div>
          ) : (
            <ul role="list">
              {sortedItems.map((n) => {
                const crit = isCritical(n);
                return (
                  <li key={n.id}>
                    <button
                      type="button"
                      onClick={() => openNotification(n.id)}
                      aria-label={typeof n.data?.url === 'string' ? `${n.title} — ouvrir` : n.title}
                      className={cn(
                        'flex w-full gap-3 border-b px-4 py-3 text-left transition-colors last:border-b-0 hover:bg-[#F4F7FD] focus-visible:bg-[#F4F7FD] focus-visible:outline-none',
                      )}
                      style={{ borderColor: '#EDF1F9' }}
                    >
                      <span
                        aria-label={n.isRead ? undefined : crit ? 'Alerte critique non lue' : 'Non lue'}
                        aria-hidden={n.isRead || undefined}
                        className={cn('mt-2 h-2 w-2 shrink-0 rounded-full', !n.isRead && crit && 'animate-pulse')}
                        style={{
                          backgroundColor: n.isRead ? 'rgba(107,122,147,0.35)' : crit ? RED_CRIT : '#2E7CD6',
                        }}
                      />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span
                            className="truncate text-sm font-semibold"
                            style={{ color: n.isRead ? '#47566B' : '#1E2A3B' }}
                          >
                            {n.title}
                          </span>
                          {crit && !n.isRead && (
                            <span
                              className="shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white"
                              style={{ backgroundColor: RED_CRIT }}
                            >
                              Dégâts
                            </span>
                          )}
                        </span>
                        {n.body && (
                          <span className="mt-0.5 block text-xs line-clamp-2" style={{ color: '#6B7A93' }}>
                            {n.body}
                          </span>
                        )}
                        <span className="mt-1 block text-[11px] opacity-70" style={{ color: '#6B7A93' }}>
                          {relativeFrTime(n.createdAt)}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
