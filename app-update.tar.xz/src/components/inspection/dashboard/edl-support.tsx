'use client';

// =============================================================
// EDL SUPPORT — ONGLET « ASSISTANCE » (v4.125)
// Tickets d'assistance côté HÔTE : création d'un ticket (sujet,
// catégorie, priorité, message), fil de discussion bidirectionnel
// avec l'équipe RoomScan (les réponses arrivent depuis l'onglet
// Assistance du Superadmin — mêmes tables, onglets CONNECTÉS),
// clôture d'un ticket résolu.
// =============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import {
  ArrowLeft,
  LifeBuoy,
  MessageSquarePlus,
  Paperclip,
  Send,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import type { SessionUser } from './edl-types';

const C = {
  blueDeep: '#2464C2',
  ink: '#1E2A3B',
  muted: '#6B7A93',
  line: '#E3E9F4',
  cta: '#C21F26',
  violet: '#8B5CF6',
  red: '#E8425A',
} as const;

const CATEGORIES: { value: string; label: string }[] = [
  { value: 'GENERAL', label: 'Question générale' },
  { value: 'TECHNIQUE', label: 'Problème technique' },
  { value: 'SEJOUR', label: 'Séjour / état des lieux' },
  { value: 'FACTURATION', label: 'Facturation / abonnement' },
  { value: 'AUTRE', label: 'Autre' },
];
const PRIORITIES: { value: string; label: string }[] = [
  { value: 'LOW', label: 'Basse' },
  { value: 'NORMAL', label: 'Normale' },
  { value: 'HIGH', label: 'Haute' },
  { value: 'URGENT', label: 'Urgente' },
];

const STATUS_META: Record<string, { label: string; bg: string; fg: string }> = {
  OPEN: { label: 'En attente de réponse', bg: '#FDF3DC', fg: '#9A6B08' },
  ANSWERED: { label: 'Répondu par le support', bg: '#E2F1FB', fg: '#1D6FB8' },
  RESOLVED: { label: 'Résolu', bg: '#DFF5EA', fg: '#0E7A52' },
  CLOSED: { label: 'Fermé', bg: '#EEF1F6', fg: C.muted },
};
const PRIORITY_META: Record<string, { label: string; fg: string }> = {
  LOW: { label: 'Basse', fg: C.muted },
  NORMAL: { label: 'Normale', fg: C.blueDeep },
  HIGH: { label: 'Haute', fg: '#B45309' },
  URGENT: { label: 'Urgente', fg: C.red },
};

function fmt(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
}

interface TicketPreview {
  id: string;
  subject: string;
  category: string;
  priority: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  messagesCount: number;
  lastMessage: { author: string; body: string; createdAt: string } | null;
}
interface TicketMessage {
  id: string;
  author: string;
  authorName: string;
  body: string;
  createdAt: string;
}
interface TicketDetail {
  id: string;
  subject: string;
  category: string;
  priority: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  messages: TicketMessage[];
}

function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={cn('rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5', className)}
      style={{ borderColor: C.line }}
    >
      {children}
    </section>
  );
}

function StatusPill({ status }: { status: string }) {
  const m = STATUS_META[status] ?? STATUS_META.OPEN;
  return (
    <span
      className="inline-flex shrink-0 items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
      style={{ background: m.bg, color: m.fg }}
    >
      {m.label}
    </span>
  );
}

export function AssistanceView({ sessionUser }: { sessionUser: SessionUser }) {
  const [tickets, setTickets] = useState<TicketPreview[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<TicketDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/support/tickets', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as { tickets?: TicketPreview[] } | null;
      if (!res.ok) {
        toast.error('Chargement impossible. Réessayez.');
        return;
      }
      setTickets(Array.isArray(json?.tickets) ? json.tickets : []);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openDetail = async (id: string) => {
    setDetailLoading(true);
    setReply('');
    try {
      const res = await fetch(`/api/support/tickets/${id}`, { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as { ticket?: TicketDetail } | null;
      if (!res.ok || !json?.ticket) {
        toast.error('Ticket introuvable.');
        return;
      }
      setSelected(json.ticket);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setDetailLoading(false);
    }
  };

  const sendReply = async () => {
    if (!selected || sending) return;
    const text = reply.trim();
    if (text.length < 2) return toast.error('Écrivez votre message avant d’envoyer.');
    setSending(true);
    try {
      const res = await fetch(`/api/support/tickets/${selected.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      const json = (await res.json().catch(() => null)) as { error?: string; message?: string } | null;
      if (!res.ok) {
        toast.error(json?.message ?? json?.error ?? 'Envoi impossible.');
        return;
      }
      toast.success('Message envoyé au support.');
      setReply('');
      await openDetail(selected.id);
      void load();
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setSending(false);
    }
  };

  const setTicketStatus = async (id: string, status: 'RESOLVED' | 'CLOSED' | 'OPEN') => {
    try {
      const res = await fetch(`/api/support/tickets/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) {
        toast.error('Action impossible.');
        return;
      }
      toast.success(status === 'RESOLVED' ? 'Ticket marqué résolu — merci !' : status === 'CLOSED' ? 'Ticket fermé.' : 'Ticket réouvert.');
      if (selected?.id === id) await openDetail(id);
      void load();
    } catch {
      toast.error('Erreur de connexion.');
    }
  };

  return (
    <div className="grid gap-4">
      {/* ── En-tête ── */}
      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <span
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
              style={{ background: '#E2F1FB', color: C.blueDeep }}
              aria-hidden="true"
            >
              <LifeBuoy className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-base font-black" style={{ color: C.ink }}>
                Assistance RoomScan
              </h2>
              <p className="text-xs" style={{ color: C.muted }}>
                Un problème, une question ? Ouvrez un ticket — l’équipe vous répond directement ici
                {sessionUser.email ? ` (${sessionUser.email})` : ''}.
              </p>
            </div>
          </div>
          <Button
            type="button"
            onClick={() => setCreateOpen(true)}
            className="h-10 rounded-lg px-4 text-sm font-bold text-white hover:brightness-110"
            style={{ background: C.cta }}
          >
            <MessageSquarePlus className="mr-1.5 h-4 w-4" /> Nouveau ticket
          </Button>
        </div>
      </Card>

      {/* ── Détail d'un ticket (fil) ── */}
      {selected ? (
        <Card>
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2">
              <button
                type="button"
                onClick={() => setSelected(null)}
                aria-label="Retour à la liste des tickets"
                className="rounded-lg p-1.5 transition-colors hover:bg-[#F4F7FD]"
                style={{ color: C.blueDeep }}
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <div className="min-w-0">
                <p className="truncate text-sm font-black" style={{ color: C.ink }}>
                  {selected.subject}
                </p>
                <p className="text-[11px]" style={{ color: C.muted }}>
                  {fmt(selected.createdAt)} · {selected.messages.length} message(s)
                </p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <StatusPill status={selected.status} />
              {selected.status !== 'CLOSED' && selected.status !== 'RESOLVED' ? (
                <button
                  type="button"
                  onClick={() => {
                    void setTicketStatus(selected.id, 'RESOLVED');
                  }}
                  className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F0FAF5]"
                  style={{ borderColor: C.line, color: '#0E7A52' }}
                >
                  Marquer résolu
                </button>
              ) : selected.status === 'RESOLVED' ? (
                <button
                  type="button"
                  onClick={() => {
                    void setTicketStatus(selected.id, 'OPEN');
                  }}
                  className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#FDF3DC]"
                  style={{ borderColor: C.line, color: '#9A6B08' }}
                >
                  Réouvrir
                </button>
              ) : null}
            </div>
          </div>

          {/* Fil de messages */}
          <div className="mt-4 space-y-3">
            {detailLoading ? (
              <Skeleton className="h-20 rounded-xl" />
            ) : (
              selected.messages.map((m) => {
                const isHost = m.author === 'HOST';
                return (
                  <div key={m.id} className={cn('flex', isHost ? 'justify-end' : 'justify-start')}>
                    <div
                      className={cn(
                        'max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed sm:max-w-[70%]',
                        isHost ? 'rounded-br-sm text-white' : 'rounded-bl-sm border bg-white',
                      )}
                      style={isHost ? { background: C.blueDeep } : { borderColor: C.line, color: C.ink }}
                    >
                      <p className="mb-1 text-[10px] font-bold uppercase tracking-wide opacity-80">
                        {isHost ? 'Vous' : `Support RoomScan — ${m.authorName}`}
                      </p>
                      <p className="whitespace-pre-wrap">{m.body}</p>
                      <p className={cn('mt-1 text-right text-[10px]', isHost ? 'text-white/70' : '')} style={!isHost ? { color: C.muted } : undefined}>
                        {fmt(m.createdAt)}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={bottomRef} />
          </div>

          {/* Réponse hôte */}
          {selected.status !== 'CLOSED' ? (
            <div className="mt-4 border-t pt-3" style={{ borderColor: C.line }}>
              <Label htmlFor="support-reply" className="text-xs" style={{ color: C.ink }}>
                Votre réponse
              </Label>
              <textarea
                id="support-reply"
                value={reply}
                onChange={(e) => setReply(e.target.value)}
                rows={3}
                maxLength={5000}
                placeholder="Répondez au support… (précisez le logement ou le séjour concerné si utile)"
                className="mt-1.5 w-full rounded-lg border bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#2464C2]/20"
                style={{ borderColor: C.line, color: C.ink }}
              />
              <div className="mt-2 flex justify-end">
                <Button
                  type="button"
                  disabled={sending}
                  onClick={() => {
                    void sendReply();
                  }}
                  className="h-10 rounded-lg px-4 text-sm font-bold text-white hover:brightness-110"
                  style={{ background: C.blueDeep }}
                >
                  <Send className="mr-1.5 h-4 w-4" /> {sending ? 'Envoi…' : 'Envoyer'}
                </Button>
              </div>
            </div>
          ) : (
            <p className="mt-3 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: C.line, color: C.muted }}>
              Ce ticket est fermé — ouvrez un nouveau ticket si le problème revient.
            </p>
          )}
        </Card>
      ) : null}

      {/* ── Liste des tickets ── */}
      {loading ? (
        <div className="grid gap-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-xl" />
          ))}
        </div>
      ) : tickets && tickets.length > 0 ? (
        <div className="grid gap-3">
          {tickets.map((t) => {
            const prio = PRIORITY_META[t.priority] ?? PRIORITY_META.NORMAL;
            const cat = CATEGORIES.find((c) => c.value === t.category)?.label ?? t.category;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  void openDetail(t.id);
                }}
                className="rounded-xl border bg-white p-4 text-left shadow-[0_1px_3px_rgba(30,42,59,0.06)] transition-colors hover:bg-[#F7F9FE]"
                style={{ borderColor: C.line }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="min-w-0 flex-1 truncate text-sm font-bold" style={{ color: C.ink }}>
                    {t.subject}
                  </p>
                  <StatusPill status={t.status} />
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px]" style={{ color: C.muted }}>
                  <span style={{ color: prio.fg }} className="font-semibold">
                    Priorité {prio.label}
                  </span>
                  <span>· {cat}</span>
                  <span>· {t.messagesCount} message(s)</span>
                  <span>· mis à jour {fmt(t.updatedAt)}</span>
                </div>
                {t.lastMessage ? (
                  <p className="mt-1.5 line-clamp-1 text-xs" style={{ color: C.muted }}>
                    {t.lastMessage.author === 'ADMIN' ? 'Support : ' : 'Vous : '}
                    {t.lastMessage.body}
                  </p>
                ) : null}
              </button>
            );
          })}
        </div>
      ) : !loading ? (
        <Card>
          <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
            Aucun ticket pour le moment. En cas de problème, cliquez sur « Nouveau ticket ».
          </p>
        </Card>
      ) : null}

      {/* ── Dialog création ── */}
      <CreateTicketDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={(id) => {
          void load();
          void openDetail(id);
        }}
      />
    </div>
  );
}

// ---------- Dialog : créer un ticket ----------

function CreateTicketDialog({
  open,
  onOpenChange,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onCreated: (id: string) => void;
}) {
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('GENERAL');
  const [priority, setPriority] = useState('NORMAL');
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (busy) return;
    if (subject.trim().length < 4) return toast.error('Le sujet doit contenir au moins 4 caractères.');
    if (body.trim().length < 10) return toast.error('Décrivez votre problème (10 caractères minimum).');
    setBusy(true);
    try {
      const res = await fetch('/api/support/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: subject.trim(), category, priority, body: body.trim() }),
      });
      const json = (await res.json().catch(() => null)) as { id?: string; error?: string; message?: string } | null;
      if (!res.ok || !json?.id) {
        toast.error(json?.message ?? json?.error ?? 'Création impossible.');
        return;
      }
      toast.success('Ticket créé — l’équipe RoomScan vous répond dans ce fil.');
      onOpenChange(false);
      setSubject('');
      setBody('');
      setPriority('NORMAL');
      onCreated(json.id);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-xl sm:max-w-lg" style={{ borderColor: C.line }}>
        <DialogHeader>
          <DialogTitle className="text-lg font-black" style={{ color: C.ink }}>
            Créer un ticket d’assistance
          </DialogTitle>
          <DialogDescription className="text-xs" style={{ color: C.muted }}>
            Décrivez votre problème : l’équipe RoomScan reçoit votre demande immédiatement et vous
            répond dans ce fil.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3.5">
          <div className="space-y-1.5">
            <Label htmlFor="ticket-subject" className="text-xs" style={{ color: C.ink }}>
              Sujet
            </Label>
            <Input
              id="ticket-subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="ex. La photo du check-in ne s’envoie pas"
              maxLength={160}
              className="h-11"
            />
          </div>
          <div className="grid gap-3.5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-xs" style={{ color: C.ink }}>
                Catégorie
              </Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="h-11 w-full" aria-label="Catégorie du ticket">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>
                      {c.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs" style={{ color: C.ink }}>
                Priorité
              </Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger className="h-11 w-full" aria-label="Priorité du ticket">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => (
                    <SelectItem key={p.value} value={p.value}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ticket-body" className="text-xs" style={{ color: C.ink }}>
              Description du problème
            </Label>
            <textarea
              id="ticket-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              rows={5}
              maxLength={5000}
              placeholder="Expliquez ce qui se passe, sur quel écran, et ce que vous attendiez…"
              className="w-full rounded-lg border bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#2464C2]/20"
              style={{ borderColor: C.line, color: C.ink }}
            />
          </div>
          <Button
            type="button"
            disabled={busy}
            onClick={() => {
              void submit();
            }}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            <Paperclip className="mr-1.5 h-4 w-4" /> {busy ? 'Création…' : 'Envoyer au support'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
