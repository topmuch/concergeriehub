'use client';

// =============================================================
// EDL SETTINGS — ONGLET « PARAMÈTRES » (v4.125, ex-« Bouclier »)
// Le contenu de référence du logement, 4 sous-onglets :
//   • Mon appartement        → photos des pièces (zones) —
//     remplaçables si l'hôte refait la peinture / la déco ;
//   • Électroménagers        → frigo, plaque, four, lave-linge… ;
//   • Électroniques          → TV, clim, sèche-cheveux, coffre… ;
//   • Divers & accessoires   → meubles, objets, clés, déco…
// Chaque action (remplacer une photo, renommer, ajouter, supprimer)
// est enregistrée immédiatement (PATCH /api/shield/properties/[id])
// et scellée : la nouvelle photo de référence reçoit un SHA-256.
// =============================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import { toast } from 'sonner';
import {
  Camera,
  Home,
  Loader2,
  Pencil,
  Plug,
  Plus,
  Refrigerator,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { fileToShieldPhotoDataUrl } from '../shield/shield-photo';

const C = {
  blueDeep: '#2464C2',
  ink: '#1E2A3B',
  muted: '#6B7A93',
  line: '#E3E9F4',
  cta: '#C21F26',
  red: '#E8425A',
  violet: '#8B5CF6',
  orange: '#F2764C',
} as const;

type SettingsTab = 'appartement' | 'electro' | 'electronique' | 'divers';

/** Kinds → onglet (compatibilité avec les anciens codes métier). */
const ELECTRO_KINDS = new Set(['PLQ', 'MO', 'FRIGO', 'LV', 'FOUR', 'LAV', 'SEC', 'BUIL', 'ELECTRO']);
const ELEC_KINDS = new Set(['TV', 'CLMS', 'CLC1', 'CLC2', 'SCH', 'COFFRE', 'ELECTRONIQUE']);
const KIND_FOR_TAB: Record<Exclude<SettingsTab, 'appartement'>, string> = {
  electro: 'ELECTRO',
  electronique: 'ELECTRONIQUE',
  divers: 'DIVERS',
};
function tabForKind(kind: string): SettingsTab {
  if (ELECTRO_KINDS.has(kind)) return 'electro';
  if (ELEC_KINDS.has(kind)) return 'electronique';
  return 'divers';
}

const TABS: { key: SettingsTab; label: string; icon: React.ComponentType<{ className?: string }>; hint: string }[] = [
  { key: 'appartement', label: 'Mon appartement', icon: Home, hint: 'Photos de référence des pièces — à remplacer si vous refaites la peinture ou la décoration.' },
  { key: 'electro', label: 'Électroménagers', icon: Refrigerator, hint: 'Réfrigérateur, plaque, four, micro-ondes, machine à laver…' },
  { key: 'electronique', label: 'Électroniques', icon: Plug, hint: 'Télévision, climatisations, sèche-cheveux, coffre-fort…' },
  { key: 'divers', label: 'Divers & accessoires', icon: Sparkles, hint: 'Meubles, objets, accessoires et équipements divers du logement.' },
];

interface PropertySummary {
  id: string;
  propertyName: string;
  propertyAddress: string;
  city: string;
  ownerName: string;
  onboardingRef: string;
  onboardedAt: string;
  zonesCount: number;
  devicesCount: number;
}
interface ZoneRow {
  id: string;
  name: string;
  referencePhoto: string;
  sortOrder: number;
}
interface DeviceRow {
  id: string;
  name: string;
  kind: string;
  referenceCode: string;
  referenceHash: string;
  referencePhoto: string;
  referenceDate: string;
}

function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={cn('rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5', className)}
      style={{ borderColor: C.line }}
    >
      {children}
    </section>
  );
}

function fmtDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ---------- Composant principal ----------

export function ParametresView() {
  const [properties, setProperties] = useState<PropertySummary[] | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [zones, setZones] = useState<ZoneRow[] | null>(null);
  const [devices, setDevices] = useState<DeviceRow[] | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [tab, setTab] = useState<SettingsTab>('appartement');
  const [busy, setBusy] = useState(false);

  // Photo en attente (cible du sélecteur de fichier).
  const pendingPhoto = useRef<{ type: 'zone' | 'device'; id: string } | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // Dialogs.
  const [addOpen, setAddOpen] = useState(false); // ajouter pièce OU appareil (selon tab)
  const [editTarget, setEditTarget] = useState<{ type: 'zone' | 'device'; id: string; name: string } | null>(null);
  const [deleteArmed, setDeleteArmed] = useState<string | null>(null);

  const loadList = useCallback(async () => {
    try {
      const res = await fetch('/api/shield/properties', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as { properties?: PropertySummary[] } | null;
      if (!res.ok) {
        toast.error('Chargement impossible.');
        setProperties([]);
        return;
      }
      const list = Array.isArray(json?.properties) ? json.properties : [];
      setProperties(list);
      setSelectedId((prev) => prev ?? list[0]?.id ?? null);
    } catch {
      toast.error('Erreur de connexion.');
      setProperties([]);
    }
  }, []);

  const loadDetail = useCallback(async (id: string) => {
    setDetailLoading(true);
    try {
      const res = await fetch(`/api/shield/properties/${id}`, { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as { zones?: ZoneRow[]; devices?: DeviceRow[] } | null;
      if (!res.ok) {
        toast.error('Chargement du bien impossible.');
        return;
      }
      setZones(Array.isArray(json?.zones) ? json.zones : []);
      setDevices(Array.isArray(json?.devices) ? json.devices : []);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setDetailLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadList();
  }, [loadList]);

  useEffect(() => {
    if (selectedId) void loadDetail(selectedId);
  }, [selectedId, loadDetail]);

  /** PATCH ciblé puis rechargement du détail. */
  const patch = useCallback(
    async (ops: Record<string, unknown>, successMsg: string) => {
      if (!selectedId || busy) return false;
      setBusy(true);
      try {
        const res = await fetch(`/api/shield/properties/${selectedId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(ops),
        });
        const json = (await res.json().catch(() => null)) as { error?: string; message?: string } | null;
        if (!res.ok) {
          toast.error(json?.message ?? json?.error ?? 'Enregistrement impossible.');
          return false;
        }
        toast.success(successMsg);
        await loadDetail(selectedId);
        void loadList();
        return true;
      } catch {
        toast.error('Erreur de connexion.');
        return false;
      } finally {
        setBusy(false);
      }
    },
    [selectedId, busy, loadDetail, loadList],
  );

  /** Fichier → compression → PATCH immédiat. */
  const onPickPhoto = async (file: File | null | undefined) => {
    const target = pendingPhoto.current;
    pendingPhoto.current = null;
    if (!file || !target) return;
    const dataUrl = await fileToShieldPhotoDataUrl(file);
    if (!dataUrl) {
      toast.error('Photo illisible — utilisez un JPEG ou un PNG.');
      return;
    }
    if (target.type === 'zone') {
      await patch({ zoneUpdates: [{ id: target.id, referencePhoto: dataUrl }] }, 'Photo de la pièce mise à jour — nouvelle référence scellée (SHA-256).');
    } else {
      await patch({ deviceUpdates: [{ id: target.id, referencePhoto: dataUrl }] }, 'Photo de l’appareil mise à jour — nouvelle référence scellée (SHA-256).');
    }
  };

  const activeProperty = properties?.find((p) => p.id === selectedId) ?? null;
  const currentTab = TABS.find((t) => t.key === tab)!;
  const visibleDevices = (devices ?? []).filter((d) => tabForKind(d.kind) === tab);

  // ── Aucun bien onboardé ──
  if (properties !== null && properties.length === 0) {
    return (
      <Card>
        <div className="flex flex-col items-center gap-3 py-8 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#E2F1FB]" style={{ color: C.blueDeep }} aria-hidden="true">
            <Home className="h-5 w-5" />
          </span>
          <p className="text-sm font-bold" style={{ color: C.ink }}>Aucun bien configuré pour le moment.</p>
          <p className="max-w-sm text-xs" style={{ color: C.muted }}>
            Lancez l’onboarding guidé pour configurer votre logement (pièces, photos de référence,
            équipements). Ses contenus apparaîtront ensuite ici.
          </p>
          <Button
            type="button"
            onClick={() => {
              window.location.href = '/onboarding/wizard?step=1';
            }}
            className="h-10 rounded-lg px-4 text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            <Plus className="mr-1.5 h-4 w-4" /> Configurer mon bien
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      {/* ── Sélecteur de bien ── */}
      {properties && properties.length > 1 ? (
        <Card className="flex flex-wrap items-center gap-2">
          <Label className="w-full text-xs sm:w-auto" style={{ color: C.ink }}>
            Bien configuré :
          </Label>
          <div className="flex flex-wrap gap-2">
            {properties.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setSelectedId(p.id);
                  setDeleteArmed(null);
                  setTab('appartement');
                }}
                className={cn(
                  'min-h-[36px] rounded-lg border px-3 py-1.5 text-xs font-bold transition-colors',
                  p.id === selectedId ? 'text-white' : 'hover:bg-[#F4F7FD]',
                )}
                style={p.id === selectedId ? { background: C.blueDeep, borderColor: C.blueDeep } : { borderColor: C.line, color: C.ink }}
                aria-pressed={p.id === selectedId}
              >
                {p.propertyName}
              </button>
            ))}
          </div>
        </Card>
      ) : null}

      {/* ── 4 onglets ── */}
      <Card>
        <div role="tablist" aria-label="Sections des paramètres" className="flex gap-1.5 overflow-x-auto pb-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button
                key={t.key}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => {
                  setTab(t.key);
                  setDeleteArmed(null);
                }}
                className={cn(
                  'inline-flex min-h-[40px] shrink-0 items-center gap-2 rounded-lg px-3 text-xs font-bold transition-colors sm:text-[13px]',
                  active ? 'text-white shadow-sm' : 'hover:bg-[#F4F7FD]',
                )}
                style={active ? { background: C.blueDeep } : { color: C.ink, background: '#F0F4FB' }}
              >
                <Icon className="h-4 w-4" aria-hidden="true" />
                {t.label}
              </button>
            );
          })}
        </div>
        {activeProperty ? (
          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 rounded-lg border px-3 py-2 text-xs" style={{ borderColor: C.line, color: C.muted }}>
            <span className="font-bold" style={{ color: C.ink }}>{activeProperty.propertyName}</span>
            <span>{activeProperty.propertyAddress} — {activeProperty.city}</span>
            <span>Réf. {activeProperty.onboardingRef}</span>
          </div>
        ) : null}
        <p className="mt-2 text-xs" style={{ color: C.muted }}>
          {currentTab.hint}
        </p>

        {/* ── Contenu de l'onglet ── */}
        {detailLoading ? (
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-44 rounded-xl" />
            ))}
          </div>
        ) : tab === 'appartement' ? (
          <ZonesGrid
            zones={zones ?? []}
            busy={busy}
            deleteArmed={deleteArmed}
            setDeleteArmed={setDeleteArmed}
            onReplacePhoto={(id) => {
              pendingPhoto.current = { type: 'zone', id };
              fileRef.current?.click();
            }}
            onRename={(z) => setEditTarget({ type: 'zone', id: z.id, name: z.name })}
            onDelete={(id) => {
              void patch({ zoneDeletes: [id] }, 'Pièce supprimée.');
              setDeleteArmed(null);
            }}
            onAdd={() => setAddOpen(true)}
          />
        ) : (
          <DevicesGrid
            devices={visibleDevices}
            busy={busy}
            deleteArmed={deleteArmed}
            setDeleteArmed={setDeleteArmed}
            onReplacePhoto={(id) => {
              pendingPhoto.current = { type: 'device', id };
              fileRef.current?.click();
            }}
            onRename={(d) => setEditTarget({ type: 'device', id: d.id, name: d.name })}
            onDelete={(id) => {
              void patch({ deviceDeletes: [id] }, 'Appareil supprimé.');
              setDeleteArmed(null);
            }}
            onAdd={() => setAddOpen(true)}
            tab={tab}
          />
        )}
      </Card>

      {/* Sélecteur de fichier caché (photo) */}
      <input
        ref={fileRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        aria-hidden="true"
        tabIndex={-1}
        onChange={(e) => {
          void onPickPhoto(e.target.files?.[0]);
          e.target.value = '';
        }}
      />

      {/* Dialog : ajouter une pièce ou un appareil */}
      <AddItemDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        isZone={tab === 'appartement'}
        kindForNew={tab === 'appartement' ? null : KIND_FOR_TAB[tab]}
        busy={busy}
        onSubmit={async (name, photo) => {
          const ok =
            tab === 'appartement'
              ? await patch({ zoneCreates: [{ name, referencePhoto: photo }] }, 'Pièce ajoutée — photo de référence scellée.')
              : await patch({ deviceCreates: [{ name, kind: KIND_FOR_TAB[tab], referencePhoto: photo }] }, 'Appareil ajouté — photo de référence scellée.');
          if (ok) setAddOpen(false);
        }}
      />

      {/* Dialog : renommer */}
      <RenameDialog
        target={editTarget}
        onClose={() => setEditTarget(null)}
        busy={busy}
        onSubmit={async (name) => {
          if (!editTarget) return;
          const ok =
            editTarget.type === 'zone'
              ? await patch({ zoneUpdates: [{ id: editTarget.id, name }] }, 'Nom mis à jour.')
              : await patch({ deviceUpdates: [{ id: editTarget.id, name }] }, 'Nom mis à jour.');
          if (ok) setEditTarget(null);
        }}
      />
    </div>
  );
}

// ---------- Grille des pièces (zones) ----------

function ZonesGrid({
  zones,
  busy,
  deleteArmed,
  setDeleteArmed,
  onReplacePhoto,
  onRename,
  onDelete,
  onAdd,
}: {
  zones: ZoneRow[];
  busy: boolean;
  deleteArmed: string | null;
  setDeleteArmed: (v: string | null) => void;
  onReplacePhoto: (id: string) => void;
  onRename: (z: ZoneRow) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
}) {
  return (
    <div className="mt-4">
      {zones.length === 0 ? (
        <p className="py-4 text-center text-sm" style={{ color: C.muted }}>
          Aucune pièce enregistrée.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {zones.map((z) => (
            <figure key={z.id} className="overflow-hidden rounded-xl border" style={{ borderColor: C.line }}>
              <div className="relative aspect-[4/3] bg-[#EEF2F9]">
                {z.referencePhoto ? (
                  <Image
                    src={z.referencePhoto}
                    alt={`Photo de référence — ${z.name}`}
                    fill
                    unoptimized
                    className="object-cover"
                    sizes="(max-width: 640px) 45vw, 220px"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center text-2xl" style={{ color: C.muted }} aria-hidden="true">
                    <Camera className="h-7 w-7" />
                  </div>
                )}
              </div>
              <figcaption className="p-2.5">
                <p className="truncate text-[13px] font-bold" style={{ color: C.ink }}>
                  {z.name}
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => onReplacePhoto(z.id)}
                    className="inline-flex min-h-[30px] items-center gap-1 rounded-lg px-2 text-[11px] font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                    style={{ background: C.blueDeep }}
                    aria-label={`Remplacer la photo de ${z.name}`}
                  >
                    <Camera className="h-3 w-3" /> Photo
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => onRename(z)}
                    className="inline-flex min-h-[30px] items-center rounded-lg border px-2 text-[11px] font-semibold transition-colors hover:bg-[#F4F7FD] disabled:opacity-50"
                    style={{ borderColor: C.line, color: C.ink }}
                    aria-label={`Renommer ${z.name}`}
                  >
                    <Pencil className="h-3 w-3" />
                  </button>
                  {deleteArmed === z.id ? (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onDelete(z.id)}
                      className="inline-flex min-h-[30px] items-center rounded-lg px-2 text-[11px] font-bold text-white disabled:opacity-50"
                      style={{ background: C.red }}
                      aria-label={`Confirmer la suppression de ${z.name}`}
                    >
                      Confirmer
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => setDeleteArmed(z.id)}
                      className="inline-flex min-h-[30px] items-center rounded-lg border px-2 text-[11px] font-semibold transition-colors hover:bg-[#FDF0F2] disabled:opacity-50"
                      style={{ borderColor: C.line, color: C.red }}
                      aria-label={`Supprimer ${z.name} (double confirmation)`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}
      {/* Carte ajouter — TOUJOURS disponible, même liste vide */}
      <div className="mt-3 flex">
        <button
          type="button"
          onClick={onAdd}
          className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-4 text-center transition-colors hover:bg-[#F4F8FE]"
          style={{ borderColor: C.blueDeep, color: C.blueDeep }}
        >
          <Plus className="h-6 w-6" aria-hidden="true" />
          <p className="text-sm font-black">Ajouter une pièce</p>
          <p className="text-[11px]" style={{ color: C.muted }}>Photo de référence obligatoire</p>
        </button>
      </div>
    </div>
  );
}

// ---------- Grille des appareils (devices) ----------

function DevicesGrid({
  devices,
  busy,
  deleteArmed,
  setDeleteArmed,
  onReplacePhoto,
  onRename,
  onDelete,
  onAdd,
  tab,
}: {
  devices: DeviceRow[];
  busy: boolean;
  deleteArmed: string | null;
  setDeleteArmed: (v: string | null) => void;
  onReplacePhoto: (id: string) => void;
  onRename: (d: DeviceRow) => void;
  onDelete: (id: string) => void;
  onAdd: () => void;
  tab: SettingsTab;
}) {
  const accent = tab === 'electro' ? C.blueDeep : tab === 'electronique' ? C.violet : C.orange;
  return (
    <div className="mt-4">
      {devices.length === 0 ? (
        <p className="py-4 text-center text-sm" style={{ color: C.muted }}>
          Aucun appareil dans cette catégorie — ajoutez ceux présents dans votre logement.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {devices.map((d) => (
            <figure key={d.id} className="overflow-hidden rounded-xl border" style={{ borderColor: C.line }}>
              <div className="relative aspect-[4/3] bg-[#EEF2F9]">
                {d.referencePhoto ? (
                  <Image
                    src={d.referencePhoto}
                    alt={`Photo de référence — ${d.name}`}
                    fill
                    unoptimized
                    className="object-cover"
                    sizes="(max-width: 640px) 45vw, 220px"
                  />
                ) : (
                  <div className="flex h-full items-center justify-center text-2xl" style={{ color: C.muted }} aria-hidden="true">
                    <Camera className="h-7 w-7" />
                  </div>
                )}
              </div>
              <figcaption className="p-2.5">
                <p className="truncate text-[13px] font-bold" style={{ color: C.ink }}>
                  {d.name}
                </p>
                <p className="truncate text-[10px]" style={{ color: C.muted }} title={d.referenceCode}>
                  {d.referenceCode} · {fmtDate(d.referenceDate)}
                </p>
                <div className="mt-2 flex flex-wrap gap-1">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => onReplacePhoto(d.id)}
                    className="inline-flex min-h-[30px] items-center gap-1 rounded-lg px-2 text-[11px] font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-50"
                    style={{ background: accent }}
                    aria-label={`Remplacer la photo de ${d.name}`}
                  >
                    <Camera className="h-3 w-3" /> Photo
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => onRename(d)}
                    className="inline-flex min-h-[30px] items-center rounded-lg border px-2 text-[11px] font-semibold transition-colors hover:bg-[#F4F7FD] disabled:opacity-50"
                    style={{ borderColor: C.line, color: C.ink }}
                    aria-label={`Renommer ${d.name}`}
                  >
                    <Pencil className="h-3 w-3" />
                  </button>
                  {deleteArmed === d.id ? (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => onDelete(d.id)}
                      className="inline-flex min-h-[30px] items-center rounded-lg px-2 text-[11px] font-bold text-white disabled:opacity-50"
                      style={{ background: C.red }}
                      aria-label={`Confirmer la suppression de ${d.name}`}
                    >
                      Confirmer
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => setDeleteArmed(d.id)}
                      className="inline-flex min-h-[30px] items-center rounded-lg border px-2 text-[11px] font-semibold transition-colors hover:bg-[#FDF0F2] disabled:opacity-50"
                      style={{ borderColor: C.line, color: C.red }}
                      aria-label={`Supprimer ${d.name} (double confirmation)`}
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  )}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}
      {/* Carte ajouter — TOUJOURS disponible, même catégorie vide */}
      <div className="mt-3 flex">
        <button
          type="button"
          onClick={onAdd}
          className="flex w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-4 text-center transition-colors hover:bg-[#F4F8FE]"
          style={{ borderColor: accent, color: accent }}
        >
          <Plus className="h-6 w-6" aria-hidden="true" />
          <p className="text-sm font-black">Ajouter un appareil</p>
          <p className="text-[11px]" style={{ color: C.muted }}>Photo de référence obligatoire</p>
        </button>
      </div>
    </div>
  );
}

// ---------- Dialog : ajouter (pièce ou appareil) ----------

function AddItemDialog({
  open,
  onOpenChange,
  isZone,
  kindForNew,
  busy,
  onSubmit,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  isZone: boolean;
  kindForNew: string | null;
  busy: boolean;
  onSubmit: (name: string, photo: string) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [fileName, setFileName] = useState('');

  useEffect(() => {
    if (!open) {
      setName('');
      setPhoto(null);
      setFileName('');
    }
  }, [open]);

  const label = isZone ? 'la pièce' : 'l’appareil';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-xl sm:max-w-md" style={{ borderColor: C.line }}>
        <DialogHeader>
          <DialogTitle className="text-lg font-black" style={{ color: C.ink }}>
            {isZone ? 'Ajouter une pièce' : 'Ajouter un appareil'}
          </DialogTitle>
          <DialogDescription className="text-xs" style={{ color: C.muted }}>
            La photo devient la <strong>référence scellée</strong> (horodatée + SHA-256) réutilisée
            dans les prochains états des lieux.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3.5">
          <div className="space-y-1.5">
            <Label htmlFor="add-item-name" className="text-xs" style={{ color: C.ink }}>
              {isZone ? 'Nom de la pièce' : 'Nom de l’appareil'}{' '}
              {kindForNew ? <span className="font-normal">(catégorie : {kindForNew === 'ELECTRO' ? 'électroménager' : kindForNew === 'ELECTRONIQUE' ? 'électronique' : 'divers'})</span> : null}
            </Label>
            <Input
              id="add-item-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={isZone ? 'ex. CHAMBRE 3' : 'ex. LAVE-LINGE, BAR, TABOURETS…'}
              maxLength={80}
              className="h-11"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="add-item-photo" className="text-xs" style={{ color: C.ink }}>
              Photo de référence
            </Label>
            <div className="flex items-center gap-3">
              <label
                htmlFor="add-item-photo"
                className="inline-flex min-h-[44px] cursor-pointer items-center gap-2 rounded-lg border px-3 text-xs font-bold transition-colors hover:bg-[#F4F7FD]"
                style={{ borderColor: C.blueDeep, color: C.blueDeep }}
              >
                <Camera className="h-4 w-4" /> Choisir une photo
              </label>
              <input
                id="add-item-photo"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = '';
                  if (!file) return;
                  const dataUrl = await fileToShieldPhotoDataUrl(file);
                  if (!dataUrl) {
                    toast.error('Photo illisible — utilisez un JPEG ou un PNG.');
                    return;
                  }
                  setPhoto(dataUrl);
                  setFileName(file.name);
                }}
              />
              {photo ? (
                <span className="flex items-center gap-2 text-xs" style={{ color: C.muted }}>
                  <span className="relative h-10 w-14 overflow-hidden rounded border" style={{ borderColor: C.line }}>
                    <Image src={photo} alt="Aperçu" fill unoptimized className="object-cover" sizes="56px" />
                  </span>
                  <span className="max-w-[140px] truncate">{fileName}</span>
                </span>
              ) : (
                <span className="text-xs" style={{ color: C.muted }}>JPEG/PNG — compressée automatiquement.</span>
              )}
            </div>
          </div>
          <Button
            type="button"
            disabled={busy || saving || !photo || name.trim().length < 2}
            onClick={async () => {
              if (!photo) return;
              setSaving(true);
              try {
                await onSubmit(name.trim(), photo);
              } finally {
                setSaving(false);
              }
            }}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            {saving || busy ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Enregistrement…
              </>
            ) : (
              <>Ajouter {label}</>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ---------- Dialog : renommer ----------

function RenameDialog({
  target,
  onClose,
  busy,
  onSubmit,
}: {
  target: { type: 'zone' | 'device'; id: string; name: string } | null;
  onClose: () => void;
  busy: boolean;
  onSubmit: (name: string) => Promise<void>;
}) {
  // Monté uniquement quand une cible existe : le state est
  // initialisé au montage (pas d'effet de synchronisation).
  if (!target) return null;
  return (
    <Dialog open onOpenChange={(v) => (!v ? onClose() : undefined)}>
      <DialogContent className="rounded-xl sm:max-w-sm" style={{ borderColor: C.line }}>
        <DialogHeader>
          <DialogTitle className="text-base font-black" style={{ color: C.ink }}>
            {target.type === 'zone' ? 'Renommer la pièce' : 'Renommer l’appareil'}
          </DialogTitle>
          <DialogDescription className="text-xs" style={{ color: C.muted }}>
            Nom actuel : <strong>{target.name}</strong>
          </DialogDescription>
        </DialogHeader>
        <RenameForm
          initialName={target.name}
          busy={busy}
          onSubmit={onSubmit}
        />
      </DialogContent>
    </Dialog>
  );
}

/** Champ + bouton — state initialisé une seule fois (montage). */
function RenameForm({
  initialName,
  busy,
  onSubmit,
}: {
  initialName: string;
  busy: boolean;
  onSubmit: (name: string) => Promise<void>;
}) {
  const [name, setName] = useState(initialName);
  return (
    <div className="grid gap-3.5">
      <Input
        value={name}
        onChange={(e) => setName(e.target.value)}
        maxLength={80}
        aria-label="Nouveau nom"
        className="h-11"
      />
      <Button
        type="button"
        disabled={busy || name.trim().length < 2}
        onClick={() => {
          void onSubmit(name.trim());
        }}
        className="h-10 w-full rounded-lg text-sm font-bold text-white"
        style={{ background: C.blueDeep }}
      >
        Enregistrer
      </Button>
    </div>
  );
}
