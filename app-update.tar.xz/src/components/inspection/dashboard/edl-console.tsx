'use client';

// =============================================================
// EDL CONSOLE v2 — « BUSINESS DASHBOARD » (design imposé par le
// client : référence visuelle type infographic business).
//
// Structure fidèle à l'image fournie :
//   • Sidebar bleue verticale (icônes blanches, carte abonnement)
//   • Rangée de 5 KPI : 4 donuts de progression + 1 jauge
//   • Area chart 14 jours (dégradé lavande)
//   • 4 cartes à vagues colorées (bleu / rouge / orange / violet)
//   • Donut de répartition avec total central
//   • Barres empilées (ENTRÉE vs SORTIE, 6 derniers mois)
//   • Timeline horizontale des dernières activités
//   • Tableau des séjours récents + vue complète « Séjours »
//
// Palette image : bleu #2E7CD6, lavande #A5A6F6, violet #8B5CF6,
// rouge #E8425A, orange #F2764C, rose #E9426E, jaune #F5A623,
// teal #1B7B78 — CTA en rouge marque #C21F26 texte blanc (règle).
//
// Circuit v2 : le gate one-shot (1re visite → /payment/success →
// wizard) est géré côté serveur (page.tsx). Ici, l'utilisateur est
// TOUJOURS déjà onboardé : l'accueil = console « Créer un séjour ».
// =============================================================
import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { toast } from 'sonner';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  BookOpen,
  Building2,
  CalendarDays,
  Copy,
  CreditCard,
  ExternalLink,
  FileDown,
  FileText,
  LayoutDashboard,
  LifeBuoy,
  LogIn,
  LogOut,
  Menu,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Timer,
  Trash2,
  X,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip as UITooltip,
  TooltipContent as UITooltipContent,
  TooltipProvider as UITooltipProvider,
  TooltipTrigger as UITooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { AssistanceView } from './edl-support';
import { GuideView } from './edl-guide';
import { ParametresView } from './edl-settings';
import { EdlNotificationsBell } from './edl-notifications-bell';
import { ShieldManager } from '../shield/shield-manager';
import type { SessionUser, ViewKey } from './edl-types';
import {
  formatFrDateTime,
  mailtoLink,
  whatsappLink,
  type InspectionListResponse,
  type InspectionRow,
} from './inspection-types';

// ---------- Palette (codes couleur de l'image client) ----------
const C = {
  sidebarTop: '#2E7CD6',
  sidebarBottom: '#2459A8',
  ring: '#E5EAF5',
  blue: '#3E8EDE',
  blueDeep: '#2464C2',
  lavande: '#A5A6F6',
  violet: '#8B5CF6',
  red: '#E8425A',
  orange: '#F2764C',
  rose: '#E9426E',
  jaune: '#F5A623',
  teal: '#1B7B78',
  cta: '#C21F26',
  ink: '#1E2A3B',
  muted: '#6B7A93',
  line: '#E3E9F4',
} as const;

interface BienRow {
  id: string;
  propertyName: string;
  propertyAddress: string;
  nbChambres: number;
  pieces: string;
  equipementsCoches: string;
  onboardingRef: string;
  onboardedAt: string;
}

const NAV: { key: ViewKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { key: 'bouclier', label: 'Bouclier', icon: ShieldCheck },
  { key: 'sejours', label: 'Séjours', icon: CalendarDays },
  { key: 'biens', label: 'Mes biens', icon: Building2 },
  { key: 'documents', label: 'Documents', icon: FileText },
  { key: 'parametres', label: 'Paramètres', icon: Settings },
  { key: 'assistance', label: 'Assistance', icon: LifeBuoy },
  { key: 'guide', label: "Mode d'emploi", icon: BookOpen },
  { key: 'abonnement', label: 'Abonnement', icon: CreditCard },
];

const VIEW_TITLES: Record<ViewKey, string> = {
  dashboard: 'Tableau de bord',
  bouclier: 'Bouclier Automatisé',
  sejours: 'Séjours',
  biens: 'Mes biens',
  documents: 'Documents',
  parametres: 'Paramètres',
  assistance: 'Assistance',
  guide: "Mode d'emploi",
  abonnement: 'Abonnement',
};

// ---------- Petits composants de style (fidèles à l'image) ----------

/** Titre de carte : « Statistic Graph » bleu + sous-titre gris. */
function CardHead({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-2">
      <div className="min-w-0">
        <p className="text-sm font-bold" style={{ color: C.blueDeep }}>
          {title}
        </p>
        {sub ? (
          <p className="text-[11px]" style={{ color: C.muted }}>
            {sub}
          </p>
        ) : null}
      </div>
      {right}
    </div>
  );
}

/** Carte blanche de base. */
function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={cn('rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5', className)}
      style={{ borderColor: C.line }}
    >
      {children}
    </section>
  );
}

/** Carte KPI rectangulaire lisible (v4.127 — remplace les donuts de %) :
 * icône lucide + GROS chiffre + libellé + contexte explicite. */
function KpiCard({
  icon: Icon,
  value,
  label,
  hint,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
  hint: string;
}) {
  return (
    <section
      className="rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5"
      style={{ borderColor: C.line }}
      aria-label={`${label} : ${value}`}
    >
      <span
        className="inline-flex h-9 w-9 items-center justify-center rounded-full"
        style={{ background: '#E2F1FB' }}
        aria-hidden="true"
      >
        <Icon className="h-[18px] w-[18px]" style={{ color: C.blueDeep }} />
      </span>
      <p className="mt-3 text-2xl font-black leading-none" style={{ color: C.ink }}>
        {value}
      </p>
      <p className="mt-1.5 text-xs font-bold" style={{ color: C.blueDeep }}>
        {label}
      </p>
      <p className="mt-0.5 text-[11px] leading-snug" style={{ color: C.muted }}>
        {hint}
      </p>
    </section>
  );
}

/** Compte à rebours FR (client, tick minute — « dans 2 h », « demain à 10:00 »). */
function upcomingWhenLabel(iso: string, now: Date): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  const diffMin = Math.round((d.getTime() - now.getTime()) / 60000);
  if (diffMin < 0) return 'en cours';
  if (diffMin < 1) return "à l'instant";
  if (diffMin < 60) return `dans ${diffMin} min`;
  const diffH = Math.round(diffMin / 60);
  if (diffH < 24) return `dans ${diffH} h`;
  const dayStart = new Date(now);
  dayStart.setHours(0, 0, 0, 0);
  const targetStart = new Date(d);
  targetStart.setHours(0, 0, 0, 0);
  const days = Math.round((targetStart.getTime() - dayStart.getTime()) / 86400000);
  const time = d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  if (days === 1) return `demain à ${time}`;
  const dateLabel = d.toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });
  return `${dateLabel} à ${time}`;
}

/** Widget « Prochains événements » (v4.127 — demande client : contexte
 * temporel). 3 prochains check-ins / check-outs non terminés, compte à
 * rebours FR, cliquables vers la vue Séjours. Anti-hydratation : les
 * libellés temporels ne s'affichent qu'après montage ('—' avant). */
function UpcomingEvents({
  inspections,
  onOpenSejours,
}: {
  inspections: InspectionRow[];
  onOpenSejours: () => void;
}) {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
    const tick = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(tick);
  }, []);

  const upcoming = useMemo(() => {
    const cutoff = Date.now() - 30 * 60000; // échéances passées depuis < 30 min : « en cours »
    return inspections
      .filter((i) => i.status !== 'COMPLETED' && new Date(i.scheduledDate).getTime() > cutoff)
      .sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate))
      .slice(0, 3);
  }, [inspections]);

  return (
    <Card>
      <CardHead
        title="Prochains événements"
        sub="Check-ins, check-outs et documents à signer"
        right={
          <button
            type="button"
            onClick={onOpenSejours}
            className="text-xs font-bold underline-offset-2 hover:underline"
            style={{ color: C.blueDeep }}
          >
            Tout voir →
          </button>
        }
      />
      {upcoming.length === 0 ? (
        <p className="py-6 text-center text-sm" style={{ color: C.muted }}>
          Aucun check-in ou check-out planifié — créez un nouveau séjour pour démarrer.
        </p>
      ) : (
        <ul className="mt-3 space-y-1.5">
          {upcoming.map((row) => (
            <li key={row.id}>
              <button
                type="button"
                onClick={onOpenSejours}
                aria-label={`Ouvrir ${row.type === 'ENTREE' ? 'le check-in' : 'le check-out'} chez ${row.propertyName}`}
                className="flex min-h-[44px] w-full items-center gap-3 rounded-lg border px-3 py-2 text-left transition-colors hover:bg-[#F4F7FD]"
                style={{ borderColor: C.line }}
              >
                <TypePill type={row.type} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold" style={{ color: C.ink }}>
                    {row.propertyName} — {row.guestName}
                  </span>
                  <span className="block truncate text-[11px]" style={{ color: C.muted }}>
                    {formatFrDateTime(row.scheduledDate)}
                  </span>
                </span>
                <span
                  className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold"
                  style={{ background: '#E2F1FB', color: C.blueDeep }}
                >
                  {now ? upcomingWhenLabel(row.scheduledDate, now) : '—'}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

/** Pastille de statut (pill fine). */
function StatusPill({ status }: { status: string }) {
  const meta: Record<string, { label: string; bg: string; fg: string }> = {
    PENDING: { label: 'En attente', bg: '#FDF3DC', fg: '#9A6B08' },
    IN_PROGRESS: { label: 'En cours', bg: '#E2F1FB', fg: '#1D6FB8' },
    COMPLETED: { label: 'Terminé', bg: '#DFF5EA', fg: '#0E7A52' },
    CANCELLED: { label: 'Annulé', bg: '#EEF1F6', fg: C.muted },
  };
  const m = meta[status] ?? meta.PENDING;
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
      style={{ background: m.bg, color: m.fg }}
    >
      {m.label}
    </span>
  );
}

/** Badge de type : ENTRÉE bleu / SORTIE violet. */
function TypePill({ type }: { type: string }) {
  const isEntree = type === 'ENTREE';
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
      style={{
        background: isEntree ? '#E2F1FB' : '#EFEAFE',
        color: isEntree ? '#1D6FB8' : '#6D3FD1',
      }}
    >
      {isEntree ? 'Entrée' : 'Sortie'}
    </span>
  );
}

// ---------- Console ----------

export function EdlConsole({ sessionUser }: { sessionUser: SessionUser }) {
  const [view, setView] = useState<ViewKey>('dashboard');
  const [navOpen, setNavOpen] = useState(false); // drawer mobile
  const [payload, setPayload] = useState<InspectionListResponse | null>(null);
  const [biens, setBiens] = useState<BienRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [stayOpen, setStayOpen] = useState(false);
  const [deleteArmedId, setDeleteArmedId] = useState<string | null>(null);

  // Console 100 % claire (v4.127) : le site est en thème sombre par
  // défaut — on applique le scope clair à <html> (une fois, avec 2
  // re-tentes retardées pour passer APRÈS l'application du thème par
  // next-themes au montage). Pas d'observateur : un MutationObserver
  // entrait en ping-pong avec la réécriture de la classe et gelait
  // l'onglet (constaté en dev). Restauration au démontage.
  useEffect(() => {
    const root = document.documentElement;
    const wasLight = root.classList.contains('light');
    root.classList.add('light');
    const t1 = setTimeout(() => root.classList.add('light'), 120);
    const t2 = setTimeout(() => root.classList.add('light'), 600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      if (!wasLight) root.classList.remove('light');
    };
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r1, r2] = await Promise.all([
        fetch('/api/inspection/list', { cache: 'no-store' }),
        fetch('/api/inspection/properties', { cache: 'no-store' }),
      ]);
      const j1 = (await r1.json().catch(() => null)) as InspectionListResponse | null;
      const j2 = (await r2.json().catch(() => null)) as { properties?: BienRow[] } | null;
      if (!r1.ok || !j1?.inspections) {
        toast.error('Chargement impossible. Réessayez.');
        return;
      }
      setPayload(j1);
      setBiens(Array.isArray(j2?.properties) ? j2.properties : []);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const inspections = useMemo(() => payload?.inspections ?? [], [payload]);
  const subscription = payload?.subscription ?? null;

  // ── Séjours « fusionnables » : ids dont le PDF FUSIONNÉ (entrée +
  // sortie, design unique) est téléchargeable — une SORTIE signée
  // et liée, ou l'ENTRÉE dont la sortie liée est signée. Le bouton
  // PDF principal utilise le fusionné dès qu'il existe (l'ancien
  // PDF individuel d'un seul document disparaît alors).
  const mergedIds = useMemo(() => {
    const ids = new Set<string>();
    const exitByEntry = new Map<string, InspectionRow>();
    for (const i of inspections) {
      if (i.type === 'SORTIE' && i.linkedInspectionId) exitByEntry.set(i.linkedInspectionId, i);
    }
    for (const i of inspections) {
      if (i.type === 'SORTIE') {
        if (i.status === 'COMPLETED' && i.linkedInspectionId) ids.add(i.id);
      } else {
        const exit = exitByEntry.get(i.id);
        if (exit && exit.status === 'COMPLETED') ids.add(i.id);
      }
    }
    return ids;
  }, [inspections]);

  // ---------- Agrégats (séjours = paires ENTREE + SORTIE liée) ----------
  const stats = useMemo(() => {
    const entries = inspections.filter((i) => i.type === 'ENTREE');
    const exits = inspections.filter((i) => i.type === 'SORTIE');
    const exitByEntry = new Map<string, InspectionRow>();
    for (const e of exits) {
      if (e.linkedInspectionId) exitByEntry.set(e.linkedInspectionId, e);
    }
    const stays = entries.map((entry) => ({ entry, exit: exitByEntry.get(entry.id) ?? null }));
    const entryDone = entries.filter((e) => e.status === 'COMPLETED').length;
    const exitDone = exits.filter((e) => e.status === 'COMPLETED').length;
    const sealed = inspections.filter((i) => i.sha256Hash).length;
    const fullStays = stays.filter((s) => s.entry.status === 'COMPLETED' && s.exit?.status === 'COMPLETED').length;
    const statusDist = [
      { name: 'En attente', value: inspections.filter((i) => i.status === 'PENDING').length, color: C.jaune },
      { name: 'En cours', value: inspections.filter((i) => i.status === 'IN_PROGRESS').length, color: C.blue },
      { name: 'Terminé', value: inspections.filter((i) => i.status === 'COMPLETED').length, color: C.violet },
    ].filter((d) => d.value > 0);
    const statusTotal = inspections.length;

    // Area chart : créations par jour (14 derniers jours).
    const days: { day: string; total: number }[] = [];
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      days.push({
        day: d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
        total: inspections.filter((x) => x.createdAt.slice(0, 10) === key).length,
      });
    }

    // Barres empilées : ENTRÉE vs SORTIE sur 6 mois.
    const months: { month: string; entree: number; sortie: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      months.push({
        month: d.toLocaleDateString('fr-FR', { month: 'short' }).replace('.', ''),
        entree: inspections.filter((x) => x.type === 'ENTREE' && x.createdAt.slice(0, 7) === key).length,
        sortie: inspections.filter((x) => x.type === 'SORTIE' && x.createdAt.slice(0, 7) === key).length,
      });
    }

    const timeline = inspections.slice(0, 6);
    return {
      stays,
      entryTotal: entries.length,
      entryDone,
      exitTotal: exits.length,
      exitDone,
      sealed,
      fullStays,
      statusDist,
      statusTotal,
      days,
      months,
      timeline,
      globalRate:
        entries.length + exits.length > 0
          ? ((entryDone + exitDone) / (entries.length + exits.length)) * 100
          : 0,
    };
  }, [inspections]);

  const stayActions = {
    onDelete: async (row: InspectionRow) => {
      try {
        const res = await fetch(`/api/inspection/manage/${row.id}`, { method: 'DELETE' });
        if (!res.ok) {
          toast.error('Suppression impossible.');
          return;
        }
        toast.success('État des lieux supprimé.');
        void load();
      } catch {
        toast.error('Erreur de connexion.');
      }
    },
  };

  // ---------- Rendu ----------
  const initials = (sessionUser.name ?? sessionUser.email ?? 'H')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  const expired = subscription && subscription.status !== 'active';

  return (
    <div className="min-h-screen" style={{ background: '#E9EDF6' }}>
      {/* ══ Sidebar desktop ══ */}
      <aside
        className="fixed inset-y-0 left-0 z-40 hidden w-[264px] flex-col justify-between text-white md:flex"
        style={{ background: `linear-gradient(180deg, ${C.sidebarTop} 0%, ${C.sidebarBottom} 100%)` }}
        aria-label="Navigation principale"
      >
        <div>
          <div className="flex items-center gap-3 px-5 pt-6 pb-7">
            {/* Logo officiel RoomScan (variante blanche pour fond bleu) */}
            <Image
              src="/brand/roomscan-logo-white.png"
              alt="Logo RoomScan"
              width={124}
              height={121}
              priority
              className="h-10 w-auto shrink-0"
            />
            <div className="leading-tight">
              <p className="text-sm font-black tracking-wide">RoomScan</p>
              <p className="text-[11px] font-medium text-white/70">États des Lieux</p>
            </div>
          </div>
          <nav className="space-y-1 px-3">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = view === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => {
                    setView(item.key);
                    setNavOpen(false);
                  }}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'flex min-h-[44px] w-full items-center gap-3 rounded-lg px-4 text-sm font-semibold transition-colors',
                    active ? 'bg-white text-[#2459A8] shadow-sm' : 'text-white/85 hover:bg-white/10 hover:text-white',
                  )}
                >
                  <Icon className="h-4.5 w-4.5 h-[18px] w-[18px]" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
        {/* Carte abonnement (bas de sidebar) */}
        <div className="px-4 pb-6">
          <div className="rounded-xl bg-white/12 p-4 backdrop-blur">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/70">Offre active</p>
            <p className="mt-1 text-sm font-black">299 € / an</p>
            <p className="mt-0.5 text-[11px] text-white/70">
              {subscription ? `Jusqu'au ${formatFrDateTime(subscription.endDate).split(' à')[0]}` : '—'}
            </p>
            <button
              type="button"
              onClick={() => setView('abonnement')}
              className="mt-3 w-full rounded-lg bg-white/20 py-2 text-xs font-bold transition-colors hover:bg-white/30"
            >
              Gérer l&apos;abonnement
            </button>
          </div>
        </div>
      </aside>

      {/* ══ Drawer mobile ══ */}
      {navOpen ? (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <button
            type="button"
            aria-label="Fermer le menu"
            className="absolute inset-0 bg-black/40"
            onClick={() => setNavOpen(false)}
          />
          <aside
            className="absolute inset-y-0 left-0 flex w-[264px] flex-col justify-between text-white shadow-2xl"
            style={{ background: `linear-gradient(180deg, ${C.sidebarTop} 0%, ${C.sidebarBottom} 100%)` }}
          >
            <div>
              <div className="flex items-center justify-between px-5 pt-6 pb-7">
                <div className="flex items-center gap-2.5">
                  <Image
                    src="/brand/roomscan-logo-white.png"
                    alt="Logo RoomScan"
                    width={124}
                    height={121}
                    className="h-8 w-auto shrink-0"
                  />
                  <p className="text-sm font-black tracking-wide">États des Lieux</p>
                </div>
                <button type="button" onClick={() => setNavOpen(false)} aria-label="Fermer" className="p-1">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="space-y-1 px-3">
                {NAV.map((item) => {
                  const Icon = item.icon;
                  const active = view === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => {
                        setView(item.key);
                        setNavOpen(false);
                      }}
                      className={cn(
                        'flex min-h-[44px] w-full items-center gap-3 rounded-lg px-4 text-sm font-semibold',
                        active ? 'bg-white text-[#2459A8]' : 'text-white/85 hover:bg-white/10',
                      )}
                    >
                      <Icon className="h-[18px] w-[18px]" />
                      {item.label}
                    </button>
                  );
                })}
              </nav>
            </div>
            <div className="px-4 pb-6 text-xs text-white/80">
              <p className="font-black">299 € / an</p>
              <p>{subscription ? `Actif jusqu'au ${formatFrDateTime(subscription.endDate).split(' à')[0]}` : '—'}</p>
            </div>
          </aside>
        </div>
      ) : null}

      {/* ══ Zone principale ══ */}
      <div className="md:pl-[264px]">
        {/* Header */}
        <header
          className="sticky top-0 z-30 border-b bg-white/95 backdrop-blur"
          style={{ borderColor: C.line }}
        >
          <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setNavOpen(true)}
                aria-label="Ouvrir le menu"
                className="rounded-lg p-2 md:hidden"
                style={{ color: C.ink }}
              >
                <Menu className="h-5 w-5" />
              </button>
              <h1 className="truncate text-lg font-black sm:text-xl" style={{ color: C.ink }}>
                {VIEW_TITLES[view]}
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <Button
                type="button"
                onClick={() => setStayOpen(true)}
                className="hidden h-10 items-center gap-2 rounded-lg px-4 text-sm font-bold text-white shadow-sm hover:brightness-110 sm:inline-flex"
                style={{ background: C.cta }}
                aria-label="Créer un nouveau séjour"
              >
                <Plus className="h-4 w-4" />
                Créer un nouveau séjour
              </Button>
              {/* Demande client : cloche de notifications à côté de « Créer
                  un nouveau séjour », badge rouge pour les alertes critiques. */}
              <EdlNotificationsBell />
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full text-xs font-black text-white"
                style={{ background: C.blueDeep }}
                aria-hidden="true"
              >
                {initials}
              </span>
            </div>
          </div>
          {expired ? (
            <div className="px-4 pb-3 sm:px-6">
              <p
                className="rounded-lg border px-3 py-2 text-xs font-semibold"
                style={{ borderColor: '#F2DFAE', background: '#FDF3DC', color: '#9A6B08' }}
              >
                Votre abonnement a expiré — renouvelez-le sur{' '}
                <Link href="/edl/abonnement" className="underline">
                  la page d&apos;abonnement
                </Link>{' '}
                pour continuer à créer des séjours.
              </p>
            </div>
          ) : null}
        </header>

        {/* Bouton créer (mobile, toujours visible) */}
        <div className="px-4 pt-4 sm:hidden">
          <Button
            type="button"
            onClick={() => setStayOpen(true)}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            <Plus className="mr-1 h-4 w-4" /> Créer un nouveau séjour
          </Button>
        </div>

        <main className="mx-auto w-full max-w-[1400px] overflow-x-hidden px-4 py-4 sm:px-6 sm:py-6">
          {loading ? (
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-28 rounded-xl" />
                ))}
              </div>
              <Skeleton className="h-72 rounded-xl" />
            </div>
          ) : (
            <>
              {view === 'dashboard' ? (
                <DashboardView
                  stats={stats}
                  inspections={inspections}
                  mergedIds={mergedIds}
                  onOpenStay={() => setStayOpen(true)}
                  onDelete={stayActions.onDelete}
                  deleteArmedId={deleteArmedId}
                  setDeleteArmedId={setDeleteArmedId}
                  setView={setView}
                />
              ) : null}
              {view === 'bouclier' ? (
                <ShieldManager sessionUser={sessionUser} />
              ) : null}
              {view === 'sejours' ? (
                <SejoursView
                  inspections={inspections}
                  mergedIds={mergedIds}
                  onDelete={stayActions.onDelete}
                  deleteArmedId={deleteArmedId}
                  setDeleteArmedId={setDeleteArmedId}
                  onOpenStay={() => setStayOpen(true)}
                />
              ) : null}
              {view === 'biens' ? (
                <BiensView
                  biens={biens}
                  inspections={inspections}
                  onOpenStay={() => setStayOpen(true)}
                />
              ) : null}
              {view === 'documents' ? <DocumentsView inspections={inspections} /> : null}
              {view === 'parametres' ? <ParametresView /> : null}
              {view === 'assistance' ? <AssistanceView sessionUser={sessionUser} /> : null}
              {view === 'guide' ? <GuideView setView={setView} /> : null}
              {view === 'abonnement' && subscription ? (
                <AbonnementView subscription={subscription} />
              ) : null}
            </>
          )}
        </main>
      </div>

      {/* ══ Dialog créer un séjour ══ */}
      <StayDialog
        open={stayOpen}
        onOpenChange={setStayOpen}
        biens={biens ?? []}
        onCreated={() => {
          void load();
          setView('sejours');
        }}
      />
    </div>
  );
}

// ---------- Vue : Tableau de bord ----------

function DashboardView({
  stats,
  inspections,
  mergedIds,
  onOpenStay,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
  setView,
}: {
  stats: {
    stays: { entry: InspectionRow; exit: InspectionRow | null }[];
    entryTotal: number;
    entryDone: number;
    exitTotal: number;
    exitDone: number;
    sealed: number;
    fullStays: number;
    statusDist: { name: string; value: number; color: string }[];
    statusTotal: number;
    days: { day: string; total: number }[];
    months: { month: string; entree: number; sortie: number }[];
    timeline: InspectionRow[];
    globalRate: number;
  };
  inspections: InspectionRow[];
  mergedIds: Set<string>;
  onOpenStay: () => void;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
  setView: (v: ViewKey) => void;
}) {
  // ── v4.127 — KPI LISIBLES (demande client : « les 5 cercles → 4 cartes
  // rectangulaires lisibles, jamais un pourcentage nu sans contexte »).
  // Chiffres RÉELS dérivés de la liste des inspections : ratios X/X,
  // revenus protégés (séjours complets × 500 € estimation), temps gagné
  // (EDL signés ce mois × 45 min). ──
  const nowDate = new Date();
  const weekStart = new Date(nowDate);
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7)); // lundi 00:00
  weekStart.setHours(0, 0, 0, 0);
  const monthKey = `${nowDate.getFullYear()}-${String(nowDate.getMonth() + 1).padStart(2, '0')}`;
  const inWeek = (iso: string | null) => !!iso && new Date(iso) >= weekStart;
  const inMonth = (iso: string | null) => !!iso && iso.slice(0, 7) === monthKey;
  const entryDoneWeek = inspections.filter(
    (i) => i.type === 'ENTREE' && i.status === 'COMPLETED' && inWeek(i.completedAt ?? i.scheduledDate),
  ).length;
  const exitDoneWeek = inspections.filter(
    (i) => i.type === 'SORTIE' && i.status === 'COMPLETED' && inWeek(i.completedAt ?? i.scheduledDate),
  ).length;
  const signedThisMonth = inspections.filter(
    (i) => i.status === 'COMPLETED' && inMonth(i.completedAt ?? i.scheduledDate),
  ).length;
  const minutesSaved = signedThisMonth * 45;
  const protectedRevenue = stats.fullStays * 500; // estimation 500 €/séjour complet
  const eurosFmt = new Intl.NumberFormat('fr-FR');
  const hoursLabel =
    minutesSaved % 60 === 0 ? `${minutesSaved / 60} h` : `${Math.floor(minutesSaved / 60)} h ${minutesSaved % 60} min`;

  // Répartition par logement (remplace la carte « Volumétrie » — demande client).
  const propertyBreakdown = useMemo(() => {
    const counts = new Map<string, number>();
    for (const i of inspections) counts.set(i.propertyName, (counts.get(i.propertyName) ?? 0) + 1);
    const total = inspections.length || 1;
    return [...counts.entries()]
      .map(([name, count]) => ({ name, count, pct: Math.round((count / total) * 100) }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [inspections]);

  const recent = inspections.slice(0, 5);

  return (
    <div className="grid gap-4">
      {/* ── Rangée KPI : 4 cartes rectangulaires lisibles (jamais de % nu) ── */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KpiCard
          icon={LogIn}
          value={`${stats.entryDone}/${stats.entryTotal}`}
          label="Check-ins terminés"
          hint={
            stats.entryTotal
              ? `${entryDoneWeek} cette semaine · entrées signées`
              : 'Aucun check-in pour le moment'
          }
        />
        <KpiCard
          icon={LogOut}
          value={`${stats.exitDone}/${stats.exitTotal}`}
          label="Check-outs terminés"
          hint={
            stats.exitTotal
              ? `${exitDoneWeek} cette semaine · sorties signées`
              : 'Aucun check-out pour le moment'
          }
        />
        <KpiCard
          icon={ShieldCheck}
          value={`${eurosFmt.format(protectedRevenue)} €`}
          label="Revenus protégés"
          hint={
            stats.fullStays
              ? `${stats.fullStays} séjour(s) complet(s) · estimation 500 €/séjour`
              : 'Cautions sécurisées sur séjours complets'
          }
        />
        <KpiCard
          icon={Timer}
          value={hoursLabel}
          label="Temps gagné"
          hint={
            signedThisMonth
              ? `${signedThisMonth} EDL digitalisé(s) ce mois (45 min/document)`
              : 'Aucun EDL signé ce mois-ci'
          }
        />
      </div>

      {/* ── Prochains événements (demande client : contexte temporel avec compte à rebours) ── */}
      <UpcomingEvents inspections={inspections} onOpenSejours={() => setView('sejours')} />

      {/* ── Area chart + cartes vagues + donut ── */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-6">
          <CardHead title="Activité — créations" sub="14 derniers jours" />
          <div className="mt-3 h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.days} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradLavande" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={C.lavande} stopOpacity={0.85} />
                    <stop offset="100%" stopColor={C.lavande} stopOpacity={0.08} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={C.line} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }}
                  formatter={(v) => [`${v} document(s)`, 'Créés']}
                />
                <Area type="monotone" dataKey="total" stroke={C.lavande} strokeWidth={2} fill="url(#gradLavande)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="lg:col-span-3">
          <CardHead title="Répartition par logement" sub="Documents par bien" />
          <div className="mt-3 space-y-2.5">
            {propertyBreakdown.length === 0 ? (
              <p className="py-6 text-center text-xs" style={{ color: C.muted }}>
                Aucun document pour le moment.
              </p>
            ) : (
              propertyBreakdown.map((p) => (
                <div key={p.name}>
                  <div className="flex items-baseline justify-between gap-2">
                    <p className="truncate text-xs font-semibold" style={{ color: C.ink }}>
                      {p.name}
                    </p>
                    <p className="shrink-0 text-[11px] font-bold" style={{ color: C.muted }}>
                      {p.count} · {p.pct} %
                    </p>
                  </div>
                  <div
                    className="mt-1 h-2 w-full overflow-hidden rounded-full"
                    style={{ background: C.ring }}
                    aria-hidden="true"
                  >
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${Math.min(100, p.pct)}%`,
                        background: `linear-gradient(90deg, ${C.blueDeep}, ${C.blue})`,
                      }}
                    />
                  </div>
                </div>
              ))
            )}
          </div>
          <button
            type="button"
            onClick={onOpenStay}
            className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg text-sm font-bold text-white transition-opacity hover:opacity-90"
            style={{ background: C.cta }}
          >
            <Plus className="h-4 w-4" /> Nouveau séjour
          </button>
        </Card>

        <Card className="lg:col-span-3">
          <CardHead title="Répartition" sub="Statuts des documents" />
          {/* Donut agrandi + légende détaillée (demande client) */}
          <div className="relative mt-2 h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.statusDist.length ? stats.statusDist : [{ name: 'Aucun', value: 1, color: C.ring }]}
                  dataKey="value"
                  innerRadius="58%"
                  outerRadius="80%"
                  strokeWidth={2}
                  stroke="#fff"
                  isAnimationActive={false}
                >
                  {(stats.statusDist.length ? stats.statusDist : [{ color: C.ring }]).map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-black" style={{ color: C.ink }}>
                {stats.statusTotal}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: C.muted }}>
                documents
              </span>
            </div>
          </div>
          <ul className="mt-2 space-y-1.5">
            {stats.statusDist.map((d) => (
              <li key={d.name} className="flex items-center gap-2 text-xs" style={{ color: C.ink }}>
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: d.color }} aria-hidden="true" />
                {d.name}
                <span className="ml-auto font-bold">
                  {d.value} · {stats.statusTotal ? Math.round((d.value / stats.statusTotal) * 100) : 0} %
                </span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {/* ── Barres empilées + timeline ── */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-7">
          <CardHead title="États des lieux par mois" sub="Entrées vs sorties — 6 derniers mois" />
          <div className="mt-3 h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.months} margin={{ top: 8, right: 8, left: -18, bottom: 0 }} barCategoryGap="28%">
                <CartesianGrid stroke={C.line} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }} cursor={{ fill: 'rgba(46,124,214,0.06)' }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="entree" name="Entrées" stackId="a" fill={C.blueDeep} radius={[0, 0, 0, 0]} />
                <Bar dataKey="sortie" name="Sorties" stackId="a" fill={C.lavande} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="min-w-0 overflow-hidden lg:col-span-5">
          <CardHead title="Dernières activités" sub="Chronologie des documents" />
          <div className="mt-4 overflow-x-auto pb-1">
            {stats.timeline.length === 0 ? (
              <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
                Aucune activité pour le moment.
              </p>
            ) : (
              <div className="relative flex min-w-[520px] items-start">
                {/* Ligne horizontale */}
                <span
                  aria-hidden="true"
                  className="absolute left-4 right-4 top-[38px] h-0.5"
                  style={{ background: C.line }}
                />
                {stats.timeline.map((t) => {
                  const d = new Date(t.createdAt);
                  return (
                    <div key={t.id} className="relative flex w-1/6 min-w-[86px] flex-col items-center px-1">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                        style={{ background: t.type === 'ENTREE' ? C.blueDeep : C.violet }}
                      >
                        {d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
                      </span>
                      <span
                        aria-hidden="true"
                        className="my-1.5 h-3 w-3 rounded-full border-2 border-white shadow"
                        style={{ background: t.status === 'COMPLETED' ? C.teal : C.blue }}
                      />
                      <p className="line-clamp-2 text-center text-[11px] font-semibold leading-tight" style={{ color: C.ink }}>
                        {t.propertyName}
                      </p>
                      <div className="mt-1 flex flex-col items-center gap-1">
                        <TypePill type={t.type} />
                        <StatusPill status={t.status} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <button
            type="button"
            onClick={() => setView('sejours')}
            className="mt-3 text-xs font-bold underline-offset-2 hover:underline"
            style={{ color: C.blueDeep }}
          >
            Voir tous les séjours →
          </button>
        </Card>
      </div>

      {/* ── Séjours récents (tableau) ── */}
      <Card>
        <CardHead title="Séjours récents" sub="5 derniers documents" />
        <RecentTable
          rows={recent}
          mergedIds={mergedIds}
          onDelete={onDelete}
          deleteArmedId={deleteArmedId}
          setDeleteArmedId={setDeleteArmedId}
        />
      </Card>
    </div>
  );
}

// ---------- Tableau récent (partagé) ----------

function RecentTable({
  rows,
  mergedIds,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
}: {
  rows: InspectionRow[];
  mergedIds: Set<string>;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
}) {
  if (rows.length === 0) {
    return (
      <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
        Aucun état des lieux pour le moment.
      </p>
    );
  }
  return (
    <>
      {/* Desktop */}
      <div className="mt-3 hidden overflow-x-auto md:block">
        <Table>
          <TableHeader>
            <TableRow style={{ background: '#F4F7FD' }}>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Logement
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Type
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Invité
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Date visée
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Statut
              </TableHead>
              <TableHead className="text-right text-xs font-bold" style={{ color: C.blueDeep }}>
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row, i) => (
              <TableRow key={row.id} style={{ background: i % 2 ? '#F7F9FE' : '#fff' }}>
                <TableCell className="max-w-[220px]">
                  <p className="truncate text-sm font-semibold" style={{ color: C.ink }}>
                    {row.propertyName}
                  </p>
                  <p className="truncate text-[11px]" style={{ color: C.muted }}>
                    {row.propertyAddress}
                  </p>
                </TableCell>
                <TableCell>
                  <TypePill type={row.type} />
                </TableCell>
                <TableCell className="text-sm" style={{ color: C.ink }}>
                  {row.guestName}
                </TableCell>
                <TableCell className="whitespace-nowrap text-xs" style={{ color: C.muted }}>
                  {formatFrDateTime(row.scheduledDate)}
                </TableCell>
                <TableCell>
                  <StatusPill status={row.status} />
                </TableCell>
                <TableCell>
                  <RowActions
                    row={row}
                    merged={mergedIds.has(row.id)}
                    onDelete={onDelete}
                    deleteArmedId={deleteArmedId}
                    setDeleteArmedId={setDeleteArmedId}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {/* Mobile : cartes */}
      <div className="mt-3 space-y-3 md:hidden">
        {rows.map((row) => (
          <div key={row.id} className="rounded-xl border p-3" style={{ borderColor: C.line }}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-bold" style={{ color: C.ink }}>
                  {row.propertyName}
                </p>
                <p className="truncate text-[11px]" style={{ color: C.muted }}>
                  {row.guestName} · {formatFrDateTime(row.scheduledDate)}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                <TypePill type={row.type} />
                <StatusPill status={row.status} />
              </div>
            </div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              <RowActions
                row={row}
                merged={mergedIds.has(row.id)}
                onDelete={onDelete}
                deleteArmedId={deleteArmedId}
                setDeleteArmedId={setDeleteArmedId}
              />
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------- Actions d'une ligne ----------

/**
 * Télécharge le PDF FUSIONNÉ (entrée + sortie) en gérant les
 * erreurs métier par toast (jamais de JSON brut affiché) — 409
 * « sortie non complétée », 404, rate limit…
 */
async function downloadMergedPdf(id: string): Promise<void> {
  try {
    const res = await fetch(`/api/inspection/merged-pdf/${id}`);
    if (res.ok) {
      const blob = await res.blob();
      const cd = res.headers.get('Content-Disposition') ?? '';
      const m = /filename\*?=(?:UTF-8''|")?([^";]+)/.exec(cd);
      const name = m ? decodeURIComponent(m[1]) : 'Etat-des-lieux-fusionne.pdf';
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success('PDF fusionné (entrée + sortie) téléchargé.');
      return;
    }
    const json = (await res.json().catch(() => null)) as { error?: string; message?: string } | null;
    toast.error(json?.message ?? json?.error ?? 'PDF fusionné indisponible pour le moment.');
  } catch {
    toast.error('Erreur de connexion.');
  }
}

function RowActions({
  row,
  merged,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
}: {
  row: InspectionRow;
  merged: boolean;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
}) {
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(row.shareUrl);
      toast.success('Lien public copié — s’ouvre sans compte ni mot de passe.');
    } catch {
      toast.error('Copie impossible.');
    }
  };
  const armed = deleteArmedId === row.id;

  return (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      {/* Lien public : OUVRE le lien invité (aucun compte, aucun mot de
          passe — l’invité vérifie et signe directement). */}
      <a
        href={row.shareUrl}
        target="_blank"
        rel="noreferrer"
        className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
        style={{ borderColor: C.line, color: C.ink }}
        aria-label={`Ouvrir le lien public de ${row.propertyName}`}
      >
        <ExternalLink className="h-3.5 w-3.5" /> Lien
      </a>
      <button
        type="button"
        onClick={copy}
        className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
        style={{ borderColor: C.line, color: C.ink }}
        aria-label="Copier le lien public"
      >
        <Copy className="h-3.5 w-3.5" />
      </button>
      {row.guestEmail ? (
        <a
          href={mailtoLink(row.guestEmail, row.guestName, row.shareUrl)}
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: C.line, color: C.ink }}
          aria-label="Envoyer par email"
        >
          Email
        </a>
      ) : (
        <a
          href={whatsappLink(row.guestName, row.shareUrl)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: C.line, color: C.ink }}
          aria-label="Partager via WhatsApp"
        >
          WhatsApp
        </a>
      )}
      {/* PDF : le fusionné (entrée + sortie, design complet) dès qu’il
          existe ; sinon le PDF individuel du document. */}
      {merged ? (
        <button
          type="button"
          onClick={() => {
            void downloadMergedPdf(row.id);
          }}
          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-2.5 text-xs font-bold text-white transition-opacity hover:opacity-90"
          style={{ background: C.violet }}
          aria-label="Télécharger le PDF fusionné entrée + sortie"
        >
          <FileDown className="h-3.5 w-3.5" /> PDF fusionné
        </button>
      ) : (
        <a
          href={`/api/inspection/pdf/${row.publicToken}`}
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: C.line, color: C.ink }}
          aria-label="Ouvrir le PDF"
        >
          <FileDown className="h-3.5 w-3.5" /> PDF
        </a>
      )}
      {armed ? (
        <button
          type="button"
          onClick={() => {
            void onDelete(row);
            setDeleteArmedId(null);
          }}
          className="inline-flex min-h-[36px] items-center rounded-lg px-2.5 text-xs font-bold text-white"
          style={{ background: C.red }}
          aria-label="Confirmer la suppression"
        >
          Confirmer
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setDeleteArmedId(row.id)}
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#FDF0F2]"
          style={{ borderColor: C.line, color: C.red }}
          aria-label="Supprimer (double confirmation)"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

// ---------- Vue : Séjours ----------

function SejoursView({
  inspections,
  mergedIds,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
  onOpenStay,
}: {
  inspections: InspectionRow[];
  mergedIds: Set<string>;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
  onOpenStay: () => void;
}) {
  const [query, setQuery] = useState('');
  // v4.127 — demande client : filtres par statut + tri par date (50+ séjours).
  const [filter, setFilter] = useState<'tous' | 'avenir' | 'encours' | 'termines'>('tous');
  const filtered = useMemo(() => {
    const nowMs = Date.now();
    let rows = inspections;
    if (filter === 'avenir') {
      rows = rows.filter((i) => i.status !== 'COMPLETED' && new Date(i.scheduledDate).getTime() > nowMs);
    } else if (filter === 'encours') {
      rows = rows.filter((i) => i.status === 'IN_PROGRESS');
    } else if (filter === 'termines') {
      rows = rows.filter((i) => i.status === 'COMPLETED');
    }
    const q = query.trim().toLowerCase();
    if (q) {
      rows = rows.filter((i) =>
        [i.propertyName, i.guestName, i.propertyAddress].some(
          (v) => (v ?? '').toLowerCase().includes(q),
        ),
      );
    }
    // Tri par date : les séjours les plus proches/récents d'abord.
    return [...rows].sort((a, b) => b.scheduledDate.localeCompare(a.scheduledDate));
  }, [inspections, query, filter]);

  return (
    <Card>
      <CardHead
        title="Tous les séjours"
        sub={`${filtered.length} sur ${inspections.length} document(s) — check-ins et check-outs`}
        right={
          <Button
            type="button"
            onClick={onOpenStay}
            className="h-9 rounded-lg px-3 text-xs font-bold text-white"
            style={{ background: C.cta }}
          >
            <Plus className="mr-1 h-3.5 w-3.5" /> Créer
          </Button>
        }
      />
      {/* ── Recherche ── */}
      <div className="relative mt-3">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2"
          style={{ color: C.muted }}
          aria-hidden="true"
        />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Rechercher un logement, un invité, une adresse…"
          aria-label="Rechercher dans les séjours"
          className="h-11 pl-9"
        />
      </div>
      {/* ── Filtres (demande client : « Tous / À venir / En cours / Terminés ») ── */}
      <div className="mt-2.5 flex flex-wrap gap-1.5" role="group" aria-label="Filtrer les séjours par statut">
        {(
          [
            ['tous', 'Tous'],
            ['avenir', 'À venir'],
            ['encours', 'En cours'],
            ['termines', 'Terminés'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            aria-pressed={filter === key}
            onClick={() => setFilter(key)}
            className={cn(
              'min-h-[36px] rounded-full px-3.5 text-xs font-bold transition-colors',
              filter === key ? 'text-white' : 'border hover:bg-[#F4F7FD]',
            )}
            style={
              filter === key
                ? { background: C.blueDeep, borderColor: C.blueDeep }
                : { borderColor: C.line, color: C.ink }
            }
          >
            {label}
          </button>
        ))}
      </div>
      <RecentTable
        rows={filtered}
        mergedIds={mergedIds}
        onDelete={onDelete}
        deleteArmedId={deleteArmedId}
        setDeleteArmedId={setDeleteArmedId}
      />
    </Card>
  );
}

// ---------- Vue : Mes biens ----------

function BiensView({
  biens,
  inspections,
  onOpenStay,
}: {
  biens: BienRow[] | null;
  inspections: InspectionRow[];
  onOpenStay: () => void;
}) {
  const list = biens ?? [];

  // ── Contexte utile (demande client : jamais de page « vide ») ──
  const nowDate = new Date();
  const monthKey = `${nowDate.getFullYear()}-${String(nowDate.getMonth() + 1).padStart(2, '0')}`;
  const signedThisMonth = inspections.filter(
    (i) => i.status === 'COMPLETED' && (i.completedAt ?? i.scheduledDate).slice(0, 7) === monthKey,
  ).length;
  const minutesSaved = signedThisMonth * 45;
  const hoursLabel =
    minutesSaved % 60 === 0 ? `${minutesSaved / 60} h` : `${Math.floor(minutesSaved / 60)} h ${minutesSaved % 60} min`;
  const upcomingCount = inspections.filter(
    (i) => i.status !== 'COMPLETED' && new Date(i.scheduledDate).getTime() > nowDate.getTime(),
  ).length;

  return (
    <div className="grid gap-4">
      {/* ── Bandeau contexte : temps gagné + échéances à venir ── */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="flex items-center gap-3">
          <span
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full"
            style={{ background: '#E2F1FB' }}
            aria-hidden="true"
          >
            <Timer className="h-[18px] w-[18px]" style={{ color: C.blueDeep }} />
          </span>
          <div className="min-w-0">
            <p className="text-xl font-black leading-none" style={{ color: C.ink }}>
              {hoursLabel}
            </p>
            <p className="mt-1 text-[11px]" style={{ color: C.muted }}>
              Vous avez économisé ce mois-ci (45 min par état des lieux digital)
            </p>
          </div>
        </Card>
        <Card className="flex items-center gap-3">
          <span
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full"
            style={{ background: '#E2F1FB' }}
            aria-hidden="true"
          >
            <CalendarDays className="h-[18px] w-[18px]" style={{ color: C.blueDeep }} />
          </span>
          <div className="min-w-0">
            <p className="text-xl font-black leading-none" style={{ color: C.ink }}>
              {upcomingCount}
            </p>
            <p className="mt-1 text-[11px]" style={{ color: C.muted }}>
              check-in(s) / check-out(s) planifié(s) à venir
            </p>
          </div>
        </Card>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((b) => {
          let pieces: string[] = [];
          try {
            pieces = JSON.parse(b.pieces) as string[];
          } catch {
            pieces = [];
          }
          // ── Mini-stats par bien (demande client) ──
          const docs = inspections.filter((i) => i.propertyName === b.propertyName);
          const checkinsDone = docs.filter((i) => i.type === 'ENTREE' && i.status === 'COMPLETED').length;
          const lastDone = docs
            .filter((i) => i.status === 'COMPLETED')
            .sort((x, y) => (y.completedAt ?? y.createdAt).localeCompare(x.completedAt ?? x.createdAt))[0];
          const lastLabel = lastDone
            ? new Date(lastDone.completedAt ?? lastDone.createdAt).toLocaleDateString('fr-FR')
            : null;
          return (
            <Card key={b.id} className="flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-black" style={{ color: C.ink }}>
                    {b.propertyName}
                  </p>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{ background: '#E2F1FB', color: '#1D6FB8' }}
                  >
                    {b.nbChambres === 0 ? 'Studio' : `${b.nbChambres} ch.`}
                  </span>
                </div>
                {/* Badge protection + mini-stats réelles */}
                <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1">
                  {checkinsDone > 0 ? (
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
                      style={{ background: '#DFF5EA', color: '#0E7A52' }}
                    >
                      <span
                        className="h-1.5 w-1.5 rounded-full"
                        style={{ background: '#0E7A52' }}
                        aria-hidden="true"
                      />
                      Protégé
                    </span>
                  ) : (
                    <span
                      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
                      style={{ background: '#FDF3DC', color: '#9A6B08' }}
                    >
                      Onboarding à finaliser
                    </span>
                  )}
                  <span className="text-[11px] font-semibold" style={{ color: C.muted }}>
                    {checkinsDone} check-in(s) signé(s) · {docs.length} document(s)
                  </span>
                </div>
                <p className="mt-1 text-xs" style={{ color: C.muted }}>
                  {b.propertyAddress}
                </p>
                {lastLabel ? (
                  <p className="mt-1 text-[11px]" style={{ color: C.muted }}>
                    Dernier document signé : {lastLabel}
                  </p>
                ) : null}
                <p className="mt-2 text-[11px] font-semibold" style={{ color: C.blueDeep }}>
                  {b.onboardingRef}
                </p>
                {pieces.length ? (
                  <p className="mt-2 line-clamp-2 text-[11px]" style={{ color: C.muted }}>
                    Pièces : {pieces.join(', ')}
                  </p>
                ) : null}
              </div>
              {/* Action rapide (demande client) */}
              <Button
                type="button"
                onClick={onOpenStay}
                className="mt-3 h-10 w-full rounded-lg text-sm font-bold text-white hover:brightness-110"
                style={{ background: C.cta }}
                aria-label={`Créer un nouveau séjour pour ${b.propertyName}`}
              >
                <Plus className="mr-1 h-4 w-4" /> Nouveau séjour
              </Button>
            </Card>
          );
        })}
        {/* Carte « Ajouter un bien » (relance le wizard) */}
        <Link
          href="/onboarding/wizard?step=1"
          className="flex min-h-[150px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-5 text-center transition-colors hover:bg-[#F4F8FE]"
          style={{ borderColor: C.blue, color: C.blueDeep }}
        >
          <Plus className="h-6 w-6" aria-hidden="true" />
          <p className="text-sm font-black">Ajouter un bien</p>
          <p className="text-[11px]" style={{ color: C.muted }}>
            Relancer l&apos;onboarding guidé (5 min)
          </p>
        </Link>
      </div>
      {list.length === 0 ? (
        <p className="text-center text-sm" style={{ color: C.muted }}>
          Aucun bien onboardé — cliquez sur « Ajouter un bien » pour démarrer.
        </p>
      ) : null}
    </div>
  );
}

// ---------- Vue : Documents (séjours DÉJÀ FUSIONNÉS) ----------

/**
 * v4.125 — chaque carte regroupe un SÉJOUR (check-in + check-out liés)
 * et propose en action principale le PDF FUSIONNÉ (pages ENTRÉE puis
 * SORTIE). Les documents orphelins (créés avant le circuit « séjour »
 * ou sans lien) gardent leur PDF individuel — plus jamais l’erreur
 * « Inspection introuvable » sur un document sans paire.
 */
function DocumentsView({ inspections }: { inspections: InspectionRow[] }) {
  const [query, setQuery] = useState('');

  const groups = useMemo(() => {
    const done = inspections.filter((i) => i.status === 'COMPLETED');
    const exits = done.filter((d) => d.type === 'SORTIE');
    const exitByEntry = new Map<string, InspectionRow>();
    for (const e of exits) {
      if (e.linkedInspectionId) exitByEntry.set(e.linkedInspectionId, e);
    }
    const entries = done.filter((d) => d.type === 'ENTREE');
    const usedExits = new Set(exitByEntry.values());
    const stays = entries.map((entry) => ({
      entry,
      exit: exitByEntry.get(entry.id) ?? null,
    }));
    const orphans = exits.filter((e) => !usedExits.has(e));
    return { stays, orphans };
  }, [inspections]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return groups;
    const hit = (...vals: (string | null)[]) => vals.some((v) => (v ?? '').toLowerCase().includes(q));
    return {
      stays: groups.stays.filter((s) =>
        hit(s.entry.propertyName, s.entry.guestName, s.entry.propertyAddress),
      ),
      orphans: groups.orphans.filter((o) =>
        hit(o.propertyName, o.guestName, o.propertyAddress),
      ),
    };
  }, [groups, query]);

  const total = filtered.stays.length + filtered.orphans.length;

  // v4.127 — demande client : filtres « Tous / Complet (Entrée + Sortie) / En attente ».
  const [docFilter, setDocFilter] = useState<'tous' | 'complets' | 'attente'>('tous');
  const visible = useMemo(() => {
    if (docFilter === 'complets') {
      return {
        stays: filtered.stays.filter((s) => s.entry.status === 'COMPLETED' && s.exit?.status === 'COMPLETED'),
        orphans: [] as InspectionRow[],
      };
    }
    if (docFilter === 'attente') {
      return {
        stays: filtered.stays.filter((s) => !(s.entry.status === 'COMPLETED' && s.exit?.status === 'COMPLETED')),
        orphans: filtered.orphans,
      };
    }
    return filtered;
  }, [filtered, docFilter]);

  const visibleTotal = visible.stays.length + visible.orphans.length;

  return (
    <Card>
      <CardHead
        title="Documents générés"
        sub={`${visibleTotal} sur ${total} séjour(s) — le PDF regroupe entrée + sortie`}
      />
      {/* ── Recherche ── */}
      <div className="relative mt-3">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2"
          style={{ color: C.muted }}
          aria-hidden="true"
        />
        <Input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Rechercher un logement, un invité…"
          aria-label="Rechercher dans les documents"
          className="h-11 pl-9"
        />
      </div>
      {/* ── Filtres (demande client) ── */}
      <div className="mt-2.5 flex flex-wrap gap-1.5" role="group" aria-label="Filtrer les documents">
        {(
          [
            ['tous', 'Tous'],
            ['complets', 'Complet (Entrée + Sortie)'],
            ['attente', 'En attente'],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            aria-pressed={docFilter === key}
            onClick={() => setDocFilter(key)}
            className={cn(
              'min-h-[36px] rounded-full px-3.5 text-xs font-bold transition-colors',
              docFilter === key ? 'text-white' : 'border hover:bg-[#F4F7FD]',
            )}
            style={
              docFilter === key
                ? { background: C.blueDeep, borderColor: C.blueDeep }
                : { borderColor: C.line, color: C.ink }
            }
          >
            {label}
          </button>
        ))}
      </div>

      {visibleTotal === 0 ? (
        <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
          Aucun document dans ce filtre.
        </p>
      ) : (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {/* ── Séjours (check-in + check-out liés) ── */}
          {visible.stays.map(({ entry, exit }) => {
            const bothDone = entry.status === 'COMPLETED' && exit?.status === 'COMPLETED';
            const sha = exit?.sha256Hash ?? entry.sha256Hash ?? null;
            const period = exit
              ? `${formatFrDateTime(entry.scheduledDate).split(' à')[0]} → ${formatFrDateTime(exit.scheduledDate).split(' à')[0]}`
              : formatFrDateTime(entry.scheduledDate).split(' à')[0];
            return (
              <div
                key={entry.id}
                className="flex flex-col justify-between gap-3 rounded-xl border p-3.5"
                style={{ borderColor: C.line }}
              >
                <div className="min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex min-w-0 items-center gap-2">
                      <FileText className="h-4 w-4 shrink-0" style={{ color: C.blueDeep }} aria-hidden="true" />
                      <p className="truncate text-sm font-bold" style={{ color: C.ink }}>
                        {entry.propertyName}
                      </p>
                    </div>
                    {bothDone ? (
                      /* v4.127 — demande client : badge « Fusionné » illisible
                         → « Complet (Entrée + Sortie) » + tooltip explicite. */
                      <UITooltipProvider delayDuration={150}>
                        <UITooltip>
                          <UITooltipTrigger asChild>
                            <span
                              className="inline-flex shrink-0 cursor-help items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                              style={{ background: '#DFF5EA', color: '#0E7A52' }}
                            >
                              Complet (Entrée + Sortie)
                            </span>
                          </UITooltipTrigger>
                          <UITooltipContent>
                            <p>PDF combiné (entrée + sortie)</p>
                          </UITooltipContent>
                        </UITooltip>
                      </UITooltipProvider>
                    ) : (
                      <span
                        className="inline-flex shrink-0 items-center rounded-full px-2.5 py-0.5 text-[10px] font-bold"
                        style={{ background: '#FDF3DC', color: '#9A6B08' }}
                      >
                        En attente du check-out
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 pl-6 text-[11px]" style={{ color: C.muted }}>
                    Invité : {entry.guestName} · {period}
                  </p>
                  <div className="mt-1 flex flex-wrap gap-1.5 pl-6">
                    <TypePill type="ENTREE" />
                    <StatusPill status={entry.status} />
                    {exit ? (
                      <>
                        <TypePill type="SORTIE" />
                        <StatusPill status={exit.status} />
                      </>
                    ) : null}
                  </div>
                  {bothDone && sha ? (
                    <p className="mt-1 truncate pl-6 text-[10px]" style={{ color: C.muted }} title={sha}>
                      SHA-256 : {sha.slice(0, 18)}…
                    </p>
                  ) : null}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {bothDone ? (
                    <button
                      type="button"
                      onClick={() => {
                        void downloadMergedPdf(entry.id);
                      }}
                      className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-xs font-bold text-white transition-opacity hover:opacity-90"
                      style={{ background: C.violet }}
                      aria-label={`Télécharger le PDF fusionné du séjour ${entry.propertyName}`}
                    >
                      <FileDown className="h-3.5 w-3.5" /> PDF fusionné
                    </button>
                  ) : null}
                  <a
                    href={`/api/inspection/pdf/${entry.publicToken}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
                    style={{ borderColor: C.line, color: C.ink }}
                  >
                    <FileDown className="h-3.5 w-3.5" /> PDF entrée
                  </a>
                  {exit ? (
                    <a
                      href={`/api/inspection/pdf/${exit.publicToken}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
                      style={{ borderColor: C.line, color: C.ink }}
                    >
                      <FileDown className="h-3.5 w-3.5" /> PDF sortie
                    </a>
                  ) : null}
                </div>
              </div>
            );
          })}
          {/* ── Documents orphelins (créés hors circuit « séjour ») ── */}
          {visible.orphans.map((d) => (
            <div
              key={d.id}
              className="flex items-center justify-between gap-3 rounded-xl border p-3.5"
              style={{ borderColor: C.line }}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 shrink-0" style={{ color: C.blueDeep }} aria-hidden="true" />
                  <p className="truncate text-sm font-bold" style={{ color: C.ink }}>
                    {d.propertyName}
                  </p>
                </div>
                <p className="mt-0.5 pl-6 text-[11px]" style={{ color: C.muted }}>
                  {d.type === 'ENTREE' ? "Attestation d'entrée" : 'Rapport de sortie'} · {d.guestName} ·{' '}
                  {formatFrDateTime(d.completedAt ?? d.createdAt)}
                </p>
                {d.sha256Hash ? (
                  <p className="mt-0.5 truncate pl-6 text-[10px]" style={{ color: C.muted }} title={d.sha256Hash}>
                    SHA-256 : {d.sha256Hash.slice(0, 18)}…
                  </p>
                ) : null}
              </div>
              <a
                href={`/api/inspection/pdf/${d.publicToken}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
                style={{ borderColor: C.line, color: C.ink }}
              >
                <FileDown className="h-3.5 w-3.5" /> PDF
              </a>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

// ---------- Vue : Abonnement ----------

function AbonnementView({ subscription }: { subscription: { status: string; plan: string; endDate: string } }) {
  const active = subscription.status === 'active';
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHead title="Mon abonnement" sub="Offre États des Lieux" />
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Formule
            </span>
            <span className="text-sm font-black" style={{ color: C.ink }}>
              299 € / an — PDF illimités
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Statut
            </span>
            <StatusPill status={active ? 'COMPLETED' : 'CANCELLED'} />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Expire le
            </span>
            <span className="text-sm font-bold" style={{ color: C.ink }}>
              {formatFrDateTime(subscription.endDate)}
            </span>
          </div>
        </div>
      </Card>
      <Card className="flex flex-col justify-between">
        <div>
          <CardHead title={active ? 'Tout est en ordre' : 'Renouvellement requis'} sub="Gestion de la souscription" />
          <p className="mt-3 text-sm leading-relaxed" style={{ color: C.muted }}>
            {active
              ? 'Votre offre est active : créez autant de séjours et de documents que nécessaire pendant toute la durée de votre abonnement.'
              : 'Votre abonnement a expiré. Renouvelez-le pour créer de nouveaux séjours — vos documents restent consultables.'}
          </p>
        </div>
        {!active ? (
          <Link
            href="/edl/abonnement"
            className="mt-4 inline-flex min-h-[44px] items-center justify-center rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            Renouveler — 299 € / an
          </Link>
        ) : null}
      </Card>
    </div>
  );
}

// ---------- Dialog : créer un nouveau séjour ----------

function StayDialog({
  open,
  onOpenChange,
  biens,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  biens: BienRow[];
  onCreated: () => void;
}) {
  const [propertyId, setPropertyId] = useState<string>('libre');
  const [propertyName, setPropertyName] = useState('');
  const [propertyAddress, setPropertyAddress] = useState('');
  const [city, setCity] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [entryDate, setEntryDate] = useState('');
  const [exitDate, setExitDate] = useState('');
  const [busy, setBusy] = useState(false);

  // Valeurs par défaut : entrée demain 10:00, sortie dans 3 jours 10:00.
  useEffect(() => {
    if (!open) return;
    const base = new Date();
    base.setDate(base.getDate() + 1);
    base.setHours(10, 0, 0, 0);
    setEntryDate((v) => v || toLocal(base));
    const out = new Date(base);
    out.setDate(out.getDate() + 3);
    setExitDate((v) => v || toLocal(out));
  }, [open]);

  const bien = biens.find((b) => b.id === propertyId);

  const submit = async () => {
    if (busy) return;
    const usingBien = propertyId !== 'libre' && !!bien;
    if (!usingBien && propertyName.trim().length < 1) return toast.error('Le nom du logement est requis.');
    if (!usingBien && propertyAddress.trim().length < 1) return toast.error("L'adresse du logement est requise.");
    if (guestName.trim().length < 1) return toast.error("Le nom de l'invité est requis.");
    if (!entryDate || !exitDate) return toast.error('Les dates d’entrée et de sortie sont requises.');
    if (new Date(exitDate) <= new Date(entryDate)) {
      return toast.error('La date de sortie doit être postérieure à la date d’entrée.');
    }

    setBusy(true);
    try {
      const res = await fetch('/api/inspection/stay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: usingBien ? bien!.id : undefined,
          propertyName: usingBien ? undefined : propertyName.trim(),
          propertyAddress: usingBien ? undefined : propertyAddress.trim(),
          city: city.trim() || undefined,
          guestName: guestName.trim(),
          guestEmail: guestEmail.trim() || undefined,
          guestPhone: guestPhone.trim() || undefined,
          entryDate: new Date(entryDate).toISOString(),
          exitDate: new Date(exitDate).toISOString(),
        }),
      });
      const json = (await res.json().catch(() => null)) as
        | { entry?: { shareUrl: string }; error?: string; message?: string }
        | null;
      if (!res.ok || !json?.entry) {
        toast.error(json?.message ?? json?.error ?? 'Création impossible. Réessayez.');
        return;
      }
      try {
        await navigator.clipboard.writeText(json.entry.shareUrl);
        toast.success('Séjour créé — check-in + check-out liés. Lien du check-in copié.');
      } catch {
        toast.success('Séjour créé — check-in + check-out liés.');
      }
      onOpenChange(false);
      setGuestName('');
      setGuestEmail('');
      setGuestPhone('');
      onCreated();
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-xl sm:max-w-xl" style={{ borderColor: C.line }}>
        <DialogHeader>
          <DialogTitle className="text-lg font-black" style={{ color: C.ink }}>
            Créer un nouveau séjour
          </DialogTitle>
          <DialogDescription className="text-xs" style={{ color: C.muted }}>
            Le check-in (entrée) et le check-out (sortie) sont créés ensemble et liés — le PDF fusionné
            « ENTRÉE + SORTIE » sera envoyé automatiquement à l&apos;hôte et à l&apos;invité à la fin du check-out.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3.5">
          <div className="space-y-1.5">
            <Label className="text-xs" style={{ color: C.ink }}>
              Bien concerné
            </Label>
            <Select value={propertyId} onValueChange={setPropertyId}>
              <SelectTrigger className="h-11 w-full" aria-label="Choisir le bien">
                <SelectValue placeholder="Choisir un bien" />
              </SelectTrigger>
              <SelectContent>
                {biens.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.propertyName}
                  </SelectItem>
                ))}
                <SelectItem value="libre">Autre logement (saisie libre)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {!bien ? (
            <>
              <div className="space-y-1.5">
                <Label htmlFor="stay-name" className="text-xs" style={{ color: C.ink }}>
                  Nom du logement
                </Label>
                <Input
                  id="stay-name"
                  value={propertyName}
                  onChange={(e) => setPropertyName(e.target.value)}
                  placeholder="ex. Villa Azur — Appartement 2"
                  maxLength={160}
                  className="h-11"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="stay-address" className="text-xs" style={{ color: C.ink }}>
                  Adresse
                </Label>
                <Input
                  id="stay-address"
                  value={propertyAddress}
                  onChange={(e) => setPropertyAddress(e.target.value)}
                  placeholder="ex. 12 rue des Palmiers"
                  maxLength={300}
                  autoComplete="street-address"
                  className="h-11"
                />
              </div>
            </>
          ) : (
            <p className="rounded-lg border px-3 py-2 text-xs" style={{ borderColor: C.line, color: C.muted }}>
              {bien.propertyName} — {bien.propertyAddress}
            </p>
          )}

          <div className="grid gap-3.5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="stay-guest" className="text-xs" style={{ color: C.ink }}>
                Invité (nom)
              </Label>
              <Input
                id="stay-guest"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="ex. Thomas Lambert"
                maxLength={120}
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-email" className="text-xs" style={{ color: C.ink }}>
                Email invité <span className="font-normal">(pour le PDF final)</span>
              </Label>
              <Input
                id="stay-email"
                type="email"
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                placeholder="ex. thomas@exemple.fr"
                autoComplete="email"
                className="h-11"
              />
            </div>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="stay-phone" className="text-xs" style={{ color: C.ink }}>
                Téléphone <span className="font-normal">(opt.)</span>
              </Label>
              <Input
                id="stay-phone"
                type="tel"
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder="+33 6…"
                autoComplete="tel"
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-entry" className="text-xs" style={{ color: C.ink }}>
                Check-in (entrée)
              </Label>
              <Input
                id="stay-entry"
                type="datetime-local"
                value={entryDate}
                onChange={(e) => setEntryDate(e.target.value)}
                className="h-11 [color-scheme:light]"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-exit" className="text-xs" style={{ color: C.ink }}>
                Check-out (sortie)
              </Label>
              <Input
                id="stay-exit"
                type="datetime-local"
                value={exitDate}
                onChange={(e) => setExitDate(e.target.value)}
                className="h-11 [color-scheme:light]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="stay-city" className="text-xs" style={{ color: C.ink }}>
              Ville <span className="font-normal">(mention « Fait à … » — optionnel)</span>
            </Label>
            <Input
              id="stay-city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="ex. Dakar"
              maxLength={120}
              className="h-11"
            />
          </div>

          <Button
            type="button"
            disabled={busy}
            onClick={() => {
              void submit();
            }}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            {busy ? 'Création…' : 'Créer le séjour (check-in + check-out)'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Formate une Date pour un input datetime-local. */
function toLocal(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
