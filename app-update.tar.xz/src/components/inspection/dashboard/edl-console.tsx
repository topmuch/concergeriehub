'use client';

// =============================================================
// EDL CONSOLE v2 — « BUSINESS DASHBOARD » (design imposé par le
// client : référence visuelle type infographic business).
//
// Structure fidèle à l'image fournie :
//   • Sidebar bleue verticale (icônes blanches, carte abonnement)
//   • Rangée de 5 KPI : 4 donuts de progression + 1 jauge
//   • Area chart 14 jours (dégradé lavande)
//   • 4 cartes à vagues colorées (bleu / rouge / orange / violet)
//   • Donut de répartition avec total central
//   • Barres empilées (ENTRÉE vs SORTIE, 6 derniers mois)
//   • Timeline horizontale des dernières activités
//   • Tableau des séjours récents + vue complète « Séjours »
//
// Palette image : bleu #2E7CD6, lavande #A5A6F6, violet #8B5CF6,
// rouge #E8425A, orange #F2764C, rose #E9426E, jaune #F5A623,
// teal #1B7B78 — CTA en rouge marque #C21F26 texte blanc (règle).
//
// Circuit v2 : le gate one-shot (1re visite → /payment/success →
// wizard) est géré côté serveur (page.tsx). Ici, l'utilisateur est
// TOUJOURS déjà onboardé : l'accueil = console « Créer un séjour ».
// =============================================================
import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { toast } from 'sonner';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Building2,
  CalendarDays,
  Copy,
  CreditCard,
  FileDown,
  FileText,
  LayoutDashboard,
  Menu,
  Plus,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { ShieldManager } from '../shield/shield-manager';
import {
  formatFrDateTime,
  mailtoLink,
  whatsappLink,
  type InspectionListResponse,
  type InspectionRow,
} from './inspection-types';

// ---------- Palette (codes couleur de l'image client) ----------
const C = {
  sidebarTop: '#2E7CD6',
  sidebarBottom: '#2459A8',
  ring: '#E5EAF5',
  blue: '#3E8EDE',
  blueDeep: '#2464C2',
  lavande: '#A5A6F6',
  violet: '#8B5CF6',
  red: '#E8425A',
  orange: '#F2764C',
  rose: '#E9426E',
  jaune: '#F5A623',
  teal: '#1B7B78',
  cta: '#C21F26',
  ink: '#1E2A3B',
  muted: '#6B7A93',
  line: '#E3E9F4',
} as const;

type ViewKey = 'dashboard' | 'sejours' | 'biens' | 'documents' | 'bouclier' | 'abonnement';

interface SessionUser {
  id: string;
  name: string | null;
  email: string | null;
}

interface BienRow {
  id: string;
  propertyName: string;
  propertyAddress: string;
  nbChambres: number;
  pieces: string;
  equipementsCoches: string;
  onboardingRef: string;
  onboardedAt: string;
}

const NAV: { key: ViewKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: 'dashboard', label: 'Tableau de bord', icon: LayoutDashboard },
  { key: 'sejours', label: 'Séjours', icon: CalendarDays },
  { key: 'biens', label: 'Mes biens', icon: Building2 },
  { key: 'documents', label: 'Documents', icon: FileText },
  { key: 'bouclier', label: 'Bouclier', icon: ShieldCheck },
  { key: 'abonnement', label: 'Abonnement', icon: CreditCard },
];

const VIEW_TITLES: Record<ViewKey, string> = {
  dashboard: 'Tableau de bord',
  sejours: 'Séjours',
  biens: 'Mes biens',
  documents: 'Documents',
  bouclier: 'Bouclier automatisé',
  abonnement: 'Abonnement',
};

// ---------- Petits composants de style (fidèles à l'image) ----------

/** Titre de carte : « Statistic Graph » bleu + sous-titre gris. */
function CardHead({ title, sub, right }: { title: string; sub?: string; right?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-2">
      <div className="min-w-0">
        <p className="text-sm font-bold" style={{ color: C.blueDeep }}>
          {title}
        </p>
        {sub ? (
          <p className="text-[11px]" style={{ color: C.muted }}>
            {sub}
          </p>
        ) : null}
      </div>
      {right}
    </div>
  );
}

/** Carte blanche de base. */
function Card({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <section
      className={cn('rounded-xl border bg-white p-4 shadow-[0_1px_3px_rgba(30,42,59,0.06)] sm:p-5', className)}
      style={{ borderColor: C.line }}
    >
      {children}
    </section>
  );
}

/** Donut de progression (pourcent au centre) — style image. */
function ProgressDonut({ value, color, size = 92 }: { value: number; color: string; size?: number }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  const data = [
    { name: 'fait', value: v },
    { name: 'reste', value: 100 - v },
  ];
  return (
    <div className="relative" style={{ width: size, height: size }} aria-hidden="true">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            innerRadius="74%"
            outerRadius="100%"
            startAngle={90}
            endAngle={-270}
            strokeWidth={0}
            isAnimationActive={false}
          >
            <Cell fill={color} />
            <Cell fill={C.ring} />
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <span
        className="absolute inset-0 flex items-center justify-center text-sm font-black"
        style={{ color: C.ink }}
      >
        {v}%
      </span>
    </div>
  );
}

/** Carte à vague colorée avec grand chiffre — style image (4 tuiles). */
function WaveCard({ color, value, label }: { color: string; value: number | string; label: string }) {
  return (
    <div
      className="relative flex h-full min-h-[118px] flex-col justify-between overflow-hidden rounded-xl p-3.5 text-white shadow-sm"
      style={{ background: color }}
    >
      <span className="text-2xl font-black leading-none sm:text-[26px]">{value}</span>
      <span className="text-[11px] font-semibold uppercase tracking-wide opacity-90">{label}</span>
      {/* Vague décorative en bas (comme l'image) */}
      <svg
        aria-hidden="true"
        viewBox="0 0 220 40"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-9 w-full"
      >
        <path
          d="M0 26 C 30 8, 60 8, 90 22 S 150 40, 185 26 S 210 14, 220 18 L 220 40 L 0 40 Z"
          fill="rgba(255,255,255,0.22)"
        />
        <path
          d="M0 32 C 40 18, 80 18, 120 30 S 190 44, 220 30 L 220 40 L 0 40 Z"
          fill="rgba(255,255,255,0.16)"
        />
      </svg>
    </div>
  );
}

/** Pastille de statut (pill fine). */
function StatusPill({ status }: { status: string }) {
  const meta: Record<string, { label: string; bg: string; fg: string }> = {
    PENDING: { label: 'En attente', bg: '#FDF3DC', fg: '#9A6B08' },
    IN_PROGRESS: { label: 'En cours', bg: '#E2F1FB', fg: '#1D6FB8' },
    COMPLETED: { label: 'Terminé', bg: '#DFF5EA', fg: '#0E7A52' },
    CANCELLED: { label: 'Annulé', bg: '#EEF1F6', fg: C.muted },
  };
  const m = meta[status] ?? meta.PENDING;
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
      style={{ background: m.bg, color: m.fg }}
    >
      {m.label}
    </span>
  );
}

/** Badge de type : ENTRÉE bleu / SORTIE violet. */
function TypePill({ type }: { type: string }) {
  const isEntree = type === 'ENTREE';
  return (
    <span
      className="inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold"
      style={{
        background: isEntree ? '#E2F1FB' : '#EFEAFE',
        color: isEntree ? '#1D6FB8' : '#6D3FD1',
      }}
    >
      {isEntree ? 'Entrée' : 'Sortie'}
    </span>
  );
}

// ---------- Console ----------

export function EdlConsole({ sessionUser }: { sessionUser: SessionUser }) {
  const [view, setView] = useState<ViewKey>('dashboard');
  const [navOpen, setNavOpen] = useState(false); // drawer mobile
  const [payload, setPayload] = useState<InspectionListResponse | null>(null);
  const [biens, setBiens] = useState<BienRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [stayOpen, setStayOpen] = useState(false);
  const [deleteArmedId, setDeleteArmedId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r1, r2] = await Promise.all([
        fetch('/api/inspection/list', { cache: 'no-store' }),
        fetch('/api/inspection/properties', { cache: 'no-store' }),
      ]);
      const j1 = (await r1.json().catch(() => null)) as InspectionListResponse | null;
      const j2 = (await r2.json().catch(() => null)) as { properties?: BienRow[] } | null;
      if (!r1.ok || !j1?.inspections) {
        toast.error('Chargement impossible. Réessayez.');
        return;
      }
      setPayload(j1);
      setBiens(Array.isArray(j2?.properties) ? j2.properties : []);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const inspections = useMemo(() => payload?.inspections ?? [], [payload]);
  const subscription = payload?.subscription ?? null;

  // ---------- Agrégats (séjours = paires ENTREE + SORTIE liée) ----------
  const stats = useMemo(() => {
    const entries = inspections.filter((i) => i.type === 'ENTREE');
    const exits = inspections.filter((i) => i.type === 'SORTIE');
    const exitByEntry = new Map<string, InspectionRow>();
    for (const e of exits) {
      if (e.linkedInspectionId) exitByEntry.set(e.linkedInspectionId, e);
    }
    const stays = entries.map((entry) => ({ entry, exit: exitByEntry.get(entry.id) ?? null }));
    const entryDone = entries.filter((e) => e.status === 'COMPLETED').length;
    const exitDone = exits.filter((e) => e.status === 'COMPLETED').length;
    const sealed = inspections.filter((i) => i.sha256Hash).length;
    const fullStays = stays.filter((s) => s.entry.status === 'COMPLETED' && s.exit?.status === 'COMPLETED').length;
    const statusDist = [
      { name: 'En attente', value: inspections.filter((i) => i.status === 'PENDING').length, color: C.jaune },
      { name: 'En cours', value: inspections.filter((i) => i.status === 'IN_PROGRESS').length, color: C.blue },
      { name: 'Terminé', value: inspections.filter((i) => i.status === 'COMPLETED').length, color: C.violet },
    ].filter((d) => d.value > 0);
    const statusTotal = inspections.length;

    // Area chart : créations par jour (14 derniers jours).
    const days: { day: string; total: number }[] = [];
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      days.push({
        day: d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
        total: inspections.filter((x) => x.createdAt.slice(0, 10) === key).length,
      });
    }

    // Barres empilées : ENTRÉE vs SORTIE sur 6 mois.
    const months: { month: string; entree: number; sortie: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      months.push({
        month: d.toLocaleDateString('fr-FR', { month: 'short' }).replace('.', ''),
        entree: inspections.filter((x) => x.type === 'ENTREE' && x.createdAt.slice(0, 7) === key).length,
        sortie: inspections.filter((x) => x.type === 'SORTIE' && x.createdAt.slice(0, 7) === key).length,
      });
    }

    const timeline = inspections.slice(0, 6);
    return {
      stays,
      entryTotal: entries.length,
      entryDone,
      exitTotal: exits.length,
      exitDone,
      sealed,
      fullStays,
      statusDist,
      statusTotal,
      days,
      months,
      timeline,
      globalRate:
        entries.length + exits.length > 0
          ? ((entryDone + exitDone) / (entries.length + exits.length)) * 100
          : 0,
    };
  }, [inspections]);

  const stayActions = {
    onDelete: async (row: InspectionRow) => {
      try {
        const res = await fetch(`/api/inspection/manage/${row.id}`, { method: 'DELETE' });
        if (!res.ok) {
          toast.error('Suppression impossible.');
          return;
        }
        toast.success('État des lieux supprimé.');
        void load();
      } catch {
        toast.error('Erreur de connexion.');
      }
    },
  };

  // ---------- Rendu ----------
  const initials = (sessionUser.name ?? sessionUser.email ?? 'H')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  const expired = subscription && subscription.status !== 'active';

  return (
    <div className="min-h-screen" style={{ background: '#E9EDF6' }}>
      {/* ══ Sidebar desktop ══ */}
      <aside
        className="fixed inset-y-0 left-0 z-40 hidden w-[264px] flex-col justify-between text-white md:flex"
        style={{ background: `linear-gradient(180deg, ${C.sidebarTop} 0%, ${C.sidebarBottom} 100%)` }}
        aria-label="Navigation principale"
      >
        <div>
          <div className="flex items-center gap-3 px-5 pt-6 pb-7">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/15 text-lg font-black backdrop-blur">
              R
            </span>
            <div className="leading-tight">
              <p className="text-sm font-black tracking-wide">RoomScan</p>
              <p className="text-[11px] font-medium text-white/70">États des Lieux</p>
            </div>
          </div>
          <nav className="space-y-1 px-3">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = view === item.key;
              return (
                <button
                  key={item.key}
                  type="button"
                  onClick={() => {
                    setView(item.key);
                    setNavOpen(false);
                  }}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'flex min-h-[44px] w-full items-center gap-3 rounded-lg px-4 text-sm font-semibold transition-colors',
                    active ? 'bg-white text-[#2459A8] shadow-sm' : 'text-white/85 hover:bg-white/10 hover:text-white',
                  )}
                >
                  <Icon className="h-4.5 w-4.5 h-[18px] w-[18px]" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
        {/* Carte abonnement (bas de sidebar) */}
        <div className="px-4 pb-6">
          <div className="rounded-xl bg-white/12 p-4 backdrop-blur">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/70">Offre active</p>
            <p className="mt-1 text-sm font-black">299 € / an</p>
            <p className="mt-0.5 text-[11px] text-white/70">
              {subscription ? `Jusqu'au ${formatFrDateTime(subscription.endDate).split(' à')[0]}` : '—'}
            </p>
            <button
              type="button"
              onClick={() => setView('abonnement')}
              className="mt-3 w-full rounded-lg bg-white/20 py-2 text-xs font-bold transition-colors hover:bg-white/30"
            >
              Gérer l&apos;abonnement
            </button>
          </div>
        </div>
      </aside>

      {/* ══ Drawer mobile ══ */}
      {navOpen ? (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true" aria-label="Menu">
          <button
            type="button"
            aria-label="Fermer le menu"
            className="absolute inset-0 bg-black/40"
            onClick={() => setNavOpen(false)}
          />
          <aside
            className="absolute inset-y-0 left-0 flex w-[264px] flex-col justify-between text-white shadow-2xl"
            style={{ background: `linear-gradient(180deg, ${C.sidebarTop} 0%, ${C.sidebarBottom} 100%)` }}
          >
            <div>
              <div className="flex items-center justify-between px-5 pt-6 pb-7">
                <p className="text-sm font-black tracking-wide">RoomScan — États des Lieux</p>
                <button type="button" onClick={() => setNavOpen(false)} aria-label="Fermer" className="p-1">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <nav className="space-y-1 px-3">
                {NAV.map((item) => {
                  const Icon = item.icon;
                  const active = view === item.key;
                  return (
                    <button
                      key={item.key}
                      type="button"
                      onClick={() => {
                        setView(item.key);
                        setNavOpen(false);
                      }}
                      className={cn(
                        'flex min-h-[44px] w-full items-center gap-3 rounded-lg px-4 text-sm font-semibold',
                        active ? 'bg-white text-[#2459A8]' : 'text-white/85 hover:bg-white/10',
                      )}
                    >
                      <Icon className="h-[18px] w-[18px]" />
                      {item.label}
                    </button>
                  );
                })}
              </nav>
            </div>
            <div className="px-4 pb-6 text-xs text-white/80">
              <p className="font-black">299 € / an</p>
              <p>{subscription ? `Actif jusqu'au ${formatFrDateTime(subscription.endDate).split(' à')[0]}` : '—'}</p>
            </div>
          </aside>
        </div>
      ) : null}

      {/* ══ Zone principale ══ */}
      <div className="md:pl-[264px]">
        {/* Header */}
        <header
          className="sticky top-0 z-30 border-b bg-white/95 backdrop-blur"
          style={{ borderColor: C.line }}
        >
          <div className="flex items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setNavOpen(true)}
                aria-label="Ouvrir le menu"
                className="rounded-lg p-2 md:hidden"
                style={{ color: C.ink }}
              >
                <Menu className="h-5 w-5" />
              </button>
              <h1 className="truncate text-lg font-black sm:text-xl" style={{ color: C.ink }}>
                {VIEW_TITLES[view]}
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <Button
                type="button"
                onClick={() => setStayOpen(true)}
                className="hidden h-10 items-center gap-2 rounded-lg px-4 text-sm font-bold text-white shadow-sm hover:brightness-110 sm:inline-flex"
                style={{ background: C.cta }}
                aria-label="Créer un nouveau séjour"
              >
                <Plus className="h-4 w-4" />
                Créer un nouveau séjour
              </Button>
              <span
                className="flex h-9 w-9 items-center justify-center rounded-full text-xs font-black text-white"
                style={{ background: C.blueDeep }}
                aria-hidden="true"
              >
                {initials}
              </span>
            </div>
          </div>
          {expired ? (
            <div className="px-4 pb-3 sm:px-6">
              <p
                className="rounded-lg border px-3 py-2 text-xs font-semibold"
                style={{ borderColor: '#F2DFAE', background: '#FDF3DC', color: '#9A6B08' }}
              >
                Votre abonnement a expiré — renouvelez-le sur{' '}
                <Link href="/edl/abonnement" className="underline">
                  la page d&apos;abonnement
                </Link>{' '}
                pour continuer à créer des séjours.
              </p>
            </div>
          ) : null}
        </header>

        {/* Bouton créer (mobile, toujours visible) */}
        <div className="px-4 pt-4 sm:hidden">
          <Button
            type="button"
            onClick={() => setStayOpen(true)}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            <Plus className="mr-1 h-4 w-4" /> Créer un nouveau séjour
          </Button>
        </div>

        <main className="mx-auto w-full max-w-[1400px] overflow-x-hidden px-4 py-4 sm:px-6 sm:py-6">
          {loading ? (
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-28 rounded-xl" />
                ))}
              </div>
              <Skeleton className="h-72 rounded-xl" />
            </div>
          ) : (
            <>
              {view === 'dashboard' ? (
                <DashboardView
                  stats={stats}
                  inspections={inspections}
                  onOpenStay={() => setStayOpen(true)}
                  onDelete={stayActions.onDelete}
                  deleteArmedId={deleteArmedId}
                  setDeleteArmedId={setDeleteArmedId}
                  setView={setView}
                />
              ) : null}
              {view === 'sejours' ? (
                <SejoursView
                  inspections={inspections}
                  onDelete={stayActions.onDelete}
                  deleteArmedId={deleteArmedId}
                  setDeleteArmedId={setDeleteArmedId}
                  onOpenStay={() => setStayOpen(true)}
                />
              ) : null}
              {view === 'biens' ? <BiensView biens={biens} /> : null}
              {view === 'documents' ? <DocumentsView inspections={inspections} /> : null}
              {view === 'bouclier' ? <BouclierView sessionUser={sessionUser} /> : null}
              {view === 'abonnement' && subscription ? (
                <AbonnementView subscription={subscription} />
              ) : null}
            </>
          )}
        </main>
      </div>

      {/* ══ Dialog créer un séjour ══ */}
      <StayDialog
        open={stayOpen}
        onOpenChange={setStayOpen}
        biens={biens ?? []}
        onCreated={() => {
          void load();
          setView('sejours');
        }}
      />
    </div>
  );
}

// ---------- Vue : Tableau de bord ----------

function DashboardView({
  stats,
  inspections,
  onOpenStay,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
  setView,
}: {
  stats: {
    stays: { entry: InspectionRow; exit: InspectionRow | null }[];
    entryTotal: number;
    entryDone: number;
    exitTotal: number;
    exitDone: number;
    sealed: number;
    fullStays: number;
    statusDist: { name: string; value: number; color: string }[];
    statusTotal: number;
    days: { day: string; total: number }[];
    months: { month: string; entree: number; sortie: number }[];
    timeline: InspectionRow[];
    globalRate: number;
  };
  inspections: InspectionRow[];
  onOpenStay: () => void;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
  setView: (v: ViewKey) => void;
}) {
  const kpis = [
    { n: '01', title: 'Check-ins complétés', sub: 'Entrées terminées', value: stats.entryTotal ? (stats.entryDone / stats.entryTotal) * 100 : 0, color: C.blueDeep },
    { n: '02', title: 'Check-outs complétés', sub: 'Sorties terminées', value: stats.exitTotal ? (stats.exitDone / stats.exitTotal) * 100 : 0, color: C.violet },
    { n: '03', title: 'Documents scellés', sub: 'Empreinte SHA-256', value: inspections.length ? (stats.sealed / inspections.length) * 100 : 0, color: C.teal },
    { n: '04', title: 'Séjours complets', sub: 'Entrée + sortie', value: stats.stays.length ? (stats.fullStays / stats.stays.length) * 100 : 0, color: C.rose },
  ];

  const recent = inspections.slice(0, 5);

  return (
    <div className="grid gap-4">
      {/* ── Rangée KPI : 4 donuts + jauge ── */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {kpis.map((k) => (
          <Card key={k.n} className="flex items-center gap-3">
            <ProgressDonut value={k.value} color={k.color} />
            <div className="min-w-0">
              <p className="text-xl font-black leading-none" style={{ color: C.ink }}>
                {k.n}
              </p>
              <p className="mt-1 truncate text-xs font-bold" style={{ color: C.blueDeep }}>
                {k.title}
              </p>
              <p className="text-[11px]" style={{ color: C.muted }}>
                {k.sub}
              </p>
            </div>
          </Card>
        ))}
        <Card className="col-span-2 flex items-center gap-3 lg:col-span-1">
          {/* Jauge demi-cercle — taux global */}
          <div className="relative h-[92px] w-[120px] shrink-0" aria-hidden="true">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={[
                    { value: Math.max(0, Math.min(100, stats.globalRate)) },
                    { value: 100 - Math.max(0, Math.min(100, stats.globalRate)) },
                  ]}
                  dataKey="value"
                  innerRadius="62%"
                  outerRadius="100%"
                  startAngle={180}
                  endAngle={0}
                  strokeWidth={0}
                  isAnimationActive={false}
                >
                  <Cell fill={stats.globalRate >= 80 ? C.teal : stats.globalRate >= 40 ? C.blueDeep : C.orange} />
                  <Cell fill={C.ring} />
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <span className="absolute inset-x-0 bottom-0 text-center text-sm font-black" style={{ color: C.ink }}>
              {Math.round(stats.globalRate)}%
            </span>
          </div>
          <div className="min-w-0">
            <p className="text-xs font-bold" style={{ color: C.blueDeep }}>
              Progression globale
            </p>
            <p className="text-[11px]" style={{ color: C.muted }}>
              Tous états des lieux
            </p>
          </div>
        </Card>
      </div>

      {/* ── Area chart + cartes vagues + donut ── */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-6">
          <CardHead title="Activité — créations" sub="14 derniers jours" />
          <div className="mt-3 h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.days} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradLavande" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={C.lavande} stopOpacity={0.85} />
                    <stop offset="100%" stopColor={C.lavande} stopOpacity={0.08} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={C.line} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }}
                  formatter={(v) => [`${v} document(s)`, 'Créés']}
                />
                <Area type="monotone" dataKey="total" stroke={C.lavande} strokeWidth={2} fill="url(#gradLavande)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="lg:col-span-3">
          <CardHead title="Volumétrie" sub="Vue d'ensemble" />
          <div className="mt-3 grid grid-cols-2 gap-2.5">
            <WaveCard color={C.blue} value={stats.stays.length} label="Séjours" />
            <WaveCard color={C.red} value={stats.entryDone} label="Check-ins" />
            <WaveCard color={C.orange} value={stats.exitDone} label="Check-outs" />
            <WaveCard color={C.violet} value={stats.sealed} label="Documents" />
          </div>
          <button
            type="button"
            onClick={onOpenStay}
            className="mt-3 flex min-h-[44px] w-full items-center justify-center gap-2 rounded-lg text-sm font-bold text-white transition-opacity hover:opacity-90"
            style={{ background: C.cta }}
          >
            <Plus className="h-4 w-4" /> Nouveau séjour
          </button>
        </Card>

        <Card className="lg:col-span-3">
          <CardHead title="Répartition" sub="Statuts des documents" />
          <div className="relative mt-2 h-[190px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={stats.statusDist.length ? stats.statusDist : [{ name: 'Aucun', value: 1, color: C.ring }]}
                  dataKey="value"
                  innerRadius="62%"
                  outerRadius="92%"
                  strokeWidth={2}
                  stroke="#fff"
                  isAnimationActive={false}
                >
                  {(stats.statusDist.length ? stats.statusDist : [{ color: C.ring }]).map((d, i) => (
                    <Cell key={i} fill={d.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-2xl font-black" style={{ color: C.ink }}>
                {stats.statusTotal}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: C.muted }}>
                documents
              </span>
            </div>
          </div>
          <ul className="mt-2 space-y-1.5">
            {stats.statusDist.map((d) => (
              <li key={d.name} className="flex items-center gap-2 text-xs" style={{ color: C.ink }}>
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: d.color }} aria-hidden="true" />
                {d.name}
                <span className="ml-auto font-bold">{d.value}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      {/* ── Barres empilées + timeline ── */}
      <div className="grid gap-4 lg:grid-cols-12">
        <Card className="lg:col-span-7">
          <CardHead title="États des lieux par mois" sub="Entrées vs sorties — 6 derniers mois" />
          <div className="mt-3 h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.months} margin={{ top: 8, right: 8, left: -18, bottom: 0 }} barCategoryGap="28%">
                <CartesianGrid stroke={C.line} vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: C.muted }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 10, border: `1px solid ${C.line}`, fontSize: 12 }} cursor={{ fill: 'rgba(46,124,214,0.06)' }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="entree" name="Entrées" stackId="a" fill={C.blueDeep} radius={[0, 0, 0, 0]} />
                <Bar dataKey="sortie" name="Sorties" stackId="a" fill={C.lavande} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="min-w-0 overflow-hidden lg:col-span-5">
          <CardHead title="Dernières activités" sub="Chronologie des documents" />
          <div className="mt-4 overflow-x-auto pb-1">
            {stats.timeline.length === 0 ? (
              <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
                Aucune activité pour le moment.
              </p>
            ) : (
              <div className="relative flex min-w-[520px] items-start">
                {/* Ligne horizontale */}
                <span
                  aria-hidden="true"
                  className="absolute left-4 right-4 top-[38px] h-0.5"
                  style={{ background: C.line }}
                />
                {stats.timeline.map((t) => {
                  const d = new Date(t.createdAt);
                  return (
                    <div key={t.id} className="relative flex w-1/6 min-w-[86px] flex-col items-center px-1">
                      <span
                        className="rounded-full px-2 py-0.5 text-[10px] font-bold text-white"
                        style={{ background: t.type === 'ENTREE' ? C.blueDeep : C.violet }}
                      >
                        {d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}
                      </span>
                      <span
                        aria-hidden="true"
                        className="my-1.5 h-3 w-3 rounded-full border-2 border-white shadow"
                        style={{ background: t.status === 'COMPLETED' ? C.teal : C.blue }}
                      />
                      <p className="line-clamp-2 text-center text-[11px] font-semibold leading-tight" style={{ color: C.ink }}>
                        {t.propertyName}
                      </p>
                      <div className="mt-1 flex flex-col items-center gap-1">
                        <TypePill type={t.type} />
                        <StatusPill status={t.status} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
          <button
            type="button"
            onClick={() => setView('sejours')}
            className="mt-3 text-xs font-bold underline-offset-2 hover:underline"
            style={{ color: C.blueDeep }}
          >
            Voir tous les séjours →
          </button>
        </Card>
      </div>

      {/* ── Séjours récents (tableau) ── */}
      <Card>
        <CardHead title="Séjours récents" sub="5 derniers documents" />
        <RecentTable
          rows={recent}
          onDelete={onDelete}
          deleteArmedId={deleteArmedId}
          setDeleteArmedId={setDeleteArmedId}
        />
      </Card>
    </div>
  );
}

// ---------- Tableau récent (partagé) ----------

function RecentTable({
  rows,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
}: {
  rows: InspectionRow[];
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
}) {
  if (rows.length === 0) {
    return (
      <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
        Aucun état des lieux pour le moment.
      </p>
    );
  }
  return (
    <>
      {/* Desktop */}
      <div className="mt-3 hidden overflow-x-auto md:block">
        <Table>
          <TableHeader>
            <TableRow style={{ background: '#F4F7FD' }}>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Logement
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Type
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Invité
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Date visée
              </TableHead>
              <TableHead className="text-xs font-bold" style={{ color: C.blueDeep }}>
                Statut
              </TableHead>
              <TableHead className="text-right text-xs font-bold" style={{ color: C.blueDeep }}>
                Actions
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((row, i) => (
              <TableRow key={row.id} style={{ background: i % 2 ? '#F7F9FE' : '#fff' }}>
                <TableCell className="max-w-[220px]">
                  <p className="truncate text-sm font-semibold" style={{ color: C.ink }}>
                    {row.propertyName}
                  </p>
                  <p className="truncate text-[11px]" style={{ color: C.muted }}>
                    {row.propertyAddress}
                  </p>
                </TableCell>
                <TableCell>
                  <TypePill type={row.type} />
                </TableCell>
                <TableCell className="text-sm" style={{ color: C.ink }}>
                  {row.guestName}
                </TableCell>
                <TableCell className="whitespace-nowrap text-xs" style={{ color: C.muted }}>
                  {formatFrDateTime(row.scheduledDate)}
                </TableCell>
                <TableCell>
                  <StatusPill status={row.status} />
                </TableCell>
                <TableCell>
                  <RowActions row={row} onDelete={onDelete} deleteArmedId={deleteArmedId} setDeleteArmedId={setDeleteArmedId} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      {/* Mobile : cartes */}
      <div className="mt-3 space-y-3 md:hidden">
        {rows.map((row) => (
          <div key={row.id} className="rounded-xl border p-3" style={{ borderColor: C.line }}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="truncate text-sm font-bold" style={{ color: C.ink }}>
                  {row.propertyName}
                </p>
                <p className="truncate text-[11px]" style={{ color: C.muted }}>
                  {row.guestName} · {formatFrDateTime(row.scheduledDate)}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                <TypePill type={row.type} />
                <StatusPill status={row.status} />
              </div>
            </div>
            <div className="mt-2.5 flex flex-wrap gap-2">
              <RowActions row={row} onDelete={onDelete} deleteArmedId={deleteArmedId} setDeleteArmedId={setDeleteArmedId} />
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ---------- Actions d'une ligne ----------

function RowActions({
  row,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
}: {
  row: InspectionRow;
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
}) {
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(row.shareUrl);
      toast.success('Lien copié dans le presse-papier.');
    } catch {
      toast.error('Copie impossible.');
    }
  };
  const armed = deleteArmedId === row.id;

  // PDF fusionné disponible si la SORTIE du couple est complétée.
  const linkedExit =
    row.type === 'SORTIE'
      ? row
      : row.linkedInspectionId
        ? null // la sortie liée n'est pas dans cette ligne — le serveur valide
        : null;
  const mergedHref = linkedExit?.status === 'COMPLETED' || (row.type === 'SORTIE' && row.status === 'COMPLETED')
    ? `/api/inspection/merged-pdf/${row.id}`
    : null;

  return (
    <div className="flex flex-wrap items-center justify-end gap-1.5">
      <a
        href={row.shareUrl}
        target="_blank"
        rel="noreferrer"
        className="inline-flex min-h-[36px] items-center rounded-lg px-3 text-xs font-bold text-white transition-opacity hover:opacity-90"
        style={{ background: C.blueDeep }}
        aria-label={`Remplir l'état des lieux ${row.propertyName}`}
      >
        Remplir
      </a>
      <button
        type="button"
        onClick={copy}
        className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
        style={{ borderColor: C.line, color: C.ink }}
        aria-label="Copier le lien public"
      >
        <Copy className="h-3.5 w-3.5" /> Lien
      </button>
      {row.guestEmail ? (
        <a
          href={mailtoLink(row.guestEmail, row.guestName, row.shareUrl)}
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: C.line, color: C.ink }}
          aria-label="Envoyer par email"
        >
          Email
        </a>
      ) : (
        <a
          href={whatsappLink(row.guestName, row.shareUrl)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
          style={{ borderColor: C.line, color: C.ink }}
          aria-label="Partager via WhatsApp"
        >
          WhatsApp
        </a>
      )}
      <a
        href={`/api/inspection/pdf/${row.publicToken}`}
        target="_blank"
        rel="noreferrer"
        className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
        style={{ borderColor: C.line, color: C.ink }}
        aria-label="Ouvrir le PDF"
      >
        <FileDown className="h-3.5 w-3.5" /> PDF
      </a>
      {mergedHref ? (
        <a
          href={mergedHref}
          className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-2.5 text-xs font-bold text-white transition-opacity hover:opacity-90"
          style={{ background: C.violet }}
          aria-label="Télécharger le PDF fusionné entrée + sortie"
        >
          <FileDown className="h-3.5 w-3.5" /> Fusionné
        </a>
      ) : null}
      {armed ? (
        <button
          type="button"
          onClick={() => {
            void onDelete(row);
            setDeleteArmedId(null);
          }}
          className="inline-flex min-h-[36px] items-center rounded-lg px-2.5 text-xs font-bold text-white"
          style={{ background: C.red }}
          aria-label="Confirmer la suppression"
        >
          Confirmer
        </button>
      ) : (
        <button
          type="button"
          onClick={() => setDeleteArmedId(row.id)}
          className="inline-flex min-h-[36px] items-center rounded-lg border px-2.5 text-xs font-semibold transition-colors hover:bg-[#FDF0F2]"
          style={{ borderColor: C.line, color: C.red }}
          aria-label="Supprimer (double confirmation)"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      )}
    </div>
  );
}

// ---------- Vue : Séjours ----------

function SejoursView({
  inspections,
  onDelete,
  deleteArmedId,
  setDeleteArmedId,
  onOpenStay,
}: {
  inspections: InspectionRow[];
  onDelete: (row: InspectionRow) => Promise<void>;
  deleteArmedId: string | null;
  setDeleteArmedId: (v: string | null) => void;
  onOpenStay: () => void;
}) {
  return (
    <Card>
      <CardHead
        title="Tous les séjours"
        sub={`${inspections.length} document(s) — check-ins et check-outs`}
        right={
          <Button
            type="button"
            onClick={onOpenStay}
            className="h-9 rounded-lg px-3 text-xs font-bold text-white"
            style={{ background: C.cta }}
          >
            <Plus className="mr-1 h-3.5 w-3.5" /> Créer
          </Button>
        }
      />
      <RecentTable rows={inspections} onDelete={onDelete} deleteArmedId={deleteArmedId} setDeleteArmedId={setDeleteArmedId} />
    </Card>
  );
}

// ---------- Vue : Mes biens ----------

function BiensView({ biens }: { biens: BienRow[] | null }) {
  const list = biens ?? [];
  return (
    <div className="grid gap-4">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((b) => {
          let pieces: string[] = [];
          try {
            pieces = JSON.parse(b.pieces) as string[];
          } catch {
            pieces = [];
          }
          return (
            <Card key={b.id} className="flex flex-col justify-between">
              <div>
                <div className="flex items-start justify-between gap-2">
                  <p className="text-sm font-black" style={{ color: C.ink }}>
                    {b.propertyName}
                  </p>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{ background: '#E2F1FB', color: '#1D6FB8' }}
                  >
                    {b.nbChambres === 0 ? 'Studio' : `${b.nbChambres} ch.`}
                  </span>
                </div>
                <p className="mt-1 text-xs" style={{ color: C.muted }}>
                  {b.propertyAddress}
                </p>
                <p className="mt-2 text-[11px] font-semibold" style={{ color: C.blueDeep }}>
                  {b.onboardingRef}
                </p>
                {pieces.length ? (
                  <p className="mt-2 line-clamp-2 text-[11px]" style={{ color: C.muted }}>
                    Pièces : {pieces.join(', ')}
                  </p>
                ) : null}
              </div>
            </Card>
          );
        })}
        {/* Carte « Ajouter un bien » (relance le wizard) */}
        <Link
          href="/onboarding/wizard?step=1"
          className="flex min-h-[150px] flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed p-5 text-center transition-colors hover:bg-[#F4F8FE]"
          style={{ borderColor: C.blue, color: C.blueDeep }}
        >
          <Plus className="h-6 w-6" aria-hidden="true" />
          <p className="text-sm font-black">Ajouter un bien</p>
          <p className="text-[11px]" style={{ color: C.muted }}>
            Relancer l&apos;onboarding guidé (5 min)
          </p>
        </Link>
      </div>
      {list.length === 0 ? (
        <p className="text-center text-sm" style={{ color: C.muted }}>
          Aucun bien onboardé — cliquez sur « Ajouter un bien » pour démarrer.
        </p>
      ) : null}
    </div>
  );
}

// ---------- Vue : Documents ----------

function DocumentsView({ inspections }: { inspections: InspectionRow[] }) {
  const done = inspections.filter((i) => i.status === 'COMPLETED');
  return (
    <Card>
      <CardHead title="Documents générés" sub={`${done.length} document(s) terminé(s) — PDF téléchargeables`} />
      {done.length === 0 ? (
        <p className="py-8 text-center text-sm" style={{ color: C.muted }}>
          Aucun document terminé pour le moment.
        </p>
      ) : (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {done.map((d) => (
            <div key={d.id} className="flex items-center justify-between gap-3 rounded-xl border p-3" style={{ borderColor: C.line }}>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 shrink-0" style={{ color: C.blueDeep }} aria-hidden="true" />
                  <p className="truncate text-sm font-bold" style={{ color: C.ink }}>
                    {d.propertyName}
                  </p>
                </div>
                <p className="mt-0.5 pl-6 text-[11px]" style={{ color: C.muted }}>
                  {d.type === 'ENTREE' ? "Attestation d'entrée" : 'Rapport de sortie'} · {formatFrDateTime(d.completedAt ?? d.createdAt)}
                </p>
                {d.sha256Hash ? (
                  <p className="mt-0.5 truncate pl-6 text-[10px]" style={{ color: C.muted }} title={d.sha256Hash}>
                    SHA-256 : {d.sha256Hash.slice(0, 18)}…
                  </p>
                ) : null}
              </div>
              <div className="flex shrink-0 flex-col gap-1.5">
                <a
                  href={`/api/inspection/pdf/${d.publicToken}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border px-3 text-xs font-semibold transition-colors hover:bg-[#F4F7FD]"
                  style={{ borderColor: C.line, color: C.ink }}
                >
                  <FileDown className="h-3.5 w-3.5" /> PDF
                </a>
                {d.status === 'COMPLETED' ? (
                  <a
                    href={`/api/inspection/merged-pdf/${d.id}`}
                    className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg px-3 text-xs font-bold text-white transition-opacity hover:opacity-90"
                    style={{ background: C.violet }}
                  >
                    Fusionné
                  </a>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}

// ---------- Vue : Bouclier ----------

function BouclierView({ sessionUser }: { sessionUser: SessionUser }) {
  return <ShieldManager sessionUser={sessionUser} />;
}

// ---------- Vue : Abonnement ----------

function AbonnementView({ subscription }: { subscription: { status: string; plan: string; endDate: string } }) {
  const active = subscription.status === 'active';
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHead title="Mon abonnement" sub="Offre États des Lieux" />
        <div className="mt-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Formule
            </span>
            <span className="text-sm font-black" style={{ color: C.ink }}>
              299 € / an — PDF illimités
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Statut
            </span>
            <StatusPill status={active ? 'COMPLETED' : 'CANCELLED'} />
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: C.muted }}>
              Expire le
            </span>
            <span className="text-sm font-bold" style={{ color: C.ink }}>
              {formatFrDateTime(subscription.endDate)}
            </span>
          </div>
        </div>
      </Card>
      <Card className="flex flex-col justify-between">
        <div>
          <CardHead title={active ? 'Tout est en ordre' : 'Renouvellement requis'} sub="Gestion de la souscription" />
          <p className="mt-3 text-sm leading-relaxed" style={{ color: C.muted }}>
            {active
              ? 'Votre offre est active : créez autant de séjours et de documents que nécessaire pendant toute la durée de votre abonnement.'
              : 'Votre abonnement a expiré. Renouvelez-le pour créer de nouveaux séjours — vos documents restent consultables.'}
          </p>
        </div>
        {!active ? (
          <Link
            href="/edl/abonnement"
            className="mt-4 inline-flex min-h-[44px] items-center justify-center rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            Renouveler — 299 € / an
          </Link>
        ) : null}
      </Card>
    </div>
  );
}

// ---------- Dialog : créer un nouveau séjour ----------

function StayDialog({
  open,
  onOpenChange,
  biens,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  biens: BienRow[];
  onCreated: () => void;
}) {
  const [propertyId, setPropertyId] = useState<string>('libre');
  const [propertyName, setPropertyName] = useState('');
  const [propertyAddress, setPropertyAddress] = useState('');
  const [city, setCity] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [entryDate, setEntryDate] = useState('');
  const [exitDate, setExitDate] = useState('');
  const [busy, setBusy] = useState(false);

  // Valeurs par défaut : entrée demain 10:00, sortie dans 3 jours 10:00.
  useEffect(() => {
    if (!open) return;
    const base = new Date();
    base.setDate(base.getDate() + 1);
    base.setHours(10, 0, 0, 0);
    setEntryDate((v) => v || toLocal(base));
    const out = new Date(base);
    out.setDate(out.getDate() + 3);
    setExitDate((v) => v || toLocal(out));
  }, [open]);

  const bien = biens.find((b) => b.id === propertyId);

  const submit = async () => {
    if (busy) return;
    const usingBien = propertyId !== 'libre' && !!bien;
    if (!usingBien && propertyName.trim().length < 1) return toast.error('Le nom du logement est requis.');
    if (!usingBien && propertyAddress.trim().length < 1) return toast.error("L'adresse du logement est requise.");
    if (guestName.trim().length < 1) return toast.error("Le nom de l'invité est requis.");
    if (!entryDate || !exitDate) return toast.error('Les dates d’entrée et de sortie sont requises.');
    if (new Date(exitDate) <= new Date(entryDate)) {
      return toast.error('La date de sortie doit être postérieure à la date d’entrée.');
    }

    setBusy(true);
    try {
      const res = await fetch('/api/inspection/stay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: usingBien ? bien!.id : undefined,
          propertyName: usingBien ? undefined : propertyName.trim(),
          propertyAddress: usingBien ? undefined : propertyAddress.trim(),
          city: city.trim() || undefined,
          guestName: guestName.trim(),
          guestEmail: guestEmail.trim() || undefined,
          guestPhone: guestPhone.trim() || undefined,
          entryDate: new Date(entryDate).toISOString(),
          exitDate: new Date(exitDate).toISOString(),
        }),
      });
      const json = (await res.json().catch(() => null)) as
        | { entry?: { shareUrl: string }; error?: string; message?: string }
        | null;
      if (!res.ok || !json?.entry) {
        toast.error(json?.message ?? json?.error ?? 'Création impossible. Réessayez.');
        return;
      }
      try {
        await navigator.clipboard.writeText(json.entry.shareUrl);
        toast.success('Séjour créé — check-in + check-out liés. Lien du check-in copié.');
      } catch {
        toast.success('Séjour créé — check-in + check-out liés.');
      }
      onOpenChange(false);
      setGuestName('');
      setGuestEmail('');
      setGuestPhone('');
      onCreated();
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto rounded-xl sm:max-w-xl" style={{ borderColor: C.line }}>
        <DialogHeader>
          <DialogTitle className="text-lg font-black" style={{ color: C.ink }}>
            Créer un nouveau séjour
          </DialogTitle>
          <DialogDescription className="text-xs" style={{ color: C.muted }}>
            Le check-in (entrée) et le check-out (sortie) sont créés ensemble et liés — le PDF fusionné
            « ENTRÉE + SORTIE » sera envoyé automatiquement à l&apos;hôte et à l&apos;invité à la fin du check-out.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3.5">
          <div className="space-y-1.5">
            <Label className="text-xs" style={{ color: C.ink }}>
              Bien concerné
            </Label>
            <Select value={propertyId} onValueChange={setPropertyId}>
              <SelectTrigger className="h-11 w-full" aria-label="Choisir le bien">
                <SelectValue placeholder="Choisir un bien" />
              </SelectTrigger>
              <SelectContent>
                {biens.map((b) => (
                  <SelectItem key={b.id} value={b.id}>
                    {b.propertyName}
                  </SelectItem>
                ))}
                <SelectItem value="libre">Autre logement (saisie libre)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {!bien ? (
            <>
              <div className="space-y-1.5">
                <Label htmlFor="stay-name" className="text-xs" style={{ color: C.ink }}>
                  Nom du logement
                </Label>
                <Input
                  id="stay-name"
                  value={propertyName}
                  onChange={(e) => setPropertyName(e.target.value)}
                  placeholder="ex. Villa Azur — Appartement 2"
                  maxLength={160}
                  className="h-11"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="stay-address" className="text-xs" style={{ color: C.ink }}>
                  Adresse
                </Label>
                <Input
                  id="stay-address"
                  value={propertyAddress}
                  onChange={(e) => setPropertyAddress(e.target.value)}
                  placeholder="ex. 12 rue des Palmiers"
                  maxLength={300}
                  autoComplete="street-address"
                  className="h-11"
                />
              </div>
            </>
          ) : (
            <p className="rounded-lg border px-3 py-2 text-xs" style={{ borderColor: C.line, color: C.muted }}>
              {bien.propertyName} — {bien.propertyAddress}
            </p>
          )}

          <div className="grid gap-3.5 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="stay-guest" className="text-xs" style={{ color: C.ink }}>
                Invité (nom)
              </Label>
              <Input
                id="stay-guest"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="ex. Thomas Lambert"
                maxLength={120}
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-email" className="text-xs" style={{ color: C.ink }}>
                Email invité <span className="font-normal">(pour le PDF final)</span>
              </Label>
              <Input
                id="stay-email"
                type="email"
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                placeholder="ex. thomas@exemple.fr"
                autoComplete="email"
                className="h-11"
              />
            </div>
          </div>

          <div className="grid gap-3.5 sm:grid-cols-3">
            <div className="space-y-1.5">
              <Label htmlFor="stay-phone" className="text-xs" style={{ color: C.ink }}>
                Téléphone <span className="font-normal">(opt.)</span>
              </Label>
              <Input
                id="stay-phone"
                type="tel"
                value={guestPhone}
                onChange={(e) => setGuestPhone(e.target.value)}
                placeholder="+33 6…"
                autoComplete="tel"
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-entry" className="text-xs" style={{ color: C.ink }}>
                Check-in (entrée)
              </Label>
              <Input
                id="stay-entry"
                type="datetime-local"
                value={entryDate}
                onChange={(e) => setEntryDate(e.target.value)}
                className="h-11 [color-scheme:light]"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="stay-exit" className="text-xs" style={{ color: C.ink }}>
                Check-out (sortie)
              </Label>
              <Input
                id="stay-exit"
                type="datetime-local"
                value={exitDate}
                onChange={(e) => setExitDate(e.target.value)}
                className="h-11 [color-scheme:light]"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="stay-city" className="text-xs" style={{ color: C.ink }}>
              Ville <span className="font-normal">(mention « Fait à … » — optionnel)</span>
            </Label>
            <Input
              id="stay-city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="ex. Dakar"
              maxLength={120}
              className="h-11"
            />
          </div>

          <Button
            type="button"
            disabled={busy}
            onClick={() => {
              void submit();
            }}
            className="h-11 w-full rounded-lg text-sm font-bold text-white"
            style={{ background: C.cta }}
          >
            {busy ? 'Création…' : 'Créer le séjour (check-in + check-out)'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Formate une Date pour un input datetime-local. */
function toLocal(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
