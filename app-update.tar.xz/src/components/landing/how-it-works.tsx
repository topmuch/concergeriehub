'use client';

// =============================================================
// COMMENT ÇA MARCHE — 3 étapes premium (glass + serif).
// Garde l'ancre #how-it-works et le contenu commercial d'origine
// (plaque livrée 48 h → wizard 2 min → invités autonomes).
// =============================================================

import { ArrowRight } from 'lucide-react';
import { Reveal } from '@/components/premium/reveal';

const STEPS = [
  {
    number: '01',
    icon: '📦',
    title: 'Recevez votre plaque',
    description:
      'Design premium en aluminium gravé, prête à poser. Livrée chez vous en 48 h.',
    gradient: 'from-amber-400 to-rose-500',
  },
  {
    number: '02',
    icon: '📱',
    title: 'Scannez pour configurer',
    description:
      'Wizard guidé : Wi-Fi, guidebook, règles, PIN. 2 minutes chrono, sans compétence technique.',
    gradient: 'from-rose-400 to-emerald-500',
  },
  {
    number: '03',
    icon: '🚀',
    title: 'Vos invités sont autonomes',
    description:
      'Ils scannent, commandent, s\'informent. Vous pilotez tout à distance, depuis votre dashboard.',
    gradient: 'from-emerald-400 to-teal-500',
  },
];

export function HowItWorks() {
  return (
    <section
      id="how-it-works"
      className="relative scroll-mt-24 bg-white py-24 dark:bg-slate-900/40"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* En-tête */}
        <Reveal className="mb-14 text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-amber-600 dark:text-amber-400">
            Comment ça marche
          </p>
          <h2 className="display-title font-serif! mb-4 text-4xl font-bold text-slate-900 dark:text-white md:text-5xl">
            Opérationnel en{' '}
            <span className="font-serif italic text-gradient-lux animate-gradient">
              3 minutes
            </span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-slate-600 dark:text-slate-300">
            De la réception de la plaque à l&apos;autonomie de vos invités,
            c&apos;est simple comme bonjour.
          </p>
        </Reveal>

        {/* Étapes + ligne de connexion (desktop) */}
        <div className="relative">
          <div
            aria-hidden="true"
            className="absolute left-0 right-0 top-24 hidden h-px bg-gradient-to-r from-transparent via-slate-300 to-transparent dark:via-white/15 lg:block"
          />
          <ol className="relative grid grid-cols-1 gap-6 md:grid-cols-3 lg:gap-8">
            {STEPS.map((step, i) => (
              <li key={step.number} className="relative">
                <Reveal delay={i * 0.15} className="h-full">
                  <div className="glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] group relative h-full rounded-3xl p-7 transition-transform duration-500 hover:-translate-y-1.5 sm:p-8">
                    <div className="mb-6 flex items-start justify-between">
                      <span
                        className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${step.gradient} text-2xl shadow-lg transition-transform duration-500 group-hover:scale-110`}
                        aria-hidden="true"
                      >
                        {step.icon}
                      </span>
                      <span className="font-serif text-5xl font-bold leading-none text-slate-200 dark:text-white/10">
                        {step.number}
                      </span>
                    </div>
                    <h3 className="mb-2 font-serif text-xl font-bold text-slate-900 dark:text-white">
                      {step.title}
                    </h3>
                    <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                      {step.description}
                    </p>
                  </div>
                </Reveal>
                {/* Flèche entre les étapes (desktop) */}
                {i < STEPS.length - 1 && (
                  <div
                    aria-hidden="true"
                    className="absolute -right-5 top-1/2 z-10 hidden -translate-y-1/2 lg:block"
                  >
                    <span className="glass backdrop-blur-xl backdrop-saturate-[1.4] flex h-10 w-10 items-center justify-center rounded-full">
                      <ArrowRight className="h-4 w-4 text-slate-500 dark:text-white/60" />
                    </span>
                  </div>
                )}
              </li>
            ))}
          </ol>
        </div>

        {/* Note bas de section */}
        <Reveal delay={0.4} className="mt-12 text-center">
          <p className="inline-flex items-center gap-2.5 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-5 py-2.5 text-sm font-medium text-emerald-700 dark:text-emerald-400">
            <span
              className="h-2 w-2 animate-pulse rounded-full bg-emerald-500"
              aria-hidden="true"
            />
            Zéro application à installer — tout fonctionne dans le navigateur
          </p>
        </Reveal>
      </div>
    </section>
  );
}
