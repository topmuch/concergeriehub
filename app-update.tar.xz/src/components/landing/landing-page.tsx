'use client';

// =============================================================
// LandingPage V6 — PREMIUM « LUXE TECH » (direction client :
// Apple × Airbnb × Linear, conversion en 30 s).
//
// Orchestration des sections (chacune dans son fichier) :
//   Navbar → Hero (mesh + particules + téléphone 3D) → Démo
//   interactive (#demo) → Avant/Après → Bento grid (#features)
//   → Comment ça marche (#how-it-works) → Tarifs (#pricing)
//   → Témoignages → CTA final → Footer (#contact).
//
// Fond signature : <AnimatedMeshGradient> est FIXE (une seule
// instance au niveau page) — il transparaît derrière les sections
// transparentes (hero, démo, bento, CTA final) et est masqué par
// les sections opaques (pricing, témoignages, footer).
//
// Contrat PRÉSERVÉ (landing-shell) :
//   • export AuthViewMode + LandingPageProps + LandingPage
//   • onGoToAuth('login' | 'register') sur tous les points
//     d'entrée connexion/inscription (navbar + tarifs + CTA final)
//   • ancres #demo / #features / #how-it-works / #pricing /
//     #contact intactes, footer en bas (mt-auto via flex-1)
// =============================================================

import { useEffect, useState, type MouseEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { SmoothScroll } from '@/components/premium/smooth-scroll';
import { AnimatedMeshGradient } from '@/components/premium/animated-mesh-gradient';
import { Reveal } from '@/components/premium/reveal';
import { InteractiveDemo } from './interactive-demo';
import { HeroSection } from './hero-section';
import { BeforeAfter } from './before-after';
import { BentoGrid } from './modules-showcase';
import { HowItWorks } from './how-it-works';
import { PricingSection } from './pricing-section';
import { Testimonials } from './testimonials';
import { CtaFinal } from './cta-final';

export type AuthViewMode = 'login' | 'register';

export interface LandingPageProps {
  /** Ouvre l'espace auth (connexion ou inscription). Si absent, les CTA ne font rien. */
  onGoToAuth?: (mode: AuthViewMode) => void;
}

/** Défilement doux vers une ancre de la page. */
function smoothScrollTo(selector: string) {
  if (typeof document === 'undefined') return;
  document.querySelector(selector)?.scrollIntoView({ behavior: 'smooth' });
}

// ==========================================
// NAVBAR
// ==========================================
function Navbar({ onGoToAuth }: LandingPageProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    handleScroll(); // état correct si la page est déjà scrollée au montage
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Fonctionnalités', href: '#features' },
    { name: 'Comment ça marche', href: '#how-it-works' },
    { name: 'Tarifs', href: '#pricing' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleAnchor = (href: string) => (e: MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    smoothScrollTo(href);
  };

  return (
    <nav
      className={`fixed left-0 right-0 top-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'border-b border-slate-200/70 bg-white/80 shadow-sm backdrop-blur-xl dark:border-white/[0.06] dark:bg-slate-950/80'
          : 'bg-transparent'
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#hero"
            onClick={handleAnchor('#hero')}
            className="flex items-center gap-2.5"
            aria-label="Conciergerie Hub — retour en haut"
          >
            <span className="animate-gradient flex h-10 w-10 items-center justify-center rounded-xl bg-[linear-gradient(110deg,#f59e0b,#fb7185,#10b981,#f59e0b)] bg-[length:200%_auto] shadow-lg shadow-amber-500/20">
              <span className="font-serif text-lg font-bold text-white">C</span>
            </span>
            <span className="font-serif text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Conciergerie Hub
            </span>
          </a>

          {/* Menu Desktop */}
          <div className="hidden items-center gap-8 md:flex">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={handleAnchor(link.href)}
                className="font-medium text-slate-600 transition-colors hover:text-slate-900 dark:text-white/60 dark:hover:text-white"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Boutons Desktop */}
          <div className="hidden items-center gap-4 md:flex">
            <button
              type="button"
              onClick={() => onGoToAuth?.('login')}
              className="font-medium text-slate-700 transition-colors hover:text-slate-950 dark:text-white/70 dark:hover:text-white"
            >
              Connexion
            </button>
            <button
              type="button"
              onClick={() => onGoToAuth?.('register')}
              className="rounded-xl bg-slate-950 px-5 py-2.5 font-semibold text-white transition-all hover:scale-[1.03] hover:bg-slate-800 hover:shadow-lg dark:bg-white dark:text-slate-950 dark:hover:bg-slate-200"
            >
              Essai gratuit
            </button>
          </div>

          {/* Menu Mobile */}
          <button
            type="button"
            className="p-1 text-slate-900 dark:text-white md:hidden"
            aria-label={
              isMobileMenuOpen ? 'Fermer le menu' : 'Ouvrir le menu'
            }
            aria-expanded={isMobileMenuOpen}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Menu Mobile Dropdown (carte adaptée au thème) */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3 overflow-hidden md:hidden"
            >
              <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-5 shadow-xl dark:border-white/10 dark:bg-slate-900">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="py-2 font-medium text-slate-700 dark:text-slate-200"
                    onClick={handleAnchor(link.href)}
                  >
                    {link.name}
                  </a>
                ))}
                <div className="flex flex-col gap-3 border-t border-slate-200 pt-4 dark:border-white/10">
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onGoToAuth?.('login');
                    }}
                    className="w-full rounded-xl border border-slate-200 py-3 font-medium text-slate-700 dark:border-white/15 dark:text-slate-200"
                  >
                    Connexion
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onGoToAuth?.('register');
                    }}
                    className="w-full rounded-xl bg-slate-950 py-3 font-semibold text-white dark:bg-white dark:text-slate-950"
                  >
                    Essai gratuit
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
}

// ==========================================
// DÉMO INTERACTIVE (ancre #demo — composant V5 préservé)
// ==========================================
function DemoSection() {
  return (
    <section id="demo" className="scroll-mt-24 px-4 py-24 sm:px-6">
      <Reveal>
        <div className="mx-auto max-w-5xl overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-white/10 dark:bg-slate-900 md:p-10">
          <div className="mx-auto mb-8 max-w-2xl text-center">
            <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-amber-600 dark:text-amber-400">
              La magie en 1 scan
            </p>
            <h2 className="display-title font-serif! mb-3 text-3xl font-bold text-slate-900 dark:text-white md:text-4xl">
              Voyez le Hub{' '}
              <span className="font-serif italic text-gradient-lux animate-gradient">
                en action
              </span>
            </h2>
            <p className="text-slate-600 dark:text-slate-300">
              Observez comment l&apos;expérience bascule fluidement entre le
              mode Invité (commande de services) et le mode Hôte (dashboard de
              gestion), le tout sans installer d&apos;application.
            </p>
            <div className="mt-3 inline-flex items-center gap-2 text-sm text-slate-500 dark:text-slate-400">
              <span
                aria-hidden="true"
                className="h-2.5 w-2.5 animate-pulse rounded-full bg-emerald-500"
              />
              Démo en cours de lecture…
            </div>
          </div>
          <InteractiveDemo />
        </div>
      </Reveal>
    </section>
  );
}

// ==========================================
// FOOTER (ancre #contact — contenu V5 préservé)
// ==========================================
function Footer() {
  return (
    <footer
      id="contact"
      className="mt-auto scroll-mt-24 border-t border-slate-800 bg-slate-950 px-4 pb-[max(3rem,env(safe-area-inset-bottom))] pt-16 text-slate-300 sm:px-6"
    >
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 grid gap-12 md:grid-cols-4">
          {/* Logo & Description */}
          <div className="md:col-span-1">
            <div className="mb-4 flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 via-rose-500 to-emerald-600">
                <span className="font-serif text-lg font-bold text-white">C</span>
              </span>
              <span className="font-serif text-xl font-bold text-white">
                Conciergerie Hub
              </span>
            </div>
            <p className="text-sm leading-relaxed text-slate-400">
              La plateforme tout-en-un pour les hôtes Airbnb et conciergeries
              professionnelles.
            </p>
          </div>

          {/* Produit */}
          <nav aria-label="Produit">
            <h4 className="mb-4 font-bold text-white">Produit</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="#features"
                  onClick={(e) => {
                    e.preventDefault();
                    smoothScrollTo('#features');
                  }}
                  className="transition-colors hover:text-white"
                >
                  Fonctionnalités
                </a>
              </li>
              <li>
                <a
                  href="#pricing"
                  onClick={(e) => {
                    e.preventDefault();
                    smoothScrollTo('#pricing');
                  }}
                  className="transition-colors hover:text-white"
                >
                  Tarifs
                </a>
              </li>
              <li>
                <a href="#demo" className="transition-colors hover:text-white">
                  Démo interactive
                </a>
              </li>
              <li>
                <a
                  href="#temoignages"
                  onClick={(e) => {
                    e.preventDefault();
                    smoothScrollTo('#temoignages');
                  }}
                  className="transition-colors hover:text-white"
                >
                  Témoignages
                </a>
              </li>
            </ul>
          </nav>

          {/* Entreprise */}
          <nav aria-label="Entreprise">
            <h4 className="mb-4 font-bold text-white">Entreprise</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="transition-colors hover:text-white">
                  À propos
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-white">
                  Blog
                </a>
              </li>
              <li>
                <a href="#" className="transition-colors hover:text-white">
                  Carrières
                </a>
              </li>
              <li>
                <span className="text-slate-400">Paris, France</span>
              </li>
            </ul>
          </nav>

          {/* Contact */}
          <div>
            <h4 className="mb-4 font-bold text-white">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li>
                <a
                  href="mailto:contact@conciergeriehub.com"
                  className="transition-colors hover:text-white"
                >
                  contact@conciergeriehub.com
                </a>
              </li>
              <li>
                <a
                  href="tel:+33123456789"
                  className="transition-colors hover:text-white"
                >
                  +33 1 23 45 67 89
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-slate-800 pt-8 md:flex-row">
          <p className="text-sm">
            © 2025 Conciergerie Hub. Tous droits réservés.
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="transition-colors hover:text-white">
              Mentions légales
            </a>
            <a href="#" className="transition-colors hover:text-white">
              CGU
            </a>
            <a href="#" className="transition-colors hover:text-white">
              Confidentialité
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ==========================================
// MAIN PAGE
// ==========================================
export function LandingPage({ onGoToAuth }: LandingPageProps) {
  return (
    <div className="flex min-h-screen flex-col overflow-x-clip bg-slate-50 font-sans text-slate-900 antialiased selection:bg-amber-100 dark:bg-slate-950 dark:text-slate-100 dark:selection:bg-amber-500/20">
      {/* Scroll ultra-doux (Lenis) — une seule instance par page */}
      <SmoothScroll />
      {/* Mesh gradient signature — FIXED, une seule instance pour
          toute la page ; visible derrière les sections transparentes. */}
      <AnimatedMeshGradient />

      <Navbar onGoToAuth={onGoToAuth} />
      <main className="flex-1">
        <HeroSection onGoToAuth={onGoToAuth} />
        <DemoSection />
        <BeforeAfter />
        <BentoGrid />
        <HowItWorks />
        <PricingSection onGoToAuth={onGoToAuth} />
        <Testimonials />
        <CtaFinal onGoToAuth={onGoToAuth} />
      </main>
      <Footer />
    </div>
  );
}
