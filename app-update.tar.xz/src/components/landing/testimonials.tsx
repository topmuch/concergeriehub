'use client';

// =============================================================
// TÉMOIGNAGES — carousel horizontal auto-défilant en boucle.
//
//   • Piste dupliquée ×2, animation framer-motion
//     x: ['0%', '-50%'], linear, 30 s, infinie → boucle parfaite
//     (chaque moitié porte son propre gap + padding-right).
//   • Pause au hover : AnimationPlaybackControls.pause()/play().
//   • Masque de fondu latéral : deux gradients du fond vers
//     transparent (le fond de section est opaque, donc stable).
//   • Respecte prefers-reduced-motion (pas d'animation lancée).
// v4.61 — section passée au clair « AIRBNB PRO » : fond blanc,
// cartes blanches .air-shadow, anneaux d'avatar Rausch, étoiles
// ambre conservées (standard 5 étoiles), masques from-white.
// =============================================================

import { useEffect, useRef } from 'react';
import { animate, type AnimationPlaybackControls } from 'framer-motion';
import { Star } from 'lucide-react';
import { Reveal } from '@/components/premium/reveal';

interface Testimonial {
  name: string;
  role: string;
  quote: string;
  initials: string;
}

const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Claire Dubois',
    role: 'Hôte Airbnb · Lyon',
    quote:
      'Depuis le Hub, je n’ai plus répondu à un seul « où est le Wi-Fi ? ». Mes avis n’ont jamais été aussi bons.',
    initials: 'CD',
  },
  {
    name: 'Julien Marchand',
    role: 'Gestionnaire · 12 biens · Bordeaux',
    quote:
      'L’upselling a ajouté 380 € de revenus le premier mois. Le dashboard multi-biens est d’une clarté rare.',
    initials: 'JM',
  },
  {
    name: 'Sophie Lambert',
    role: 'Hôte Airbnb · Paris 11e',
    quote:
      'Mes invités pensent que j’ai une équipe de conciergerie 24/7. C’est juste la plaque QR et l’app qui va avec.',
    initials: 'SL',
  },
  {
    name: 'Antoine Rivière',
    role: 'Conciergerie Rivière · Annecy',
    quote:
      'Le bouclier à avis nous a évité deux mauvais commentaires publics. Résolus en privé, en moins d’une heure.',
    initials: 'AR',
  },
  {
    name: 'Nadia Benali',
    role: 'Propriétaire · Nice',
    quote:
      'Installation en 5 minutes, la plaque sublime l’entrée. Mes locataires adorent le guidebook digital.',
    initials: 'NB',
  },
  {
    name: 'Marc Olivier',
    role: 'Hôte Airbnb · Chamonix',
    quote:
      'Même à la montagne, le hub reste accessible hors-ligne pour mes invités. Franchement bluffant.',
    initials: 'MO',
  },
];

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  return (
    <figure className="air-shadow w-[300px] shrink-0 rounded-3xl border border-slate-200/70 bg-white p-6 sm:w-[360px]">
      <div className="mb-3 flex gap-1" aria-label="Note : 5 étoiles sur 5">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star
            key={i}
            aria-hidden="true"
            className="h-4 w-4 fill-amber-400 text-amber-400"
          />
        ))}
      </div>
      <blockquote className="font-serif text-[15px] italic leading-relaxed text-slate-700">
        «&nbsp;{testimonial.quote}&nbsp;»
      </blockquote>
      <figcaption className="mt-5 flex items-center gap-3">
        {/* Avatar = initiales dans un cercle à bordure gradient Rausch */}
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[linear-gradient(135deg,#FF385C,#D70466)] p-[2px]">
          <span className="flex h-full w-full items-center justify-center rounded-full bg-white text-xs font-bold text-slate-900">
            {testimonial.initials}
          </span>
        </span>
        <span>
          <span className="block text-sm font-semibold text-slate-900">
            {testimonial.name}
          </span>
          <span className="block text-xs text-slate-500">
            {testimonial.role}
          </span>
        </span>
      </figcaption>
    </figure>
  );
}

export function Testimonials() {
  const trackRef = useRef<HTMLDivElement>(null);
  const controlsRef = useRef<AnimationPlaybackControls | null>(null);

  // Boucle infinie 30 s linéaire — démarrée au montage, stoppée au
  // démontage ; jamais de setState (pause/play via le contrôleur).
  useEffect(() => {
    if (
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      return;
    }
    const track = trackRef.current;
    if (!track) return;
    const controls = animate(
      track,
      { x: ['0%', '-50%'] },
      { duration: 30, ease: 'linear', repeat: Infinity },
    );
    controlsRef.current = controls;
    return () => {
      controls.stop();
      controlsRef.current = null;
    };
  }, []);

  const pause = () => controlsRef.current?.pause();
  const play = () => controlsRef.current?.play();

  return (
    <section
      id="temoignages"
      className="relative scroll-mt-24 overflow-hidden bg-white py-24 text-slate-900"
    >
      <div
        aria-hidden="true"
        className="absolute left-1/2 top-0 h-64 w-[700px] max-w-none -translate-x-1/2 rounded-full bg-[#FF385C]/[0.06] blur-[120px]"
      />

      <div className="relative z-10">
        {/* En-tête */}
        <Reveal className="mb-14 px-4 text-center sm:px-6">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-[#E61E4D]">
            Témoignages
          </p>
          <h2 className="display-title font-serif! mb-4 text-4xl font-bold md:text-5xl">
            Ils ont franchi le{' '}
            <span className="air-gradient-text font-serif italic">
              pas
            </span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-slate-600">
            Hôtes solo et conciergeries professionnelles racontent leur
            quotidien avec Conciergerie Hub.
          </p>
        </Reveal>

        {/* Marquee */}
        <div
          className="relative"
          onMouseEnter={pause}
          onMouseLeave={play}
          role="region"
          aria-label="Témoignages d'hôtes"
        >
          <div ref={trackRef} className="flex w-max">
            {/* Jeu 1 */}
            <div className="flex gap-4 pr-4 sm:gap-6 sm:pr-6">
              {TESTIMONIALS.map((t) => (
                <TestimonialCard key={t.name} testimonial={t} />
              ))}
            </div>
            {/* Jeu 2 (dupliqué pour la boucle, masqué aux lecteurs d'écran) */}
            <div className="flex gap-4 pr-4 sm:gap-6 sm:pr-6" aria-hidden="true">
              {TESTIMONIALS.map((t) => (
                <TestimonialCard key={`dup-${t.name}`} testimonial={t} />
              ))}
            </div>
          </div>

          {/* Masques de fondu latéraux (fond blanc → transparent) */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 left-0 w-12 bg-gradient-to-r from-white to-transparent sm:w-28"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-y-0 right-0 w-12 bg-gradient-to-l from-white to-transparent sm:w-28"
          />
        </div>
      </div>
    </section>
  );
}
