'use client';

// =============================================================
// CTA FINAL — section pleine largeur sur le mesh gradient animé
// (monté au niveau page, visible car la section est transparente)
// + halo signature local. Gros MagneticButton (confettis) et
// sous-texte rassurant.
// =============================================================

import { ArrowRight } from 'lucide-react';
import { MagneticButton } from '@/components/premium/magnetic-button';
import { Reveal } from '@/components/premium/reveal';

type GoToAuth = (mode: 'login' | 'register') => void;

export function CtaFinal({ onGoToAuth }: { onGoToAuth?: GoToAuth }) {
  return (
    <section className="relative overflow-hidden py-28 sm:py-36">
      {/* Halo signature local (au-dessus du mesh global) */}
      <div
        aria-hidden="true"
        className="bg-gradient-signature absolute left-1/2 top-1/2 h-[420px] w-[720px] max-w-[92vw] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-70 blur-3xl dark:opacity-40"
      />

      <Reveal className="relative z-10 mx-auto max-w-3xl px-4 text-center sm:px-6">
        <h2 className="display-title font-serif! mb-5 text-4xl font-bold text-slate-900 dark:text-white sm:text-5xl md:text-6xl">
          Prêt à offrir l&apos;expérience{' '}
          <span className="font-serif italic text-gradient-lux animate-gradient">
            5 étoiles
          </span>{' '}
          ?
        </h2>
        <p className="mb-10 text-lg text-slate-600 dark:text-slate-300">
          Rejoignez les 500+ hôtes qui automatisent déjà leur conciergerie.
        </p>
        <MagneticButton
          onClick={() => onGoToAuth?.('register')}
          className="px-10 py-5 text-lg"
        >
          ✨ Commencer l&apos;essai gratuit
          <ArrowRight className="h-5 w-5" />
        </MagneticButton>
        <p className="mt-7 text-sm text-slate-500 dark:text-slate-400">
          Sans engagement · Installé en 5 minutes
        </p>
      </Reveal>
    </section>
  );
}
