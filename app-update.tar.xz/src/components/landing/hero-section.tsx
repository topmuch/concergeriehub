'use client';

// =============================================================
// HERO PREMIUM V6 — direction « Apple × Airbnb × Linear »
//
//   • Badge « Nouveau » : pill gradient animé (.animate-gradient)
//     + reflet shimmer + ✨ en rotation lente
//   • H1 serif via <StaggerWords> — « 5 étoiles » en dégradé lux
//   • Téléphone CSS en 3D : rotateY(-15°) rotateX(5°) au repos,
//     se redresse vers 0° au scroll (useScroll + springs)
//   • CTA principal <MagneticButton> (confettis) + CTA secondaire
//     glass — ancres #pricing / #demo
//   • Fond : AnimatedMeshGradient (monté au niveau page, fixed)
//     + <FloatingParticles> locaux à la section
// =============================================================

import { useRef } from 'react';
import { motion, useScroll, useSpring, useTransform } from 'framer-motion';
import {
  ArrowRight,
  Battery,
  ChevronRight,
  ConciergeBell,
  Home,
  Play,
  Signal,
  User,
  Wifi,
} from 'lucide-react';
import { FloatingParticles } from '@/components/premium/floating-particles';
import { MagneticButton } from '@/components/premium/magnetic-button';
import { CountUp } from '@/components/premium/count-up';
import { Reveal, StaggerWords } from '@/components/premium/reveal';

type GoToAuth = (mode: 'login' | 'register') => void;

/** Défilement doux vers une ancre de la page. */
function smoothScrollTo(selector: string) {
  if (typeof document === 'undefined') return;
  document.querySelector(selector)?.scrollIntoView({ behavior: 'smooth' });
}

// ==========================================
// TÉLÉPHONE MOCKUP 3D (au scroll, se redresse)
// ==========================================
function PhoneMockup({ targetRef }: { targetRef: React.RefObject<HTMLElement | null> }) {
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ['start start', 'end start'],
  });

  // Repos : rotateY(-15°) rotateX(5°) → redressement complet à ~55 % du scroll.
  const rotateY = useSpring(useTransform(scrollYProgress, [0, 0.55], [-15, 0]), {
    stiffness: 80,
    damping: 20,
  });
  const rotateX = useSpring(useTransform(scrollYProgress, [0, 0.55], [5, 0]), {
    stiffness: 80,
    damping: 20,
  });
  const shadowOpacity = useTransform(scrollYProgress, [0, 0.55], [0.18, 0.32]);
  const shadowScale = useTransform(scrollYProgress, [0, 0.55], [0.88, 1]);

  const services = [
    { emoji: '🥐', label: 'Petit-déjeuner royal', price: '12 €' },
    { emoji: '🚕', label: 'Transfert gare', price: '29 €' },
  ];

  return (
    <div className="relative flex justify-center [perspective:1400px]">
      {/* Ombre au sol dynamique */}
      <motion.div
        aria-hidden="true"
        style={{ opacity: shadowOpacity, scaleX: shadowScale }}
        className="absolute -bottom-7 h-9 w-2/3 rounded-[100%] bg-slate-900 blur-xl dark:bg-black"
      />

      <motion.div
        style={{ rotateY, rotateX, transformStyle: 'preserve-3d' }}
        className="relative"
      >
        {/* Halo de couleur derrière l'appareil */}
        <div
          aria-hidden="true"
          className="absolute -inset-10 rounded-[4rem] bg-gradient-to-br from-amber-300/40 via-rose-300/25 to-emerald-300/40 blur-3xl dark:from-amber-500/20 dark:via-rose-500/10 dark:to-emerald-500/20"
        />

        {/* Corps du téléphone */}
        <div className="relative w-[260px] rounded-[2.9rem] bg-slate-950 p-2.5 shadow-2xl ring-1 ring-white/15 sm:w-[296px]">
          <div
            aria-hidden="true"
            className="absolute -left-[2px] top-24 h-12 w-[3px] rounded-l bg-slate-700"
          />
          {/* Écran : capture stylisée de l'app Hub */}
          <div className="relative overflow-hidden rounded-[2.3rem] bg-slate-50 dark:bg-slate-900">
            {/* Reflet diagonal */}
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 z-20 bg-[linear-gradient(115deg,transparent_32%,rgba(255,255,255,0.16)_46%,transparent_60%)]"
            />
            {/* Dynamic island */}
            <div
              aria-hidden="true"
              className="absolute left-1/2 top-2 z-20 h-5 w-24 -translate-x-1/2 rounded-full bg-slate-950"
            />

            {/* Header emerald de l'app */}
            <div className="bg-gradient-to-br from-emerald-600 to-teal-600 px-5 pb-11 pt-3 text-white">
              <div className="flex items-center justify-between text-[9px] font-semibold text-white/80">
                <span>9:41</span>
                <span className="flex items-center gap-1.5">
                  <Signal className="h-3 w-3" />
                  <Wifi className="h-3 w-3" />
                  <Battery className="h-3 w-3" />
                </span>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div>
                  <p className="text-[9px] uppercase tracking-[0.2em] text-white/70">
                    Bienvenue
                  </p>
                  <p className="text-sm font-bold">Villa Belle Rive</p>
                </div>
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-xs font-bold">
                  C
                </div>
              </div>
            </div>

            {/* Cartes Wi-Fi / Services */}
            <div className="relative z-10 -mt-7 space-y-2.5 px-4 pb-3">
              <div className="rounded-2xl bg-white p-3 shadow-lg shadow-slate-900/5 dark:bg-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-emerald-100 dark:bg-emerald-500/15">
                    <Wifi className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      Wi-Fi Fibre
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      BelleRive-5G · ••••••••
                    </p>
                  </div>
                  <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[9px] font-bold text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400">
                    Connecté
                  </span>
                </div>
              </div>

              <div className="rounded-2xl bg-white p-3 shadow-lg shadow-slate-900/5 dark:bg-slate-800">
                <p className="mb-2 text-[9px] font-bold uppercase tracking-wider text-slate-400">
                  Services
                </p>
                <div className="space-y-2">
                  {services.map((s) => (
                    <div key={s.label} className="flex items-center gap-2">
                      <span className="text-base" aria-hidden="true">
                        {s.emoji}
                      </span>
                      <p className="min-w-0 flex-1 truncate text-[11px] font-medium text-slate-700 dark:text-slate-200">
                        {s.label}
                      </p>
                      <span className="text-[11px] font-bold text-slate-900 dark:text-white">
                        {s.price}
                      </span>
                      <span className="rounded-full bg-slate-900 px-2 py-0.5 text-[9px] font-semibold text-white dark:bg-white dark:text-slate-900">
                        Commander
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Barre d'onglets */}
            <div className="flex items-center justify-around border-t border-slate-200 bg-white/90 px-6 py-2.5 dark:border-slate-700 dark:bg-slate-800/90">
              {[
                { icon: Home, label: 'Accueil', active: true },
                { icon: ConciergeBell, label: 'Services', active: false },
                { icon: User, label: 'Profil', active: false },
              ].map((tab) => (
                <div
                  key={tab.label}
                  className={`flex flex-col items-center gap-0.5 ${
                    tab.active
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-slate-400'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  <span className="text-[8px] font-medium">{tab.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Chips flottantes (hors du plan 3D, positionnées sur le conteneur) */}
      <div className="glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] absolute -right-2 top-14 hidden animate-float items-center gap-2 rounded-2xl px-3.5 py-2.5 shadow-xl sm:flex lg:-right-8">
        <span className="text-base text-amber-500" aria-hidden="true">
          ★
        </span>
        <span>
          <span className="block text-xs font-bold text-slate-900 dark:text-white">
            4,9/5
          </span>
          <span className="block text-[10px] text-slate-500 dark:text-slate-400">
            214 avis
          </span>
        </span>
      </div>
      <div
        className="glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] absolute -left-2 bottom-20 hidden animate-float items-center gap-2 rounded-2xl px-3.5 py-2.5 shadow-xl sm:flex lg:-left-10"
        style={{ animationDelay: '-3s' }}
      >
        <span aria-hidden="true">🔔</span>
        <span>
          <span className="block text-xs font-bold text-slate-900 dark:text-white">
            Nouvelle commande
          </span>
          <span className="block text-[10px] text-slate-500 dark:text-slate-400">
            Petit-déjeuner · il y a 2 min
          </span>
        </span>
      </div>
    </div>
  );
}

// ==========================================
// HERO SECTION
// ==========================================
export function HeroSection({ onGoToAuth }: { onGoToAuth?: GoToAuth }) {
  const heroRef = useRef<HTMLElement>(null);

  const stats = [
    { end: 500, suffix: '+', label: 'Hôtes actifs' },
    { end: 98, suffix: ' %', label: 'Satisfaction' },
    { end: 2, suffix: ' min', label: 'Setup moyen' },
  ];

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative scroll-mt-16 overflow-hidden pb-20 pt-28 sm:pt-32 lg:pb-28"
    >
      {/* Particules locales (le mesh gradient animé est monté au niveau page) */}
      <FloatingParticles className="z-0" />

      <div className="relative z-10 mx-auto grid max-w-7xl grid-cols-1 items-center gap-16 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
        {/* ── Colonne texte ── */}
        <div className="text-center lg:text-left">
          {/* Badge « Nouveau » — pill gradient animé + shimmer + ✨ */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-7 flex justify-center lg:justify-start"
          >
            <span className="shimmer-line animate-gradient inline-flex items-center gap-2 rounded-full border border-white/20 bg-[linear-gradient(110deg,#f59e0b,#fb7185,#10b981,#f59e0b)] bg-[length:200%_auto] px-4 py-1.5 text-xs font-bold uppercase tracking-wider text-white shadow-lg shadow-amber-500/25">
              <span aria-hidden="true" className="animate-spin-slow">
                ✨
              </span>
              Nouveau — Mode White-Label
            </span>
          </motion.div>

          {/* H1 — serif display, mots staggerés, « 5 étoiles » en lux */}
          <h1 className="display-title font-serif! mb-6 text-5xl font-bold text-slate-900 dark:text-white sm:text-6xl md:text-7xl lg:text-8xl">
            <StaggerWords
              text="Transformez chaque séjour en expérience 5 étoiles."
              highlightFrom={5}
              delay={0.15}
            />
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55 }}
            className="mx-auto mb-9 max-w-xl text-lg leading-relaxed text-slate-600 dark:text-slate-300 sm:text-xl lg:mx-0"
          >
            Une seule plaque QR élégante : vos invités accèdent au Wi-Fi, au
            guidebook et à vos services en 1 scan. Vous pilotez tout depuis un
            dashboard professionnel.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.7 }}
            className="mb-12 flex flex-col items-center justify-center gap-4 sm:flex-row lg:justify-start"
          >
            <MagneticButton
              onClick={() => smoothScrollTo('#pricing')}
              className="px-8 py-4 text-base"
            >
              Commencer l&apos;essai gratuit
              <ArrowRight className="h-5 w-5" />
            </MagneticButton>
            <button
              type="button"
              onClick={() => smoothScrollTo('#demo')}
              className="glass glass-hover backdrop-blur-xl backdrop-saturate-[1.4] flex items-center gap-2 rounded-2xl px-8 py-4 font-semibold text-slate-900 transition-all hover:scale-[1.03] dark:text-white"
            >
              <Play className="h-5 w-5" />
              Voir la démo
            </button>
          </motion.div>

          {/* Stats */}
          <Reveal delay={0.85} y={20} className="mx-auto max-w-md lg:mx-0">
            <dl className="grid grid-cols-3 gap-6">
              {stats.map((stat) => (
                <div key={stat.label} className="text-center lg:text-left">
                  <dt className="sr-only">{stat.label}</dt>
                  <dd className="mb-1 font-serif text-3xl font-bold text-slate-900 dark:text-white sm:text-4xl">
                    <CountUp end={stat.end} suffix={stat.suffix} />
                  </dd>
                  <dd className="text-xs text-slate-500 dark:text-slate-400 sm:text-sm">
                    {stat.label}
                  </dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        {/* ── Colonne téléphone 3D ── */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
        >
          <PhoneMockup targetRef={heroRef} />
        </motion.div>
      </div>

      {/* Indicateur de scroll */}
      <motion.div
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 lg:block"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        aria-hidden="true"
      >
        <ChevronRight className="h-6 w-6 rotate-90 text-slate-400 dark:text-white/40" />
      </motion.div>
    </section>
  );
}
