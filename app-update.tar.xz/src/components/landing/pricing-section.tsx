'use client';

// =============================================================
// PRICING PREMIUM V6 — 2 offres (Solo / Pro).
//
//   Solo : carte glass claire.
//   Pro  : fond slate-950 + BORDURE GRADIENT ANIMÉE (technique
//          double div : wrapper p-[1px] à fond gradient animé
//          amber→rose→emerald + carte intérieure slate-950),
//          badge « Populaire » pulsant, glow ambre, features
//          avec coches qui se dessinent.
//   Prix en font-serif avec <CountUp> au scroll (format fr-FR).
//
// LOGIQUE D'ABONNEMENT PRÉSERVÉE : les CTA appellent
// onGoToAuth('register') — parcours d'inscription → Stripe,
// identique à la V5. Aucun changement de flux.
// =============================================================

import { Check } from 'lucide-react';
import { CountUp } from '@/components/premium/count-up';
import { MagneticButton } from '@/components/premium/magnetic-button';
import { Reveal } from '@/components/premium/reveal';
import { AnimatedCheck } from './animated-check';

type GoToAuth = (mode: 'login' | 'register') => void;

const SOLO_FEATURES = [
  '1 Plaque QR Hub',
  'Wi-Fi & guidebook illimités',
  'Module upselling de base',
  'Support par email',
  'Analytics essentiels',
];

const PRO_FEATURES = [
  'Jusqu’à 3 logements inclus',
  'Équipe multi-rôles (ménage, maintenance)',
  'White-label complet',
  'Analytics avancés multi-biens',
  'Support prioritaire 24/7',
  'API & Webhooks',
];

export function PricingSection({ onGoToAuth }: { onGoToAuth?: GoToAuth }) {
  return (
    <section
      id="pricing"
      className="relative scroll-mt-24 overflow-hidden bg-slate-950 py-24 text-white"
    >
      {/* Texture + halos d'ambiance (section opaque : le mesh global est masqué) */}
      <div aria-hidden="true" className="texture-dots absolute inset-0 opacity-[0.05]" />
      <div
        aria-hidden="true"
        className="absolute -top-44 left-1/2 h-[480px] w-[820px] max-w-none -translate-x-1/2 rounded-full bg-amber-500/10 blur-[140px]"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-0 left-[12%] h-72 w-72 rounded-full bg-rose-500/10 blur-[120px]"
      />
      <div
        aria-hidden="true"
        className="absolute bottom-0 right-[12%] h-72 w-72 rounded-full bg-emerald-500/10 blur-[120px]"
      />

      <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6">
        {/* En-tête */}
        <Reveal className="mb-16 text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.25em] text-amber-400">
            Tarifs
          </p>
          <h2 className="display-title font-serif! mb-4 text-4xl font-bold md:text-5xl">
            Simple. Transparent.{' '}
            <span className="font-serif italic text-gradient-lux animate-gradient">
              Sans surprise.
            </span>
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-white/60">
            Choisissez l&apos;offre adaptée à votre activité. 14 jours
            d&apos;essai, sans engagement.
          </p>
        </Reveal>

        <div className="grid grid-cols-1 items-stretch gap-8 md:grid-cols-2 md:gap-10">
          {/* ── SOLO — carte glass ── */}
          <Reveal delay={0.1} className="h-full">
            <div className="flex h-full flex-col rounded-3xl border border-white/10 bg-white/5 p-8 shadow-[0_8px_32px_rgba(0,0,0,0.35)] backdrop-blur-xl transition-shadow duration-500 hover:shadow-[0_12px_48px_rgba(0,0,0,0.5)]">
              <div className="mb-6 flex items-center justify-between">
                <span className="text-4xl" aria-hidden="true">
                  🏠
                </span>
                <span className="rounded-full border border-white/15 bg-white/5 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-white/60">
                  1 logement
                </span>
              </div>
              <h3 className="mb-1 font-serif text-2xl font-bold">Solo</h3>
              <p className="text-sm text-white/50">
                Pour les hôtes avec un seul logement.
              </p>
              <div className="mb-8 mt-7 flex items-baseline gap-2">
                <span className="font-serif text-5xl font-bold md:text-6xl">
                  <CountUp end={9.9} decimals={2} /> €
                </span>
                <span className="text-white/40">/ mois</span>
              </div>
              <ul className="mb-8 space-y-3.5">
                {SOLO_FEATURES.map((feature) => (
                  <li key={feature} className="flex items-start gap-3">
                    <span
                      className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-400"
                      aria-hidden="true"
                    >
                      <Check className="h-3 w-3" strokeWidth={3} />
                    </span>
                    <span className="text-[15px] text-white/75">{feature}</span>
                  </li>
                ))}
              </ul>
              <button
                type="button"
                onClick={() => onGoToAuth?.('register')}
                className="mt-auto w-full rounded-2xl border border-white/15 bg-white/5 py-4 font-semibold text-white transition-all hover:scale-[1.02] hover:bg-white/10"
              >
                Commencer l&apos;essai
              </button>
            </div>
          </Reveal>

          {/* ── PRO — bordure gradient animée + glow ── */}
          <Reveal delay={0.2} className="h-full">
            <div className="relative h-full">
              {/* Wrapper padding 1px + fond gradient animé = bordure */}
              <div className="animate-gradient h-full rounded-[1.7rem] bg-[linear-gradient(110deg,#f59e0b,#fb7185,#10b981,#f59e0b)] bg-[length:200%_auto] p-[1px] shadow-[0_0_80px_rgba(245,158,11,0.25)]">
                <div className="relative flex h-full flex-col overflow-hidden rounded-[calc(1.7rem-1px)] bg-slate-950 p-8">
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute -top-24 left-1/2 h-48 w-72 -translate-x-1/2 rounded-full bg-amber-500/15 blur-3xl"
                  />
                  <div className="mb-6 flex items-center justify-between">
                    <span className="text-4xl" aria-hidden="true">
                      🏢
                    </span>
                    <span className="animate-pulse-slow rounded-full bg-gradient-to-r from-amber-500 to-rose-500 px-3.5 py-1 text-[11px] font-bold uppercase tracking-wider text-white shadow-lg shadow-rose-500/30">
                      Populaire
                    </span>
                  </div>
                  <h3 className="mb-1 font-serif text-2xl font-bold">Pro</h3>
                  <p className="text-sm text-white/50">
                    Pour les conciergeries et multi-hôtes.
                  </p>
                  <div className="mb-8 mt-7 flex items-baseline gap-2">
                    <span className="font-serif text-5xl font-bold md:text-6xl">
                      <CountUp end={199} /> €
                    </span>
                    <span className="text-white/40">/ an</span>
                  </div>
                  <ul className="mb-8 space-y-3.5">
                    {PRO_FEATURES.map((feature, i) => (
                      <li key={feature} className="flex items-start gap-3">
                        <AnimatedCheck delay={i * 0.08} />
                        <span className="text-[15px] text-white/75">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-auto">
                    <MagneticButton
                      onClick={() => onGoToAuth?.('register')}
                      className="w-full py-4 text-base"
                    >
                      Passer à Pro
                      <span aria-hidden="true">→</span>
                    </MagneticButton>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Note bas de section */}
        <Reveal delay={0.3} className="mt-14 text-center">
          <p className="text-sm text-white/40">
            Au-delà de 3 logements,{' '}
            <a
              href="#contact"
              onClick={(e) => {
                e.preventDefault();
                document
                  .querySelector('#contact')
                  ?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="font-medium text-white underline decoration-amber-400/60 underline-offset-4 transition-colors hover:text-amber-300"
            >
              contactez-nous
            </a>{' '}
            pour un devis sur mesure.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
