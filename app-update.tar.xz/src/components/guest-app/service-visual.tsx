'use client';

// =============================================================
// REFONTE SERVICES PREMIUM (V4.11) — Visuels des services.
// Aucune image n'est fournie par les prestataires → chaque catégorie
// reçoit un gradient signature + l'emoji en grand (style Uber Eats,
// cover de carte). Le mapping est déterministe : un même service
// garde toujours le même visuel.
// =============================================================

import { cn } from '@/lib/utils';

/** Gradient Tailwind par libellé de catégorie (providerCategoryMeta). */
const CATEGORY_GRADIENTS: Record<string, string> = {
  'Petit-déjeuner': 'from-amber-400 to-orange-500',
  Arrivée: 'from-rose-400 to-pink-500',
  Pratique: 'from-green-400 to-teal-500',
  Sommelier: 'from-purple-400 to-pink-500',
  Pressing: 'from-teal-400 to-cyan-500',
  'Chef à domicile': 'from-rose-400 to-red-500',
  'Bien-être': 'from-emerald-400 to-teal-500',
  'Visites & expériences': 'from-violet-400 to-fuchsia-500',
  Transferts: 'from-blue-400 to-cyan-500',
  'Baby-sitting': 'from-pink-300 to-rose-400',
};

const DEFAULT_GRADIENT = 'from-stone-400 to-stone-600';

export function getCategoryGradient(categoryLabel: string): string {
  return CATEGORY_GRADIENTS[categoryLabel] ?? DEFAULT_GRADIENT;
}

/** Couverture visuelle d'un service — gradient + emoji géant. */
export function ServiceCover({
  emoji,
  categoryLabel,
  className,
  emojiClassName,
}: {
  emoji: string;
  categoryLabel: string;
  className?: string;
  emojiClassName?: string;
}) {
  return (
    <div
      aria-hidden="true"
      className={cn(
        'relative flex items-center justify-center overflow-hidden bg-gradient-to-br',
        getCategoryGradient(categoryLabel),
        className,
      )}
    >
      {/* halo lumineux premium */}
      <div className="absolute -top-6 -right-6 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
      <div className="absolute -bottom-8 -left-4 h-20 w-20 rounded-full bg-white/15 blur-xl" />
      <span className={cn('drop-shadow-sm select-none', emojiClassName ?? 'text-6xl')}>
        {emoji}
      </span>
    </div>
  );
}
