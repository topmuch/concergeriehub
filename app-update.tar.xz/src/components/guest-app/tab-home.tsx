'use client';

import { useState } from 'react';
import { InstallButton } from './install-button';
import {
  formatFrDate,
  daysUntil,
  type GuestPayload,
  type GuestView,
} from './types';

// =============================================================
// DIGITAL CONCIERGE (V4.1) — ÉTAPE 3.1 : Onglet 🏠 Accueil
// Héro du logement + bienvenue personnalisée + SÉJOUR en cours,
// puis GRILLE 2 COLONNES d'accès rapide :
//   🔑 Accès & Codes (coffre-fort numérique)   📶 Wi-Fi (rappel rapide)
//   🥐 Commander un service (upselling)        💬 Contacter l'hôte
// =============================================================

export function TabHome({
  payload,
  onNavigate,
}: {
  payload: GuestPayload;
  onNavigate: (view: GuestView) => void;
}) {
  const { property, guest, ownerName } = payload;
  const booking = guest.booking;
  const firstName = booking ? booking.guestName.trim().split(/\s+/)[0] : null;
  const nightsLeft = booking ? daysUntil(booking.checkOut) : null;
  const hasAccessCodes = property.accessCodes !== null;

  return (
    <div className="space-y-4">
      {/* Héro du logement */}
      <section
        aria-label="Logement"
        className="bg-card border border-border rounded-2xl shadow-sm p-5"
      >
        <div className="flex items-center gap-4">
          <span className="text-4xl leading-none select-none" aria-hidden="true">
            {property.propertyTypeEmoji}
          </span>
          <div className="min-w-0">
            <h1 className="text-xl font-bold text-card-foreground leading-tight">{property.name}</h1>
            {property.address && (
              <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">{property.address}</p>
            )}
            <span className="inline-block mt-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-accent/10 text-accent border border-accent/30">
              {property.propertyTypeLabel} · Hub officiel
            </span>
          </div>
        </div>
      </section>

      {/* Bienvenue personnalisé (connecté via booking) */}
      <section aria-label="Bienvenue" className="bg-card border border-border rounded-2xl shadow-sm p-5">
        <h2 className="text-lg font-bold text-card-foreground">
          {firstName ? `Bonjour ${firstName} 👋` : 'Bienvenue 👋'}
        </h2>
        <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
          {/* ÉTAPE 19 — message d'accueil white-label de la conciergerie */}
          {payload.branding?.welcomeMessage ? (
            payload.branding.welcomeMessage
          ) : booking ? (
            <>
              Votre séjour est en cours — profitez bien&nbsp;!{' '}
              {ownerName && <>En cas de besoin, {ownerName} est à votre écoute.</>}
            </>
          ) : (
            <>Tout ce dont vous avez besoin pendant votre séjour est ici : accès, guide, quartier et assistance.</>
          )}
        </p>

        {booking && (
          <div className="mt-3 rounded-xl bg-secondary border border-border p-3.5">
            <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">Votre séjour</p>
            <div className="mt-1.5 flex flex-wrap gap-x-5 gap-y-1 text-sm text-card-foreground">
              <span>
                🛬 Arrivée&nbsp;: <strong>{formatFrDate(booking.checkIn)}</strong>
              </span>
              <span>
                🛫 Départ&nbsp;: <strong>{formatFrDate(booking.checkOut)}</strong>
              </span>
              <span>
                👥 {booking.guests} voyageur{booking.guests > 1 ? 's' : ''}
              </span>
            </div>
            {nightsLeft !== null && (
              <p className="mt-2 text-xs font-semibold text-accent">
                {nightsLeft === 0
                  ? '🛫 C’est le jour du départ — pensez à rendre les clés !'
                  : `🗓️ Départ dans ${nightsLeft} jour${nightsLeft > 1 ? 's' : ''}`}
              </p>
            )}
          </div>
        )}
      </section>

      {/* ── Grille d'accès rapide (2 colonnes) ── */}
      <div className="grid grid-cols-2 gap-3" role="navigation" aria-label="Accès rapide">
        <HomeTile
          emoji="🔑"
          title="Accès & Codes"
          subtitle={hasAccessCodes ? 'Codes, coffre, parking' : 'Bientôt disponible'}
          onClick={hasAccessCodes ? () => onNavigate('access') : undefined}
        />
        <WifiTile
          wifi={guest.wifi}
          open={false}
        />
        <HomeTile
          emoji="🥐"
          title="Commander un service"
          subtitle="Partenaires locaux"
          onClick={() => onNavigate('services')}
        />
        <HomeTile
          emoji="💬"
          title="Contacter l'hôte"
          subtitle={payload.guest.contact.name !== 'Votre hôte' ? payload.guest.contact.name : 'Réponse rapide'}
          onClick={() => onNavigate('help')}
        />
      </div>

      {/* Installation PWA (discret) */}
      <InstallButton />
    </div>
  );
}

// =============================================================
// Tuile générique de la grille (emoji 28px + titre + sous-titre)
// =============================================================
function HomeTile({
  emoji,
  title,
  subtitle,
  onClick,
}: {
  emoji: string;
  title: string;
  subtitle?: string;
  onClick?: () => void;
}) {
  if (!onClick) {
    return (
      <div className="flex flex-col items-start gap-1.5 bg-card border border-border rounded-2xl shadow-sm p-4 opacity-60" aria-disabled="true">
        <span className="text-[28px] leading-none select-none" aria-hidden="true">{emoji}</span>
        <span className="text-sm font-bold text-card-foreground leading-tight">{title}</span>
        {subtitle && <span className="text-[11px] text-muted-foreground leading-snug">{subtitle}</span>}
      </div>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex flex-col items-start gap-1.5 text-left bg-card border border-border rounded-2xl shadow-sm p-4 hover:border-accent hover:bg-accent/5 active:scale-[0.97] transition-all cursor-pointer"
    >
      <span className="text-[28px] leading-none select-none" aria-hidden="true">{emoji}</span>
      <span className="text-sm font-bold text-card-foreground leading-tight">{title}</span>
      {subtitle && <span className="text-[11px] text-muted-foreground leading-snug line-clamp-2">{subtitle}</span>}
    </button>
  );
}

// =============================================================
// DIGITAL CONCIERGE — Tuile Wi-Fi « rappel rapide » : réseau +
// mot de passe copiable directement dans la tuile (masqué par
// défaut, 👁️ pour révéler).
// =============================================================
function WifiTile({
  wifi,
  open: _open,
}: {
  wifi: NonNullable<GuestPayload['guest']['wifi']> | null;
  open?: boolean;
}) {
  const [expanded, setExpanded] = useState(false);
  const [showPwd, setShowPwd] = useState(false);
  const [copied, setCopied] = useState<'ssid' | 'pwd' | null>(null);

  if (!wifi) {
    return (
      <HomeTile emoji="📶" title="Wi-Fi" subtitle="En cours de préparation par votre hôte" />
    );
  }

  const copy = async (text: string, which: 'ssid' | 'pwd') => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      setCopied(null);
    }
  };

  return (
    <div
      className={`flex flex-col items-start gap-1.5 bg-card border rounded-2xl shadow-sm p-4 transition-all ${
        expanded ? 'border-accent col-span-2' : 'border-border'
      }`}
    >
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        aria-expanded={expanded}
        className="w-full flex flex-col items-start gap-1.5 text-left cursor-pointer"
      >
        <span className="text-[28px] leading-none select-none" aria-hidden="true">📶</span>
        <span className="text-sm font-bold text-card-foreground leading-tight">Wi-Fi</span>
        <span className="text-[11px] text-muted-foreground leading-snug truncate max-w-full">
          {wifi.networkName}
        </span>
      </button>

      {expanded && (
        <div className="w-full space-y-2 pt-2 border-t border-border mt-2">
          <div className="flex items-center justify-between gap-2 bg-secondary border border-border rounded-xl px-3 py-2">
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Réseau</p>
              <p className="text-xs font-semibold text-card-foreground truncate">{wifi.networkName}</p>
            </div>
            <button
              type="button"
              onClick={() => copy(wifi.networkName, 'ssid')}
              className="shrink-0 text-[11px] font-semibold rounded-lg px-2.5 py-1.5 border border-border bg-card text-card-foreground hover:bg-secondary transition-colors cursor-pointer"
            >
              {copied === 'ssid' ? '✓' : '📋'}
            </button>
          </div>
          <div className="flex items-center justify-between gap-2 bg-secondary border border-border rounded-xl px-3 py-2">
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Mot de passe</p>
              <p className="text-xs font-semibold text-card-foreground truncate font-mono">
                {showPwd ? wifi.password : '••••••••'}
              </p>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => setShowPwd((v) => !v)}
                aria-label={showPwd ? 'Masquer le mot de passe' : 'Afficher le mot de passe'}
                className="h-7 w-7 inline-flex items-center justify-center rounded-lg border border-border bg-card text-sm hover:bg-secondary transition-colors cursor-pointer"
              >
                {showPwd ? '🙈' : '👁️'}
              </button>
              <button
                type="button"
                onClick={() => copy(wifi.password, 'pwd')}
                aria-label="Copier le mot de passe"
                className="h-7 w-7 inline-flex items-center justify-center rounded-lg bg-primary text-primary-foreground text-xs hover:opacity-90 transition-opacity cursor-pointer"
              >
                {copied === 'pwd' ? '✓' : '📋'}
              </button>
            </div>
          </div>
        </div>
      )}

      {!expanded && (
        <button
          type="button"
          onClick={() => setExpanded(true)}
          className="text-[11px] font-semibold text-accent hover:underline cursor-pointer"
        >
          Voir le mot de passe →
        </button>
      )}
    </div>
  );
}
