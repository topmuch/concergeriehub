'use client';

import { useRef, useState } from 'react';
import { isLocalMediaUrl } from '@/lib/concierge';
import type { GuestVisualStep } from '@/lib/concierge';

// =============================================================
// PREMIUM « CONCIERGERIE 5 ÉTOILES » (V5) — 2.1 GUIDE VISUEL
// « PAS À PAS » — carrousel horizontal (snap-x) du trajet
// façade → digicode → porte, photos + textes courts de l'hôte.
//
// • Swipe natif (snap-mandatory) + boutons ‹ › + points de progression
// • Images locales (/uploads, /demo) → rendu direct (CSP 'self') ;
//   URL externe → pastille « Voir la photo » (cohérent GuestMedia)
// • CTA final « Voir les codes d'accès » si le coffre-fort existe
// =============================================================

export function VisualGuideCard({
  steps,
  onNavigateAccess,
}: {
  steps: GuestVisualStep[];
  onNavigateAccess?: () => void;
}) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const [index, setIndex] = useState(0);
  if (steps.length === 0) return null;

  const scrollToStep = (i: number) => {
    const clamped = Math.max(0, Math.min(steps.length - 1, i));
    const track = trackRef.current;
    if (!track) return;
    const child = track.children[clamped] as HTMLElement | undefined;
    if (child) track.scrollTo({ left: child.offsetLeft - track.offsetLeft, behavior: 'smooth' });
  };

  const handleScroll = () => {
    const track = trackRef.current;
    if (!track) return;
    const children = Array.from(track.children) as HTMLElement[];
    const center = track.scrollLeft + track.clientWidth / 2;
    let best = 0;
    let bestDist = Number.POSITIVE_INFINITY;
    children.forEach((c, i) => {
      const cCenter = c.offsetLeft - track.offsetLeft + c.clientWidth / 2;
      const d = Math.abs(cCenter - center);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    });
    setIndex(best);
  };

  return (
    <section
      aria-label="Guide visuel d'arrivée"
      className="bg-card border border-border rounded-2xl shadow-sm p-5"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-base font-bold text-card-foreground">🗝️ Votre arrivée, pas à pas</h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Le chemin de votre hôte jusqu&apos;aux clés — glissez pour suivre →
          </p>
        </div>
        <span className="shrink-0 text-[11px] font-bold px-2 py-0.5 rounded-full bg-secondary text-muted-foreground border border-border whitespace-nowrap">
          {index + 1}/{steps.length}
        </span>
      </div>

      {/* Piste horizontale snap-x */}
      <div
        ref={trackRef}
        onScroll={handleScroll}
        className="mt-3.5 flex gap-3 overflow-x-auto snap-x snap-mandatory -mx-1 px-1 pb-1 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
        role="group"
        aria-label={`Étapes d'arrivée (${steps.length})`}
      >
        {steps.map((step, i) => (
          <article
            key={step.id}
            className="min-w-[86%] snap-center rounded-xl border border-border bg-secondary/60 overflow-hidden"
            aria-label={`Étape ${i + 1} : ${step.title}`}
          >
            <StepImage step={step} index={i} />
            <div className="p-3.5">
              <p className="text-[10px] font-bold uppercase tracking-widest text-accent">
                Étape {i + 1}
              </p>
              <h3 className="mt-0.5 text-sm font-bold text-card-foreground leading-snug">
                {step.title}
              </h3>
              {step.description && (
                <p className="mt-1 text-xs text-muted-foreground leading-relaxed whitespace-pre-line">
                  {step.description}
                </p>
              )}
            </div>
          </article>
        ))}
      </div>

      {/* Navigation : flèches + points */}
      <div className="mt-3 flex items-center justify-between gap-3">
        <div className="flex items-center gap-1.5" role="tablist" aria-label="Étape affichée">
          {steps.map((s, i) => (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={i === index}
              aria-label={`Aller à l'étape ${i + 1} (${s.title})`}
              onClick={() => scrollToStep(i)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                i === index ? 'w-5 bg-accent' : 'w-2 bg-border hover:bg-muted-foreground/40'
              }`}
            />
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => scrollToStep(index - 1)}
            disabled={index === 0}
            aria-label="Étape précédente"
            className="h-9 w-9 inline-flex items-center justify-center rounded-xl border border-border bg-card text-card-foreground text-sm font-bold hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            ‹
          </button>
          <button
            type="button"
            onClick={() => scrollToStep(index + 1)}
            disabled={index === steps.length - 1}
            aria-label="Étape suivante"
            className="h-9 w-9 inline-flex items-center justify-center rounded-xl border border-border bg-card text-card-foreground text-sm font-bold hover:bg-secondary disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            ›
          </button>
        </div>
      </div>

      {onNavigateAccess && (
        <button
          type="button"
          onClick={onNavigateAccess}
          className="mt-4 w-full h-11 rounded-xl bg-primary text-primary-foreground font-bold text-sm hover:opacity-90 active:scale-[0.99] transition-all cursor-pointer"
        >
          🔑 Voir les codes d&apos;accès
        </button>
      )}
    </section>
  );
}

function StepImage({ step, index }: { step: GuestVisualStep; index: number }) {
  if (!step.imageUrl) {
    return (
      <div className="h-36 w-full flex items-center justify-center bg-secondary" aria-hidden="true">
        <span className="text-4xl select-none">{['🏡', '🔢', '🔑'][index % 3]}</span>
      </div>
    );
  }
  if (isLocalMediaUrl(step.imageUrl)) {
    return (
      <img
        src={step.imageUrl}
        alt={`Photo de l'étape ${index + 1} : ${step.title}`}
        loading="lazy"
        className="h-36 w-full object-cover"
      />
    );
  }
  // Image externe (CSP img-src stricte) → pastille de secours
  return (
    <a
      href={step.imageUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="h-36 w-full flex flex-col items-center justify-center gap-1.5 bg-secondary hover:bg-accent/10 transition-colors"
    >
      <span className="text-3xl select-none" aria-hidden="true">🖼️</span>
      <span className="text-[11px] font-semibold text-card-foreground">
        Voir la photo de l&apos;étape {index + 1} ↗
      </span>
    </a>
  );
}
