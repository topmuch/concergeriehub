'use client';

import { useMemo, useState } from 'react';
import { geoDirectionsUrl, spotCategoryMeta, SPOT_CATEGORY_META, type GuestSpot, type GuestSpotCategory } from '@/lib/concierge';

// =============================================================
// DIGITAL CONCIERGE (V4.1) — ÉTAPE 3.4 : onglet 🗺️ Quartier
// « 🤫 La Carte Secrète de l'Hôte » : adresses perso filtrables
// (🍔 Food · 🍹 Bars · 🛒 Courses · 🏃 Sport) + bouton « 📍 Y aller »
// (Apple Maps sur iPhone, Google Maps ailleurs — app native).
// =============================================================

type Filter = 'all' | GuestSpotCategory;

export function TabLocal({ spots }: { spots: GuestSpot[] }) {
  const [filter, setFilter] = useState<Filter>('all');

  // Compteurs par catégorie (uniquement celles réellement configurées)
  const counts = useMemo(() => {
    const map = new Map<GuestSpotCategory, number>();
    for (const s of spots) map.set(s.category, (map.get(s.category) ?? 0) + 1);
    return map;
  }, [spots]);

  const visible = spots
    .filter((s) => filter === 'all' || s.category === filter)
    .sort((a, b) => a.name.localeCompare(b.name));

  if (spots.length === 0) {
    return (
      <div className="bg-card border border-border rounded-2xl shadow-sm p-8 text-center mt-2" role="status">
        <span className="text-5xl select-none" aria-hidden="true">🤫</span>
        <h1 className="mt-4 text-lg font-bold text-card-foreground">La Carte Secrète de l'Hôte</h1>
        <p className="mt-2 text-sm text-muted-foreground leading-relaxed">
          Votre hôte prépare ses meilleures adresses : restaurants, bars, courses et balades du quartier.
          Revenez très vite !
        </p>
      </div>
    );
  }

  return (
    <div className="mt-2 space-y-4">
      {/* Titre du module */}
      <section aria-label="Carte secrète" className="bg-card border border-border rounded-2xl shadow-sm p-5">
        <h1 className="text-lg font-bold text-card-foreground">🤫 La Carte Secrète de l'Hôte</h1>
        <p className="mt-1 text-sm text-muted-foreground leading-relaxed">
          {spots.length} adresse{spots.length > 1 ? 's' : ''} testée{spots.length > 1 ? 's' : ''} et approuvée{spots.length > 1 ? 's' : ''} par votre hôte.
        </p>

        {/* Filtres — chips */}
        <div className="mt-3.5 flex flex-wrap gap-2" role="group" aria-label="Filtrer par catégorie">
          <FilterChip active={filter === 'all'} onClick={() => setFilter('all')} label={`🗺️ Tous (${spots.length})`} />
          {(Object.keys(SPOT_CATEGORY_META) as GuestSpotCategory[])
            .filter((c) => counts.has(c))
            .map((c) => (
              <FilterChip
                key={c}
                active={filter === c}
                onClick={() => setFilter(c)}
                label={`${SPOT_CATEGORY_META[c].emoji} ${SPOT_CATEGORY_META[c].label} (${counts.get(c)})`}
              />
            ))}
        </div>
      </section>

      {/* Liste des lieux */}
      {visible.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground py-6" role="status">
          Aucune adresse dans cette catégorie pour le moment.
        </p>
      ) : (
        <ul className="space-y-3">
          {visible.map((spot) => (
            <SpotCard key={spot.id} spot={spot} />
          ))}
        </ul>
      )}
    </div>
  );
}

function FilterChip({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`h-9 px-3.5 rounded-full text-xs font-semibold border transition-colors cursor-pointer ${
        active
          ? 'bg-primary text-primary-foreground border-primary'
          : 'bg-card text-card-foreground border-border hover:border-accent hover:bg-accent/5'
      }`}
    >
      {label}
    </button>
  );
}

function SpotCard({ spot }: { spot: GuestSpot }) {
  const meta = spotCategoryMeta(spot.category);
  const href = geoDirectionsUrl(spot.lat, spot.lng);

  return (
    <li className="bg-card border border-border rounded-2xl shadow-sm p-5">
      <div className="flex items-start gap-3">
        <span className="text-2xl leading-none select-none shrink-0 mt-0.5" aria-hidden="true">
          {meta.emoji}
        </span>
        <div className="min-w-0 flex-1">
          <h2 className="text-sm font-bold text-card-foreground leading-snug">{spot.name}</h2>
          <p className="mt-0.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">
            {meta.label}
            {spot.address && <span className="font-normal normal-case tracking-normal"> · {spot.address}</span>}
          </p>
          {spot.hostNote && (
            <div className="mt-2.5 rounded-xl bg-accent/5 border border-accent/30 px-3 py-2">
              <p className="text-[10px] font-bold uppercase tracking-wide text-accent">💬 Note de l'hôte</p>
              <p className="mt-0.5 text-sm text-card-foreground leading-relaxed">{spot.hostNote}</p>
            </div>
          )}
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-flex items-center justify-center gap-1.5 h-10 px-4 w-full rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:opacity-90 active:scale-[0.98] transition-all"
          >
            📍 Y aller
            <span aria-hidden="true" className="opacity-80">↗</span>
          </a>
        </div>
      </div>
    </li>
  );
}
