'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  BadgeCheck,
  FileText,
  Home,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  ShieldCheck,
  SprayCan,
  type LucideIcon,
} from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Toaster } from '@/components/ui/sonner';
import { cn } from '@/lib/utils';

// =============================================================
// BOUCLIER V2 — SHELL PRINCIPAL (master prompt, ÉTAPE 1)
// Design system validé client :
//   • Sidebar GAUCHE : fond BLEU PROFOND #1e3a8a, texte blanc,
//     icônes lucide-react — 8 onglets :
//     Tableau de bord · Ménage à faire · Check-ins · Check-outs ·
//     Mes biens · Documents · Bouclier · Abonnement
//   • Fond principal : gris très clair bg-slate-50
//   • Rendu FIXE (pas de thème sombre) : design constant client.
// Mobile-first : sidebar en drawer (Sheet) sous md, topbar bleue.
// =============================================================

interface ShieldNavItem {
  href: string;
  label: string;
  icon: LucideIcon;
  /** Correspondance exacte (Tableau de bord) au lieu de préfixe. */
  exact?: boolean;
}

const NAV_ITEMS: ShieldNavItem[] = [
  { href: '/airbnb/dashboard', label: 'Tableau de bord', icon: LayoutDashboard, exact: true },
  { href: '/airbnb/cleaning', label: 'Ménage à faire', icon: SprayCan },
  { href: '/airbnb/checkins', label: 'Check-ins', icon: LogIn },
  { href: '/airbnb/checkouts', label: 'Check-outs', icon: LogOut },
  { href: '/airbnb/properties', label: 'Mes biens', icon: Home },
  { href: '/airbnb/documents', label: 'Documents', icon: FileText },
  { href: '/airbnb/shield', label: 'Bouclier', icon: ShieldCheck },
  { href: '/airbnb/subscription', label: 'Abonnement', icon: BadgeCheck },
];

/** Libellé humain du plan (Bouclier V2). */
function planLabel(plan: string): string {
  if (plan === '499_20_BIENS') return 'Plan 499 € · 20 biens';
  return 'Plan 299 € · 3 biens';
}

function initialsOf(name: string | null | undefined): string {
  return (
    name
      ?.trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || '?'
  );
}

export interface ShieldShellProps {
  children: React.ReactNode;
  userName: string | null;
  plan: string;
}

export function ShieldShell({ children, userName, plan }: ShieldShellProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (item: ShieldNavItem): boolean =>
    item.exact ? pathname === item.href : pathname.startsWith(item.href);

  const navList = (
    <nav aria-label="Navigation Bouclier" className="flex flex-col gap-1 px-3" onClick={() => setMobileOpen(false)}>
      {NAV_ITEMS.map((item) => {
        const Icon = item.icon;
        const active = isActive(item);
        return (
          <Link
            key={item.href}
            href={item.href}
            aria-current={active ? 'page' : undefined}
            className={cn(
              'group flex min-h-[42px] items-center gap-3 rounded-xl px-3 text-[13.5px] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60',
              active
                ? 'bg-white font-semibold text-[#1e3a8a] shadow-sm'
                : 'font-medium text-blue-100 hover:bg-white/10 hover:text-white',
            )}
          >
            <Icon
              className={cn('h-[18px] w-[18px] shrink-0', active ? 'text-[#1e3a8a]' : 'text-blue-200 group-hover:text-white')}
              aria-hidden="true"
            />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );

  const profileBlock = (
    <div className="border-t border-white/10 px-4 py-3">
      <div className="flex items-center gap-2.5">
        <span
          aria-hidden="true"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-xs font-bold text-[#1e3a8a]"
        >
          {initialsOf(userName)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{userName ?? 'Hôte'}</p>
          <p className="truncate text-[10px] font-semibold uppercase tracking-[0.14em] text-blue-200">
            {planLabel(plan)}
          </p>
        </div>
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: '/' })}
          title="Se déconnecter"
          aria-label="Se déconnecter"
          className="shrink-0 rounded-lg p-1.5 text-blue-200 transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );

  const logo = (
    <Link href="/airbnb/dashboard" className="flex items-center gap-2.5 px-5 py-4" aria-label="RoomScan Bouclier">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white shadow-sm">
        <ShieldCheck className="h-6 w-6 text-[#1e3a8a]" aria-hidden="true" />
      </span>
      <span className="flex min-w-0 flex-col leading-tight">
        <span className="truncate text-[15px] font-bold text-white">RoomScan</span>
        <span className="text-[9px] font-bold uppercase tracking-[0.28em] text-blue-200">Bouclier</span>
      </span>
    </Link>
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* ============ SIDEBAR DESKTOP (bleu profond #1e3a8a) ============ */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-[#1e3a8a] md:flex">
        {logo}
        <div className="flex-1 overflow-y-auto py-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">{navList}</div>
        {profileBlock}
      </aside>

      {/* ============ TOPBAR MOBILE (bleu profond) ============ */}
      <header className="sticky top-0 z-30 flex h-14 items-center gap-2 bg-[#1e3a8a] px-3 md:hidden">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-9 rounded-xl px-3 text-xs font-semibold text-white hover:bg-white/10 hover:text-white"
              aria-label="Ouvrir le menu"
            >
              <Menu className="h-5 w-5" aria-hidden="true" />
              Menu
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[280px] border-none bg-[#1e3a8a] p-0">
            <SheetHeader className="border-b border-white/10 pb-1 pt-3">
              <SheetTitle asChild>
                <div>{logo}</div>
              </SheetTitle>
            </SheetHeader>
            <div className="flex h-[calc(100%-5rem)] flex-col justify-between pb-3 pt-3">
              <div className="flex-1 overflow-y-auto">{navList}</div>
              {profileBlock}
            </div>
          </SheetContent>
        </Sheet>
        <div className="flex min-w-0 items-center gap-2">
          <ShieldCheck className="h-5 w-5 shrink-0 text-white" aria-hidden="true" />
          <span className="truncate text-sm font-bold text-white">RoomScan Bouclier</span>
        </div>
      </header>

      {/* ============ CONTENU (fond gris très clair) ============ */}
      <div className="flex min-h-screen flex-col md:pl-64">
        <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-6 sm:px-6 lg:px-8">{children}</main>
        <footer className="mt-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-4">
          <p className="text-center text-xs text-slate-400">
            Copyright © <span className="font-bold text-slate-600">RoomScan Bouclier</span> 2025 — L&apos;état des lieux certifié de vos locations
          </p>
        </footer>
      </div>

      <Toaster position="top-center" richColors />
    </div>
  );
}
