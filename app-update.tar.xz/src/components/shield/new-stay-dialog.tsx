'use client';

// =============================================================
// ROOMSCAN BOUCLIER V2 — FLUX B : FORMULAIRE « NOUVEAU SÉJOUR »
//
// Crée une session CHECKIN ou CHECKOUT (statut A_VENIR) :
//   · bien (parmi les biens configurés) ;
//   · type avec règles : CHECKOUT « Disponible après un check-in
//     terminé » — sinon fantômes = bibliothèque de référence ;
//   · invité (nom + email — destinataires des PDF/emails) ;
//   · date + heure d'intervention ;
//   · téléphone du cleaner (optionnel).
// À la création : lien magique /s/{token} copiable immédiatement.
// =============================================================
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  CalendarClock,
  Copy,
  DoorClosed,
  DoorOpen,
  Link2,
  Loader2,
  Phone,
  Plus,
  User,
} from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ShieldPrimaryButton } from '@/components/shield/shield-ui';
import { cn } from '@/lib/utils';

export interface NewStayProperty {
  id: string;
  name: string;
  city: string | null;
}

interface CreatedInfo {
  cleanerUrl: string;
  guestName: string;
  type: 'CHECKIN' | 'CHECKOUT';
  linkedToCheckin: boolean;
}

export default function NewStayDialog({
  properties,
  label = 'Nouveau Séjour',
  iconName = 'plus',
}: {
  properties: NewStayProperty[];
  label?: string;
  /** Affiche une petite icône lucide résolue côté client (RSC-safe). */
  iconName?: 'plus' | 'doorOpen';
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const [propertyId, setPropertyId] = useState(properties[0]?.id ?? '');
  const [type, setType] = useState<'CHECKIN' | 'CHECKOUT'>('CHECKIN');
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [cleanerPhone, setCleanerPhone] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('15:00');
  const [submitting, setSubmitting] = useState(false);
  const [created, setCreated] = useState<CreatedInfo | null>(null);

  const canSubmit = useMemo(
    () =>
      Boolean(propertyId) &&
      guestName.trim().length >= 2 &&
      /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(guestEmail.trim()) &&
      date.length > 0 &&
      !submitting,
    [propertyId, guestName, guestEmail, date, submitting],
  );

  const submit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    try {
      const scheduledDate = new Date(`${date}T${time || '12:00'}:00`);
      const res = await fetch('/api/airbnb/sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId,
          type,
          guestName: guestName.trim(),
          guestEmail: guestEmail.trim(),
          cleanerPhone: cleanerPhone.trim() || undefined,
          scheduledDate: scheduledDate.toISOString(),
        }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        error?: string;
        session?: { publicToken: string };
        cleanerUrl?: string;
        linkedToCheckin?: boolean;
      };
      if (!res.ok || !data.ok || !data.session || !data.cleanerUrl) {
        if (data.error === 'onboarding_requis') {
          toast.error("Ce bien n'est pas encore configuré", {
            description: "Terminez d'abord l'onboarding (photos de référence).",
          });
        } else if (data.error === 'email_invalide') {
          toast.error('Email invité invalide');
        } else {
          toast.error('Impossible de créer le séjour');
        }
        setSubmitting(false);
        return;
      }
      setCreated({
        cleanerUrl: data.cleanerUrl,
        guestName: guestName.trim(),
        type,
        linkedToCheckin: Boolean(data.linkedToCheckin),
      });
      router.refresh();
    } catch {
      toast.error('Erreur réseau — réessayez');
    } finally {
      setSubmitting(false);
    }
  };

  const copyLink = async () => {
    if (!created) return;
    try {
      await navigator.clipboard.writeText(`${window.location.origin}${created.cleanerUrl}`);
      toast.success('Lien cleaner copié !', {
        description: 'Envoyez-le à votre cleaner : il ouvrira l’app guidée sans compte.',
      });
    } catch {
      toast.error('Copie impossible — sélectionnez le lien manuellement');
    }
  };

  const reset = () => {
    setCreated(null);
    setGuestName('');
    setGuestEmail('');
    setCleanerPhone('');
    setDate('');
    setTime('15:00');
    setType('CHECKIN');
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v && created) reset();
      }}
    >
      <DialogTrigger asChild>
        <ShieldPrimaryButton>
          {iconName === 'doorOpen' ? (
            <DoorOpen className="h-4 w-4" aria-hidden="true" />
          ) : (
            <Plus className="h-4 w-4" aria-hidden="true" />
          )}
          {label}
        </ShieldPrimaryButton>
      </DialogTrigger>
      <DialogContent className="max-h-[92dvh] overflow-y-auto rounded-2xl sm:max-w-lg">
        {created ? (
          /* ---------------- SUCCÈS ---------------- */
          <div className="py-2 text-center">
            <DialogHeader className="text-left">
              <DialogTitle>Séjour créé !</DialogTitle>
            </DialogHeader>
            <div className="mt-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
              <p className="font-bold">
                {created.type === 'CHECKIN' ? 'Check-in' : 'Check-out'} — {created.guestName}
              </p>
              <p className="mt-1 text-xs leading-relaxed">
                {created.type === 'CHECKOUT' && !created.linkedToCheckin
                  ? 'Fantômes : bibliothèque de référence (aucun check-in terminé pour ce bien).'
                  : 'La session apparaît dans « Ménage à faire ».'}
              </p>
            </div>
            <div className="mt-4 rounded-xl border border-slate-200 bg-slate-50 p-4">
              <p className="flex items-center justify-center gap-1.5 text-xs font-bold uppercase tracking-[0.12em] text-slate-500">
                <Link2 className="h-3.5 w-3.5" aria-hidden="true" /> Lien magique du cleaner
              </p>
              <p className="mt-2 break-all rounded-lg bg-white px-3 py-2 font-mono text-[11px] text-slate-700" dir="ltr">
                {typeof window !== 'undefined' ? window.location.origin : ''}
                {created.cleanerUrl}
              </p>
              <ShieldPrimaryButton className="mt-3 w-full" onClick={() => void copyLink()}>
                <Copy className="h-4 w-4" aria-hidden="true" /> Copier le lien cleaner
              </ShieldPrimaryButton>
            </div>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                setTimeout(reset, 200);
              }}
              className="mt-4 min-h-[44px] w-full rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-600 transition-colors hover:bg-slate-50"
            >
              Fermer
            </button>
          </div>
        ) : (
          /* ---------------- FORMULAIRE ---------------- */
          <div>
            <DialogHeader>
              <DialogTitle className="text-lg font-extrabold">Nouveau séjour</DialogTitle>
            </DialogHeader>

            {properties.length === 0 ? (
              <p className="mt-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800" role="alert">
                Aucun bien configuré — commencez par l&apos;onboarding (onglet « Mes biens »).
              </p>
            ) : (
              <div className="mt-3 space-y-4">
                {/* Bien */}
                <div>
                  <label htmlFor="stay-property" className="text-sm font-semibold text-slate-700">
                    Bien
                  </label>
                  <select
                    id="stay-property"
                    value={propertyId}
                    onChange={(e) => setPropertyId(e.target.value)}
                    className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                  >
                    {properties.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                        {p.city ? ` — ${p.city}` : ''}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Type */}
                <fieldset>
                  <legend className="text-sm font-semibold text-slate-700">Type de session</legend>
                  <div className="mt-1.5 grid grid-cols-2 gap-2.5">
                    {(
                      [
                        { value: 'CHECKIN', label: 'Check-in', hint: 'Avant l’arrivée', Icon: DoorOpen },
                        { value: 'CHECKOUT', label: 'Check-out', hint: 'Après le départ', Icon: DoorClosed },
                      ] as const
                    ).map(({ value, label: l, hint, Icon }) => {
                      const selected = type === value;
                      return (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setType(value)}
                          aria-pressed={selected}
                          className={cn(
                            'rounded-xl border-2 p-3 text-left transition-all',
                            selected
                              ? 'border-[#C41E3A] bg-[#C41E3A]/5'
                              : 'border-slate-200 bg-white hover:border-slate-300',
                          )}
                        >
                          <Icon
                            className={cn('h-4 w-4', selected ? 'text-[#C41E3A]' : 'text-slate-400')}
                            aria-hidden="true"
                          />
                          <span className="mt-1 block text-sm font-bold text-slate-900">{l}</span>
                          <span className="block text-[11px] text-slate-500">{hint}</span>
                        </button>
                      );
                    })}
                  </div>
                </fieldset>

                {/* Invité */}
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label htmlFor="stay-guest" className="text-sm font-semibold text-slate-700">
                      Nom de l&apos;invité
                    </label>
                    <div className="relative mt-1.5">
                      <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                      <input
                        id="stay-guest"
                        value={guestName}
                        onChange={(e) => setGuestName(e.target.value)}
                        placeholder="ex : Marie Dubois"
                        className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="stay-email" className="text-sm font-semibold text-slate-700">
                      Email de l&apos;invité
                    </label>
                    <input
                      id="stay-email"
                      type="email"
                      value={guestEmail}
                      onChange={(e) => setGuestEmail(e.target.value)}
                      placeholder="marie@email.fr"
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                    />
                  </div>
                </div>

                {/* Date + heure */}
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label htmlFor="stay-date" className="text-sm font-semibold text-slate-700">
                      Date d&apos;intervention
                    </label>
                    <div className="relative mt-1.5">
                      <CalendarClock className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                      <input
                        id="stay-date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                      />
                    </div>
                  </div>
                  <div>
                    <label htmlFor="stay-time" className="text-sm font-semibold text-slate-700">
                      Heure
                    </label>
                    <input
                      id="stay-time"
                      type="time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                    />
                  </div>
                </div>

                {/* Cleaner */}
                <div>
                  <label htmlFor="stay-phone" className="text-sm font-semibold text-slate-700">
                    Téléphone du cleaner <span className="font-normal text-slate-400">(optionnel)</span>
                  </label>
                  <div className="relative mt-1.5">
                    <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                    <input
                      id="stay-phone"
                      type="tel"
                      value={cleanerPhone}
                      onChange={(e) => setCleanerPhone(e.target.value)}
                      placeholder="ex : +33 6 12 34 56 78"
                      className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3 text-sm shadow-sm outline-none focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                    />
                  </div>
                </div>

                <ShieldPrimaryButton className="w-full" onClick={() => void submit()} disabled={!canSubmit}>
                  {submitting ? (
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  ) : null}
                  Créer le séjour + générer le lien cleaner
                </ShieldPrimaryButton>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
