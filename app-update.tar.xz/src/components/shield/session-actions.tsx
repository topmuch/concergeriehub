'use client';

// =============================================================
// ROOMSCAN BOUCLIER V2 — ACTIONS DE SESSION (client)
//   · Copier le lien magique cleaner /s/{token}
//   · Annuler la session (PATCH → ANNULE)
// Props 100 % sérialisables (compatible rendu RSC / build prod).
// =============================================================
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Ban, Copy, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { ShieldStatus } from '@/lib/shield-v2';

export function CopyCleanerLinkButton({
  publicToken,
  className,
}: {
  publicToken: string;
  className?: string;
}) {
  const [busy, setBusy] = useState(false);
  const copy = async () => {
    setBusy(true);
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/s/${publicToken}`);
      toast.success('Lien cleaner copié !', {
        description: 'Envoyez-le (SMS/WhatsApp) : l’app guidée s’ouvre sans compte.',
      });
    } catch {
      toast.error('Copie impossible', {
        description: `${typeof window !== 'undefined' ? window.location.origin : ''}/s/${publicToken}`,
      });
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      type="button"
      onClick={() => void copy()}
      disabled={busy}
      className={
        className ??
        'inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-xs font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:text-slate-900 disabled:opacity-50'
      }
    >
      {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> : <Copy className="h-3.5 w-3.5" aria-hidden="true" />}
      Lien cleaner
    </button>
  );
}

export function CancelSessionButton({ sessionId }: { sessionId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  const cancel = async () => {
    if (busy) return;
    if (!window.confirm('Annuler cette session ? Le lien cleaner cessera de fonctionner.')) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/airbnb/sessions/${sessionId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'CANCEL' }),
      });
      if (!res.ok) {
        toast.error('Annulation impossible');
        return;
      }
      toast.success('Session annulée');
      router.refresh();
    } catch {
      toast.error('Erreur réseau — réessayez');
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      type="button"
      onClick={() => void cancel()}
      disabled={busy}
      className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-xs font-semibold text-slate-500 transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
      aria-label="Annuler la session"
    >
      {busy ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
      ) : (
        <Ban className="h-3.5 w-3.5" aria-hidden="true" />
      )}
      Annuler
    </button>
  );
}

/** Badge de statut client (dupliqué de shield-ui pour les listes client). */
export function StatusPill({ status }: { status: ShieldStatus }) {
  const styles: Record<ShieldStatus, string> = {
    A_VENIR: 'bg-amber-50 text-amber-700 border-amber-200',
    EN_RETARD: 'bg-red-50 text-red-700 border-red-200',
    TERMINE: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    ANNULE: 'bg-slate-100 text-slate-600 border-slate-200',
  };
  const labels: Record<ShieldStatus, string> = {
    A_VENIR: 'À venir',
    EN_RETARD: 'En retard',
    TERMINE: 'Terminé',
    ANNULE: 'Annulé',
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-1 text-xs font-semibold ${styles[status]}`}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />
      {labels[status]}
    </span>
  );
}
