'use client';

// =============================================================
// ROOMSCAN BOUCLIER V2 — FLUX A : WIZARD D'ONBOARDING (3 ÉTAPES)
//
// ① Le logement   : nom, ville, TYPE (Studio / 1 / 2 / 3+ chambres)
// ② Pièces & appareils : cochés dynamiquement (ZÉRO case vide : les
//    captures et l'app cleaner s'adaptent aux choix)
// ③ Bibliothèque de référence : UNE photo par pièce + appareil,
//    capturée une seule fois — verrouillée puis réutilisée à chaque
//    session (ghost mode check-in/check-out).
//
// Réutilise GhostCamera (v5.4) : caméra arrière + fallback fichiers,
// photo PROPRE compressée ≤ 500 Ko. En mode reconfiguration, l'ANCIENNE
// photo sert de fantôme pour garder le même angle.
// =============================================================
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Check,
  CheckCircle2,
  ImagePlus,
  Loader2,
  Lock,
  MapPin,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  APPLIANCE_LABELS,
  APPLIANCE_ORDER,
  PROPERTY_TYPES,
  ROOM_LABELS,
  ROOM_ORDER,
} from '@/lib/shield-v2';
import { ShieldCard, ShieldPrimaryButton } from '@/components/shield/shield-ui';
import GhostCamera from '@/components/inspection/shield/ghost-camera';
import { cn } from '@/lib/utils';

export interface WizardPropertyPrefill {
  id: string;
  name: string;
  city: string | null;
  nbRooms: number;
  rooms: string[];
  appliances: string[];
  /** Clés déjà capturées (bibliothèque existante — servie en fantôme). */
  capturedKeys: string[];
  /** Pour les fantômes de re-capture. */
  propertyId: string;
}

interface Slot {
  key: string;
  kind: 'ROOM' | 'APPLIANCE';
  label: string;
  dataUrl: string | null;
}

const STEPS = ['Le logement', 'Pièces & appareils', 'Photos de référence'] as const;

export default function OnboardingWizardV2({ prefill }: { prefill?: WizardPropertyPrefill }) {
  const router = useRouter();
  const editMode = Boolean(prefill);

  // ---------------- Step 1 ----------------
  const [name, setName] = useState(prefill?.name ?? '');
  const [city, setCity] = useState(prefill?.city ?? '');
  const [nbRooms, setNbRooms] = useState<number | null>(prefill ? prefill.nbRooms : null);

  // ---------------- Step 2 ----------------
  const [rooms, setRooms] = useState<string[]>(prefill?.rooms ?? []);
  const [appliances, setAppliances] = useState<string[]>(
    prefill?.appliances ?? ['PLAQUE', 'FRIGO', 'TV', 'MICRO_ONDES'],
  );

  // ---------------- Step 3 ----------------
  const [slots, setSlots] = useState<Slot[]>([]);
  const [activeSlot, setActiveSlot] = useState<Slot | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const roomSlots = useMemo(
    () => rooms.map((key) => ({ key, kind: 'ROOM' as const, label: ROOM_LABELS[key] ?? key })),
    [rooms],
  );
  const applianceSlots = useMemo(
    () =>
      appliances.map((key) => ({
        key,
        kind: 'APPLIANCE' as const,
        label: APPLIANCE_LABELS[key] ?? key,
      })),
    [appliances],
  );

  // Slots = rooms + appareils cochés ; on conserve les captures déjà faites.
  const allSlots: Slot[] = useMemo(() => {
    const wanted: Slot[] = [
      ...roomSlots.map((r) => ({ ...r, dataUrl: null as string | null })),
      ...applianceSlots.map((a) => ({ ...a, dataUrl: null as string | null })),
    ];
    return wanted.map((w) => {
      const existing = slots.find((s) => s.key === w.key && s.kind === w.kind);
      return existing ?? w;
    });
  }, [roomSlots, applianceSlots, slots]);

  const capturedCount = allSlots.filter((s) => s.dataUrl).length;
  const totalSlots = allSlots.length;
  const allCaptured = totalSlots > 0 && capturedCount === totalSlots;

  const [step, setStep] = useState(0);
  const canNext0 = name.trim().length >= 2 && nbRooms !== null;
  const canNext1 = rooms.length > 0;

  const chooseType = (value: number) => {
    setNbRooms(value);
    const preset = PROPERTY_TYPES.find((t) => t.nbRooms === value);
    if (preset && !editMode) setRooms(preset.defaultRooms);
  };

  const toggle = (list: string[], setList: (v: string[]) => void, key: string) => {
    setList(list.includes(key) ? list.filter((k) => k !== key) : [...list, key]);
  };

  const onPhotoTaken = (dataUrl: string) => {
    if (!activeSlot) return;
    setSlots((prev) => {
      const rest = prev.filter((s) => !(s.key === activeSlot.key && s.kind === activeSlot.kind));
      return [...rest, { key: activeSlot.key, kind: activeSlot.kind, label: activeSlot.label, dataUrl }];
    });
    setActiveSlot(null);
    toast.success('Photo de référence capturée', { description: activeSlot.label });
  };

  const ghostForActive = (): string | undefined => {
    if (!activeSlot || !prefill) return undefined;
    return prefill.capturedKeys.includes(activeSlot.key)
      ? `/api/airbnb/media/${prefill.propertyId}/ref_${activeSlot.key}.jpg`
      : undefined;
  };

  const submit = async () => {
    if (!allCaptured || submitting) return;
    setSubmitting(true);
    try {
      const referencePhotos: Record<string, string> = {};
      for (const slot of allSlots) {
        if (slot.dataUrl) referencePhotos[slot.key] = slot.dataUrl;
      }
      const payload = {
        name: name.trim(),
        city: city.trim(),
        nbRooms: nbRooms ?? 0,
        rooms,
        appliances,
        referencePhotos,
      };
      const res = await fetch(
        editMode ? `/api/airbnb/properties/${prefill?.id}` : '/api/airbnb/properties',
        {
          method: editMode ? 'PATCH' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        },
      );
      const data = (await res.json().catch(() => ({}))) as { error?: string; missing?: string[] };
      if (!res.ok) {
        if (data.error === 'plan_limit_reached') {
          toast.error('Limite du plan atteinte', {
            description: 'Votre abonnement ne permet plus d\u2019ajouter de bien. Passez au plan supérieur (onglet Abonnement).',
          });
        } else if (data.error === 'photos_manquantes' && data.missing) {
          toast.error('Photos manquantes', { description: data.missing.join(', ') });
        } else {
          toast.error("Impossible d'enregistrer le bien");
        }
        setSubmitting(false);
        return;
      }
      toast.success(
        editMode ? 'Bien reconfiguré !' : 'Bien configuré — bouclier activé !',
        { description: 'La bibliothèque de référence est verrouillée. Vous pouvez créer des séjours.' },
      );
      router.push('/airbnb/properties');
      router.refresh();
    } catch {
      toast.error('Erreur réseau — réessayez');
      setSubmitting(false);
    }
  };

  // =============================================================
  return (
    <div>
      {/* Fil d'Ariane 1-2-3 */}
      <ol className="mb-6 flex items-center gap-2" aria-label="Étapes de l'onboarding">
        {STEPS.map((label, index) => {
          const state = index === step ? 'current' : index < step ? 'done' : 'todo';
          return (
            <li key={label} className="flex min-w-0 flex-1 items-center gap-2">
              <span
                aria-current={state === 'current' ? 'step' : undefined}
                className={cn(
                  'flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold',
                  state === 'current' && 'bg-[#C41E3A] text-white shadow-sm',
                  state === 'done' && 'bg-emerald-500 text-white',
                  state === 'todo' && 'bg-slate-200 text-slate-500',
                )}
              >
                {state === 'done' ? <Check className="h-4 w-4" aria-hidden="true" /> : index + 1}
              </span>
              <span
                className={cn(
                  'hidden truncate text-xs font-semibold sm:block',
                  state === 'current' ? 'text-slate-900' : 'text-slate-400',
                )}
              >
                {label}
              </span>
              {index < STEPS.length - 1 ? (
                <span aria-hidden="true" className="h-px flex-1 bg-slate-200" />
              ) : null}
            </li>
          );
        })}
      </ol>

      {/* ================= ÉTAPE 1 — LE LOGEMENT ================= */}
      {step === 0 ? (
        <ShieldCard className="p-5 sm:p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
            <Building2 className="h-5 w-5 text-[#C41E3A]" aria-hidden="true" />
            Votre logement, c&apos;est quoi ?
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            L&apos;onboarding se fait UNE SEULE FOIS par bien — ensuite, plus jamais besoin de
            refaire les photos.
          </p>

          <div className="mt-5 space-y-4">
            <div>
              <label htmlFor="prop-name" className="text-sm font-semibold text-slate-700">
                Nom du bien
              </label>
              <input
                id="prop-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="ex : Studio République"
                maxLength={80}
                className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-900 shadow-sm outline-none transition focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
              />
            </div>
            <div>
              <label htmlFor="prop-city" className="text-sm font-semibold text-slate-700">
                Ville <span className="font-normal text-slate-400">(optionnel)</span>
              </label>
              <div className="relative mt-1.5">
                <MapPin className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
                <input
                  id="prop-city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="ex : Paris"
                  maxLength={60}
                  className="w-full rounded-xl border border-slate-200 bg-white py-2.5 pl-9 pr-3.5 text-sm text-slate-900 shadow-sm outline-none transition focus:border-[#C41E3A] focus:ring-2 focus:ring-[#C41E3A]/20"
                />
              </div>
            </div>

            <fieldset>
              <legend className="text-sm font-semibold text-slate-700">Type de logement</legend>
              <div className="mt-2 grid grid-cols-2 gap-2.5 lg:grid-cols-4">
                {PROPERTY_TYPES.map((type) => {
                  const selected = nbRooms === type.nbRooms;
                  return (
                    <button
                      key={type.nbRooms}
                      type="button"
                      onClick={() => chooseType(type.nbRooms)}
                      aria-pressed={selected}
                      className={cn(
                        'rounded-xl border-2 p-3.5 text-left transition-all',
                        selected
                          ? 'border-[#C41E3A] bg-[#C41E3A]/5 shadow-sm'
                          : 'border-slate-200 bg-white hover:border-slate-300',
                      )}
                    >
                      <span
                        className={cn(
                          'flex h-5 w-5 items-center justify-center rounded-full border-2',
                          selected ? 'border-[#C41E3A] bg-[#C41E3A]' : 'border-slate-300',
                        )}
                        aria-hidden="true"
                      >
                        {selected ? <Check className="h-3 w-3 text-white" /> : null}
                      </span>
                      <span className="mt-2 block text-sm font-bold text-slate-900">{type.label}</span>
                      <span className="mt-0.5 block text-[11px] leading-snug text-slate-500">
                        {type.hint}
                      </span>
                    </button>
                  );
                })}
              </div>
            </fieldset>
          </div>

          <div className="mt-6 flex justify-end">
            <ShieldPrimaryButton onClick={() => setStep(1)} disabled={!canNext0}>
              Continuer <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </ShieldPrimaryButton>
          </div>
        </ShieldCard>
      ) : null}

      {/* ============== ÉTAPE 2 — PIÈCES & APPAREILS ============== */}
      {step === 1 ? (
        <ShieldCard className="p-5 sm:p-6">
          <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
            <Sparkles className="h-5 w-5 text-[#C41E3A]" aria-hidden="true" />
            Pièces &amp; appareils à vérifier
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Cochez ce que le cleaner devra photographier et vérifier à chaque séjour. L&apos;app
            du cleaner s&apos;adaptera automatiquement à vos choix.
          </p>

          <fieldset className="mt-5">
            <legend className="text-sm font-bold uppercase tracking-[0.1em] text-slate-400">
              Pièces ({rooms.length})
            </legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {ROOM_ORDER.map((key) => {
                const selected = rooms.includes(key);
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => toggle(rooms, setRooms, key)}
                    aria-pressed={selected}
                    className={cn(
                      'min-h-[40px] rounded-full border-2 px-4 text-sm font-semibold transition-all',
                      selected
                        ? 'border-[#C41E3A] bg-[#C41E3A] text-white shadow-sm'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                    )}
                  >
                    {selected ? <Check className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" /> : null}
                    {ROOM_LABELS[key]}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <fieldset className="mt-6">
            <legend className="text-sm font-bold uppercase tracking-[0.1em] text-slate-400">
              Appareils ({appliances.length}) — photo une seule fois, vérifiés à chaque séjour
            </legend>
            <div className="mt-2 flex flex-wrap gap-2">
              {APPLIANCE_ORDER.map((key) => {
                const selected = appliances.includes(key);
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => toggle(appliances, setAppliances, key)}
                    aria-pressed={selected}
                    className={cn(
                      'min-h-[40px] rounded-full border-2 px-4 text-sm font-semibold transition-all',
                      selected
                        ? 'border-[#1e3a8a] bg-[#1e3a8a] text-white shadow-sm'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300',
                    )}
                  >
                    {selected ? <Check className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" /> : null}
                    {APPLIANCE_LABELS[key]}
                  </button>
                );
              })}
            </div>
          </fieldset>

          {rooms.length === 0 ? (
            <p className="mt-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700" role="alert">
              Sélectionnez au moins une pièce.
            </p>
          ) : null}

          <div className="mt-6 flex items-center justify-between">
            <ShieldSecondary onClick={() => setStep(0)}>
              <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Retour
            </ShieldSecondary>
            <ShieldPrimaryButton onClick={() => setStep(2)} disabled={!canNext1}>
              Photos de référence <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </ShieldPrimaryButton>
          </div>
        </ShieldCard>
      ) : null}

      {/* ============ ÉTAPE 3 — BIBLIOTHÈQUE DE RÉFÉRENCE ============ */}
      {step === 2 ? (
        <div className="space-y-4">
          <ShieldCard className="p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
                  <Lock className="h-5 w-5 text-[#C41E3A]" aria-hidden="true" />
                  Bibliothèque de référence
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  Une photo par pièce / appareil, capturée <strong>une seule fois</strong>. Elle
                  servira de modèle (fantôme) à chaque session.
                </p>
              </div>
              <span
                className={cn(
                  'rounded-full border px-3 py-1.5 text-xs font-bold',
                  allCaptured
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                    : 'border-amber-200 bg-amber-50 text-amber-700',
                )}
                role="status"
              >
                {capturedCount} / {totalSlots} photos
              </span>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {allSlots.map((slot) => (
                <div
                  key={`${slot.kind}-${slot.key}`}
                  className={cn(
                    'overflow-hidden rounded-xl border-2 bg-white transition-all',
                    slot.dataUrl ? 'border-emerald-200' : 'border-dashed border-slate-300',
                  )}
                >
                  <div className="relative aspect-[4/3] bg-slate-100">
                    {slot.dataUrl ? (
                       
                      <img
                        src={slot.dataUrl}
                        alt={`Référence ${slot.label}`}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <button
                        type="button"
                        onClick={() => setActiveSlot(slot)}
                        className="flex h-full w-full flex-col items-center justify-center gap-1.5 text-slate-400 transition-colors hover:bg-slate-50 hover:text-[#C41E3A]"
                        aria-label={`Capturer ${slot.label}`}
                      >
                        <ImagePlus className="h-6 w-6" aria-hidden="true" />
                        <span className="text-[11px] font-semibold">Capturer</span>
                      </button>
                    )}
                    {slot.dataUrl ? (
                      <span
                        aria-hidden="true"
                        className="absolute right-1.5 top-1.5 flex h-6 w-6 items-center justify-center rounded-full bg-emerald-500 shadow"
                      >
                        <Check className="h-3.5 w-3.5 text-white" />
                      </span>
                    ) : null}
                  </div>
                  <div className="flex items-center justify-between gap-1 px-2.5 py-2">
                    <div className="min-w-0">
                      <p className="truncate text-xs font-bold text-slate-900">{slot.label}</p>
                      <p className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                        {slot.kind === 'ROOM' ? 'Pièce' : 'Appareil'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setActiveSlot(slot)}
                      className="shrink-0 rounded-lg p-1.5 text-slate-400 transition-colors hover:bg-slate-100 hover:text-[#C41E3A]"
                      aria-label={slot.dataUrl ? `Reprendre ${slot.label}` : `Capturer ${slot.label}`}
                    >
                      {slot.dataUrl ? (
                        <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                      ) : (
                        <ImagePlus className="h-3.5 w-3.5" aria-hidden="true" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {allCaptured ? (
              <p className="mt-4 flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700" role="status">
                <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
                Bibliothèque complète — le bien sera prêt à recevoir des séjours.
              </p>
            ) : null}

            <div className="mt-6 flex items-center justify-between">
              <ShieldSecondary onClick={() => setStep(1)}>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" /> Retour
              </ShieldSecondary>
              <ShieldPrimaryButton onClick={() => void submit()} disabled={!allCaptured || submitting}>
                {submitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                )}
                {editMode ? 'Enregistrer la configuration' : 'Activer le bouclier'}
              </ShieldPrimaryButton>
            </div>
          </ShieldCard>
        </div>
      ) : null}

      {/* Caméra plein écran (capture / re-capture avec fantôme) */}
      {activeSlot ? (
        <GhostCamera
          key={`${activeSlot.kind}-${activeSlot.key}`}
          roomName={activeSlot.label}
          referencePhotoUrl={ghostForActive()}
          onPhotoTaken={onPhotoTaken}
          onClose={() => setActiveSlot(null)}
        />
      ) : null}
    </div>
  );
}

/** Bouton secondaire (bordure grise) du wizard. */
function ShieldSecondary({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-600 shadow-sm transition-colors hover:bg-slate-50"
    >
      {children}
    </button>
  );
}
