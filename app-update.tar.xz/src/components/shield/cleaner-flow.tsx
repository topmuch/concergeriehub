'use client';

// =============================================================
// ROOMSCAN BOUCLIER V2 — FLUX C : APP CLEANER (lien magique /s/[token])
//
// Parcours guidé MOBILE, SANS LOGIN (le token EST l'autorisation) :
//   ① Accueil  — bien, invité, type de session, consigne.
//   ② Vidéo    — traversée CONTINUE jusqu'à 120 s, badge REC +
//                compte à rebours, hash SHA-256 (client affiché,
//                serveur recalculé → non falsifiable).
//   ③ Photos   — UNE photo par pièce cochée à l'onboarding, MODE
//                FANTÔME 50 % : CHECK-IN = bibliothèque de référence
//                verrouillée ; CHECK-OUT = photos du CHECK-IN lié
//                (même angle exact). La photo enregistrée reste
//                PROPRE (le fantôme n'est jamais incrusté).
//   ④ Récap    — tous les médias vérifiés → « Terminer la session ».
//   ⑤ Terminé  — session scellée (statut TERMINE côté serveur).
//
// ROBUSTESSE : chaque média est envoyé INDIVIDUELLEMENT dès la
// capture, 3 tentatives automatiques + bouton « Réessayer » manuel
// (master prompt : 上传失败可重试 — upload failure can be retried).
// =============================================================
import { useCallback, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Camera,
  CheckCircle2,
  Ghost,
  Loader2,
  Lock,
  RotateCcw,
  ShieldCheck,
  Video as VideoIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { ShieldCard } from '@/components/shield/shield-ui';
import GhostCamera from '@/components/inspection/shield/ghost-camera';
import VideoRecorder from '@/components/inspection/shield/video-recorder';
import { generateSHA256Hash, shortHash } from '@/lib/crypto-utils';
import { cn } from '@/lib/utils';

export interface CleanerZone {
  key: string;
  label: string;
  /** URL du fantôme (référence ou photo du check-in) — absente = capture libre. */
  ghostUrl?: string;
}

export interface CleanerFlowProps {
  token: string;
  type: 'CHECKIN' | 'CHECKOUT';
  guestName: string;
  propertyName: string;
  city: string | null;
  zones: CleanerZone[];
}

type MediaState =
  | { status: 'idle' }
  | { status: 'uploading' }
  | { status: 'done'; url: string; hash?: string }
  | { status: 'error'; message?: string };

/** 3 tentatives automatiques (backoff 1 s / 2 s). */
async function fetchWithRetry(
  input: string,
  init: RequestInit,
  attempts = 3,
): Promise<Response> {
  let lastError: unknown = null;
  for (let i = 0; i < attempts; i += 1) {
    try {
      const res = await fetch(input, init);
      if (res.ok) return res;
      // 4xx définitifs : inutile de réessayer tel quel
      if (res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) {
        throw new Error(`http_${res.status}`);
      }
      lastError = new Error(`http_${res.status}`);
    } catch (error) {
      lastError = error;
    }
    await new Promise((r) => setTimeout(r, 1000 * (i + 1)));
  }
  throw lastError instanceof Error ? lastError : new Error('network');
}

export default function CleanerFlow({
  token,
  type,
  guestName,
  propertyName,
  city,
  zones,
}: CleanerFlowProps) {
  const isCheckin = type === 'CHECKIN';
  const [step, setStep] = useState(0); // 0 accueil · 1 vidéo · 2 photos · 3 récap · 4 fini

  // ------------------------- VIDÉO -------------------------
  const [videoState, setVideoState] = useState<MediaState>({ status: 'idle' });
  const [videoMeta, setVideoMeta] = useState<{ duration: number; hash: string | null } | null>(null);
  const videoBlobRef = useRef<Blob | null>(null);
  const [recorderOpen, setRecorderOpen] = useState(false);

  const uploadVideo = useCallback(
    async (blob: Blob, duration: number) => {
      videoBlobRef.current = blob;
      setVideoState({ status: 'uploading' });
      try {
        const form = new FormData();
        form.append('file', blob, 'walkthrough.webm');
        const res = await fetchWithRetry(`/api/s/${token}/upload`, {
          method: 'POST',
          body: form,
        });
        const data = (await res.json()) as { url?: string; hash?: string };
        if (!data.url) throw new Error('reponse_incomplete');
        setVideoState({ status: 'done', url: data.url, hash: data.hash });
        setVideoMeta({ duration, hash: data.hash ?? null });
        toast.success('Vidéo envoyée et scellée');
      } catch {
        setVideoState({ status: 'error', message: 'Envoi impossible — vérifiez le réseau.' });
      }
    },
    [token],
  );

  const retryVideo = async () => {
    const blob = videoBlobRef.current;
    if (!blob) return;
    await uploadVideo(blob, videoMeta?.duration ?? 0);
  };

  // ------------------------- PHOTOS -------------------------
  const [photos, setPhotos] = useState<Record<string, { state: MediaState; dataUrl: string }>>({});
  const [activeZone, setActiveZone] = useState<CleanerZone | null>(null);

  const uploadPhoto = useCallback(
    async (zoneKey: string, dataUrl: string) => {
      setPhotos((prev) => ({ ...prev, [zoneKey]: { state: { status: 'uploading' }, dataUrl } }));
      try {
        const res = await fetchWithRetry(`/api/s/${token}/upload`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ zone: zoneKey, dataUrl }),
        });
        const data = (await res.json()) as { url?: string };
        if (!data.url) throw new Error('reponse_incomplete');
        setPhotos((prev) => ({
          ...prev,
          [zoneKey]: { state: { status: 'done', url: data.url as string }, dataUrl },
        }));
      } catch {
        setPhotos((prev) => ({
          ...prev,
          [zoneKey]: {
            state: { status: 'error', message: 'Envoi impossible' },
            dataUrl,
          },
        }));
      }
    },
    [token],
  );

  const onPhotoTaken = (dataUrl: string) => {
    if (!activeZone) return;
    const zoneKey = activeZone.key;
    setActiveZone(null);
    toast.success(`${activeZone.label} — photo capturée`);
    void uploadPhoto(zoneKey, dataUrl);
  };

  const photosDone = zones.filter((z) => photos[z.key]?.state.status === 'done').length;
  const allPhotosDone = zones.length > 0 && photosDone === zones.length;
  const videoDone = videoState.status === 'done';

  // ------------------------- CLÔTURE -------------------------
  const [completing, setCompleting] = useState(false);
  const [finalHash, setFinalHash] = useState<string | null>(null);

  const complete = async () => {
    if (completing || !videoDone || !allPhotosDone) return;
    setCompleting(true);
    try {
      const photosMap: Record<string, string> = {};
      for (const zone of zones) {
        const entry = photos[zone.key];
        if (entry?.state.status === 'done') photosMap[zone.key] = entry.state.url;
      }
      const videoEntry = videoState.status === 'done' ? videoState : null;
      const res = await fetch(`/api/s/${token}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          photos: photosMap,
          videoUrl: videoEntry?.url,
          videoHash: videoEntry?.hash,
        }),
      });
      const data = (await res.json()) as { ok?: boolean };
      if (!res.ok || !data.ok) throw new Error('complete_failed');
      // Empreinte globale affichée (vidéo déjà scellée côté serveur)
      const hash = videoEntry?.hash ?? (await generateSHA256Hash(JSON.stringify(photosMap)));
      setFinalHash(hash);
      setStep(4);
    } catch {
      toast.error('Clôture impossible — réessayez');
    } finally {
      setCompleting(false);
    }
  };

  // =============================================================
  return (
    <div className="mx-auto w-full max-w-md px-4 pb-10 pt-6">
      {/* En-tête session */}
      <div className="mb-5 text-center">
        <span
          aria-hidden="true"
          className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-[#1e3a8a]"
        >
          <ShieldCheck className="h-6 w-6 text-white" />
        </span>
        <h1 className="mt-3 text-lg font-extrabold text-slate-900">
          {isCheckin ? 'Check-in' : 'Check-out'} — {propertyName}
        </h1>
        <p className="mt-0.5 text-sm text-slate-500">
          {city ? `${city} · ` : ''}invité : {guestName}
        </p>
      </div>

      {/* ============ ÉTAPE 0 — ACCUEIL ============ */}
      {step === 0 ? (
        <ShieldCard className="p-5">
          <h2 className="text-base font-bold text-slate-900">Votre mission</h2>
          <ol className="mt-3 space-y-3 text-sm text-slate-600">
            <li className="flex gap-2.5">
              <VideoIcon className="mt-0.5 h-4 w-4 shrink-0 text-[#C41E3A]" aria-hidden="true" />
              <span>
                <strong className="text-slate-900">1 vidéo</strong> — traversez toutes les pièces
                en continu (jusqu&apos;à 2 minutes). Preuve juridique scellée SHA-256.
              </span>
            </li>
            <li className="flex gap-2.5">
              <Camera className="mt-0.5 h-4 w-4 shrink-0 text-[#C41E3A]" aria-hidden="true" />
              <span>
                <strong className="text-slate-900">{zones.length} photos</strong> — une par pièce,
                superposées au modèle de référence (mode fantôme) pour le même angle exact.
              </span>
            </li>
          </ol>
          {isCheckin ? (
            <p className="mt-4 rounded-xl border border-blue-100 bg-blue-50 px-3.5 py-2.5 text-xs leading-relaxed text-[#1e3a8a]">
              <Lock className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />
              Check-in : vous photographiez sur le modèle de référence — l&apos;état d&apos;arrivée
              sera la référence des prochains check-outs.
            </p>
          ) : (
            <p className="mt-4 rounded-xl border border-amber-100 bg-amber-50 px-3.5 py-2.5 text-xs leading-relaxed text-amber-800">
              <Ghost className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />
              Check-out : les photos du check-in s&apos;affichent en transparence — reproduisez le
              même angle, tout écart sera visible dans le rapport.
            </p>
          )}
          <button
            type="button"
            onClick={() => setStep(1)}
            className="mt-5 inline-flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#C41E3A] text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830]"
          >
            C&apos;est parti <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </button>
        </ShieldCard>
      ) : null}

      {/* ============ ÉTAPE 1 — VIDÉO 120 s ============ */}
      {step === 1 ? (
        <ShieldCard className="p-5">
          <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
            <VideoIcon className="h-5 w-5 text-[#C41E3A]" aria-hidden="true" />
            Vidéo walkthrough (120 s max)
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            Traversez <strong>toutes les pièces en continu</strong>, sans couper — c&apos;est la
            preuve reine de l&apos;état des lieux.
          </p>

          {videoState.status === 'done' ? (
            <div className="mt-4 space-y-3">
              <div
                className="flex items-center gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-700"
                role="status"
              >
                <CheckCircle2 className="h-5 w-5 shrink-0" aria-hidden="true" />
                Vidéo enregistrée
                {videoMeta?.duration ? ` — ${formatDuration(videoMeta.duration)}` : ''}
              </div>
              {videoMeta?.hash ? (
                <p className="break-all rounded-lg bg-slate-50 px-3 py-2 font-mono text-[10px] text-slate-500" dir="ltr">
                  SHA-256 {shortHash(videoMeta.hash, 24)}
                </p>
              ) : null}
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setRecorderOpen(true)}
                  className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-50"
                >
                  <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> Refaire la vidéo
                </button>
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#C41E3A] px-4 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830]"
                >
                  Photos <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          ) : videoState.status === 'uploading' ? (
            <p
              className="mt-4 flex items-center gap-2 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-sm font-semibold text-[#1e3a8a]"
              role="status"
            >
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              Envoi de la vidéo… (ne fermez pas la page)
            </p>
          ) : videoState.status === 'error' ? (
            <div className="mt-4 space-y-3">
              <p
                className="flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700"
                role="alert"
              >
                <AlertTriangle className="h-4 w-4 shrink-0" aria-hidden="true" />
                {videoState.message ?? 'Échec de l\u2019envoi'}
              </p>
              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => void retryVideo()}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#C41E3A] px-4 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830]"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" /> Réessayer l&apos;envoi
                </button>
                <button
                  type="button"
                  onClick={() => setRecorderOpen(true)}
                  className="min-h-[44px] text-xs font-semibold text-slate-500 underline"
                >
                  Réenregistrer
                </button>
              </div>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setRecorderOpen(true)}
              className="mt-4 inline-flex min-h-[52px] w-full items-center justify-center gap-2 rounded-xl bg-[#C41E3A] text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830]"
            >
              <VideoIcon className="h-5 w-5" aria-hidden="true" />
              Démarrer la vidéo
            </button>
          )}
        </ShieldCard>
      ) : null}

      {/* ============ ÉTAPE 2 — PHOTOS MODE FANTÔME ============ */}
      {step === 2 ? (
        <ShieldCard className="p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
              <Camera className="h-5 w-5 text-[#C41E3A]" aria-hidden="true" />
              Photos des pièces
            </h2>
            <span
              className={cn(
                'rounded-full border px-2.5 py-1 text-xs font-bold',
                allPhotosDone
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
                  : 'border-amber-200 bg-amber-50 text-amber-700',
              )}
              role="status"
            >
              {photosDone} / {zones.length}
            </span>
          </div>
          <p className="mt-1 text-sm text-slate-500">
            Le modèle de référence s&apos;affiche en transparence (50 %) — alignez-vous dessus.
          </p>

          <ul className="mt-4 space-y-2.5">
            {zones.map((zone) => {
              const entry = photos[zone.key];
              const state = entry?.state ?? { status: 'idle' };
              return (
                <li
                  key={zone.key}
                  className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-2.5"
                >
                  <div className="relative h-14 w-16 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                    {entry?.dataUrl ? (
                       
                      <img
                        src={entry.dataUrl}
                        alt={`Photo ${zone.label}`}
                        className="h-full w-full object-cover"
                      />
                    ) : zone.ghostUrl ? (
                       
                      <img
                        src={zone.ghostUrl}
                        alt=""
                        aria-hidden="true"
                        className="h-full w-full object-cover opacity-50"
                      />
                    ) : (
                      <Camera className="absolute inset-0 m-auto h-5 w-5 text-slate-300" aria-hidden="true" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-900">{zone.label}</p>
                    <p className="text-[11px] text-slate-400">
                      {state.status === 'idle' && 'À photographier'}
                      {state.status === 'uploading' && 'Envoi…'}
                      {state.status === 'done' && 'Photo scellée'}
                      {state.status === 'error' && (state.message ?? 'Échec de l\u2019envoi')}
                    </p>
                  </div>
                  {state.status === 'done' ? (
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" aria-hidden="true" />
                  ) : state.status === 'uploading' ? (
                    <Loader2 className="h-5 w-5 shrink-0 animate-spin text-slate-400" aria-hidden="true" />
                  ) : state.status === 'error' ? (
                    <button
                      type="button"
                      onClick={() => void uploadPhoto(zone.key, entry?.dataUrl ?? '')}
                      className="inline-flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-lg bg-[#C41E3A] px-3 text-xs font-bold text-white"
                    >
                      <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" /> Réessayer
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setActiveZone(zone)}
                      className="inline-flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-lg bg-[#C41E3A] px-3 text-xs font-bold text-white shadow-sm transition-colors hover:bg-[#a01830]"
                    >
                      <Camera className="h-3.5 w-3.5" aria-hidden="true" />
                      {entry?.dataUrl ? 'Reprendre' : 'Capturer'}
                    </button>
                  )}
                </li>
              );
            })}
          </ul>

          <div className="mt-5 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => setStep(1)}
              className="min-h-[44px] text-xs font-semibold text-slate-500 underline"
            >
              Retour vidéo
            </button>
            <button
              type="button"
              onClick={() => setStep(3)}
              disabled={!allPhotosDone}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#C41E3A] px-4 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830] disabled:cursor-not-allowed disabled:opacity-50"
            >
              Récapitulatif <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </ShieldCard>
      ) : null}

      {/* ============ ÉTAPE 3 — RÉCAPITULATIF ============ */}
      {step === 3 ? (
        <ShieldCard className="p-5">
          <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
            <ShieldCheck className="h-5 w-5 text-emerald-500" aria-hidden="true" />
            Tout est prêt — scellement
          </h2>
          <ul className="mt-3 space-y-2 text-sm" aria-label="Récapitulatif des médias">
            <li className="flex items-center gap-2 text-slate-700">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" aria-hidden="true" />
              Vidéo walkthrough scellée (SHA-256)
            </li>
            {zones.map((zone) => (
              <li key={zone.key} className="flex items-center gap-2 text-slate-700">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" aria-hidden="true" />
                {zone.label}
              </li>
            ))}
          </ul>
          <p className="mt-3 rounded-xl bg-slate-50 px-3.5 py-2.5 text-xs leading-relaxed text-slate-500">
            En validant, la session passe au statut <strong>Terminé</strong> : l&apos;hôte reçoit
            l&apos;état des lieux scellé. Vérifiez que les photos sont nettes et bien cadrées.
          </p>
          <div className="mt-5 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => setStep(2)}
              className="min-h-[44px] text-xs font-semibold text-slate-500 underline"
            >
              Retour photos
            </button>
            <button
              type="button"
              onClick={() => void complete()}
              disabled={completing}
              className="inline-flex min-h-[48px] items-center gap-2 rounded-xl bg-[#C41E3A] px-5 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[#a01830] disabled:opacity-60"
            >
              {completing ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <ShieldCheck className="h-4 w-4" aria-hidden="true" />
              )}
              Terminer la session
            </button>
          </div>
        </ShieldCard>
      ) : null}

      {/* ============ ÉTAPE 4 — TERMINÉ ============ */}
      {step === 4 ? (
        <ShieldCard className="p-6 text-center">
          <span
            aria-hidden="true"
            className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100"
          >
            <CheckCircle2 className="h-7 w-7 text-emerald-600" />
          </span>
          <h2 className="mt-3 text-lg font-extrabold text-slate-900">Session terminée, merci !</h2>
          <p className="mt-1 text-sm text-slate-500">
            L&apos;état des lieux {isCheckin ? "d'entrée" : 'de sortie'} est scellé et transmis à
            l&apos;hôte. Vous pouvez fermer cette page.
          </p>
          {finalHash ? (
            <p
              className="mt-4 break-all rounded-lg bg-slate-50 px-3 py-2 font-mono text-[10px] text-slate-500"
              dir="ltr"
            >
              SCELLEMENT SHA-256 {shortHash(finalHash, 32)}
            </p>
          ) : null}
        </ShieldCard>
      ) : null}

      {/* Overlays plein écran */}
      {recorderOpen ? (
        <VideoRecorder
          maxDuration={120}
          maxBytes={80_000_000}
          onClose={() => setRecorderOpen(false)}
          onVideoRecorded={(blob, _base64, duration) => {
            setRecorderOpen(false);
            void uploadVideo(blob, duration);
          }}
        />
      ) : null}
      {activeZone ? (
        <GhostCamera
          key={activeZone.key}
          roomName={activeZone.label}
          referencePhotoUrl={activeZone.ghostUrl}
          onPhotoTaken={onPhotoTaken}
          onClose={() => setActiveZone(null)}
        />
      ) : null}
    </div>
  );
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
