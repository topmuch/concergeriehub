'use client';

import type { ReactNode } from 'react';
import {
  DoorClosed,
  DoorOpen,
  FileText,
  Fingerprint,
  GitCompareArrows,
  Home,
  Plus,
  SprayCan,
  Video,
  type LucideIcon,
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

// =============================================================
// Icônes — restriction RSC : une référence de composant lucide
// (composant NON client) ne peut PAS être passée en prop d'un
// client component (crash prod « Functions cannot be passed… »).
// On passe donc un NOM D'ICÔNE (string sérialisable) résolu ici,
// côté client, depuis cette map.
// =============================================================

export type ShieldIconName =
  | 'doorOpen'
  | 'doorClosed'
  | 'sprayCan'
  | 'fileText'
  | 'home'
  | 'plus'
  | 'video'
  | 'compare'
  | 'fingerprint';

const ICON_MAP: Record<ShieldIconName, LucideIcon> = {
  doorOpen: DoorOpen,
  doorClosed: DoorClosed,
  sprayCan: SprayCan,
  fileText: FileText,
  home: Home,
  plus: Plus,
  video: Video,
  compare: GitCompareArrows,
  fingerprint: Fingerprint,
};

// =============================================================
// BOUCLIER V2 — KIT UI (master prompt, design system validé)
//   • Cartes      : bg-white rounded-xl shadow-sm border-slate-200
//   • Bouton primaire : ROUGE Roomscan #C41E3A (hover #a01830)
//   • Statuts     : À venir (jaune) · En retard (rouge) ·
//                   Terminé (vert) · Annulé (gris)
//   • Rendu FIXE (fond slate-50, encre slate-900) — le shell V2
//     ne suit pas le thème global : design client constant.
// =============================================================

export interface ShieldPageHeaderProps {
  title: string;
  description?: string;
  /** Action principale (bouton rouge, etc.) rendue à droite. */
  action?: ReactNode;
}

export function ShieldPageHeader({ title, description, action }: ShieldPageHeaderProps) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <h1 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">{title}</h1>
        {description ? (
          <p className="mt-1 text-sm text-slate-500">{description}</p>
        ) : null}
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </div>
  );
}

export function ShieldCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        'rounded-xl border border-slate-200 bg-white shadow-sm',
        className,
      )}
    >
      {children}
    </div>
  );
}

/** Bouton primaire ROUGE Roomscan (#C41E3A / hover #a01830). */
export function ShieldPrimaryButton({
  children,
  onClick,
  type = 'button',
  className,
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: 'button' | 'submit';
  className?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        'inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[#C41E3A] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-[#a01830] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C41E3A]/50 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60',
        className,
      )}
    >
      {children}
    </button>
  );
}

/** Bouton d'action dont la logique arrive à l'étape suivante. */
export function ShieldSoonButton({
  label,
  iconName,
  soonMessage = 'Cette étape arrive juste après la validation du design — étape 2.',
}: {
  label: string;
  /** Nom d'icône (string) — résolu côté client (restriction RSC). */
  iconName?: ShieldIconName;
  soonMessage?: string;
}) {
  const Icon = iconName ? ICON_MAP[iconName] : null;
  return (
    <ShieldPrimaryButton
      onClick={() => toast.info(soonMessage, { description: 'Structure et routing déjà en place.' })}
    >
      {Icon ? <Icon className="h-4 w-4" aria-hidden="true" /> : null}
      {label}
    </ShieldPrimaryButton>
  );
}

export type ShieldStatus = 'A_VENIR' | 'EN_RETARD' | 'TERMINE' | 'ANNULE';

const STATUS_STYLES: Record<ShieldStatus, { label: string; className: string; dot: string }> = {
  A_VENIR: {
    label: 'À venir',
    className: 'bg-amber-50 text-amber-700 border-amber-200',
    dot: 'bg-amber-400',
  },
  EN_RETARD: {
    label: 'En retard',
    className: 'bg-red-50 text-red-700 border-red-200',
    dot: 'bg-red-500',
  },
  TERMINE: {
    label: 'Terminé',
    className: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    dot: 'bg-emerald-500',
  },
  ANNULE: {
    label: 'Annulé',
    className: 'bg-slate-100 text-slate-600 border-slate-200',
    dot: 'bg-slate-400',
  },
};

/** Badge de statut — spec client : À venir (jaune), En retard (rouge), Terminé (vert), Annulé (gris). */
export function ShieldStatusBadge({ status, className }: { status: ShieldStatus; className?: string }) {
  const style = STATUS_STYLES[status] ?? STATUS_STYLES.A_VENIR;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold',
        style.className,
        className,
      )}
    >
      <span className={cn('h-1.5 w-1.5 rounded-full', style.dot)} aria-hidden="true" />
      {style.label}
    </span>
  );
}

export interface ShieldEmptyStateProps {
  /** Nom d'icône (string) — résolu côté client (restriction RSC). */
  iconName: ShieldIconName;
  title: string;
  text: string;
  /** Bloc optionnel sous le texte (bouton d'action, liste d'appareils…). */
  children?: ReactNode;
}

/** État vide standard — carte blanche centrée, icône pastille rouge doux. */
export function ShieldEmptyState({ iconName, title, text, children }: ShieldEmptyStateProps) {
  const Icon = ICON_MAP[iconName];
  return (
    <ShieldCard className="px-6 py-12 text-center sm:px-10">
      <span
        aria-hidden="true"
        className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#C41E3A]/10"
      >
        <Icon className="h-7 w-7 text-[#C41E3A]" />
      </span>
      <h2 className="mt-4 text-lg font-bold text-slate-900">{title}</h2>
      <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-slate-500">{text}</p>
      {children ? <div className="mt-6 flex flex-col items-center">{children}</div> : null}
    </ShieldCard>
  );
}

/** Pastille « Étape suivante » — honnêteté UI pendant la reconstruction. */
export function ShieldStepHint({ children }: { children?: ReactNode }) {
  return (
    <p className="mt-6 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-center text-xs leading-relaxed text-slate-500">
      {children ?? 'Le contenu dynamique de cette page est câblé à l\u2019étape suivante (données + logique métier).'}
    </p>
  );
}

/** Bandeau d'aperçu : contenu de démonstration pour VALIDER LE DESIGN (étape 1). */
export function ShieldPreviewNote({ className }: { className?: string }) {
  return (
    <p
      className={cn(
        'mb-4 inline-flex items-center gap-2 rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.14em] text-[#1e3a8a]',
        className,
      )}
    >
      Aperçu du design — données réelles à l&apos;étape 2
    </p>
  );
}

/** Ligne de session (aperçu design des listes Ménage / Check-ins / Check-outs). */
export function ShieldSessionRow({
  iconName,
  guest,
  property,
  meta,
  status,
}: {
  /** Nom d'icône (string) — résolu côté client (restriction RSC). */
  iconName: ShieldIconName;
  guest: string;
  property: string;
  meta: string;
  status: ShieldStatus;
}) {
  const Icon = ICON_MAP[iconName];
  return (
    <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3 last:border-b-0">
      <span aria-hidden="true" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-100">
        <Icon className="h-4 w-4 text-slate-500" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-semibold text-slate-900">{guest}</p>
        <p className="truncate text-xs text-slate-500">
          {property} · {meta}
        </p>
      </div>
      <ShieldStatusBadge status={status} />
    </div>
  );
}
