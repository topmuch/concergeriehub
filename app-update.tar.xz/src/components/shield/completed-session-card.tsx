'use client';

// =============================================================
// ROOMSCAN BOUCLIER V2 — CARTE SESSION TERMINÉE (Check-ins /
// Check-outs / Documents). Photos de la session, vidéo scellée,
// hash SHA-256, bouton PDF (génération = étape suivante du master
// prompt). Props sérialisables uniquement (RSC-safe).
// =============================================================
import { useState } from 'react';
import { Copy, FileText, Images, Lock, ShieldCheck, Video } from 'lucide-react';
import { toast } from 'sonner';
import { ShieldCard } from '@/components/shield/shield-ui';
import { ROOM_LABELS } from '@/lib/shield-v2';

export interface CompletedSessionData {
  id: string;
  type: 'CHECKIN' | 'CHECKOUT';
  guestName: string;
  propertyName: string;
  city: string | null;
  completedAt: string; // ISO
  photos: { zone: string; url: string }[];
  videoUrl: string | null;
  videoHash: string | null;
}

function shortHash(hash: string): string {
  return hash.length > 20 ? `${hash.slice(0, 10)}…${hash.slice(-8)}` : hash;
}

export default function CompletedSessionCard({ data }: { data: CompletedSessionData }) {
  const [expanded, setExpanded] = useState(false);
  const isCheckin = data.type === 'CHECKIN';

  const copyHash = async () => {
    if (!data.videoHash) return;
    try {
      await navigator.clipboard.writeText(data.videoHash);
      toast.success('Hash SHA-256 copié');
    } catch {
      toast.error('Copie impossible');
    }
  };

  const pdfHint = () => {
    toast.info(
      isCheckin
        ? 'PDF certificat de check-in — génération à l\u2019étape suivante (master prompt)'
        : 'PDF rapport Delta (entrée vs sortie) — génération à l\u2019étape suivante',
      { description: 'Les données (photos + vidéo + hash) sont déjà scellées.' },
    );
  };

  const visible = expanded ? data.photos : data.photos.slice(0, 4);

  return (
    <ShieldCard className="overflow-hidden">
      <div className="flex flex-col gap-2.5 border-b border-slate-100 px-4 py-3.5 sm:flex-row sm:items-center">
        <span
          aria-hidden="true"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-emerald-50"
        >
          <ShieldCheck className="h-4 w-4 text-emerald-600" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-slate-900">
            {isCheckin ? 'Check-in' : 'Check-out'} · {data.guestName}
          </p>
          <p className="truncate text-xs text-slate-500">
            {data.propertyName}
            {data.city ? ` — ${data.city}` : ''} · validé le{' '}
            {new Intl.DateTimeFormat('fr-FR', {
              day: 'numeric',
              month: 'short',
              hour: '2-digit',
              minute: '2-digit',
            }).format(new Date(data.completedAt))}
          </p>
        </div>
        <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">
          <Lock className="h-3 w-3" aria-hidden="true" />
          Scellé
        </span>
      </div>

      {/* Photos de la session */}
      <div className="px-4 py-3">
        <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.12em] text-slate-400">
          <Images className="h-3.5 w-3.5" aria-hidden="true" />
          Photos de session ({data.photos.length})
        </p>
        <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-6">
          {visible.map((photo) => (
            <figure key={photo.zone} className="overflow-hidden rounded-lg border border-slate-200">
              { }
              <img
                src={photo.url}
                alt={`Photo ${ROOM_LABELS[photo.zone] ?? photo.zone}`}
                className="aspect-[4/3] w-full object-cover"
                loading="lazy"
              />
              <figcaption className="truncate px-1 py-0.5 text-center text-[9px] font-semibold text-slate-500">
                {ROOM_LABELS[photo.zone] ?? photo.zone}
              </figcaption>
            </figure>
          ))}
        </div>
        {data.photos.length > 4 ? (
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="mt-2 min-h-[32px] text-xs font-semibold text-[#C41E3A] hover:underline"
          >
            {expanded ? 'Réduire' : `Voir les ${data.photos.length} photos`}
          </button>
        ) : null}
      </div>

      {/* Preuve vidéo + hash */}
      <div className="flex flex-col gap-2 border-t border-slate-100 bg-slate-50/60 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 flex-wrap items-center gap-2">
          {data.videoUrl ? (
            <a
              href={data.videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 text-xs font-semibold text-slate-600 transition-colors hover:border-slate-300 hover:text-slate-900"
            >
              <Video className="h-3.5 w-3.5" aria-hidden="true" />
              Vidéo walkthrough
            </a>
          ) : null}
          {data.videoHash ? (
            <button
              type="button"
              onClick={() => void copyHash()}
              className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 font-mono text-[11px] text-slate-500 transition-colors hover:text-slate-900"
              title="Copier le hash SHA-256 de la vidéo"
            >
              <Copy className="h-3 w-3 shrink-0" aria-hidden="true" />
              <span className="truncate">SHA-256 {shortHash(data.videoHash)}</span>
            </button>
          ) : null}
        </div>
        <button
          type="button"
          onClick={pdfHint}
          className="inline-flex min-h-[36px] shrink-0 items-center gap-1.5 rounded-lg bg-[#1e3a8a] px-3 text-xs font-bold text-white shadow-sm transition-colors hover:bg-[#16307a]"
        >
          <FileText className="h-3.5 w-3.5" aria-hidden="true" />
          {isCheckin ? 'PDF certificat' : 'PDF rapport Delta'}
        </button>
      </div>
    </ShieldCard>
  );
}
