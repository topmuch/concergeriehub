'use client';

import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Lock, Settings2, User } from 'lucide-react';
import { BrandLogo } from '@/components/ui/brand-logo';
import { cn } from '@/lib/utils';

// =============================================================
// HUB PREMIUM « LUXE TECH » — HeroLanding (page d'entrée du hub QR)
//
// v4.51 — POLISH VISUEL « EFFET WAHOU » (demande client, spec exacte) :
//   • Fond bg-slate-950 avec 3 « blobs » de couleur flottants
//     (absolute, blur-3xl, opacity-30) : bg-amber-500 en haut à
//     gauche, bg-emerald-600 en bas à droite + un 3ᵉ petit contrepoint.
//     Animation Framer Motion TRÈS lente (20 s) pour les faire flotter.
//   • Badge pill « ✨ Expérience Conciergerie » (white/10 + ambre-300).
//   • Titre Playfair text-4xl/5xl tracking-tight, message slate-400.
//   • Cartes glassmorphism avancé : bg-white/5 backdrop-blur-2xl
//     border-white/10 rounded-3xl, hover bg-white/10 + scale 1.02.
//       – Carte Mode Invité : icône haute (group-hover:scale-110),
//         bouton plein « Entrer » émeraude.
//       – Carte Mode Hôte : glow ambre (shadow-[0_0_30px_-5px_…]),
//         les 2 sous-espaces (🔐 Hôte / 🧹 Ménage) séparés par une
//         fine ligne border-t, bouton plein « Entrer » ambre.
//   • Chorégraphie d'apparition en cascade : badge 0.1 s → titre 0.2 s
//     → message 0.3 s → carte invité 0.4 s → carte hôte 0.5 s → footer.
//
// LOGIQUE MÉTIER CONSERVÉE : accord de l'article (welcomeTitle), mise
// en évidence du nom (gradient or), FIX-16 ⚙️ accès hôte rapide,
// badges « Accès libre » / « 2 espaces », ligne de confiance du type
// de bien, nom de l'hôte dans le footer, aria-labels + focus visibles,
// respect de prefers-reduced-motion. La navigation (clics) reste
// portée par hub-content.tsx — aucune logique changée, uniquement
// l'enrobage visuel.
// =============================================================

/** Easing expo partagé. */
const EASE_EXPO = [0.16, 1, 0.3, 1] as const;

interface HeroLandingProps {
  propertyName: string;
  propertyTypeEmoji: string;
  propertyTypeLabel: string;
  ownerName: string | null;
  onGuestClick: () => void;
  onHostClick: () => void;
  // v4.43 — le Mode Ménage est FUSIONNÉ dans le Mode Hôte : un seul
  // bouton, la modale propose 2 grandes cartes (Hôte / Ménage).
}

/**
 * Accorde l'article du titre d'accueil au nom du bien :
 *   « Villa Sarbacane » → « Bienvenue à la Villa Sarbacane »
 *   « Le Petit Nid »    → « Bienvenue au Petit Nid »
 *   « Les Oliviers »    → « Bienvenue aux Oliviers »
 *   « L'Atelier »       → « Bienvenue à l'Atelier »
 *   « Loft des Arts »   → « Bienvenue au Loft des Arts »
 */
function welcomeTitle(raw: string): string {
  const n = raw.trim();
  const l = n.toLowerCase();
  if (/^le\s/.test(l)) return `Bienvenue au ${n.slice(3)}`;
  if (/^les\s/.test(l)) return `Bienvenue aux ${n.slice(4)}`;
  if (/^l'/.test(l)) return `Bienvenue à l'${n.slice(2)}`;
  if (
    /^(loft|studio|chalet|gîte|gite|appartement|duplex|penthouse|bungalow|roulotte|tipi|mobile-home)\b/i.test(
      n,
    )
  ) {
    return `Bienvenue au ${n}`;
  }
  return `Bienvenue à la ${n}`;
}

/* ── Blobs de couleur flottants (fond « effet wahou ») ─────────── */

function FloatingBlob({
  className,
  animate,
  duration,
  reduceMotion,
  delay = 0,
}: {
  className: string;
  animate: { x: number[]; y: number[] };
  duration: number;
  reduceMotion: boolean | null;
  delay?: number;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className={cn('absolute rounded-full blur-3xl opacity-30', className)}
      animate={reduceMotion ? undefined : animate}
      transition={{
        duration,
        repeat: Infinity,
        repeatType: 'mirror',
        ease: 'easeInOut',
        delay,
      }}
    />
  );
}

/* ── Carte d'accès premium (Mode Invité / Mode Hôte) ──────────── */

/** Conteneur glassmorphism commun aux 2 cartes (spec v4.51 exacte). */
const GLASS_CARD =
  'relative overflow-hidden bg-white/5 backdrop-blur-2xl border border-white/10 rounded-3xl p-6 shadow-2xl ' +
  'transition-all duration-300 hover:bg-white/10 hover:border-white/20 hover:scale-[1.02] group';

function AccessCard({
  tone,
  icon: Icon,
  iconTile,
  iconText,
  title,
  subtitle,
  badge,
  delay,
  glowClass,
  ctaClass,
  subOptions,
  onClick,
}: {
  tone: 'emerald' | 'amber';
  icon: typeof User;
  iconTile: string;
  iconText: string;
  title: string;
  subtitle: string;
  badge: string;
  /** Délai de la cascade (0.4 = invité, 0.5 = hôte). */
  delay: number;
  /** Ombre spécifique (glow ambre sur la carte hôte). */
  glowClass: string;
  /** Classes du bouton plein (émeraude / ambre). */
  ctaClass: string;
  /** v4.51 carte hôte : sous-options listées SOUS une fine ligne. */
  subOptions?: { emoji: string; label: string; hint: string }[];
  onClick: () => void;
}) {
  const reduceMotion = useReducedMotion();

  return (
    <motion.button
      type="button"
      onClick={onClick}
      aria-label={`${title} — ${badge}. Entrer`}
      initial={reduceMotion ? { opacity: 1 } : { opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: EASE_EXPO }}
      whileHover={reduceMotion ? undefined : { scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        GLASS_CARD,
        'w-full cursor-pointer text-left',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950',
        glowClass,
      )}
    >
      {/* Badge pill translucide (haut-droite) */}
      <span
        className={cn(
          'absolute right-4 top-4 z-10 inline-flex items-center rounded-full border px-3 py-1 text-[11px] font-semibold backdrop-blur-md',
          tone === 'emerald'
            ? 'border-emerald-400/40 bg-emerald-500/20 text-emerald-100'
            : 'border-amber-400/40 bg-amber-500/20 text-amber-100',
        )}
      >
        {badge}
      </span>

      {/* Icône en haut — grossit au survol (spec : group-hover:scale-110) */}
      <span
        aria-hidden="true"
        className={cn(
          'relative z-[5] mb-4 inline-flex h-14 w-14 items-center justify-center rounded-2xl border backdrop-blur-sm transition-transform duration-300 group-hover:scale-110',
          iconTile,
        )}
      >
        <Icon className={cn('h-8 w-8', iconText)} strokeWidth={1.5} />
      </span>

      {/* Titre serif + sous-titre */}
      <span className="relative z-[5] block">
        <span className="font-serif text-2xl font-bold text-white">{title}</span>
        <span className="mt-1.5 block text-sm leading-relaxed text-slate-400">{subtitle}</span>
      </span>

      {/* v4.51 — carte hôte : les 2 sous-espaces SOUS une fine ligne */}
      {subOptions && subOptions.length > 0 && (
        <span className="relative z-[5] mt-4 block border-t border-white/10 pt-4">
          {subOptions.map((o) => (
            <span key={o.label} className="mt-1.5 flex items-center gap-2.5 first:mt-0">
              <span aria-hidden="true" className="text-base leading-none">
                {o.emoji}
              </span>
              <span className="min-w-0">
                <span className="block text-sm font-semibold text-white/90">{o.label}</span>
                <span className="block truncate text-[11px] text-slate-400">{o.hint}</span>
              </span>
            </span>
          ))}
        </span>
      )}

      {/* Bouton « Entrer » plein (span stylée — la carte EST le bouton) */}
      <span
        aria-hidden="true"
        className={cn(
          'relative z-[5] mt-4 flex w-full items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold text-white transition-colors duration-300',
          ctaClass,
        )}
      >
        Entrer
        <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
      </span>
    </motion.button>
  );
}

/* ── Écran d'accueil immersif « EFFET WAHOU » ─────────────────── */

export function HeroLanding({
  propertyName,
  propertyTypeEmoji,
  propertyTypeLabel,
  ownerName,
  onGuestClick,
  onHostClick,
}: HeroLandingProps) {
  const reduceMotion = useReducedMotion();

  // Titre accordé — le nom du bien est mis en évidence (gradient or)
  // seulement s'il apparaît tel quel dans le titre accordé.
  const nameToken = propertyName.trim();
  const titleParts = welcomeTitle(propertyName).split(nameToken);

  return (
    <div className="flex-1 w-full">
      {/* ── FOND « EFFET WAHOU » (v4.51) — bg-slate-950 + 3 blobs de
          couleur flottants en absolute/blur-3xl/opacity-30, animés par
          Framer Motion très lentement (20 s). Les couches restent des
          enfants directs de la vue (aucun ancêtre transformé → fixed
          fiable) et -z-10 les glisse SOUS tout le contenu. ── */}
      <div aria-hidden="true" className="fixed inset-0 -z-10 overflow-hidden bg-slate-950">
        {/* Blob ambre — haut à gauche */}
        <FloatingBlob
          className="-top-40 -left-32 h-[30rem] w-[30rem] bg-amber-500"
          animate={{ x: [0, 60, -30, 0], y: [0, 40, -20, 0] }}
          duration={20}
          reduceMotion={reduceMotion}
        />
        {/* Blob émeraude — bas à droite */}
        <FloatingBlob
          className="-bottom-48 -right-36 h-[34rem] w-[34rem] bg-emerald-600"
          animate={{ x: [0, -70, 30, 0], y: [0, -50, 25, 0] }}
          duration={20}
          reduceMotion={reduceMotion}
          delay={2.5}
        />
        {/* 3ᵉ blob discret (contrepoint or, centre-bas) pour la profondeur */}
        <FloatingBlob
          className="bottom-1/4 left-1/3 h-72 w-72 bg-amber-600"
          animate={{ x: [0, 35, -25, 0], y: [0, -30, 20, 0] }}
          duration={20}
          reduceMotion={reduceMotion}
          delay={5}
        />
      </div>

      {/* ── CONTENU ──────────────────────────────────────────────── */}
      <div className="relative w-full max-w-md mx-auto min-h-dvh px-5 pt-7 pb-[calc(1.75rem+env(safe-area-inset-bottom))] flex flex-col md:max-w-xl">
        {/* Header — logo + FIX-16 ⚙️ (accès hôte rapide) — delay 0 */}
        <motion.header
          initial={{ opacity: 0, y: -18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: EASE_EXPO }}
          className="flex items-center justify-between"
        >
          <BrandLogo variant="light" size="sm" />
          <button
            type="button"
            onClick={onHostClick}
            aria-label="Paramètres hôte — ouvrir le mode hôte"
            className="h-11 w-11 inline-flex items-center justify-center rounded-xl border border-white/20 bg-white/10 text-white/70 backdrop-blur-md hover:border-white/35 hover:text-white active:scale-95 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
          >
            <Settings2 className="h-[18px] w-[18px]" aria-hidden="true" />
          </button>
        </motion.header>

        {/* Message d'accueil — cascade 0.1 → 0.3 s */}
        <section aria-label="Bienvenue" className="mt-12 text-center sm:mt-16">
          {/* Badge pill (0.1 s) */}
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1, ease: EASE_EXPO }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1 text-xs font-semibold text-amber-300 backdrop-blur-md"
          >
            ✨ Expérience Conciergerie
          </motion.p>

          {/* Titre principal — Playfair 4xl/5xl tracking-tight (0.2 s) */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2, ease: EASE_EXPO }}
            className="mb-4 font-serif text-4xl font-bold leading-[1.08] tracking-tight text-white md:text-5xl"
          >
            {titleParts.length > 1 ? (
              <>
                {titleParts[0]}
                <span className="text-gradient-lux">{nameToken}</span>
              </>
            ) : (
              welcomeTitle(propertyName)
            )}
          </motion.h1>

          {/* Message chaleureux (0.3 s) */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3, ease: EASE_EXPO }}
            className="mx-auto max-w-md text-center text-lg text-slate-400"
          >
            Nous avons tout préparé pour rendre votre séjour inoubliable.
          </motion.p>

          {/* Ligne de confiance (0.35 s) */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="mt-3 text-xs font-medium text-white/50"
          >
            {propertyTypeEmoji} {propertyTypeLabel} · Hub officiel du logement
          </motion.p>
        </section>

        {/* 2 cartes d'accès — cascade 0.4 / 0.5 s */}
        <div className="mt-10 grid gap-5 md:grid-cols-2 md:items-stretch">
          {/* CARTE MODE INVITÉ — verre + CTA émeraude */}
          <AccessCard
            tone="emerald"
            icon={User}
            iconTile="border-emerald-400/30 bg-emerald-500/15"
            iconText="text-emerald-300 drop-shadow-[0_0_18px_rgba(52,211,153,0.85)]"
            title="Mode Invité"
            subtitle="Wi-Fi, Guide, Services & Commandes"
            badge="Accès libre"
            delay={0.4}
            glowClass="hover:shadow-[0_28px_80px_-20px_rgba(16,185,129,0.45)]"
            ctaClass="bg-emerald-600 hover:bg-emerald-500"
            onClick={onGuestClick}
          />

          {/* CARTE MODE HÔTE — glow ambre + sous-espaces séparés + CTA ambre */}
          <AccessCard
            tone="amber"
            icon={Lock}
            iconTile="border-amber-400/30 bg-amber-500/15"
            iconText="text-amber-300 drop-shadow-[0_0_18px_rgba(251,191,36,0.9)]"
            title="Mode Hôte"
            subtitle="Deux espaces protégés, deux codes distincts"
            badge="2 espaces"
            delay={0.5}
            glowClass="shadow-[0_0_30px_-5px_rgba(245,158,11,0.15)] hover:shadow-[0_0_44px_-5px_rgba(245,158,11,0.32)]"
            ctaClass="bg-amber-600 hover:bg-amber-500"
            subOptions={[
              { emoji: '🔐', label: 'Hôte', hint: 'Code PIN du bien' },
              { emoji: '🧹', label: 'Ménage', hint: 'Code staff de l\u2019équipe' },
            ]}
            onClick={onHostClick}
          />
        </div>

        {/* Footer (0.7 s) */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="mt-auto pt-12 text-center"
        >
          <p className="text-xs text-slate-500">
            {ownerName ? `Votre hôte : ${ownerName} · ` : ''}Propulsé par{' '}
            <span className="font-semibold text-slate-400">Conciergerie Hub</span>
          </p>
        </motion.footer>
      </div>
    </div>
  );
}
