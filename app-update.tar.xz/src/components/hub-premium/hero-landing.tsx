'use client';

import { useState } from 'react';
import Image from 'next/image';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, Lock, Settings2, User } from 'lucide-react';
import { AnimatedMeshGradient } from '@/components/premium/animated-mesh-gradient';
import { BrandLogo } from '@/components/ui/brand-logo';
import { cn } from '@/lib/utils';

// =============================================================
// HUB PREMIUM « LUXE TECH » — HeroLanding (page d'entrée du hub QR)
//
// Refonte immersive complète de l'écran d'accueil :
//   • Fond photo « villa de luxe au crépuscule » (Option A) avec
//     overlay sombre en dégradé — fallback élégant : mesh gradient
//     animé (Option B) tant que la photo n'est pas chargée / si elle
//     échoue (le mesh est TOUJOURS rendu en dessous).
//   • Typographie Playfair Display (« display-title font-serif! ») :
//     eyebrow « ✨ Expérience Conciergerie », titre
//     « Bienvenue à la <Villa> » (article accordé automatiquement),
//     message chaleureux.
//   • 2 cartes d'accès glassmorphism (style Apple / Linear) :
//       – Mode Invité : verre blanc + glow émeraude + badge
//         « Accès libre », hover scale + ombre colorée.
//       – Mode Hôte : verre ambre + glow or + badge « Code PIN
//         requis », shimmer (reflet) en boucle.
//   • Chorégraphie d'entrée framer-motion :
//       fond 0 s → eyebrow 0.15 s → titre 0.2 s → message 0.3 s →
//       carte invité 0.4 s → carte hôte 0.6 s → footer 0.8 s.
//   • FIX-16 conservé : bouton ⚙️ d'accès hôte rapide (header).
//
// NB : la page est volontairement TOUJOURS sombre (immersive) — les
// vues invité/hôte conservent leur propre thème. Toute la logique
// (chargement payload, PIN, navigation) reste dans hub-content.tsx.
// =============================================================

/** Easing expo partagé (même signature que <Reveal/>). */
const EASE_EXPO = [0.16, 1, 0.3, 1] as const;

/** Image de fond par défaut (villa luxueuse) — servie depuis public/.
 *  Une vraie photo du bien remplacera ce fichier sans changement de code. */
const HERO_IMAGE = '/hub-hero-villa.jpg';

interface HeroLandingProps {
  propertyName: string;
  propertyTypeEmoji: string;
  propertyTypeLabel: string;
  ownerName: string | null;
  onGuestClick: () => void;
  onHostClick: () => void;
}

/**
 * Accorde l'article du titre d'accueil au nom du bien :
 *   « Villa Sarbacane » → « Bienvenue à la Villa Sarbacane »
 *   « Le Petit Nid »    → « Bienvenue au Petit Nid »
 *   « Les Oliviers »    → « Bienvenue aux Oliviers »
 *   « L'Atelier »       → « Bienvenue à l'Atelier »
 *   « Loft des Arts »   → « Bienvenue au Loft des Arts »
 */
function welcomeTitle(raw: string): string {
  const n = raw.trim();
  const l = n.toLowerCase();
  if (/^le\s/.test(l)) return `Bienvenue au ${n.slice(3)}`;
  if (/^les\s/.test(l)) return `Bienvenue aux ${n.slice(4)}`;
  if (/^l'/.test(l)) return `Bienvenue à l'${n.slice(2)}`;
  if (
    /^(loft|studio|chalet|gîte|gite|appartement|duplex|penthouse|bungalow|roulotte|tipi|mobile-home)\b/i.test(
      n,
    )
  ) {
    return `Bienvenue au ${n}`;
  }
  return `Bienvenue à la ${n}`;
}

/* ── Palettes des 2 cartes d'accès (glassmorphism sombre) ─────── */

type CardTone = 'emerald' | 'amber';

const TONES: Record<
  CardTone,
  { card: string; iconTile: string; icon: string; badge: string }
> = {
  emerald: {
    card: 'border-white/20 bg-white/10 hover:border-white/35 hover:shadow-[0_28px_80px_-20px_rgba(16,185,129,0.5)]',
    iconTile: 'border border-emerald-400/30 bg-emerald-500/15',
    icon: 'text-emerald-300 drop-shadow-[0_0_18px_rgba(52,211,153,0.85)]',
    badge: 'border-emerald-400/40 bg-emerald-500/20 text-emerald-100',
  },
  amber: {
    card: 'border-amber-500/30 bg-amber-500/10 hover:border-amber-400/50 hover:shadow-[0_28px_80px_-20px_rgba(245,158,11,0.5)]',
    iconTile: 'border border-amber-400/30 bg-amber-500/15',
    icon: 'text-amber-300 drop-shadow-[0_0_18px_rgba(251,191,36,0.9)]',
    badge: 'border-amber-400/40 bg-amber-500/20 text-amber-100',
  },
};

/* ── Carte d'accès premium (Mode Invité / Mode Hôte) ──────────── */

function AccessCard({
  tone,
  icon: Icon,
  title,
  subtitle,
  badge,
  delay,
  shimmer = false,
  pulseIcon = false,
  onClick,
}: {
  tone: CardTone;
  icon: typeof User;
  title: string;
  subtitle: string;
  badge: string;
  /** Délai d'entrée (chorégraphie d'accueil). */
  delay: number;
  /** Reflet qui traverse la carte en boucle (carte hôte). */
  shimmer?: boolean;
  /** Pulsation lente de l'icône (carte hôte). */
  pulseIcon?: boolean;
  onClick: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const t = TONES[tone];

  return (
    <motion.button
      type="button"
      onClick={onClick}
      aria-label={`${title} — ${badge}`}
      initial={{ opacity: 0, y: 34 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.75, delay, ease: EASE_EXPO }}
      whileHover={reduceMotion ? undefined : { scale: 1.04 }}
      whileTap={{ scale: 0.97 }}
      className={cn(
        'group relative w-full cursor-pointer overflow-hidden rounded-3xl p-6 text-left backdrop-blur-xl',
        'border shadow-[0_18px_50px_-18px_rgba(0,0,0,0.65)] transition-[border-color,box-shadow] duration-500',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-950',
        t.card,
        shimmer && 'shimmer-line',
      )}
    >
      {/* Badge pill translucide (haut-droite) */}
      <span
        className={cn(
          'absolute right-4 top-4 z-10 inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-semibold backdrop-blur-md',
          t.badge,
        )}
      >
        {badge}
      </span>

      {/* Icône 48 px en tuile + glow coloré */}
      <span className="relative z-[5] flex items-center gap-4 pr-16">
        <span
          aria-hidden="true"
          className={cn(
            'inline-flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl backdrop-blur-sm',
            tone === 'amber' && pulseIcon && !reduceMotion && 'animate-pulse-slow',
            t.iconTile,
          )}
        >
          <Icon className={cn('h-12 w-12', t.icon)} strokeWidth={1.5} />
        </span>
        <span className="min-w-0">
          {/* font-serif explicite : la var --font-playfair (next/font sur
              <body>) est résolue au niveau :root — voir ModeCard. */}
          <span className="display-title font-serif! block text-2xl font-bold text-white">
            {title}
          </span>
          <span className="mt-1 block text-sm text-white/70">{subtitle}</span>
        </span>
      </span>

      {/* CTA discret : Entrer → */}
      <span className="relative z-[5] mt-4 inline-flex items-center gap-2 text-sm font-semibold text-white/85">
        Entrer
        <ArrowRight
          className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          aria-hidden="true"
        />
      </span>
    </motion.button>
  );
}

/* ── Écran d'accueil immersif ─────────────────────────────────── */

export function HeroLanding({
  propertyName,
  propertyTypeEmoji,
  propertyTypeLabel,
  ownerName,
  onGuestClick,
  onHostClick,
}: HeroLandingProps) {
  const reduceMotion = useReducedMotion();
  // Photo de fond : fade-in au chargement, fallback mesh si échec.
  const [heroLoaded, setHeroLoaded] = useState(false);
  const [heroFailed, setHeroFailed] = useState(false);

  // Titre accordé — le nom du bien est mis en évidence (gradient or)
  // seulement s'il apparaît tel quel dans le titre accordé.
  const nameToken = propertyName.trim();
  const titleParts = welcomeTitle(propertyName).split(nameToken);

  return (
    <div className="flex-1 w-full">
      {/* ── FOND IMMERSIF (3 couches fixed -z-10, ordre DOM = ordre z) ──
          1. Base sombre (masque le dégradé clair de la page)
          2. Mesh animé (fallback élégant si la photo n'est pas là)
          3. Photo villa + overlays sombres (+ voile pendant le chargement)
          Les fonds restent des enfants directs de la vue (aucun ancêtre
          transformé → position: fixed fiable). */}
      <div aria-hidden="true" className="fixed inset-0 -z-10 bg-slate-950" />
      <AnimatedMeshGradient />

      <motion.div
        aria-hidden="true"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="fixed inset-0 -z-10 overflow-hidden"
      >
        {!heroFailed && (
          <>
            {/* Zoom très lent « Ken Burns » pour donner vie à la photo */}
            <motion.div
              className="absolute inset-0"
              animate={reduceMotion || !heroLoaded ? undefined : { scale: [1, 1.07] }}
              transition={
                reduceMotion
                  ? undefined
                  : { duration: 30, repeat: Infinity, repeatType: 'mirror', ease: 'easeInOut' }
              }
            >
              <Image
                src={HERO_IMAGE}
                alt=""
                fill
                priority
                unoptimized
                sizes="100vw"
                onLoad={() => setHeroLoaded(true)}
                onError={() => setHeroFailed(true)}
                className={cn(
                  'object-cover object-center transition-opacity duration-1000 ease-out',
                  heroLoaded ? 'opacity-100' : 'opacity-0',
                )}
              />
            </motion.div>

            {/* Overlays : dégradé vertical + vignette → lisibilité maximale */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/35 to-black/85" />
            <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_8%,transparent_38%,rgba(2,6,23,0.6)_100%)]" />

            {/* Voile pendant le chargement : laisse deviner le mesh */}
            {!heroLoaded && <div className="absolute inset-0 bg-slate-950/60" />}
          </>
        )}
      </motion.div>

      {/* ── CONTENU ──────────────────────────────────────────────── */}
      <div className="relative w-full max-w-md mx-auto min-h-dvh px-5 pt-7 pb-[calc(1.75rem+env(safe-area-inset-bottom))] flex flex-col">
        {/* Header — logo + FIX-16 ⚙️ (accès hôte rapide) — delay 0 */}
        <motion.header
          initial={{ opacity: 0, y: -18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: EASE_EXPO }}
          className="flex items-center justify-between"
        >
          <BrandLogo variant="light" size="sm" />
          <button
            type="button"
            onClick={onHostClick}
            aria-label="Paramètres hôte — ouvrir le mode hôte"
            className="h-11 w-11 inline-flex items-center justify-center rounded-xl border border-white/20 bg-white/10 text-white/70 backdrop-blur-md hover:border-white/35 hover:text-white active:scale-95 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
          >
            <Settings2 className="h-[18px] w-[18px]" aria-hidden="true" />
          </button>
        </motion.header>

        {/* Message d'accueil — chorégraphie 0.15 → 0.35 s */}
        <section aria-label="Bienvenue" className="mt-12 text-center sm:mt-16">
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15, ease: EASE_EXPO }}
            className="inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-white/10 px-4 py-1.5 text-xs font-medium tracking-wide text-white/80 backdrop-blur-md"
          >
            ✨ Expérience Conciergerie
          </motion.p>

          {/* Titre principal — Playfair, glisse du bas vers le haut (0.2 s) */}
          <motion.h1
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2, ease: EASE_EXPO }}
            className="display-title font-serif! mt-5 text-4xl font-bold leading-[1.08] text-white sm:text-5xl"
          >
            {titleParts.length > 1 ? (
              <>
                {titleParts[0]}
                <span className="text-gradient-lux">{nameToken}</span>
              </>
            ) : (
              welcomeTitle(propertyName)
            )}
          </motion.h1>

          {/* Message chaleureux (0.3 s) */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="mx-auto mt-4 max-w-xs text-[15px] leading-relaxed text-white/70"
          >
            Nous avons tout préparé pour rendre votre séjour inoubliable.
          </motion.p>

          {/* Ligne de confiance (0.35 s) */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.35 }}
            className="mt-3 text-xs font-medium text-white/50"
          >
            {propertyTypeEmoji} {propertyTypeLabel} · Hub officiel du logement
          </motion.p>
        </section>

        {/* 2 cartes d'accès — chorégraphie 0.4 / 0.6 s */}
        <div className="mt-10 grid gap-5">
          <AccessCard
            tone="emerald"
            icon={User}
            title="Mode Invité"
            subtitle="Wi-Fi, Guide, Services & Commandes"
            badge="Accès libre"
            delay={0.4}
            onClick={onGuestClick}
          />
          <AccessCard
            tone="amber"
            icon={Lock}
            title="Mode Hôte"
            subtitle="Gestion, Paramètres & Réclamations"
            badge="Code PIN requis"
            delay={0.6}
            shimmer
            pulseIcon
            onClick={onHostClick}
          />
        </div>

        {/* Footer — delay 0.8 s */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-auto pt-10 text-center"
        >
          <p className="text-xs text-white/40">
            {ownerName ? `Votre hôte : ${ownerName} · ` : ''}Propulsé par{' '}
            <span className="font-semibold text-white/55">Conciergerie Hub</span>
          </p>
        </motion.footer>
      </div>
    </div>
  );
}
