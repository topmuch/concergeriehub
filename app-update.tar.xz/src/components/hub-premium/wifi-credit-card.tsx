'use client';

import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Copy, Wifi } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { buildWifiQrString } from '@/lib/wifi-qr';

// =============================================================
// HUB PREMIUM « LUXE TECH » — WifiPremiumCard
// Module Wi-Fi du mode invité, style « carte de crédit premium » :
//   • fond gradient sombre slate-900 → slate-800, texte blanc
//   • puce EMV décorative (rectangle doré) en haut à gauche
//   • logo Wi-Fi en grand en haut à droite (opacité 20 %)
//   • SSID en font-serif text-2xl
//   • MOT DE PASSE À EFFET GRATTAGE : masque argenté (gradient
//     brillant + texture de points + reflet shimmer) qui se dissout
//     (scale + blur + fade) au clic/touch. État révélé mémorisé en
//     state LOCAL (revient au masque à chaque visite du hub).
//   • boutons copier (réseau + mot de passe) et QR d'auto-connexion
//     conservés — même logique métier que l'ancien panneau.
// =============================================================

const EASE_EXPO = [0.16, 1, 0.3, 1] as const;

interface WifiCredentials {
  networkName: string;
  password: string;
  securityType: string;
}

export function WifiPremiumCard({
  wifi,
  copy,
  delay = 0,
}: {
  wifi: WifiCredentials;
  /** Callback de copie du hub (toast inclus), inchangée. */
  copy: (text: string, label: string) => Promise<void>;
  delay?: number;
}) {
  // Effet grattage : état révélé mémorisé en state local.
  const [revealed, setRevealed] = useState(false);

  return (
    <motion.section
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.7, delay, ease: EASE_EXPO }}
      aria-label="Carte Wi-Fi — identifiants du logement"
      className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-slate-900 to-slate-800 p-5 text-white shadow-[0_24px_60px_-18px_rgba(2,6,23,0.55)] sm:p-6"
    >
      {/* Halos décoratifs (profondeur « carte bancaire ») */}
      <span aria-hidden="true" className="pointer-events-none absolute -right-16 -top-20 h-52 w-52 rounded-full bg-white/10 blur-3xl" />
      <span aria-hidden="true" className="pointer-events-none absolute -left-20 bottom-0 h-40 w-40 rounded-full bg-teal-400/10 blur-3xl" />

      {/* Rangée 1 : puce EMV + logo Wi-Fi géant translucide */}
      <div className="relative flex items-start justify-between">
        <span
          aria-hidden="true"
          className="relative mt-1 block h-9 w-12 overflow-hidden rounded-lg border border-amber-700/40 bg-gradient-to-br from-amber-200 via-yellow-400 to-amber-600 shadow-inner"
        >
          <span className="absolute inset-x-0 top-1/2 h-px bg-amber-900/30" />
          <span className="absolute inset-y-0 left-1/2 w-px bg-amber-900/30" />
        </span>
        <Wifi aria-hidden="true" className="-mr-2 -mt-2 h-20 w-20 text-white opacity-20" strokeWidth={1.5} />
      </div>

      {/* SSID — font-serif (cf. note mode-card.tsx : font-serif explicite) */}
      <p className="relative mt-3 text-[10px] font-bold uppercase tracking-[0.25em] text-white/50">
        Réseau Wi-Fi
      </p>
      <h3 className="display-title font-serif! relative text-2xl font-bold text-white">{wifi.networkName}</h3>
      <p className="relative mt-1.5 inline-flex items-center rounded-full border border-white/15 bg-white/10 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-white/70">
        {wifi.securityType || 'WPA2'}
      </p>

      {/* Mot de passe — zone à gratter */}
      <div className="relative mt-4">
        <p className="mb-1.5 text-[10px] font-bold uppercase tracking-[0.25em] text-white/50">
          Mot de passe
        </p>
        <div className="relative min-h-[56px] rounded-xl border border-white/15 bg-white/5">
          <AnimatePresence initial={false}>
            {!revealed && (
              <motion.button
                key="wifi-scratch-mask"
                type="button"
                onClick={() => setRevealed(true)}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 1.18, filter: 'blur(6px)' }}
                transition={{ duration: 0.45, ease: 'easeOut' }}
                aria-label="Révéler le mot de passe Wi-Fi"
                className="absolute inset-0 z-10 flex h-full min-h-[56px] w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl"
              >
                {/* Feuille argentée : gradient gris brillant + trame de points + reflet */}
                <span aria-hidden="true" className="absolute inset-0 bg-gradient-to-r from-slate-500 via-slate-200 to-slate-500" />
                <span aria-hidden="true" className="texture-dots absolute inset-0 opacity-30" />
                <span aria-hidden="true" className="shimmer-line absolute inset-0" />
                <span className="relative z-10 inline-flex items-center gap-2 rounded-full bg-slate-900/70 px-4 py-2 text-xs font-bold uppercase tracking-wider text-white backdrop-blur-sm">
                  👆 Toucher pour révéler
                </span>
              </motion.button>
            )}
            {revealed && (
              <motion.p
                key="wifi-password-value"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.08, ease: EASE_EXPO }}
                className="relative flex min-h-[56px] items-center justify-center break-all px-4 py-2 text-center font-mono text-lg font-semibold tracking-widest text-white sm:text-xl"
              >
                {wifi.password}
              </motion.p>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Actions copie (logique existante conservée) */}
      <div className="relative mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => void copy(wifi.networkName, 'Nom du réseau')}
          className="inline-flex h-11 min-w-[140px] flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 text-sm font-semibold text-white transition-colors duration-300 hover:bg-white/20 active:scale-[0.98]"
        >
          <Copy className="h-4 w-4" aria-hidden="true" /> Copier le réseau
        </button>
        <button
          type="button"
          onClick={() => void copy(wifi.password, 'Mot de passe Wi-Fi')}
          className="inline-flex h-11 min-w-[140px] flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl bg-white px-4 text-sm font-semibold text-slate-900 shadow-lg transition-colors duration-300 hover:bg-slate-100 active:scale-[0.98]"
        >
          <Copy className="h-4 w-4" aria-hidden="true" /> Copier le mot de passe
        </button>
      </div>

      {/* QR d'auto-connexion (standard WIFI:, générateur partagé) */}
      <div className="relative mt-4 flex flex-col items-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-4 py-4">
        <span className="rounded-xl bg-white p-2 shadow-sm">
          <QRCodeSVG
            value={buildWifiQrString(wifi.networkName, wifi.password, wifi.securityType)}
            size={116}
            bgColor="#FFFFFF"
            fgColor="#0F172A"
            level="M"
            aria-hidden="true"
          />
        </span>
        <p className="text-center text-[11px] leading-snug text-white/70">
          Scannez ce code avec l&apos;appareil photo pour rejoindre le réseau automatiquement
        </p>
      </div>
    </motion.section>
  );
}
