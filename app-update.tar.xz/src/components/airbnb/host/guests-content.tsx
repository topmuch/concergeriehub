'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Check, ChevronDown, Copy, FileText, Link2, Search } from 'lucide-react';
import { toast } from 'sonner';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { KPICard } from '@/components/airbnb/host/kpi-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';

// =============================================================
// GuestsContent — onglet « Invités » du Dashboard Client (mini-CRM)
// v4.80 — REFAONTE « ENGAGEANTE » (demande client) :
//   • 2 VUES : « Séjours » (historique complet par séjour) et
//     « États des lieux » (tous les documents signés) ;
//   • vue États des lieux : chaque document affiche NOM du client,
//     DATE de signature, NOMBRE DE JOURS du séjour, LIEN WEB public
//     et PDF — exactement ce que l'hôte doit retrouver ;
//   • 5 KPIs (séjours, en cours, EDL signés, EDL à venir, CA) ;
//   • cartes séjours expandables : commandes minibar/pressing,
//     états des lieux (entrée + sortie, PDF + preuve publique),
//     ménages associés par fenêtre de dates, livre d'or.
// Design : tokens shadcn + .air-gradient/.air-shadow (bleu #0066EF).
// =============================================================

// ----- Types (miroir du payload /api/airbnb/guests) -----

interface MinibarItemLite {
  name: string;
  qty: number;
}

interface GuestMinibarOrder {
  id: string;
  items: MinibarItemLite[];
  totalEur: number;
  payment: string;
  status: string;
  createdAt: string;
}

interface GuestLaundryOrder {
  id: string;
  serviceType: string;
  pieces: number;
  pickupSlot: string;
  amountEur: number;
  payment: string;
  status: string;
  createdAt: string;
}

interface GuestInspection {
  id: string;
  publicToken: string;
  signedAt: string;
  guestName: string;
  status: string;
  selfAssessment: number;
  /** v4.80 — 'checkin' = état des lieux d'ARRIVÉE | 'checkout' = SORTIE. */
  type: 'checkin' | 'checkout';
  hasDamages: boolean;
}

interface GuestCheckoutReport {
  id: string;
  minibarTotal: number;
  signalementsCount: number;
  departedAt: string | null;
  cleaningValidatedAt: string | null;
  restockPending: boolean;
}

interface GuestMemory {
  id: string;
  guestName: string;
  rating: number;
  message: string | null;
  isApproved: boolean;
  isPublic: boolean;
  hostReply: string | null;
  createdAt: string;
}

interface GuestMiddleStay {
  id: string;
  requestType: string;
  status: string;
  details: string | null;
  createdAt: string;
}

interface GuestBooking {
  id: string;
  propertyId: string;
  propertyName: string | null;
  guestName: string | null;
  guestEmail: string | null;
  checkIn: string;
  checkOut: string;
  guests: number;
  source: string;
  status: string;
  accessCode: string | null;
  minibarOrders: GuestMinibarOrder[];
  laundryOrders: GuestLaundryOrder[];
  checkOutInspections: GuestInspection[];
  checkoutReports: GuestCheckoutReport[];
  guestMemories: GuestMemory[];
  middleStayRequests: GuestMiddleStay[];
}

interface CleaningLite {
  id: string;
  staffName: string | null;
  startedAt: string | null;
  endedAt: string | null;
  checklistDone: number;
  checklistTotal: number;
  photosCount: number;
}

type GuestsApiResponse = {
  bookings: GuestBooking[];
  cleaningByProperty: Record<string, CleaningLite[]>;
};

// ----- Métadonnées d'affichage -----

/** Badges statut séjour — dark-safe (pattern LAUNDRY_STATUS_HOST_META). */
const BOOKING_STATUS_META: Record<string, { label: string; className: string }> = {
  CONFIRMED: {
    label: 'Confirmé',
    className:
      'bg-primary/10 text-primary border-primary/25 dark:bg-primary/15 dark:text-primary',
  },
  CHECKED_IN: {
    label: 'En cours',
    className:
      'bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-500/30',
  },
  CHECKED_OUT: {
    label: 'Parti',
    className:
      'bg-muted text-muted-foreground border-border',
  },
  CANCELLED: {
    label: 'Annulé',
    className:
      'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-500/30',
  },
};

const SOURCE_LABELS: Record<string, string> = {
  MANUAL: 'Manuel',
  AIRBNB: 'Airbnb',
  BOOKING: 'Booking.com',
  ICAL: 'iCal',
};

const LAUNDRY_STATUS_LABELS: Record<string, string> = {
  PENDING_PAYMENT: 'Paiement en cours',
  REQUESTED: 'Demandée',
  PAID: 'Réglée',
  IN_PROGRESS: 'En cours',
  READY: 'Prête à livrer',
  DELIVERED: 'Livrée',
  CANCELLED: 'Annulée',
};

const LAUNDRY_TYPE_LABELS: Record<string, string> = {
  ironing: 'Repassage express',
  washing: 'Lessive complète',
  drycleaning: 'Pressing à sec',
};

const INSPECTION_STATUS_LABELS: Record<string, string> = {
  pending: 'En attente de traitement',
  reviewed: 'Examiné',
  resolved: 'Résolu',
  disputed: 'Contesté',
};

const MIDDLE_STAY_LABELS: Record<string, string> = {
  restock: 'Réassort',
  cleaning: 'Ménage en cours de séjour',
};

const MIDDLE_STAY_STATUS_LABELS: Record<string, string> = {
  pending: 'En attente',
  in_progress: 'En cours',
  completed: 'Traité',
};

const STATUS_FILTERS: { value: string; label: string }[] = [
  { value: 'all', label: 'Tous' },
  { value: 'CONFIRMED', label: 'Confirmés' },
  { value: 'CHECKED_IN', label: 'En cours' },
  { value: 'CHECKED_OUT', label: 'Partis' },
  { value: 'CANCELLED', label: 'Annulés' },
];

const DAY_MS = 86_400_000;

/** v4.80 — méta par TYPE d'état des lieux (entrée = émeraude, sortie = ambre). */
const INSPECTION_TYPE_META: Record<
  'checkin' | 'checkout',
  { label: string; emoji: string; pill: string; band: string }
> = {
  checkin: {
    label: 'Arrivée',
    emoji: '🏠',
    pill: 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300',
    band: 'bg-gradient-to-r from-emerald-500 to-teal-500',
  },
  checkout: {
    label: 'Départ',
    emoji: '🚪',
    pill: 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-950/40 dark:text-amber-300',
    band: 'bg-gradient-to-r from-amber-500 to-orange-500',
  },
};

// ----- Helpers -----

function normalizeText(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function initialsOf(name: string | null): string {
  const clean = name?.trim();
  if (!clean) return '?';
  return (
    clean
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || '?'
  );
}

function nightsBetween(checkIn: string, checkOut: string): number {
  const ci = new Date(checkIn).getTime();
  const co = new Date(checkOut).getTime();
  if (Number.isNaN(ci) || Number.isNaN(co)) return 0;
  return Math.max(1, Math.ceil((co - ci) / DAY_MS));
}

const fmtDayMonth = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short' });
const fmtFullDate = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' });
const fmtTime = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });

function safeDate(iso: string | null): Date | null {
  if (!iso) return null;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d;
}

function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);
}

function minibarItemsLabel(items: MinibarItemLite[]): string {
  if (items.length === 0) return 'Commande';
  return items.map((it) => `${it.qty} × ${it.name}`).join(', ');
}

async function copyText(value: string, label: string) {
  try {
    await navigator.clipboard.writeText(value);
    toast.success(label);
  } catch {
    toast.error('Copie impossible sur ce navigateur');
  }
}

// =============================================================
// CARTE ÉTAT DES LIEUX — vue dédiée (v4.80, demande client :
// « lien web, PDF, nom du client, date et nombre de jours »)
// =============================================================

function InspectionCard({ row }: { row: InspectionRow }) {
  const meta = INSPECTION_TYPE_META[row.inspection.type];
  const signedAt = safeDate(row.inspection.signedAt);
  const checkIn = safeDate(row.booking.checkIn);
  const checkOut = safeDate(row.booking.checkOut);
  const nights = nightsBetween(row.booking.checkIn, row.booking.checkOut);
  const publicUrl = `/public/inspection/${encodeURIComponent(row.inspection.publicToken)}`;
  const pdfUrl = `/api/public/inspection/${encodeURIComponent(row.inspection.publicToken)}/pdf`;

  return (
    <article
      className={cn(
        'air-shadow flex min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-card transition-shadow hover:shadow-md',
      )}
      aria-label={`État des lieux ${meta.label} de ${row.inspection.guestName || 'invité'}`}
    >
      {/* Bandeau couleur par type */}
      <div className={cn('h-1.5 w-full', meta.band)} aria-hidden="true" />

      <div className="flex min-w-0 flex-col gap-3 p-4 sm:p-5">
        {/* En-tête : avatar + nom + pill type */}
        <div className="flex items-start gap-3">
          <span
            aria-hidden="true"
            className="air-gradient flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-sm font-extrabold text-white shadow"
          >
            {initialsOf(row.inspection.guestName || row.booking.guestName)}
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-bold text-foreground">
              {row.inspection.guestName?.trim() || row.booking.guestName?.trim() || 'Invité'}
            </h3>
            <p className="mt-0.5 truncate text-xs text-muted-foreground">
              🏠 {row.booking.propertyName ?? 'Bien'}
            </p>
          </div>
          <span
            className={cn(
              'inline-flex shrink-0 items-center rounded-full border px-2.5 py-0.5 text-[11px] font-bold',
              meta.pill,
            )}
          >
            {meta.emoji} {meta.label}
          </span>
        </div>

        {/* Infos demandées : date + durée + statut */}
        <div className="grid grid-cols-2 gap-2 rounded-xl border border-border bg-secondary/60 p-3 text-xs">
          <div>
            <p className="font-semibold uppercase tracking-wide text-muted-foreground">Signé le</p>
            <p className="mt-0.5 font-bold text-foreground">
              {signedAt ? fmtFullDate.format(signedAt) : '—'}
              {signedAt ? ` · ${fmtTime.format(signedAt)}` : ''}
            </p>
          </div>
          <div>
            <p className="font-semibold uppercase tracking-wide text-muted-foreground">Séjour</p>
            <p className="mt-0.5 font-bold text-foreground">
              {checkIn && checkOut
                ? `${nights} jour${nights > 1 ? 's' : ''}`
                : '—'}
              {checkIn && checkOut ? (
                <span className="ml-1 font-medium text-muted-foreground">
                  ({fmtDayMonth.format(checkIn)} → {fmtDayMonth.format(checkOut)})
                </span>
              ) : null}
            </p>
          </div>
          <div className="col-span-2 flex flex-wrap items-center gap-1.5">
            <span
              className={cn(
                'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-bold',
                row.booking.status === 'CHECKED_IN'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300'
                  : 'border-border bg-muted text-muted-foreground',
              )}
            >
              {BOOKING_STATUS_META[row.booking.status]?.label ?? row.booking.status}
            </span>
            {row.inspection.hasDamages && (
              <span className="inline-flex items-center rounded-full border border-rose-200 bg-rose-50 px-2 py-0.5 text-[10px] font-bold text-rose-700 dark:border-rose-500/30 dark:bg-rose-950/40 dark:text-rose-300">
                ⚠️ Dégâts signalés
              </span>
            )}
            {row.inspection.type === 'checkout' && (
              <span className="inline-flex items-center rounded-full border border-border bg-muted px-2 py-0.5 text-[10px] font-bold text-muted-foreground">
                ⭐ {row.inspection.selfAssessment}/5
              </span>
            )}
            <span className="inline-flex items-center rounded-full border border-border bg-muted px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">
              {INSPECTION_STATUS_LABELS[row.inspection.status] ?? row.inspection.status}
            </span>
          </div>
        </div>

        {/* Actions : LIEN WEB + PDF (demande client) */}
        <div className="flex flex-wrap items-center gap-2">
          <a
            href={publicUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full border border-primary/30 bg-primary/5 px-3 text-[11px] font-bold text-primary transition-colors hover:bg-primary/10"
            aria-label="Ouvrir le lien web public de l'état des lieux"
          >
            <Link2 className="h-3.5 w-3.5" aria-hidden="true" />
            Lien web public
          </a>
          <a
            href={pdfUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-9 flex-1 items-center justify-center gap-1.5 rounded-full border border-emerald-300 bg-emerald-50 px-3 text-[11px] font-bold text-emerald-800 transition-colors hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300 dark:hover:bg-emerald-500/20"
            aria-label="Ouvrir le PDF de l'état des lieux"
          >
            <FileText className="h-3.5 w-3.5" aria-hidden="true" />
            PDF signé
          </a>
          <button
            type="button"
            onClick={() => void copyText(publicUrl, 'Lien public copié')}
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border bg-background text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            aria-label="Copier le lien public"
          >
            <Copy className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>
    </article>
  );
}

/** Ligne aplatie séjour + inspection (vue États des lieux). */
interface InspectionRow {
  booking: GuestBooking;
  inspection: GuestInspection;
}

// =============================================================
// Carte séjour expandable
// =============================================================

function StayCard({
  booking,
  cleanings,
  expanded,
  onToggle,
}: {
  booking: GuestBooking;
  cleanings: CleaningLite[];
  expanded: boolean;
  onToggle: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const statusMeta = BOOKING_STATUS_META[booking.status] ?? {
    label: booking.status,
    className: 'bg-muted text-muted-foreground border-border',
  };
  const nights = nightsBetween(booking.checkIn, booking.checkOut);
  const checkInDate = safeDate(booking.checkIn);
  const checkOutDate = safeDate(booking.checkOut);
  const hasCheckin = booking.checkOutInspections.some((i) => i.type === 'checkin');
  const hasCheckout = booking.checkOutInspections.some((i) => i.type === 'checkout');

  const copyAccessCode = async () => {
    if (!booking.accessCode) return;
    await copyText(booking.accessCode, 'Code d\'accès copié');
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  return (
    <article
      className={cn(
        'air-shadow flex min-w-0 flex-col gap-3 rounded-2xl border border-border bg-card p-4 transition-shadow sm:p-5',
        expanded && 'ring-1 ring-primary/30',
      )}
      aria-label={`Séjour de ${booking.guestName ?? 'invité'} du ${checkInDate ? fmtFullDate.format(checkInDate) : '—'}`}
    >
      {/* ---------- En-tête : avatar + identité + dates ---------- */}
      <div className="flex items-start gap-3">
        <span
          aria-hidden="true"
          className="air-gradient flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-sm font-extrabold text-white shadow"
        >
          {initialsOf(booking.guestName)}
        </span>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-bold text-foreground">
            {booking.guestName?.trim() || 'Invité'}
          </h3>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            {checkInDate && checkOutDate
              ? `${fmtDayMonth.format(checkInDate)} → ${fmtFullDate.format(checkOutDate)} · ${nights} nuit${nights > 1 ? 's' : ''}`
              : 'Dates indisponibles'}
          </p>
          <p className="mt-0.5 truncate text-xs text-muted-foreground">
            🏠 {booking.propertyName ?? 'Bien'}
          </p>
        </div>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="h-9 w-9 shrink-0 rounded-full hover:bg-black/5 dark:hover:bg-white/10"
          onClick={onToggle}
          aria-expanded={expanded}
          aria-label={expanded ? 'Replier le détail du séjour' : 'Déplier le détail du séjour'}
        >
          <ChevronDown
            className={cn('h-5 w-5 text-muted-foreground transition-transform', expanded && 'rotate-180')}
            aria-hidden="true"
          />
        </Button>
      </div>

      {/* ---------- Badges : statut + source + voyageurs + EDL ---------- */}
      <div className="flex min-w-0 flex-wrap items-center gap-1.5">
        <span
          className={cn(
            'inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-bold',
            statusMeta.className,
          )}
        >
          {statusMeta.label}
        </span>
        <span className="inline-flex items-center rounded-full border border-border bg-muted px-2.5 py-0.5 text-[11px] font-semibold text-muted-foreground">
          {SOURCE_LABELS[booking.source] ?? booking.source}
        </span>
        <span className="inline-flex items-center rounded-full border border-border bg-muted px-2.5 py-0.5 text-[11px] font-semibold text-muted-foreground">
          👥 {booking.guests} voyageur{booking.guests > 1 ? 's' : ''}
        </span>
        {hasCheckin && (
          <span className="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300">
            🏠 EDL arrivée ✓
          </span>
        )}
        {hasCheckout && (
          <span className="inline-flex items-center rounded-full border border-amber-200 bg-amber-50 px-2.5 py-0.5 text-[11px] font-semibold text-amber-800 dark:border-amber-500/30 dark:bg-amber-950/40 dark:text-amber-300">
            🚪 EDL départ ✓
          </span>
        )}
      </div>

      {/* ---------- Code d'accès ---------- */}
      {booking.accessCode && (
        <div className="flex items-center gap-2 rounded-xl border border-border bg-secondary px-3 py-2">
          <span className="text-xs font-medium text-muted-foreground">Code d&apos;accès</span>
          <code className="min-w-0 flex-1 truncate font-mono text-sm font-bold tracking-widest text-foreground">
            {booking.accessCode}
          </code>
          <button
            type="button"
            onClick={() => void copyAccessCode()}
            className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-black/5 hover:text-foreground dark:hover:bg-white/10"
            aria-label="Copier le code d'accès"
          >
            {copied ? (
              <Check className="h-4 w-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
            ) : (
              <Copy className="h-4 w-4" aria-hidden="true" />
            )}
          </button>
        </div>
      )}

      {/* ---------- Détail expandable : 4 blocs ---------- */}
      {expanded && (
        <div className="mt-1 grid grid-cols-1 gap-4 border-t border-border pt-4 md:grid-cols-2">
          {/* 📦 Commandes */}
          <StayOrdersBlock booking={booking} />

          {/* 📄 États des lieux */}
          <StayInspectionsBlock booking={booking} />

          {/* 🧹 Ménages */}
          <StayCleaningsBlock cleanings={cleanings} />

          {/* 📖 Livre d'or */}
          <StayMemoriesBlock booking={booking} />
        </div>
      )}
    </article>
  );
}

// -------------------------------------------------------------
// Bloc 📦 Commandes (minibar + pressing)
// -------------------------------------------------------------
function StayOrdersBlock({ booking }: { booking: GuestBooking }) {
  const hasMinibar = booking.minibarOrders.length > 0;
  const hasLaundry = booking.laundryOrders.length > 0;

  return (
    <section className="rounded-xl border border-border bg-secondary/60 p-3" aria-label="Commandes du séjour">
      <h4 className="text-sm font-bold text-foreground">
        <span aria-hidden="true">📦</span> Commandes
      </h4>
      {!hasMinibar && !hasLaundry ? (
        <p className="mt-2 text-xs text-muted-foreground">Aucune commande sur ce séjour.</p>
      ) : (
        <ul className="mt-2 flex flex-col gap-2">
          {booking.minibarOrders.map((o) => (
            <li key={o.id} className="flex items-start justify-between gap-2 text-xs">
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-foreground" title={minibarItemsLabel(o.items)}>
                  🍷 {minibarItemsLabel(o.items)}
                </p>
                <p className="text-muted-foreground">
                  {o.payment === 'stripe' ? 'Paiement en ligne' : 'Sur place'}
                  {' · '}
                  {safeDate(o.createdAt) ? fmtFullDate.format(safeDate(o.createdAt)!) : ''}
                </p>
              </div>
              <span className="flex shrink-0 flex-col items-end gap-0.5">
                <span className="font-bold text-foreground">{formatEur(o.totalEur)}</span>
                <span
                  className={cn(
                    'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-bold',
                    o.status === 'PAID'
                      ? 'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300'
                      : 'border-amber-200 bg-amber-50 text-amber-800 dark:border-amber-500/30 dark:bg-amber-950/40 dark:text-amber-300',
                  )}
                >
                  {o.status === 'PAID' ? 'Payée' : 'À régler'}
                </span>
              </span>
            </li>
          ))}
          {booking.laundryOrders.map((o) => (
            <li key={o.id} className="flex items-start justify-between gap-2 text-xs">
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-foreground">
                  👕 {LAUNDRY_TYPE_LABELS[o.serviceType] ?? o.serviceType} · {o.pieces} pièce{o.pieces > 1 ? 's' : ''}
                </p>
                <p className="text-muted-foreground">
                  Retrait {o.pickupSlot === 'morning' ? 'matin' : 'après-midi'}
                  {' · '}
                  {LAUNDRY_STATUS_LABELS[o.status] ?? o.status}
                </p>
              </div>
              <span className="shrink-0 font-bold text-foreground">{formatEur(o.amountEur)}</span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

// -------------------------------------------------------------
// Bloc 📄 États des lieux (liens PDF + preuve publique, par type)
// -------------------------------------------------------------
function StayInspectionsBlock({ booking }: { booking: GuestBooking }) {
  const nights = nightsBetween(booking.checkIn, booking.checkOut);
  return (
    <section className="rounded-xl border border-border bg-secondary/60 p-3" aria-label="États des lieux du séjour">
      <h4 className="text-sm font-bold text-foreground">
        <span aria-hidden="true">📄</span> États des lieux
        <span className="ml-1.5 text-xs font-medium text-muted-foreground">
          · {nights} jour{nights > 1 ? 's' : ''}
        </span>
      </h4>
      {booking.checkOutInspections.length === 0 ? (
        <p className="mt-2 text-xs text-muted-foreground">
          Pas encore d&apos;état des lieu signé — l&apos;invité le signe depuis le Hub (arrivée et/ou départ).
        </p>
      ) : (
        <ul className="mt-2 flex flex-col gap-2.5">
          {booking.checkOutInspections.map((i) => {
            const meta = INSPECTION_TYPE_META[i.type];
            const signed = safeDate(i.signedAt);
            return (
              <li key={i.id} className="flex flex-col gap-1 rounded-lg border border-border bg-background/60 p-2.5 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate font-semibold text-foreground">
                    <span
                      className={cn(
                        'mr-1.5 inline-flex items-center rounded-full border px-1.5 py-0.5 text-[10px] font-bold',
                        meta.pill,
                      )}
                    >
                      {meta.emoji} {meta.label}
                    </span>
                    {i.guestName || 'Invité'}
                  </span>
                  <span className="shrink-0 text-muted-foreground">
                    {signed ? fmtFullDate.format(signed) : ''}
                  </span>
                </div>
                <p className="text-muted-foreground">
                  {INSPECTION_STATUS_LABELS[i.status] ?? i.status}
                  {i.type === 'checkout' ? ` · ⭐ ${i.selfAssessment}/5` : ''}
                  {i.hasDamages ? ' · ⚠️ Dégâts signalés' : ''}
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  <a
                    href={`/api/public/inspection/${encodeURIComponent(i.publicToken)}/pdf`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-8 items-center rounded-full border border-border bg-background px-3 text-[11px] font-semibold text-primary transition-colors hover:bg-primary/10"
                    aria-label="Ouvrir le PDF de l'état des lieux"
                  >
                    📄 Ouvrir le PDF
                  </a>
                  <a
                    href={`/public/inspection/${encodeURIComponent(i.publicToken)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-8 items-center rounded-full border border-border bg-background px-3 text-[11px] font-semibold text-foreground transition-colors hover:bg-muted"
                    aria-label="Voir la preuve publique de l'état des lieux"
                  >
                    🔗 Voir la preuve
                  </a>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

// -------------------------------------------------------------
// Bloc 🧹 Ménages (fenêtre [checkIn − 1 j ; checkOut + 1 j])
// -------------------------------------------------------------
function StayCleaningsBlock({ cleanings }: { cleanings: CleaningLite[] }) {
  return (
    <section className="rounded-xl border border-border bg-secondary/60 p-3" aria-label="Ménages autour du séjour">
      <h4 className="text-sm font-bold text-foreground">
        <span aria-hidden="true">🧹</span> Ménages
      </h4>
      {cleanings.length === 0 ? (
        <p className="mt-2 text-xs text-muted-foreground">Aucun ménage enregistré sur cette période.</p>
      ) : (
        <ul className="mt-2 flex flex-col gap-2 text-xs">
          {cleanings.slice(0, 4).map((c) => {
            const start = safeDate(c.startedAt);
            const end = safeDate(c.endedAt);
            return (
              <li key={c.id} className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-foreground">
                    {c.staffName?.trim() || 'Équipe ménage'}
                  </p>
                  <p className="text-muted-foreground">
                    {start ? `${fmtFullDate.format(start)} · ${fmtTime.format(start)}` : '—'}
                    {end ? ` → ${fmtTime.format(end)}` : ''}
                  </p>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-0.5 text-[10px] text-muted-foreground">
                  {c.checklistTotal > 0 && (
                    <span>
                      ✅ {c.checklistDone}/{c.checklistTotal}
                    </span>
                  )}
                  <span>
                    📷 {c.photosCount} photo{c.photosCount > 1 ? 's' : ''}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

// -------------------------------------------------------------
// Bloc 📖 Livre d'or (souvenirs rattachés au séjour)
// -------------------------------------------------------------
function StayMemoriesBlock({ booking }: { booking: GuestBooking }) {
  return (
    <section className="rounded-xl border border-border bg-secondary/60 p-3" aria-label="Livre d'or du séjour">
      <h4 className="text-sm font-bold text-foreground">
        <span aria-hidden="true">📖</span> Livre d&apos;or
      </h4>
      {booking.guestMemories.length === 0 ? (
        <p className="mt-2 text-xs text-muted-foreground">Aucun souvenir laissé pour ce séjour.</p>
      ) : (
        <ul className="mt-2 flex flex-col gap-2.5 text-xs">
          {booking.guestMemories.map((m) => (
            <li key={m.id} className="flex flex-col gap-1">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate font-semibold text-foreground">{m.guestName || 'Invité'}</span>
                <span className="shrink-0 text-amber-500 dark:text-amber-400" aria-label={`Note ${m.rating} sur 5`}>
                  {'⭐'.repeat(Math.min(5, Math.max(0, m.rating)))}
                  <span className="ml-1 text-muted-foreground">{m.rating}/5</span>
                </span>
              </div>
              {m.message && (
                <p className="line-clamp-2 text-muted-foreground" title={m.message}>
                  « {m.message} »
                </p>
              )}
              {m.hostReply && (
                <p className="rounded-lg bg-background px-2 py-1 text-muted-foreground">
                  <span className="font-semibold text-foreground">Réponse de l&apos;hôte :</span> {m.hostReply}
                </p>
              )}
              {!m.isApproved && (
                <span className="inline-flex w-fit items-center rounded-full border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10px] font-bold text-amber-800 dark:border-amber-500/30 dark:bg-amber-950/40 dark:text-amber-300">
                  En attente de modération
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

// =============================================================
// Conteneur de page
// =============================================================
export function GuestsContent() {
  const { properties, selectedId, setSelectedId, propertiesLoading } = useHostContext();

  const [data, setData] = useState<GuestsApiResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'checkin' | 'checkout'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  // v4.80 — 2 vues : « Séjours » (historique) | « États des lieux » (documents).
  const [view, setView] = useState<'stays' | 'inspections'>('stays');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/airbnb/guests', { cache: 'no-store' });
      if (!res.ok) {
        const j = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(j.error || `HTTP ${res.status}`);
      }
      const payload = (await res.json()) as GuestsApiResponse;
      setData({ bookings: payload.bookings ?? [], cleaningByProperty: payload.cleaningByProperty ?? {} });
    } catch (err) {
      console.error('[GuestsContent] fetch failed:', err);
      setError('Impossible de charger les séjours. Réessayez dans un instant.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // ----- Filtres client-side -----
  const bookings = data?.bookings ?? [];

  const filtered = useMemo(() => {
    const q = normalizeText(search.trim());
    return bookings.filter((b) => {
      if (selectedId !== 'all' && b.propertyId !== selectedId) return false;
      if (view === 'stays' && statusFilter !== 'all' && b.status !== statusFilter) return false;
      if (q) {
        const haystack = normalizeText(`${b.guestName ?? ''} ${b.guestEmail ?? ''} ${b.propertyName ?? ''}`);
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [bookings, selectedId, statusFilter, search, view]);

  // v4.80 — vue « États des lieux » : toutes les inspections aplaties
  // (séjour + document), triées par signature la plus récente.
  const inspectionRows = useMemo(() => {
    const rows: InspectionRow[] = [];
    for (const b of filtered) {
      for (const i of b.checkOutInspections) {
        rows.push({ booking: b, inspection: i });
      }
    }
    rows.sort(
      (a, b2) =>
        new Date(b2.inspection.signedAt).getTime() - new Date(a.inspection.signedAt).getTime(),
    );
    return rows.filter((r) => typeFilter === 'all' || r.inspection.type === typeFilter);
  }, [filtered, typeFilter]);

  // ----- KPIs (sur la liste filtrée) -----
  const stats = useMemo(() => {
    const inProgress = filtered.filter((b) => b.status === 'CHECKED_IN').length;
    const inspections = filtered.reduce((sum, b) => sum + b.checkOutInspections.length, 0);
    const revenue = filtered.reduce((sum, b) => {
      const minibar = b.minibarOrders.reduce((s, o) => s + o.totalEur, 0);
      const laundry = b.laundryOrders
        .filter((o) => o.status !== 'CANCELLED')
        .reduce((s, o) => s + o.amountEur, 0);
      return sum + minibar + laundry;
    }, 0);
    return { total: filtered.length, inProgress, inspections, revenue };
  }, [filtered]);

  // Ménages associés à un séjour : du bien, dont startedAt tombe dans
  // la fenêtre [checkIn − 1 j ; checkOut + 1 j] (pas de bookingId côté
  // CleaningReport — association par dates, cf. route API).
  const cleaningsFor = useCallback(
    (booking: GuestBooking): CleaningLite[] => {
      const pool = data?.cleaningByProperty[booking.propertyId] ?? [];
      const ci = safeDate(booking.checkIn);
      const co = safeDate(booking.checkOut);
      if (!ci || !co) return [];
      const from = ci.getTime() - DAY_MS;
      const to = co.getTime() + DAY_MS;
      return pool.filter((c) => {
        const started = safeDate(c.startedAt);
        if (!started) return false;
        return started.getTime() >= from && started.getTime() <= to;
      });
    },
    [data],
  );

  const hasProperties = properties.length > 0;
  const totalInspections = bookings
    .filter((b) => selectedId === 'all' || b.propertyId === selectedId)
    .reduce((sum, b) => sum + b.checkOutInspections.length, 0);

  return (
    <div className="flex min-w-0 flex-col gap-6">
      {/* ---------- En-tête ---------- */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            <span aria-hidden="true">🧑‍🤝‍🧑</span> Invités
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Séjours, commandes, états des lieux signés et livre d&apos;or — tout au même endroit.
          </p>
        </div>
        {/* Filtre bien — partagé avec le sélecteur du header (useHostContext) */}
        {!propertiesLoading && hasProperties && (
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger
              className="h-9 w-full rounded-full border-border bg-background text-sm font-semibold sm:w-56"
              aria-label="Filtrer par bien"
            >
              <SelectValue placeholder="Tous les biens" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tous les biens</SelectItem>
              {properties.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* ---------- Erreur API ---------- */}
      {error && (
        <div
          className="air-empty flex flex-col gap-3 rounded-2xl px-4 py-3 sm:flex-row sm:items-center"
          role="alert"
        >
          <span aria-hidden="true" className="air-float text-2xl">⚠️</span>
          <p className="min-w-0 flex-1 text-sm font-medium text-rose-800 dark:text-rose-300">{error}</p>
          <Button
            type="button"
            variant="outline"
            className="shrink-0 rounded-full border-border"
            onClick={() => void load()}
          >
            Réessayer
          </Button>
        </div>
      )}

      {/* ---------- v4.80 — Bascule de vue « Séjours | États des lieux » ---------- */}
      <div
        className="grid w-full max-w-xl grid-cols-2 gap-1.5 rounded-2xl border border-border bg-secondary/60 p-1.5"
        role="tablist"
        aria-label="Choisir la vue"
      >
        {(
          [
            { key: 'stays' as const, label: '🧳 Séjours', count: bookings.filter((b) => selectedId === 'all' || b.propertyId === selectedId).length },
            { key: 'inspections' as const, label: '📄 États des lieux', count: totalInspections },
          ]
        ).map((tab) => {
          const active = view === tab.key;
          return (
            <button
              key={tab.key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setView(tab.key)}
              className={cn(
                'inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-3 text-sm font-bold transition-all cursor-pointer',
                active
                  ? 'air-gradient text-white shadow'
                  : 'text-muted-foreground hover:bg-background hover:text-foreground',
              )}
            >
              {tab.label}
              <span
                className={cn(
                  'inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[10px] font-black',
                  active ? 'bg-white/25 text-white' : 'bg-muted text-muted-foreground',
                )}
              >
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* ---------- KPIs ---------- */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <KPICard label="Séjours totaux" value={loading ? '—' : stats.total} emoji="🧳" tone="rausch" />
        <KPICard label="En cours" value={loading ? '—' : stats.inProgress} emoji="🛎️" tone="emerald" />
        <KPICard
          label="États des lieux signés"
          value={loading ? '—' : stats.inspections}
          emoji="📄"
          tone="violet"
        />
        <KPICard
          label="Chiffre commandes"
          value={loading ? '—' : formatEur(stats.revenue)}
          emoji="💰"
          tone="teal"
        />
      </div>

      {/* ---------- Recherche + filtres (selon la vue) ---------- */}
      {view === 'stays' ? (
        <div className="flex min-w-0 flex-col gap-3">
          <div className="relative max-w-md">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un invité…"
              className="h-10 rounded-full border-border bg-background pl-9"
              aria-label="Rechercher un invité par nom"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filtrer par statut de séjour">
            {STATUS_FILTERS.map((f) => {
              const active = statusFilter === f.value;
              return (
                <button
                  key={f.value}
                  type="button"
                  onClick={() => setStatusFilter(f.value)}
                  aria-pressed={active}
                  className={cn(
                    'inline-flex h-9 items-center rounded-full border px-3.5 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50',
                    active
                      ? 'border-primary bg-primary text-primary-foreground shadow'
                      : 'border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground',
                  )}
                >
                  {f.label}
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="flex min-w-0 flex-col gap-3">
          <div className="relative max-w-md">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher un client, un bien…"
              className="h-10 rounded-full border-border bg-background pl-9"
              aria-label="Rechercher un état des lieux par client ou bien"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filtrer par type d'état des lieux">
            {(
              [
                { value: 'all' as const, label: '📋 Tous' },
                { value: 'checkin' as const, label: '🏠 Arrivée' },
                { value: 'checkout' as const, label: '🚪 Départ' },
              ]
            ).map((f) => {
              const active = typeFilter === f.value;
              return (
                <button
                  key={f.value}
                  type="button"
                  onClick={() => setTypeFilter(f.value)}
                  aria-pressed={active}
                  className={cn(
                    'inline-flex h-9 items-center rounded-full border px-3.5 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50',
                    active
                      ? 'border-primary bg-primary text-primary-foreground shadow'
                      : 'border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground',
                  )}
                >
                  {f.label}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* ---------- Aucun bien ---------- */}
      {!propertiesLoading && !hasProperties && !loading && (
        <div className="air-empty flex flex-col items-center gap-3 rounded-2xl px-6 py-10 text-center">
          <span aria-hidden="true" className="air-float text-4xl">🏠</span>
          <p className="text-base font-semibold text-foreground">Aucun bien dans votre portfolio</p>
          <p className="max-w-md text-sm text-muted-foreground">
            Ajoutez votre première propriété pour retrouver ici l&apos;historique de vos invités.
          </p>
        </div>
      )}

      {/* ---------- Chargement ---------- */}
      {loading && (
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-2" aria-busy="true" aria-label="Chargement des séjours">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="air-shadow rounded-2xl border border-border bg-card p-5">
              <div className="flex items-center gap-3">
                <Skeleton className="h-11 w-11 rounded-xl" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
              <Skeleton className="mt-4 h-3 w-1/3" />
              <Skeleton className="mt-2 h-8 w-full rounded-xl" />
            </div>
          ))}
        </div>
      )}

      {/* ---------- VUE « SÉJOURS » ---------- */}
      {!loading && hasProperties && view === 'stays' && (
        <>
          {filtered.length === 0 ? (
            <div className="air-empty flex flex-col items-center gap-3 rounded-2xl px-6 py-10 text-center">
              <span aria-hidden="true" className="air-float text-4xl">🧳</span>
              <p className="text-base font-semibold text-foreground">Aucun séjour ne correspond</p>
              <p className="max-w-md text-sm text-muted-foreground">
                Modifiez la recherche, le statut ou le bien filtré pour voir plus de résultats.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
              {filtered.map((b) => (
                <StayCard
                  key={b.id}
                  booking={b}
                  cleanings={cleaningsFor(b)}
                  expanded={expandedId === b.id}
                  onToggle={() => setExpandedId((prev) => (prev === b.id ? null : b.id))}
                />
              ))}
            </div>
          )}
        </>
      )}

      {/* ---------- VUE « ÉTATS DES LIEUX » (v4.80) ---------- */}
      {!loading && hasProperties && view === 'inspections' && (
        <>
          {inspectionRows.length === 0 ? (
            <div className="air-empty flex flex-col items-center gap-3 rounded-2xl px-6 py-10 text-center">
              <span aria-hidden="true" className="air-float text-4xl">📄</span>
              <p className="text-base font-semibold text-foreground">Aucun état des lieux signé</p>
              <p className="max-w-md text-sm text-muted-foreground">
                Vos invités signent leurs états des lieux depuis le Hub QR : à l&apos;arrivée
                (pièces + photos) et au départ (minibar + pièces). Chaque document signé
                apparaît ici avec son PDF et son lien public.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
              {inspectionRows.map((row) => (
                <InspectionCard key={row.inspection.id} row={row} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
