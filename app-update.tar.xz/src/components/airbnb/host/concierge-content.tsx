'use client';

import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Loader2, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  SPOT_CATEGORY_META,
  type GuestAppliance,
  type GuestSpot,
  type GuestSpotCategory,
} from '@/lib/concierge';

// =============================================================
// DIGITAL CONCIERGE (V4.1) — ÉDITEURS CÔTÉ HÔTE (« Espace Hôte »)
// Page /airbnb/concierge : les 4 modules du Hub Invité remplis par
// l'hôte, sauvegardés via PATCH /api/airbnb/concierge :
//   🔑 Coffre-fort   → Property.accessCodes
//   📖 Appareils     → Property.appliances (+ vidéo YouTube / photo)
//   🗺️ Bonnes adresses → Property.localSpots (Carte Secrète)
//   🆘 SOS           → Property.emergencyInfo (+ pannes courantes)
// Design system du shell hôte : cartes blanches rounded-xl border
// shadow-sm, accent #E23F2B, toasts sonner, bouton d'enregistrement
// sticky. Aperçu direct de l'app invitée (QR hub du bien).
// =============================================================

// ── Types locaux (brouillons éditables — strings pour la saisie) ──

interface DraftCodes {
  building: string;
  letterbox: string;
  parking: string;
  alarm: string;
  safe: string;
  note: string;
}

interface DraftAppliance {
  key: string;
  emoji: string;
  name: string;
  instructions: string;
  videoUrl: string;
  imageUrl: string;
}

interface DraftSpot {
  key: string;
  name: string;
  category: GuestSpotCategory;
  address: string;
  lat: string;
  lng: string;
  hostNote: string;
}

interface DraftIssue {
  key: string;
  title: string;
  instructions: string;
  imageUrl: string;
}

interface DraftSos {
  hostPhone: string;
  police: string;
  hospital: string;
  hospitalLat: string;
  hospitalLng: string;
  pharmacy: string;
  pharmacyPhone: string;
  issues: DraftIssue[];
}

interface ConciergeDraft {
  codes: DraftCodes;
  appliances: DraftAppliance[];
  spots: DraftSpot[];
  sos: DraftSos;
}

interface ConciergeGetResponse {
  properties: { id: string; name: string }[];
  property: { id: string; name: string; qrHubSlug: string | null } | null;
  concierge: {
    accessCodes: Record<string, unknown> | null;
    appliances: GuestAppliance[];
    localSpots: GuestSpot[];
    emergencyInfo: Record<string, unknown> | null;
  } | null;
  error?: string;
}

const CODE_FIELDS: { key: keyof Omit<DraftCodes, 'note'>; emoji: string; label: string; placeholder: string }[] = [
  { key: 'building', emoji: '🏢', label: 'Bâtiment / Entrée', placeholder: 'ex : 8452#' },
  { key: 'letterbox', emoji: '📮', label: 'Boîte aux lettres', placeholder: 'ex : B-12' },
  { key: 'parking', emoji: '🚗', label: 'Parking', placeholder: 'ex : B2-12' },
  { key: 'alarm', emoji: '🚨', label: 'Alarme', placeholder: 'ex : 2468' },
  { key: 'safe', emoji: '🔐', label: 'Coffre-fort', placeholder: 'ex : 0000' },
];

const SPOT_CATEGORIES = Object.entries(SPOT_CATEGORY_META) as [GuestSpotCategory, { emoji: string; label: string }][];

const EMPTY_CODES: DraftCodes = { building: '', letterbox: '', parking: '', alarm: '', safe: '', note: '' };
const EMPTY_SOS: DraftSos = {
  hostPhone: '',
  police: '',
  hospital: '',
  hospitalLat: '',
  hospitalLng: '',
  pharmacy: '',
  pharmacyPhone: '',
  issues: [],
};

function newRowKey(): string {
  try {
    return crypto.randomUUID().slice(0, 8);
  } catch {
    return Math.random().toString(36).slice(2, 10);
  }
}

/** "48,8566" → 48.8566 (les coordonnées copiées de Maps peuvent contenir une virgule). */
function parseCoordInput(raw: string): number | null {
  const n = Number(raw.trim().replace(',', '.'));
  return Number.isFinite(n) ? n : null;
}

export function ConciergeContent() {
  const [data, setData] = useState<ConciergeGetResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [propertyId, setPropertyId] = useState('');
  const [activeTab, setActiveTab] = useState('codes');

  const [draft, setDraft] = useState<ConciergeDraft>({
    codes: { ...EMPTY_CODES },
    appliances: [],
    spots: [],
    sos: { ...EMPTY_SOS, issues: [] },
  });
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);

  // ── Chargement ──
  const load = useCallback(async (pid?: string) => {
    setLoading(true);
    setError('');
    try {
      const qs = pid ? `?propertyId=${encodeURIComponent(pid)}` : '';
      const res = await fetch(`/api/airbnb/concierge${qs}`);
      const json = (await res.json()) as ConciergeGetResponse;
      if (!res.ok) {
        setError(json.error || 'Impossible de charger la conciergerie.');
        setData(null);
        return;
      }
      setData(json);
      setPropertyId(json.property?.id ?? '');
      setDraft(hydrateDraft(json));
      setDirty(false);
    } catch {
      setError('Connexion impossible. Réessayez.');
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const changeProperty = (pid: string) => {
    if (dirty && !window.confirm('Des modifications ne sont pas enregistrées — changer de bien ?')) return;
    setPropertyId(pid);
    void load(pid);
  };

  // ── Mise à jour du brouillon (marque « dirty » automatiquement) ──
  const update = (fn: (d: ConciergeDraft) => ConciergeDraft) => {
    setDraft(fn);
    setDirty(true);
  };

  const setCode = (key: keyof DraftCodes, value: string) =>
    update((d) => ({ ...d, codes: { ...d.codes, [key]: value } }));

  const setAppliance = (key: string, patch: Partial<DraftAppliance>) =>
    update((d) => ({ ...d, appliances: d.appliances.map((a) => (a.key === key ? { ...a, ...patch } : a)) }));

  const addAppliance = () =>
    update((d) => ({
      ...d,
      appliances: [...d.appliances, { key: newRowKey(), emoji: '', name: '', instructions: '', videoUrl: '', imageUrl: '' }],
    }));

  const removeAppliance = (key: string) =>
    update((d) => ({ ...d, appliances: d.appliances.filter((a) => a.key !== key) }));

  const setSpot = (key: string, patch: Partial<DraftSpot>) =>
    update((d) => ({ ...d, spots: d.spots.map((s) => (s.key === key ? { ...s, ...patch } : s)) }));

  const addSpot = () =>
    update((d) => ({
      ...d,
      spots: [...d.spots, { key: newRowKey(), name: '', category: 'food', address: '', lat: '', lng: '', hostNote: '' }],
    }));

  const removeSpot = (key: string) =>
    update((d) => ({ ...d, spots: d.spots.filter((s) => s.key !== key) }));

  const setSos = (patch: Partial<Omit<DraftSos, 'issues'>>) =>
    update((d) => ({ ...d, sos: { ...d.sos, ...patch } }));

  const setIssue = (key: string, patch: Partial<DraftIssue>) =>
    update((d) => ({ ...d, sos: { ...d.sos, issues: d.sos.issues.map((i) => (i.key === key ? { ...i, ...patch } : i)) } }));

  const addIssue = () =>
    update((d) => ({ ...d, sos: { ...d.sos, issues: [...d.sos.issues, { key: newRowKey(), title: '', instructions: '', imageUrl: '' }] } }));

  const removeIssue = (key: string) =>
    update((d) => ({ ...d, sos: { ...d.sos, issues: d.sos.issues.filter((i) => i.key !== key) } }));

  // ── Upload photo (appareil / panne) ──
  const uploadImage = async (kind: 'appliance' | 'issue', rowKey: string, file: File) => {
    if (!propertyId) return;
    const busyKey = `${kind}:${rowKey}`;
    setUploadingKey(busyKey);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch(`/api/airbnb/concierge/upload?propertyId=${encodeURIComponent(propertyId)}`, {
        method: 'POST',
        body: fd,
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; url?: string; error?: string } | null;
      if (!res.ok || !json?.ok || !json.url) {
        toast.error(json?.error || 'Upload impossible.');
        return;
      }
      if (kind === 'appliance') {
        setAppliance(rowKey, { imageUrl: json.url });
      } else {
        setIssue(rowKey, { imageUrl: json.url });
      }
      toast.success('📷 Photo ajoutée.');
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setUploadingKey(null);
    }
  };

  const pickImage = (kind: 'appliance' | 'issue', rowKey: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp,image/gif';
    input.onchange = () => {
      const f = input.files?.[0];
      if (f) void uploadImage(kind, rowKey, f);
    };
    input.click();
  };

  // ── Enregistrement — validation client + PATCH complet ──
  const save = async () => {
    if (!propertyId) return;

    // 1. Codes — lignes vides ignorées
    const codes = draft.codes;
    const codesPayload = {
      building: codes.building.trim(),
      letterbox: codes.letterbox.trim(),
      parking: codes.parking.trim(),
      alarm: codes.alarm.trim(),
      safe: codes.safe.trim(),
      note: codes.note.trim() || undefined,
    };
    const accessCodes =
      codesPayload.building || codesPayload.letterbox || codesPayload.parking || codesPayload.alarm || codesPayload.safe
        ? codesPayload
        : null;

    // 2. Appareils
    const appliancesPayload: Record<string, unknown>[] = [];
    for (const a of draft.appliances) {
      const name = a.name.trim();
      const instructions = a.instructions.trim();
      if (!name && !instructions && !a.videoUrl.trim() && !a.imageUrl.trim() && !a.emoji.trim()) continue;
      if (!name) {
        setActiveTab('appliances');
        toast.error('Chaque appareil doit avoir un nom.');
        return;
      }
      if (!instructions) {
        setActiveTab('appliances');
        toast.error(`Ajoutez les instructions de « ${name} ».`);
        return;
      }
      appliancesPayload.push({
        id: a.key,
        name,
        emoji: a.emoji.trim() || undefined,
        instructions,
        videoUrl: a.videoUrl.trim() || undefined,
        imageUrl: a.imageUrl.trim() || undefined,
      });
    }

    // 3. Bonnes adresses
    const spotsPayload: Record<string, unknown>[] = [];
    for (const s of draft.spots) {
      const name = s.name.trim();
      if (!name && !s.lat.trim() && !s.lng.trim() && !s.address.trim() && !s.hostNote.trim()) continue;
      if (!name) {
        setActiveTab('spots');
        toast.error('Chaque adresse doit avoir un nom.');
        return;
      }
      const lat = parseCoordInput(s.lat);
      const lng = parseCoordInput(s.lng);
      if (lat === null || lng === null || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        setActiveTab('spots');
        toast.error(`Coordonnées invalides pour « ${name} » (ex : 48.8566 et 2.3522).`);
        return;
      }
      spotsPayload.push({
        id: s.key,
        name,
        category: s.category,
        lat,
        lng,
        address: s.address.trim() || undefined,
        hostNote: s.hostNote.trim() || undefined,
      });
    }

    // 4. SOS
    const issuesPayload: Record<string, unknown>[] = [];
    for (const it of draft.sos.issues) {
      const title = it.title.trim();
      const instructions = it.instructions.trim();
      if (!title && !instructions && !it.imageUrl.trim()) continue;
      if (!title || !instructions) {
        setActiveTab('sos');
        toast.error('Chaque panne doit avoir un titre ET des instructions.');
        return;
      }
      issuesPayload.push({
        id: it.key,
        title,
        instructions,
        imageUrl: it.imageUrl.trim() || undefined,
      });
    }
    const hospitalLat = parseCoordInput(draft.sos.hospitalLat);
    const hospitalLng = parseCoordInput(draft.sos.hospitalLng);
    if ((draft.sos.hospitalLat.trim() && hospitalLat === null) || (draft.sos.hospitalLng.trim() && hospitalLng === null)) {
      setActiveTab('sos');
      toast.error('Coordonnées de l’hôpital invalides (ex : 48.8566 et 2.3522).');
      return;
    }
    const sosTrim = {
      hostPhone: draft.sos.hostPhone.trim(),
      police: draft.sos.police.trim(),
      hospital: draft.sos.hospital.trim(),
      pharmacy: draft.sos.pharmacy.trim(),
      pharmacyPhone: draft.sos.pharmacyPhone.trim(),
    };
    const emergencyInfo =
      sosTrim.hostPhone || sosTrim.police || sosTrim.hospital || sosTrim.pharmacy || sosTrim.pharmacyPhone || issuesPayload.length > 0
        ? {
            ...sosTrim,
            ...(hospitalLat !== null ? { hospitalLat } : {}),
            ...(hospitalLng !== null ? { hospitalLng } : {}),
            commonIssues: issuesPayload,
          }
        : null;

    setSaving(true);
    try {
      const res = await fetch(`/api/airbnb/concierge?propertyId=${encodeURIComponent(propertyId)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accessCodes,
          appliances: appliancesPayload,
          localSpots: spotsPayload,
          emergencyInfo,
        }),
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!res.ok || !json?.ok) {
        toast.error(json?.error || 'Enregistrement impossible.');
        return;
      }
      setDirty(false);
      toast.success('🗝️ Conciergerie enregistrée — visible dans l’app de vos invités !');
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setSaving(false);
    }
  };

  // ── Compteurs (badges des onglets) ──
  const codesCount = CODE_FIELDS.filter((f) => draft.codes[f.key].trim()).length;
  const appliancesCount = draft.appliances.filter((a) => a.name.trim() || a.instructions.trim()).length;
  const spotsCount = draft.spots.filter((s) => s.name.trim() || s.lat.trim() || s.lng.trim()).length;
  const sosCount = draft.sos.issues.length + [draft.sos.hostPhone, draft.sos.police, draft.sos.hospital, draft.sos.pharmacy].filter((v) => v.trim()).length;

  const previewHref = data?.property?.qrHubSlug ? `/app/hub/${data.property.qrHubSlug}/guest` : null;

  return (
    <div className="max-w-4xl mx-auto w-full px-4 py-8">
      {/* ----- En-tête + switch propriété + aperçu ----- */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold text-slate-900">🗝️ Conciergerie digitale</h1>
          <p className="text-sm text-slate-500 mt-1">
            Remplissez le coffre-fort, les appareils, vos bonnes adresses et le SOS — tout apparaît dans l’app de vos invités.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {data && data.properties.length > 0 && (
            <Select value={data.property?.id ?? ''} onValueChange={changeProperty}>
              <SelectTrigger className="w-full sm:w-56 bg-white" aria-label="Choisir le bien">
                <SelectValue placeholder="Choisir un bien" />
              </SelectTrigger>
              <SelectContent>
                {data.properties.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {previewHref && (
            <a
              href={previewHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              title="Ouvrir l’app de vos invités dans un nouvel onglet"
            >
              👁️ Aperçu
            </a>
          )}
        </div>
      </div>

      {loading && !data && <LoadingSkeleton />}

      {!loading && error && (
        <div className="mt-6 bg-white border border-slate-200 rounded-xl p-8 text-center" role="alert">
          <p className="text-3xl" aria-hidden="true">🔌</p>
          <p className="mt-2 text-sm text-slate-600">{error}</p>
          <Button className="mt-4" onClick={() => void load(propertyId || undefined)}>
            Réessayer
          </Button>
        </div>
      )}

      {!loading && data && data.property && (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full mt-5">
          <TabsList className="h-auto w-full flex-wrap justify-start gap-1 rounded-xl border border-slate-200 bg-white p-1.5 sm:flex-nowrap">
            <TabsTrigger value="codes" className="gap-1.5 data-[state=active]:bg-[#FEF1EF] data-[state=active]:text-[#E23F2B]">
              🔑 Coffre-fort <CountBadge n={codesCount} />
            </TabsTrigger>
            <TabsTrigger value="appliances" className="gap-1.5 data-[state=active]:bg-[#FEF1EF] data-[state=active]:text-[#E23F2B]">
              📖 Appareils <CountBadge n={appliancesCount} />
            </TabsTrigger>
            <TabsTrigger value="spots" className="gap-1.5 data-[state=active]:bg-[#FEF1EF] data-[state=active]:text-[#E23F2B]">
              🗺️ Adresses <CountBadge n={spotsCount} />
            </TabsTrigger>
            <TabsTrigger value="sos" className="gap-1.5 data-[state=active]:bg-[#FEF1EF] data-[state=active]:text-[#E23F2B]">
              🆘 SOS <CountBadge n={sosCount} />
            </TabsTrigger>
          </TabsList>

          {/* ═══════════ 🔑 COFFRE-FORT ═══════════ */}
          <TabsContent value="codes" className="mt-4 space-y-4">
            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Codes d’accès">
              <h2 className="text-base font-bold text-slate-900">🔑 Codes d’accès</h2>
              <p className="mt-0.5 text-sm text-slate-500">
                L’invité les voit masqués (••••••) et les révèle d’un appui. Remplissez uniquement ce qui existe.
              </p>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {CODE_FIELDS.map((f) => (
                  <div key={f.key} className="flex flex-col gap-1.5">
                    <Label htmlFor={`code-${f.key}`} className="text-xs font-semibold text-slate-600">
                      {f.emoji} {f.label}
                    </Label>
                    <Input
                      id={`code-${f.key}`}
                      value={draft.codes[f.key]}
                      onChange={(e) => setCode(f.key, e.target.value)}
                      maxLength={40}
                      placeholder={f.placeholder}
                      autoComplete="off"
                    />
                  </div>
                ))}
              </div>
            </section>

            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Note pour l’invité">
              <h2 className="text-base font-bold text-slate-900">📝 Note pour l’invité</h2>
              <Textarea
                value={draft.codes.note}
                onChange={(e) => setCode('note', e.target.value)}
                maxLength={280}
                rows={3}
                className="mt-3"
                placeholder="ex : Le code bâtiment change chaque mois — l’actualité est dans votre email de veille d’arrivée."
                aria-label="Note pour l’invité"
              />
              <p className="mt-1.5 text-xs text-slate-400">{draft.codes.note.length}/280</p>
            </section>

            <div className="max-w-2xl rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed text-amber-800">
              🔒 <strong>Confidentialité :</strong> ces codes restent dans l’app de VOS invités (masqués par défaut,
              révélés uniquement par eux). Ne partagez jamais ces informations par email ou SMS.
            </div>
          </TabsContent>

          {/* ═══════════ 📖 APPAREILS ═══════════ */}
          <TabsContent value="appliances" className="mt-4">
            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Appareils">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <h2 className="text-base font-bold text-slate-900">📖 Appareils &amp; équipements</h2>
                  <p className="mt-0.5 text-sm text-slate-500">
                    Chaque appareil devient un accordéon dans le Guide : instructions + vidéo YouTube ou photo.
                  </p>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={addAppliance}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter
                </Button>
              </div>

              {draft.appliances.length === 0 ? (
                <EmptyList
                  emoji="🛠️"
                  text="Aucun appareil pour l’instant. Ajoutez la machine à café, la TV, le lave-linge…"
                  onAdd={addAppliance}
                />
              ) : (
                <div className="mt-4 space-y-4">
                  {draft.appliances.map((a, i) => (
                    <div key={a.key} className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <Input
                          value={a.emoji}
                          onChange={(e) => setAppliance(a.key, { emoji: e.target.value })}
                          maxLength={4}
                          className="w-16 text-center text-lg"
                          placeholder="🛠️"
                          aria-label={`Emoji de l’appareil ${i + 1}`}
                        />
                        <Input
                          value={a.name}
                          onChange={(e) => setAppliance(a.key, { name: e.target.value })}
                          maxLength={80}
                          className="flex-1"
                          placeholder="Nom de l’appareil (ex : Machine à café)"
                          aria-label={`Nom de l’appareil ${i + 1}`}
                        />
                        <DeleteRowButton onClick={() => removeAppliance(a.key)} label={`Supprimer l’appareil ${a.name || i + 1}`} />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label className="text-xs font-semibold text-slate-600">📌 Instructions pour l’invité</Label>
                        <Textarea
                          value={a.instructions}
                          onChange={(e) => setAppliance(a.key, { instructions: e.target.value })}
                          maxLength={4000}
                          rows={5}
                          placeholder={'1. Soulevez le levier et insérez une capsule.\n2. Appuyez sur ☕.\n\n💡 Astuce : utilisez des emojis pour guider.'}
                          aria-label={`Instructions de l’appareil ${a.name || i + 1}`}
                        />
                      </div>
                      <div className="grid gap-3 sm:grid-cols-2">
                        <div className="flex flex-col gap-1.5">
                          <Label className="text-xs font-semibold text-slate-600">🎬 Vidéo YouTube (optionnel)</Label>
                          <Input
                            value={a.videoUrl}
                            onChange={(e) => setAppliance(a.key, { videoUrl: e.target.value })}
                            placeholder="https://youtube.com/watch?v=…"
                            aria-label={`Vidéo YouTube de l’appareil ${a.name || i + 1}`}
                          />
                        </div>
                        <div className="flex flex-col gap-1.5">
                          <Label className="text-xs font-semibold text-slate-600">📷 Photo / GIF (optionnel)</Label>
                          {a.imageUrl ? (
                            <div className="flex items-center gap-2">
                              <img
                                src={a.imageUrl}
                                alt={`Photo de l’appareil ${a.name || i + 1}`}
                                className="h-10 w-10 rounded-lg border border-slate-200 object-cover"
                              />
                              <Button variant="outline" size="sm" onClick={() => setAppliance(a.key, { imageUrl: '' })}>
                                Retirer
                              </Button>
                            </div>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              className="justify-start"
                              disabled={uploadingKey === `appliance:${a.key}`}
                              onClick={() => pickImage('appliance', a.key)}
                            >
                              {uploadingKey === `appliance:${a.key}` ? (
                                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                              ) : (
                                '📷'
                              )}
                              <span className="ml-1.5">Ajouter une photo</span>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={addAppliance}>
                    <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter un appareil
                  </Button>
                </div>
              )}
            </section>
          </TabsContent>

          {/* ═══════════ 🗺️ BONNES ADRESSES ═══════════ */}
          <TabsContent value="spots" className="mt-4">
            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Bonnes adresses">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <h2 className="text-base font-bold text-slate-900">🗺️ Vos bonnes adresses</h2>
                  <p className="mt-0.5 text-sm text-slate-500">
                    La « Carte Secrète de l’hôte » : vos coups de cœur avec une note perso et un bouton « Y aller ».
                  </p>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={addSpot}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter
                </Button>
              </div>

              {draft.spots.length === 0 ? (
                <EmptyList
                  emoji="📍"
                  text="Aucune adresse pour l’instant. Ajoutez votre boulangerie préférée, le rooftop du coin…"
                  onAdd={addSpot}
                />
              ) : (
                <div className="mt-4 space-y-4">
                  {draft.spots.map((s, i) => (
                    <div key={s.key} className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <Input
                          value={s.name}
                          onChange={(e) => setSpot(s.key, { name: e.target.value })}
                          maxLength={80}
                          className="flex-1"
                          placeholder="Nom du lieu (ex : Boulangerie Dupont)"
                          aria-label={`Nom de l’adresse ${i + 1}`}
                        />
                        <Select value={s.category} onValueChange={(v) => setSpot(s.key, { category: v as GuestSpotCategory })}>
                          <SelectTrigger className="w-36 bg-white shrink-0" aria-label={`Catégorie de l’adresse ${i + 1}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {SPOT_CATEGORIES.map(([cat, meta]) => (
                              <SelectItem key={cat} value={cat}>
                                {meta.emoji} {meta.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <DeleteRowButton onClick={() => removeSpot(s.key)} label={`Supprimer l’adresse ${s.name || i + 1}`} />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label className="text-xs font-semibold text-slate-600">🏠 Adresse (optionnel)</Label>
                        <Input
                          value={s.address}
                          onChange={(e) => setSpot(s.key, { address: e.target.value })}
                          maxLength={160}
                          placeholder="ex : 8 rue Dupont"
                          aria-label={`Adresse de ${s.name || `l’adresse ${i + 1}`}`}
                        />
                      </div>
                      <div>
                        <div className="grid gap-3 sm:grid-cols-2">
                          <div className="flex flex-col gap-1.5">
                            <Label htmlFor={`spot-lat-${s.key}`} className="text-xs font-semibold text-slate-600">
                              🧭 Latitude
                            </Label>
                            <Input
                              id={`spot-lat-${s.key}`}
                              value={s.lat}
                              onChange={(e) => setSpot(s.key, { lat: e.target.value })}
                              inputMode="decimal"
                              placeholder="48.8661"
                              aria-label={`Latitude de ${s.name || `l’adresse ${i + 1}`}`}
                            />
                          </div>
                          <div className="flex flex-col gap-1.5">
                            <Label htmlFor={`spot-lng-${s.key}`} className="text-xs font-semibold text-slate-600">
                              🧭 Longitude
                            </Label>
                            <Input
                              id={`spot-lng-${s.key}`}
                              value={s.lng}
                              onChange={(e) => setSpot(s.key, { lng: e.target.value })}
                              inputMode="decimal"
                              placeholder="2.3280"
                              aria-label={`Longitude de ${s.name || `l’adresse ${i + 1}`}`}
                            />
                          </div>
                        </div>
                        <p className="mt-1.5 text-xs text-slate-400">
                          💡 Astuce : sur Google Maps, clic droit sur le lieu → « Copier les coordonnées », puis collez-les
                          ici (la virgule est acceptée).
                        </p>
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label className="text-xs font-semibold text-slate-600">🤫 Votre note secrète (optionnel)</Label>
                        <Textarea
                          value={s.hostNote}
                          onChange={(e) => setSpot(s.key, { hostNote: e.target.value })}
                          maxLength={280}
                          rows={2}
                          placeholder="ex : Le meilleur croissant de la rue — allez-y tôt !"
                          aria-label={`Note de l’hôte pour ${s.name || `l’adresse ${i + 1}`}`}
                        />
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={addSpot}>
                    <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une adresse
                  </Button>
                </div>
              )}
            </section>
          </TabsContent>

          {/* ═══════════ 🆘 SOS ═══════════ */}
          <TabsContent value="sos" className="mt-4 space-y-4">
            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Numéros utiles">
              <h2 className="text-base font-bold text-slate-900">📞 Numéros utiles</h2>
              <p className="mt-0.5 text-sm text-slate-500">
                Le 15 (SAMU), le 18 (Pompiers) et le 112 (Europe) sont déjà affichés automatiquement — inutile de les saisir.
              </p>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-host" className="text-xs font-semibold text-slate-600">
                    🚨 Urgence logement (vous)
                  </Label>
                  <Input
                    id="sos-host"
                    type="tel"
                    value={draft.sos.hostPhone}
                    onChange={(e) => setSos({ hostPhone: e.target.value })}
                    maxLength={40}
                    placeholder="+33 6 12 34 56 78"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-police" className="text-xs font-semibold text-slate-600">
                    👮 Police locale
                  </Label>
                  <Input
                    id="sos-police"
                    value={draft.sos.police}
                    onChange={(e) => setSos({ police: e.target.value })}
                    maxLength={40}
                    placeholder="17"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-pharmacy" className="text-xs font-semibold text-slate-600">
                    💊 Pharmacie de garde (nom)
                  </Label>
                  <Input
                    id="sos-pharmacy"
                    value={draft.sos.pharmacy}
                    onChange={(e) => setSos({ pharmacy: e.target.value })}
                    maxLength={120}
                    placeholder="ex : Pharmacie du Coin"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-pharmacy-phone" className="text-xs font-semibold text-slate-600">
                    💊 Téléphone pharmacie
                  </Label>
                  <Input
                    id="sos-pharmacy-phone"
                    type="tel"
                    value={draft.sos.pharmacyPhone}
                    onChange={(e) => setSos({ pharmacyPhone: e.target.value })}
                    maxLength={40}
                    placeholder="+33 1 42 00 00 00"
                  />
                </div>
              </div>
            </section>

            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Hôpital le plus proche">
              <h2 className="text-base font-bold text-slate-900">🏥 Hôpital le plus proche</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <Label htmlFor="sos-hospital" className="text-xs font-semibold text-slate-600">
                    🏥 Nom de l’hôpital
                  </Label>
                  <Input
                    id="sos-hospital"
                    value={draft.sos.hospital}
                    onChange={(e) => setSos({ hospital: e.target.value })}
                    maxLength={120}
                    placeholder="ex : Hôtel-Dieu Paris"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-hospital-lat" className="text-xs font-semibold text-slate-600">
                    🧭 Latitude (pour l’itinéraire)
                  </Label>
                  <Input
                    id="sos-hospital-lat"
                    value={draft.sos.hospitalLat}
                    onChange={(e) => setSos({ hospitalLat: e.target.value })}
                    inputMode="decimal"
                    placeholder="48.8545"
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="sos-hospital-lng" className="text-xs font-semibold text-slate-600">
                    🧭 Longitude
                  </Label>
                  <Input
                    id="sos-hospital-lng"
                    value={draft.sos.hospitalLng}
                    onChange={(e) => setSos({ hospitalLng: e.target.value })}
                    inputMode="decimal"
                    placeholder="2.3465"
                  />
                </div>
              </div>
            </section>

            <section className="max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Pannes courantes">
              <div className="flex items-start justify-between gap-3 flex-wrap">
                <div className="min-w-0">
                  <h2 className="text-base font-bold text-slate-900">🛠️ Pannes courantes</h2>
                  <p className="mt-0.5 text-sm text-slate-500">
                    Les invités débloquent seuls les petits soucis : disjoncteur, eau chaude, chasse d’eau…
                  </p>
                </div>
                <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={addIssue}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter
                </Button>
              </div>

              {draft.sos.issues.length === 0 ? (
                <EmptyList
                  emoji="🔧"
                  text="Aucune panne documentée. Préparez les réponses aux 2-3 soucis les plus fréquents du logement."
                  onAdd={addIssue}
                />
              ) : (
                <div className="mt-4 space-y-4">
                  {draft.sos.issues.map((it, i) => (
                    <div key={it.key} className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-3">
                      <div className="flex items-center gap-2">
                        <Input
                          value={it.title}
                          onChange={(e) => setIssue(it.key, { title: e.target.value })}
                          maxLength={80}
                          className="flex-1"
                          placeholder="Titre (ex : Le disjoncteur a sauté)"
                          aria-label={`Titre de la panne ${i + 1}`}
                        />
                        <DeleteRowButton onClick={() => removeIssue(it.key)} label={`Supprimer la panne ${it.title || i + 1}`} />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label className="text-xs font-semibold text-slate-600">📌 Que faire ?</Label>
                        <Textarea
                          value={it.instructions}
                          onChange={(e) => setIssue(it.key, { instructions: e.target.value })}
                          maxLength={4000}
                          rows={4}
                          placeholder={'1. Ouvrez le tableau électrique (entrée, à gauche).\n2. Repérez le levier baissé.\n3. Remontez-le d’un coup sec.'}
                          aria-label={`Instructions de la panne ${it.title || i + 1}`}
                        />
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <Label className="text-xs font-semibold text-slate-600">📷 Photo (optionnel)</Label>
                        {it.imageUrl ? (
                          <div className="flex items-center gap-2">
                            <img
                              src={it.imageUrl}
                              alt={`Photo de la panne ${it.title || i + 1}`}
                              className="h-10 w-10 rounded-lg border border-slate-200 object-cover"
                            />
                            <Button variant="outline" size="sm" onClick={() => setIssue(it.key, { imageUrl: '' })}>
                              Retirer
                            </Button>
                          </div>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="justify-start"
                            disabled={uploadingKey === `issue:${it.key}`}
                            onClick={() => pickImage('issue', it.key)}
                          >
                            {uploadingKey === `issue:${it.key}` ? (
                              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                            ) : (
                              '📷'
                            )}
                            <span className="ml-1.5">Ajouter une photo</span>
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={addIssue}>
                    <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une panne
                  </Button>
                </div>
              )}
            </section>
          </TabsContent>
        </Tabs>
      )}

      {!loading && data && data.property && (
        <div className="sticky bottom-4 z-30 mt-6 flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white/95 p-3 shadow-lg backdrop-blur">
          <p className="text-sm text-slate-600" aria-live="polite">
            {dirty ? '✍️ Modifications non enregistrées' : '✓ Tout est à jour'}
          </p>
          <Button
            onClick={() => void save()}
            disabled={saving || loading || !propertyId}
            className="gap-2 bg-[#E23F2B] font-bold text-white hover:bg-[#c93623]"
            aria-label="Enregistrer la conciergerie"
          >
            {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
            💾 Enregistrer
          </Button>
        </div>
      )}

      {!loading && data && !data.property && (
        <div className="mt-6 bg-white border border-slate-200 rounded-xl p-10 text-center">
          <p className="text-4xl" aria-hidden="true">🗝️</p>
          <h2 className="mt-3 text-lg font-bold text-slate-900">Aucun bien</h2>
          <p className="mt-1 text-sm text-slate-500">Ajoutez d’abord un bien pour remplir sa conciergerie digitale.</p>
        </div>
      )}
    </div>
  );
}

// =============================================================
// Helpers de rendu
// =============================================================

function hydrateDraft(json: ConciergeGetResponse): ConciergeDraft {
  const c = json.concierge;
  const codes = (c?.accessCodes ?? {}) as Record<string, unknown>;
  const sos = (c?.emergencyInfo ?? {}) as Record<string, unknown>;
  const str = (v: unknown): string => (typeof v === 'string' ? v : '');
  const num = (v: unknown): string => (typeof v === 'number' && Number.isFinite(v) ? String(v) : '');

  return {
    codes: {
      building: str(codes.building),
      letterbox: str(codes.letterbox),
      parking: str(codes.parking),
      alarm: str(codes.alarm),
      safe: str(codes.safe),
      note: str(codes.note),
    },
    appliances: (c?.appliances ?? []).map((a) => ({
      key: a.id || newRowKey(),
      // '🛠️' = défaut du parseur → champ laissé vide pour montrer le placeholder
      emoji: a.emoji && a.emoji !== '🛠️' ? a.emoji : '',
      name: a.name,
      instructions: a.instructions,
      videoUrl: a.videoUrl ?? '',
      imageUrl: a.imageUrl ?? '',
    })),
    spots: (c?.localSpots ?? []).map((s) => ({
      key: s.id || newRowKey(),
      name: s.name,
      category: s.category,
      address: s.address ?? '',
      lat: String(s.lat),
      lng: String(s.lng),
      hostNote: s.hostNote ?? '',
    })),
    sos: {
      hostPhone: str(sos.hostPhone),
      police: str(sos.police),
      hospital: str(sos.hospital),
      hospitalLat: num(sos.hospitalLat),
      hospitalLng: num(sos.hospitalLng),
      pharmacy: str(sos.pharmacy),
      pharmacyPhone: str(sos.pharmacyPhone),
      issues: Array.isArray(sos.commonIssues)
        ? (sos.commonIssues as { id?: string; title?: string; instructions?: string; imageUrl?: string }[]).map((it) => ({
            key: it.id || newRowKey(),
            title: it.title ?? '',
            instructions: it.instructions ?? '',
            imageUrl: it.imageUrl ?? '',
          }))
        : [],
    },
  };
}

function CountBadge({ n }: { n: number }) {
  if (n <= 0) return null;
  return (
    <span className="ml-0.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-emerald-100 px-1 text-[10px] font-bold text-emerald-700">
      {n}
    </span>
  );
}

function DeleteRowButton({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className="shrink-0 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
      onClick={onClick}
      aria-label={label}
      title={label}
    >
      <Trash2 className="h-4 w-4" aria-hidden="true" />
    </Button>
  );
}

function EmptyList({ emoji, text, onAdd }: { emoji: string; text: string; onAdd: () => void }) {
  return (
    <div className="mt-4 rounded-xl border-2 border-dashed border-slate-200 p-8 text-center">
      <p className="text-3xl" aria-hidden="true">{emoji}</p>
      <p className="mx-auto mt-2 max-w-sm text-sm text-slate-500">{text}</p>
      <Button variant="outline" size="sm" className="mt-3 gap-1.5" onClick={onAdd}>
        <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter
      </Button>
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="mt-6 space-y-4" aria-busy="true" aria-label="Chargement de la conciergerie">
      <Skeleton className="h-12 w-full max-w-2xl rounded-xl" />
      <Skeleton className="h-48 w-full max-w-2xl rounded-xl" />
      <Skeleton className="h-32 w-full max-w-2xl rounded-xl" />
    </div>
  );
}
