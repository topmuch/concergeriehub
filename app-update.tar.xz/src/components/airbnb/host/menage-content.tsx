'use client';

// =============================================================
// MenageContent — ONGLET MÉNAGE du Dashboard Client (/airbnb/menage)
//
// v4.43 — onglet DÉDIÉ au ménage (demande client : « dans le dashboard
// mettre un onglet dédié carrément aux ménages ») :
//   1. CHECKLIST : l'hôte garde la checklist générale (10 essentiels)
//      ou crée sa checklist personnalisée — elle est servie à la
//      femme de ménage dans le Mode Ménage du Hub ;
//   2. MESSAGE VOCAL POUR LA FEMME DE MÉNAGE : micro de l'hôte OU
//      voix IA (TTS) — écoutable par l'équipe dans le Mode Ménage ;
//   3. PREUVES DE MÉNAGE (déplacées depuis l'onglet Messages) :
//      rapports des passages — horaires, agent, checklist validée
//      (dépliable), photos de l'appartement propre (+N) et VOCAL de
//      la femme de ménage accompagnant ses preuves.
//
// Filtre : suit la propriété sélectionnée dans le header du shell
// (HostContext). La configuration (checklist + vocal) exige un bien
// précis ; en « Toutes les propriétés », vue lecture seule.
// =============================================================
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Camera, Check, ChevronDown, FileText, Loader2, Mic, RefreshCw, Square, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { DEFAULT_CLEANING_CHECKLIST, MAX_CHECKLIST_ITEMS } from '@/lib/housekeeping';
import { pickRecorderMime } from '@/lib/voice-audio';
// v4.54 « ALERTES STOCK » — panel hôte (résolution 1 clic).
import { INVENTORY_STATUS_META, inventoryItemMeta } from '@/lib/inventory';
// v4.53 « HISTORIQUE D'ÉTAT DES LIEUX EN PHOTOS HORODATÉES » — rapport
// visuel extrait EN UN CLIC (litige propreté, dossier Airbnb/assurance).
import { downloadCleaningReportPdf } from '@/lib/cleaning-report-pdf';

// ----- Types API -----
interface ChecklistInfo {
  source: 'default' | 'custom';
  items: string[];
}
interface HostNoteInfo {
  propertyId: string;
  propertyName: string | null;
  audioUrl: string;
  source: string;
  text: string | null;
  durationSec: number;
  updatedAt: string;
}
interface MenageReport {
  id: string;
  propertyId: string;
  propertyName: string | null;
  staffName: string | null;
  checklist: { label: string; done: boolean }[];
  coverPhoto: string | null;
  photoCount: number;
  hasVoice: boolean;
  voiceDurationSec: number;
  voiceUrl: string | null;
  startedAt: string | null;
  endedAt: string | null;
  createdAt: string;
}
interface MenageData {
  properties: { id: string; name: string }[];
  focusPropertyId: string | null;
  checklist: ChecklistInfo;
  customChecklist: string[] | null;
  hostNote: HostNoteInfo | null;
  reports: MenageReport[];
}

function formatFrDateTime(iso: string): string {
  return new Date(iso).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
function formatFrTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function MenageContent() {
  const { selectedId, selectedProperty } = useHostContext();
  const scopeLabel = selectedId === 'all' ? 'Toutes les propriétés' : selectedProperty?.name ?? '';
  // Configuration (checklist + vocal) possible uniquement sur un bien précis.
  const isAll = selectedId === 'all';

  const [data, setData] = useState<MenageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(
    async (mode: 'initial' | 'refresh') => {
      if (mode === 'refresh') setRefreshing(true);
      try {
        const res = await fetch(`/api/airbnb/menage?propertyId=${encodeURIComponent(selectedId)}`, {
          cache: 'no-store',
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as MenageData;
        setData(json);
      } catch {
        if (mode === 'initial') setData(null);
        toast.error('Impossible de charger l’onglet Ménage. Réessayez.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedId],
  );

  useEffect(() => {
    setLoading(true);
    void load('initial');
  }, [load]);
  useEffect(() => {
    const poll = setInterval(() => void load('refresh'), 45_000);
    return () => clearInterval(poll);
  }, [load]);

  const reportsSorted = useMemo(
    () =>
      [...(data?.reports ?? [])].sort(
        (a, b) =>
          new Date(b.endedAt ?? b.createdAt).getTime() -
          new Date(a.endedAt ?? a.createdAt).getTime(),
      ),
    [data],
  );

  if (loading && data === null) {
    return (
      <div className="space-y-4 max-w-4xl">
        <Skeleton className="h-9 w-52" />
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-40 w-full rounded-2xl" />
        <Skeleton className="h-64 w-full rounded-2xl" />
      </div>
    );
  }

  const focusPropertyId = data?.focusPropertyId ?? null;

  return (
    <div className="space-y-6 max-w-4xl">
      {/* ----- En-tête ----- */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <span aria-hidden="true">🧽</span> Ménage
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Checklist, consigne vocale et preuves de passage — {scopeLabel}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          disabled={refreshing}
          className="gap-2 rounded-xl self-start sm:self-auto"
          aria-label="Rafraîchir"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden="true" />
          Rafraîchir
        </Button>
      </div>

      {isAll && (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
          Vous voyez <strong>toutes les propriétés</strong>. Sélectionnez un bien précis dans la
          barre du haut pour configurer sa checklist et lui enregistrer un message vocal.
        </div>
      )}

      {/* ----- 1. Checklist de nettoyage ----- */}
      <ChecklistSection
        propertyId={focusPropertyId}
        enabled={!isAll && !!focusPropertyId}
        checklist={data?.checklist ?? { source: 'default', items: DEFAULT_CLEANING_CHECKLIST }}
        onSaved={(c) =>
          setData((d) => (d ? { ...d, checklist: c, customChecklist: c.source === 'custom' ? c.items : null } : d))
        }
      />

      {/* ----- 2. Message vocal pour la femme de ménage ----- */}
      <HostNoteSection
        propertyId={focusPropertyId}
        enabled={!isAll && !!focusPropertyId}
        note={data?.hostNote ?? null}
        onDeleted={() => setData((d) => (d ? { ...d, hostNote: null } : d))}
        onSaved={(note) => setData((d) => (d ? { ...d, hostNote: note } : d))}
      />

      {/* ----- 3. Preuves de ménage (passages de l'équipe) ----- */}
      <ReportsSection reports={reportsSorted} />

      {/* ----- 4. v4.54 « ALERTES STOCK » — signalements de l'équipe ----- */}
      <InventoryAlertsPanel enabled={!isAll && !!focusPropertyId} propertyId={focusPropertyId} />
    </div>
  );
}

// =============================================================
// 1. CHECKLIST DE NETTOYAGE
// =============================================================
function ChecklistSection({
  propertyId,
  enabled,
  checklist,
  onSaved,
}: {
  propertyId: string | null;
  enabled: boolean;
  checklist: ChecklistInfo;
  onSaved: (c: ChecklistInfo) => void;
}) {
  const [mode, setMode] = useState<'default' | 'custom'>(checklist.source);
  const [items, setItems] = useState<string[]>(
    checklist.source === 'custom' ? checklist.items : [],
  );
  const [saving, setSaving] = useState(false);

  // Re-synchronise si le bien sélectionné change.
  useEffect(() => {
    setMode(checklist.source);
    setItems(checklist.source === 'custom' ? checklist.items : []);
  }, [checklist.source, checklist.items, propertyId]);

  const saveDefault = async () => {
    if (!propertyId) return;
    setSaving(true);
    try {
      const res = await fetch('/api/airbnb/menage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, mode: 'default' }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; checklist?: ChecklistInfo };
      if (!res.ok || !json.checklist) {
        toast.error(json.error ?? 'Enregistrement impossible.');
        return;
      }
      onSaved(json.checklist);
      toast.success('Checklist générale activée ✅');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setSaving(false);
    }
  };

  const saveCustom = async () => {
    if (!propertyId) return;
    const cleaned = items.map((i) => i.trim()).filter(Boolean);
    if (cleaned.length === 0) {
      toast.error('Ajoutez au moins un point à votre checklist.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/airbnb/menage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, mode: 'custom', items: cleaned }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; checklist?: ChecklistInfo };
      if (!res.ok || !json.checklist) {
        toast.error(json.error ?? 'Enregistrement impossible.');
        return;
      }
      onSaved(json.checklist);
      setItems(json.checklist.items);
      toast.success('Votre checklist personnalisée est active ✅');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setSaving(false);
    }
  };

  const dirty =
    (mode === 'custom' &&
      (JSON.stringify(items.map((i) => i.trim()).filter(Boolean)) !==
        JSON.stringify(checklist.source === 'custom' ? checklist.items : []) ||
        checklist.source !== 'custom')) ||
    (mode === 'default' && checklist.source !== 'default');

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
        <div>
          <h2 className="text-base font-bold text-slate-900">Checklist de nettoyage</h2>
          <p className="text-sm text-slate-500 mt-1">
            Cochée point par point par votre équipe à chaque passage. Elle est affichée telle
            quelle dans le Mode Ménage du Hub.
          </p>
        </div>
        <Badge
          className={
            checklist.source === 'custom'
              ? 'bg-teal-100 text-teal-700 hover:bg-teal-100 shrink-0'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-100 shrink-0'
          }
        >
          {checklist.source === 'custom' ? 'Personnalisée' : 'Checklist générale'}
        </Badge>
      </div>

      {/* Choix du mode */}
      <div className="mt-4 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Type de checklist">
        <button
          type="button"
          disabled={!enabled}
          onClick={() => setMode('default')}
          aria-pressed={mode === 'default'}
          className={`rounded-xl border p-3 text-left transition-colors disabled:opacity-50 ${
            mode === 'default'
              ? 'border-teal-500 bg-teal-50 ring-1 ring-teal-500'
              : 'border-slate-200 bg-white hover:bg-slate-50'
          }`}
        >
          <p className="text-sm font-bold text-slate-800">🧽 Checklist générale</p>
          <p className="mt-0.5 text-xs text-slate-500">
            Les 10 essentiels du nettoyage (recommandé).
          </p>
        </button>
        <button
          type="button"
          disabled={!enabled}
          onClick={() => {
            setMode('custom');
            if (items.length === 0) setItems(['']);
          }}
          aria-pressed={mode === 'custom'}
          className={`rounded-xl border p-3 text-left transition-colors disabled:opacity-50 ${
            mode === 'custom'
              ? 'border-teal-500 bg-teal-50 ring-1 ring-teal-500'
              : 'border-slate-200 bg-white hover:bg-slate-50'
          }`}
        >
          <p className="text-sm font-bold text-slate-800">✍️ Ma checklist personnalisée</p>
          <p className="mt-0.5 text-xs text-slate-500">
            Écrivez vos propres points (20 maximum).
          </p>
        </button>
      </div>

      {/* Éditeur */}
      {mode === 'default' ? (
        <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
          {DEFAULT_CLEANING_CHECKLIST.map((label) => (
            <li key={label} className="flex items-center gap-2 text-sm text-slate-600">
              <Check className="h-4 w-4 shrink-0 text-teal-600" aria-hidden="true" />
              {label}
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-4 space-y-2">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              <Input
                value={item}
                onChange={(e) => setItems((arr) => arr.map((v, j) => (j === i ? e.target.value : v)))}
                maxLength={120}
                placeholder={`Point ${i + 1} (ex. « Lits refaits avec housse »)`}
                aria-label={`Point de checklist ${i + 1}`}
                className="h-10"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 border-slate-200 text-slate-400 hover:text-rose-600"
                onClick={() => setItems((arr) => arr.filter((_, j) => j !== i))}
                aria-label={`Supprimer le point ${i + 1}`}
              >
                <Trash2 className="h-4 w-4" aria-hidden="true" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="rounded-xl border-dashed"
            disabled={items.length >= MAX_CHECKLIST_ITEMS}
            onClick={() => setItems((arr) => [...arr, ''])}
          >
            + Ajouter un point ({items.length}/{MAX_CHECKLIST_ITEMS})
          </Button>
        </div>
      )}

      {enabled && (
        <div className="mt-4 flex flex-wrap gap-2">
          {mode === 'custom' ? (
            <Button
              type="button"
              className="h-10 rounded-xl bg-teal-600 font-semibold text-white hover:bg-teal-700"
              onClick={() => void saveCustom()}
              disabled={saving}
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Enregistrer ma checklist
            </Button>
          ) : (
            <Button
              type="button"
              className="h-10 rounded-xl bg-teal-600 font-semibold text-white hover:bg-teal-700"
              onClick={() => void saveDefault()}
              disabled={saving || checklist.source === 'default'}
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Utiliser la checklist générale
            </Button>
          )}
          {dirty && mode === 'custom' && checklist.source === 'custom' && (
            <span className="self-center text-xs text-slate-400">Modifications non enregistrées</span>
          )}
        </div>
      )}
      {!enabled && (
        <p className="mt-3 text-xs text-slate-400">
          Sélectionnez un bien précis (barre du haut) pour modifier sa checklist.
        </p>
      )}
    </section>
  );
}

// =============================================================
// 2. MESSAGE VOCAL POUR LA FEMME DE MÉNAGE
// =============================================================
const MAX_NOTE_SEC = 90;

function HostNoteSection({
  propertyId,
  enabled,
  note,
  onSaved,
  onDeleted,
}: {
  propertyId: string | null;
  enabled: boolean;
  note: HostNoteInfo | null;
  onSaved: (n: HostNoteInfo) => void;
  onDeleted: () => void;
}) {
  const [ttsText, setTtsText] = useState('');
  const [ttsBusy, setTtsBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSec, setRecSec] = useState(0);
  const [uploadBusy, setUploadBusy] = useState(false);
  const [pending, setPending] = useState<{ dataUrl: string; mime: string; sec: number } | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recSecRef = useRef(0);

  const stopStreams = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => stopStreams, [stopStreams]);

  const startRecording = async () => {
    if (typeof MediaRecorder === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      toast.error('Enregistrement non disponible sur ce navigateur. Utilisez la voix IA.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mimeType = pickRecorderMime();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const sec = recSecRef.current;
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setPending({ dataUrl: reader.result, mime: blob.type.split(';')[0], sec });
          }
        };
        reader.readAsDataURL(blob);
        stopStreams();
      };
      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
      setRecSec(0);
      recSecRef.current = 0;
      timerRef.current = setInterval(() => {
        setRecSec((s) => {
          const next = s + 1;
          recSecRef.current = next;
          if (next >= MAX_NOTE_SEC && recorderRef.current?.state === 'recording') {
            recorderRef.current.stop();
          }
          return next;
        });
      }, 1000);
    } catch {
      toast.error('Micro inaccessible. Vérifiez les autorisations du navigateur.');
    }
  };

  const stopRecording = () => {
    if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
    setRecording(false);
  };

  const sendPending = async () => {
    if (!pending || !propertyId) return;
    setUploadBusy(true);
    try {
      const res = await fetch('/api/airbnb/menage/voice-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId,
          action: 'upload',
          audioData: pending.dataUrl,
          audioMime: pending.mime,
          durationSec: pending.sec,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(json.error ?? 'Envoi impossible.');
        return;
      }
      setPending(null);
      onSaved({
        propertyId,
        propertyName: null,
        audioUrl: `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}&v=${Date.now()}`,
        source: 'upload',
        text: null,
        durationSec: pending.sec,
        updatedAt: new Date().toISOString(),
      });
      toast.success('Message vocal enregistré — visible par votre équipe 🎙️');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setUploadBusy(false);
    }
  };

  const generateTts = async () => {
    if (!propertyId) return;
    const text = ttsText.trim();
    if (!text) {
      toast.error('Écrivez d’abord le message à transformer en voix.');
      return;
    }
    setTtsBusy(true);
    try {
      const res = await fetch('/api/airbnb/menage/voice-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, action: 'tts', text }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; durationSec?: number };
      if (!res.ok) {
        toast.error(json.error ?? 'Génération impossible.');
        return;
      }
      onSaved({
        propertyId,
        propertyName: null,
        audioUrl: `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}&v=${Date.now()}`,
        source: 'tts',
        text,
        durationSec: json.durationSec ?? 0,
        updatedAt: new Date().toISOString(),
      });
      toast.success('Voix générée — votre équipe peut l’écouter 🔊');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setTtsBusy(false);
    }
  };

  const deleteNote = async () => {
    if (!propertyId) return;
    try {
      const res = await fetch(
        `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}`,
        { method: 'DELETE' },
      );
      if (!res.ok) {
        toast.error('Suppression impossible.');
        return;
      }
      onDeleted();
      toast.success('Message vocal supprimé.');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    }
  };

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
      <h2 className="text-base font-bold text-slate-900">Message vocal pour l&apos;équipe de ménage</h2>
      <p className="text-sm text-slate-500 mt-1">
        Laissez une consigne parlée (rangement particulier, produits à utiliser…) : votre équipe
        l&apos;écoute directement dans le Mode Ménage du Hub, avant de commencer.
      </p>

      {enabled && note && (
        <div className="mt-4 rounded-xl border border-teal-200 bg-teal-50 p-4">
          <p className="text-sm font-semibold text-teal-800">
            🎙️ Message actif{' '}
            <span className="font-normal text-teal-600">
              ({note.source === 'tts' ? 'voix IA' : 'micro'}
              {note.durationSec > 0 ? ` · ${note.durationSec} s` : ''})
            </span>
          </p>
          <audio controls preload="none" src={note.audioUrl} className="mt-2 w-full max-w-md" />
          <div className="mt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50"
              onClick={() => void deleteNote()}
            >
              <Trash2 className="h-4 w-4" aria-hidden="true" />
              Supprimer
            </Button>
          </div>
        </div>
      )}

      {enabled ? (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          {/* Voix IA */}
          <div className="rounded-xl border border-slate-200 p-4">
            <p className="text-sm font-bold text-slate-800">🤖 Générer avec la voix IA</p>
            <p className="mt-1 text-xs text-slate-500">
              Écrivez votre consigne, elle est transformée en message vocal.
            </p>
            <Textarea
              value={ttsText}
              onChange={(e) => setTtsText(e.target.value)}
              rows={3}
              maxLength={600}
              placeholder="Ex. : Bonjour ! Aujourd'hui, merci de changer aussi la housse de couette du lit double et de laisser la fenêtre de la chambre ouverte dix minutes."
              className="mt-2"
              aria-label="Texte du message pour l'équipe de ménage"
            />
            <Button
              type="button"
              size="sm"
              className="mt-2 h-10 rounded-xl bg-teal-600 font-semibold text-white hover:bg-teal-700"
              onClick={() => void generateTts()}
              disabled={ttsBusy || recording}
            >
              {ttsBusy && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              Générer la voix
            </Button>
          </div>

          {/* Micro */}
          <div className="rounded-xl border border-slate-200 p-4">
            <p className="text-sm font-bold text-slate-800">🎤 Enregistrer avec votre micro</p>
            <p className="mt-1 text-xs text-slate-500">Jusqu&apos;à {MAX_NOTE_SEC} secondes.</p>
            {recording ? (
              <div className="mt-2 flex items-center gap-3">
                <span className="inline-flex items-center gap-2 rounded-full bg-rose-50 px-3 py-1 text-sm font-bold text-rose-600">
                  <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-rose-500" aria-hidden="true" />
                  {recSec} s / {MAX_NOTE_SEC} s
                </span>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="h-10 rounded-xl border-rose-200 text-rose-600 hover:bg-rose-50"
                  onClick={stopRecording}
                >
                  <Square className="h-4 w-4" aria-hidden="true" />
                  Arrêter
                </Button>
              </div>
            ) : pending ? (
              <div className="mt-2 space-y-2">
                <audio controls preload="metadata" src={pending.dataUrl} className="w-full max-w-md" />
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    className="h-10 rounded-xl bg-teal-600 font-semibold text-white hover:bg-teal-700"
                    onClick={() => void sendPending()}
                    disabled={uploadBusy}
                  >
                    {uploadBusy && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
                    Envoyer à l&apos;équipe
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-10 rounded-xl border-slate-200 text-slate-500"
                    onClick={() => setPending(null)}
                  >
                    Refaire
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="mt-2 h-10 rounded-xl border-teal-200 text-teal-700 hover:bg-teal-50"
                onClick={() => void startRecording()}
                disabled={ttsBusy}
              >
                <Mic className="h-4 w-4" aria-hidden="true" />
                Démarrer l&apos;enregistrement
              </Button>
            )}
          </div>
        </div>
      ) : (
        <p className="mt-3 text-xs text-slate-400">
          Sélectionnez un bien précis (barre du haut) pour enregistrer un message vocal.
        </p>
      )}
    </section>
  );
}

// =============================================================
// 3. PREUVES DE MÉNAGE (rapports des passages)
// v4.53 — ARCHIVE HORODATÉE : chaque passage est archivé avec ses
// photos de fin de ménage, heures serveur et GPS ; l'hôte extrait en
// UN CLIC le rapport visuel horodaté (PDF) en cas de litige propreté.
// =============================================================
function ReportsSection({ reports }: { reports: MenageReport[] }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [exportingId, setExportingId] = useState<string | null>(null);

  const toggle = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  // Export PDF en 1 clic : charge les photos complètes du rapport
  // (?reportId=&photos=full) puis génère le dossier horodaté.
  const exportPdf = useCallback(async (r: MenageReport) => {
    setExportingId(r.id);
    try {
      const res = await fetch(
        `/api/airbnb/menage?reportId=${encodeURIComponent(r.id)}&photos=full`,
        { cache: 'no-store' },
      );
      const json = (await res.json().catch(() => null)) as {
        report?: {
          photos: string[];
          checklist: { label: string; done: boolean }[];
          staffName: string | null;
          startedAt: string | null;
          endedAt: string | null;
          createdAt: string;
          startLat: number | null;
          startLng: number | null;
        } | null;
      } | null;
      if (!res.ok || !json?.report) {
        throw new Error('rapport introuvable');
      }
      await downloadCleaningReportPdf({
        propertyName: r.propertyName,
        staffName: json.report.staffName,
        checklist: json.report.checklist,
        photos: json.report.photos,
        startedAt: json.report.startedAt,
        endedAt: json.report.endedAt,
        createdAt: json.report.createdAt,
        startLat: json.report.startLat,
        startLng: json.report.startLng,
      });
      toast.success('Rapport visuel horodaté exporté en PDF ✅');
    } catch {
      toast.error('Export impossible. Réessayez.');
    } finally {
      setExportingId(null);
    }
  }, []);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-bold text-slate-900">Preuves de ménage</h2>
          <p className="text-sm text-slate-500 mt-1">
            Passages de votre équipe : horaires, checklist validée, photos de l&apos;appartement
            propre et message vocal de l&apos;équipe.
          </p>
          {/* v4.53 — archive horodatée explicite (état des lieux) */}
          <p className="mt-1.5 text-xs text-teal-700 bg-teal-50 border border-teal-200 rounded-lg px-2.5 py-1.5 inline-block">
            🗄️ Archive horodatée : chaque fin de ménage est archivée avec photos + heure serveur +
            GPS. En cas de litige propreté, extrayez le rapport visuel en un clic.
          </p>
        </div>
        {reports.length > 0 && (
          <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 shrink-0">
            {reports.length} passage{reports.length > 1 ? 's' : ''}
          </Badge>
        )}
      </div>

      {reports.length === 0 ? (
        <div className="mt-4 rounded-xl border border-dashed border-slate-200 bg-slate-50 p-8 text-center">
          <span className="text-4xl" aria-hidden="true">🧽</span>
          <p className="mt-2 text-sm font-semibold text-slate-700">Aucun passage pour le moment</p>
          <p className="mt-1 text-xs text-slate-500">
            Votre femme de ménage valide son passage depuis le Mode Ménage du Hub (code staff) :
            ses preuves apparaîtront ici automatiquement.
          </p>
        </div>
      ) : (
        <ul className="mt-4 max-h-[62vh] space-y-3 overflow-y-auto custom-scrollbar pr-1">
          {reports.map((r) => {
            const done = r.checklist.filter((c) => c.done).length;
            const isOpen = expanded.has(r.id);
            return (
              <li key={r.id} className="rounded-2xl border border-slate-200 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-slate-900">🧹 Ménage terminé</p>
                    <p className="mt-0.5 text-xs text-slate-500">
                      {r.propertyName && <span className="mr-2 font-semibold text-slate-600">{r.propertyName}</span>}
                      {formatFrDateTime(r.endedAt ?? r.createdAt)}
                    </p>
                  </div>
                  <Badge className="shrink-0 bg-slate-100 text-slate-600 hover:bg-slate-100">
                    {r.staffName ?? 'Équipe ménage'}
                  </Badge>
                </div>

                <p className="mt-1.5 text-xs text-slate-500">
                  👤 {r.staffName ?? 'Équipe ménage'} · 🕐{' '}
                  {r.startedAt
                    ? `Arrivée ${formatFrTime(r.startedAt)} · Départ ${formatFrTime(r.endedAt ?? r.createdAt)}`
                    : `Validé à ${formatFrTime(r.endedAt ?? r.createdAt)}`}
                </p>

                {r.coverPhoto && (
                  <a href={r.coverPhoto} target="_blank" rel="noopener noreferrer" className="relative mt-3 block">
                    <img
                      src={r.coverPhoto}
                      alt={`Appartement propre — ménage du ${formatFrDateTime(r.endedAt ?? r.createdAt)}`}
                      className="max-h-40 w-full rounded-xl object-cover"
                    />
                    {r.photoCount > 1 && (
                      <span className="absolute bottom-2 right-2 rounded-full bg-slate-900/70 px-2 py-0.5 text-[11px] font-bold text-white">
                        +{r.photoCount - 1} photo{r.photoCount > 2 ? 's' : ''}
                      </span>
                    )}
                  </a>
                )}

                {r.voiceUrl && (
                  <div className="mt-3 rounded-xl bg-teal-50 p-3">
                    <p className="text-xs font-semibold text-teal-700">
                      🎙️ Message vocal de l&apos;équipe
                      {r.voiceDurationSec > 0 ? ` (${r.voiceDurationSec} s)` : ''}
                    </p>
                    <audio controls preload="none" src={r.voiceUrl} className="mt-1 w-full" />
                  </div>
                )}

                {r.checklist.length > 0 && (
                  <div className="mt-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="rounded-xl border-slate-200 text-xs text-slate-600"
                      onClick={() => toggle(r.id)}
                      aria-expanded={isOpen}
                    >
                      <ChevronDown
                        className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                        aria-hidden="true"
                      />
                      {done}/{r.checklist.length} points validés · {isOpen ? 'Masquer' : 'Voir le détail'}
                    </Button>
                    {isOpen && (
                      <ul className="mt-2 space-y-1 rounded-xl bg-slate-50 p-3">
                        {r.checklist.map((c, i) => (
                          <li
                            key={`${r.id}-c-${i}`}
                            className={`text-sm ${c.done ? 'text-slate-700' : 'text-slate-400'}`}
                          >
                            {c.done ? '✅' : '⬜'} {c.label}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}

                {/* v4.53 — rapport visuel horodaté EN 1 CLIC (litige propreté) */}
                <div className="mt-3">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="rounded-xl border-teal-200 text-xs font-semibold text-teal-700 hover:bg-teal-50"
                    disabled={exportingId === r.id}
                    onClick={() => void exportPdf(r)}
                    aria-label="Extraire le rapport visuel horodaté du ménage (PDF)"
                  >
                    {exportingId === r.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                    ) : (
                      <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                    )}
                    📸 Rapport visuel (PDF)
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

// =============================================================
// v4.54 « ALERTES STOCK » (amélioration 2.2) — panel hôte
// Les signalements non résolus en tête (rouges), l'historique en
// dessous ; « Réapprovisionné ✓ » résout l'alerte en 1 clic.
// =============================================================
interface InventoryAlertApi {
  id: string;
  bookingId: string | null;
  item: string;
  itemLabel: string;
  itemEmoji: string;
  status: string;
  reportedBy: string | null;
  note: string | null;
  createdAt: string;
  resolvedAt: string | null;
}

function InventoryAlertsPanel({
  enabled,
  propertyId,
}: {
  enabled: boolean;
  propertyId: string | null;
}) {
  const [alerts, setAlerts] = useState<InventoryAlertApi[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  const load = useCallback(async (pid: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(pid)}/inventory-alerts`, {
        cache: 'no-store',
      });
      const json = (await res.json().catch(() => null)) as { alerts?: InventoryAlertApi[] } | null;
      if (res.ok && json) setAlerts(json.alerts ?? []);
      else setAlerts(null);
    } catch {
      setAlerts(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled || !propertyId) {
      setAlerts(null);
      return;
    }
    void load(propertyId);
  }, [enabled, propertyId, load]);

  const resolve = async (alertId: string) => {
    if (!propertyId || resolvingId) return;
    setResolvingId(alertId);
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(propertyId)}/inventory-alerts`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, action: 'RESOLVE' }),
      });
      if (!res.ok) throw new Error('http');
      setAlerts((prev) =>
        prev
          ? prev.map((a) => (a.id === alertId ? { ...a, resolvedAt: new Date().toISOString() } : a))
          : prev,
      );
      toast.success('Alerte résolue — merci !');
    } catch {
      toast.error('Résolution impossible. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  };

  if (!enabled) return null;

  const open = (alerts ?? []).filter((a) => !a.resolvedAt);
  const history = (alerts ?? []).filter((a) => a.resolvedAt);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-label="Alertes stock">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div>
          <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
            📦 Alertes stock
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Signalements de l&apos;équipe de ménage (serviettes, papier toilette, savon, capsules café).
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 shrink-0 rounded-xl border-slate-200"
          disabled={loading || !propertyId}
          onClick={() => propertyId && void load(propertyId)}
          aria-label="Rafraîchir les alertes stock"
        >
          <Loader2 className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} aria-hidden="true" />
          Actualiser
        </Button>
      </div>

      {alerts === null && !loading ? (
        <div className="mt-4 rounded-xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center">
          <span className="text-3xl" aria-hidden="true">📦</span>
          <p className="mt-2 text-sm font-semibold text-slate-700">Aucune alerte pour le moment</p>
          <p className="mt-1 text-xs text-slate-500">
            L&apos;équipe signale le stock depuis le Mode Ménage du Hub (« Contrôle du stock »).
          </p>
        </div>
      ) : loading && alerts === null ? (
        <Skeleton className="mt-4 h-24 w-full rounded-xl" />
      ) : (
        <div className="mt-4 space-y-3">
          {open.length === 0 && history.length === 0 && (
            <div className="rounded-xl border border-dashed border-slate-200 bg-slate-50 p-6 text-center">
              <span className="text-3xl" aria-hidden="true">📦</span>
              <p className="mt-2 text-sm font-semibold text-slate-700">Aucune alerte pour le moment</p>
              <p className="mt-1 text-xs text-slate-500">
                L&apos;équipe signale le stock depuis le Mode Ménage du Hub (« Contrôle du stock »).
              </p>
            </div>
          )}

          {open.length > 0 && (
            <ul className="space-y-2.5">
              {open.map((a) => {
                const meta = inventoryItemMeta(a.item);
                const statusMeta = INVENTORY_STATUS_META[a.status] ?? INVENTORY_STATUS_META.low;
                return (
                  <li
                    key={a.id}
                    className={`flex items-start justify-between gap-3 rounded-2xl border p-4 ${
                      a.status === 'empty' ? 'border-rose-200 bg-rose-50/60' : 'border-amber-200 bg-amber-50/60'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-slate-900">
                        {meta.emoji} {meta.label}{' '}
                        <span className={`ml-1 inline-block rounded-full border px-2 py-0.5 text-[11px] font-bold ${statusMeta.className}`}>
                          {statusMeta.label}
                        </span>
                      </p>
                      <p className="mt-1 text-xs text-slate-500">
                        👤 {a.reportedBy ?? 'Équipe ménage'} · 🕐 {formatFrDateTime(a.createdAt)}
                        {a.note ? ` · « ${a.note.slice(0, 120)} »` : ''}
                      </p>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      className="h-9 shrink-0 rounded-xl bg-emerald-600 font-bold text-white hover:bg-emerald-700"
                      disabled={resolvingId === a.id}
                      onClick={() => void resolve(a.id)}
                      aria-label={`Marquer ${meta.label} comme réapprovisionné`}
                    >
                      {resolvingId === a.id ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                      ) : (
                        <Check className="h-4 w-4" aria-hidden="true" />
                      )}
                      Réapprovisionné
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}

          {history.length > 0 && (
            <details className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
              <summary className="cursor-pointer text-sm font-semibold text-slate-600">
                Historique résolu ({history.length})
              </summary>
              <ul className="mt-2.5 space-y-1.5">
                {history.map((a) => {
                  const meta = inventoryItemMeta(a.item);
                  return (
                    <li key={a.id} className="text-xs text-slate-500">
                      {meta.emoji} {meta.label} — {INVENTORY_STATUS_META[a.status]?.short ?? a.status} ·{' '}
                      {a.reportedBy ?? 'Équipe'} · {formatFrDateTime(a.createdAt)} · ✅ résolu{' '}
                      {a.resolvedAt ? formatFrDateTime(a.resolvedAt) : '—'}
                    </li>
                  );
                })}
              </ul>
            </details>
          )}
        </div>
      )}
    </section>
  );
}
