'use client';

// =============================================================
// MenageContent — ONGLET MÉNAGE du Dashboard Client (/airbnb/menage)
// v5.2 « SAPHIR LUXE » — refonte design profonde (demande client) :
//
// • Design SIMPLE, LUXUEUX, PROFESSIONNEL — mode sombre BLEUTÉ
// • SANS ICÔNES : typographie (lux-eyebrow / lux-display / lux-num),
//   points colorés .lux-dot et glyphes purs (✓ ▾ ×) — aucun lucide,
//   aucun emoji décoratif (titres, boutons, badges, empty states)
// • Cartes .lux-card, pastilles .lux-chip, empty states .lux-empty,
//   zones défilantes .lux-scroll, boutons .lux-btn / .lux-btn-ghost
// • DONNÉES, HANDLERS, CONDITIONS ET LIBELLÉS MÉTIER INTACTS :
//   checklist (générale ou personnalisée), consigne vocale (micro ou
//   voix IA), preuves de ménage (rapports horodatés + photos + vocal),
//   alertes stock, états des lieux de sortie — REDESIGNÉS uniquement.
//
// Historique :
// v4.60 « AIRBNB PRO » — cartes air-shadow, bulles kpi-bubble-*, CTA
//   air-gradient, empty states .air-empty (remplacés par Saphir Luxe).
// v4.54 — ALERTES STOCK : panel hôte (résolution 1 clic).
// v4.43 — onglet DÉDIÉ au ménage (demande client : « dans le dashboard
//   mettre un onglet dédié carrément aux ménages ») :
//     1. CHECKLIST : l'hôte garde la checklist générale (10 essentiels)
//        ou crée sa checklist personnalisée — servie à la femme de
//        ménage dans le Mode Ménage du Hub ;
//     2. MESSAGE VOCAL POUR LA FEMME DE MÉNAGE : micro de l'hôte OU
//        voix IA (TTS) — écoutable par l'équipe dans le Mode Ménage ;
//     3. PREUVES DE MÉNAGE : rapports des passages — horaires, agent,
//        checklist validée (dépliable), photos (+N) et VOCAL.
// Filtre : suit la propriété sélectionnée dans le header du shell
// (HostContext). La configuration (checklist + vocal) exige un bien
// précis ; en « Toutes les propriétés », vue lecture seule.
// =============================================================
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { DEFAULT_CLEANING_CHECKLIST, MAX_CHECKLIST_ITEMS } from '@/lib/housekeeping';
import { pickRecorderMime } from '@/lib/voice-audio';
// v4.54 « ALERTES STOCK » — panel hôte (résolution 1 clic).
import { INVENTORY_STATUS_META, inventoryItemMeta } from '@/lib/inventory';
// v4.53 « HISTORIQUE D'ÉTAT DES LIEUX EN PHOTOS HORODATÉES » — rapport
// visuel extrait EN UN CLIC (litige propreté, dossier Airbnb/assurance).
import { downloadCleaningReportPdf } from '@/lib/cleaning-report-pdf';
import { cn } from '@/lib/utils';

// ----- Types API -----
interface ChecklistInfo {
  source: 'default' | 'custom';
  items: string[];
}
interface HostNoteInfo {
  propertyId: string;
  propertyName: string | null;
  audioUrl: string;
  source: string;
  text: string | null;
  durationSec: number;
  updatedAt: string;
}
interface MenageReport {
  id: string;
  propertyId: string;
  propertyName: string | null;
  staffName: string | null;
  checklist: { label: string; done: boolean }[];
  coverPhoto: string | null;
  photoCount: number;
  hasVoice: boolean;
  voiceDurationSec: number;
  voiceUrl: string | null;
  startedAt: string | null;
  endedAt: string | null;
  createdAt: string;
}
interface MenageData {
  properties: { id: string; name: string }[];
  focusPropertyId: string | null;
  checklist: ChecklistInfo;
  customChecklist: string[] | null;
  hostNote: HostNoteInfo | null;
  reports: MenageReport[];
}

function formatFrDateTime(iso: string): string {
  return new Date(iso).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
function formatFrTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** Point pulsé — indicateur de chargement (remplace toute icône busy). */
function LuxBusyDot({ color = 'rgba(255,255,255,0.9)', className }: { color?: string; className?: string }) {
  return <span aria-hidden="true" className={cn('lux-dot animate-pulse', className)} style={{ backgroundColor: color }} />;
}

/** Classes communes des champs de saisie sur la nuit saphir. */
const LUX_FIELD =
  'rounded-xl border-white/12 bg-white/[0.04] text-white placeholder:text-[#8fa0c2]/60 focus-visible:ring-[#5c8af0]/50';
/** Bouton secondaire fantôme (shadcn Button + teintes lux). */
const LUX_GHOST_BTN =
  'rounded-full border-white/12 bg-white/[0.04] font-semibold text-[#d5def0] hover:bg-white/8 hover:text-white';

export function MenageContent() {
  const { selectedId, selectedProperty } = useHostContext();
  const scopeLabel = selectedId === 'all' ? 'Toutes les propriétés' : selectedProperty?.name ?? '';
  // Configuration (checklist + vocal) possible uniquement sur un bien précis.
  const isAll = selectedId === 'all';

  const [data, setData] = useState<MenageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(
    async (mode: 'initial' | 'refresh') => {
      if (mode === 'refresh') setRefreshing(true);
      try {
        const res = await fetch(`/api/airbnb/menage?propertyId=${encodeURIComponent(selectedId)}`, {
          cache: 'no-store',
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as MenageData;
        setData(json);
      } catch {
        if (mode === 'initial') setData(null);
        toast.error('Impossible de charger l’onglet Ménage. Réessayez.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedId],
  );

  useEffect(() => {
    setLoading(true);
    void load('initial');
  }, [load]);
  useEffect(() => {
    const poll = setInterval(() => void load('refresh'), 45_000);
    return () => clearInterval(poll);
  }, [load]);

  const reportsSorted = useMemo(
    () =>
      [...(data?.reports ?? [])].sort(
        (a, b) =>
          new Date(b.endedAt ?? b.createdAt).getTime() -
          new Date(a.endedAt ?? a.createdAt).getTime(),
      ),
    [data],
  );

  if (loading && data === null) {
    return (
      <div
        className="flex max-w-4xl flex-col gap-6"
        role="status"
        aria-label="Chargement de l'onglet Ménage"
      >
        <Skeleton className="h-10 w-56 rounded-full bg-white/8" />
        <Skeleton className="h-44 w-full rounded-2xl bg-white/8" />
        <Skeleton className="h-56 w-full rounded-2xl bg-white/8" />
        <Skeleton className="h-72 w-full rounded-2xl bg-white/8" />
        <Skeleton className="h-52 w-full rounded-2xl bg-white/8" />
      </div>
    );
  }

  const focusPropertyId = data?.focusPropertyId ?? null;

  return (
    <div className="flex max-w-4xl flex-col gap-6">
      {/* ----- En-tête ----- */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="lux-eyebrow">Ménage &amp; stock</p>
          <h1 className="lux-display mt-1.5 text-2xl font-semibold text-white sm:text-3xl">Ménage</h1>
          <p className="mt-1 text-sm text-[#8fa0c2]">
            Checklist, consigne vocale et preuves de passage — {scopeLabel}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          disabled={refreshing}
          className={cn('h-9 gap-2 self-start rounded-full px-4 text-xs sm:self-auto', LUX_GHOST_BTN)}
          aria-label="Rafraîchir"
        >
          {refreshing && <LuxBusyDot />}
          Rafraîchir
        </Button>
      </div>

      {isAll && (
        <div
          className="flex items-start gap-3 rounded-2xl border border-[#e9c47c]/25 bg-[#e9c47c]/8 p-4 text-sm text-[#f3d795]"
          role="note"
        >
          <span className="lux-dot mt-2 shrink-0" style={{ backgroundColor: '#e9c47c' }} aria-hidden="true" />
          <p>
            Vous voyez <strong>toutes les propriétés</strong>. Sélectionnez un bien précis dans la
            barre du haut pour configurer sa checklist et lui enregistrer un message vocal.
          </p>
        </div>
      )}

      {/* ----- 1. Checklist de nettoyage ----- */}
      <ChecklistSection
        propertyId={focusPropertyId}
        enabled={!isAll && !!focusPropertyId}
        checklist={data?.checklist ?? { source: 'default', items: DEFAULT_CLEANING_CHECKLIST }}
        onSaved={(c) =>
          setData((d) => (d ? { ...d, checklist: c, customChecklist: c.source === 'custom' ? c.items : null } : d))
        }
      />

      {/* ----- 2. Message vocal pour la femme de ménage ----- */}
      <HostNoteSection
        propertyId={focusPropertyId}
        enabled={!isAll && !!focusPropertyId}
        note={data?.hostNote ?? null}
        onDeleted={() => setData((d) => (d ? { ...d, hostNote: null } : d))}
        onSaved={(note) => setData((d) => (d ? { ...d, hostNote: note } : d))}
      />

      {/* ----- 3. Preuves de ménage (passages de l'équipe) ----- */}
      <ReportsSection reports={reportsSorted} />

      {/* ----- 4. v4.54 « ALERTES STOCK » — signalements de l'équipe ----- */}
      <InventoryAlertsPanel enabled={!isAll && !!focusPropertyId} propertyId={focusPropertyId} />

      {/* ----- 5. v5.0 « ÉTATS DES LIEUX DE SORTIE » — inspections signées ----- */}
      <CheckoutInspectionsSection selectedId={selectedId} />
    </div>
  );
}

// =============================================================
// 1. CHECKLIST DE NETTOYAGE
// =============================================================
function ChecklistSection({
  propertyId,
  enabled,
  checklist,
  onSaved,
}: {
  propertyId: string | null;
  enabled: boolean;
  checklist: ChecklistInfo;
  onSaved: (c: ChecklistInfo) => void;
}) {
  const [mode, setMode] = useState<'default' | 'custom'>(checklist.source);
  const [items, setItems] = useState<string[]>(
    checklist.source === 'custom' ? checklist.items : [],
  );
  const [saving, setSaving] = useState(false);

  // Re-synchronise si le bien sélectionné change.
  useEffect(() => {
    setMode(checklist.source);
    setItems(checklist.source === 'custom' ? checklist.items : []);
  }, [checklist.source, checklist.items, propertyId]);

  const saveDefault = async () => {
    if (!propertyId) return;
    setSaving(true);
    try {
      const res = await fetch('/api/airbnb/menage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, mode: 'default' }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; checklist?: ChecklistInfo };
      if (!res.ok || !json.checklist) {
        toast.error(json.error ?? 'Enregistrement impossible.');
        return;
      }
      onSaved(json.checklist);
      toast.success('Checklist générale activée ✅');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setSaving(false);
    }
  };

  const saveCustom = async () => {
    if (!propertyId) return;
    const cleaned = items.map((i) => i.trim()).filter(Boolean);
    if (cleaned.length === 0) {
      toast.error('Ajoutez au moins un point à votre checklist.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch('/api/airbnb/menage', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, mode: 'custom', items: cleaned }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; checklist?: ChecklistInfo };
      if (!res.ok || !json.checklist) {
        toast.error(json.error ?? 'Enregistrement impossible.');
        return;
      }
      onSaved(json.checklist);
      setItems(json.checklist.items);
      toast.success('Votre checklist personnalisée est active ✅');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setSaving(false);
    }
  };

  const dirty =
    (mode === 'custom' &&
      (JSON.stringify(items.map((i) => i.trim()).filter(Boolean)) !==
        JSON.stringify(checklist.source === 'custom' ? checklist.items : []) ||
        checklist.source !== 'custom')) ||
    (mode === 'default' && checklist.source !== 'default');

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="lux-card p-4 sm:p-6"
      aria-label="Checklist de nettoyage"
    >
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <p className="lux-eyebrow">Servie à votre équipe dans le hub</p>
          <h2 className="lux-display mt-1 text-lg text-white">Checklist de nettoyage</h2>
          <p className="mt-1 text-sm text-[#8fa0c2]">
            Cochée point par point par votre équipe à chaque passage. Elle est affichée telle
            quelle dans le Mode Ménage du Hub.
          </p>
        </div>
        <span className="lux-chip shrink-0">
          <span
            className="lux-dot"
            style={{ backgroundColor: checklist.source === 'custom' ? '#2dd4bf' : 'rgba(143,160,194,0.55)' }}
            aria-hidden="true"
          />
          {checklist.source === 'custom' ? 'Personnalisée' : 'Checklist générale'}
        </span>
      </div>

      {/* Choix du mode */}
      <div className="mt-4 grid gap-2 sm:grid-cols-2" role="radiogroup" aria-label="Type de checklist">
        <button
          type="button"
          disabled={!enabled}
          onClick={() => setMode('default')}
          aria-pressed={mode === 'default'}
          className={cn(
            'rounded-xl border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:opacity-50',
            mode === 'default'
              ? 'border-[#e9c47c]/45 bg-[#e9c47c]/8 ring-1 ring-[#e9c47c]/25'
              : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.05]',
          )}
        >
          <p className="flex items-center gap-2 text-sm font-semibold text-white">
            <span
              className="lux-dot"
              style={{ backgroundColor: mode === 'default' ? '#e9c47c' : 'rgba(143,160,194,0.4)' }}
              aria-hidden="true"
            />
            Checklist générale
          </p>
          <p className="mt-0.5 text-xs text-[#8fa0c2]">
            Les 10 essentiels du nettoyage (recommandé).
          </p>
        </button>
        <button
          type="button"
          disabled={!enabled}
          onClick={() => {
            setMode('custom');
            if (items.length === 0) setItems(['']);
          }}
          aria-pressed={mode === 'custom'}
          className={cn(
            'rounded-xl border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:opacity-50',
            mode === 'custom'
              ? 'border-[#e9c47c]/45 bg-[#e9c47c]/8 ring-1 ring-[#e9c47c]/25'
              : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.05]',
          )}
        >
          <p className="flex items-center gap-2 text-sm font-semibold text-white">
            <span
              className="lux-dot"
              style={{ backgroundColor: mode === 'custom' ? '#2dd4bf' : 'rgba(143,160,194,0.4)' }}
              aria-hidden="true"
            />
            Ma checklist personnalisée
          </p>
          <p className="mt-0.5 text-xs text-[#8fa0c2]">
            Écrivez vos propres points (20 maximum).
          </p>
        </button>
      </div>

      {/* Éditeur */}
      {mode === 'default' ? (
        <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
          {DEFAULT_CLEANING_CHECKLIST.map((label) => (
            <li key={label} className="flex items-center gap-2 text-sm text-[#8fa0c2]">
              <span aria-hidden="true" className="shrink-0 font-semibold text-[#2dd4bf]">
                ✓
              </span>
              {label}
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-4 space-y-2">
          {items.map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              <Input
                value={item}
                onChange={(e) => setItems((arr) => arr.map((v, j) => (j === i ? e.target.value : v)))}
                maxLength={120}
                placeholder={`Point ${i + 1} (ex. « Lits refaits avec housse »)`}
                aria-label={`Point de checklist ${i + 1}`}
                className={cn('h-10', LUX_FIELD)}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="h-10 w-10 shrink-0 rounded-full border-white/12 bg-white/[0.04] text-[#8fa0c2] hover:bg-[#f07d6a]/10 hover:text-[#f07d6a]"
                onClick={() => setItems((arr) => arr.filter((_, j) => j !== i))}
                aria-label={`Supprimer le point ${i + 1}`}
              >
                <span aria-hidden="true" className="text-base leading-none">
                  ×
                </span>
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="h-9 rounded-full border-dashed border-white/15 bg-transparent text-xs font-semibold text-[#8fa0c2] hover:bg-white/5 hover:text-white"
            disabled={items.length >= MAX_CHECKLIST_ITEMS}
            onClick={() => setItems((arr) => [...arr, ''])}
          >
            + Ajouter un point ({items.length}/{MAX_CHECKLIST_ITEMS})
          </Button>
        </div>
      )}

      {enabled && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          {mode === 'custom' ? (
            <button
              type="button"
              className="lux-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:pointer-events-none disabled:opacity-60"
              onClick={() => void saveCustom()}
              disabled={saving}
            >
              {saving && <LuxBusyDot />}
              Enregistrer ma checklist
            </button>
          ) : (
            <button
              type="button"
              className="lux-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:pointer-events-none disabled:opacity-60"
              onClick={() => void saveDefault()}
              disabled={saving || checklist.source === 'default'}
            >
              {saving && <LuxBusyDot />}
              Utiliser la checklist générale
            </button>
          )}
          {dirty && mode === 'custom' && checklist.source === 'custom' && (
            <span className="text-xs text-[#8fa0c2]">Modifications non enregistrées</span>
          )}
        </div>
      )}
      {!enabled && (
        <p className="mt-3 text-xs text-[#8fa0c2]">
          Sélectionnez un bien précis (barre du haut) pour modifier sa checklist.
        </p>
      )}
    </motion.section>
  );
}

// =============================================================
// 2. MESSAGE VOCAL POUR LA FEMME DE MÉNAGE
// =============================================================
const MAX_NOTE_SEC = 90;

function HostNoteSection({
  propertyId,
  enabled,
  note,
  onSaved,
  onDeleted,
}: {
  propertyId: string | null;
  enabled: boolean;
  note: HostNoteInfo | null;
  onSaved: (n: HostNoteInfo) => void;
  onDeleted: () => void;
}) {
  const [ttsText, setTtsText] = useState('');
  const [ttsBusy, setTtsBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSec, setRecSec] = useState(0);
  const [uploadBusy, setUploadBusy] = useState(false);
  const [pending, setPending] = useState<{ dataUrl: string; mime: string; sec: number } | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recSecRef = useRef(0);

  const stopStreams = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => stopStreams, [stopStreams]);

  const startRecording = async () => {
    if (typeof MediaRecorder === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      toast.error('Enregistrement non disponible sur ce navigateur. Utilisez la voix IA.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mimeType = pickRecorderMime();
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        const sec = recSecRef.current;
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setPending({ dataUrl: reader.result, mime: blob.type.split(';')[0], sec });
          }
        };
        reader.readAsDataURL(blob);
        stopStreams();
      };
      recorderRef.current = recorder;
      recorder.start();
      setRecording(true);
      setRecSec(0);
      recSecRef.current = 0;
      timerRef.current = setInterval(() => {
        setRecSec((s) => {
          const next = s + 1;
          recSecRef.current = next;
          if (next >= MAX_NOTE_SEC && recorderRef.current?.state === 'recording') {
            recorderRef.current.stop();
          }
          return next;
        });
      }, 1000);
    } catch {
      toast.error('Micro inaccessible. Vérifiez les autorisations du navigateur.');
    }
  };

  const stopRecording = () => {
    if (recorderRef.current?.state === 'recording') recorderRef.current.stop();
    setRecording(false);
  };

  const sendPending = async () => {
    if (!pending || !propertyId) return;
    setUploadBusy(true);
    try {
      const res = await fetch('/api/airbnb/menage/voice-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId,
          action: 'upload',
          audioData: pending.dataUrl,
          audioMime: pending.mime,
          durationSec: pending.sec,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(json.error ?? 'Envoi impossible.');
        return;
      }
      setPending(null);
      onSaved({
        propertyId,
        propertyName: null,
        audioUrl: `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}&v=${Date.now()}`,
        source: 'upload',
        text: null,
        durationSec: pending.sec,
        updatedAt: new Date().toISOString(),
      });
      toast.success('Message vocal enregistré — visible par votre équipe 🎙️');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setUploadBusy(false);
    }
  };

  const generateTts = async () => {
    if (!propertyId) return;
    const text = ttsText.trim();
    if (!text) {
      toast.error('Écrivez d’abord le message à transformer en voix.');
      return;
    }
    setTtsBusy(true);
    try {
      const res = await fetch('/api/airbnb/menage/voice-note', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, action: 'tts', text }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; durationSec?: number };
      if (!res.ok) {
        toast.error(json.error ?? 'Génération impossible.');
        return;
      }
      onSaved({
        propertyId,
        propertyName: null,
        audioUrl: `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}&v=${Date.now()}`,
        source: 'tts',
        text,
        durationSec: json.durationSec ?? 0,
        updatedAt: new Date().toISOString(),
      });
      toast.success('Voix générée — votre équipe peut l’écouter 🔊');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setTtsBusy(false);
    }
  };

  const deleteNote = async () => {
    if (!propertyId) return;
    try {
      const res = await fetch(
        `/api/airbnb/menage/voice-note?propertyId=${encodeURIComponent(propertyId)}`,
        { method: 'DELETE' },
      );
      if (!res.ok) {
        toast.error('Suppression impossible.');
        return;
      }
      onDeleted();
      toast.success('Message vocal supprimé.');
    } catch {
      toast.error('Erreur réseau. Réessayez dans un instant.');
    }
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut', delay: 0.05 }}
      className="lux-card p-4 sm:p-6"
      aria-label="Message vocal pour l'équipe de ménage"
    >
      <div className="min-w-0">
        <p className="lux-eyebrow">Écouté dans le mode ménage du hub</p>
        <h2 className="lux-display mt-1 text-lg text-white">Message vocal pour l&apos;équipe de ménage</h2>
        <p className="mt-1 text-sm text-[#8fa0c2]">
          Laissez une consigne parlée (rangement particulier, produits à utiliser…) : votre équipe
          l&apos;écoute directement dans le Mode Ménage du Hub, avant de commencer.
        </p>
      </div>

      {enabled && note && (
        <div className="mt-4 rounded-2xl border border-[#2dd4bf]/25 bg-[#2dd4bf]/8 p-4">
          <p className="flex items-center gap-2 text-sm font-semibold text-[#86e9cb]">
            <span className="lux-dot" style={{ backgroundColor: '#2dd4bf' }} aria-hidden="true" />
            Message actif{' '}
            <span className="font-normal text-[#8fa0c2]">
              ({note.source === 'tts' ? 'voix IA' : 'micro'}
              {note.durationSec > 0 ? ` · ${note.durationSec} s` : ''})
            </span>
          </p>
          <audio controls preload="none" src={note.audioUrl} className="mt-2 w-full max-w-md" />
          <div className="mt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-9 rounded-full border-[#f07d6a]/30 bg-transparent text-xs font-semibold text-[#f07d6a] hover:bg-[#f07d6a]/10 hover:text-[#f07d6a]"
              onClick={() => void deleteNote()}
            >
              Supprimer
            </Button>
          </div>
        </div>
      )}

      {enabled ? (
        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          {/* Voix IA */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="flex items-center gap-2 text-sm font-semibold text-white">
              <span className="lux-dot" style={{ backgroundColor: '#cdb6ff' }} aria-hidden="true" />
              Générer avec la voix IA
            </p>
            <p className="mt-1 text-xs text-[#8fa0c2]">
              Écrivez votre consigne, elle est transformée en message vocal.
            </p>
            <Textarea
              value={ttsText}
              onChange={(e) => setTtsText(e.target.value)}
              rows={3}
              maxLength={600}
              placeholder="Ex. : Bonjour ! Aujourd'hui, merci de changer aussi la housse de couette du lit double et de laisser la fenêtre de la chambre ouverte dix minutes."
              className={cn('mt-2', LUX_FIELD)}
              aria-label="Texte du message pour l'équipe de ménage"
            />
            <button
              type="button"
              className="lux-btn mt-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:pointer-events-none disabled:opacity-60"
              onClick={() => void generateTts()}
              disabled={ttsBusy || recording}
            >
              {ttsBusy && <LuxBusyDot />}
              Générer la voix
            </button>
          </div>

          {/* Micro */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <p className="flex items-center gap-2 text-sm font-semibold text-white">
              <span className="lux-dot" style={{ backgroundColor: '#f07d6a' }} aria-hidden="true" />
              Enregistrer avec votre micro
            </p>
            <p className="mt-1 text-xs text-[#8fa0c2]">Jusqu&apos;à {MAX_NOTE_SEC} secondes.</p>
            {recording ? (
              <div className="mt-2 flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-2 rounded-full border border-[#f07d6a]/30 bg-[#f07d6a]/10 px-3 py-1 text-sm font-semibold text-[#f07d6a]">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-[#f07d6a]" aria-hidden="true" />
                  <span className="lux-num">{recSec}</span> s / {MAX_NOTE_SEC} s
                </span>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className={cn('h-9 rounded-full', LUX_GHOST_BTN)}
                  onClick={stopRecording}
                >
                  Arrêter
                </Button>
              </div>
            ) : pending ? (
              <div className="mt-2 space-y-2">
                <audio controls preload="metadata" src={pending.dataUrl} className="w-full max-w-md" />
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    className="lux-btn focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60 disabled:pointer-events-none disabled:opacity-60"
                    onClick={() => void sendPending()}
                    disabled={uploadBusy}
                  >
                    {uploadBusy && <LuxBusyDot />}
                    Envoyer à l&apos;équipe
                  </button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className={cn('h-9 rounded-full', LUX_GHOST_BTN)}
                    onClick={() => setPending(null)}
                  >
                    Refaire
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="mt-2 h-9 rounded-full border-[#2dd4bf]/30 bg-[#2dd4bf]/8 text-xs font-semibold text-[#2dd4bf] hover:bg-[#2dd4bf]/15 hover:text-[#86e9cb]"
                onClick={() => void startRecording()}
                disabled={ttsBusy}
              >
                Démarrer l&apos;enregistrement
              </Button>
            )}
          </div>
        </div>
      ) : (
        <p className="mt-3 text-xs text-[#8fa0c2]">
          Sélectionnez un bien précis (barre du haut) pour enregistrer un message vocal.
        </p>
      )}
    </motion.section>
  );
}

// =============================================================
// 3. PREUVES DE MÉNAGE (rapports des passages)
// v4.53 — ARCHIVE HORODATÉE : chaque passage est archivé avec ses
// photos de fin de ménage, heures serveur et GPS ; l'hôte extrait en
// UN CLIC le rapport visuel horodaté (PDF) en cas de litige propreté.
// =============================================================
function ReportsSection({ reports }: { reports: MenageReport[] }) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [exportingId, setExportingId] = useState<string | null>(null);

  const toggle = useCallback((id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  // Export PDF en 1 clic : charge les photos complètes du rapport
  // (?reportId=&photos=full) puis génère le dossier horodaté.
  const exportPdf = useCallback(async (r: MenageReport) => {
    setExportingId(r.id);
    try {
      const res = await fetch(
        `/api/airbnb/menage?reportId=${encodeURIComponent(r.id)}&photos=full`,
        { cache: 'no-store' },
      );
      const json = (await res.json().catch(() => null)) as {
        report?: {
          photos: string[];
          checklist: { label: string; done: boolean }[];
          staffName: string | null;
          startedAt: string | null;
          endedAt: string | null;
          createdAt: string;
          startLat: number | null;
          startLng: number | null;
        } | null;
      } | null;
      if (!res.ok || !json?.report) {
        throw new Error('rapport introuvable');
      }
      await downloadCleaningReportPdf({
        propertyName: r.propertyName,
        staffName: json.report.staffName,
        checklist: json.report.checklist,
        photos: json.report.photos,
        startedAt: json.report.startedAt,
        endedAt: json.report.endedAt,
        createdAt: json.report.createdAt,
        startLat: json.report.startLat,
        startLng: json.report.startLng,
      });
      toast.success('Rapport visuel horodaté exporté en PDF ✅');
    } catch {
      toast.error('Export impossible. Réessayez.');
    } finally {
      setExportingId(null);
    }
  }, []);

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut', delay: 0.1 }}
      className="lux-card p-4 sm:p-6"
      aria-label="Preuves de ménage"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="lux-eyebrow">Archive horodatée</p>
          <h2 className="lux-display mt-1 text-lg text-white">Preuves de ménage</h2>
          <p className="mt-1 text-sm text-[#8fa0c2]">
            Passages de votre équipe : horaires, checklist validée, photos de l&apos;appartement
            propre et message vocal de l&apos;équipe.
          </p>
          {/* v4.53 — archive horodatée explicite (état des lieux) */}
          <p className="mt-2 inline-flex max-w-md items-start gap-2 rounded-lg border border-[#2dd4bf]/25 bg-[#2dd4bf]/8 px-2.5 py-1.5 text-xs leading-relaxed text-[#86e9cb]">
            <span className="lux-dot mt-1.5 shrink-0" style={{ backgroundColor: '#2dd4bf' }} aria-hidden="true" />
            Archive horodatée : chaque fin de ménage est archivée avec photos + heure serveur +
            GPS. En cas de litige propreté, extrayez le rapport visuel en un clic.
          </p>
        </div>
        {reports.length > 0 && (
          <span className="lux-chip shrink-0">
            <span className="lux-dot" style={{ backgroundColor: '#34d399' }} aria-hidden="true" />
            {reports.length} passage{reports.length > 1 ? 's' : ''}
          </span>
        )}
      </div>

      {reports.length === 0 ? (
        <div className="lux-empty mt-4 flex flex-col items-center gap-2 rounded-2xl p-8 text-center">
          <span className="lux-dot" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
          <p className="text-sm font-semibold text-white">Aucun passage pour le moment</p>
          <p className="max-w-md text-xs text-[#8fa0c2]">
            Votre femme de ménage valide son passage depuis le Mode Ménage du Hub (code staff) :
            ses preuves apparaîtront ici automatiquement.
          </p>
        </div>
      ) : (
        <ul className="lux-scroll mt-4 max-h-[62vh] space-y-3 overflow-y-auto pr-1">
          {reports.map((r) => {
            const done = r.checklist.filter((c) => c.done).length;
            const isOpen = expanded.has(r.id);
            return (
              <li
                key={r.id}
                className="rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition-colors hover:bg-white/[0.05]"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-white">Ménage terminé</p>
                    <p className="mt-0.5 text-xs text-[#8fa0c2]">
                      {r.propertyName && <span className="mr-2 font-semibold text-white">{r.propertyName}</span>}
                      {formatFrDateTime(r.endedAt ?? r.createdAt)}
                    </p>
                  </div>
                  <span className="lux-chip shrink-0">{r.staffName ?? 'Équipe ménage'}</span>
                </div>

                <p className="mt-1.5 flex items-center gap-2 text-xs text-[#8fa0c2]">
                  <span className="lux-dot shrink-0" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
                  {r.staffName ?? 'Équipe ménage'} ·{' '}
                  {r.startedAt
                    ? `Arrivée ${formatFrTime(r.startedAt)} · Départ ${formatFrTime(r.endedAt ?? r.createdAt)}`
                    : `Validé à ${formatFrTime(r.endedAt ?? r.createdAt)}`}
                </p>

                {r.coverPhoto && (
                  <a href={r.coverPhoto} target="_blank" rel="noopener noreferrer" className="relative mt-3 block">
                    <img
                      src={r.coverPhoto}
                      alt={`Appartement propre — ménage du ${formatFrDateTime(r.endedAt ?? r.createdAt)}`}
                      className="max-h-40 w-full rounded-xl border border-white/10 object-cover"
                    />
                    {r.photoCount > 1 && (
                      <span className="absolute bottom-2 right-2 rounded-full bg-[#060a17]/85 px-2 py-0.5 text-[11px] font-semibold text-white ring-1 ring-white/15">
                        +{r.photoCount - 1} photo{r.photoCount > 2 ? 's' : ''}
                      </span>
                    )}
                  </a>
                )}

                {r.voiceUrl && (
                  <div className="mt-3 rounded-2xl border border-[#2dd4bf]/20 bg-[#2dd4bf]/8 p-3">
                    <p className="flex items-center gap-2 text-xs font-semibold text-[#86e9cb]">
                      <span className="lux-dot" style={{ backgroundColor: '#2dd4bf' }} aria-hidden="true" />
                      Message vocal de l&apos;équipe
                      {r.voiceDurationSec > 0 ? ` (${r.voiceDurationSec} s)` : ''}
                    </p>
                    <audio controls preload="none" src={r.voiceUrl} className="mt-1 w-full" />
                  </div>
                )}

                {r.checklist.length > 0 && (
                  <div className="mt-3">
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className={cn('h-8 rounded-full border-white/12 bg-white/[0.04] text-xs', LUX_GHOST_BTN)}
                      onClick={() => toggle(r.id)}
                      aria-expanded={isOpen}
                    >
                      <span
                        aria-hidden="true"
                        className={cn('text-[10px] transition-transform', isOpen && 'rotate-180')}
                      >
                        ▾
                      </span>
                      {done}/{r.checklist.length} points validés · {isOpen ? 'Masquer' : 'Voir le détail'}
                    </Button>
                    {isOpen && (
                      <ul className="mt-2 space-y-1 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                        {r.checklist.map((c, i) => (
                          <li
                            key={`${r.id}-c-${i}`}
                            className={cn('flex items-center gap-2 text-sm', c.done ? 'text-white' : 'text-[#8fa0c2]/70')}
                          >
                            <span
                              className="lux-dot shrink-0"
                              style={{ backgroundColor: c.done ? '#34d399' : 'rgba(143,160,194,0.35)' }}
                              aria-hidden="true"
                            />
                            {c.label}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}

                {/* v4.53 — rapport visuel horodaté EN 1 CLIC (litige propreté) */}
                <div className="mt-3">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-8 rounded-full border-[#2dd4bf]/30 bg-[#2dd4bf]/8 text-xs font-semibold text-[#2dd4bf] hover:bg-[#2dd4bf]/15 hover:text-[#86e9cb]"
                    disabled={exportingId === r.id}
                    onClick={() => void exportPdf(r)}
                    aria-label="Extraire le rapport visuel horodaté du ménage (PDF)"
                  >
                    {exportingId === r.id && <LuxBusyDot color="#2dd4bf" />}
                    Rapport visuel (PDF)
                  </Button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </motion.section>
  );
}

// =============================================================
// v4.54 « ALERTES STOCK » (amélioration 2.2) — panel hôte
// Les signalements non résolus en tête (rouges), l'historique en
// dessous ; « Réapprovisionné ✓ » résout l'alerte en 1 clic.
// =============================================================
interface InventoryAlertApi {
  id: string;
  bookingId: string | null;
  item: string;
  itemLabel: string;
  itemEmoji: string;
  status: string;
  reportedBy: string | null;
  note: string | null;
  createdAt: string;
  resolvedAt: string | null;
}

function InventoryAlertsPanel({
  enabled,
  propertyId,
}: {
  enabled: boolean;
  propertyId: string | null;
}) {
  const [alerts, setAlerts] = useState<InventoryAlertApi[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  const load = useCallback(async (pid: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(pid)}/inventory-alerts`, {
        cache: 'no-store',
      });
      const json = (await res.json().catch(() => null)) as { alerts?: InventoryAlertApi[] } | null;
      if (res.ok && json) setAlerts(json.alerts ?? []);
      else setAlerts(null);
    } catch {
      setAlerts(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled || !propertyId) {
      setAlerts(null);
      return;
    }
    void load(propertyId);
  }, [enabled, propertyId, load]);

  const resolve = async (alertId: string) => {
    if (!propertyId || resolvingId) return;
    setResolvingId(alertId);
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(propertyId)}/inventory-alerts`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, action: 'RESOLVE' }),
      });
      if (!res.ok) throw new Error('http');
      setAlerts((prev) =>
        prev
          ? prev.map((a) => (a.id === alertId ? { ...a, resolvedAt: new Date().toISOString() } : a))
          : prev,
      );
      toast.success('Alerte résolue — merci !');
    } catch {
      toast.error('Résolution impossible. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  };

  if (!enabled) return null;

  const open = (alerts ?? []).filter((a) => !a.resolvedAt);
  const history = (alerts ?? []).filter((a) => a.resolvedAt);

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut', delay: 0.15 }}
      className="lux-card p-4 sm:p-5"
      aria-label="Alertes stock"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="lux-eyebrow">Stock minibar &amp; consommables</p>
          <h2 className="lux-display mt-1 text-lg text-white">Alertes stock</h2>
          <p className="mt-0.5 text-xs text-[#8fa0c2]">
            Signalements de l&apos;équipe de ménage (serviettes, papier toilette, savon, capsules café).
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className={cn('h-8 shrink-0 rounded-full border-white/12 bg-white/[0.04] px-3 text-xs', LUX_GHOST_BTN)}
          disabled={loading || !propertyId}
          onClick={() => propertyId && void load(propertyId)}
          aria-label="Rafraîchir les alertes stock"
        >
          {loading && <LuxBusyDot />}
          Actualiser
        </Button>
      </div>

      {alerts === null && !loading ? (
        <div className="lux-empty mt-4 flex flex-col items-center gap-2 rounded-2xl p-6 text-center">
          <span className="lux-dot" style={{ backgroundColor: '#e9c47c' }} aria-hidden="true" />
          <p className="text-sm font-semibold text-white">Aucune alerte pour le moment</p>
          <p className="text-xs text-[#8fa0c2]">
            L&apos;équipe signale le stock depuis le Mode Ménage du Hub (« Contrôle du stock »).
          </p>
        </div>
      ) : loading && alerts === null ? (
        <Skeleton className="mt-4 h-24 w-full rounded-2xl bg-white/8" />
      ) : (
        <div className="mt-4 space-y-3">
          {open.length === 0 && history.length === 0 && (
            <div className="lux-empty flex flex-col items-center gap-2 rounded-2xl p-6 text-center">
              <span className="lux-dot" style={{ backgroundColor: '#e9c47c' }} aria-hidden="true" />
              <p className="text-sm font-semibold text-white">Aucune alerte pour le moment</p>
              <p className="text-xs text-[#8fa0c2]">
                L&apos;équipe signale le stock depuis le Mode Ménage du Hub (« Contrôle du stock »).
              </p>
            </div>
          )}

          {open.length > 0 && (
            <ul className="space-y-2.5">
              {open.map((a) => {
                const meta = inventoryItemMeta(a.item);
                const statusMeta = INVENTORY_STATUS_META[a.status] ?? INVENTORY_STATUS_META.low;
                return (
                  <li
                    key={a.id}
                    className={cn(
                      'flex flex-col gap-3 rounded-2xl border p-4 sm:flex-row sm:items-start sm:justify-between',
                      a.status === 'empty'
                        ? 'border-[#f07d6a]/30 bg-[#f07d6a]/8'
                        : 'border-[#fbbf24]/30 bg-[#fbbf24]/8',
                    )}
                  >
                    <div className="min-w-0">
                      <p className="flex flex-wrap items-center gap-2 text-sm font-semibold text-white">
                        {meta.label}{' '}
                        <span className={`ml-1 inline-block rounded-full border px-2 py-0.5 text-[11px] font-bold ${statusMeta.className}`}>
                          {statusMeta.label}
                        </span>
                      </p>
                      <p className="mt-1 flex items-center gap-2 text-xs text-[#8fa0c2]">
                        <span
                          className="lux-dot shrink-0"
                          style={{ backgroundColor: a.status === 'empty' ? '#f07d6a' : '#fbbf24' }}
                          aria-hidden="true"
                        />
                        {a.reportedBy ?? 'Équipe ménage'} · {formatFrDateTime(a.createdAt)}
                        {a.note ? ` · « ${a.note.slice(0, 120)} »` : ''}
                      </p>
                    </div>
                    <Button
                      type="button"
                      size="sm"
                      className="h-9 shrink-0 rounded-full bg-gradient-to-br from-[#3d6fe0] to-[#24479c] px-4 text-xs font-semibold text-white shadow-[0_10px_28px_-12px_rgba(61,111,224,0.55)] hover:from-[#5c8af0] hover:to-[#2c56b8]"
                      disabled={resolvingId === a.id}
                      onClick={() => void resolve(a.id)}
                      aria-label={`Marquer ${meta.label} comme réapprovisionné`}
                    >
                      {resolvingId === a.id && <LuxBusyDot />}
                      Réapprovisionné
                    </Button>
                  </li>
                );
              })}
            </ul>
          )}

          {history.length > 0 && (
            <details className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <summary className="cursor-pointer text-sm font-semibold text-[#8fa0c2] transition-colors hover:text-white">
                Historique résolu ({history.length})
              </summary>
              <ul className="mt-2.5 space-y-1.5">
                {history.map((a) => {
                  const meta = inventoryItemMeta(a.item);
                  return (
                    <li key={a.id} className="flex items-center gap-2 text-xs text-[#8fa0c2]">
                      <span className="lux-dot shrink-0" style={{ backgroundColor: '#34d399' }} aria-hidden="true" />
                      {meta.label} — {INVENTORY_STATUS_META[a.status]?.short ?? a.status} ·{' '}
                      {a.reportedBy ?? 'Équipe'} · {formatFrDateTime(a.createdAt)} ·{' '}
                      <span aria-hidden="true" className="font-semibold text-[#34d399]">
                        ✓
                      </span>{' '}
                      résolu {a.resolvedAt ? formatFrDateTime(a.resolvedAt) : '—'}
                    </li>
                  );
                })}
              </ul>
            </details>
          )}
        </div>
      )}
    </motion.section>
  );
}

// =============================================================
// v5.0 « ÉTATS DES LIEUX DE SORTIE » — panel hôte
// Les 20 dernières inspections signées par les invités (toutes les
// propriétés ou le bien ciblé) : pièces endommagées/sales, auto-
// évaluation, statut de traitement (pending/reviewed/resolved),
// preuve publique + PDF. « Marquer traitée » résout en 1 clic.
// =============================================================
interface CheckoutInspectionApi {
  id: string;
  propertyId: string;
  propertyName: string | null;
  guestName: string;
  hasDamages: boolean;
  damagedRooms: string[];
  dirtyRooms: string[];
  selfAssessment: number;
  status: string;
  signedAt: string;
  createdAt: string;
  publicUrl: string;
}

const INSPECTION_STATUS_META: Record<string, { label: string; className: string }> = {
  pending: {
    label: 'À traiter',
    className: 'border-[#fbbf24]/30 bg-[#fbbf24]/10 text-[#fbbf24]',
  },
  reviewed: {
    label: 'Consultée',
    className: 'border-[#2dd4bf]/30 bg-[#2dd4bf]/10 text-[#2dd4bf]',
  },
  resolved: {
    label: 'Traitée',
    className: 'border-[#34d399]/30 bg-[#34d399]/10 text-[#34d399]',
  },
};

function CheckoutInspectionsSection({ selectedId }: { selectedId: string }) {
  const [inspections, setInspections] = useState<CheckoutInspectionApi[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [patchingId, setPatchingId] = useState<string | null>(null);

  const load = useCallback(async (mode: 'initial' | 'refresh') => {
    if (mode === 'initial') setLoading(true);
    try {
      const res = await fetch(`/api/airbnb/checkout-inspections?propertyId=${encodeURIComponent(selectedId)}`, {
        cache: 'no-store',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = (await res.json()) as { inspections?: CheckoutInspectionApi[] };
      setInspections(json.inspections ?? []);
    } catch {
      if (mode === 'initial') setInspections(null);
      if (mode === 'refresh') toast.error('Actualisation des états des lieux impossible.');
    } finally {
      setLoading(false);
    }
  }, [selectedId]);

  useEffect(() => {
    void load('initial');
  }, [load]);

  const markResolved = async (id: string) => {
    if (patchingId) return;
    setPatchingId(id);
    try {
      const res = await fetch('/api/airbnb/checkout-inspections', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: 'resolved' }),
      });
      if (!res.ok) throw new Error('http');
      setInspections((prev) =>
        prev ? prev.map((i) => (i.id === id ? { ...i, status: 'resolved' } : i)) : prev,
      );
      toast.success('Inspection marquée comme traitée.');
    } catch {
      toast.error('Mise à jour impossible. Réessayez.');
    } finally {
      setPatchingId(null);
    }
  };

  const stars = (n: number) => '★'.repeat(Math.max(0, Math.min(5, n))) + '☆'.repeat(Math.max(0, 5 - n));

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut', delay: 0.18 }}
      className="lux-card p-4 sm:p-5"
      aria-label="États des lieux de sortie"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="lux-eyebrow">Signés par vos invités</p>
          <h2 className="lux-display mt-1 text-lg text-white">États des lieux de sortie</h2>
          <p className="text-xs text-[#8fa0c2]">
            Inspections signées par vos invités avant leur départ
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          className={cn('h-9 gap-2 rounded-full px-4 text-xs', LUX_GHOST_BTN)}
          aria-label="Rafraîchir les états des lieux de sortie"
        >
          {loading && <LuxBusyDot />}
          Actualiser
        </Button>
      </div>

      {loading && inspections === null ? (
        <div className="mt-4 space-y-2.5" role="status" aria-label="Chargement des inspections">
          <Skeleton className="h-20 w-full rounded-2xl bg-white/8" />
          <Skeleton className="h-20 w-full rounded-2xl bg-white/8" />
        </div>
      ) : !inspections || inspections.length === 0 ? (
        <div className="lux-empty mt-4 flex flex-col items-center gap-2 rounded-2xl py-8 text-center">
          <span className="lux-dot" style={{ backgroundColor: '#cdb6ff' }} aria-hidden="true" />
          <p className="text-sm font-semibold text-white">Aucun état des lieux pour le moment</p>
          <p className="mt-1 max-w-md text-xs text-[#8fa0c2]">
            L&apos;invité signe son inspection depuis son Hub (« Je quitte le logement ») — le document
            apparaît ici instantanément.
          </p>
        </div>
      ) : (
        <ul className="lux-scroll mt-4 max-h-96 space-y-2.5 overflow-y-auto pr-1">
          {inspections.map((i) => {
            const statusMeta = INSPECTION_STATUS_META[i.status] ?? INSPECTION_STATUS_META.pending;
            return (
              <li
                key={i.id}
                className={cn(
                  'rounded-2xl border p-4',
                  i.hasDamages
                    ? 'border-[#f07d6a]/30 bg-[#f07d6a]/8'
                    : 'border-white/10 bg-white/[0.03]',
                )}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="flex flex-wrap items-center gap-2 text-sm font-semibold text-white">
                      {i.guestName}
                      {i.hasDamages && (
                        <span className="inline-block rounded-full border border-[#f07d6a]/30 bg-[#f07d6a]/12 px-2 py-0.5 text-[10px] font-bold text-[#f07d6a]">
                          Dégâts signalés
                        </span>
                      )}
                      <span className={`inline-block rounded-full border px-2 py-0.5 text-[10px] font-bold ${statusMeta.className}`}>
                        {statusMeta.label}
                      </span>
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-[#8fa0c2]">
                      <span className="lux-dot shrink-0" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
                      {i.propertyName ? `${i.propertyName} · ` : ''}
                      {formatFrDateTime(i.signedAt)} ·{' '}
                      <span className="text-[#e9c47c]">{stars(i.selfAssessment)}</span>{' '}
                      <span className="lux-num text-[#e9c47c]">{i.selfAssessment}</span>
                      /5
                    </p>
                    {(i.damagedRooms.length > 0 || i.dirtyRooms.length > 0) && (
                      <p className="mt-1.5 flex flex-wrap gap-1">
                        {i.damagedRooms.map((room) => (
                          <span
                            key={`d-${room}`}
                            className="rounded-full border border-[#f07d6a]/35 bg-[#f07d6a]/12 px-2 py-0.5 text-[10px] font-bold text-[#f07d6a]"
                          >
                            {room}
                          </span>
                        ))}
                        {i.dirtyRooms.map((room) => (
                          <span
                            key={`s-${room}`}
                            className="rounded-full border border-[#fbbf24]/35 bg-[#fbbf24]/12 px-2 py-0.5 text-[10px] font-bold text-[#fbbf24]"
                          >
                            {room}
                          </span>
                        ))}
                      </p>
                    )}
                  </div>
                  <div className="flex shrink-0 flex-wrap items-center gap-1.5">
                    <a
                      href={i.publicUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex h-9 items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3 text-xs font-semibold text-[#d5def0] transition-colors hover:bg-white/8 hover:text-white"
                      aria-label={`Voir la preuve publique de ${i.guestName}`}
                    >
                      Preuve publique
                    </a>
                    <a
                      href={`${i.publicUrl.replace(/^\/public\/inspection\//, '/api/public/inspection/')}/pdf`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex h-9 items-center gap-1.5 rounded-full border border-white/12 bg-white/[0.04] px-3 text-xs font-semibold text-[#d5def0] transition-colors hover:bg-white/8 hover:text-white"
                      aria-label={`Voir le PDF de ${i.guestName}`}
                    >
                      PDF
                    </a>
                    {i.status !== 'resolved' && (
                      <Button
                        type="button"
                        size="sm"
                        className="h-9 rounded-full bg-gradient-to-br from-[#3d6fe0] to-[#24479c] px-4 text-xs font-semibold text-white shadow-[0_10px_28px_-12px_rgba(61,111,224,0.55)] hover:from-[#5c8af0] hover:to-[#2c56b8]"
                        disabled={patchingId === i.id}
                        onClick={() => void markResolved(i.id)}
                        aria-label={`Marquer l'inspection de ${i.guestName} comme traitée`}
                      >
                        {patchingId === i.id && <LuxBusyDot />}
                        Marquer traitée
                      </Button>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </motion.section>
  );
}
