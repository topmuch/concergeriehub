'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { LogIn, LogOut, ShieldCheck, Timer } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useOverview, type ActivityItem } from '@/hooks/use-overview';
import { OnboardingWizard } from '@/components/airbnb/onboarding-wizard';
import { CoachWidget } from '@/components/airbnb/host/coach-widget';
import { PropertyDonut } from '@/components/airbnb/host/property-donut';
import { relativeFrTime } from '@/lib/automations';
import { cn } from '@/lib/utils';

// =============================================================
// OverviewContent — page « Vue d'ensemble » du Dashboard Hôte
// v7.0 « AZUR » — refonte design (demande client) : style dashboard
// bleu/lavande — cartes blanches arrondies sur fond #E4E9F7, tuiles
// KPI en dégradés colorés (bleu/rouge/orange/violet) avec grande
// valeur blanche + vague SVG, graphique aires VIOLET dégradé,
// donut à gros chiffre centré, flux d'activité en cartes.
//
// • Les 4 cartes KPI lisibles conservées (Task 3-a) :
//     1 Check-ins terminés (ratio X/X cette semaine) — dégradé bleu
//     2 Check-outs terminés (ratio X/X cette semaine) — dégradé rouge
//     3 Revenus protégés (cautions sécurisées, estimation) — orange
//     4 Temps gagné (EDL digitaux × 45 min, ce mois) — violet
// • Widget « Prochains événements » + graphique + donut + flux :
//   TOUTES les données/textes/liens conservés à l'identique.
// =============================================================

// ---------- Couleurs du graphe (thème AZUR violet/rose — v7.0) ----------
const BLUE_MAIN = '#7C6FF0';   // créations de séjours (héros violet)
const BLUE_SOFT = '#93B4FF';   // scans de plaques (bleu clair)
const GOLD_ACCENT = '#F472B6'; // commandes invités (rose secondaire)

// ---------- Types ----------
interface KpiResponse {
  checkinsDone: number;
  checkinsTotal: number;
  checkoutsDone: number;
  checkoutsTotal: number;
  protectedRevenueEur: number;
  protectedStaysCount: number;
  minutesSaved: number;
  inspectionsThisMonth: number;
  damagesCount: number;
  upcomingEvents: UpcomingEvent[];
}

interface UpcomingEvent {
  id: string;
  kind: 'checkin' | 'checkout' | 'housekeeping';
  title: string;
  propertyName: string;
  at: string;
  bookingId: string | null;
  hasDispute: boolean;
}

interface DayStatsResponse {
  scope: 'single' | 'all';
  property: { id: string; name: string } | null;
  stats: {
    propertiesActive: number;
    propertiesCount: number;
    staysInProgress: number;
    arrivalsToday: number;
    departuresToday: number;
    revenueThisMonth: number;
    ordersThisMonth: number;
    canSeeFinance: boolean;
  };
  today: {
    id: string;
    kind: 'arrival' | 'departure';
    guestName: string;
    propertyName: string;
    at: string;
    status: string;
    source: string;
  }[];
}

interface NotifItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  isRead: boolean;
  createdAt: string;
}

// ---------- Helpers ----------
function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);
}

function greeting(date: Date): string {
  const h = date.getHours();
  if (h < 12) return 'Bonjour';
  if (h < 18) return 'Bon après-midi';
  return 'Bonsoir';
}

function longDateFr(d: Date): string {
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

const fmtHour = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });
const fmtEventDay = new Intl.DateTimeFormat('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });

function sourceLabel(source: string): string {
  if (source === 'ICAL') return 'iCal';
  if (source === 'MANUAL') return 'Manuelle';
  return source.charAt(0) + source.slice(1).toLowerCase();
}

/** Statut de réservation → libellé + pastille colorée (sans badge à icône). */
function statusMeta(status: string): { label: string; dot: string } {
  switch (status) {
    case 'CONFIRMED':
      return { label: 'Confirmée', dot: '#10b981' };
    case 'PENDING':
      return { label: 'En attente', dot: '#f59e0b' };
    case 'COMPLETED':
      return { label: 'Terminée', dot: '#94a3b8' };
    default:
      return { label: status.toLowerCase(), dot: '#94a3b8' };
  }
}

/** Point coloré par type d'événement du flux d'activité. */
const ACTIVITY_DOT: Record<ActivityItem['type'], string> = {
  scan: '#2563EB',
  order: '#10b981',
  booking: '#7C6FF0',
  message: '#f59e0b',
};

/** Task 3-a — libellé et teinte du badge de type (prochains événements). */
const EVENT_KIND_LABEL: Record<UpcomingEvent['kind'], string> = {
  checkin: 'Check-in',
  checkout: 'Check-out',
  housekeeping: 'Ménage',
};
const EVENT_TONE: Record<UpcomingEvent['kind'], string> = {
  checkin: '#2563EB',
  checkout: '#0d9488',
  housekeeping: '#d97706',
};

/** Task 3-a — minutes → « 4 h 30 » / « 3 h » / « 45 min » (fr-FR). */
function formatHoursMinutes(minutes: number): string {
  if (minutes <= 0) return '0 min';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h} h`;
  return `${h} h ${String(m).padStart(2, '0')}`;
}

function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** Task 3-a — échéance lisible : « dans 2 h », « demain à 11:00 », « sam. 19 oct. ». */
function eventWhenLabel(target: Date, now: Date): string {
  const diffMin = Math.round((target.getTime() - now.getTime()) / 60_000);
  if (diffMin <= 0) return 'maintenant';
  if (diffMin < 60) return `dans ${diffMin} min`;
  if (isSameDay(target, now)) return `dans ${Math.floor(diffMin / 60)} h`;
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  if (isSameDay(target, tomorrow)) return `demain à ${fmtHour.format(target)}`;
  return fmtEventDay.format(target);
}

function LuxSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-slate-100', className)} />;
}

// ---------- Carte KPI rectangulaire (Task 3-a) : icône + gros chiffre + libellé ----------
// v7.0 « AZUR » — tuile en DÉGRADÉ coloré (bleu/rouge/orange/violet),
// GRANDE valeur blanche + vague SVG décorative (demande client).
const KPI_GRADIENTS = [
  'linear-gradient(160deg,#5B8CFF,#2E5BFF)', // 0 · bleu — check-ins
  'linear-gradient(160deg,#FF6B7E,#E11D48)', // 1 · rouge — check-outs
  'linear-gradient(160deg,#FF9A62,#F97316)', // 2 · orange — revenus protégés
  'linear-gradient(160deg,#C084FC,#7C3AED)', // 3 · violet — temps gagné
];

function KpiCard({
  icon: Icon,
  value,
  label,
  hint,
  chip,
  loading,
  index = 0,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
  hint?: string;
  chip?: string;
  loading?: boolean;
  index?: number;
}) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.35, ease: 'easeOut' }}
      className="relative overflow-hidden rounded-2xl p-5 text-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.25)]"
      style={{ background: KPI_GRADIENTS[index % KPI_GRADIENTS.length] }}
      aria-label={loading ? `${label} (chargement)` : `${label} : ${value}`}
    >
      {/* Vague SVG décorative (blanc translucide) en bas de tuile */}
      <svg
        aria-hidden="true"
        viewBox="0 0 220 40"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-9 w-full"
      >
        <path
          d="M0 40 L0 22 C 30 4, 55 30, 90 18 C 125 6, 150 28, 185 14 C 198 9, 210 10, 220 16 L220 40 Z"
          fill="#ffffff"
          fillOpacity="0.2"
        />
      </svg>
      <div className="relative flex items-center justify-between gap-2">
        <span
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white/20 ring-1 ring-white/30 text-white"
          aria-hidden="true"
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
        {chip && !loading && (
          <span className="inline-flex shrink-0 items-center rounded-full bg-white/25 px-2 py-0.5 text-[10px] font-bold text-white ring-1 ring-white/30">
            {chip}
          </span>
        )}
      </div>
      {loading ? (
        <div className="relative mt-3 h-9 w-24 animate-pulse rounded-lg bg-white/25" aria-hidden="true" />
      ) : (
        <p className="relative mt-3 truncate text-3xl font-bold leading-none tracking-tight text-white sm:text-4xl">{value}</p>
      )}
      <span className="relative mt-2 block text-[11px] font-bold uppercase tracking-[0.14em] text-white/80">{label}</span>
      {hint && !loading && (
        <p className="relative mt-1.5 line-clamp-2 text-[12px] font-medium leading-snug text-white/75">{hint}</p>
      )}
    </motion.article>
  );
}

// =============================================================
export function OverviewContent() {
  const { userFirstName, invitations, properties, propertiesLoading, selectedId, onboardingCompleted, refreshProperties } =
    useHostContext();
  const { data, loading, error, refetch } = useOverview();
  const now = new Date();

  // ----- Les 4 KPI lisibles (Task 3-a) : /api/airbnb/dashboard-kpis -----
  const [kpi, setKpi] = useState<KpiResponse | null>(null);
  const [kpiLoading, setKpiLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);

  // ----- KPIs « journée » : /api/airbnb/dashboard-stats (real data) -----
  const [day, setDay] = useState<DayStatsResponse | null>(null);
  const [dayLoading, setDayLoading] = useState(true);

  // Horloge pour les comptes à rebours (mise à jour chaque minute,
  // après montage uniquement — anti-hydratation).
  const [tick, setTick] = useState<Date | null>(null);
  useEffect(() => {
    setTick(new Date());
    const id = setInterval(() => setTick(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (propertiesLoading) return;
    let cancelled = false;
    setKpiLoading(true);
    setDayLoading(true);
    (async () => {
      try {
        const qs = `?propertyId=${encodeURIComponent(selectedId)}`;
        const [resKpi, resDay] = await Promise.all([
          fetch(`/api/airbnb/dashboard-kpis${qs}`, { cache: 'no-store' }),
          fetch(`/api/airbnb/dashboard-stats${qs}`, { cache: 'no-store' }),
        ]);
        if (resKpi.ok) setKpi((await resKpi.json()) as KpiResponse);
        else setKpi(null);
        if (resDay.ok) setDay((await resDay.json()) as DayStatsResponse);
        else setDay(null);
      } catch {
        if (!cancelled) {
          setKpi(null);
          setDay(null);
        }
      } finally {
        if (!cancelled) {
          setKpiLoading(false);
          setDayLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedId, propertiesLoading, reloadKey]);

  // ----- Dernières notifications de l'utilisateur (section « Activité récente ») -----
  const [notifs, setNotifs] = useState<NotifItem[]>([]);
  const [notifsLoading, setNotifsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/airbnb/notifications?limit=8', { cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as { notifications: NotifItem[] };
        if (!cancelled) setNotifs(json.notifications ?? []);
      } catch {
        if (!cancelled) setNotifs([]);
      } finally {
        if (!cancelled) setNotifsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  // ----- Chantier ONBOARDING : assistant post-inscription (conservé) -----
  const [onboardingClosed, setOnboardingClosed] = useState(false);
  const onboardingTarget = useMemo(() => {
    if (propertiesLoading || onboardingClosed || onboardingCompleted) return null;
    if (typeof window !== 'undefined' && sessionStorage.getItem('ch-onboarding-dismissed') === '1') {
      return null;
    }
    const owned = properties.find((p) => p.isOwner);
    if (!owned) return null;
    return { propertyId: owned.id, name: owned.name, address: owned.address ?? '' };
  }, [properties, propertiesLoading, onboardingCompleted, onboardingClosed]);

  function finishOnboarding(completed: boolean) {
    setOnboardingClosed(true);
    if (completed) {
      toast.success('Votre logement est configuré');
      void refreshProperties();
      void refetch();
    }
  }

  function refreshAll() {
    void refetch();
    setReloadKey((k) => k + 1);
    toast.success('Données actualisées');
  }

  const kpiPending = kpiLoading || propertiesLoading;
  const today = day?.today ?? [];

  return (
    // v7.0 « AZUR » — fond lavande explicite, encre slate (rendu
    // identique en mode clair et sombre).
    <div className="-m-4 min-h-full bg-[#E4E9F7] p-4 pb-10 text-slate-800 sm:-m-6 sm:p-6">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-7">
          {/* ═══════════ HERO — carte blanche arrondie (v7.0) ═══════════ */}
          <motion.section
            aria-label="Vue d'ensemble"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="relative overflow-hidden rounded-2xl border border-slate-100 bg-white p-6 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-8"
          >
            {/* Liseré dégradé bleu discret en haut de la carte */}
            <div
              aria-hidden="true"
              className="absolute inset-x-0 top-0 h-1.5"
              style={{ background: 'linear-gradient(90deg,#4A8BFF,#7C6FF0,#F472B6)' }}
            />
            <div className="relative flex flex-wrap items-start justify-between gap-x-6 gap-y-4">
              <div className="min-w-0">
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-600" suppressHydrationWarning>
                  {longDateFr(now)}
                </p>
                <h1
                  className="mt-2 text-3xl font-bold tracking-tight text-slate-800 sm:text-[40px]"
                  suppressHydrationWarning
                >
                  {greeting(now)}, {userFirstName}
                </h1>
                <p className="mt-2.5 max-w-xl text-sm text-slate-500 sm:text-[15px]" suppressHydrationWarning>
                  {data?.scope === 'single' && data.property ? (
                    <>
                      Activité de <span className="font-semibold text-slate-800">{data.property.name}</span> — voici
                      l&apos;état de vos locations aujourd&apos;hui.
                    </>
                  ) : (
                    <>
                      Vue consolidée de vos {properties.length} propriétés — voici l&apos;état de vos locations
                      aujourd&apos;hui.
                    </>
                  )}
                </p>

                {/* Actions du hero — boutons dégradé bleu + blancs */}
                <div className="mt-6 flex flex-wrap items-center gap-2.5">
                  <Link
                    href="/airbnb/properties?new=1"
                    className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                  >
                    Nouvelle propriété
                  </Link>
                  <Link
                    href="/airbnb/calendar"
                    className="inline-flex items-center justify-center rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition-colors hover:bg-slate-50 hover:text-slate-900"
                  >
                    Ajouter un séjour
                  </Link>
                  <Link
                    href="/airbnb/menage"
                    className="inline-flex items-center justify-center rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition-colors hover:bg-slate-50 hover:text-slate-900"
                  >
                    Voir les tâches
                  </Link>
                  <button
                    type="button"
                    onClick={refreshAll}
                    disabled={loading || dayLoading || kpiLoading}
                    className="inline-flex items-center justify-center rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition-colors hover:bg-slate-50 hover:text-slate-900 disabled:opacity-50"
                  >
                    Actualiser
                  </button>
                </div>
              </div>

              {/* Monogramme de la maison (décor) */}
              <div className="hidden shrink-0 items-center gap-3 sm:flex" aria-hidden="true">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] text-xl font-bold text-white shadow-lg shadow-blue-500/25">R</span>
              </div>
            </div>
          </motion.section>

          {/* ═══════════ Bannière invitations en attente (conservée) ═══════════ */}
          {invitations.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-wrap items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3"
              role="status"
            >
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#f59e0b' }} aria-hidden="true" />
              <p className="flex-1 text-sm text-amber-800">
                <span className="font-semibold">
                  {invitations.length === 1 ? 'Une invitation en attente' : `${invitations.length} invitations en attente`}
                </span>{' '}
                — {invitations[0].property.name} ({roleLabel(invitations[0].role)})
                {invitations.length > 1 && ' et d’autres…'}
              </p>
              <Link
                href="/airbnb/team"
                className="inline-flex h-9 items-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105"
              >
                Gérer mes invitations
              </Link>
            </motion.div>
          )}

          {/* ═══════════ Erreur API (conservée) ═══════════ */}
          {error && (
            <div className="flex flex-col items-center gap-3 rounded-2xl border border-rose-100 bg-white p-6 text-center shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]" role="alert">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#f43f5e' }} aria-hidden="true" />
              <p className="text-sm font-semibold text-slate-800">{error}</p>
              <button
                type="button"
                onClick={() => void refetch()}
                className="mt-1 inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105"
              >
                Réessayer
              </button>
            </div>
          )}

          {/* ═════ LES 4 KPI rectangulaires — icône + gros chiffre + libellé explicite (Task 3-a) ═════ */}
          <section aria-label="Indicateurs clés" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {/* KPI 1 · Check-ins terminés — ratio X/X (JAMAIS un pourcentage nu) */}
            <KpiCard
              index={0}
              icon={LogIn}
              loading={kpiPending}
              value={kpi ? `${kpi.checkinsDone}/${kpi.checkinsTotal}` : '—'}
              label="Check-ins terminés"
              hint={
                kpi && kpi.checkinsTotal > 0
                  ? `${kpi.checkinsTotal} arrivée${kpi.checkinsTotal > 1 ? 's' : ''} prévue${kpi.checkinsTotal > 1 ? 's' : ''} cette semaine`
                  : 'Aucune arrivée prévue cette semaine'
              }
            />

            {/* KPI 2 · Check-outs terminés — même logique de ratio */}
            <KpiCard
              index={1}
              icon={LogOut}
              loading={kpiPending}
              value={kpi ? `${kpi.checkoutsDone}/${kpi.checkoutsTotal}` : '—'}
              label="Check-outs terminés"
              hint={
                kpi && kpi.checkoutsTotal > 0
                  ? `${kpi.checkoutsTotal} départ${kpi.checkoutsTotal > 1 ? 's' : ''} prévu${kpi.checkoutsTotal > 1 ? 's' : ''} cette semaine`
                  : 'Aucun départ prévu cette semaine'
              }
            />

            {/* KPI 3 · Revenus protégés — cautions des séjours terminés sans dégât */}
            <KpiCard
              index={2}
              icon={ShieldCheck}
              loading={kpiPending}
              value={kpi ? formatEur(kpi.protectedRevenueEur) : '—'}
              label="Revenus protégés"
              chip={
                kpi && kpi.damagesCount > 0
                  ? `${kpi.damagesCount} dégât${kpi.damagesCount > 1 ? 's' : ''} à traiter`
                  : undefined
              }
              hint={
                kpi && kpi.protectedStaysCount > 0
                  ? `${kpi.protectedStaysCount} séjour${kpi.protectedStaysCount > 1 ? 's' : ''} sans dégât — cautions sécurisées (estimation)`
                  : 'Cautions sécurisées (estimation)'
              }
            />

            {/* KPI 4 · Temps gagné — EDL digitaux du mois × 45 min */}
            <KpiCard
              index={3}
              icon={Timer}
              loading={kpiPending}
              value={kpi ? formatHoursMinutes(kpi.minutesSaved) : '—'}
              label="Temps gagné"
              hint={
                kpi && kpi.inspectionsThisMonth > 0
                  ? `${kpi.inspectionsThisMonth} EDL ce mois — économisées grâce aux EDL digitaux`
                  : 'Économisées ce mois-ci grâce aux EDL digitaux'
              }
            />
          </section>

          {/* ═════ PROCHAINS ÉVÉNEMENTS — 3 échéances + compte à rebours FR (Task 3-a) ═════ */}
          <section
            aria-label="Prochains événements"
            className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6"
          >
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">À venir</h2>
                <p className="mt-1 text-[15px] font-bold text-slate-800">Prochains événements</p>
                <p className="mt-0.5 text-xs text-slate-400">Check-ins, check-outs et ménages planifiés</p>
              </div>
              <Link
                href="/airbnb/calendar"
                className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700 ring-1 ring-blue-200 transition-colors hover:bg-blue-100"
              >
                Calendrier <span aria-hidden="true">→</span>
              </Link>
            </div>

            {kpiPending ? (
              <div className="flex flex-col gap-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <LuxSkeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : (kpi?.upcomingEvents.length ?? 0) === 0 ? (
              <div className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-slate-50 p-6 text-center ring-1 ring-slate-100">
                <p className="text-base font-bold text-slate-800">Rien de prévu</p>
                <p className="max-w-sm text-xs text-slate-400">
                  Aucun check-in, check-out ni ménage à venir sur ce périmètre.
                </p>
              </div>
            ) : (
              <ul className="flex flex-col gap-2">
                {kpi?.upcomingEvents.map((ev, i) => (
                  <motion.li
                    key={ev.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.04 * i, duration: 0.25 }}
                  >
                    <Link
                      href="/airbnb/calendar"
                      className="group flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50 px-3.5 py-2.5 transition-colors hover:bg-[#F8FAFF] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                    >
                      <span
                        className="w-[72px] shrink-0 text-center text-[10px] font-bold uppercase leading-tight tracking-[0.12em]"
                        style={{ color: EVENT_TONE[ev.kind] }}
                      >
                        {EVENT_KIND_LABEL[ev.kind]}
                      </span>
                      <span className="h-8 w-px shrink-0 bg-slate-200" aria-hidden="true" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-slate-800">
                          {ev.title}
                          {ev.hasDispute && (
                            <span className="ml-2 inline-flex items-center rounded-full bg-rose-50 px-2 py-0.5 align-middle text-[10px] font-bold uppercase tracking-wide text-rose-600 ring-1 ring-rose-200">
                              Litige
                            </span>
                          )}
                        </p>
                        <p className="truncate text-xs text-slate-400">{ev.propertyName}</p>
                      </div>
                      <span
                        className="shrink-0 text-right text-[12px] font-semibold tabular-nums text-blue-700"
                        suppressHydrationWarning
                      >
                        {tick ? eventWhenLabel(new Date(ev.at), tick) : '—'}
                      </span>
                      <span
                        aria-hidden="true"
                        className="shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5"
                      >
                        →
                      </span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            )}
          </section>

          {/* ═══════════ COACH ROOMSCAN — recommandations IA du jour (v5.4) ═══════════ */}
          <CoachWidget refreshKey={reloadKey} />

          {/* ═══════════ Arrivées & Départs du jour + Activité récente ═══════════ */}
          <section aria-label="Journée et notifications" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            {/* ----- Arrivées & Départs du jour (real data) ----- */}
            <div className="flex flex-col rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6 xl:col-span-2">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Programme du jour</h2>
                  <p className="mt-1 text-[15px] font-bold text-slate-800" suppressHydrationWarning>
                    Arrivées &amp; départs
                  </p>
                </div>
                <Link
                  href="/airbnb/calendar"
                  className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700 ring-1 ring-blue-200 transition-colors hover:bg-blue-100"
                >
                  Calendrier <span aria-hidden="true">→</span>
                </Link>
              </div>

              {kpiLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : today.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl bg-slate-50 p-8 text-center ring-1 ring-slate-100">
                  <p className="text-lg font-bold text-slate-800">Journée tranquille</p>
                  <p className="max-w-xs text-xs text-slate-400">
                    Ni arrivée ni départ aujourd&apos;hui. Les réservations du calendrier apparaîtront ici.
                  </p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[320px] flex-col gap-2 overflow-y-auto pr-1">
                  {today.map((item, i) => {
                    const st = statusMeta(item.status);
                    const isArrival = item.kind === 'arrival';
                    return (
                      <motion.li
                        key={item.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.04 * i, duration: 0.25 }}
                        className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50 px-3.5 py-2.5"
                      >
                        <span
                          className="w-10 shrink-0 text-center text-[13px] font-bold tabular-nums"
                          style={{ color: isArrival ? '#2563EB' : '#0d9488' }}
                        >
                          {fmtHour.format(new Date(item.at))}
                        </span>
                        <span className="h-8 w-px shrink-0 bg-slate-200" aria-hidden="true" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-slate-800">{item.guestName}</p>
                          <p className="truncate text-xs text-slate-400">
                            {item.propertyName} · {isArrival ? 'Arrivée' : 'Départ'} · {sourceLabel(item.source)}
                          </p>
                        </div>
                        <span className="hidden shrink-0 items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200 sm:inline-flex">
                          <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: st.dot }} aria-hidden="true" />
                          {st.label}
                        </span>
                      </motion.li>
                    );
                  })}
                </ul>
              )}
            </div>

            {/* ----- Activité récente : dernières notifications ----- */}
            <div className="flex flex-col rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Activité récente</h2>
                <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600 ring-1 ring-slate-200">{notifsLoading ? '…' : notifs.length}</span>
              </div>
              {notifsLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : notifs.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl bg-slate-50 p-6 text-center ring-1 ring-slate-100">
                  <p className="text-lg font-bold text-slate-800">Rien pour l&apos;instant</p>
                  <p className="text-xs text-slate-400">Réservations, ménages et réclamations arriveront ici.</p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[320px] flex-col gap-1 overflow-y-auto pr-1">
                  {notifs.map((n) => (
                    <li
                      key={n.id}
                      className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-slate-50"
                    >
                      <span
                        className="mt-1.5 h-2 w-2 shrink-0 rounded-full"
                        style={{ backgroundColor: n.isRead ? '#cbd5e1' : '#2563EB' }}
                        aria-hidden="true"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-slate-800">{n.title}</p>
                        {n.body && <p className="line-clamp-2 text-xs text-slate-400">{n.body}</p>}
                      </div>
                      <time
                        dateTime={n.createdAt}
                        className="shrink-0 text-[11px] text-slate-400"
                        title={new Date(n.createdAt).toLocaleString('fr-FR')}
                      >
                        {relativeFrTime(new Date(n.createdAt))}
                      </time>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          {/* ═════ Graphique Activité + donut Répartition + Flux d'activité (Task 3-a) ═════ */}
          <section aria-label="Activité et historique" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            {/* Graphique 30 jours — créations de séjours + scans + commandes */}
            <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] xl:col-span-2">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Tendance</h2>
                  <p className="mt-1 text-[15px] font-bold text-slate-800">Activité des 30 derniers jours</p>
                  {/* Task 3-a — légende explicite sous le titre */}
                  <p className="mt-0.5 text-xs text-slate-400">Créations de séjours par jour — 30 derniers jours</p>
                </div>
                {/* Task 3-a — sous-total clair (données réelles) */}
                {loading || propertiesLoading ? (
                  <LuxSkeleton className="h-6 w-32" />
                ) : (
                  <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700 ring-1 ring-blue-200">
                    {data?.stats
                      ? `${data.stats.bookingsThisMonth} séjour${data.stats.bookingsThisMonth > 1 ? 's' : ''} créé${data.stats.bookingsThisMonth > 1 ? 's' : ''} ce mois`
                      : '— séjours créés ce mois'}
                  </span>
                )}
              </div>
              {loading || propertiesLoading ? (
                <LuxSkeleton className="h-[280px] w-full" />
              ) : (
                <div
                  className="h-[280px] w-full"
                  role="img"
                  aria-label="Courbe d'activité des 30 derniers jours : créations de séjours, scans et commandes par jour"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data?.series ?? []} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                      <defs>
                        {/* v7.0 « AZUR » — aires VIOLET dégradé → transparent */}
                        <linearGradient id="gradBookingsLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={BLUE_MAIN} stopOpacity={0.35} />
                          <stop offset="100%" stopColor={BLUE_MAIN} stopOpacity={0.02} />
                        </linearGradient>
                        <linearGradient id="gradScansLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={BLUE_SOFT} stopOpacity={0.26} />
                          <stop offset="100%" stopColor={BLUE_SOFT} stopOpacity={0.02} />
                        </linearGradient>
                        <linearGradient id="gradOrdersLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={GOLD_ACCENT} stopOpacity={0.26} />
                          <stop offset="100%" stopColor={GOLD_ACCENT} stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 11, fill: '#94A3B8' }}
                        tickLine={false}
                        axisLine={{ stroke: '#E2E8F0' }}
                        interval="preserveStartEnd"
                        minTickGap={24}
                      />
                      <YAxis
                        yAxisId="counts"
                        tick={{ fontSize: 11, fill: '#94A3B8' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <YAxis
                        yAxisId="orders"
                        orientation="right"
                        tick={{ fontSize: 11, fill: '#94A3B8' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip
                        contentStyle={{
                          borderRadius: 12,
                          border: '1px solid #E2E8F0',
                          backgroundColor: '#ffffff',
                          color: '#0f172a',
                          boxShadow: '0 12px 32px rgba(37,99,235,0.15)',
                          fontSize: 13,
                        }}
                        labelStyle={{ color: '#64748b', fontWeight: 600 }}
                        itemStyle={{ color: '#0f172a' }}
                        cursor={{ stroke: 'rgba(37,99,235,0.25)' }}
                        formatter={(value: number | string, name: string) => [
                          String(value),
                          name === 'bookings'
                            ? 'Créations de séjours'
                            : name === 'scans'
                              ? 'Scans de plaques'
                              : 'Commandes invités',
                        ]}
                      />
                      <Legend
                        formatter={(value: string) => (
                          <span className="text-xs font-medium text-slate-400">
                            {value === 'bookings'
                              ? 'Créations de séjours'
                              : value === 'scans'
                                ? 'Scans de plaques'
                                : 'Commandes invités'}
                          </span>
                        )}
                      />
                      <Area
                        yAxisId="counts"
                        type="monotone"
                        dataKey="scans"
                        stroke={BLUE_SOFT}
                        strokeWidth={1.5}
                        fill="url(#gradScansLux)"
                        activeDot={{ r: 3, strokeWidth: 2, fill: '#ffffff' }}
                      />
                      <Area
                        yAxisId="orders"
                        type="monotone"
                        dataKey="orders"
                        stroke={GOLD_ACCENT}
                        strokeWidth={1.5}
                        fill="url(#gradOrdersLux)"
                        activeDot={{ r: 3, strokeWidth: 2, fill: '#ffffff' }}
                      />
                      {/* Task 3-a — série héros : créations de séjours (violet #7C6FF0) */}
                      <Area
                        yAxisId="counts"
                        type="monotone"
                        dataKey="bookings"
                        stroke={BLUE_MAIN}
                        strokeWidth={2.4}
                        fill="url(#gradBookingsLux)"
                        activeDot={{ r: 4, strokeWidth: 2, fill: '#ffffff' }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Task 3-a — donut « Répartition par logement » (90 derniers jours) */}
            <PropertyDonut data={data?.propertyBreakdown ?? []} loading={loading || propertiesLoading} />

            {/* Flux d'activité unifié (conservé — pleine largeur sous le graphique et le donut) */}
            <div className="flex flex-col rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] xl:col-span-3">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Flux d&apos;activité</h2>
                <span className="inline-flex items-center rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600 ring-1 ring-slate-200">{data?.activity.length ?? 0}</span>
              </div>
              {loading || propertiesLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (data?.activity.length ?? 0) === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl bg-slate-50 p-6 text-center ring-1 ring-slate-100">
                  <p className="text-lg font-bold text-slate-800">Aucune activité</p>
                  <p className="text-xs text-slate-400">Scans, commandes et réservations apparaîtront ici.</p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1">
                  {data?.activity.map((item) => (
                    <li
                      key={item.id}
                      className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-slate-50"
                    >
                      <span
                        className="mt-2 h-2 w-2 shrink-0 rounded-full"
                        style={{ backgroundColor: ACTIVITY_DOT[item.type] ?? '#94a3b8' }}
                        aria-hidden="true"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-slate-800">{item.title}</p>
                        {item.detail && <p className="truncate text-xs text-slate-400">{item.detail}</p>}
                      </div>
                      <div className="shrink-0 text-right">
                        {item.amount != null && (
                          <p className="text-sm font-semibold tabular-nums" style={{ color: '#059669' }}>
                            {formatEur(item.amount)}
                          </p>
                        )}
                        <time
                          dateTime={item.at}
                          className="text-[11px] text-slate-400"
                          title={new Date(item.at).toLocaleString('fr-FR')}
                        >
                          {relativeFrTime(new Date(item.at))}
                        </time>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          {/* ═══════════ Actions rapides (conservées — cartes blanches) ═══════════ */}
          <section aria-label="Actions rapides">
            <h2 className="mb-3 text-[15px] font-bold text-slate-800">Actions rapides</h2>
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              {QUICK_ACTIONS.map((action, i) => (
                <motion.div
                  key={action.href}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.05 * i, duration: 0.25 }}
                >
                  <Link
                    href={action.href}
                    className="group flex h-full items-center gap-3 rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
                  >
                    <span
                      className="h-2 w-2 shrink-0 rounded-full"
                      style={{ backgroundColor: action.dot }}
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1 text-[13px] font-medium leading-tight text-slate-800 sm:text-sm">
                      {action.label}
                    </span>
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5"
                    >
                      →
                    </span>
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>

          {/* ═══════════ Modules actifs (aperçu QR — conservé) ═══════════ */}
          {!loading && data && data.modules.length > 0 && (
            <section aria-label="Modules du bien">
              <h2 className="mb-3 text-[15px] font-bold text-slate-800">
                Modules {data.scope === 'single' && data.property ? `— ${data.property.name}` : '(toutes propriétés)'}
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                {data.modules.map((m, i) => (
                  <motion.div
                    key={m.key}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.04 * i, duration: 0.25 }}
                    className="rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)]"
                  >
                    <p className="text-sm font-semibold text-slate-800">{m.label}</p>
                    <p className="mt-1 line-clamp-2 text-xs text-slate-400">{m.description}</p>
                    <p className="mt-2.5 text-xs font-semibold" style={{ color: '#d97706' }}>
                      {m.qrCount} QR actif{m.qrCount > 1 ? 's' : ''}
                      {m.nearbyProviders != null && m.qrCount > 0 && (
                        <> · {m.nearbyProviders} prestataire{m.nearbyProviders > 1 ? 's' : ''} à proximité</>
                      )}
                    </p>
                  </motion.div>
                ))}
              </div>
            </section>
          )}

          {/* ═══════════ Bande secondaire (scans, note, commandes — données conservées) ═══════════ */}
          <section aria-label="Autres indicateurs" className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {[
              {
                label: 'Scans ce mois',
                value: data?.stats ? data.stats.scansThisMonth.toLocaleString('fr-FR') : '—',
                hint: data?.stats?.lastScanAt ? `Dernier scan ${relativeFrTime(new Date(data.stats.lastScanAt))}` : 'Aucun scan pour l’instant',
              },
              {
                label: 'Note moyenne',
                value: data?.stats?.avgRating != null ? `${data.stats.avgRating.toFixed(1).replace('.', ',')}/5` : '—',
                hint: data?.stats ? `${data.stats.reviewsCount} avis service${data.stats.reviewsCount > 1 ? 's' : ''}` : undefined,
              },
              {
                label: 'Commandes ce mois',
                value: data?.stats ? String(data.stats.ordersThisMonth) : '—',
                hint: 'Commandes invités payées',
              },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between gap-3 rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]">
                <div className="min-w-0">
                  {loading || propertiesLoading ? (
                    <LuxSkeleton className="h-6 w-24" />
                  ) : (
                    <p className="truncate text-2xl font-bold tabular-nums tracking-tight text-slate-800">{s.value}</p>
                  )}
                  <p className="mt-1 text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400">{s.label}</p>
                  {s.hint && !loading && !propertiesLoading && (
                    <p className="mt-0.5 truncate text-[11px] text-slate-400">{s.hint}</p>
                  )}
                </div>
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#2563EB' }} aria-hidden="true" />
              </div>
            ))}
          </section>

          {/* ═══════════ Wizard d'onboarding (post-inscription — conservé) ═══════════ */}
          {onboardingTarget && (
            <OnboardingWizard
              open
              propertyId={onboardingTarget.propertyId}
              initialName={onboardingTarget.name}
              initialAddress={onboardingTarget.address}
              onFinished={finishOnboarding}
            />
          )}
        </div>
    </div>
  );
}

const QUICK_ACTIONS: { href: string; label: string; dot: string }[] = [
  { href: '/airbnb/properties?new=1', label: 'Ajouter une propriété', dot: '#2563EB' },
  { href: '/airbnb/plates?new=1', label: 'Générer une plaque QR', dot: '#14b8a6' },
  { href: '/airbnb/orders', label: 'Voir les commandes', dot: '#10b981' },
  { href: '/airbnb/automations', label: 'Automatisations', dot: '#7C6FF0' },
];

function roleLabel(role: string): string {
  switch (role) {
    case 'OWNER': return 'propriétaire';
    case 'MANAGER': return 'manager';
    case 'CLEANER': return 'ménage';
    case 'MAINTENANCE': return 'maintenance';
    default: return role.toLowerCase();
  }
}
