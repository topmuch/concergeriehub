'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { LogIn, LogOut, ShieldCheck, Timer } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { toast } from 'sonner';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useOverview, type ActivityItem } from '@/hooks/use-overview';
import { OnboardingWizard } from '@/components/airbnb/onboarding-wizard';
import { CoachWidget } from '@/components/airbnb/host/coach-widget';
import { PropertyDonut } from '@/components/airbnb/host/property-donut';
import { relativeFrTime } from '@/lib/automations';
import { cn } from '@/lib/utils';

// =============================================================
// OverviewContent — page « Vue d'ensemble » du Dashboard Hôte
// v6.2 « KPI LISIBLES » (Task 3-a — demande client) :
//
// • Les 6 cartes « joyaux » remplacées par 4 CARTES RECTANGULAIRES
//   claires (.luxkpi) : icône lucide + GROS chiffre + libellé
//   contextuel explicite — JAMAIS un pourcentage nu :
//     1 Check-ins terminés (ratio X/X cette semaine)
//     2 Check-outs terminés (ratio X/X cette semaine)
//     3 Revenus protégés (cautions sécurisées, estimation)
//     4 Temps gagné (EDL digitaux × 45 min, ce mois)
// • NOUVEAU widget « Prochains événements » : 3 prochaines échéances
//   (check-in / check-out / ménage) avec compte à rebours FR + badge
//   litige, cliquables vers le Calendrier.
// • Graphique Activité : légende « Créations de séjours », sous-total
//   ce mois, couleurs harmonisées (#4D8DFF) + tooltip sombre lisible.
// • NOUVEAU donut « Répartition par logement » (PropertyDonut, 90 j).
// • Sections conservées : hero, invitations, programme du jour,
//   activité récente, flux, actions rapides, modules, onboarding.
// =============================================================

// ---------- Couleurs du graphe (thème bleuté / or — Task 3-a) ----------
const BLUE_MAIN = '#4D8DFF';   // créations de séjours (héros)
const BLUE_SOFT = '#8FB3FF';   // scans de plaques (bleu atténué)
const GOLD_ACCENT = '#E9C47C'; // commandes invités (or du thème)

// ---------- Types ----------
interface KpiResponse {
  checkinsDone: number;
  checkinsTotal: number;
  checkoutsDone: number;
  checkoutsTotal: number;
  protectedRevenueEur: number;
  protectedStaysCount: number;
  minutesSaved: number;
  inspectionsThisMonth: number;
  damagesCount: number;
  upcomingEvents: UpcomingEvent[];
}

interface UpcomingEvent {
  id: string;
  kind: 'checkin' | 'checkout' | 'housekeeping';
  title: string;
  propertyName: string;
  at: string;
  bookingId: string | null;
  hasDispute: boolean;
}

interface DayStatsResponse {
  scope: 'single' | 'all';
  property: { id: string; name: string } | null;
  stats: {
    propertiesActive: number;
    propertiesCount: number;
    staysInProgress: number;
    arrivalsToday: number;
    departuresToday: number;
    revenueThisMonth: number;
    ordersThisMonth: number;
    canSeeFinance: boolean;
  };
  today: {
    id: string;
    kind: 'arrival' | 'departure';
    guestName: string;
    propertyName: string;
    at: string;
    status: string;
    source: string;
  }[];
}

interface NotifItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  isRead: boolean;
  createdAt: string;
}

// ---------- Helpers ----------
function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);
}

function greeting(date: Date): string {
  const h = date.getHours();
  if (h < 12) return 'Bonjour';
  if (h < 18) return 'Bon après-midi';
  return 'Bonsoir';
}

function longDateFr(d: Date): string {
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

const fmtHour = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });
const fmtEventDay = new Intl.DateTimeFormat('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });

function sourceLabel(source: string): string {
  if (source === 'ICAL') return 'iCal';
  if (source === 'MANUAL') return 'Manuelle';
  return source.charAt(0) + source.slice(1).toLowerCase();
}

/** Statut de réservation → libellé + pastille colorée (sans badge à icône). */
function statusMeta(status: string): { label: string; dot: string } {
  switch (status) {
    case 'CONFIRMED':
      return { label: 'Confirmée', dot: '#34d399' };
    case 'PENDING':
      return { label: 'En attente', dot: '#fbbf24' };
    case 'COMPLETED':
      return { label: 'Terminée', dot: '#8fa0c2' };
    default:
      return { label: status.toLowerCase(), dot: '#8fa0c2' };
  }
}

/** Point coloré par type d'événement du flux d'activité. */
const ACTIVITY_DOT: Record<ActivityItem['type'], string> = {
  scan: '#5c8af0',
  order: '#34d399',
  booking: '#a78bfa',
  message: '#fbbf24',
};

/** Task 3-a — libellé et teinte du badge de type (prochains événements). */
const EVENT_KIND_LABEL: Record<UpcomingEvent['kind'], string> = {
  checkin: 'Check-in',
  checkout: 'Check-out',
  housekeeping: 'Ménage',
};
const EVENT_TONE: Record<UpcomingEvent['kind'], string> = {
  checkin: '#a9c4ff',
  checkout: '#86e9cb',
  housekeeping: '#e9c47c',
};

/** Task 3-a — minutes → « 4 h 30 » / « 3 h » / « 45 min » (fr-FR). */
function formatHoursMinutes(minutes: number): string {
  if (minutes <= 0) return '0 min';
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m} min`;
  if (m === 0) return `${h} h`;
  return `${h} h ${String(m).padStart(2, '0')}`;
}

function isSameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** Task 3-a — échéance lisible : « dans 2 h », « demain à 11:00 », « sam. 19 oct. ». */
function eventWhenLabel(target: Date, now: Date): string {
  const diffMin = Math.round((target.getTime() - now.getTime()) / 60_000);
  if (diffMin <= 0) return 'maintenant';
  if (diffMin < 60) return `dans ${diffMin} min`;
  if (isSameDay(target, now)) return `dans ${Math.floor(diffMin / 60)} h`;
  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  if (isSameDay(target, tomorrow)) return `demain à ${fmtHour.format(target)}`;
  return fmtEventDay.format(target);
}

function LuxSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-white/8', className)} />;
}

// ---------- Carte KPI rectangulaire (Task 3-a) : icône + gros chiffre + libellé ----------
function KpiCard({
  icon: Icon,
  value,
  label,
  hint,
  chip,
  loading,
  index = 0,
}: {
  icon: LucideIcon;
  value: string;
  label: string;
  hint?: string;
  chip?: string;
  loading?: boolean;
  index?: number;
}) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.35, ease: 'easeOut' }}
      className="luxkpi"
      aria-label={loading ? `${label} (chargement)` : `${label} : ${value}`}
    >
      {/* Icône lucide dans une pastille discrète (lisible clair + sombre via .lux) */}
      <div className="relative flex items-center justify-between gap-2">
        <span
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/6 text-[#a9c4ff]"
          aria-hidden="true"
        >
          <Icon className="h-[18px] w-[18px]" />
        </span>
        {chip && !loading && <span className="luxkpi-chip">{chip}</span>}
      </div>
      {loading ? (
        <div className="mt-3 h-9 w-24 animate-pulse rounded-lg bg-white/10" aria-hidden="true" />
      ) : (
        <p className="luxkpi-value mt-3 truncate text-[28px] leading-none sm:text-[32px]">{value}</p>
      )}
      <span className="luxkpi-label mt-2 block">{label}</span>
      {hint && !loading && (
        <p className="relative mt-1.5 line-clamp-2 text-[12px] leading-snug text-[#8fa0c2]">{hint}</p>
      )}
    </motion.article>
  );
}

// =============================================================
export function OverviewContent() {
  const { userFirstName, invitations, properties, propertiesLoading, selectedId, onboardingCompleted, refreshProperties } =
    useHostContext();
  const { data, loading, error, refetch } = useOverview();
  const now = new Date();

  // ----- Les 4 KPI lisibles (Task 3-a) : /api/airbnb/dashboard-kpis -----
  const [kpi, setKpi] = useState<KpiResponse | null>(null);
  const [kpiLoading, setKpiLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);

  // ----- KPIs « journée » : /api/airbnb/dashboard-stats (real data) -----
  const [day, setDay] = useState<DayStatsResponse | null>(null);
  const [dayLoading, setDayLoading] = useState(true);

  // Horloge pour les comptes à rebours (mise à jour chaque minute,
  // après montage uniquement — anti-hydratation).
  const [tick, setTick] = useState<Date | null>(null);
  useEffect(() => {
    setTick(new Date());
    const id = setInterval(() => setTick(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (propertiesLoading) return;
    let cancelled = false;
    setKpiLoading(true);
    setDayLoading(true);
    (async () => {
      try {
        const qs = `?propertyId=${encodeURIComponent(selectedId)}`;
        const [resKpi, resDay] = await Promise.all([
          fetch(`/api/airbnb/dashboard-kpis${qs}`, { cache: 'no-store' }),
          fetch(`/api/airbnb/dashboard-stats${qs}`, { cache: 'no-store' }),
        ]);
        if (resKpi.ok) setKpi((await resKpi.json()) as KpiResponse);
        else setKpi(null);
        if (resDay.ok) setDay((await resDay.json()) as DayStatsResponse);
        else setDay(null);
      } catch {
        if (!cancelled) {
          setKpi(null);
          setDay(null);
        }
      } finally {
        if (!cancelled) {
          setKpiLoading(false);
          setDayLoading(false);
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedId, propertiesLoading, reloadKey]);

  // ----- Dernières notifications de l'utilisateur (section « Activité récente ») -----
  const [notifs, setNotifs] = useState<NotifItem[]>([]);
  const [notifsLoading, setNotifsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/airbnb/notifications?limit=8', { cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as { notifications: NotifItem[] };
        if (!cancelled) setNotifs(json.notifications ?? []);
      } catch {
        if (!cancelled) setNotifs([]);
      } finally {
        if (!cancelled) setNotifsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  // ----- Chantier ONBOARDING : assistant post-inscription (conservé) -----
  const [onboardingClosed, setOnboardingClosed] = useState(false);
  const onboardingTarget = useMemo(() => {
    if (propertiesLoading || onboardingClosed || onboardingCompleted) return null;
    if (typeof window !== 'undefined' && sessionStorage.getItem('ch-onboarding-dismissed') === '1') {
      return null;
    }
    const owned = properties.find((p) => p.isOwner);
    if (!owned) return null;
    return { propertyId: owned.id, name: owned.name, address: owned.address ?? '' };
  }, [properties, propertiesLoading, onboardingCompleted, onboardingClosed]);

  function finishOnboarding(completed: boolean) {
    setOnboardingClosed(true);
    if (completed) {
      toast.success('Votre logement est configuré');
      void refreshProperties();
      void refetch();
    }
  }

  function refreshAll() {
    void refetch();
    setReloadKey((k) => k + 1);
    toast.success('Données actualisées');
  }

  const kpiPending = kpiLoading || propertiesLoading;
  const today = day?.today ?? [];

  return (
    <div className="lux -m-4 min-h-full p-4 pb-10 sm:-m-6 sm:p-6">
      <div className="lux-bg -m-4 min-h-full p-4 pb-10 sm:-m-6 sm:p-6">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-7">
          {/* ═══════════ HERO — panneau AURA coloré (v6.0) ═══════════ */}
          <motion.section
            aria-label="Vue d'ensemble"
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="lux-hero p-6 sm:p-8"
          >
            <div className="relative flex flex-wrap items-start justify-between gap-x-6 gap-y-4">
              <div className="min-w-0">
                <p className="lux-eyebrow" suppressHydrationWarning>
                  {longDateFr(now)}
                </p>
                <h1
                  className="lux-display mt-2 text-3xl font-semibold text-white sm:text-[40px]"
                  suppressHydrationWarning
                >
                  {greeting(now)}, {userFirstName}
                </h1>
                <p className="mt-2.5 max-w-xl text-sm text-[#8fa0c2] sm:text-[15px]" suppressHydrationWarning>
                  {data?.scope === 'single' && data.property ? (
                    <>
                      Activité de <span className="font-semibold text-white">{data.property.name}</span> — voici
                      l&apos;état de vos locations aujourd&apos;hui.
                    </>
                  ) : (
                    <>
                      Vue consolidée de vos {properties.length} propriétés — voici l&apos;état de vos locations
                      aujourd&apos;hui.
                    </>
                  )}
                </p>

                {/* Actions du hero — pilules typographiques */}
                <div className="mt-6 flex flex-wrap items-center gap-2.5">
                  <Link href="/airbnb/properties?new=1" className="lux-btn">
                    Nouvelle propriété
                  </Link>
                  <Link href="/airbnb/calendar" className="lux-btn lux-btn-gold">
                    Ajouter un séjour
                  </Link>
                  <Link href="/airbnb/menage" className="lux-btn-ghost">
                    Voir les tâches
                  </Link>
                  <button
                    type="button"
                    onClick={refreshAll}
                    disabled={loading || dayLoading || kpiLoading}
                    className="lux-btn-ghost disabled:opacity-50"
                  >
                    Actualiser
                  </button>
                </div>
              </div>

              {/* Monogramme de la maison (sans icône — typographie seule) */}
              <div className="hidden shrink-0 items-center gap-3 sm:flex" aria-hidden="true">
                <div className="lux-rule w-10" />
                <span className="lux-display text-2xl text-[#e9c47c]">R</span>
              </div>
            </div>
          </motion.section>

          {/* ═══════════ Bannière invitations en attente (conservée) ═══════════ */}
          {invitations.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-wrap items-center gap-3 rounded-2xl border border-[#e9c47c]/30 bg-[#e9c47c]/8 px-4 py-3"
              role="status"
            >
              <span className="lux-dot" style={{ backgroundColor: '#e9c47c' }} aria-hidden="true" />
              <p className="flex-1 text-sm text-[#f3d795]">
                <span className="font-semibold">
                  {invitations.length === 1 ? 'Une invitation en attente' : `${invitations.length} invitations en attente`}
                </span>{' '}
                — {invitations[0].property.name} ({roleLabel(invitations[0].role)})
                {invitations.length > 1 && ' et d’autres…'}
              </p>
              <Link href="/airbnb/team" className="lux-btn lux-btn-gold h-9 px-4 text-xs">
                Gérer mes invitations
              </Link>
            </motion.div>
          )}

          {/* ═══════════ Erreur API (conservée) ═══════════ */}
          {error && (
            <div className="lux-card flex flex-col items-center gap-3 p-6 text-center" role="alert">
              <span className="lux-dot" style={{ backgroundColor: '#f07d6a' }} aria-hidden="true" />
              <p className="text-sm font-semibold text-white">{error}</p>
              <button type="button" onClick={() => void refetch()} className="lux-btn mt-1">
                Réessayer
              </button>
            </div>
          )}

          {/* ═════ LES 4 KPI rectangulaires — icône + gros chiffre + libellé explicite (Task 3-a) ═════ */}
          <section aria-label="Indicateurs clés" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {/* KPI 1 · Check-ins terminés — ratio X/X (JAMAIS un pourcentage nu) */}
            <KpiCard
              index={0}
              icon={LogIn}
              loading={kpiPending}
              value={kpi ? `${kpi.checkinsDone}/${kpi.checkinsTotal}` : '—'}
              label="Check-ins terminés"
              hint={
                kpi && kpi.checkinsTotal > 0
                  ? `${kpi.checkinsTotal} arrivée${kpi.checkinsTotal > 1 ? 's' : ''} prévue${kpi.checkinsTotal > 1 ? 's' : ''} cette semaine`
                  : 'Aucune arrivée prévue cette semaine'
              }
            />

            {/* KPI 2 · Check-outs terminés — même logique de ratio */}
            <KpiCard
              index={1}
              icon={LogOut}
              loading={kpiPending}
              value={kpi ? `${kpi.checkoutsDone}/${kpi.checkoutsTotal}` : '—'}
              label="Check-outs terminés"
              hint={
                kpi && kpi.checkoutsTotal > 0
                  ? `${kpi.checkoutsTotal} départ${kpi.checkoutsTotal > 1 ? 's' : ''} prévu${kpi.checkoutsTotal > 1 ? 's' : ''} cette semaine`
                  : 'Aucun départ prévu cette semaine'
              }
            />

            {/* KPI 3 · Revenus protégés — cautions des séjours terminés sans dégât */}
            <KpiCard
              index={2}
              icon={ShieldCheck}
              loading={kpiPending}
              value={kpi ? formatEur(kpi.protectedRevenueEur) : '—'}
              label="Revenus protégés"
              chip={
                kpi && kpi.damagesCount > 0
                  ? `${kpi.damagesCount} dégât${kpi.damagesCount > 1 ? 's' : ''} à traiter`
                  : undefined
              }
              hint={
                kpi && kpi.protectedStaysCount > 0
                  ? `${kpi.protectedStaysCount} séjour${kpi.protectedStaysCount > 1 ? 's' : ''} sans dégât — cautions sécurisées (estimation)`
                  : 'Cautions sécurisées (estimation)'
              }
            />

            {/* KPI 4 · Temps gagné — EDL digitaux du mois × 45 min */}
            <KpiCard
              index={3}
              icon={Timer}
              loading={kpiPending}
              value={kpi ? formatHoursMinutes(kpi.minutesSaved) : '—'}
              label="Temps gagné"
              hint={
                kpi && kpi.inspectionsThisMonth > 0
                  ? `${kpi.inspectionsThisMonth} EDL ce mois — économisées grâce aux EDL digitaux`
                  : 'Économisées ce mois-ci grâce aux EDL digitaux'
              }
            />
          </section>

          {/* ═════ PROCHAINS ÉVÉNEMENTS — 3 échéances + compte à rebours FR (Task 3-a) ═════ */}
          <section aria-label="Prochains événements" className="lux-card p-5 sm:p-6">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="lux-eyebrow">À venir</h2>
                <p className="lux-display mt-1 text-xl text-white">Prochains événements</p>
                <p className="mt-0.5 text-xs text-[#8fa0c2]">Check-ins, check-outs et ménages planifiés</p>
              </div>
              <Link href="/airbnb/calendar" className="lux-chip transition-colors hover:text-white">
                Calendrier <span aria-hidden="true">→</span>
              </Link>
            </div>

            {kpiPending ? (
              <div className="flex flex-col gap-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <LuxSkeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : (kpi?.upcomingEvents.length ?? 0) === 0 ? (
              <div className="lux-empty flex flex-col items-center justify-center gap-2 rounded-2xl p-6 text-center">
                <p className="lux-display text-base text-white">Rien de prévu</p>
                <p className="max-w-sm text-xs text-[#8fa0c2]">
                  Aucun check-in, check-out ni ménage à venir sur ce périmètre.
                </p>
              </div>
            ) : (
              <ul className="flex flex-col gap-2">
                {kpi?.upcomingEvents.map((ev, i) => (
                  <motion.li
                    key={ev.id}
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.04 * i, duration: 0.25 }}
                  >
                    <Link
                      href="/airbnb/calendar"
                      className="group flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-3.5 py-2.5 transition-colors hover:bg-white/[0.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60"
                    >
                      <span
                        className="lux-eyebrow w-[72px] shrink-0 text-center !text-[10px] !leading-tight"
                        style={{ color: EVENT_TONE[ev.kind] }}
                      >
                        {EVENT_KIND_LABEL[ev.kind]}
                      </span>
                      <span className="h-8 w-px shrink-0 bg-white/10" aria-hidden="true" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold text-white">
                          {ev.title}
                          {ev.hasDispute && (
                            <span className="ml-2 inline-flex items-center rounded-full bg-[#f07d6a]/15 px-2 py-0.5 align-middle text-[10px] font-bold uppercase tracking-wide text-[#f07d6a]">
                              Litige
                            </span>
                          )}
                        </p>
                        <p className="truncate text-xs text-[#8fa0c2]">{ev.propertyName}</p>
                      </div>
                      <span
                        className="shrink-0 text-right text-[12px] font-semibold tabular-nums text-[#a9c4ff]"
                        suppressHydrationWarning
                      >
                        {tick ? eventWhenLabel(new Date(ev.at), tick) : '—'}
                      </span>
                      <span
                        aria-hidden="true"
                        className="shrink-0 text-[#8fa0c2] transition-transform group-hover:translate-x-0.5"
                      >
                        →
                      </span>
                    </Link>
                  </motion.li>
                ))}
              </ul>
            )}
          </section>

          {/* ═══════════ COACH ROOMSCAN — recommandations IA du jour (v5.4) ═══════════ */}
          <CoachWidget refreshKey={reloadKey} />

          {/* ═══════════ Arrivées & Départs du jour + Activité récente ═══════════ */}
          <section aria-label="Journée et notifications" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            {/* ----- Arrivées & Départs du jour (real data) ----- */}
            <div className="lux-card flex flex-col p-5 sm:p-6 xl:col-span-2">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="lux-eyebrow">Programme du jour</h2>
                  <p className="lux-display mt-1 text-xl text-white" suppressHydrationWarning>
                    Arrivées &amp; départs
                  </p>
                </div>
                <Link href="/airbnb/calendar" className="lux-chip transition-colors hover:text-white">
                  Calendrier <span aria-hidden="true">→</span>
                </Link>
              </div>

              {kpiLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : today.length === 0 ? (
                <div className="lux-empty flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl p-8 text-center">
                  <p className="lux-display text-lg text-white">Journée tranquille</p>
                  <p className="max-w-xs text-xs text-[#8fa0c2]">
                    Ni arrivée ni départ aujourd&apos;hui. Les réservations du calendrier apparaîtront ici.
                  </p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[320px] flex-col gap-2 overflow-y-auto pr-1">
                  {today.map((item, i) => {
                    const st = statusMeta(item.status);
                    const isArrival = item.kind === 'arrival';
                    return (
                      <motion.li
                        key={item.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.04 * i, duration: 0.25 }}
                        className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-3.5 py-2.5"
                      >
                        <span className="lux-eyebrow w-10 shrink-0 text-center !text-[13px] !tracking-normal" style={{ color: isArrival ? '#a9c4ff' : '#86e9cb' }}>
                          {fmtHour.format(new Date(item.at))}
                        </span>
                        <span className="h-8 w-px shrink-0 bg-white/10" aria-hidden="true" />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-white">{item.guestName}</p>
                          <p className="truncate text-xs text-[#8fa0c2]">
                            {item.propertyName} · {isArrival ? 'Arrivée' : 'Départ'} · {sourceLabel(item.source)}
                          </p>
                        </div>
                        <span className="lux-chip hidden shrink-0 sm:inline-flex">
                          <span className="lux-dot" style={{ backgroundColor: st.dot }} aria-hidden="true" />
                          {st.label}
                        </span>
                      </motion.li>
                    );
                  })}
                </ul>
              )}
            </div>

            {/* ----- Activité récente : dernières notifications ----- */}
            <div className="lux-card flex flex-col p-5">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="lux-eyebrow">Activité récente</h2>
                <span className="lux-chip">{notifsLoading ? '…' : notifs.length}</span>
              </div>
              {notifsLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : notifs.length === 0 ? (
                <div className="lux-empty flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl p-6 text-center">
                  <p className="lux-display text-lg text-white">Rien pour l&apos;instant</p>
                  <p className="text-xs text-[#8fa0c2]">Réservations, ménages et réclamations arriveront ici.</p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[320px] flex-col gap-1 overflow-y-auto pr-1">
                  {notifs.map((n) => (
                    <li
                      key={n.id}
                      className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-white/[0.04]"
                    >
                      <span
                        className="lux-dot mt-1.5 shrink-0"
                        style={{ backgroundColor: n.isRead ? 'rgba(143,160,194,0.4)' : '#5c8af0' }}
                        aria-hidden="true"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-white">{n.title}</p>
                        {n.body && <p className="line-clamp-2 text-xs text-[#8fa0c2]">{n.body}</p>}
                      </div>
                      <time
                        dateTime={n.createdAt}
                        className="shrink-0 text-[11px] text-[#8fa0c2]"
                        title={new Date(n.createdAt).toLocaleString('fr-FR')}
                      >
                        {relativeFrTime(new Date(n.createdAt))}
                      </time>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          {/* ═════ Graphique Activité + donut Répartition + Flux d'activité (Task 3-a) ═════ */}
          <section aria-label="Activité et historique" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
            {/* Graphique 30 jours — créations de séjours + scans + commandes */}
            <div className="lux-card p-5 xl:col-span-2">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="lux-eyebrow">Tendance</h2>
                  <p className="lux-display mt-1 text-xl text-white">Activité des 30 derniers jours</p>
                  {/* Task 3-a — légende explicite sous le titre */}
                  <p className="mt-0.5 text-xs text-[#8fa0c2]">Créations de séjours par jour — 30 derniers jours</p>
                </div>
                {/* Task 3-a — sous-total clair (données réelles) */}
                {loading || propertiesLoading ? (
                  <LuxSkeleton className="h-6 w-32" />
                ) : (
                  <span className="lux-chip">
                    {data?.stats
                      ? `${data.stats.bookingsThisMonth} séjour${data.stats.bookingsThisMonth > 1 ? 's' : ''} créé${data.stats.bookingsThisMonth > 1 ? 's' : ''} ce mois`
                      : '— séjours créés ce mois'}
                  </span>
                )}
              </div>
              {loading || propertiesLoading ? (
                <LuxSkeleton className="h-[280px] w-full" />
              ) : (
                <div
                  className="h-[280px] w-full"
                  role="img"
                  aria-label="Courbe d'activité des 30 derniers jours : créations de séjours, scans et commandes par jour"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data?.series ?? []} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                      <defs>
                        <linearGradient id="gradBookingsLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={BLUE_MAIN} stopOpacity={0.4} />
                          <stop offset="100%" stopColor={BLUE_MAIN} stopOpacity={0.02} />
                        </linearGradient>
                        <linearGradient id="gradScansLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={BLUE_SOFT} stopOpacity={0.26} />
                          <stop offset="100%" stopColor={BLUE_SOFT} stopOpacity={0.02} />
                        </linearGradient>
                        <linearGradient id="gradOrdersLux" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor={GOLD_ACCENT} stopOpacity={0.26} />
                          <stop offset="100%" stopColor={GOLD_ACCENT} stopOpacity={0.02} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 6" stroke="rgba(148,170,214,0.14)" vertical={false} />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 11, fill: '#8fa0c2' }}
                        tickLine={false}
                        axisLine={{ stroke: 'rgba(148,170,214,0.18)' }}
                        interval="preserveStartEnd"
                        minTickGap={24}
                      />
                      <YAxis
                        yAxisId="counts"
                        tick={{ fontSize: 11, fill: '#8fa0c2' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <YAxis
                        yAxisId="orders"
                        orientation="right"
                        tick={{ fontSize: 11, fill: '#8fa0c2' }}
                        tickLine={false}
                        axisLine={false}
                        allowDecimals={false}
                      />
                      <Tooltip
                        contentStyle={{
                          borderRadius: 12,
                          border: '1px solid rgba(148,170,214,0.25)',
                          backgroundColor: '#0d1530',
                          color: '#eef3fb',
                          boxShadow: '0 12px 32px rgba(2,6,18,0.6)',
                          fontSize: 13,
                        }}
                        labelStyle={{ color: '#8fa3c8', fontWeight: 600 }}
                        itemStyle={{ color: '#eef3fb' }}
                        cursor={{ stroke: 'rgba(148,170,214,0.3)' }}
                        formatter={(value: number | string, name: string) => [
                          String(value),
                          name === 'bookings'
                            ? 'Créations de séjours'
                            : name === 'scans'
                              ? 'Scans de plaques'
                              : 'Commandes invités',
                        ]}
                      />
                      <Legend
                        formatter={(value: string) => (
                          <span className="text-xs font-medium text-[#8fa0c2]">
                            {value === 'bookings'
                              ? 'Créations de séjours'
                              : value === 'scans'
                                ? 'Scans de plaques'
                                : 'Commandes invités'}
                          </span>
                        )}
                      />
                      <Area
                        yAxisId="counts"
                        type="monotone"
                        dataKey="scans"
                        stroke={BLUE_SOFT}
                        strokeWidth={1.5}
                        fill="url(#gradScansLux)"
                        activeDot={{ r: 3, strokeWidth: 2, fill: '#0d1530' }}
                      />
                      <Area
                        yAxisId="orders"
                        type="monotone"
                        dataKey="orders"
                        stroke={GOLD_ACCENT}
                        strokeWidth={1.5}
                        fill="url(#gradOrdersLux)"
                        activeDot={{ r: 3, strokeWidth: 2, fill: '#0d1530' }}
                      />
                      {/* Task 3-a — série héros : créations de séjours (#4D8DFF) */}
                      <Area
                        yAxisId="counts"
                        type="monotone"
                        dataKey="bookings"
                        stroke={BLUE_MAIN}
                        strokeWidth={2.4}
                        fill="url(#gradBookingsLux)"
                        activeDot={{ r: 4, strokeWidth: 2, fill: '#0d1530' }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Task 3-a — donut « Répartition par logement » (90 derniers jours) */}
            <PropertyDonut data={data?.propertyBreakdown ?? []} loading={loading || propertiesLoading} />

            {/* Flux d'activité unifié (conservé — pleine largeur sous le graphique et le donut) */}
            <div className="lux-card flex flex-col p-5 xl:col-span-3">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="lux-eyebrow">Flux d&apos;activité</h2>
                <span className="lux-chip">{data?.activity.length ?? 0}</span>
              </div>
              {loading || propertiesLoading ? (
                <div className="flex flex-col gap-3">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <LuxSkeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : (data?.activity.length ?? 0) === 0 ? (
                <div className="lux-empty flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl p-6 text-center">
                  <p className="lux-display text-lg text-white">Aucune activité</p>
                  <p className="text-xs text-[#8fa0c2]">Scans, commandes et réservations apparaîtront ici.</p>
                </div>
              ) : (
                <ul className="lux-scroll flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1">
                  {data?.activity.map((item) => (
                    <li
                      key={item.id}
                      className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-white/[0.04]"
                    >
                      <span
                        className="lux-dot mt-2 shrink-0"
                        style={{ backgroundColor: ACTIVITY_DOT[item.type] ?? '#8fa0c2' }}
                        aria-hidden="true"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-white">{item.title}</p>
                        {item.detail && <p className="truncate text-xs text-[#8fa0c2]">{item.detail}</p>}
                      </div>
                      <div className="shrink-0 text-right">
                        {item.amount != null && (
                          <p className="lux-num text-sm font-semibold" style={{ color: '#86e9cb' }}>
                            {formatEur(item.amount)}
                          </p>
                        )}
                        <time
                          dateTime={item.at}
                          className="text-[11px] text-[#8fa0c2]"
                          title={new Date(item.at).toLocaleString('fr-FR')}
                        >
                          {relativeFrTime(new Date(item.at))}
                        </time>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>

          {/* ═══════════ Actions rapides (conservées — pilules typographiques) ═══════════ */}
          <section aria-label="Actions rapides">
            <h2 className="lux-eyebrow mb-3">Actions rapides</h2>
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              {QUICK_ACTIONS.map((action, i) => (
                <motion.div
                  key={action.href}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.05 * i, duration: 0.25 }}
                >
                  <Link
                    href={action.href}
                    className="lux-card lux-card-hover group flex h-full items-center gap-3 p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/60"
                  >
                    <span
                      className="lux-dot shrink-0"
                      style={{ backgroundColor: action.dot }}
                      aria-hidden="true"
                    />
                    <span className="min-w-0 flex-1 text-[13px] font-medium leading-tight text-white sm:text-sm">
                      {action.label}
                    </span>
                    <span
                      aria-hidden="true"
                      className="shrink-0 text-[#8fa0c2] transition-transform group-hover:translate-x-0.5"
                    >
                      →
                    </span>
                  </Link>
                </motion.div>
              ))}
            </div>
          </section>

          {/* ═══════════ Modules actifs (aperçu QR — conservé) ═══════════ */}
          {!loading && data && data.modules.length > 0 && (
            <section aria-label="Modules du bien">
              <h2 className="lux-eyebrow mb-3">
                Modules {data.scope === 'single' && data.property ? `— ${data.property.name}` : '(toutes propriétés)'}
              </h2>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                {data.modules.map((m, i) => (
                  <motion.div
                    key={m.key}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.04 * i, duration: 0.25 }}
                    className="lux-card lux-card-hover p-4"
                  >
                    <p className="text-sm font-semibold text-white">{m.label}</p>
                    <p className="mt-1 line-clamp-2 text-xs text-[#8fa0c2]">{m.description}</p>
                    <p className="mt-2.5 text-xs font-semibold" style={{ color: '#e9c47c' }}>
                      {m.qrCount} QR actif{m.qrCount > 1 ? 's' : ''}
                      {m.nearbyProviders != null && m.qrCount > 0 && (
                        <> · {m.nearbyProviders} prestataire{m.nearbyProviders > 1 ? 's' : ''} à proximité</>
                      )}
                    </p>
                  </motion.div>
                ))}
              </div>
            </section>
          )}

          {/* ═══════════ Bande secondaire (scans, note, commandes — données conservées) ═══════════ */}
          <section aria-label="Autres indicateurs" className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {[
              {
                label: 'Scans ce mois',
                value: data?.stats ? data.stats.scansThisMonth.toLocaleString('fr-FR') : '—',
                hint: data?.stats?.lastScanAt ? `Dernier scan ${relativeFrTime(new Date(data.stats.lastScanAt))}` : 'Aucun scan pour l’instant',
              },
              {
                label: 'Note moyenne',
                value: data?.stats?.avgRating != null ? `${data.stats.avgRating.toFixed(1).replace('.', ',')}/5` : '—',
                hint: data?.stats ? `${data.stats.reviewsCount} avis service${data.stats.reviewsCount > 1 ? 's' : ''}` : undefined,
              },
              {
                label: 'Commandes ce mois',
                value: data?.stats ? String(data.stats.ordersThisMonth) : '—',
                hint: 'Commandes invités payées',
              },
            ].map((s) => (
              <div key={s.label} className="lux-card flex items-center justify-between gap-3 p-4">
                <div className="min-w-0">
                  {loading || propertiesLoading ? (
                    <LuxSkeleton className="h-6 w-24" />
                  ) : (
                    <p className="lux-num truncate text-2xl text-white">{s.value}</p>
                  )}
                  <p className="lux-eyebrow mt-1">{s.label}</p>
                  {s.hint && !loading && !propertiesLoading && (
                    <p className="mt-0.5 truncate text-[11px] text-[#8fa0c2]">{s.hint}</p>
                  )}
                </div>
                <span className="lux-dot" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
              </div>
            ))}
          </section>

          {/* ═══════════ Wizard d'onboarding (post-inscription — conservé) ═══════════ */}
          {onboardingTarget && (
            <OnboardingWizard
              open
              propertyId={onboardingTarget.propertyId}
              initialName={onboardingTarget.name}
              initialAddress={onboardingTarget.address}
              onFinished={finishOnboarding}
            />
          )}
        </div>
      </div>
    </div>
  );
}

const QUICK_ACTIONS: { href: string; label: string; dot: string }[] = [
  { href: '/airbnb/properties?new=1', label: 'Ajouter une propriété', dot: '#5c8af0' },
  { href: '/airbnb/plates?new=1', label: 'Générer une plaque QR', dot: '#2dd4bf' },
  { href: '/airbnb/orders', label: 'Voir les commandes', dot: '#86e9cb' },
  { href: '/airbnb/automations', label: 'Automatisations', dot: '#cdb6ff' },
];

function roleLabel(role: string): string {
  switch (role) {
    case 'OWNER': return 'propriétaire';
    case 'MANAGER': return 'manager';
    case 'CLEANER': return 'ménage';
    case 'MAINTENANCE': return 'maintenance';
    default: return role.toLowerCase();
  }
}
