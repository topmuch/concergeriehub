'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { CalendarPlus, ChevronRight, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { KPICard, type KPITone } from '@/components/airbnb/host/kpi-card';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useOverview, type ActivityItem } from '@/hooks/use-overview';
import { OnboardingWizard } from '@/components/airbnb/onboarding-wizard';
import { relativeFrTime } from '@/lib/automations';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

// =============================================================
// OverviewContent — page « Vue d'ensemble » du Dashboard Hôte
// v4.59 « AIRBNB PRO » — refonte visuelle (logique intacte)
//
// • HERO gradient Airbnb : salutation, date, chips glass (scans,
//   revenus, biens actifs), CTA blanc + Actualiser glass
// • 4 KPIs colorés (tons variés rausch/emerald/amber/violet)
// • Graphique recharts : courbe d'activité 30 jours (scans + commandes)
// • Activité récente : flux unifié (scans, commandes, réservations,
//   messages invités) — données réelles
// • Actions rapides : pilules avec bulles dégradées
// • Modules du bien : tuiles vivantes à bulle tonée
// • Bannière d'invitations d'équipe en attente
// =============================================================

const BRAND = '#FF385C'; // Rausch Airbnb
const BABU = '#00A699'; // Teal Airbnb

/** Emoji du flux d'activité, par type d'événement. */
const ACTIVITY_EMOJI: Record<ActivityItem['type'], string> = {
  scan: '📱',
  order: '💰',
  booking: '📅',
  message: '🎙️',
};

const QUICK_ACTIONS = [
  { href: '/airbnb/properties?new=1', emoji: '🏠', label: 'Ajouter une propriété', tone: 'rausch' },
  { href: '/airbnb/plates?new=1', emoji: '📱', label: 'Générer une plaque QR', tone: 'teal' },
  { href: '/airbnb/orders', emoji: '💰', label: 'Voir les commandes', tone: 'emerald' },
  { href: '/airbnb/automations', emoji: '⚡', label: 'Automatisations', tone: 'violet' },
] as const;

/** Tonalité des bulles des modules du bien (clé → tone). */
const MODULE_TONES: Record<string, KPITone> = {
  WIFI: 'teal',
  GUIDEBOOK: 'amber',
  UPSELLING: 'emerald',
  COMPLAINT: 'rausch',
  PROVIDER_DIRECTORY: 'violet',
};

function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);
}

function greeting(date: Date): string {
  const h = date.getHours();
  if (h < 12) return 'Bonjour';
  if (h < 18) return 'Bon après-midi';
  return 'Bonsoir';
}

export function OverviewContent() {
  const { userFirstName, invitations, properties, propertiesLoading, onboardingCompleted, refreshProperties } = useHostContext();
  const { data, loading, error, refetch } = useOverview();
  const stats = data?.stats ?? null;
  const now = new Date();

  // ----- Chantier ONBOARD : assistant post-inscription (bien possédé
  //  non configuré) — reprend le mécanisme de l'ancien dashboard,
  //  rejetable via sessionStorage ("Plus tard"). Cible dérivée au
  //  rendu (pas d'effet). -----
  const [onboardingClosed, setOnboardingClosed] = useState(false);
  const onboardingTarget = useMemo(() => {
    if (propertiesLoading || onboardingClosed || onboardingCompleted) return null;
    if (typeof window !== 'undefined' && sessionStorage.getItem('ch-onboarding-dismissed') === '1') {
      return null;
    }
    const owned = properties.find((p) => p.isOwner);
    if (!owned) return null;
    return { propertyId: owned.id, name: owned.name, address: owned.address ?? '' };
  }, [properties, propertiesLoading, onboardingCompleted, onboardingClosed]);

  function finishOnboarding(completed: boolean) {
    setOnboardingClosed(true);
    if (completed) {
      toast.success('Votre logement est configuré 🎉');
      void refreshProperties();
      void refetch();
    }
  }

  // ----- Chips glass du hero (chiffres clés du dashboard) -----
  const heroChips: Array<{ emoji: string; text: string }> = [
    {
      emoji: '📱',
      text: stats ? `${stats.scansThisMonth.toLocaleString('fr-FR')} scans ce mois` : 'Scans —',
    },
    {
      emoji: '💰',
      text: stats ? `${formatEur(stats.upsellingRevenue)} de revenus` : 'Revenus —',
    },
    {
      emoji: '🏠',
      text: stats ? `${stats.activeProperties}/${stats.propertiesCount} biens actifs` : 'Biens —',
    },
  ];
  if (stats?.avgRating != null) {
    heroChips.push({
      emoji: '⭐',
      text: `${stats.avgRating.toFixed(1).replace('.', ',')}/5 · ${stats.reviewsCount} avis`,
    });
  }

  return (
    <div className="flex flex-col gap-6">
      {/* ---------- HERO gradient Airbnb ---------- */}
      <motion.section
        aria-label="Vue d'ensemble"
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
        className="air-gradient-deep air-shadow-lg relative overflow-hidden rounded-3xl p-6 text-white sm:p-8"
      >
        {/* Bulles décoratives flottantes */}
        <span
          aria-hidden="true"
          className="air-float pointer-events-none absolute -right-10 -top-14 h-48 w-48 rounded-full bg-white/10"
        />
        <span
          aria-hidden="true"
          className="air-float pointer-events-none absolute -bottom-20 right-32 h-40 w-40 rounded-full bg-white/5"
          style={{ animationDelay: '1.6s' }}
        />

        <div className="relative flex flex-wrap items-start justify-between gap-x-6 gap-y-4">
          <div className="min-w-0">
            {/* suppressHydrationWarning : la salutation/date dépend de l'horloge locale,
                volontairement rendue à la volée (identique à l'instant T côté serveur et client). */}
            <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-white/70" suppressHydrationWarning>
              {longDateFr(now)}
            </p>
            <h1 className="mt-1.5 text-2xl font-extrabold tracking-tight sm:text-4xl" suppressHydrationWarning>
              {greeting(now)}, {userFirstName} 👋
            </h1>
            <p className="mt-2 max-w-xl text-sm text-white/80 sm:text-[15px]" suppressHydrationWarning>
              {data?.scope === 'single' && data.property ? (
                <>
                  Activité de <span className="font-bold text-white">{data.property.name}</span> — voici l&apos;état de
                  vos locations aujourd&apos;hui.
                </>
              ) : (
                <>Vue consolidée de vos {properties.length} propriétés — voici l&apos;état de vos locations aujourd&apos;hui.</>
              )}
            </p>

            {/* Chips glass : chiffres clés du dashboard */}
            <div className="mt-4 flex flex-wrap items-center gap-2">
              {heroChips.map((chip) => (
                <span
                  key={chip.emoji}
                  className="inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-white ring-1 ring-white/20"
                >
                  <span aria-hidden="true">{chip.emoji}</span>
                  {chip.text}
                </span>
              ))}
            </div>
          </div>

          {/* Actions du hero : Actualiser (glass) + CTA principal (blanc) */}
          <div className="flex shrink-0 flex-row items-center gap-2 sm:flex-col sm:items-stretch">
            <button
              type="button"
              onClick={() => {
                void refetch();
                toast.success('Données actualisées');
              }}
              disabled={loading}
              aria-label="Actualiser les données"
              className="inline-flex h-9 items-center justify-center gap-2 rounded-full bg-white/15 px-4 text-xs font-bold text-white ring-1 ring-white/25 backdrop-blur transition-colors hover:bg-white/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 disabled:opacity-60"
            >
              <RefreshCw className={cn('h-3.5 w-3.5', loading && 'animate-spin')} aria-hidden="true" />
              Actualiser
            </button>
            <Link
              href="/airbnb/properties?new=1"
              className="inline-flex h-9 items-center justify-center gap-2 rounded-full bg-white px-4 text-xs font-bold text-[#D70466] shadow transition-transform hover:scale-[1.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70"
            >
              <CalendarPlus className="h-3.5 w-3.5" aria-hidden="true" />
              Ajouter une propriété
            </Link>
          </div>
        </div>
      </motion.section>

      {/* ---------- Bannière invitations en attente ---------- */}
      {invitations.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="air-shadow flex flex-wrap items-center gap-3 rounded-2xl border border-amber-300/70 bg-amber-50 px-4 py-3 dark:border-amber-400/30 dark:bg-amber-400/10"
          role="status"
        >
          <span aria-hidden="true" className="text-xl">✉️</span>
          <p className="flex-1 text-sm text-amber-900 dark:text-amber-200">
            <span className="font-bold">
              {invitations.length === 1 ? 'Une invitation en attente' : `${invitations.length} invitations en attente`}
            </span>{' '}
            — {invitations[0].property.name} ({roleLabel(invitations[0].role)})
            {invitations.length > 1 && ' et d’autres…'}
          </p>
          <Link
            href="/airbnb/team"
            className="inline-flex h-8 items-center rounded-full bg-amber-500 px-3 text-xs font-bold text-white shadow transition-colors hover:bg-amber-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 dark:bg-amber-400 dark:text-amber-950 dark:hover:bg-amber-300"
          >
            Gérer mes invitations
          </Link>
        </motion.div>
      )}

      {/* ---------- Erreur API ---------- */}
      {error && (
        <div className="air-empty flex flex-col items-center gap-3 rounded-2xl p-6 text-center" role="alert">
          <span className="air-float text-3xl" aria-hidden="true">⚠️</span>
          <p className="text-sm font-semibold text-foreground">{error}</p>
          <button
            type="button"
            onClick={() => {
              void refetch();
            }}
            className="air-gradient inline-flex h-9 items-center gap-2 rounded-full px-4 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E61E4D]/50"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            Réessayer
          </button>
        </div>
      )}

      {/* ---------- KPIs ---------- */}
      <section aria-label="Indicateurs clés" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KPICard
          emoji="📱"
          tone="rausch"
          label="Scans ce mois"
          value={stats ? stats.scansThisMonth.toLocaleString('fr-FR') : '—'}
          chip={
            stats?.scansDelta != null
              ? {
                  text: `${stats.scansDelta >= 0 ? '▲' : '▼'} ${Math.abs(stats.scansDelta)}%`,
                  tone: stats.scansDelta >= 0 ? 'positive' : 'negative',
                }
              : undefined
          }
          hint={stats?.lastScanAt ? `Dernier scan ${relativeFrTime(new Date(stats.lastScanAt))}` : 'Aucun scan pour l’instant'}
          loading={loading || propertiesLoading}
        />
        <KPICard
          emoji="💰"
          tone="emerald"
          label="Revenus Upselling"
          value={stats ? formatEur(stats.upsellingRevenue) : '—'}
          chip={
            stats?.ordersDelta != null
              ? {
                  text: `${stats.ordersDelta >= 0 ? '▲' : '▼'} ${Math.abs(stats.ordersDelta)}%`,
                  tone: stats.ordersDelta >= 0 ? 'positive' : 'negative',
                }
              : undefined
          }
          hint={stats ? `${stats.ordersThisMonth} commande${stats.ordersThisMonth > 1 ? 's' : ''} payée${stats.ordersThisMonth > 1 ? 's' : ''} ce mois` : undefined}
          loading={loading || propertiesLoading}
        />
        <KPICard
          emoji="⭐"
          tone="amber"
          label="Note moyenne"
          value={stats?.avgRating != null ? `${stats.avgRating.toFixed(1).replace('.', ',')}/5` : '—'}
          hint={stats ? `${stats.reviewsCount} avis service${stats.reviewsCount > 1 ? 's' : ''}` : undefined}
          loading={loading || propertiesLoading}
        />
        <KPICard
          emoji="🏠"
          tone="violet"
          label="Propriétés actives"
          value={stats ? `${stats.activeProperties}/${stats.propertiesCount}` : '—'}
          hint={data?.scope === 'single' ? 'Bien sélectionné' : 'Toutes propriétés confondues'}
          loading={loading || propertiesLoading}
        />
      </section>

      {/* ---------- Graphique + Activité ---------- */}
      <section aria-label="Activité et historique" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
        {/* Graphique 30 jours */}
        <div className="air-shadow rounded-2xl border border-border bg-card p-5 xl:col-span-2">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-foreground">📈 Courbe d&apos;activité</h2>
              <p className="text-xs text-muted-foreground">Scans de plaques et commandes — 30 derniers jours</p>
            </div>
          </div>
          {loading || propertiesLoading ? (
            <Skeleton className="h-[280px] w-full rounded-2xl" aria-hidden="true" />
          ) : (
            <div className="h-[280px] w-full" role="img" aria-label="Courbe d'activité des 30 derniers jours : scans et commandes par jour">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data?.series ?? []} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                  <defs>
                    <linearGradient id="gradScans" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={BRAND} stopOpacity={0.28} />
                      <stop offset="100%" stopColor={BRAND} stopOpacity={0.02} />
                    </linearGradient>
                    <linearGradient id="gradOrders" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={BABU} stopOpacity={0.24} />
                      <stop offset="100%" stopColor={BABU} stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    tickLine={false}
                    axisLine={{ stroke: 'var(--border)' }}
                    interval="preserveStartEnd"
                    minTickGap={24}
                  />
                  <YAxis
                    yAxisId="scans"
                    tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <YAxis
                    yAxisId="orders"
                    orientation="right"
                    tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
                    tickLine={false}
                    axisLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 12,
                      border: '1px solid var(--border)',
                      backgroundColor: 'var(--card)',
                      color: 'var(--card-foreground)',
                      boxShadow: '0 4px 12px rgb(0 0 0 / 0.06)',
                      fontSize: 13,
                    }}
                    formatter={(value: number | string, name: string) => [
                      String(value),
                      name === 'scans' ? 'Scans' : 'Commandes',
                    ]}
                  />
                  <Legend
                    formatter={(value: string) => (
                      <span className="text-xs font-semibold text-muted-foreground">
                        {value === 'scans' ? 'Scans de plaques' : 'Commandes invités'}
                      </span>
                    )}
                  />
                  <Area
                    yAxisId="scans"
                    type="monotone"
                    dataKey="scans"
                    stroke={BRAND}
                    strokeWidth={2.5}
                    fill="url(#gradScans)"
                    activeDot={{ r: 4, strokeWidth: 2 }}
                  />
                  <Area
                    yAxisId="orders"
                    type="monotone"
                    dataKey="orders"
                    stroke={BABU}
                    strokeWidth={2.5}
                    fill="url(#gradOrders)"
                    activeDot={{ r: 4, strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Activité récente */}
        <div className="air-shadow flex flex-col rounded-2xl border border-border bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-base font-bold text-foreground">🕒 Activité récente</h2>
            <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-bold text-muted-foreground">
              {data?.activity.length ?? 0}
            </span>
          </div>
          {loading || propertiesLoading ? (
            <div className="flex flex-col gap-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-12 w-full rounded-2xl" aria-hidden="true" />
              ))}
            </div>
          ) : (data?.activity.length ?? 0) === 0 ? (
            <div className="air-empty flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl p-6 text-center">
              <span className="air-float text-3xl" aria-hidden="true">🌿</span>
              <p className="text-sm font-semibold text-foreground">Aucune activité pour le moment.</p>
              <p className="text-xs text-muted-foreground">Scans, commandes et réservations apparaîtront ici.</p>
            </div>
          ) : (
            <ul className="flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1 [scrollbar-width:thin]">
              {data?.activity.map((item) => (
                <li
                  key={item.id}
                  className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-muted/60"
                >
                  <span
                    aria-hidden="true"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-base"
                  >
                    {ACTIVITY_EMOJI[item.type]}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-foreground">{item.title}</p>
                    {item.detail && (
                      <p className="truncate text-xs text-muted-foreground">{item.detail}</p>
                    )}
                  </div>
                  <div className="shrink-0 text-right">
                    {item.amount != null && (
                      <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{formatEur(item.amount)}</p>
                    )}
                    <time
                      dateTime={item.at}
                      className="text-[11px] text-muted-foreground"
                      title={new Date(item.at).toLocaleString('fr-FR')}
                    >
                      {relativeFrTime(new Date(item.at))}
                    </time>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* ---------- Actions rapides ---------- */}
      <section aria-label="Actions rapides">
        <h2 className="mb-3 text-base font-bold text-foreground">⚡ Actions rapides</h2>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {QUICK_ACTIONS.map((action, i) => (
            <motion.div
              key={action.href}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.05 * i, duration: 0.25 }}
            >
              <Link
                href={action.href}
                className="air-shadow air-hoverlift group flex h-full items-center gap-3 rounded-2xl border border-border bg-card p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E61E4D]/50"
              >
                <span
                  aria-hidden="true"
                  className={cn(
                    'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl text-white shadow',
                    `kpi-bubble-${action.tone}`,
                  )}
                >
                  {action.emoji}
                </span>
                <span className="min-w-0 flex-1 text-[13px] font-bold leading-tight text-foreground sm:text-sm">
                  {action.label}
                </span>
                <ChevronRight
                  aria-hidden="true"
                  className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5"
                />
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ---------- Modules actifs (aperçu QR) ---------- */}
      {!loading && data && data.modules.length > 0 && (
        <section aria-label="Modules du bien">
          <h2 className="mb-3 text-base font-bold text-foreground">
            🧩 Modules {data.scope === 'single' && data.property ? `— ${data.property.name}` : '(toutes propriétés)'}
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {data.modules.map((m, i) => (
              <motion.div
                key={m.key}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.04 * i, duration: 0.25 }}
                className="air-shadow air-hoverlift rounded-2xl border border-border bg-card p-4"
              >
                <span
                  aria-hidden="true"
                  className={cn(
                    'flex h-10 w-10 items-center justify-center rounded-xl text-lg text-white shadow',
                    `kpi-bubble-${MODULE_TONES[m.key] ?? 'rausch'}`,
                  )}
                >
                  {m.emoji}
                </span>
                <p className="mt-2 text-sm font-bold text-foreground">{m.label}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">{m.description}</p>
                <p className="air-gradient-text mt-2 text-xs font-extrabold">
                  {m.qrCount} QR actif{m.qrCount > 1 ? 's' : ''}
                  {m.nearbyProviders != null && m.qrCount > 0 && (
                    <> · {m.nearbyProviders} prestataire{m.nearbyProviders > 1 ? 's' : ''} à proximité</>
                  )}
                </p>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* ---------- Wizard d'onboarding (post-inscription) ---------- */}
      {onboardingTarget && (
        <OnboardingWizard
          open
          propertyId={onboardingTarget.propertyId}
          initialName={onboardingTarget.name}
          initialAddress={onboardingTarget.address}
          onFinished={finishOnboarding}
        />
      )}
    </div>
  );
}

function longDateFr(d: Date): string {
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

function roleLabel(role: string): string {
  switch (role) {
    case 'OWNER': return 'propriétaire';
    case 'MANAGER': return 'manager';
    case 'CLEANER': return 'ménage';
    case 'MAINTENANCE': return 'maintenance';
    default: return role.toLowerCase();
  }
}
