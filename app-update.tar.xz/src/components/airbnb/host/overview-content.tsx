'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  BedDouble,
  CalendarPlus,
  ChevronRight,
  Home,
  ListChecks,
  LogIn,
  LogOut,
  PlaneLanding,
  RefreshCw,
  Wallet,
} from 'lucide-react';
import { toast } from 'sonner';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useOverview, type ActivityItem } from '@/hooks/use-overview';
import { OnboardingWizard } from '@/components/airbnb/onboarding-wizard';
import { relativeFrTime } from '@/lib/automations';
import { cn } from '@/lib/utils';

// =============================================================
// OverviewContent — page « Vue d'ensemble » du Dashboard Hôte
// v5.0 « AIRBNB PRO CLAIR » — redesign en mode clair garanti :
//
// • Wrapper .light (scope CSS indépendant de html.dark) + fond
//   chaud #faf9f7, cartes blanches, accent bleu logo #0066EF
// • HERO clair : « Bonjour {prénom} 👋 », date fr-FR, accroche,
//   3 actions rapides (propriété / séjour / tâches) + Actualiser
// • 4 cartes KPI (real data via /api/airbnb/dashboard-stats) :
//   Propriétés actives, Séjours en cours, Arrivées du jour,
//   Revenus du mois
// • Bande secondaire : scans ce mois, note moyenne, commandes
//   (données conservées de l'ancienne vue — /api/airbnb/dashboard)
// • « Arrivées & Départs du jour » : programme horodaté réel
// • « Activité récente » : dernières notifications de l'utilisateur
// • Courbe 30 jours + flux d'activité unifié (conservés)
// • Actions rapides, modules du bien, bannière invitations,
//   wizard d'onboarding : toutes les fonctionnalités existantes
// =============================================================

const BRAND = '#0066EF'; // Bleu logo RoomScan
const BABU = '#00A699'; // Teal Airbnb

// ----- Design tokens « clair garanti » (utilities inline, pas de dark:) -----
const AIR_SHADOW = 'shadow-[0_6px_16px_rgba(0,0,0,0.08),0_1px_2px_rgba(0,0,0,0.04)]';
const AIR_SHADOW_LG = 'shadow-[0_12px_32px_rgba(0,0,0,0.12),0_2px_6px_rgba(0,0,0,0.06)]';
const CARD_CLAIR = cn('rounded-2xl border border-[#ece7e1] bg-white', AIR_SHADOW);

/** Tonalités pastel des cartes KPI (dégradés clairs explicites). */
const TONES = {
  rausch: {
    card: 'bg-gradient-to-br from-[#EAF2FF] to-[#DBE8FF] text-[#0642A8]',
    bubble: 'bg-gradient-to-br from-[#0066EF] to-[#0047B3]',
  },
  emerald: {
    card: 'bg-gradient-to-br from-[#E7FAF6] to-[#D2F3EC] text-[#0B7A6E]',
    bubble: 'bg-gradient-to-br from-[#00A699] to-[#047857]',
  },
  amber: {
    card: 'bg-gradient-to-br from-[#FFF4E5] to-[#FFE8CC] text-[#B45309]',
    bubble: 'bg-gradient-to-br from-[#F59E0B] to-[#D97706]',
  },
  violet: {
    card: 'bg-gradient-to-br from-[#F3EFFE] to-[#E9E2FC] text-[#6D28D9]',
    bubble: 'bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9]',
  },
} as const;
type ToneKey = keyof typeof TONES;

/** Emoji du flux d'activité, par type d'événement. */
const ACTIVITY_EMOJI: Record<ActivityItem['type'], string> = {
  scan: '📱',
  order: '💰',
  booking: '📅',
  message: '🎙️',
};

const QUICK_ACTIONS = [
  { href: '/airbnb/properties?new=1', emoji: '🏠', label: 'Ajouter une propriété', tone: 'rausch' },
  { href: '/airbnb/plates?new=1', emoji: '📱', label: 'Générer une plaque QR', tone: 'teal' },
  { href: '/airbnb/orders', emoji: '💰', label: 'Voir les commandes', tone: 'emerald' },
  { href: '/airbnb/automations', emoji: '⚡', label: 'Automatisations', tone: 'violet' },
] as const;

/** Bulles dégradées des actions rapides (identiques clair/sombre). */
const QUICK_BUBBLES: Record<string, string> = {
  rausch: 'bg-gradient-to-br from-[#0066EF] to-[#0047B3]',
  teal: 'bg-gradient-to-br from-[#06B6D4] to-[#0E7490]',
  emerald: 'bg-gradient-to-br from-[#00A699] to-[#047857]',
  violet: 'bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9]',
};

/** Tonalité des bulles des modules du bien (clé → dégradé). */
const MODULE_BUBBLES: Record<string, string> = {
  WIFI: 'bg-gradient-to-br from-[#06B6D4] to-[#0E7490]',
  GUIDEBOOK: 'bg-gradient-to-br from-[#F59E0B] to-[#D97706]',
  UPSELLING: 'bg-gradient-to-br from-[#00A699] to-[#047857]',
  COMPLAINT: 'bg-gradient-to-br from-[#0066EF] to-[#0047B3]',
  PROVIDER_DIRECTORY: 'bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9]',
};

/** Badges de statut de réservation (clair). */
const STATUS_META: Record<string, { label: string; className: string }> = {
  CONFIRMED: { label: 'Confirmée', className: 'bg-emerald-50 text-emerald-700 ring-emerald-200' },
  PENDING: { label: 'En attente', className: 'bg-amber-50 text-amber-700 ring-amber-200' },
  COMPLETED: { label: 'Terminée', className: 'bg-slate-100 text-slate-600 ring-slate-200' },
};

function statusMeta(status: string) {
  return STATUS_META[status] ?? { label: status.toLowerCase(), className: 'bg-slate-100 text-slate-600 ring-slate-200' };
}

function sourceLabel(source: string): string {
  if (source === 'ICAL') return 'iCal';
  if (source === 'MANUAL') return 'Manuelle';
  return source.charAt(0) + source.slice(1).toLowerCase();
}

// ---------- Types de la nouvelle API /api/airbnb/dashboard-stats ----------
interface DayStatsResponse {
  scope: 'single' | 'all';
  property: { id: string; name: string } | null;
  stats: {
    propertiesActive: number;
    propertiesCount: number;
    staysInProgress: number;
    arrivalsToday: number;
    departuresToday: number;
    revenueThisMonth: number;
    ordersThisMonth: number;
    canSeeFinance: boolean;
  };
  today: {
    id: string;
    kind: 'arrival' | 'departure';
    guestName: string;
    propertyName: string;
    at: string;
    status: string;
    source: string;
  }[];
}

interface NotifItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  isRead: boolean;
  createdAt: string;
}

function formatEur(value: number): string {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(value);
}

function greeting(date: Date): string {
  const h = date.getHours();
  if (h < 12) return 'Bonjour';
  if (h < 18) return 'Bon après-midi';
  return 'Bonsoir';
}

function longDateFr(d: Date): string {
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

const fmtHour = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });

/** Skeleton clair local (le Skeleton global a une variante dark:). */
function AirSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-slate-200/70', className)} />;
}

/** Carte KPI « AIRBNB PRO clair » : icône lucide, valeur grosse, sous-titre. */
function StatCard({
  icon: Icon,
  tone,
  label,
  value,
  chip,
  hint,
  loading,
}: {
  icon: typeof Home;
  tone: ToneKey;
  label: string;
  value: string;
  chip?: { text: string; positive: boolean };
  hint?: string;
  loading?: boolean;
}) {
  const t = TONES[tone];
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      whileHover={{ y: -3 }}
      className={cn('rounded-2xl p-5', t.card, AIR_SHADOW, 'air-hoverlift')}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          aria-hidden="true"
          className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow', t.bubble)}
        >
          <Icon className="h-5 w-5" strokeWidth={2.2} />
        </span>
        {chip && !loading && (
          <span
            className={cn(
              'inline-flex shrink-0 items-center rounded-full bg-white/70 px-2.5 py-0.5 text-[11px] font-bold',
              chip.positive ? 'text-emerald-700' : 'text-rose-700',
            )}
          >
            {chip.text}
          </span>
        )}
      </div>
      {loading ? (
        <div className="mt-4 h-8 w-24 animate-pulse rounded-lg bg-black/10" aria-hidden="true" />
      ) : (
        <p className="mt-4 truncate text-3xl font-extrabold tracking-tight tabular-nums">{value}</p>
      )}
      <p className="mt-1 truncate text-sm font-semibold">{label}</p>
      {hint && !loading && <p className="mt-0.5 truncate text-[11px] opacity-75">{hint}</p>}
    </motion.div>
  );
}

export function OverviewContent() {
  const { userFirstName, invitations, properties, propertiesLoading, selectedId, onboardingCompleted, refreshProperties } =
    useHostContext();
  const { data, loading, error, refetch } = useOverview();
  const stats = data?.stats ?? null;
  const now = new Date();

  // ----- KPIs « journée » : /api/airbnb/dashboard-stats (real data) -----
  const [day, setDay] = useState<DayStatsResponse | null>(null);
  const [dayLoading, setDayLoading] = useState(true);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    if (propertiesLoading) return;
    let cancelled = false;
    setDayLoading(true);
    (async () => {
      try {
        const res = await fetch(`/api/airbnb/dashboard-stats?propertyId=${encodeURIComponent(selectedId)}`, {
          cache: 'no-store',
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as DayStatsResponse;
        if (!cancelled) setDay(json);
      } catch {
        if (!cancelled) setDay(null);
      } finally {
        if (!cancelled) setDayLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [selectedId, propertiesLoading, reloadKey]);

  // ----- Dernières notifications de l'utilisateur (section « Activité récente ») -----
  const [notifs, setNotifs] = useState<NotifItem[]>([]);
  const [notifsLoading, setNotifsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/airbnb/notifications?limit=8', { cache: 'no-store' });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = (await res.json()) as { notifications: NotifItem[] };
        if (!cancelled) setNotifs(json.notifications ?? []);
      } catch {
        if (!cancelled) setNotifs([]);
      } finally {
        if (!cancelled) setNotifsLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [reloadKey]);

  // ----- Chantier ONBOARDING : assistant post-inscription (conservé) -----
  const [onboardingClosed, setOnboardingClosed] = useState(false);
  const onboardingTarget = useMemo(() => {
    if (propertiesLoading || onboardingClosed || onboardingCompleted) return null;
    if (typeof window !== 'undefined' && sessionStorage.getItem('ch-onboarding-dismissed') === '1') {
      return null;
    }
    const owned = properties.find((p) => p.isOwner);
    if (!owned) return null;
    return { propertyId: owned.id, name: owned.name, address: owned.address ?? '' };
  }, [properties, propertiesLoading, onboardingCompleted, onboardingClosed]);

  function finishOnboarding(completed: boolean) {
    setOnboardingClosed(true);
    if (completed) {
      toast.success('Votre logement est configuré 🎉');
      void refreshProperties();
      void refetch();
    }
  }

  function refreshAll() {
    void refetch();
    setReloadKey((k) => k + 1);
    toast.success('Données actualisées');
  }

  const ds = day?.stats ?? null;
  const kpiLoading = dayLoading || propertiesLoading;

  return (
    <div className="light -m-4 min-h-full bg-[#faf9f7] p-4 pb-8 text-slate-900 [color-scheme:light] sm:-m-6 sm:p-6">
      <div className="flex flex-col gap-6">
        {/* ---------- HERO clair Airbnb Pro ---------- */}
        <motion.section
          aria-label="Vue d'ensemble"
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className={cn('relative overflow-hidden rounded-3xl border border-[#DBE8FF] bg-white p-6 sm:p-8', AIR_SHADOW_LG)}
        >
          {/* Halos discrets Rausch / Babu */}
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-24 -top-28 h-72 w-72 rounded-full bg-[#0066EF]/10 blur-3xl"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-28 right-1/3 h-56 w-56 rounded-full bg-[#00A699]/10 blur-3xl"
          />

          <div className="relative flex flex-wrap items-start justify-between gap-x-6 gap-y-4">
            <div className="min-w-0">
              {/* suppressHydrationWarning : salutation/date dépendent de l'horloge locale. */}
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#0066EF]" suppressHydrationWarning>
                {longDateFr(now)}
              </p>
              <h1 className="mt-1.5 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-4xl" suppressHydrationWarning>
                {greeting(now)}, {userFirstName} 👋
              </h1>
              <p className="mt-2 max-w-xl text-sm text-slate-600 sm:text-[15px]" suppressHydrationWarning>
                {data?.scope === 'single' && data.property ? (
                  <>
                    Activité de <span className="font-bold text-slate-900">{data.property.name}</span> — voici
                    l&apos;état de vos locations aujourd&apos;hui.
                  </>
                ) : (
                  <>
                    Vue consolidée de vos {properties.length} propriétés — voici l&apos;état de vos locations
                    aujourd&apos;hui.
                  </>
                )}
              </p>

              {/* Actions rapides du hero */}
              <div className="mt-5 flex flex-wrap items-center gap-2">
                <Link
                  href="/airbnb/properties?new=1"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full bg-[#0066EF] px-5 text-sm font-bold text-white shadow-[0_8px_24px_rgba(0,102,239,0.30)] transition-all hover:bg-[#0052C4] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/60"
                >
                  <Home className="h-4 w-4" aria-hidden="true" />
                  Nouvelle propriété
                </Link>
                <Link
                  href="/airbnb/calendar"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 transition-colors hover:border-[#0066EF]/40 hover:text-[#0066EF] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/40"
                >
                  <CalendarPlus className="h-4 w-4" aria-hidden="true" />
                  Ajouter un séjour
                </Link>
                <Link
                  href="/airbnb/menage"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-5 text-sm font-bold text-slate-700 transition-colors hover:border-[#0066EF]/40 hover:text-[#0066EF] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/40"
                >
                  <ListChecks className="h-4 w-4" aria-hidden="true" />
                  Voir les tâches
                </Link>
                <button
                  type="button"
                  onClick={refreshAll}
                  disabled={loading || dayLoading}
                  aria-label="Actualiser les données"
                  className="inline-flex h-11 items-center justify-center gap-2 rounded-full px-4 text-sm font-bold text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/40 disabled:opacity-60"
                >
                  <RefreshCw className={cn('h-4 w-4', (loading || dayLoading) && 'animate-spin')} aria-hidden="true" />
                  <span className="sr-only sm:not-sr-only">Actualiser</span>
                </button>
              </div>
            </div>
          </div>
        </motion.section>

        {/* ---------- Bannière invitations en attente (conservée) ---------- */}
        {invitations.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            className={cn(
              'flex flex-wrap items-center gap-3 rounded-2xl border border-amber-300/80 bg-amber-50 px-4 py-3',
              AIR_SHADOW,
            )}
            role="status"
          >
            <span aria-hidden="true" className="text-xl">✉️</span>
            <p className="flex-1 text-sm text-amber-900">
              <span className="font-bold">
                {invitations.length === 1 ? 'Une invitation en attente' : `${invitations.length} invitations en attente`}
              </span>{' '}
              — {invitations[0].property.name} ({roleLabel(invitations[0].role)})
              {invitations.length > 1 && ' et d’autres…'}
            </p>
            <Link
              href="/airbnb/team"
              className="inline-flex h-9 items-center rounded-full bg-amber-500 px-3 text-xs font-bold text-white shadow transition-colors hover:bg-amber-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50"
            >
              Gérer mes invitations
            </Link>
          </motion.div>
        )}

        {/* ---------- Erreur API (conservée) ---------- */}
        {error && (
          <div
            className={cn('flex flex-col items-center gap-3 rounded-2xl border border-rose-100 bg-rose-50/70 p-6 text-center', AIR_SHADOW)}
            role="alert"
          >
            <span className="air-float text-3xl" aria-hidden="true">⚠️</span>
            <p className="text-sm font-semibold text-slate-900">{error}</p>
            <button
              type="button"
              onClick={() => {
                void refetch();
              }}
              className="inline-flex h-10 items-center gap-2 rounded-full bg-[#0066EF] px-5 text-xs font-bold text-white shadow transition-all hover:bg-[#0052C4] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50"
            >
              <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
              Réessayer
            </button>
          </div>
        )}

        {/* ---------- 4 KPIs (real data /api/airbnb/dashboard-stats) ---------- */}
        <section aria-label="Indicateurs clés du jour" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            icon={Home}
            tone="rausch"
            label="Propriétés actives"
            value={ds ? `${ds.propertiesActive}/${ds.propertiesCount}` : '—'}
            hint={day?.scope === 'single' ? 'Bien sélectionné' : 'Toutes propriétés confondues'}
            loading={kpiLoading}
          />
          <StatCard
            icon={BedDouble}
            tone="emerald"
            label="Séjours en cours"
            value={ds ? String(ds.staysInProgress) : '—'}
            hint={ds && ds.arrivalsToday > 0 ? `+ ${ds.arrivalsToday} arrivée${ds.arrivalsToday > 1 ? 's' : ''} aujourd’hui` : 'Check-ins et check-outs à venir'}
            loading={kpiLoading}
          />
          <StatCard
            icon={PlaneLanding}
            tone="amber"
            label="Arrivées aujourd'hui"
            value={ds ? String(ds.arrivalsToday) : '—'}
            hint={ds ? `${ds.departuresToday} départ${ds.departuresToday > 1 ? 's' : ''} prévu${ds.departuresToday > 1 ? 's' : ''} aujourd’hui` : undefined}
            loading={kpiLoading}
          />
          <StatCard
            icon={Wallet}
            tone="violet"
            label="Revenus du mois"
            value={ds ? formatEur(ds.revenueThisMonth) : '—'}
            chip={
              stats?.ordersDelta != null
                ? { text: `${stats.ordersDelta >= 0 ? '▲' : '▼'} ${Math.abs(stats.ordersDelta)}%`, positive: stats.ordersDelta >= 0 }
                : undefined
            }
            hint={
              ds
                ? ds.canSeeFinance
                  ? `${ds.ordersThisMonth} commande${ds.ordersThisMonth > 1 ? 's' : ''} payée${ds.ordersThisMonth > 1 ? 's' : ''} ce mois`
                  : 'Non visible pour votre rôle'
                : undefined
            }
            loading={kpiLoading}
          />
        </section>

        {/* ---------- Bande secondaire (données conservées : scans, note, commandes) ---------- */}
        <section aria-label="Autres indicateurs" className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            {
              emoji: '📱',
              label: 'Scans ce mois',
              value: stats ? stats.scansThisMonth.toLocaleString('fr-FR') : '—',
              chip:
                stats?.scansDelta != null
                  ? `${stats.scansDelta >= 0 ? '▲' : '▼'} ${Math.abs(stats.scansDelta)}%`
                  : undefined,
              hint: stats?.lastScanAt ? `Dernier scan ${relativeFrTime(new Date(stats.lastScanAt))}` : 'Aucun scan pour l’instant',
            },
            {
              emoji: '⭐',
              label: 'Note moyenne',
              value: stats?.avgRating != null ? `${stats.avgRating.toFixed(1).replace('.', ',')}/5` : '—',
              chip: undefined,
              hint: stats ? `${stats.reviewsCount} avis service${stats.reviewsCount > 1 ? 's' : ''}` : undefined,
            },
            {
              emoji: '🛒',
              label: 'Commandes ce mois',
              value: stats ? String(stats.ordersThisMonth) : '—',
              chip:
                stats?.ordersDelta != null
                  ? `${stats.ordersDelta >= 0 ? '▲' : '▼'} ${Math.abs(stats.ordersDelta)}%`
                  : undefined,
              hint: 'Commandes invités payées',
            },
          ].map((s) => (
            <div key={s.label} className={cn('flex items-center gap-3 p-4', CARD_CLAIR)}>
              <span
                aria-hidden="true"
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-lg"
              >
                {s.emoji}
              </span>
              <div className="min-w-0 flex-1">
                {loading || propertiesLoading ? (
                  <AirSkeleton className="h-5 w-20" />
                ) : (
                  <p className="truncate text-lg font-extrabold tabular-nums text-slate-900">
                    {s.value}
                    {s.chip && (
                      <span
                        className={cn(
                          'ml-2 align-middle text-[11px] font-bold',
                          s.chip.startsWith('▲') ? 'text-emerald-600' : 'text-rose-600',
                        )}
                      >
                        {s.chip}
                      </span>
                    )}
                  </p>
                )}
                <p className="truncate text-xs font-semibold text-slate-600">{s.label}</p>
                {s.hint && <p className="truncate text-[11px] text-slate-400">{s.hint}</p>}
              </div>
            </div>
          ))}
        </section>

        {/* ---------- Arrivées & Départs du jour + Activité récente (notifications) ---------- */}
        <section aria-label="Journée et notifications" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          {/* ----- Arrivées & Départs du jour (real data) ----- */}
          <div className={cn('flex flex-col p-5 sm:p-6 xl:col-span-2', CARD_CLAIR)}>
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900">🛬 Arrivées &amp; Départs du jour</h2>
                <p suppressHydrationWarning className="text-xs text-slate-500">Programme réel de vos séjours — {longDateFr(now)}</p>
              </div>
              <Link
                href="/airbnb/calendar"
                className="inline-flex h-8 items-center gap-1 rounded-full border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 transition-colors hover:border-[#0066EF]/40 hover:text-[#0066EF]"
              >
                Calendrier
                <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
              </Link>
            </div>

            {kpiLoading ? (
              <div className="flex flex-col gap-3">
                {Array.from({ length: 3 }).map((_, i) => (
                  <AirSkeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : (day?.today.length ?? 0) === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 p-8 text-center">
                <span className="air-float text-3xl" aria-hidden="true">🌤️</span>
                <p className="text-sm font-semibold text-slate-900">Aucune arrivée aujourd&apos;hui</p>
                <p className="text-xs text-slate-500">
                  Ni départ non plus — journée tranquille. Les réservations du calendrier apparaîtront ici.
                </p>
              </div>
            ) : (
              <ul className="flex max-h-[320px] flex-col gap-2 overflow-y-auto pr-1 [scrollbar-width:thin]">
                {day?.today.map((item, i) => {
                  const st = statusMeta(item.status);
                  const isArrival = item.kind === 'arrival';
                  return (
                    <motion.li
                      key={item.id}
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.04 * i, duration: 0.25 }}
                      className="flex items-center gap-3 rounded-xl border border-slate-100 bg-slate-50/60 px-3 py-2.5"
                    >
                      <span
                        aria-hidden="true"
                        className={cn(
                          'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white shadow',
                          isArrival
                            ? 'bg-gradient-to-br from-[#0066EF] to-[#0047B3]'
                            : 'bg-gradient-to-br from-[#00A699] to-[#047857]',
                        )}
                      >
                        {isArrival ? <LogIn className="h-4 w-4" /> : <LogOut className="h-4 w-4" />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-slate-900">
                          {item.guestName}
                          <span className="ml-2 text-xs font-semibold text-slate-500">{item.propertyName}</span>
                        </p>
                        <p className="truncate text-xs text-slate-500">
                          {isArrival ? 'Arrivée' : 'Départ'} · {sourceLabel(item.source)}
                        </p>
                      </div>
                      <span
                        className={cn(
                          'hidden shrink-0 items-center rounded-full px-2 py-0.5 text-[11px] font-bold ring-1 sm:inline-flex',
                          st.className,
                        )}
                      >
                        {st.label}
                      </span>
                      <time
                        dateTime={item.at}
                        className="shrink-0 text-sm font-extrabold tabular-nums text-slate-900"
                        title={new Date(item.at).toLocaleString('fr-FR')}
                      >
                        {fmtHour.format(new Date(item.at))}
                      </time>
                    </motion.li>
                  );
                })}
              </ul>
            )}
          </div>

          {/* ----- Activité récente : dernières notifications de l'utilisateur ----- */}
          <div className={cn('flex flex-col p-5', CARD_CLAIR)}>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">🔔 Activité récente</h2>
              <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-500">
                {notifsLoading ? '…' : notifs.length}
              </span>
            </div>
            {notifsLoading ? (
              <div className="flex flex-col gap-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <AirSkeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : notifs.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 p-6 text-center">
                <span className="air-float text-3xl" aria-hidden="true">🌿</span>
                <p className="text-sm font-semibold text-slate-900">Aucune notification pour le moment.</p>
                <p className="text-xs text-slate-500">Réservations, ménages et réclamations arriveront ici.</p>
              </div>
            ) : (
              <ul className="flex max-h-[320px] flex-col gap-1 overflow-y-auto pr-1 [scrollbar-width:thin]">
                {notifs.map((n) => (
                  <li key={n.id} className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-slate-50">
                    <span
                      aria-hidden="true"
                      className={cn(
                        'mt-1.5 h-2 w-2 shrink-0 rounded-full',
                        n.isRead ? 'bg-slate-200' : 'bg-[#0066EF]',
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-slate-900">{n.title}</p>
                      {n.body && <p className="line-clamp-2 text-xs text-slate-500">{n.body}</p>}
                    </div>
                    <time
                      dateTime={n.createdAt}
                      className="shrink-0 text-[11px] text-slate-400"
                      title={new Date(n.createdAt).toLocaleString('fr-FR')}
                    >
                      {relativeFrTime(new Date(n.createdAt))}
                    </time>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ---------- Graphique + Flux d'activité (conservés) ---------- */}
        <section aria-label="Activité et historique" className="grid grid-cols-1 gap-4 xl:grid-cols-3">
          {/* Graphique 30 jours */}
          <div className={cn('p-5 xl:col-span-2', CARD_CLAIR)}>
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900">📈 Courbe d&apos;activité</h2>
                <p className="text-xs text-slate-500">Scans de plaques et commandes — 30 derniers jours</p>
              </div>
            </div>
            {loading || propertiesLoading ? (
              <AirSkeleton className="h-[280px] w-full" />
            ) : (
              <div
                className="h-[280px] w-full"
                role="img"
                aria-label="Courbe d'activité des 30 derniers jours : scans et commandes par jour"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data?.series ?? []} margin={{ top: 4, right: 8, left: -18, bottom: 0 }}>
                    <defs>
                      <linearGradient id="gradScans" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={BRAND} stopOpacity={0.28} />
                        <stop offset="100%" stopColor={BRAND} stopOpacity={0.02} />
                      </linearGradient>
                      <linearGradient id="gradOrders" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={BABU} stopOpacity={0.24} />
                        <stop offset="100%" stopColor={BABU} stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                      interval="preserveStartEnd"
                      minTickGap={24}
                    />
                    <YAxis
                      yAxisId="scans"
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickLine={false}
                      axisLine={false}
                      allowDecimals={false}
                    />
                    <YAxis
                      yAxisId="orders"
                      orientation="right"
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      tickLine={false}
                      axisLine={false}
                      allowDecimals={false}
                    />
                    <Tooltip
                      contentStyle={{
                        borderRadius: 12,
                        border: '1px solid #e2e8f0',
                        backgroundColor: '#ffffff',
                        color: '#0f172a',
                        boxShadow: '0 4px 12px rgb(0 0 0 / 0.06)',
                        fontSize: 13,
                      }}
                      formatter={(value: number | string, name: string) => [
                        String(value),
                        name === 'scans' ? 'Scans' : 'Commandes',
                      ]}
                    />
                    <Legend
                      formatter={(value: string) => (
                        <span className="text-xs font-semibold text-slate-500">
                          {value === 'scans' ? 'Scans de plaques' : 'Commandes invités'}
                        </span>
                      )}
                    />
                    <Area
                      yAxisId="scans"
                      type="monotone"
                      dataKey="scans"
                      stroke={BRAND}
                      strokeWidth={2.5}
                      fill="url(#gradScans)"
                      activeDot={{ r: 4, strokeWidth: 2 }}
                    />
                    <Area
                      yAxisId="orders"
                      type="monotone"
                      dataKey="orders"
                      stroke={BABU}
                      strokeWidth={2.5}
                      fill="url(#gradOrders)"
                      activeDot={{ r: 4, strokeWidth: 2 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Flux d'activité unifié (conservé) */}
          <div className={cn('flex flex-col p-5', CARD_CLAIR)}>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900">🕒 Flux d&apos;activité</h2>
              <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-bold text-slate-500">
                {data?.activity.length ?? 0}
              </span>
            </div>
            {loading || propertiesLoading ? (
              <div className="flex flex-col gap-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <AirSkeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (data?.activity.length ?? 0) === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 p-6 text-center">
                <span className="air-float text-3xl" aria-hidden="true">🌿</span>
                <p className="text-sm font-semibold text-slate-900">Aucune activité pour le moment.</p>
                <p className="text-xs text-slate-500">Scans, commandes et réservations apparaîtront ici.</p>
              </div>
            ) : (
              <ul className="flex max-h-[300px] flex-col gap-1 overflow-y-auto pr-1 [scrollbar-width:thin]">
                {data?.activity.map((item) => (
                  <li key={item.id} className="flex items-start gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-slate-50">
                    <span
                      aria-hidden="true"
                      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-base"
                    >
                      {ACTIVITY_EMOJI[item.type]}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-slate-900">{item.title}</p>
                      {item.detail && <p className="truncate text-xs text-slate-500">{item.detail}</p>}
                    </div>
                    <div className="shrink-0 text-right">
                      {item.amount != null && (
                        <p className="text-sm font-bold text-emerald-600">{formatEur(item.amount)}</p>
                      )}
                      <time
                        dateTime={item.at}
                        className="text-[11px] text-slate-400"
                        title={new Date(item.at).toLocaleString('fr-FR')}
                      >
                        {relativeFrTime(new Date(item.at))}
                      </time>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ---------- Actions rapides (conservées) ---------- */}
        <section aria-label="Actions rapides">
          <h2 className="mb-3 text-base font-bold text-slate-900">⚡ Actions rapides</h2>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {QUICK_ACTIONS.map((action, i) => (
              <motion.div
                key={action.href}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.05 * i, duration: 0.25 }}
              >
                <Link
                  href={action.href}
                  className={cn(
                    'air-hoverlift group flex h-full items-center gap-3 p-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50',
                    CARD_CLAIR,
                  )}
                >
                  <span
                    aria-hidden="true"
                    className={cn(
                      'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl text-white shadow',
                      QUICK_BUBBLES[action.tone],
                    )}
                  >
                    {action.emoji}
                  </span>
                  <span className="min-w-0 flex-1 text-[13px] font-bold leading-tight text-slate-900 sm:text-sm">
                    {action.label}
                  </span>
                  <ChevronRight
                    aria-hidden="true"
                    className="h-4 w-4 shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5"
                  />
                </Link>
              </motion.div>
            ))}
          </div>
        </section>

        {/* ---------- Modules actifs (aperçu QR — conservé) ---------- */}
        {!loading && data && data.modules.length > 0 && (
          <section aria-label="Modules du bien">
            <h2 className="mb-3 text-base font-bold text-slate-900">
              🧩 Modules {data.scope === 'single' && data.property ? `— ${data.property.name}` : '(toutes propriétés)'}
            </h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
              {data.modules.map((m, i) => (
                <motion.div
                  key={m.key}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.04 * i, duration: 0.25 }}
                  className={cn('air-hoverlift p-4', CARD_CLAIR)}
                >
                  <span
                    aria-hidden="true"
                    className={cn(
                      'flex h-10 w-10 items-center justify-center rounded-xl text-lg text-white shadow',
                      MODULE_BUBBLES[m.key] ?? 'bg-gradient-to-br from-[#0066EF] to-[#0047B3]',
                    )}
                  >
                    {m.emoji}
                  </span>
                  <p className="mt-2 text-sm font-bold text-slate-900">{m.label}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{m.description}</p>
                  <p className="air-gradient-text mt-2 text-xs font-extrabold">
                    {m.qrCount} QR actif{m.qrCount > 1 ? 's' : ''}
                    {m.nearbyProviders != null && m.qrCount > 0 && (
                      <> · {m.nearbyProviders} prestataire{m.nearbyProviders > 1 ? 's' : ''} à proximité</>
                    )}
                  </p>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* ---------- Wizard d'onboarding (post-inscription — conservé) ---------- */}
        {onboardingTarget && (
          <OnboardingWizard
            open
            propertyId={onboardingTarget.propertyId}
            initialName={onboardingTarget.name}
            initialAddress={onboardingTarget.address}
            onFinished={finishOnboarding}
          />
        )}
      </div>
    </div>
  );
}

function roleLabel(role: string): string {
  switch (role) {
    case 'OWNER': return 'propriétaire';
    case 'MANAGER': return 'manager';
    case 'CLEANER': return 'ménage';
    case 'MAINTENANCE': return 'maintenance';
    default: return role.toLowerCase();
  }
}
