'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

// =============================================================
// KPICard — tuile KPI du Dashboard Hôte
// v7.0 « AZUR » — refonte design (demande client) : tuiles en
// DÉGRADÉS COLORÉS (bleu / rouge / orange / violet / vert / teal)
// avec GRANDE valeur blanche + vague SVG décorative en bas.
// Rendu identique en mode clair et sombre (couleurs explicites).
//
// RÉTRO-COMPATIBILITÉ : l'ancienne API (icon/emoji, tone,
// delta: number|null, loading, onClick, className) reste
// supportée pour orders-content.tsx et plates-content.tsx —
// les props icon/emoji ne sont pas rendues et `tone` choisit
// le dégradé de la tuile.
// =============================================================

export type KPITone = 'rausch' | 'emerald' | 'amber' | 'violet' | 'teal' | 'orange';

/** Dégradé de la tuile par tonalité (palette azur du client). */
const TONE_GRADIENTS: Record<KPITone, string> = {
  rausch: 'linear-gradient(160deg,#5B8CFF,#2E5BFF)', // bleu
  emerald: 'linear-gradient(160deg,#4ADE9B,#0DA678)', // vert harmonieux
  amber: 'linear-gradient(160deg,#FF9A62,#F97316)', // orange
  violet: 'linear-gradient(160deg,#C084FC,#7C3AED)', // violet
  teal: 'linear-gradient(160deg,#5B8CFF,#2E5BFF)', // bleu
  orange: 'linear-gradient(160deg,#FF6B7E,#E11D48)', // rouge
};

export interface KPICardProps {
  label: string;
  value: string | number;
  /** Ancienne prop (non rendue). */
  emoji?: string;
  /** Ancienne prop (non rendue). */
  icon?: unknown;
  /** v4.59 — tonalité chromatique → dégradé de la tuile. */
  tone?: KPITone;
  /** v4.59 — pastille d'info en haut à droite (ex : « ▲ 12% », « nouveau »). */
  chip?: { text: string; tone?: 'positive' | 'negative' | 'neutral' };
  /** Ancienne API — variation vs période précédente, en % (convertie en chip). */
  delta?: number | null;
  /** Texte complémentaire sous la valeur (ex : "vs mois précédent"). */
  hint?: string;
  loading?: boolean;
  /** Clic optionnel → carte interactive. */
  onClick?: () => void;
  className?: string;
}

export function KPICard({
  label,
  value,
  tone,
  chip,
  delta,
  hint,
  loading = false,
  onClick,
  className,
}: KPICardProps) {
  const interactive = Boolean(onClick);

  // Chip : nouvelle API prioritaire, sinon conversion de l'ancienne `delta`.
  const resolvedChip =
    chip ??
    (delta != null && !loading
      ? {
          text: `${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}%`,
          tone: (delta >= 0 ? 'positive' : 'negative') as 'positive' | 'negative',
        }
      : undefined);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      whileHover={{ y: -2 }}
      onClick={onClick}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      onKeyDown={
        interactive
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick?.();
              }
            }
          : undefined
      }
      className={cn(
        'group relative overflow-hidden rounded-2xl p-5 text-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.25)]',
        interactive &&
          'cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#E4E9F7]',
        className,
      )}
      style={{ background: tone ? TONE_GRADIENTS[tone] : TONE_GRADIENTS.rausch }}
      aria-label={`${label} : ${loading ? 'chargement' : value}`}
    >
      {/* Vague SVG décorative (blanc translucide) en bas de tuile */}
      <svg
        aria-hidden="true"
        viewBox="0 0 220 40"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-9 w-full"
      >
        <path
          d="M0 40 L0 22 C 30 4, 55 30, 90 18 C 125 6, 150 28, 185 14 C 198 9, 210 10, 220 16 L220 40 Z"
          fill="#ffffff"
          fillOpacity="0.2"
        />
      </svg>

      <div className="relative flex items-start justify-between gap-2">
        <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/80">{label}</p>
        {resolvedChip && !loading && (
          <span
            className={cn(
              'inline-flex shrink-0 items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold',
              resolvedChip.tone === 'positive' && 'bg-white/25 text-white',
              resolvedChip.tone === 'negative' && 'bg-[#450a0a]/30 text-white ring-1 ring-white/30',
              (!resolvedChip.tone || resolvedChip.tone === 'neutral') && 'bg-white/20 text-white',
            )}
          >
            {resolvedChip.text}
          </span>
        )}
      </div>
      {loading ? (
        <div className="relative mt-3 h-9 w-24 animate-pulse rounded-lg bg-white/25" aria-hidden="true" />
      ) : (
        <p className="relative mt-2 text-3xl font-bold leading-none tracking-tight text-white sm:text-4xl">
          {value}
        </p>
      )}
      {hint && !loading && (
        <p className="relative mt-2 line-clamp-2 text-[11.5px] font-medium text-white/75">{hint}</p>
      )}
    </motion.div>
  );
}
