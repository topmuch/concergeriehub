'use client';

import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

// =============================================================
// KPICard — carte de statistique du Dashboard Hôte
// v4.59 « AIRBNB PRO » : fond pastel kpi-{tone} (clair + dark
// automatiques via globals.css), bulle d'icône dégradée
// kpi-bubble-{tone} (contenu blanc), chip optionnelle, hint
// discret, ombre douce air-shadow + lift au survol.
//
// RÉTRO-COMPATIBILITÉ : l'ancienne API (icon: '💰' en string,
// delta: number|null, loading, onClick, className) reste
// supportée pour orders-content.tsx et plates-content.tsx.
// Sans `tone`, la carte adopte un rendu neutre sémantique
// (bg-card / border-border) lisible en clair ET en sombre.
// =============================================================

export type KPITone = 'rausch' | 'emerald' | 'amber' | 'violet' | 'teal' | 'orange';

export interface KPICardProps {
  label: string;
  value: string | number;
  /** v4.59 — emoji affiché dans la bulle dégradée. */
  emoji?: string;
  /** Icône : string = emoji (ancienne API), composant Lucide = nouvelle API. */
  icon?: LucideIcon | string;
  /** v4.59 — tonalité chromatique de la carte (fond pastel + bulle dégradée). */
  tone?: KPITone;
  /** v4.59 — pastille d'info en haut à droite (ex : « ▲ 12% », « nouveau »). */
  chip?: { text: string; tone?: 'positive' | 'negative' | 'neutral' };
  /** Ancienne API — variation vs période précédente, en % (convertie en chip). */
  delta?: number | null;
  /** Texte complémentaire sous la valeur (ex : "vs mois précédent"). */
  hint?: string;
  loading?: boolean;
  /** Clic optionnel → carte interactive. */
  onClick?: () => void;
  className?: string;
}

/** Couleurs de texte des chips sur fond pastel toné. */
const CHIP_TONE_CLASSES: Record<'positive' | 'negative' | 'neutral', string> = {
  positive: 'text-emerald-700 dark:text-emerald-300',
  negative: 'text-rose-700 dark:text-rose-300',
  neutral: '',
};

/** Couleurs des chips sur carte neutre (ancienne API, sans tonalité). */
const LEGACY_CHIP_TONE_CLASSES: Record<'positive' | 'negative' | 'neutral', string> = {
  positive: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300',
  negative: 'bg-rose-500/10 text-rose-700 dark:text-rose-300',
  neutral: 'bg-muted text-muted-foreground',
};

export function KPICard({
  label,
  value,
  emoji,
  icon,
  tone,
  chip,
  delta,
  hint,
  loading = false,
  onClick,
  className,
}: KPICardProps) {
  const interactive = Boolean(onClick);
  const toned = tone != null;

  // Glyphe : emoji (string — nouvelle prop `emoji` ou ancienne `icon`
  // passée en string) OU composant Lucide (nouvelle API).
  const rawGlyph = emoji ?? (typeof icon === 'string' ? icon : undefined);
  const LucideGlyph = typeof icon === 'function' ? icon : undefined;

  // Chip : nouvelle API prioritaire, sinon conversion de l'ancienne `delta`.
  const resolvedChip =
    chip ??
    (delta != null && !loading
      ? {
          text: `${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)}%`,
          tone: (delta >= 0 ? 'positive' : 'negative') as 'positive' | 'negative',
        }
      : undefined);

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      whileHover={{ y: -3 }}
      onClick={onClick}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      onKeyDown={
        interactive
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick?.();
              }
            }
          : undefined
      }
      className={cn(
        'group air-shadow air-hoverlift rounded-2xl p-5',
        toned ? `kpi-${tone}` : 'border border-border bg-card',
        interactive &&
          'cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#E61E4D]/50',
        className,
      )}
      aria-label={`${label} : ${loading ? 'chargement' : value}`}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          aria-hidden="true"
          className={cn(
            'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl shadow',
            toned ? `kpi-bubble-${tone} text-white` : 'bg-muted',
          )}
        >
          {LucideGlyph ? (
            <LucideGlyph className="h-5 w-5" aria-hidden="true" />
          ) : rawGlyph ? (
            <span className="text-xl leading-none">{rawGlyph}</span>
          ) : null}
        </span>
        {resolvedChip && !loading && (
          <span
            className={cn(
              'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-bold',
              toned
                ? cn('bg-white/60 dark:bg-white/10', CHIP_TONE_CLASSES[resolvedChip.tone ?? 'neutral'])
                : LEGACY_CHIP_TONE_CLASSES[resolvedChip.tone ?? 'neutral'],
            )}
          >
            {resolvedChip.text}
          </span>
        )}
      </div>

      {loading ? (
        <div className="mt-4 h-8 w-24 animate-pulse rounded-lg bg-black/10 dark:bg-white/10" aria-hidden="true" />
      ) : (
        <p className={cn('mt-4 text-3xl font-extrabold tracking-tight tabular-nums', !toned && 'text-foreground')}>
          {value}
        </p>
      )}
      <p className={cn('mt-1 text-sm font-medium opacity-80', !toned && 'text-foreground')}>{label}</p>
      {hint && !loading && (
        <p className={cn('mt-0.5 text-[11px] opacity-70', !toned && 'text-muted-foreground')}>{hint}</p>
      )}
    </motion.div>
  );
}
