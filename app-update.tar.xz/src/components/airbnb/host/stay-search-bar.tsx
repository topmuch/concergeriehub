'use client';

// =============================================================
// StaySearchBar — v6.2 (demande client, page Séjours)
// Barre de recherche + filtres de l'onglet « Séjours » :
//   • recherche texte (invité OU logement) — debounced 200 ms côté
//     parent (ce composant garde la frappe locale fluide) ;
//   • recherche par DATE : plage « du / au » (type="date") qui filtre
//     les séjours CHEVAUCHANT la période (checkIn ≤ au && checkOut ≥ du) ;
//   • filtres segmentés temporels : Tous | À venir | En cours |
//     Terminés | Litiges (dégâts signalés) ;
//   • compteur de résultats (« X séjours sur Y ») + bouton
//     « Réinitialiser » affiché uniquement si des filtres sont actifs.
// Mobile-first : flex-wrap, inputs pleine largeur sous 480 px, cibles
// tactiles ≥ 40 px. Cohérence visuelle : thème nuit saphir (lux).
// =============================================================

import { useEffect, useState } from 'react';
import { CalendarDays, RotateCcw, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

/** Filtres temporels d'un séjour (client-side, jour local). */
export type StayFilter = 'all' | 'upcoming' | 'ongoing' | 'past' | 'disputes';

export const STAY_FILTER_OPTIONS: { value: StayFilter; label: string }[] = [
  { value: 'all', label: 'Tous' },
  { value: 'upcoming', label: 'À venir' },
  { value: 'ongoing', label: 'En cours' },
  { value: 'past', label: 'Terminés' },
  { value: 'disputes', label: 'Litiges' },
];

export interface StaySearchBarProps {
  /** Valeur appliquée côté parent (après debounce). */
  query: string;
  onQueryChange: (value: string) => void;
  /** Plage de dates ISO « YYYY-MM-DD » ('' = non renseignée). */
  dateFrom: string;
  dateTo: string;
  onDateFromChange: (value: string) => void;
  onDateToChange: (value: string) => void;
  filter: StayFilter;
  onFilterChange: (value: StayFilter) => void;
  /** Résultats après filtres / total du périmètre (compteur). */
  resultCount: number;
  totalCount: number;
  hasActiveFilters: boolean;
  onReset: () => void;
}

export function StaySearchBar({
  query,
  onQueryChange,
  dateFrom,
  dateTo,
  onDateFromChange,
  onDateToChange,
  filter,
  onFilterChange,
  resultCount,
  totalCount,
  hasActiveFilters,
  onReset,
}: StaySearchBarProps) {
  // Frappe locale instantanée ; la valeur n'est poussée au parent
  // qu'après 200 ms sans saisie (évite de filtrer à chaque touche).
  const [localQuery, setLocalQuery] = useState(query);

  useEffect(() => {
    // Resynchronisation si le parent réinitialise la recherche.
    setLocalQuery(query);
  }, [query]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      if (localQuery !== query) onQueryChange(localQuery);
    }, 200);
    return () => window.clearTimeout(timer);
  }, [localQuery, query, onQueryChange]);

  return (
    <section
      className="lux-card flex min-w-0 flex-col gap-3 p-4"
      aria-label="Recherche et filtres des séjours"
    >
      {/* Ligne 1 — recherche texte + plage de dates */}
      <div className="flex min-w-0 flex-col gap-2 sm:flex-row sm:items-center">
        <div className="relative min-w-0 flex-1">
          <Search
            aria-hidden="true"
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#8fa0c2]"
          />
          <Input
            type="search"
            value={localQuery}
            onChange={(e) => setLocalQuery(e.target.value)}
            placeholder="Rechercher un invité ou un logement…"
            className="h-10 w-full rounded-full border-white/12 bg-white/[0.04] pl-9 pr-4 text-white placeholder:text-[#8fa0c2]/60 focus-visible:ring-[#5c8af0]/50"
            aria-label="Rechercher un séjour par nom d'invité ou de logement"
          />
        </div>
        <div className="flex min-w-0 flex-wrap items-center gap-2">
          <CalendarDays aria-hidden="true" className="h-4 w-4 shrink-0 text-[#8fa0c2]" />
          <label className="sr-only" htmlFor="stay-date-from">
            Séjours à partir du
          </label>
          <Input
            id="stay-date-from"
            type="date"
            value={dateFrom}
            onChange={(e) => onDateFromChange(e.target.value)}
            className="h-10 w-full min-w-0 rounded-full border-white/12 bg-white/[0.04] px-3 text-sm text-white [color-scheme:dark] focus-visible:ring-[#5c8af0]/50 sm:w-auto"
            aria-label="Filtrer les séjours à partir du"
          />
          <span aria-hidden="true" className="shrink-0 text-xs text-[#8fa0c2]">
            →
          </span>
          <label className="sr-only" htmlFor="stay-date-to">
            Séjours jusqu'au
          </label>
          <Input
            id="stay-date-to"
            type="date"
            value={dateTo}
            onChange={(e) => onDateToChange(e.target.value)}
            className="h-10 w-full min-w-0 rounded-full border-white/12 bg-white/[0.04] px-3 text-sm text-white [color-scheme:dark] focus-visible:ring-[#5c8af0]/50 sm:w-auto"
            aria-label="Filtrer les séjours jusqu'au"
          />
        </div>
      </div>

      {/* Ligne 2 — filtres segmentés + compteur + réinitialisation */}
      <div className="flex min-w-0 flex-wrap items-center gap-2">
        <div
          className="flex min-w-0 flex-wrap items-center gap-1.5"
          role="group"
          aria-label="Filtrer les séjours par période"
        >
          {STAY_FILTER_OPTIONS.map((opt) => {
            const active = filter === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => onFilterChange(opt.value)}
                aria-pressed={active}
                className={cn(
                  'inline-flex min-h-[36px] items-center rounded-full border px-3.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#5c8af0]/50',
                  active
                    ? 'border-[#5c8af0]/40 bg-[#5c8af0]/15 text-white'
                    : 'border-white/12 bg-white/[0.03] text-[#8fa0c2] hover:bg-white/[0.06] hover:text-white',
                )}
              >
                {opt.label}
              </button>
            );
          })}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <p className="lux-num whitespace-nowrap text-xs text-[#8fa0c2]" aria-live="polite">
            <span className="font-semibold text-white">{resultCount}</span> séjour
            {resultCount > 1 ? 's' : ''} sur {totalCount}
          </p>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={onReset}
              className="btn-tertiary-gray"
              aria-label="Réinitialiser la recherche et les filtres"
            >
              <RotateCcw aria-hidden="true" className="h-3.5 w-3.5" />
              Réinitialiser
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
