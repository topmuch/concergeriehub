'use client';

// =============================================================
// UI PARTAGÉE — module « Ménage & Stock »
// Petits briques communes aux 5 onglets : champ de saisie saphir,
// bouton fantôme, point de chargement pulsé (aucune icône).
// =============================================================
import { cn } from '@/lib/utils';

/** Classes communes des champs de saisie sur la nuit saphir. */
export const LUX_FIELD =
  'rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50';

/** Bouton secondaire fantôme (shadcn Button + teintes lux). */
export const LUX_GHOST_BTN =
  'rounded-full border-slate-200 bg-slate-50 font-semibold text-slate-700 hover:bg-slate-100 hover:text-slate-900';

/** Point pulsé — indicateur de chargement (remplace toute icône busy). */
export function LuxBusyDot({ color = 'rgba(255,255,255,0.9)', className }: { color?: string; className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn('h-2 w-2 rounded-full animate-pulse', className)}
      style={{ backgroundColor: color }}
    />
  );
}
