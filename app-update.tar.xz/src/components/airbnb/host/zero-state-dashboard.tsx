import { Home, RotateCcw, ArrowRight, CheckCircle2 } from 'lucide-react';
import Link from 'next/link';

// =============================================================
// v4.135 « REMISE À ZÉRO » (ÉTAPE 1, demande client) — état zéro du
// tableau de bord hôte : AUCUN appartement, AUCUN onboarding, aucune
// donnée métier. Toutes les anciennes rubriques ont été supprimées
// du shell. L'écran invite à démarrer la configuration d'un premier
// logement ; le circuit complet (onboarding par logement, check-in
// 90 s, check-out, PDF Bouclier) sera reconstruit à l'étape 2 sur la
// spec client A→Z.
// =============================================================

const RESET_POINTS: readonly string[] = [
  'Aucun appartement enregistré',
  'Aucun onboarding effectué',
  'Aucune donnée résiduelle (séjours, photos, QR, PDF)',
] as const;

export function ZeroStateDashboard() {
  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col items-center py-6 sm:py-10">
      <section
        aria-labelledby="zero-state-title"
        className="w-full rounded-3xl border border-slate-100 bg-white p-7 text-center shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] dark:border-white/10 dark:bg-[#0B1526] sm:p-10"
      >
        {/* Icône principale — carré dégradé bleu, cohérence shell « AZUR » */}
        <span
          aria-hidden="true"
          className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] shadow-lg shadow-blue-500/25"
        >
          <Home className="h-8 w-8 text-white" />
        </span>

        {/* Pastille d'état */}
        <p className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.18em] text-blue-700 dark:bg-blue-500/10 dark:text-blue-300">
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          Remise à zéro — Étape 1
        </p>

        <h1
          id="zero-state-title"
          className="mt-4 text-2xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-3xl"
        >
          Aucun appartement configuré
        </h1>

        <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-slate-500 dark:text-slate-400 sm:text-base">
          Le tableau de bord a été entièrement réinitialisé : appartements, onboarding,
          séjours, états des lieux, photos et vidéos ont été supprimés. On reprend
          à zéro, sur une base propre.
        </p>

        {/* Points de contrôle du reset */}
        <ul className="mx-auto mt-6 flex max-w-lg flex-col items-start gap-2 sm:flex-row sm:flex-wrap sm:justify-center sm:gap-2.5">
          {RESET_POINTS.map((point) => (
            <li
              key={point}
              className="inline-flex w-full items-center gap-2 rounded-xl border border-slate-100 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-300 sm:w-auto"
            >
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" aria-hidden="true" />
              {point}
            </li>
          ))}
        </ul>

        {/* CTA principal — dégradé bleu = action principale (convention shell) */}
        <Link
          href="/airbnb/properties?new=1"
          className="mt-8 inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-6 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50"
        >
          Créer mon premier logement
          <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>

        <p className="mx-auto mt-5 max-w-md text-xs leading-relaxed text-slate-400 dark:text-slate-500">
          Le nouveau circuit complet (type de logement, équipements, bibliothèque
          photo de référence, check-in 90&nbsp;s avec vidéo 30&nbsp;s, check-out et
          PDF comparatif) sera reconstruit à l&apos;étape&nbsp;2.
        </p>
      </section>

      <p className="mt-6 text-center text-xs text-slate-400 dark:text-slate-500">
        RoomScan v4.135 — Espace Hôte réinitialisé · Vos comptes restent inchangés
      </p>
    </div>
  );
}
