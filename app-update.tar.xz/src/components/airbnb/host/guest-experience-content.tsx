'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import {
  ArrowDown,
  ArrowUp,
  ChevronDown,
  GripVertical,
  Loader2,
  Plus,
  Trash2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { isLocalMediaUrl } from '@/lib/concierge';

// =============================================================
// PREMIUM « CONCIERGERIE 5 ÉTOILES » (V5) — ÉDITEUR CÔTÉ HÔTE
// Page /airbnb/properties/[id]/guest-experience : 4 sections qui
// alimentent les modules premium du Hub Invité, sauvegardées via
// PATCH /api/airbnb/properties/[id]/premium :
//   🎬 Vidéo de bienvenue   → premiumFeatures.videoWelcomeUrl
//   🖼️ Guide visuel pas à pas → visualGuide (upload + réordonnancement)
//   ⏱️ Services & upselling  → premiumFeatures (late check-out, bouclier d'avis)
//   🧰 Kit de survie        → survivalKitItems
// Design system du shell hôte : cartes blanches rounded-2xl,
// accent #E23F2B, toasts sonner, barre d'enregistrement sticky.
// =============================================================

// ── Types locaux (brouillons éditables — strings pour la saisie) ──

interface DraftStep {
  key: string;
  title: string;
  description: string;
  imageUrl: string;
}

interface DraftKitItem {
  key: string;
  name: string;
  location: string;
}

interface DraftMinibarItem {
  key: string;
  emoji: string;
  name: string;
  price: string;
}

interface PremiumDraft {
  videoUrl: string;
  enableLateCheckout: boolean;
  lateCheckoutPrice: string;
  /** v4.44 — heure de fin du départ tardif (12–18 h, défaut 14). */
  lateCheckoutHour: string;
  enableReviewShield: boolean;
  reviewUrl: string;
  /** v4.44 « MINIBAR NUMÉRIQUE » (Honesty Bar). */
  enableMinibar: boolean;
  minibar: DraftMinibarItem[];
  steps: DraftStep[];
  kit: DraftKitItem[];
}

interface PremiumGetResponse {
  properties: { id: string; name: string }[];
  property: { id: string; name: string; qrHubSlug: string | null } | null;
  premium: {
    premiumFeatures: Record<string, unknown> | null;
    /** v4.44 — minibar parsé ({ enabled, items }). */
    minibar?: { enabled: boolean; items: { id: string; emoji: string; name: string; price: number }[] };
    visualGuide: { id: string; title: string; description?: string; imageUrl?: string }[];
    survivalKitItems: { id: string; name: string; location?: string }[];
  } | null;
  error?: string;
}

const MAX_STEPS = 12;
const MAX_KIT_ITEMS = 30;
const MAX_MINIBAR_ITEMS = 20;

/** v4.44 — catalogue d'exemple affiché quand le minibar est activé vide. */
const MINIBAR_SUGGESTIONS: { emoji: string; name: string; price: string }[] = [
  { emoji: '💧', name: 'Eau minérale 50 cl', price: '2' },
  { emoji: '🍺', name: 'Bière locale', price: '4' },
  { emoji: '🍷', name: 'Bouteille de vin', price: '12' },
  { emoji: '🥨', name: 'Paquet de chips / biscuits', price: '2.5' },
  { emoji: '🍫', name: 'Tablette de chocolat', price: '3.5' },
  { emoji: '🔌', name: 'Câble de recharge neuf', price: '12' },
];

const EMPTY_DRAFT: PremiumDraft = {
  videoUrl: '',
  enableLateCheckout: false,
  lateCheckoutPrice: '',
  lateCheckoutHour: '14',
  enableReviewShield: false,
  reviewUrl: '',
  enableMinibar: false,
  minibar: [],
  steps: [],
  kit: [],
};

function newRowKey(): string {
  try {
    return crypto.randomUUID().slice(0, 8);
  } catch {
    return Math.random().toString(36).slice(2, 10);
  }
}

/** "20" ou "20,5" → nombre (null si invalide). */
function parsePriceInput(raw: string): number | null {
  const n = Number(raw.trim().replace(',', '.'));
  return Number.isFinite(n) && n > 0 && n <= 1000 ? Math.round(n * 100) / 100 : null;
}

export function GuestExperienceContent({ initialPropertyId }: { initialPropertyId: string }) {
  const router = useRouter();
  const [data, setData] = useState<PremiumGetResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [propertyId, setPropertyId] = useState(initialPropertyId);

  const [draft, setDraft] = useState<PremiumDraft>({ ...EMPTY_DRAFT });
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);
  const [dragOverKey, setDragOverKey] = useState<string | null>(null);
  const dragIndex = useRef<number | null>(null);

  // ── Chargement ──
  const load = useCallback(async (pid: string) => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(pid)}/premium`);
      const json = (await res.json()) as PremiumGetResponse;
      if (!res.ok) {
        setError(json.error || 'Impossible de charger l’expérience invité.');
        setData(null);
        return;
      }
      setData(json);
      setPropertyId(json.property?.id ?? pid);
      setDraft(hydrateDraft(json));
      setDirty(false);
    } catch {
      setError('Connexion impossible. Réessayez.');
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (initialPropertyId) void load(initialPropertyId);
  }, [initialPropertyId, load]);

  const changeProperty = (pid: string) => {
    if (pid === propertyId) return;
    if (dirty && !window.confirm('Des modifications ne sont pas enregistrées — changer de bien ?')) return;
    router.push(`/airbnb/properties/${encodeURIComponent(pid)}/guest-experience`);
  };

  // ── Mise à jour du brouillon (marque « dirty » automatiquement) ──
  const update = (fn: (d: PremiumDraft) => PremiumDraft) => {
    setDraft(fn);
    setDirty(true);
  };

  const setPremium = (patch: Partial<Omit<PremiumDraft, 'steps' | 'kit'>>) =>
    update((d) => ({ ...d, ...patch }));

  // ── Étapes du guide visuel ──
  const setStep = (key: string, patch: Partial<DraftStep>) =>
    update((d) => ({ ...d, steps: d.steps.map((s) => (s.key === key ? { ...s, ...patch } : s)) }));

  const addStep = () =>
    update((d) => ({
      ...d,
      steps: [...d.steps, { key: newRowKey(), title: '', description: '', imageUrl: '' }],
    }));

  const removeStep = (key: string) =>
    update((d) => ({ ...d, steps: d.steps.filter((s) => s.key !== key) }));

  const moveStep = (from: number, to: number) => {
    if (to < 0 || to >= draft.steps.length || from === to) return;
    update((d) => {
      const arr = [...d.steps];
      const [moved] = arr.splice(from, 1);
      arr.splice(to, 0, moved);
      return { ...d, steps: arr };
    });
  };

  // ── Kit de survie ──
  const setKit = (key: string, patch: Partial<DraftKitItem>) =>
    update((d) => ({ ...d, kit: d.kit.map((k) => (k.key === key ? { ...k, ...patch } : k)) }));

  const addKit = () =>
    update((d) => ({ ...d, kit: [...d.kit, { key: newRowKey(), name: '', location: '' }] }));

  const removeKit = (key: string) =>
    update((d) => ({ ...d, kit: d.kit.filter((k) => k.key !== key) }));

  // ── v4.44 — Minibar (Honesty Bar) ──
  const setMb = (key: string, patch: Partial<DraftMinibarItem>) =>
    update((d) => ({
      ...d,
      minibar: d.minibar.map((m) => (m.key === key ? { ...m, ...patch } : m)),
    }));

  const addMb = () =>
    update((d) => ({
      ...d,
      minibar: [...d.minibar, { key: newRowKey(), emoji: '🍷', name: '', price: '' }],
    }));

  const addMbSuggestion = (s: { emoji: string; name: string; price: string }) =>
    update((d) => ({
      ...d,
      minibar: [...d.minibar, { key: newRowKey(), emoji: s.emoji, name: s.name, price: s.price }],
    }));

  const removeMb = (key: string) =>
    update((d) => ({ ...d, minibar: d.minibar.filter((m) => m.key !== key) }));

  // ── Upload photo d'une étape (clic ou glisser-déposer) ──
  const uploadImage = async (rowKey: string, file: File) => {
    if (!propertyId) return;
    setUploadingKey(rowKey);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch(`/api/airbnb/concierge/upload?propertyId=${encodeURIComponent(propertyId)}`, {
        method: 'POST',
        body: fd,
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; url?: string; error?: string } | null;
      if (!res.ok || !json?.ok || !json.url) {
        toast.error(json?.error || 'Upload impossible.');
        return;
      }
      setStep(rowKey, { imageUrl: json.url });
      toast.success('📷 Photo ajoutée.');
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setUploadingKey(null);
    }
  };

  const pickImage = (rowKey: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp,image/gif';
    input.onchange = () => {
      const f = input.files?.[0];
      if (f) void uploadImage(rowKey, f);
    };
    input.click();
  };

  // ── Enregistrement — validation client (miroir de l'API) + PATCH ──
  const save = async () => {
    if (!propertyId) return;

    // 1. Options premium
    const videoUrl = draft.videoUrl.trim();
    if (videoUrl && !/^https?:\/\//.test(videoUrl) && !videoUrl.startsWith('/')) {
      toast.error('Collez un lien vidéo public (YouTube, Vimeo ou Loom) commençant par https://.');
      return;
    }
    const price = parsePriceInput(draft.lateCheckoutPrice);
    if (draft.enableLateCheckout && price === null) {
      toast.error('Indiquez le prix du late check-out (entre 1 et 1000 €).');
      return;
    }
    const lateHour = Number(draft.lateCheckoutHour);
    if (draft.enableLateCheckout && (!Number.isFinite(lateHour) || lateHour < 12 || lateHour > 18)) {
      toast.error('Heure de départ tardif invalide (entre 12 et 18 h).');
      return;
    }
    const reviewUrl = draft.reviewUrl.trim();
    if (draft.enableReviewShield && !/^https?:\/\//.test(reviewUrl)) {
      toast.error('Collez le lien de votre annonce (https://…) pour le bouclier d’avis.');
      return;
    }
    // v4.44 — minibar : nom + prix obligatoires (prix recalculé serveur).
    const minibarPayload: Record<string, unknown>[] = [];
    for (const m of draft.minibar) {
      const name = m.name.trim();
      const emoji = m.emoji.trim();
      const p = parsePriceInput(m.price);
      if (!name && !p) continue;
      if (!name || p === null) {
        toast.error('Chaque article du minibar doit avoir un nom et un prix (0,50 à 500 €).');
        return;
      }
      minibarPayload.push({ id: m.key, name, price: p, ...(emoji ? { emoji } : {}) });
    }
    if (draft.enableMinibar && minibarPayload.length === 0) {
      toast.error('Ajoutez au moins un article au minibar (ou désactivez-le).');
      return;
    }
    const premiumFeatures =
      videoUrl || draft.enableLateCheckout || draft.enableReviewShield || draft.enableMinibar
        ? {
            ...(videoUrl ? { videoWelcomeUrl: videoUrl } : {}),
            ...(draft.enableLateCheckout
              ? { enableLateCheckout: true, lateCheckoutPrice: price, lateCheckoutHour: Math.round(lateHour) }
              : {}),
            ...(draft.enableReviewShield ? { enableReviewShield: true, reviewUrl } : {}),
            ...(draft.enableMinibar ? { enableMinibar: true } : {}),
          }
        : null;

    // 2. Guide visuel — lignes vides ignorées, titre obligatoire
    const stepsPayload: Record<string, unknown>[] = [];
    for (const s of draft.steps) {
      const title = s.title.trim();
      const description = s.description.trim();
      const imageUrl = s.imageUrl.trim();
      if (!title && !description && !imageUrl) continue;
      if (!title) {
        toast.error('Chaque étape du guide visuel doit avoir un titre (ex : « La façade »).');
        return;
      }
      stepsPayload.push({
        id: s.key,
        title,
        ...(description ? { description } : {}),
        ...(imageUrl ? { imageUrl } : {}),
      });
    }

    // 3. Kit de survie — lignes vides ignorées, nom obligatoire
    const kitPayload: Record<string, unknown>[] = [];
    for (const k of draft.kit) {
      const name = k.name.trim();
      const location = k.location.trim();
      if (!name && !location) continue;
      if (!name) {
        toast.error('Chaque objet du kit de survie doit avoir un nom.');
        return;
      }
      kitPayload.push({ id: k.key, name, ...(location ? { location } : {}) });
    }

    setSaving(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${encodeURIComponent(propertyId)}/premium`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          premiumFeatures,
          minibarItems: draft.enableMinibar ? minibarPayload : null,
          visualGuide: stepsPayload,
          survivalKitItems: kitPayload,
        }),
      });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: string } | null;
      if (!res.ok || !json?.ok) {
        toast.error(json?.error || 'Enregistrement impossible.');
        return;
      }
      setDirty(false);
      toast.success('✨ Expérience invité enregistrée — visible dans l’app de vos invités !');
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setSaving(false);
    }
  };

  // ── Compteurs ──
  const stepsCount = draft.steps.filter((s) => s.title.trim() || s.imageUrl.trim()).length;
  const kitCount = draft.kit.filter((k) => k.name.trim()).length;
  const premiumCount = [draft.videoUrl.trim(), draft.enableLateCheckout, draft.enableReviewShield, draft.enableMinibar].filter(Boolean).length;

  const previewHref = data?.property?.qrHubSlug ? `/app/hub/${data.property.qrHubSlug}/guest` : null;

  return (
    <div className="max-w-4xl mx-auto w-full px-4 py-8">
      {/* ----- En-tête + switch propriété + aperçu ----- */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold text-slate-900">✨ Expérience Invité</h1>
          <p className="text-sm text-slate-500 mt-1">
            Vidéo de bienvenue, arrivée guidée en photos, upselling et kit de survie — l’expérience 5 étoiles, dans l’app de vos invités.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {data && data.properties.length > 0 && (
            <Select value={data.property?.id ?? ''} onValueChange={changeProperty}>
              <SelectTrigger className="w-full sm:w-56 bg-white" aria-label="Choisir le bien">
                <SelectValue placeholder="Choisir un bien" />
              </SelectTrigger>
              <SelectContent>
                {data.properties.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {previewHref && (
            <a
              href={previewHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
              title="Ouvrir l’app de vos invités dans un nouvel onglet"
            >
              👁️ Aperçu
            </a>
          )}
        </div>
      </div>

      {loading && !data && <LoadingSkeleton />}

      {!loading && error && (
        <div className="mt-6 bg-white border border-slate-200 rounded-2xl p-8 text-center" role="alert">
          <p className="text-3xl" aria-hidden="true">🔌</p>
          <p className="mt-2 text-sm text-slate-600">{error}</p>
          <Button className="mt-4" onClick={() => void load(propertyId || initialPropertyId)}>
            Réessayer
          </Button>
        </div>
      )}

      {!loading && data && data.property && (
        <>
          {/* ═══════════ 🎬 VIDÉO DE BIENVENUE ═══════════ */}
          <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-label="Vidéo de bienvenue">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
                  🎬 Vidéo de bienvenue
                  <CountBadge n={premiumCount} />
                </h2>
                <p className="mt-0.5 text-sm text-slate-500">
                  « Un mot de votre hôte » — la carte s’affiche en tête de l’accueil de vos invités.
                </p>
              </div>
            </div>
            <div className="mt-4 flex flex-col gap-1.5">
              <Label htmlFor="premium-video" className="text-xs font-semibold text-slate-600">
                Collez un lien YouTube, Vimeo ou Loom (public)
              </Label>
              <Input
                id="premium-video"
                value={draft.videoUrl}
                onChange={(e) => setPremium({ videoUrl: e.target.value })}
                maxLength={500}
                placeholder="https://youtube.com/watch?v=…"
                autoComplete="off"
              />
            </div>
            {draft.videoUrl.trim() && (
              <VideoPreview url={draft.videoUrl.trim()} />
            )}
            <p className="mt-2 text-xs text-slate-400">
              💡 Astuce : une vidéo de 60–90 s suffit. Collez un lien PUBLIC (YouTube, Vimeo ou Loom) :
              il s’ouvre dans un lecteur dédié côté invité. Aucun fichier à téléverser.
            </p>
          </section>

          {/* ═══════════ 🖼️ GUIDE VISUEL PAS À PAS ═══════════ */}
          <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-label="Guide visuel d’arrivée">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
                  🖼️ Guide visuel d’arrivée
                  <CountBadge n={stepsCount} />
                </h2>
                <p className="mt-0.5 text-sm text-slate-500">
                  Pas à pas en photos : façade → digicode → porte… Fin des « C’est laquelle la porte ? ».
                </p>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={addStep} disabled={draft.steps.length >= MAX_STEPS}>
                <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une étape
              </Button>
            </div>

            {draft.steps.length === 0 ? (
              <div className="mt-4 rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center">
                <p className="text-3xl" aria-hidden="true">🚪</p>
                <p className="mx-auto mt-2 max-w-sm text-sm text-slate-500">
                  Aucune étape. Ajoutez la façade, le digicode, la porte, l’ascenseur… dans l’ordre réel de l’arrivée.
                </p>
                <Button variant="outline" size="sm" className="mt-3 gap-1.5" onClick={addStep}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une étape
                </Button>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                {draft.steps.map((s, i) => (
                  <div
                    key={s.key}
                    draggable
                    onDragStart={() => {
                      dragIndex.current = i;
                    }}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      if (dragIndex.current !== null) moveStep(dragIndex.current, i);
                      dragIndex.current = null;
                    }}
                    onDragEnd={() => {
                      dragIndex.current = null;
                    }}
                    className="rounded-2xl border border-slate-200 bg-slate-50/60 p-4"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="hidden cursor-grab text-slate-300 hover:text-slate-500 sm:block"
                        title="Glisser pour réordonner"
                        aria-hidden="true"
                      >
                        <GripVertical className="h-5 w-5" />
                      </span>
                      <span className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[#FEF1EF] text-sm font-bold text-[#E23F2B]" aria-hidden="true">
                        {i + 1}
                      </span>
                      <Input
                        value={s.title}
                        onChange={(e) => setStep(s.key, { title: e.target.value })}
                        maxLength={80}
                        className="flex-1"
                        placeholder={`Titre de l’étape ${i + 1} (ex : « La façade »)`}
                        aria-label={`Titre de l’étape ${i + 1}`}
                      />
                      <div className="flex shrink-0 flex-col gap-0.5">
                        <button
                          type="button"
                          className="rounded p-0.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 disabled:opacity-30"
                          onClick={() => moveStep(i, i - 1)}
                          disabled={i === 0}
                          aria-label={`Monter l’étape ${i + 1}`}
                        >
                          <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                        <button
                          type="button"
                          className="rounded p-0.5 text-slate-400 hover:bg-slate-200 hover:text-slate-700 disabled:opacity-30"
                          onClick={() => moveStep(i, i + 1)}
                          disabled={i === draft.steps.length - 1}
                          aria-label={`Descendre l’étape ${i + 1}`}
                        >
                          <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      </div>
                      <DeleteRowButton onClick={() => removeStep(s.key)} label={`Supprimer l’étape ${s.title || i + 1}`} />
                    </div>
                    <div className="mt-3 grid gap-3 sm:grid-cols-[auto_1fr]">
                      {/* Zone photo — glisser-déposer ou clic */}
                      {s.imageUrl ? (
                        <div className="flex flex-col gap-1.5">
                          <img
                            src={s.imageUrl}
                            alt={`Photo de l’étape ${s.title || i + 1}`}
                            className="h-28 w-44 rounded-xl border border-slate-200 object-cover"
                            loading="lazy"
                            decoding="async"
                          />
                          <Button variant="outline" size="sm" onClick={() => setStep(s.key, { imageUrl: '' })}>
                            Retirer la photo
                          </Button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onDragOver={(e) => {
                            e.preventDefault();
                            setDragOverKey(s.key);
                          }}
                          onDragLeave={() => setDragOverKey(null)}
                          onDrop={(e) => {
                            e.preventDefault();
                            setDragOverKey(null);
                            const f = e.dataTransfer.files?.[0];
                            if (f) void uploadImage(s.key, f);
                          }}
                          onClick={() => pickImage(s.key)}
                          disabled={uploadingKey === s.key}
                          className={`flex h-28 w-44 shrink-0 flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed text-center text-xs transition-colors ${
                            dragOverKey === s.key
                              ? 'border-[#E23F2B] bg-[#FEF1EF] text-[#E23F2B]'
                              : 'border-slate-300 bg-white text-slate-500 hover:border-slate-400 hover:bg-slate-50'
                          }`}
                          aria-label={`Ajouter la photo de l’étape ${s.title || i + 1} (glisser-déposer ou cliquer)`}
                        >
                          {uploadingKey === s.key ? (
                            <Loader2 className="h-5 w-5 animate-spin" aria-hidden="true" />
                          ) : (
                            <>
                              <span className="text-xl" aria-hidden="true">📷</span>
                              <span className="px-2 font-semibold">Glissez une photo ou cliquez</span>
                            </>
                          )}
                        </button>
                      )}
                      <div className="flex flex-col gap-2">
                        <div className="flex flex-col gap-1.5">
                          <Label className="text-xs font-semibold text-slate-600">📝 Texte court pour l’invité</Label>
                          <Textarea
                            value={s.description}
                            onChange={(e) => setStep(s.key, { description: e.target.value })}
                            maxLength={280}
                            rows={3}
                            placeholder="ex : Immeuble bleu avec la porte verte — le digicode est à droite."
                            aria-label={`Description de l’étape ${s.title || i + 1}`}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                <Button variant="outline" size="sm" className="gap-1.5" onClick={addStep} disabled={draft.steps.length >= MAX_STEPS}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une étape
                </Button>
              </div>
            )}
          </section>

          {/* ═══════════ ⏱️ SERVICES & UPSELLING ═══════════ */}
          <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-label="Services et upselling">
            <h2 className="text-base font-bold text-slate-900">⏱️ Services &amp; Upselling</h2>
            <p className="mt-0.5 text-sm text-slate-500">
              Transformez l’app en source de revenus — et protégez votre note en cas de couac.
            </p>

            <div className="mt-4 space-y-4">
              {/* Late check-out */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <Label htmlFor="toggle-late" className="text-sm font-semibold text-slate-800">
                      ⏱️ Late Check-out payant
                    </Label>
                    <p className="mt-0.5 text-xs text-slate-500">
                      L’invité voit une carte « Prolonger votre séjour ? » sur son accueil.
                    </p>
                  </div>
                  <Switch
                    id="toggle-late"
                    checked={draft.enableLateCheckout}
                    onCheckedChange={(v) => setPremium({ enableLateCheckout: v })}
                    aria-label="Activer le late check-out payant"
                  />
                </div>
                {draft.enableLateCheckout && (
                  <div className="mt-3 flex flex-wrap items-end gap-3">
                    <div className="flex flex-col gap-1.5">
                      <Label htmlFor="late-price" className="text-xs font-semibold text-slate-600">
                        Prix (€)
                      </Label>
                      <Input
                        id="late-price"
                        value={draft.lateCheckoutPrice}
                        onChange={(e) => setPremium({ lateCheckoutPrice: e.target.value })}
                        inputMode="decimal"
                        maxLength={7}
                        className="w-28"
                        placeholder="20"
                        aria-label="Prix du late check-out en euros"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <Label htmlFor="late-hour" className="text-xs font-semibold text-slate-600">
                        Départ jusqu’à
                      </Label>
                      <Select
                        value={draft.lateCheckoutHour}
                        onValueChange={(v) => setPremium({ lateCheckoutHour: v })}
                      >
                        <SelectTrigger id="late-hour" className="w-24 bg-white" aria-label="Heure de fin du départ tardif">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[12, 13, 14, 15, 16, 17, 18].map((h) => (
                            <SelectItem key={h} value={String(h)}>
                              {h} h
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
                {draft.enableLateCheckout && (
                  <p className="mt-2 rounded-xl bg-emerald-50 px-3 py-2 text-xs leading-relaxed text-emerald-800">
                    ✅ <strong>Automatisation v4.44 :</strong> le serveur vérifie votre calendrier — si le logement est libre le jour du départ, l’invité voit « Prolongez jusqu’à {draft.lateCheckoutHour} h pour {draft.lateCheckoutPrice || '…'} € » ; s’il est déjà loué, le départ tardif est automatiquement indisponible.
                  </p>
                )}
              </div>

              {/* Bouclier d'avis */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <Label htmlFor="toggle-shield" className="text-sm font-semibold text-slate-800">
                      ⭐ Bouclier d’avis (Review Shield)
                    </Label>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Invités ravis → guidés vers votre annonce. Invités déçus → message privé d’abord.
                    </p>
                  </div>
                  <Switch
                    id="toggle-shield"
                    checked={draft.enableReviewShield}
                    onCheckedChange={(v) => setPremium({ enableReviewShield: v })}
                    aria-label="Activer le bouclier d’avis"
                  />
                </div>
                {draft.enableReviewShield && (
                  <div className="mt-3 flex flex-col gap-1.5">
                    <Label htmlFor="review-url" className="text-xs font-semibold text-slate-600">
                      Lien de votre annonce (Airbnb, Booking…)
                    </Label>
                    <Input
                      id="review-url"
                      value={draft.reviewUrl}
                      onChange={(e) => setPremium({ reviewUrl: e.target.value })}
                      maxLength={500}
                      placeholder="https://www.airbnb.com/rooms/…"
                      autoComplete="off"
                      aria-label="Lien de l’annonce pour le bouclier d’avis"
                    />
                  </div>
                )}
              </div>
              {/* v4.44 — Minibar numérique (Honesty Bar) */}
              <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <Label htmlFor="toggle-minibar" className="text-sm font-semibold text-slate-800">
                      🍷 Minibar numérique (Honesty Bar)
                    </Label>
                    <p className="mt-0.5 text-xs text-slate-500">
                      Snacks, vin, bières locales, câbles neufs… L’invité coche sa consommation et paie (CB / Apple Pay) ou règle sur place.
                    </p>
                  </div>
                  <Switch
                    id="toggle-minibar"
                    checked={draft.enableMinibar}
                    onCheckedChange={(v) => setPremium({ enableMinibar: v })}
                    aria-label="Activer le minibar numérique"
                  />
                </div>
                {draft.enableMinibar && (
                  <div className="mt-3">
                    {draft.minibar.length === 0 && (
                      <div className="rounded-xl border border-dashed border-slate-300 p-3">
                        <p className="text-xs text-slate-500">
                          Ajoutez vos articles (ou partez d’une suggestion) — prix recalculés côté serveur à chaque commande.
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {MINIBAR_SUGGESTIONS.map((s) => (
                            <button
                              key={s.name}
                              type="button"
                              onClick={() => addMbSuggestion(s)}
                              disabled={draft.minibar.length >= MAX_MINIBAR_ITEMS}
                              className="inline-flex items-center gap-1 rounded-full border border-slate-300 bg-white px-2.5 py-1 text-[11px] font-semibold text-slate-600 transition-colors hover:bg-slate-100 disabled:opacity-50"
                            >
                              {s.emoji} {s.name} · {s.price} €
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="mt-2 space-y-2">
                      {draft.minibar.map((m, i) => (
                        <div key={m.key} className="flex items-center gap-2">
                          <Input
                            value={m.emoji}
                            onChange={(e) => setMb(m.key, { emoji: e.target.value })}
                            maxLength={4}
                            className="w-14 text-center"
                            placeholder="🍷"
                            aria-label={`Emoji de l’article ${m.name || i + 1}`}
                          />
                          <Input
                            value={m.name}
                            onChange={(e) => setMb(m.key, { name: e.target.value })}
                            maxLength={60}
                            className="flex-1"
                            placeholder="Article (ex : Bière locale)"
                            aria-label={`Nom de l’article ${i + 1}`}
                          />
                          <Input
                            value={m.price}
                            onChange={(e) => setMb(m.key, { price: e.target.value })}
                            inputMode="decimal"
                            maxLength={7}
                            className="w-20"
                            placeholder="€"
                            aria-label={`Prix de l’article ${m.name || i + 1}`}
                          />
                          <DeleteRowButton onClick={() => removeMb(m.key)} label={`Supprimer l’article ${m.name || i + 1}`} />
                        </div>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-2 gap-1.5"
                      onClick={addMb}
                      disabled={draft.minibar.length >= MAX_MINIBAR_ITEMS}
                    >
                      <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter un article
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* ═══════════ 🧰 KIT DE SURVIE ═══════════ */}
          <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm" aria-label="Kit de survie">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <h2 className="flex items-center gap-2 text-base font-bold text-slate-900">
                  🧰 Kit de survie
                  <CountBadge n={kitCount} />
                </h2>
                <p className="mt-0.5 text-sm text-slate-500">
                  Les objets qu’on oublie toujours — et leur emplacement exact dans le logement.
                </p>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={addKit} disabled={draft.kit.length >= MAX_KIT_ITEMS}>
                <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter
              </Button>
            </div>

            {draft.kit.length === 0 ? (
              <div className="mt-4 rounded-2xl border-2 border-dashed border-slate-200 p-8 text-center">
                <p className="text-3xl" aria-hidden="true">🔋</p>
                <p className="mx-auto mt-2 max-w-sm text-sm text-slate-500">
                  Chargeur iPhone, adaptateur, parapluie… Listez-les avec leur emplacement — fin des appels paniques à 23 h.
                </p>
                <Button variant="outline" size="sm" className="mt-3 gap-1.5" onClick={addKit}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter un objet
                </Button>
              </div>
            ) : (
              <div className="mt-4 space-y-2.5">
                {draft.kit.map((k, i) => (
                  <div key={k.key} className="flex flex-col gap-2 rounded-xl border border-slate-200 bg-slate-50/60 p-3 sm:flex-row sm:items-center">
                    <Input
                      value={k.name}
                      onChange={(e) => setKit(k.key, { name: e.target.value })}
                      maxLength={60}
                      className="sm:w-56"
                      placeholder="Objet (ex : Chargeur iPhone)"
                      aria-label={`Nom de l’objet ${i + 1}`}
                    />
                    <Input
                      value={k.location}
                      onChange={(e) => setKit(k.key, { location: e.target.value })}
                      maxLength={120}
                      className="flex-1"
                      placeholder="Emplacement (ex : Tiroir de la cuisine, sous le micro-ondes)"
                      aria-label={`Emplacement de l’objet ${k.name || i + 1}`}
                    />
                    <DeleteRowButton onClick={() => removeKit(k.key)} label={`Supprimer l’objet ${k.name || i + 1}`} />
                  </div>
                ))}
                <Button variant="outline" size="sm" className="gap-1.5" onClick={addKit} disabled={draft.kit.length >= MAX_KIT_ITEMS}>
                  <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter un objet
                </Button>
              </div>
            )}
          </section>

          {/* ----- Barre d'enregistrement sticky ----- */}
          <div className="sticky bottom-4 z-30 mt-6 flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-lg backdrop-blur">
            <p className="text-sm text-slate-600" aria-live="polite">
              {dirty ? '✍️ Modifications non enregistrées' : '✓ Tout est à jour'}
            </p>
            <Button
              onClick={() => void save()}
              disabled={saving || loading || !propertyId}
              className="gap-2 bg-[#E23F2B] font-bold text-white hover:bg-[#c93623]"
              aria-label="Enregistrer l’expérience invité"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />}
              💾 Enregistrer
            </Button>
          </div>
        </>
      )}

      {!loading && data && !data.property && (
        <div className="mt-6 bg-white border border-slate-200 rounded-2xl p-10 text-center">
          <p className="text-4xl" aria-hidden="true">✨</p>
          <h2 className="mt-3 text-lg font-bold text-slate-900">Aucun bien</h2>
          <p className="mt-1 text-sm text-slate-500">Ajoutez d’abord un bien pour créer son expérience invité.</p>
        </div>
      )}
    </div>
  );
}

// =============================================================
// Helpers de rendu
// =============================================================

/** Aperçu de la vidéo : lecteur local (<video>) ou carte lien (CSP-safe). */
function VideoPreview({ url }: { url: string }) {
  if (isLocalMediaUrl(url)) {
    return (
      <video
        src={url}
        controls
        muted
        playsInline
        preload="metadata"
        className="mt-3 aspect-video w-full max-w-md rounded-xl border border-slate-200 bg-black"
        aria-label="Aperçu de la vidéo de bienvenue"
      />
    );
  }
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="mt-3 flex max-w-md items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 p-3 transition-colors hover:bg-slate-100"
      title="Prévisualiser la vidéo dans un nouvel onglet"
    >
      <span className="text-2xl" aria-hidden="true">🎬</span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-semibold text-slate-800">{url}</span>
        <span className="block text-xs text-slate-500">Cliquez pour prévisualiser — l’invité la verra en tête d’accueil</span>
      </span>
      <ChevronDown className="h-4 w-4 -rotate-90 shrink-0 text-slate-400" aria-hidden="true" />
    </a>
  );
}

function hydrateDraft(json: PremiumGetResponse): PremiumDraft {
  const pf = (json.premium?.premiumFeatures ?? {}) as Record<string, unknown>;
  const str = (v: unknown): string => (typeof v === 'string' ? v : '');
  const num = (v: unknown): string => (typeof v === 'number' && Number.isFinite(v) ? String(v) : '');
  const bool = (v: unknown): boolean => v === true;

  return {
    videoUrl: str(pf.videoWelcomeUrl),
    enableLateCheckout: bool(pf.enableLateCheckout),
    lateCheckoutPrice: num(pf.lateCheckoutPrice),
    // v4.44 — heure de fin du départ tardif (12–18, défaut 14).
    lateCheckoutHour:
      typeof pf.lateCheckoutHour === 'number' &&
      Number.isFinite(pf.lateCheckoutHour) &&
      pf.lateCheckoutHour >= 12 &&
      pf.lateCheckoutHour <= 18
        ? String(Math.round(pf.lateCheckoutHour))
        : '14',
    enableReviewShield: bool(pf.enableReviewShield),
    reviewUrl: str(pf.reviewUrl),
    // v4.44 — minibar (items parsés côté serveur).
    enableMinibar: bool(pf.enableMinibar) || json.premium?.minibar?.enabled === true,
    minibar: (json.premium?.minibar?.items ?? []).map((m) => ({
      key: m.id || newRowKey(),
      emoji: m.emoji ?? '🍷',
      name: m.name ?? '',
      price: typeof m.price === 'number' && Number.isFinite(m.price) ? String(m.price) : '',
    })),
    steps: (json.premium?.visualGuide ?? []).map((s) => ({
      key: s.id || newRowKey(),
      title: s.title ?? '',
      description: s.description ?? '',
      imageUrl: s.imageUrl ?? '',
    })),
    kit: (json.premium?.survivalKitItems ?? []).map((k) => ({
      key: k.id || newRowKey(),
      name: k.name ?? '',
      location: k.location ?? '',
    })),
  };
}

function CountBadge({ n }: { n: number }) {
  if (n <= 0) return null;
  return (
    <span className="ml-0.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-emerald-100 px-1 text-[10px] font-bold text-emerald-700">
      {n}
    </span>
  );
}

function DeleteRowButton({ onClick, label }: { onClick: () => void; label: string }) {
  return (
    <Button
      variant="ghost"
      size="icon"
      className="shrink-0 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
      onClick={onClick}
      aria-label={label}
      title={label}
    >
      <Trash2 className="h-4 w-4" aria-hidden="true" />
    </Button>
  );
}

function LoadingSkeleton() {
  return (
    <div className="mt-6 space-y-4" aria-busy="true" aria-label="Chargement de l’expérience invité">
      <Skeleton className="h-12 w-full rounded-2xl" />
      <Skeleton className="h-48 w-full rounded-2xl" />
      <Skeleton className="h-32 w-full rounded-2xl" />
    </div>
  );
}
