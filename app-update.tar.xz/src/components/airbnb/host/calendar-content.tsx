'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { ContextualInsight } from '@/components/airbnb/host/contextual-insight';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';

// =============================================================
// CalendarContent — page « Calendrier » du Dashboard Client
//
// • Grille mensuelle (lun → dim) des réservations du bien sélectionné
//   • séjour en cours · arrivée du jour · départ du jour
//   • ménage à faire (checkout passé, cleaningStatus ≠ DONE)
// • Navigation mois + retour « Aujourd'hui » + clic sur un séjour →
//   fiche (ménage fait/à faire, annuler, supprimer selon les droits)
// • Création manuelle (POST bookings) et import iCal RÉEL
//   (GET/POST/DELETE /api/airbnb/ical, re-sync par feedId)
//
// v5.2 « SAPHIR LUXE » — refonte visuelle uniquement (zéro logique) :
// carte verre .lux-card, cellules nuit saphir, pastilles teintes
// sémantiques + point coloré, légende typographique, portails sombres
// bg-[#0b1226], boutons .lux-btn / .lux-btn-ghost / .lux-btn-gold.
// =============================================================

interface CalBooking {
  id: string;
  guestName: string;
  guestEmail: string | null;
  guestPhone: string | null;
  checkIn: string;
  checkOut: string;
  guests: number;
  source: string;
  status: string;
  cleaningStatus: string;
  notes: string | null;
  // v4.50 « VERROUILLAGE DU HUB PAR CODE » — code d'activation généré
  // automatiquement + prolongation de séjour validée par l'hôte.
  accessCode?: string | null;
  lateCheckOutUntil?: string | null;
}

interface IcalFeed {
  id: string;
  label: string;
  url: string;
  lastSyncAt: string | null;
  lastStatus: string | null;
  lastError: string | null;
  lastImported: number;
}

const DAY_LABELS = ['lun.', 'mar.', 'mer.', 'jeu.', 'ven.', 'sam.', 'dim.'];
const MS_DAY = 86_400_000;

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function sameDay(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}
/** Nuit (dates) — les check-in/check-out iCal sont des dates pures. */
function toDayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function fmtDayFr(d: Date): string {
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
}
function fmtDateTimeFr(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' });
}

// ── v4.83 « INFOS DE CONNEXION AU HUB » ─────────────────────────
// Après la création d'une résa (code d'accès généré), l'hôte choisit :
//   • OUI → envoyer DIRECTEMENT à l'invité (email enrichi via
//     /api/airbnb/bookings/send-hub-access : arrivée, départ, lien hub,
//     code d'accès, contact hôte) ;
//   • NON → COPIER le message complet (WhatsApp/SMS) dans le
//     presse-papier.
// Les heures sont rendues en UTC (= ce que l'hôte a SAISI, le serveur
// interprétant datetime-local en UTC) pour ne pas décaler le créneau.
function fmtUtcSlotLabel(iso: string): string {
  return new Date(iso).toLocaleString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'UTC',
  });
}

/** Message « infos de connexion » complet (copie WhatsApp/SMS). */
function hubConnectionText(opts: {
  propertyName: string;
  hubSlug: string | null;
  guestName: string;
  accessCode: string;
  checkInIso: string;
  checkOutIso: string;
}): string {
  const firstName = opts.guestName.trim().split(/\s+/)[0] || opts.guestName.trim();
  const hubUrl = opts.hubSlug
    ? `${window.location.origin}/hub/${opts.hubSlug}`
    : `${window.location.origin}/hub (lien du hub indisponible — vérifiez la plaque QR du bien)`;
  return [
    `🏡 ${opts.propertyName} — vos infos de connexion`,
    '',
    `Bonjour ${firstName} !`,
    '',
    `📲 Votre Hub de voyage : ${hubUrl}`,
    `🔐 Code d'accès : ${opts.accessCode}`,
    '',
    `📅 Arrivée : ${fmtUtcSlotLabel(opts.checkInIso)}`,
    `🧳 Départ : ${fmtUtcSlotLabel(opts.checkOutIso)}`,
    '',
    'Scannez le QR code de la plaque du logement (ou ouvrez le lien), puis saisissez le code. Le hub reste déverrouillé sur votre téléphone tout le séjour et se verrouille automatiquement au départ.',
    '',
    'À très vite !',
  ].join('\n');
}

/** Teintes sémantiques (nuit saphir) des pastilles d'événements — texte blanc. */
const EVT_STYLES: Record<'checkin' | 'checkout' | 'stay' | 'cleaning', string> = {
  stay: 'border-[#5c8af0]/30 bg-[#5c8af0]/15 hover:bg-[#5c8af0]/25',
  checkin: 'border-[#34d399]/30 bg-[#34d399]/12 hover:bg-[#34d399]/22',
  checkout: 'border-[#fbbf24]/30 bg-[#fbbf24]/12 hover:bg-[#fbbf24]/22',
  cleaning: 'border-[#cdb6ff]/30 bg-[#cdb6ff]/12 hover:bg-[#cdb6ff]/22',
};

/** Point coloré de chaque type d'événement (remplace les emojis). */
const EVT_DOT: Record<'checkin' | 'checkout' | 'stay' | 'cleaning', string> = {
  stay: '#5c8af0',
  checkin: '#34d399',
  checkout: '#fbbf24',
  cleaning: '#cdb6ff',
};

/** Légende typographique (points colorés cohérents avec les pastilles). */
const LEGEND = [
  { color: '#5c8af0', label: 'Séjour' },
  { color: '#34d399', label: 'Arrivée (check-in)' },
  { color: '#fbbf24', label: 'Départ (check-out)' },
  { color: '#cdb6ff', label: 'Ménage à faire' },
];

/** v5.2 — classes communes des champs de formulaire (portails sombres). */
const LUX_FIELD =
  'rounded-xl border-white/12 bg-white/[0.04] text-white placeholder:text-[#8fa0c2]/60 focus-visible:ring-[#5c8af0]/50';

export function CalendarContent() {
  const { properties, propertiesLoading, selectedId, selectedProperty } = useHostContext();

  // Le calendrier porte sur UN bien : si "toutes" → première propriété.
  const property = useMemo(() => {
    if (selectedProperty) return selectedProperty;
    return properties[0] ?? null;
  }, [selectedProperty, properties]);

  const [cursor, setCursor] = useState(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), 1);
  });
  const [bookings, setBookings] = useState<CalBooking[]>([]);
  const [myRole, setMyRole] = useState<string>('OWNER');
  const [canManage, setCanManage] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [selected, setSelected] = useState<CalBooking | null>(null);
  // v4.50 — valeur du champ « prolonger le verrouillage » (datetime-local).
  // Pré-remplie à l'ouverture de la fiche : checkOut à 15 h (départ tardif
  // type) — l'hôte ajuste puis valide.
  const [extensionValue, setExtensionValue] = useState('');
  // Pré-remplissage du champ prolongation à l'ouverture d'une fiche
  // (départ tardif type : checkOut à 15 h ; prolongation existante si déjà définie).
  useEffect(() => {
    if (!selected) return;
    const toLocal = (d: Date) => {
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };
    if (selected.lateCheckOutUntil) {
      setExtensionValue(toLocal(new Date(selected.lateCheckOutUntil)));
    } else {
      const co = new Date(selected.checkOut);
      co.setHours(15, 0, 0, 0);
      setExtensionValue(toLocal(co));
    }
  }, [selected]);
  const [actionBusy, setActionBusy] = useState(false);
  const [newOpen, setNewOpen] = useState(false);
  const [icalOpen, setIcalOpen] = useState(false);

  // ── v4.83 — envoi des infos de connexion depuis la fiche séjour ──
  // sentAccessTo : souvenir « déjà envoyé à <email> » par séjour (le
  // ✓ persiste tant que le dashboard est ouvert ; renvoyer est permis).
  const [sendAccessBusy, setSendAccessBusy] = useState(false);
  const [sentAccessTo, setSentAccessTo] = useState<Record<string, string>>({});
  const sendHubAccess = useCallback(async (bookingId: string) => {
    setSendAccessBusy(true);
    try {
      const res = await fetch('/api/airbnb/bookings/send-hub-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookingId }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        sentTo?: string;
      };
      if (!res.ok) throw new Error(json.error ?? 'Envoi refusé');
      if (json.sentTo) setSentAccessTo((m) => ({ ...m, [bookingId]: json.sentTo! }));
      toast.success(`Infos de connexion envoyées à ${json.sentTo ?? "l'invité"}`, {
        description: 'Lien du hub + code d’accès + arrivée/départ + votre contact.',
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setSendAccessBusy(false);
    }
  }, []);

  const requestId = useRef(0);

  const loadBookings = useCallback(async () => {
    if (!property) {
      setLoading(false);
      return;
    }
    const current = ++requestId.current;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/airbnb/properties/${property.id}/bookings?limit=200`, {
        cache: 'no-store',
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = (await res.json()) as { bookings: CalBooking[]; myRole: string; canManage: boolean };
      if (current !== requestId.current) return;
      setBookings(data.bookings ?? []);
      setMyRole(data.myRole ?? 'OWNER');
      setCanManage(data.canManage ?? false);
    } catch (err) {
      if (current !== requestId.current) return;
      console.error('[calendar] load failed:', err);
      setError('Impossible de charger le planning. Réessayez dans un instant.');
    } finally {
      if (current === requestId.current) setLoading(false);
    }
  }, [property]);

  useEffect(() => {
    void loadBookings();
  }, [loadBookings]);

  // ----- Grille du mois : lun-de mais 6 semaines complètes -----
  const gridDays = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const offset = (first.getDay() + 6) % 7; // lundi = 0
    const start = new Date(first.getTime() - offset * MS_DAY);
    return Array.from({ length: 42 }, (_, i) => new Date(start.getTime() + i * MS_DAY));
  }, [cursor]);

  /** Réservations actives chevauchant le mois affiché. */
  const monthBookings = useMemo(() => {
    const monthStart = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
    return bookings.filter((b) => {
      if (b.status === 'CANCELLED') return false;
      return new Date(b.checkOut) > monthStart && new Date(b.checkIn) < monthEnd;
    });
  }, [bookings, cursor]);

  const monthLabel = cursor.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  const today = startOfDay(new Date());
  const isCurrentMonth = cursor.getMonth() === today.getMonth() && cursor.getFullYear() === today.getFullYear();

  // ----- Événements d'un jour donné -----
  function eventsOfDay(day: Date) {
    const out: {
      booking: CalBooking;
      kind: 'checkin' | 'checkout' | 'stay' | 'cleaning';
    }[] = [];
    for (const b of monthBookings) {
      const ci = startOfDay(new Date(b.checkIn));
      const co = startOfDay(new Date(b.checkOut));
      if (sameDay(day, ci)) {
        out.push({ booking: b, kind: 'checkin' });
      } else if (sameDay(day, co)) {
        const cleaningDue = b.cleaningStatus !== 'DONE';
        out.push({ booking: b, kind: 'checkout' });
        if (cleaningDue && co <= today) {
          out.push({ booking: b, kind: 'cleaning' });
        }
      } else if (day > ci && day < co) {
        out.push({ booking: b, kind: 'stay' });
      }
    }
    return out.slice(0, 3); // max 3 pastilles/jour (volumétrie grille)
  }

  // ----- Actions sur une réservation -----
  async function patchBooking(id: string, data: Record<string, string>) {
    if (!property) return;
    setActionBusy(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${property.id}/bookings?bookingId=${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Modification refusée');
      toast.success('Réservation mise à jour');
      setSelected(null);
      await loadBookings();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setActionBusy(false);
    }
  }

  async function deleteBooking(id: string) {
    if (!property) return;
    setActionBusy(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${property.id}/bookings?bookingId=${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Suppression refusée');
      toast.success('Réservation supprimée');
      setSelected(null);
      await loadBookings();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setActionBusy(false);
    }
  }

  // ----- États vides -----
  if (!propertiesLoading && properties.length === 0) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="lux-empty max-w-md rounded-2xl p-8 text-center">
          <h1 className="lux-display text-xl font-semibold text-white">Aucun bien à afficher</h1>
          <p className="mt-2 text-sm text-[#8fa0c2]">
            Créez votre première propriété pour organiser votre planning.
          </p>
          <Link
            href="/airbnb/properties?new=1"
            className="lux-btn mt-5"
          >
            + Ajouter une propriété
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* ---------- En-tête ---------- */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="lux-eyebrow">Planning</p>
          <h1 className="lux-display mt-1.5 text-2xl font-semibold text-white sm:text-3xl">Calendrier</h1>
          <p className="mt-1 text-sm text-[#8fa0c2]">
            {property ? (
              <>Planning de <span className="font-semibold text-white">{property.name}</span> — {monthBookings.length} séjour(s) ce mois</>
            ) : (
              'Chargement du planning…'
            )}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            className="lux-btn-ghost h-9 px-4 text-xs"
            onClick={() => setIcalOpen(true)}
            aria-label="Synchroniser un calendrier iCal"
          >
            Synchroniser iCal
          </button>
          <button
            type="button"
            className="lux-btn h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-50"
            onClick={() => setNewOpen(true)}
            disabled={!canManage}
            aria-label="Nouvelle réservation"
            title={canManage ? undefined : "Réservé aux propriétaires et managers"}
          >
            Nouvelle réservation
          </button>
        </div>
      </div>

      {error && (
        <div className="lux-empty flex flex-col items-center gap-3 rounded-2xl p-6 text-center" role="alert">
          <span className="lux-dot" style={{ backgroundColor: '#f07d6a' }} aria-hidden="true" />
          <p className="text-sm font-semibold text-white">{error}</p>
          <button
            type="button"
            onClick={() => {
              void loadBookings();
            }}
            className="lux-btn-ghost mt-1 h-9 px-4 text-xs"
          >
            Réessayer
          </button>
        </div>
      )}

      {/* ---------- COACH ROOMSCAN — suggestions contextuelles (v5.4) ---------- */}
      <ContextualInsight context="/airbnb/calendar" />

      {/* ---------- Navigation mois + légende ---------- */}
      <div className="lux-card p-4 sm:p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-[#8fa0c2] transition-colors hover:bg-white/[0.06] hover:text-white"
              onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
              aria-label="Mois précédent"
            >
              <span aria-hidden="true" className="text-base leading-none">‹</span>
            </button>
            <span className="lux-display min-w-[150px] text-center text-lg font-semibold capitalize text-white" aria-live="polite">
              {monthLabel}
            </span>
            <button
              type="button"
              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-white/10 bg-white/[0.03] text-[#8fa0c2] transition-colors hover:bg-white/[0.06] hover:text-white"
              onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
              aria-label="Mois suivant"
            >
              <span aria-hidden="true" className="text-base leading-none">›</span>
            </button>
            {!isCurrentMonth && (
              <button
                type="button"
                className="ml-1 inline-flex h-8 items-center rounded-full px-3 text-xs font-semibold text-[#a9c4ff] transition-colors hover:bg-white/[0.06] hover:text-white"
                onClick={() => setCursor(new Date(today.getFullYear(), today.getMonth(), 1))}
              >
                Aujourd&apos;hui
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5" aria-label="Légende du calendrier">
            {LEGEND.map((l) => (
              <span key={l.label} className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[#8fa0c2]">
                <span aria-hidden="true" className="lux-dot" style={{ backgroundColor: l.color }} />
                {l.label}
              </span>
            ))}
          </div>
        </div>

        {/* ---------- Grille ---------- */}
        {loading || propertiesLoading ? (
          <Skeleton className="h-[560px] w-full rounded-2xl bg-white/[0.06]" aria-hidden="true" />
        ) : (
          <div className="overflow-x-auto">
            <div className="min-w-[640px]">
              <div className="grid grid-cols-7 border-b border-white/10 pb-2" role="row">
                {DAY_LABELS.map((d) => (
                  <div key={d} className="lux-eyebrow px-1 text-center">
                    {d}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-1.5 pt-2">
                {gridDays.map((day) => {
                  const inMonth = day.getMonth() === cursor.getMonth();
                  const isToday = sameDay(day, today);
                  const evts = eventsOfDay(day);
                  return (
                    <div
                      key={day.toISOString()}
                      className={cn(
                        'min-h-[88px] rounded-xl border p-1.5 transition-colors sm:min-h-[96px]',
                        inMonth
                          ? 'border-white/10 bg-white/[0.03] hover:bg-white/[0.05]'
                          : 'border-transparent bg-white/[0.015]',
                      )}
                      aria-label={`${day.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })} — ${evts.length} événement(s)`}
                    >
                      <div className="mb-1 flex items-center justify-between px-0.5">
                        <span
                          className={cn(
                            'lux-num inline-flex h-6 min-w-6 items-center justify-center rounded-full px-1 text-xs font-semibold',
                            isToday
                              ? 'bg-[#3d6fe0] text-white shadow'
                              : inMonth
                                ? 'text-white'
                                : 'text-[#8fa0c2]/50',
                          )}
                        >
                          {day.getDate()}
                        </span>
                        {evts.length > 2 && (
                          <span className="text-[10px] font-semibold text-[#8fa0c2]">+{evts.length - 2}</span>
                        )}
                      </div>
                      <div className="flex flex-col gap-1">
                        {evts.slice(0, 2).map((e) => (
                          <motion.button
                            key={`${e.booking.id}-${e.kind}`}
                            type="button"
                            whileHover={{ scale: 1.02 }}
                            onClick={() => setSelected(e.booking)}
                            className={cn(
                              'flex w-full items-center gap-1.5 truncate rounded-lg border px-1.5 py-0.5 text-left text-[10px] font-semibold leading-tight text-white sm:text-[11px]',
                              EVT_STYLES[e.kind],
                            )}
                            title={`${e.booking.guestName} — ${kindLabel(e.kind)} (${fmtDayFr(new Date(e.booking.checkIn))} → ${fmtDayFr(new Date(e.booking.checkOut))})`}
                          >
                            <span
                              aria-hidden="true"
                              className="h-1.5 w-1.5 shrink-0 rounded-full"
                              style={{ backgroundColor: EVT_DOT[e.kind] }}
                            />
                            <span className="truncate">{e.booking.guestName}</span>
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ---------- Fiche réservation ---------- */}
      {selected && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 sm:items-center" role="dialog" aria-modal="true" aria-label={`Réservation de ${selected.guestName}`}>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-md rounded-t-3xl border border-white/10 bg-[#0b1226] p-6 shadow-2xl sm:rounded-2xl"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="lux-display text-xl font-semibold text-white">{selected.guestName}</h2>
                <p className="mt-0.5 text-sm text-[#8fa0c2]">
                  {fmtDayFr(new Date(selected.checkIn))} → {fmtDayFr(new Date(selected.checkOut))} · {selected.guests} pers.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelected(null)}
                className="rounded-full p-1.5 text-[#8fa0c2] transition-colors hover:bg-white/[0.06] hover:text-white"
                aria-label="Fermer"
              >
                <span aria-hidden="true" className="text-lg leading-none">×</span>
              </button>
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                <dt className="lux-eyebrow !text-[9.5px]">Source</dt>
                <dd className="mt-1 font-semibold text-white">{sourceLabel(selected.source)}</dd>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                <dt className="lux-eyebrow !text-[9.5px]">Statut</dt>
                <dd className="mt-1 font-semibold text-white">{statusLabel(selected.status)}</dd>
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                <dt className="lux-eyebrow !text-[9.5px]">Ménage</dt>
                <dd className="mt-1 flex items-center gap-2 font-semibold text-white">
                  <span
                    className="lux-dot"
                    style={{
                      backgroundColor:
                        selected.cleaningStatus === 'DONE'
                          ? '#34d399'
                          : selected.cleaningStatus === 'IN_PROGRESS'
                            ? '#5c8af0'
                            : '#cdb6ff',
                    }}
                    aria-hidden="true"
                  />
                  {cleaningLabel(selected.cleaningStatus)}
                </dd>
              </div>
              {selected.guestEmail && (
                <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                  <dt className="lux-eyebrow !text-[9.5px]">Email</dt>
                  <dd className="mt-1 truncate font-medium text-white">{selected.guestEmail}</dd>
                </div>
              )}
              {selected.guestPhone && (
                <div className="rounded-xl border border-white/10 bg-white/[0.04] p-3">
                  <dt className="lux-eyebrow !text-[9.5px]">Téléphone</dt>
                  <dd className="mt-1 truncate font-medium text-white">{selected.guestPhone}</dd>
                </div>
              )}
            </dl>
            {selected.notes && (
              <p className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 text-sm text-[#8fa0c2]">
                {selected.notes}
              </p>
            )}
            {/* ── v4.50 « VERROUILLAGE DU HUB PAR CODE » — le code est
                généré AUTOMATIQUEMENT à la création (4 derniers chiffres
                du téléphone → code plateforme → aléatoire unique) et
                communiqué à l'invité pour déverrouiller son hub. ── */}
            {selected.accessCode && (
              <div className="mt-3 rounded-xl border border-[#e9c47c]/30 bg-[#e9c47c]/10 p-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="lux-eyebrow !text-[9.5px] !text-[#e9c47c]/80">
                      Code d'accès hub (à communiquer à l'invité)
                    </p>
                    <p className="lux-num mt-1 text-2xl font-semibold tracking-[0.35em] text-white">
                      {selected.accessCode}
                    </p>
                  </div>
                  <button
                    type="button"
                    className="lux-btn-ghost h-9 shrink-0 px-3 text-xs"
                    onClick={() => {
                      void navigator.clipboard
                        .writeText(selected.accessCode!)
                        .then(() => toast.success('Code d’acces copié'))
                        .catch(() => toast.error('Copie impossible'));
                    }}
                  >
                    Copier
                  </button>
                </div>
                {/* v4.83 — (re)envoyer les infos de connexion à l'invité ou
                    copier le message complet (WhatsApp/SMS). */}
                {canManage && selected.status !== 'CANCELLED' && (
                  <div className="mt-3 border-t border-[#e9c47c]/20 pt-3">
                    <p className="text-xs font-semibold text-[#e9c47c]">
                      Envoyer les infos de connexion à l'invité ?
                    </p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <button
                        type="button"
                        className="lux-btn lux-btn-gold h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-50"
                        disabled={sendAccessBusy || !selected.guestEmail}
                        onClick={() => void sendHubAccess(selected.id)}
                      >
                        {sendAccessBusy
                          ? 'Envoi…'
                          : `Envoyer à l'invité${selected.guestEmail ? '' : ' (email manquant)'}`}
                      </button>
                      <button
                        type="button"
                        className="lux-btn-ghost h-9 px-3 text-xs"
                        onClick={() => {
                          const text = hubConnectionText({
                            propertyName: property?.name ?? 'Votre logement',
                            hubSlug: property?.qrHubSlug ?? null,
                            guestName: selected.guestName,
                            accessCode: selected.accessCode!,
                            checkInIso: selected.checkIn,
                            checkOutIso: selected.checkOut,
                          });
                          void navigator.clipboard
                            .writeText(text)
                            .then(() => toast.success('Infos de connexion copiées — collez-les dans WhatsApp/SMS'))
                            .catch(() => toast.error('Copie impossible'));
                        }}
                      >
                        Copier les infos
                      </button>
                    </div>
                    {sentAccessTo[selected.id] ? (
                      <p className="mt-2 text-xs font-semibold text-[#86e9cb]">
                        ✓ Envoyé à {sentAccessTo[selected.id]}
                      </p>
                    ) : !selected.guestEmail ? (
                      <p className="mt-2 text-xs text-[#e9c47c]/75">
                        Ajoutez un email invité pour l'envoi direct — ou copiez les infos et envoyez-les vous-même.
                      </p>
                    ) : (
                      <p className="mt-2 text-xs text-[#e9c47c]/75">
                        Email enrichi : lien du hub, code d'accès, arrivée &amp; départ, votre contact.
                      </p>
                    )}
                    {/* v5.6 — rappel de la fenêtre d'activation du code. */}
                    <p className="mt-1 text-[11px] text-[#e9c47c]/60">
                      Rappel : le code devient actif 4 h avant l&apos;arrivée et jusqu&apos;à la fin du séjour.
                    </p>
                  </div>
                )}
                {selected.lateCheckOutUntil ? (
                  <p className="mt-1.5 text-xs font-semibold text-[#86e9cb]">
                    Verrouillage prolongé jusqu'au{' '}
                    {fmtDateTimeFr(selected.lateCheckOutUntil)}
                  </p>
                ) : null}
              </div>
            )}
            {/* v4.50 — prolonger le départ tardif : rallonge le verrouillage
                du hub ET le compte à rebours de l'invité. */}
            {canManage && selected.status !== 'CANCELLED' && (
              <div className="mt-3 rounded-xl border border-white/10 p-3">
                <p className="lux-eyebrow !text-[9.5px]">
                  Départ tardif — prolonger le verrouillage
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <input
                    type="datetime-local"
                    value={extensionValue}
                    onChange={(e) => setExtensionValue(e.target.value)}
                    className="h-9 rounded-lg border border-white/12 bg-white/[0.04] px-2 text-sm text-white"
                    aria-label="Nouvelle heure de fin de séjour"
                  />
                  <button
                    type="button"
                    className="lux-btn h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-50"
                    disabled={actionBusy || !extensionValue}
                    onClick={() => {
                      if (!extensionValue) return;
                      const iso = new Date(extensionValue).toISOString();
                      void patchBooking(selected.id, { lateCheckOutUntil: iso });
                    }}
                  >
                    Prolonger
                  </button>
                  {selected.lateCheckOutUntil && (
                    <button
                      type="button"
                      className="inline-flex h-9 items-center rounded-full px-3 text-xs text-[#8fa0c2] transition-colors hover:text-[#ffab92]"
                      disabled={actionBusy}
                      onClick={() => void patchBooking(selected.id, { lateCheckOutUntil: '' })}
                    >
                      Annuler la prolongation
                    </button>
                  )}
                </div>
              </div>
            )}
            <div className="mt-5 flex flex-wrap gap-2">
              {selected.cleaningStatus !== 'DONE' ? (
                <Button
                  size="sm"
                  className="lux-btn h-9 px-4 text-xs"
                  disabled={actionBusy}
                  onClick={() => void patchBooking(selected.id, { cleaningStatus: 'DONE' })}
                >
                  Marquer le ménage fait
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant="outline"
                  className="lux-btn-ghost h-9 px-4 text-xs"
                  disabled={actionBusy}
                  onClick={() => void patchBooking(selected.id, { cleaningStatus: 'PENDING' })}
                >
                  Ménage à refaire
                </Button>
              )}
              {canManage && selected.status !== 'CANCELLED' && (
                <Button
                  size="sm"
                  variant="outline"
                  className="h-9 rounded-full border-[#f07d6a]/30 bg-[#f07d6a]/10 px-4 text-xs text-[#ffab92] hover:bg-[#f07d6a]/20 hover:text-[#ffab92]"
                  disabled={actionBusy}
                  onClick={() => void patchBooking(selected.id, { status: 'CANCELLED' })}
                >
                  Annuler le séjour
                </Button>
              )}
              {canManage && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-9 rounded-full px-4 text-xs text-[#8fa0c2] hover:bg-white/[0.06] hover:text-[#ffab92]"
                  disabled={actionBusy}
                  onClick={() => void deleteBooking(selected.id)}
                >
                  Supprimer
                </Button>
              )}
            </div>
          </motion.div>
        </div>
      )}

      <NewBookingDialog
        open={newOpen}
        onOpenChange={setNewOpen}
        propertyId={property?.id ?? ''}
        // v4.83 — envoi direct des infos de connexion à l'invité
        // (nom du bien + slug hub pour le lien/copie).
        propertyName={property?.name ?? ''}
        hubSlug={property?.qrHubSlug ?? null}
        onCreated={() => {
          void loadBookings();
        }}
      />

      <IcalDialog
        open={icalOpen}
        onOpenChange={setIcalOpen}
        propertyId={property?.id ?? ''}
        propertyName={property?.name ?? ''}
        canManage={canManage}
      />
    </div>
  );
}

function kindLabel(kind: 'checkin' | 'checkout' | 'stay' | 'cleaning'): string {
  switch (kind) {
    case 'checkin': return 'Arrivée';
    case 'checkout': return 'Départ';
    case 'cleaning': return 'Ménage à faire';
    default: return 'Séjour';
  }
}
function sourceLabel(s: string): string {
  switch (s) {
    case 'AIRBNB': return 'Airbnb';
    case 'BOOKING': return 'Booking.com';
    case 'ICAL': return 'Import iCal';
    case 'MANUAL': return 'Manuelle';
    default: return s;
  }
}
function statusLabel(s: string): string {
  switch (s) {
    case 'CONFIRMED': return 'Confirmé';
    case 'CHECKED_IN': return 'Arrivé';
    case 'CHECKED_OUT': return 'Parti';
    case 'CANCELLED': return 'Annulé';
    default: return s;
  }
}
function cleaningLabel(s: string): string {
  switch (s) {
    case 'PENDING': return 'À faire';
    case 'IN_PROGRESS': return 'En cours';
    case 'DONE': return 'Terminé';
    default: return s;
  }
}

// =============================================================
// Modale « Nouvelle réservation » (création manuelle)
// =============================================================

function NewBookingDialog({
  open,
  onOpenChange,
  propertyId,
  propertyName,
  hubSlug,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  propertyId: string;
  /** v4.83 — nom du bien + slug hub pour l'envoi/copie des infos. */
  propertyName: string;
  hubSlug: string | null;
  onCreated: () => void | Promise<void>;
}) {
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  // v4.50 — heure exacte de check-in / check-out (protège le hub : le
  // verrouillage se déclenche à l'heure de départ exacte). Défauts
  // standards : 15 h / 11 h.
  const [checkInTime, setCheckInTime] = useState('15:00');
  const [checkOutTime, setCheckOutTime] = useState('11:00');
  const [guests, setGuests] = useState('2');
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  // v4.50 — code d'accès généré automatiquement (affiché après création
  // pour que l'hôte le communique immédiatement à l'invité).
  const [generatedCode, setGeneratedCode] = useState<string | null>(null);
  // v4.83 — séjour créé (envoi direct des infos de connexion) :
  // OUI → POST send-hub-access (email enrichi) ; NON → copie complète.
  const [createdBooking, setCreatedBooking] = useState<{
    id: string;
    guestName: string;
    guestEmail: string | null;
    checkIn: string;
    checkOut: string;
  } | null>(null);
  const [sendBusy, setSendBusy] = useState(false);
  const [sentTo, setSentTo] = useState<string | null>(null);

  /** Réinitialise le formulaire ET la séquence post-création. */
  function resetAll() {
    setGuestName(''); setGuestEmail(''); setGuestPhone(''); setCheckIn(''); setCheckOut(''); setGuests('2'); setNotes('');
    setGeneratedCode(null);
    setCreatedBooking(null);
    setSentTo(null);
    setSendBusy(false);
  }

  /** v4.83 — OUI : envoi DIRECT à l'invité (email enrichi). */
  async function sendToGuest() {
    if (!createdBooking) return;
    setSendBusy(true);
    try {
      const res = await fetch('/api/airbnb/bookings/send-hub-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bookingId: createdBooking.id }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; sentTo?: string };
      if (!res.ok) throw new Error(json.error ?? 'Envoi refusé');
      setSentTo(json.sentTo ?? createdBooking.guestEmail ?? 'invité');
      toast.success(`Infos de connexion envoyées à ${json.sentTo ?? "l'invité"}`, {
        description: 'Lien du hub + code d’accès + arrivée/départ + votre contact.',
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setSendBusy(false);
    }
  }

  /** v4.83 — NON : copie du message complet (WhatsApp/SMS). */
  function copyConnectionInfo() {
    if (!createdBooking || !generatedCode) return;
    const text = hubConnectionText({
      propertyName: propertyName || 'Votre logement',
      hubSlug,
      guestName: createdBooking.guestName,
      accessCode: generatedCode,
      checkInIso: createdBooking.checkIn,
      checkOutIso: createdBooking.checkOut,
    });
    void navigator.clipboard
      .writeText(text)
      .then(() => toast.success('Infos de connexion copiées — collez-les dans WhatsApp/SMS'))
      .catch(() => toast.error('Copie impossible'));
  }

  async function submit() {
    if (!guestName.trim() || !checkIn || !checkOut) {
      toast.error('Invité, arrivée et départ sont requis.');
      return;
    }
    // Datetimes complets (date + heure) — fin de séjour EXACTE pour le
    // verrouillage du hub et le compte à rebours de l'invité.
    const ci = `${checkIn}T${checkInTime || '15:00'}`;
    const co = `${checkOut}T${checkOutTime || '11:00'}`;
    if (new Date(co) <= new Date(ci)) {
      toast.error('La date de départ doit être après la date d’arrivée.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${propertyId}/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestName: guestName.trim(),
          guestEmail: guestEmail.trim() || undefined,
          guestPhone: guestPhone.trim() || undefined,
          checkIn: ci,
          checkOut: co,
          guests: Math.max(1, Math.min(30, Number(guests) || 1)),
          notes: notes.trim() || undefined,
        }),
      });
      const json = (await res.json().catch(() => ({}))) as {
        error?: string;
        booking?: {
          id?: string;
          guestName?: string;
          guestEmail?: string | null;
          checkIn?: string;
          checkOut?: string;
          accessCode?: string | null;
        };
      };
      if (!res.ok) throw new Error(json.error ?? 'Création refusée');
      // v4.50 — le code d'accès hub est AFFICHÉ dans la modale (copy →
      // WhatsApp/SMS à l'invité) ; la modale reste ouverte dessus.
      setGeneratedCode(json.booking?.accessCode ?? null);
      // v4.83 — mémorise le séjour créé pour l'envoi/copie des infos.
      if (json.booking?.id && json.booking.accessCode) {
        setCreatedBooking({
          id: json.booking.id,
          guestName: json.booking.guestName ?? guestName.trim(),
          guestEmail: json.booking.guestEmail ?? (guestEmail.trim() || null),
          checkIn: json.booking.checkIn ?? ci,
          checkOut: json.booking.checkOut ?? co,
        });
      }
      toast.success('Réservation ajoutée au planning');
      setGuestName(''); setGuestEmail(''); setGuestPhone(''); setCheckIn(''); setCheckOut(''); setGuests('2'); setNotes('');
      await onCreated();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(false);
    }
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-h-[90vh] overflow-y-auto border-white/10 bg-[#0b1226] text-white sm:max-w-lg">
        <AlertDialogHeader>
          <AlertDialogTitle className="lux-display font-semibold text-white">Nouvelle réservation</AlertDialogTitle>
          <AlertDialogDescription className="text-[#8fa0c2]">
            Ajoutez un séjour manuellement (hors plateformes). Les séjours iCal ne doivent PAS être
            recréés ici — ils se synchronisent automatiquement.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="bk-guest">Nom de l&apos;invité *</Label>
            <Input id="bk-guest" className={LUX_FIELD} value={guestName} onChange={(e) => setGuestName(e.target.value)} placeholder="Camille Laurent" maxLength={80} />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="bk-email">Email invité (optionnel)</Label>
            <Input id="bk-email" className={LUX_FIELD} type="email" value={guestEmail} onChange={(e) => setGuestEmail(e.target.value)} placeholder="camille@exemple.fr" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="bk-phone">Téléphone invité (optionnel)</Label>
            <Input
              id="bk-phone"
              className={LUX_FIELD}
              type="tel"
              value={guestPhone}
              onChange={(e) => setGuestPhone(e.target.value)}
              placeholder="+33612345678"
              inputMode="tel"
              maxLength={20}
            />
            <p className="text-xs text-[#8fa0c2]">
              Format international (+33…). Sert à l&apos;envoi automatique du Bouclier d&apos;avis le matin du départ
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-in">Arrivée *</Label>
              <Input id="bk-in" className={LUX_FIELD} type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-in-time">Heure d’arrivée</Label>
              <Input id="bk-in-time" className={LUX_FIELD} type="time" value={checkInTime} onChange={(e) => setCheckInTime(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-out">Départ *</Label>
              <Input id="bk-out" className={LUX_FIELD} type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-out-time">Heure de départ</Label>
              <Input id="bk-out-time" className={LUX_FIELD} type="time" value={checkOutTime} onChange={(e) => setCheckOutTime(e.target.value)} />
            </div>
          </div>
          <p className="text-xs text-[#8fa0c2]">
            L’heure de départ exacte verrouille le hub à la fin du séjour (prolongable en cas de départ tardif).
          </p>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-nb">Voyageurs</Label>
              <Input id="bk-nb" className={LUX_FIELD} type="number" min={1} max={30} value={guests} onChange={(e) => setGuests(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="bk-notes">Notes (optionnel)</Label>
              <Input id="bk-notes" className={LUX_FIELD} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Arrivée tardive…" maxLength={200} />
            </div>
          </div>
        </div>
        <AlertDialogFooter className="flex-col gap-3 sm:flex-col">
          {/* v4.50 — code d'accès hub généré automatiquement.
              v4.83 — l'hôte choisit : OUI → envoi direct à l'invité
              (email enrichi) ; NON → copie des infos complètes. */}
          {generatedCode ? (
            <div className="w-full rounded-xl border border-[#e9c47c]/30 bg-[#e9c47c]/10 p-3 text-center">
              <p className="lux-eyebrow !text-[#e9c47c]/80">
                Code d'accès hub de ce séjour
              </p>
              <p className="lux-num mt-1 text-3xl font-semibold tracking-[0.4em] text-white">
                {generatedCode}
              </p>
              <p className="mt-1 text-[11px] text-[#e9c47c]/75">
                Communiquez-le à l’invité : il déverrouillera son hub en le saisissant au scan du QR.
              </p>
              {/* v5.6 — la fenêtre du code est expliquée AVANT l'envoi :
                  évite le « le code ne marche pas » d'un invité (ou d'un
                  hôte qui teste) avant l'heure d'arrivée. */}
              <p className="mt-1 text-[11px] leading-relaxed text-[#e9c47c]/60">
                Le code devient actif 4 h avant l&apos;heure d&apos;arrivée et le hub se verrouille à la fin du séjour.
              </p>
              {/* v4.83 — « Envoyer directement à l'invité ? » */}
              {createdBooking ? (
                <div className="mt-3 rounded-lg border border-white/10 bg-white/[0.04] p-3 text-left">
                  <p className="text-xs font-semibold text-white">
                    Envoyer directement les infos de connexion à l'invité ?
                  </p>
                  <p className="mt-0.5 text-[11px] leading-relaxed text-[#8fa0c2]">
                    Message enrichi : lien du hub, code d'accès, arrivée &amp; départ, votre contact.
                  </p>
                  <div className="mt-2 flex flex-col gap-2">
                    {sentTo ? (
                      <p className="rounded-lg bg-[#34d399]/10 px-3 py-2 text-xs font-semibold text-[#86e9cb]">
                        ✓ Envoyé à {sentTo} — l'invité a tout ce qu'il faut.
                      </p>
                    ) : (
                      <button
                        type="button"
                        className="lux-btn lux-btn-gold h-10 w-full text-xs disabled:pointer-events-none disabled:opacity-50"
                        disabled={sendBusy || !createdBooking.guestEmail}
                        onClick={() => void sendToGuest()}
                      >
                        {sendBusy
                          ? 'Envoi…'
                          : createdBooking.guestEmail
                            ? `Oui, envoyer à ${createdBooking.guestEmail}`
                            : 'Oui — email invité manquant (ajoutez-le dans la fiche)'}
                      </button>
                    )}
                    <button
                      type="button"
                      className="lux-btn-ghost h-10 w-full text-xs"
                      onClick={copyConnectionInfo}
                    >
                      Non, copier les infos de connexion (WhatsApp/SMS)
                    </button>
                  </div>
                </div>
              ) : null}
              <button
                type="button"
                className="mt-2 inline-flex h-8 w-full items-center justify-center text-xs text-[#e9c47c]/80 transition-colors hover:text-[#e9c47c]"
                onClick={() => {
                  void navigator.clipboard
                    .writeText(generatedCode)
                    .then(() => toast.success('Code d’acces copié'))
                    .catch(() => toast.error('Copie impossible'));
                }}
              >
                Copier le code seul
              </button>
            </div>
          ) : null}
          <div className="flex w-full gap-2 sm:justify-end">
            <AlertDialogCancel
              className="h-10 rounded-full border-white/12 bg-white/[0.04] text-[#8fa0c2] hover:bg-white/[0.08] hover:text-white"
              onClick={() => {
                resetAll();
                onOpenChange(false);
              }}
            >
              {generatedCode ? 'Fermer' : 'Annuler'}
            </AlertDialogCancel>
            {!generatedCode ? (
              <AlertDialogAction
                className="lux-btn h-10 font-semibold disabled:opacity-50"
                disabled={busy}
                onClick={(e) => {
                  e.preventDefault();
                  void submit();
                }}
              >
                {busy ? 'Ajout…' : 'Ajouter au planning'}
              </AlertDialogAction>
            ) : null}
          </div>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

// =============================================================
// Modale « Synchroniser iCal » — liste des feeds + ajout RÉEL
// =============================================================

function IcalDialog({
  open,
  onOpenChange,
  propertyId,
  propertyName,
  canManage,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  propertyId: string;
  propertyName: string;
  canManage: boolean;
}) {
  const [feeds, setFeeds] = useState<IcalFeed[]>([]);
  const [loading, setLoading] = useState(false);
  const [label, setLabel] = useState('');
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<IcalFeed | null>(null);

  const load = useCallback(async () => {
    if (!propertyId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/airbnb/ical?propertyId=${encodeURIComponent(propertyId)}`, { cache: 'no-store' });
      if (!res.ok) throw new Error('load');
      const data = (await res.json()) as { feeds: IcalFeed[] };
      setFeeds(data.feeds ?? []);
    } catch {
      toast.error('Impossible de charger les calendriers connectés.');
    } finally {
      setLoading(false);
    }
  }, [propertyId]);

  useEffect(() => {
    if (open) void load();
  }, [open, load]);

  async function addFeed() {
    if (!label.trim() || !url.trim()) {
      toast.error('Libellé et URL sont requis.');
      return;
    }
    setBusy('add');
    try {
      const res = await fetch('/api/airbnb/ical', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId, label: label.trim(), url: url.trim() }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; feed?: IcalFeed };
      if (!res.ok) throw new Error(json.error ?? 'Connexion refusée');
      if (json.feed?.lastStatus === 'OK') {
        toast.success(`Calendrier connecté — ${json.feed.lastImported} séjour(s) importé(s)`);
      } else if (json.feed?.lastStatus === 'ERROR') {
        toast.error(`Calendrier enregistré, mais la synchro a échoué : ${json.feed.lastError ?? 'erreur inconnue'}`);
      }
      setLabel(''); setUrl('');
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(null);
    }
  }

  async function resync(feed: IcalFeed) {
    setBusy(feed.id);
    try {
      const res = await fetch('/api/airbnb/ical', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feedId: feed.id }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; feed?: { lastStatus?: string; lastImported?: number; lastError?: string | null } };
      if (!res.ok) throw new Error(json.error ?? 'Synchro refusée');
      if (json.feed?.lastStatus === 'OK') {
        toast.success(`${feed.label} — ${json.feed.lastImported} séjour(s) synchronisé(s)`);
      } else {
        toast.error(`${feed.label} — échec : ${json.feed?.lastError ?? 'erreur inconnue'}`);
      }
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(null);
    }
  }

  async function removeFeed(feed: IcalFeed) {
    setBusy(feed.id);
    try {
      const res = await fetch(`/api/airbnb/ical?feedId=${encodeURIComponent(feed.id)}`, { method: 'DELETE' });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Suppression refusée');
      toast.success(`${feed.label} déconnecté`);
      setConfirmDelete(null);
      await load();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(null);
    }
  }

  return (
    <>
      <AlertDialog open={open} onOpenChange={onOpenChange}>
        <AlertDialogContent className="max-h-[90vh] overflow-y-auto border-white/10 bg-[#0b1226] text-white sm:max-w-xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="lux-display font-semibold text-white">Synchroniser iCal</AlertDialogTitle>
            <AlertDialogDescription className="text-[#8fa0c2]">
              Connectez les calendriers externes de {propertyName || 'votre bien'} (Airbnb, Booking.com,
              Abritel…). Collez l&apos;URL d&apos;export iCal fournie par la plateforme — les séjours
              s&apos;importent puis se mettent à jour à chaque synchronisation.
            </AlertDialogDescription>
          </AlertDialogHeader>

          {/* ----- Feeds existants ----- */}
          <div className="flex flex-col gap-2">
            {loading ? (
              <Skeleton className="h-16 w-full rounded-xl bg-white/[0.06]" />
            ) : feeds.length === 0 ? (
              <p className="lux-empty rounded-xl p-4 text-center text-sm font-medium text-[#8fa0c2]">
                Aucun calendrier connecté pour ce bien.
              </p>
            ) : (
              feeds.map((f) => (
                <div key={f.id} className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3 transition-colors hover:bg-white/[0.05]">
                  <span
                    aria-hidden="true"
                    className="lux-dot mt-1.5 shrink-0"
                    style={{ backgroundColor: f.lastStatus === 'ERROR' ? '#f07d6a' : f.lastStatus === 'OK' ? '#34d399' : '#8fa0c2' }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-white">{f.label}</p>
                    <p className="truncate text-xs text-[#8fa0c2]" title={f.url}>{f.url}</p>
                    <p className="mt-0.5 text-xs">
                      {f.lastSyncAt ? (
                        <>
                          <span className={cn('font-semibold', f.lastStatus === 'OK' ? 'text-[#86e9cb]' : 'text-[#f07d6a]')}>
                            {f.lastStatus === 'OK' ? '✓ Synchronisé' : '✗ Erreur'}
                          </span>{' '}
                          <span className="text-[#8fa0c2]">{fmtDateTimeFr(f.lastSyncAt)} · {f.lastImported} séjour(s)</span>
                          {f.lastError && <span className="block text-[#f07d6a]">{f.lastError}</span>}
                        </>
                      ) : (
                        <span className="text-[#8fa0c2]">Jamais synchronisé</span>
                      )}
                    </p>
                  </div>
                  {canManage && (
                    <div className="flex shrink-0 flex-col gap-1">
                      <Button size="sm" variant="outline" className="h-7 rounded-full border-white/12 bg-white/[0.04] px-3 text-[11px] text-[#8fa0c2] hover:bg-white/[0.08] hover:text-white" disabled={busy !== null} onClick={() => void resync(f)}>
                        {busy === f.id ? '…' : 'Re-sync'}
                      </Button>
                      <Button size="sm" variant="ghost" className="h-7 text-xs text-[#8fa0c2] hover:bg-white/[0.06] hover:text-[#ffab92]" disabled={busy !== null} onClick={() => setConfirmDelete(f)}>
                        Retirer
                      </Button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>

          {/* ----- Ajout ----- */}
          {canManage && (
            <div className="flex flex-col gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
              <p className="lux-eyebrow">Connecter un calendrier</p>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ic-label">Libellé (ex : « Airbnb — Loft »)</Label>
                <Input id="ic-label" className={LUX_FIELD} value={label} onChange={(e) => setLabel(e.target.value)} maxLength={60} placeholder="Airbnb — Loft" disabled={busy !== null} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ic-url">URL d&apos;export iCal</Label>
                <Input id="ic-url" className={LUX_FIELD} value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://fr.airbnb.com/calendar/ical/…" disabled={busy !== null} />
                <p className="text-[11px] text-[#8fa0c2]">
                  Airbnb : Annonces → Calendrier → Disponibilité → Exporter le calendrier. Les URL
                  webcal:// sont converties automatiquement.
                </p>
              </div>
              <button
                type="button"
                className="lux-btn h-9 w-fit px-4 text-xs disabled:pointer-events-none disabled:opacity-50"
                disabled={busy !== null}
                onClick={() => void addFeed()}
              >
                {busy === 'add' ? 'Connexion…' : 'Connecter le calendrier'}
              </button>
            </div>
          )}

          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-full border-white/12 bg-white/[0.04] text-[#8fa0c2] hover:bg-white/[0.08] hover:text-white">Fermer</AlertDialogCancel>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ----- Confirmation de suppression d'un feed ----- */}
      <AlertDialog open={confirmDelete !== null} onOpenChange={(v) => !v && setConfirmDelete(null)}>
        <AlertDialogContent className="border-white/10 bg-[#0b1226] text-white">
          <AlertDialogHeader>
            <AlertDialogTitle className="lux-display font-semibold text-white">Déconnecter ce calendrier ?</AlertDialogTitle>
            <AlertDialogDescription className="text-[#8fa0c2]">
              {confirmDelete?.label} ne se synchronisera plus. Les séjours déjà importés restent dans
              le planning (traçabilité).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="h-10 rounded-full border-white/12 bg-white/[0.04] text-[#8fa0c2] hover:bg-white/[0.08] hover:text-white">Annuler</AlertDialogCancel>
            <AlertDialogAction
              className="h-10 rounded-full bg-[#f07d6a] font-semibold text-[#2a0c06] hover:bg-[#f07d6a]/85"
              onClick={() => confirmDelete && void removeFeed(confirmDelete)}
            >
              Déconnecter
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
