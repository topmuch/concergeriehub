'use client';

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Bell,
  CalendarDays,
  CreditCard,
  KeyRound,
  Link2,
  Palette,
  Plus,
  ShieldCheck,
  Trash2,
  UserRound,
  Zap,
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { BrandingContent } from '@/components/airbnb/branding-content';
import { usePushNotifications } from '@/hooks/use-push-notifications';
import {
  NOTIFICATION_EVENTS,
  type NotificationPrefsMap,
} from '@/lib/notification-prefs';
import type { KPITone } from '@/components/airbnb/host/kpi-card';
import { cn } from '@/lib/utils';

// =============================================================
// SettingsContent — page « Paramètres » du Dashboard Client
// v4.60 « AIRBNB PRO » — refonte visuelle (logique intacte)
// Onglets : Profil · Propriétés · White-Label · Notifications ·
// Sécurité · Intégrations. Toutes les mutations passent par les
// API réelles (/api/airbnb/profile, /security/password,
// /notifications/prefs) — aucun état factice.
//
// • Chaque thème = une carte air-shadow rounded-2xl avec bulle
//   d'icône dégradée kpi-bubble-{tone} (tons variés)
// • CTA principaux en pilule air-gradient, secondaires outline
// • Tokens sémantiques partout (bg-card / text-foreground /
//   border-border) — lisible en clair ET en sombre
// =============================================================

interface ProfileState {
  email: string;
  fullName: string;
  phone: string;
  address: string;
}

interface WebhookRow {
  id: string;
  name: string;
  url: string;
  isActive: boolean;
  successCount: number;
  failCount: number;
}

/* ----- Carte de section locale « AIRBNB PRO » (bulle tonée + titre) ----- */
function SettingsCard({
  tone,
  icon,
  title,
  description,
  children,
  className,
}: {
  tone: KPITone;
  icon: ReactNode;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('air-shadow rounded-2xl border border-border bg-card', className)}>
      <div className="flex flex-col gap-4 p-5 sm:p-6">
        <div className="flex items-start gap-3">
          <span
            aria-hidden="true"
            className={cn(
              'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow',
              `kpi-bubble-${tone}`,
            )}
          >
            {icon}
          </span>
          <div className="min-w-0">
            <h2 className="text-base font-bold text-foreground">{title}</h2>
            {description ? (
              <p className="mt-0.5 text-xs text-muted-foreground sm:text-sm">{description}</p>
            ) : null}
          </div>
        </div>
        {children}
      </div>
    </div>
  );
}

export function SettingsContent() {
  const { properties, plan } = useHostContext();

  return (
    <div className="flex flex-col gap-6">
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
      >
        <h1 className="text-2xl font-bold tracking-tight text-foreground">⚙️ Paramètres</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Gérez votre profil, votre abonnement, vos notifications et vos intégrations.
        </p>
      </motion.div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="air-shadow h-auto w-full flex-wrap justify-start gap-1 rounded-2xl border border-border bg-card p-1.5 sm:flex-nowrap">
          <TabsTrigger
            value="profile"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            <UserRound className="h-4 w-4" aria-hidden="true" /> Profil
          </TabsTrigger>
          <TabsTrigger
            value="properties"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            🏠 Propriétés
          </TabsTrigger>
          <TabsTrigger
            value="white-label"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            <Palette className="h-4 w-4" aria-hidden="true" /> White-Label
          </TabsTrigger>
          <TabsTrigger
            value="notifications"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            🔔 Notifications
          </TabsTrigger>
          <TabsTrigger
            value="security"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            <ShieldCheck className="h-4 w-4" aria-hidden="true" /> Sécurité
          </TabsTrigger>
          <TabsTrigger
            value="integrations"
            className="gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold text-muted-foreground data-[state=active]:bg-foreground data-[state=active]:text-background data-[state=active]:shadow-sm dark:data-[state=active]:bg-foreground dark:data-[state=active]:text-background"
          >
            <Link2 className="h-4 w-4" aria-hidden="true" /> Intégrations
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-4">
          <ProfileTab />
        </TabsContent>
        <TabsContent value="properties" className="mt-4">
          <PropertiesTab />
        </TabsContent>
        <TabsContent value="white-label" className="mt-4">
          {plan?.isPro ? (
            <BrandingContent />
          ) : (
            <div className="air-empty flex flex-col items-center gap-3 rounded-2xl p-8 text-center">
              <span aria-hidden="true" className="air-float text-3xl">🎨</span>
              <h2 className="text-lg font-bold text-foreground">White-Label réservé au plan Pro</h2>
              <p className="mx-auto max-w-md text-sm text-muted-foreground">
                Personnalisez le Hub invité avec votre logo, vos couleurs et votre propre domaine
                en passant à l&apos;offre Airbnb Pro.
              </p>
              <Link
                href="/airbnb/billing"
                className="air-gradient mt-1 inline-flex h-9 items-center rounded-full px-4 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50"
              >
                Découvrir l&apos;offre Pro
              </Link>
            </div>
          )}
        </TabsContent>
        <TabsContent value="notifications" className="mt-4">
          <NotificationsTab />
        </TabsContent>
        <TabsContent value="security" className="mt-4">
          <SecurityTab />
        </TabsContent>
        <TabsContent value="integrations" className="mt-4">
          <IntegrationsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// =============================================================
// Onglet Profil — GET/PATCH /api/airbnb/profile
// =============================================================

function ProfileTab() {
  const [profile, setProfile] = useState<ProfileState | null>(null);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch('/api/airbnb/profile', { cache: 'no-store' });
        if (!res.ok) throw new Error();
        const data = (await res.json()) as { profile: ProfileState };
        if (!alive) return;
        setProfile(data.profile);
        setFullName(data.profile.fullName ?? '');
        setPhone(data.profile.phone ?? '');
        setAddress(data.profile.address ?? '');
      } catch {
        if (alive) toast.error('Impossible de charger votre profil.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  async function save() {
    setBusy(true);
    try {
      const res = await fetch('/api/airbnb/profile', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, phone, address }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Enregistrement refusé');
      toast.success('Profil mis à jour ✅');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(false);
    }
  }

  return (
    <SettingsCard
      tone="rausch"
      icon={<UserRound className="h-5 w-5" aria-hidden="true" />}
      title="Mon profil"
      description="Ces informations apparaissent pour votre équipe."
      className="max-w-xl"
    >
      {loading ? (
        <div className="flex flex-col gap-4">
          <Skeleton className="h-10 w-full rounded-xl" aria-hidden="true" />
          <Skeleton className="h-10 w-full rounded-xl" aria-hidden="true" />
          <Skeleton className="h-10 w-full rounded-xl" aria-hidden="true" />
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="st-email">Email (identifiant de connexion)</Label>
            <Input id="st-email" value={profile?.email ?? ''} disabled className="bg-muted text-muted-foreground" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="st-name">Nom complet *</Label>
            <Input id="st-name" value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={80} />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="st-phone">Téléphone</Label>
            <Input id="st-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06 12 34 56 78" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="st-address">Adresse</Label>
            <Input id="st-address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="12 rue de Exemple, Paris" />
          </div>
          <div>
            <Button
              className="air-gradient h-9 rounded-full px-5 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03]"
              disabled={busy || fullName.trim().length < 2}
              onClick={() => void save()}
            >
              {busy ? 'Enregistrement…' : 'Enregistrer'}
            </Button>
          </div>
        </div>
      )}
    </SettingsCard>
  );
}

// =============================================================
// Onglet Propriétés — renvoi vers le portfolio (source de vérité)
// =============================================================

function PropertiesTab() {
  const { properties, plan } = useHostContext();
  return (
    <SettingsCard
      tone="violet"
      icon={<span className="text-lg leading-none">🏠</span>}
      title="Mes biens"
      description="La gestion complète (création, édition, plaques) se fait depuis « Mes Propriétés »."
      className="max-w-2xl"
    >
      <ul className="flex flex-col gap-2">
        {properties.map((p) => (
          <li
            key={p.id}
            className="flex items-center gap-3 rounded-xl border border-border bg-background p-3 transition-colors hover:bg-muted/50"
          >
            <span
              aria-hidden="true"
              className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted text-lg"
            >
              🏠
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold text-foreground">{p.name}</p>
              <p className="truncate text-xs text-muted-foreground">{p.address ?? 'Adresse non renseignée'}</p>
            </div>
            <Link
              href="/airbnb/properties"
              className="shrink-0 text-xs font-bold text-[#0066EF] hover:underline dark:text-[#8FB8FF]"
            >
              Gérer →
            </Link>
          </li>
        ))}
      </ul>
      {plan && (
        <p className="text-xs text-muted-foreground">
          Plan {plan.planName} — {plan.ownedCount}/{plan.maxProperties} biens.
        </p>
      )}
    </SettingsCard>
  );
}

// =============================================================
// Onglet Notifications — GET/PUT /api/airbnb/notifications/prefs
// =============================================================

/** v4.76 — PUSH VAPID SUR CET APPAREIL : le vrai abonnement navigateur
 *  (permission + PushManager + /api/client/push), branché sur le backend
 *  sendPushToUser. S'affiche au-dessus des préférences par canal (qui ne
 *  contrôlent que QUELS événements partent en push, pas l'abonnement). */
function PushDeviceCard() {
  const push = usePushNotifications();
  const active = push.subscribed && push.permission === 'granted';

  const statusLine = !push.supported
    ? '❌ Non supporté par ce navigateur (essayez Chrome, Edge ou Safari 16.4+).'
    : push.permission === 'denied'
      ? '❌ Non autorisé — réactivez les notifications dans les réglages du navigateur.'
      : active
        ? 'Activé ✅ — vous recevrez les alertes push sur cet appareil.'
        : 'Désactivé — activez pour recevoir les alertes en temps réel.';

  return (
    <div
      className={cn(
        'mb-5 rounded-2xl border p-4',
        active
          ? 'border-emerald-300/70 bg-emerald-50/60 dark:border-emerald-500/30 dark:bg-emerald-950/30'
          : 'border-border bg-muted/40',
      )}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-bold text-foreground">
            📲 Notifications push sur cet appareil
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">{statusLine}</p>
          {push.error && <p className="mt-1 text-xs font-semibold text-red-500">{push.error}</p>}
        </div>
        <Switch
          checked={active}
          disabled={push.busy || !push.supported || push.permission === 'denied'}
          onCheckedChange={(checked) => {
            if (checked) void push.enable();
            else void push.disable();
          }}
          aria-label="Activer les notifications push sur cet appareil"
        />
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
        📱 Sur iOS / iPadOS : ajoutez d&apos;abord le site à l&apos;écran d&apos;accueil
        (bouton Partager → « Sur l&apos;écran d&apos;accueil ») pour que les
        notifications push fonctionnent.
      </p>
    </div>
  );
}

function NotificationsTab() {
  const [prefs, setPrefs] = useState<NotificationPrefsMap | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const res = await fetch('/api/airbnb/notifications/prefs', { cache: 'no-store' });
        if (!res.ok) throw new Error();
        const data = (await res.json()) as { prefs: NotificationPrefsMap };
        if (alive) setPrefs(data.prefs);
      } catch {
        if (alive) toast.error('Impossible de charger vos préférences.');
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  function toggle(key: string, channel: 'email' | 'push') {
    setPrefs((prev) => {
      if (!prev) return prev;
      return { ...prev, [key]: { ...prev[key], [channel]: !prev[key]?.[channel] } };
    });
    setDirty(true);
  }

  async function save() {
    if (!prefs) return;
    setSaving(true);
    try {
      const res = await fetch('/api/airbnb/notifications/prefs', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefs }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Enregistrement refusé');
      toast.success('Préférences enregistrées ✅');
      setDirty(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setSaving(false);
    }
  }

  return (
    <SettingsCard
      tone="amber"
      icon={<Bell className="h-5 w-5" aria-hidden="true" />}
      title="Choisissez quels événements vous alertent"
      description="Par canal : email et notification push (l'application doit avoir autorisé les push)."
      className="max-w-2xl"
    >
      {loading || !prefs ? (
        <div className="flex flex-col gap-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-14 w-full rounded-2xl" aria-hidden="true" />
          ))}
        </div>
      ) : (
        <>
          {/* v4.76 — abonnement push réel de l'appareil (avant les canaux). */}
          <PushDeviceCard />
          <ul className="flex flex-col divide-y divide-border">
            {NOTIFICATION_EVENTS.map((ev) => (
              <li key={ev.key} className="flex items-center gap-3 py-3">
                <span
                  aria-hidden="true"
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-base"
                >
                  {ev.emoji}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-foreground">{ev.label}</p>
                  <p className="text-xs text-muted-foreground">{ev.description}</p>
                </div>
                <div className="flex shrink-0 items-center gap-2 sm:gap-3">
                  <label className="flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold text-muted-foreground">
                    ✉️
                    <Switch
                      checked={prefs[ev.key]?.email ?? true}
                      onCheckedChange={() => toggle(ev.key, 'email')}
                      aria-label={`Email pour ${ev.label}`}
                    />
                  </label>
                  <label className="flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-[11px] font-bold text-muted-foreground">
                    📲
                    <Switch
                      checked={prefs[ev.key]?.push ?? false}
                      onCheckedChange={() => toggle(ev.key, 'push')}
                      aria-label={`Push pour ${ev.label}`}
                    />
                  </label>
                </div>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap items-center gap-3">
            <Button
              className="air-gradient h-9 rounded-full px-5 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03]"
              disabled={!dirty || saving}
              onClick={() => void save()}
            >
              {saving ? 'Enregistrement…' : 'Enregistrer les préférences'}
            </Button>
            {!dirty && (
              <span className="rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
                Aucune modification en attente
              </span>
            )}
          </div>
        </>
      )}
    </SettingsCard>
  );
}

// =============================================================
// Onglet Sécurité — changement de mot de passe réel + état 2FA
// =============================================================

function SecurityTab() {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);

  const strengthOk = next.length >= 8 && /[A-Za-z]/.test(next) && /[0-9]/.test(next);

  async function changePassword() {
    if (next !== confirm) {
      toast.error('Les deux mots de passe ne correspondent pas.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/airbnb/security/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(json.error ?? 'Changement refusé');
      toast.success(json.message ?? 'Mot de passe mis à jour ✅');
      setCurrent(''); setNext(''); setConfirm('');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex max-w-2xl flex-col gap-4">
      <SettingsCard
        tone="rausch"
        icon={<KeyRound className="h-5 w-5" aria-hidden="true" />}
        title="Changer de mot de passe"
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="sec-cur">Mot de passe actuel</Label>
            <Input id="sec-cur" type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="sec-new">Nouveau mot de passe</Label>
            <Input id="sec-new" type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" />
            {next.length > 0 && (
              <p className={cn('text-xs', strengthOk ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400')}>
                {strengthOk
                  ? '✓ Format valide (8+ caractères, 1 lettre, 1 chiffre)'
                  : '8 caractères minimum, avec au moins une lettre et un chiffre'}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="sec-conf">Confirmer le nouveau mot de passe</Label>
            <Input id="sec-conf" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
            {confirm.length > 0 && confirm !== next && (
              <p className="text-xs text-rose-600 dark:text-rose-400">Les mots de passe ne correspondent pas.</p>
            )}
          </div>
          <div>
            <Button
              className="air-gradient h-9 rounded-full px-5 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03]"
              disabled={busy || !current || !strengthOk || next !== confirm}
              onClick={() => void changePassword()}
            >
              {busy ? 'Vérification…' : 'Mettre à jour le mot de passe'}
            </Button>
          </div>
        </div>
      </SettingsCard>

      <SettingsCard
        tone="violet"
        icon={<ShieldCheck className="h-5 w-5" aria-hidden="true" />}
        title="Double authentification (2FA)"
      >
        <p className="text-sm text-muted-foreground">
          État actuel :{' '}
          <span className="inline-flex items-center rounded-full border border-amber-200 bg-amber-50 px-2.5 py-0.5 text-xs font-bold text-amber-700 dark:border-amber-500/30 dark:bg-amber-950/40 dark:text-amber-300">
            Non configurée
          </span>{' '}
          sur ce compte.
        </p>
        <p className="rounded-xl border border-border bg-muted p-3.5 text-xs leading-relaxed text-muted-foreground">
          La 2FA TOTP (application d&apos;authentification) sera disponible prochainement — elle
          nécessite l&apos;intégration de l&apos;étape de vérification à la connexion. Le changement
          de mot de passe ci-dessus est effectif immédiatement et appliqué par bcrypt côté serveur.
        </p>
      </SettingsCard>
    </div>
  );
}

// =============================================================
// Onglet Intégrations — webhooks (CRUD COMPLET v4.73) + Stripe + iCal
// =============================================================

/** Événements webhook déclenchables (VALID_EVENTS de l'API). */
const WEBHOOK_EVENTS: { key: string; label: string }[] = [
  { key: 'scan', label: '📱 Scan de la plaque QR' },
  { key: 'doorbell', label: '🔔 Message / sonnette invité' },
  { key: 'guestbook', label: '📖 Nouvelle entrée livre d\'or' },
  { key: 'chore_completed', label: '🧹 Tâche terminée' },
  { key: 'notification', label: '🔔 Notification plateforme' },
];

interface WebhookFullRow extends WebhookRow {
  events?: string;
  property?: { id: string; name: string } | null;
  lastTriggerAt?: string | null;
}

function IntegrationsTab() {
  const { properties } = useHostContext();
  const [webhooks, setWebhooks] = useState<WebhookFullRow[] | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<WebhookFullRow | null>(null);
  const [saving, setSaving] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [form, setForm] = useState<{ propertyId: string; name: string; url: string; events: string[] }>({
    propertyId: '',
    name: '',
    url: '',
    events: ['scan', 'doorbell', 'guestbook'],
  });

  const fetchWebhooks = useCallback(async () => {
    try {
      const res = await fetch('/api/client/webhooks', { cache: 'no-store' });
      if (!res.ok) throw new Error();
      const data = (await res.json()) as { webhooks?: WebhookFullRow[] };
      setWebhooks(data.webhooks ?? []);
    } catch {
      setWebhooks([]);
    }
  }, []);

  useEffect(() => {
    void fetchWebhooks();
  }, [fetchWebhooks]);

  // Préremplit le bien avec le premier du portfolio à l'ouverture.
  const openCreate = () => {
    setEditing(null);
    setForm({
      propertyId: properties[0]?.id ?? '',
      name: '',
      url: '',
      events: ['scan', 'doorbell', 'guestbook'],
    });
    setDialogOpen(true);
  };

  const openEdit = (w: WebhookFullRow) => {
    setEditing(w);
    let events: string[] = [];
    try {
      const parsed: unknown = JSON.parse(w.events ?? '[]');
      if (Array.isArray(parsed)) events = parsed.filter((v): v is string => typeof v === 'string');
    } catch {
      events = [];
    }
    setForm({
      propertyId: w.property?.id ?? properties[0]?.id ?? '',
      name: w.name,
      url: w.url,
      events: events.length ? events : ['scan', 'doorbell', 'guestbook'],
    });
    setDialogOpen(true);
  };

  const saveWebhook = async () => {
    if (!form.propertyId) {
      toast.error('Choisissez le bien concerné.');
      return;
    }
    if (!form.name.trim()) {
      toast.error('Donnez un nom à votre webhook.');
      return;
    }
    if (!/^https?:\/\/.+\..+/.test(form.url.trim())) {
      toast.error('URL invalide — https:// attendu.');
      return;
    }
    if (form.events.length === 0) {
      toast.error('Sélectionnez au moins un événement.');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(
        editing ? `/api/client/webhooks/${editing.id}` : '/api/client/webhooks',
        {
          method: editing ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(
            editing
              ? { name: form.name.trim(), url: form.url.trim(), events: form.events }
              : { propertyId: form.propertyId, name: form.name.trim(), url: form.url.trim(), events: form.events },
          ),
        },
      );
      const json = (await res.json().catch(() => null)) as { error?: string; secret?: string } | null;
      if (!res.ok) {
        toast.error(json?.error || 'Enregistrement impossible.');
        return;
      }
      if (!editing && json?.secret) {
        toast.success('Webhook créé ✓', {
          description: `Clé secrète (notez-la, elle ne sera plus affichée) : ${json.secret.slice(0, 12)}…`,
          duration: 10000,
        });
      } else {
        toast.success(editing ? 'Webhook mis à jour ✓' : 'Webhook créé ✓');
      }
      setDialogOpen(false);
      await fetchWebhooks();
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (w: WebhookFullRow, isActive: boolean) => {
    setWebhooks((prev) =>
      (prev ?? []).map((r) => (r.id === w.id ? { ...r, isActive } : r)),
    );
    try {
      const res = await fetch(`/api/client/webhooks/${w.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive }),
      });
      if (!res.ok) throw new Error();
      toast.success(isActive ? 'Webhook activé ✓' : 'Webhook désactivé');
    } catch {
      toast.error('Mise à jour impossible.');
      await fetchWebhooks();
    }
  };

  const testWebhook = async (w: WebhookFullRow) => {
    setTestingId(w.id);
    toast.info('Test en cours…');
    try {
      const res = await fetch(`/api/client/webhooks/${w.id}/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event: 'test' }),
      });
      const json = (await res.json().catch(() => null)) as {
        success?: boolean;
        statusCode?: number | null;
        response?: string;
      } | null;
      if (json?.success) {
        toast.success(`Test réussi — HTTP ${json.statusCode ?? 200}`, {
          description: json.response?.slice(0, 120),
        });
      } else {
        toast.error(`Test échoué${json?.statusCode ? ` — HTTP ${json.statusCode}` : ''}`, {
          description: json?.response?.slice(0, 140),
        });
      }
      await fetchWebhooks();
    } catch {
      toast.error('Test impossible — connexion perdue.');
    } finally {
      setTestingId(null);
    }
  };

  const deleteWebhook = async (w: WebhookFullRow) => {
    try {
      const res = await fetch(`/api/client/webhooks/${w.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error();
      toast.success('Webhook supprimé');
      setConfirmDeleteId(null);
      await fetchWebhooks();
    } catch {
      toast.error('Suppression impossible.');
    }
  };

  return (
    <div className="flex max-w-4xl flex-col gap-4">
      {/* Stripe */}
      <SettingsCard
        tone="emerald"
        icon={<CreditCard className="h-5 w-5" aria-hidden="true" />}
        title="Stripe (abonnement & paiements)"
        description="Les paiements invités et votre abonnement sont traités par Stripe. Le portail client vous permet de gérer vos moyens de paiement et vos factures."
      >
        <Link
          href="/airbnb/billing"
          className="inline-flex h-9 items-center rounded-full border border-border px-4 text-xs font-bold text-foreground transition-colors hover:bg-muted"
        >
          Ouvrir la facturation →
        </Link>
      </SettingsCard>

      {/* iCal */}
      <SettingsCard
        tone="teal"
        icon={<CalendarDays className="h-5 w-5" aria-hidden="true" />}
        title="Calendriers iCal (Airbnb, Booking, Abritel)"
        description="Connectez les calendriers externes de vos biens pour importer automatiquement les séjours dans votre planning."
      >
        <Link
          href="/airbnb/calendar"
          className="inline-flex h-9 items-center rounded-full border border-border px-4 text-xs font-bold text-foreground transition-colors hover:bg-muted"
        >
          Ouvrir le calendrier →
        </Link>
      </SettingsCard>

      {/* Webhooks — CRUD complet (v4.73) */}
      <SettingsCard
        tone="violet"
        icon={<Link2 className="h-5 w-5" aria-hidden="true" />}
        title="Webhooks"
        description={
          <>
            Recevez un appel HTTP à chaque scan, message invité ou entrée de livre d&apos;or —
            vers Zapier, Make, n8n ou votre propre serveur.
            {webhooks && webhooks.length === 0 && ' Aucun webhook configuré pour le moment.'}
          </>
        }
      >
        <div className="flex flex-col gap-3">
          {webhooks === null && <Skeleton className="h-20 w-full rounded-xl" />}

          {webhooks && webhooks.length === 0 && (
            <p className="rounded-xl border border-dashed border-border bg-muted/40 p-4 text-xs text-muted-foreground">
              Créez votre premier webhook : RoomScan enverra un POST JSON à votre URL à chaque
              événement sélectionné (scan, message, livre d&apos;or…).
            </p>
          )}

          {webhooks && webhooks.length > 0 && (
            <ul className="flex flex-col gap-2">
              {webhooks.map((w) => (
                <li key={w.id} className="rounded-xl border border-border bg-background p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="min-w-0 truncate text-sm font-bold text-foreground">{w.name}</p>
                    <div className="flex shrink-0 items-center gap-2">
                      <Switch
                        checked={w.isActive}
                        onCheckedChange={(v) => void toggleActive(w, v)}
                        aria-label={w.isActive ? 'Désactiver ce webhook' : 'Activer ce webhook'}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="h-8 rounded-full px-3 text-xs"
                        disabled={testingId === w.id}
                        onClick={() => void testWebhook(w)}
                      >
                        <Zap className={cn('h-3.5 w-3.5', testingId === w.id && 'animate-pulse')} aria-hidden="true" />
                        {testingId === w.id ? 'Test…' : 'Tester'}
                      </Button>
                      <button
                        type="button"
                        onClick={() => openEdit(w)}
                        className="rounded-full border border-border px-3 py-1 text-xs font-semibold text-foreground transition-colors hover:bg-muted"
                      >
                        Modifier
                      </button>
                      {confirmDeleteId === w.id ? (
                        <span className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => void deleteWebhook(w)}
                            className="rounded-full bg-destructive px-3 py-1 text-xs font-bold text-white"
                          >
                            Confirmer
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(null)}
                            className="rounded-full border border-border px-2 py-1 text-xs text-muted-foreground"
                          >
                            Annuler
                          </button>
                        </span>
                      ) : (
                        <button
                          type="button"
                          aria-label={`Supprimer ${w.name}`}
                          onClick={() => setConfirmDeleteId(w.id)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                        >
                          <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                      )}
                    </div>
                  </div>
                  <p className="truncate font-mono text-xs text-muted-foreground">{w.url}</p>
                  <p className="mt-0.5 text-[11px] text-muted-foreground">
                    {w.property?.name ? `${w.property.name} · ` : ''}
                    {w.successCount} succès · {w.failCount} échec(s)
                    {w.lastTriggerAt
                      ? ` · dernier déclenchement ${new Date(w.lastTriggerAt).toLocaleDateString('fr-FR')}`
                      : ''}
                  </p>
                </li>
              ))}
            </ul>
          )}

          <div>
            <Button
              type="button"
              className="air-gradient h-9 rounded-full px-4 text-xs font-bold text-white shadow"
              onClick={openCreate}
              disabled={properties.length === 0}
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              Ajouter un webhook
            </Button>
            {properties.length === 0 && (
              <p className="mt-2 text-[11px] text-muted-foreground">
                Créez d&apos;abord un bien pour rattacher vos webhooks.
              </p>
            )}
          </div>
        </div>
      </SettingsCard>

      {/* Dialog création / édition */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? 'Modifier le webhook' : 'Nouveau webhook'}</DialogTitle>
            <DialogDescription>
              RoomScan enverra un POST JSON à votre URL à chaque événement sélectionné.
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            {!editing && (
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="wh-property">Bien concerné</Label>
                <Select
                  value={form.propertyId}
                  onValueChange={(v) => setForm((f) => ({ ...f, propertyId: v }))}
                >
                  <SelectTrigger id="wh-property" aria-label="Bien concerné">
                    <SelectValue placeholder="Choisir un bien" />
                  </SelectTrigger>
                  <SelectContent>
                    {properties.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="wh-name">Nom</Label>
              <Input
                id="wh-name"
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="Ex. Zapier — alertes scans"
                maxLength={60}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="wh-url">URL de réception (https)</Label>
              <Input
                id="wh-url"
                value={form.url}
                onChange={(e) => setForm((f) => ({ ...f, url: e.target.value }))}
                placeholder="https://hooks.zapier.com/…"
                inputMode="url"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label>Événements déclencheurs</Label>
              {WEBHOOK_EVENTS.map((ev) => (
                <label
                  key={ev.key}
                  className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-border bg-background px-3 py-2 text-sm text-foreground transition-colors hover:bg-muted/50"
                >
                  <Checkbox
                    checked={form.events.includes(ev.key)}
                    onCheckedChange={(v) =>
                      setForm((f) => ({
                        ...f,
                        events: v
                          ? [...f.events, ev.key]
                          : f.events.filter((e) => e !== ev.key),
                      }))
                    }
                    aria-label={ev.label}
                  />
                  {ev.label}
                </label>
              ))}
            </div>
          </div>
          <DialogFooter className="mt-2">
            <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
              Annuler
            </Button>
            <Button
              type="button"
              className="air-gradient font-bold text-white"
              disabled={saving}
              onClick={() => void saveWebhook()}
            >
              {saving ? 'Enregistrement…' : editing ? 'Enregistrer' : 'Créer le webhook'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
