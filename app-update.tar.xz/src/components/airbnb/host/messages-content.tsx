'use client';

// =============================================================
// MessagesContent — ONGLET MESSAGES du Dashboard Client (/airbnb/messages)
//
// Centre unifié des entrées invitées :
//   🎙️ Messages vocaux (VoiceMessage) — envoyés via « Contacter l'hôte »
//      du Hub et les modules QR vocaux. Lecture directe via la route
//      /api/uploads/voice/[file] (correction du bug de lecture en
//      standalone). Marquage « lu » automatique à la lecture.
//   🚨 Signalements de problème (GuestComplaint) — envoyés via
//      « Signaler un problème » du Hub. Photos, urgence, résolution.
//   🧹 Ménage : depuis la v4.43, les preuves de ménage (rapports de
//      passage, photos, vocaux de l'équipe) vivent dans l'ONGLET DÉDIÉ
//      « Ménage » (/airbnb/menage) — demandé par le client.
//
// Filtre : suit la propriété sélectionnée dans le header du shell
// (HostContext). Rafraîchissement : bouton + polling 45 s.
//
// v4.60 « AIRBNB PRO » — refonte visuelle uniquement (zéro logique) :
// cartes air-shadow tokens + bulles d'expéditeur tonées, onglets pilules,
// empty states .air-empty, badges dark-safe, CTA air-gradient.
// v4.69 — PHASE 1 refonte UI « messagerie moderne » (maître-détail) :
//   colonne GAUCHE = recherche + segmented Vocaux/Signalements +
//   conversations groupées par expéditeur|bien (avatar air-gradient,
//   aperçu, temps relatif, pastille non-lus) ; colonne DROITE = fil de
//   bulles (invités à gauche, hôte à droite) avec lecteur vocal custom
//   (play/pause + waveform), suppression poubelle + rollback, pied de
//   thread « Répondre par vocal » réutilisant VoiceReplyButton ;
//   signalements affichés pleine largeur dans la colonne droite ;
//   mobile : liste seule puis thread plein écran avec retour.
//   Logique/API inchangées (PATCH read/resolve/read-all, DELETE, 45 s).
// =============================================================
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  ArrowLeft,
  Check,
  FileText,
  Loader2,
  Mic,
  Pause,
  Play,
  RefreshCw,
  Search,
  Trash2,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useRefreshMessageCounts } from '@/components/airbnb/messages-badge';
import { voicePlaybackSrc } from '@/lib/voice-audio';
import { relativeFrTime } from '@/lib/automations';
import { cn } from '@/lib/utils';
// RÉPONSE VOCALE — le propriétaire répond par message vocal enregistré.
import { VoiceReplyButton } from '@/components/airbnb/host/voice-reply-button';
// v4.53 « FICHE ASSURANCE / INVENTAIRE EN 1 CLIC » — PDF pré-rempli
// pour les réclamations de caution (Airbnb / assurance habitation).
import { downloadInsurancePdf } from '@/lib/insurance-pdf';

// ── Types (contrat de /api/airbnb/messages) ──

interface VoiceItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  senderName: string;
  senderType: string;
  audioUrl: string;
  /** v4.32 — copie dataURL en base (lecture durable, v. bug redéploiements). */
  audioData?: string | null;
  durationSec: number;
  fileSizeKb: number;
  isRead: boolean;
  createdAt: string;
}

interface ComplaintItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  category: string;
  description: string;
  photos: string[];
  isUrgent: boolean;
  guestName: string | null;
  status: string;
  /** v4.32 — notification déjà vue (badge rouge éteint une fois lue). */
  isRead?: boolean;
  createdAt: string;
}

/** v4.69 — conversation = groupe de vocaux partageant le même
 *  expéditeur sur le même bien (clé `${senderName}|${propertyId}`). */
interface Conversation {
  key: string;
  senderName: string;
  propertyId: string;
  propertyName: string | null;
  /** Messages triés du plus ancien au plus récent. */
  messages: VoiceItem[];
  lastAt: number;
  /** Nb de vocaux invités non lus (les réponses de l'hôte ne comptent pas). */
  unread: number;
  totalDurationSec: number;
}

type MessagesTab = 'voice' | 'complaints';

/** v4.42 — rapport de passage ménage : DÉPLACÉ dans l'onglet Ménage
 *  (/airbnb/menage, v4.43) — plus affiché ici. */

const COMPLAINT_LABELS: Record<string, { emoji: string; label: string }> = {
  PLUMBING: { emoji: '🚰', label: 'Plomberie' },
  ELECTRICAL: { emoji: '⚡', label: 'Électricité' },
  CLEANING: { emoji: '🧹', label: 'Ménage' },
  // v4.53 — casse invité : bouton « Fiche assurance » pré-remplie.
  BREAKAGE: { emoji: '🫖', label: 'Casse / objet abîmé' },
  OTHER: { emoji: '📝', label: 'Autre' },
};

function complaintMeta(category: string) {
  return COMPLAINT_LABELS[category] ?? COMPLAINT_LABELS.OTHER;
}

/** v4.69 — initiales pour l'avatar dégradé (2 lettres max). */
function initialsOf(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '👤';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

/** v4.69 — aperçu de la dernière ligne de la liste de conversations. */
function previewOf(m: VoiceItem): string {
  if (m.senderType === 'host') return '↩️ Réponse vocale envoyée';
  return m.durationSec > 0 ? `🎙️ Message vocal · ${m.durationSec} s` : '🎙️ Message vocal';
}

/** v4.69 — waveform simulée, déterministe par message (hash du id). */
function waveformFor(id: string): number[] {
  let h = 7;
  for (let i = 0; i < id.length; i += 1) h = (h * 31 + id.charCodeAt(i)) % 997;
  return Array.from({ length: 22 }, (_, i) => {
    h = (h * 33 + i * 7 + 13) % 997;
    return 4 + (h % 13);
  });
}

export function MessagesContent() {
  const { selectedId, selectedProperty, propertiesLoading } = useHostContext();
  // Synchronise le badge du bouton Messages (header + sidebar) dès qu'une
  // action est effectuée sur cette page.
  const refreshCounts = useRefreshMessageCounts();
  const [voice, setVoice] = useState<VoiceItem[] | null>(null);
  const [complaints, setComplaints] = useState<ComplaintItem[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  // WP-BACK v4.61 — vocal en cours de suppression (spinner sur la poubelle).
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // ── v4.69 — état de la messagerie moderne ──
  const [tab, setTab] = useState<MessagesTab>('voice');
  const [search, setSearch] = useState('');
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [showReply, setShowReply] = useState(false);

  // ── v4.53 « FICHE ASSURANCE EN 1 CLIC » — modal d'estimation des
  //    dégâts puis PDF pré-rempli (casse invité). ──
  const [insuranceComplaint, setInsuranceComplaint] = useState<ComplaintItem | null>(null);
  const [insuranceItems, setInsuranceItems] = useState('');
  const [insuranceEstimate, setInsuranceEstimate] = useState('');
  const [insuranceComment, setInsuranceComment] = useState('');
  const [insuranceBusy, setInsuranceBusy] = useState(false);

  const openInsuranceDialog = useCallback((c: ComplaintItem) => {
    setInsuranceComplaint(c);
    // Pré-remplissage : l'objet endommagé est déduit de la description
    // (après l'emoji / préfixe), l'estimation reste à la main de l'hôte.
    const cleaned = c.description.replace(/^[^a-zA-Zà-üÀ-Ü]+/, '').trim();
    setInsuranceItems(cleaned.slice(0, 120));
    setInsuranceEstimate('');
    setInsuranceComment('');
  }, []);

  const generateInsurance = useCallback(async () => {
    const c = insuranceComplaint;
    if (!c) return;
    const estimate = Number(insuranceEstimate.trim().replace(',', '.'));
    if (!Number.isFinite(estimate) || estimate < 0 || estimate > 100_000) {
      toast.error('Indiquez une estimation des dégâts valide (ex. 89,99).');
      return;
    }
    setInsuranceBusy(true);
    try {
      await downloadInsurancePdf({
        propertyName: c.propertyName ?? 'Logement',
        propertyAddress: null,
        guestName: c.guestName,
        reportedAtLabel: new Date(c.createdAt).toLocaleString('fr-FR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        categoryLabel: complaintMeta(c.category).label,
        description: c.description,
        photos: c.photos,
        damagedItems: insuranceItems.trim(),
        damageEstimate: estimate,
        hostComment: insuranceComment.trim(),
        statusLabel: c.status === 'RESOLVED' ? 'Résolu' : 'Ouvert',
      });
      toast.success('Fiche assurance générée — prête à joindre à votre réclamation ✅');
      setInsuranceComplaint(null);
    } catch {
      toast.error('Génération du PDF impossible. Réessayez.');
    } finally {
      setInsuranceBusy(false);
    }
  }, [insuranceComplaint, insuranceEstimate, insuranceItems, insuranceComment]);

  const scopeLabel =
    selectedId === 'all' ? 'Toutes les propriétés' : selectedProperty?.name ?? '';

  const load = useCallback(
    async (mode: 'initial' | 'refresh') => {
      if (mode === 'refresh') setRefreshing(true);
      try {
        const res = await fetch(
          `/api/airbnb/messages?propertyId=${encodeURIComponent(selectedId)}`,
          { cache: 'no-store' },
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as {
          voice: VoiceItem[];
          complaints: ComplaintItem[];
        };
        setVoice(data.voice ?? []);
        setComplaints(data.complaints ?? []);
      } catch {
        if (mode === 'initial') {
          setVoice([]);
        }
        toast.error('Impossible de charger les messages. Réessayez.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedId],
  );

  // Chargement à l'ouverture + à chaque changement de propriété + polling 45 s.
  useEffect(() => {
    setLoading(true);
    void load('initial');
  }, [load]);
  useEffect(() => {
    const poll = setInterval(() => void load('refresh'), 45_000);
    return () => clearInterval(poll);
  }, [load]);

  const voiceUnread = useMemo(() => (voice ?? []).filter((v) => !v.isRead).length, [voice]);
  const complaintsOpen = useMemo(
    () => (complaints ?? []).filter((c) => c.status === 'OPEN').length,
    [complaints],
  );

  // Marquer un vocal comme lu (à la lecture) — optimiste.
  const markVoiceRead = useCallback(async (id: string) => {
    setVoice((prev) => (prev ?? []).map((v) => (v.id === id ? { ...v, isRead: true } : v)));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'voice', id, action: 'read' }),
      });
    } catch {
      // silencieux — l'état optimiste reste, re-synchronisé au prochain poll
    }
  }, []);

  // v4.69 — lecture d'une bulle : marque « lu » (une seule fois) + badge.
  const handleBubblePlay = useCallback(
    (m: VoiceItem) => {
      if (!m.isRead) {
        void markVoiceRead(m.id);
        refreshCounts();
      }
    },
    [markVoiceRead, refreshCounts],
  );

  // ── WP-BACK v4.61 — Suppression définitive d'un vocal (invité OU
  //    réponse hôte) : confirmation → DELETE → retrait optimiste. ──
  const deleteVoice = useCallback(async (id: string) => {
    if (!window.confirm('Supprimer définitivement ce message vocal ?')) return;
    setDeletingId(id);
    const previous = voice;
    setVoice((prev) => (prev ?? []).filter((v) => v.id !== id));
    try {
      const res = await fetch(`/api/airbnb/messages?type=voice&id=${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
      if (!res.ok) {
        const body = (await res.json().catch(() => null)) as { error?: string } | null;
        throw new Error(body?.error || `HTTP ${res.status}`);
      }
      toast.success('Message vocal supprimé 🗑️');
      refreshCounts();
    } catch {
      // Rollback optimiste : la carte réapparaît, re-sync au prochain poll.
      setVoice(previous);
      toast.error('Impossible de supprimer le message vocal. Réessayez.');
    } finally {
      setDeletingId(null);
    }
  }, [voice, refreshCounts]);

  // v4.32 — demande client : « le bouton de notification rouge reste rouge
  // même si la notification est lue ». Ouvrir l'onglet Signalements = tout
  // est considéré vu : le badge rouge s'éteint (les réclamations restent
  // ouvertes jusqu'à résolution, sans allumer le badge).
  const markAllComplaintsSeen = useCallback(async () => {
    setComplaints((prev) => (prev ?? []).map((c) => (c.isRead ? c : { ...c, isRead: true })));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', action: 'read-all' }),
      });
      refreshCounts();
    } catch {
      // silencieux — re-synchronisé au prochain poll
    }
  }, [refreshCounts]);

  // Résoudre un signalement — optimiste + rollback si échec.
  const resolveComplaint = useCallback(async (id: string) => {
    setResolvingId(id);
    const previous = complaints;
    setComplaints((prev) =>
      (prev ?? []).map((c) => (c.id === id ? { ...c, status: 'RESOLVED' } : c)),
    );
    try {
      const res = await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', id, action: 'resolve' }),
      });
      if (!res.ok) throw new Error();
      toast.success('Signalement marqué comme résolu ✅');
      refreshCounts();
    } catch {
      setComplaints(previous);
      toast.error('Impossible de résoudre le signalement. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  }, [complaints]);

  // ── v4.69 — conversations groupées par `${senderName}|${propertyId}`,
  //    les plus récentes d'abord ; messages triés du plus ancien au + récent. ──
  const conversations = useMemo(() => {
    const map = new Map<string, Conversation>();
    for (const m of voice ?? []) {
      const key = `${m.senderName}|${m.propertyId}`;
      let c = map.get(key);
      if (!c) {
        c = {
          key,
          senderName: m.senderName,
          propertyId: m.propertyId,
          propertyName: m.propertyName,
          messages: [],
          lastAt: 0,
          unread: 0,
          totalDurationSec: 0,
        };
        map.set(key, c);
      }
      c.messages.push(m);
      c.lastAt = Math.max(c.lastAt, new Date(m.createdAt).getTime());
      // Pastille non-lus = isRead=false (même sémantique que le badge serveur).
      if (!m.isRead) c.unread += 1;
      c.totalDurationSec += m.durationSec ?? 0;
    }
    const list = Array.from(map.values());
    for (const c of list) {
      c.messages.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    }
    list.sort((a, b) => b.lastAt - a.lastAt);
    return list;
  }, [voice]);

  const filteredConversations = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) =>
        c.senderName.toLowerCase().includes(q) ||
        (c.propertyName ?? '').toLowerCase().includes(q),
    );
  }, [conversations, search]);

  const filteredComplaints = useMemo(() => {
    const list = complaints ?? [];
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((c) =>
      [
        c.guestName ?? '',
        c.propertyName ?? '',
        complaintMeta(c.category).label,
        c.description,
      ]
        .join(' ')
        .toLowerCase()
        .includes(q),
    );
  }, [complaints, search]);

  const selectedConversation = useMemo(
    () => filteredConversations.find((c) => c.key === selectedKey) ?? null,
    [filteredConversations, selectedKey],
  );

  const openConversation = useCallback((key: string) => {
    setSelectedKey(key);
    setShowReply(false);
  }, []);

  const switchTab = useCallback(
    (t: MessagesTab) => {
      setTab(t);
      if (t === 'complaints') void markAllComplaintsSeen();
    },
    [markAllComplaintsSeen],
  );

  const handleReplySent = useCallback(() => {
    setShowReply(false);
    void load('refresh');
  }, [load]);

  if (loading && voice === null) {
    return (
      <div className="flex flex-col gap-4 lg:flex-row">
        <div className="flex w-full shrink-0 flex-col gap-3 rounded-2xl border border-border bg-card p-3 lg:w-80">
          <Skeleton className="h-10 w-full rounded-full" aria-hidden="true" />
          <Skeleton className="h-11 w-full rounded-full" aria-hidden="true" />
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-16 w-full rounded-xl" aria-hidden="true" />
          ))}
        </div>
        <div className="hidden min-w-0 flex-1 flex-col gap-3 rounded-2xl border border-border bg-card p-4 lg:flex">
          <Skeleton className="h-14 w-full rounded-xl" aria-hidden="true" />
          <Skeleton className="h-20 w-2/3 rounded-2xl" aria-hidden="true" />
          <Skeleton className="h-20 w-1/2 rounded-2xl" aria-hidden="true" />
        </div>
      </div>
    );
  }

  const lastGuestMessage = selectedConversation
    ? [...selectedConversation.messages].reverse().find((m) => m.senderType !== 'host') ?? null
    : null;
  const replyTargetId =
    lastGuestMessage?.id ??
    (selectedConversation && selectedConversation.messages.length > 0
      ? selectedConversation.messages[selectedConversation.messages.length - 1].id
      : undefined);

  return (
    <div className="flex flex-col gap-4">
      {/* ----- En-tête ----- */}
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"
      >
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight text-foreground">
            <span aria-hidden="true">💬</span> Messagerie
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Vocaux et signalements — {propertiesLoading ? 'chargement…' : scopeLabel}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          disabled={refreshing}
          className="gap-2 self-start rounded-full sm:self-auto"
          aria-label="Rafraîchir les messages"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden="true" />
          Rafraîchir
        </Button>
      </motion.div>

      {/* ----- Zone maître-détail ----- */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-stretch">
        {/* ── Colonne GAUCHE : recherche + onglets + conversations ── */}
        {tab === 'voice' && (
          <aside
            aria-label="Liste des conversations"
            className={cn(
              'air-shadow w-full shrink-0 flex-col gap-3 rounded-2xl border border-border bg-card p-3 lg:h-[calc(100dvh-210px)] lg:w-80',
              selectedKey ? 'hidden lg:flex' : 'flex',
            )}
          >
            {/* Recherche par nom */}
            <div className="relative">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                aria-hidden="true"
              />
              <Input
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Rechercher un nom…"
                className="h-10 rounded-full bg-muted/40 pl-9 text-sm"
                aria-label="Rechercher une conversation par nom"
              />
            </div>

            {/* Segmented control Vocaux / Signalements */}
            <SegmentedTabs
              tab={tab}
              onChange={switchTab}
              voiceUnread={voiceUnread}
              complaintsOpen={complaintsOpen}
            />

            {/* Liste des conversations */}
            <div className="scrollbar-thin-light -mx-1 max-h-[46dvh] min-h-0 flex-1 overflow-y-auto px-1 lg:max-h-none">
              {conversations.length === 0 ? (
                <div className="air-empty flex flex-col items-center rounded-2xl p-6 text-center">
                  <span className="air-float text-3xl" aria-hidden="true">🎙️</span>
                  <h3 className="mt-3 text-sm font-semibold text-foreground">Aucun message vocal</h3>
                  <p className="mt-1.5 max-w-[240px] text-xs text-muted-foreground">
                    Les messages vocaux laissés par vos invités (bouton « Contacter l&apos;hôte »
                    de la plaque QR) apparaîtront ici.
                  </p>
                </div>
              ) : filteredConversations.length === 0 ? (
                <div className="air-empty flex flex-col items-center rounded-2xl p-6 text-center">
                  <span className="text-2xl" aria-hidden="true">🔍</span>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Aucune conversation pour « {search.trim()} ».
                  </p>
                </div>
              ) : (
                <ul className="flex flex-col gap-1.5">
                  {filteredConversations.map((c) => {
                    const last = c.messages[c.messages.length - 1];
                    const active = selectedKey === c.key;
                    return (
                      <li key={c.key}>
                        <button
                          type="button"
                          onClick={() => openConversation(c.key)}
                          aria-current={active || undefined}
                          className={cn(
                            'flex w-full items-center gap-3 rounded-xl border p-2.5 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50',
                            active
                              ? 'border-[#0066EF]/40 bg-[#0066EF]/5 dark:bg-[#0066EF]/10'
                              : 'border-transparent hover:bg-muted/60',
                          )}
                        >
                          <span className="relative shrink-0">
                            <Avatar name={c.senderName} className="h-10 w-10 text-xs" />
                            {c.unread > 0 && (
                              <span
                                aria-label={`${c.unread} message${c.unread > 1 ? 's' : ''} non lu${c.unread > 1 ? 's' : ''}`}
                                className="absolute -right-1.5 -top-1.5 flex h-5 min-w-5 items-center justify-center rounded-full border-2 border-card bg-[#0066EF] px-1 text-[9px] font-bold text-white"
                              >
                                {c.unread > 9 ? '9+' : c.unread}
                              </span>
                            )}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="flex items-center justify-between gap-2">
                              <span
                                className={cn(
                                  'truncate text-sm text-foreground',
                                  c.unread > 0 ? 'font-bold' : 'font-semibold',
                                )}
                              >
                                {c.senderName}
                              </span>
                              <span className="shrink-0 text-[10px] tabular-nums text-muted-foreground/80">
                                {relativeFrTime(new Date(c.lastAt).toISOString())}
                              </span>
                            </span>
                            <span className="mt-0.5 flex items-center justify-between gap-2">
                              <span
                                className={cn(
                                  'truncate text-xs',
                                  c.unread > 0
                                    ? 'font-semibold text-[#0066EF] dark:text-[#8FB8FF]'
                                    : 'text-muted-foreground',
                                )}
                              >
                                {previewOf(last)}
                              </span>
                            </span>
                            {c.propertyName && (
                              <span className="mt-0.5 block truncate text-[10px] font-medium text-muted-foreground/70">
                                🏠 {c.propertyName}
                              </span>
                            )}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </aside>
        )}

        {/* ── Colonne DROITE (mode Vocaux) : fil de discussion ── */}
        {tab === 'voice' && (
          <section
            aria-label="Fil de discussion"
            className={cn(
              'air-shadow min-h-[420px] min-w-0 flex-1 flex-col overflow-hidden rounded-2xl border border-border bg-card max-h-[78dvh] lg:h-[calc(100dvh-210px)] lg:max-h-none',
              selectedKey ? 'flex' : 'hidden lg:flex',
            )}
          >
            {selectedConversation ? (
              <div key={selectedConversation.key} className="flex min-h-0 flex-1 flex-col">
                {/* En-tête du thread */}
                <div className="flex items-center gap-3 border-b border-border p-3 sm:px-4">
                  <button
                    type="button"
                    onClick={() => setSelectedKey(null)}
                    aria-label="Retour à la liste des conversations"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50 lg:hidden"
                  >
                    <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                  </button>
                  <Avatar name={selectedConversation.senderName} className="h-10 w-10 text-xs" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-foreground">
                      {selectedConversation.senderName}
                    </p>
                    <p className="truncate text-[11px] text-muted-foreground">
                      {selectedConversation.propertyName ?? 'Bien'} ·{' '}
                      {selectedConversation.messages.length} message
                      {selectedConversation.messages.length > 1 ? 's' : ''} ·{' '}
                      {selectedConversation.totalDurationSec} s de vocal
                    </p>
                  </div>
                  {selectedConversation.unread > 0 && (
                    <Badge className="shrink-0 rounded-full bg-[#0066EF] text-[10px] font-bold text-white hover:bg-[#0066EF]">
                      {selectedConversation.unread} non lu
                      {selectedConversation.unread > 1 ? 's' : ''}
                    </Badge>
                  )}
                </div>

                {/* Fil de bulles */}
                <div className="scrollbar-thin-light flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto p-3 sm:p-4">
                  {selectedConversation.messages.map((m) => (
                    <VoiceBubble
                      key={m.id}
                      m={m}
                      onFirstPlay={handleBubblePlay}
                      onDelete={(id) => void deleteVoice(id)}
                      deleting={deletingId === m.id}
                    />
                  ))}
                </div>

                {/* Pied de thread : réponse vocale */}
                <div className="border-t border-border p-3">
                  {showReply ? (
                    <div className="flex flex-col gap-2">
                      <VoiceReplyButton
                        voiceMessageId={replyTargetId}
                        onSent={handleReplySent}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-7 self-center rounded-full text-muted-foreground"
                        onClick={() => setShowReply(false)}
                        aria-label="Annuler la réponse vocale"
                      >
                        Annuler
                      </Button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setShowReply(true)}
                      aria-label="Répondre par message vocal"
                      className="flex w-full items-center justify-between gap-3 rounded-full border border-border bg-muted/40 py-1.5 pl-4 pr-1.5 text-left transition-colors hover:border-[#0066EF]/40 hover:bg-muted/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50"
                    >
                      <span className="text-sm text-muted-foreground">Répondre par vocal…</span>
                      <span
                        aria-hidden="true"
                        className="air-gradient flex h-9 w-9 items-center justify-center rounded-full text-white shadow"
                      >
                        <Mic className="h-4 w-4" />
                      </span>
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="air-empty flex flex-1 flex-col items-center justify-center rounded-2xl p-8 text-center">
                <span className="air-float text-3xl" aria-hidden="true">💬</span>
                <h3 className="mt-3 text-sm font-semibold text-foreground">
                  Sélectionnez une conversation
                </h3>
                <p className="mt-1.5 max-w-xs text-xs text-muted-foreground">
                  Choisissez un échange dans la liste de gauche pour écouter les vocaux et
                  répondre.
                </p>
              </div>
            )}
          </section>
        )}

        {/* ── Colonne DROITE (mode Signalements) : cartes réclamations ── */}
        {tab === 'complaints' && (
          <section aria-label="Signalements de problème" className="flex min-w-0 flex-1 flex-col gap-3">
            {/* Barre d'outils compacte (le panneau gauche est masqué dans ce mode) */}
            <div className="air-shadow flex flex-col gap-2.5 rounded-2xl border border-border bg-card p-3 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search
                  className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground"
                  aria-hidden="true"
                />
                <Input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Rechercher un signalement…"
                  className="h-10 rounded-full bg-muted/40 pl-9 text-sm"
                  aria-label="Rechercher un signalement"
                />
              </div>
              <SegmentedTabs
                tab={tab}
                onChange={switchTab}
                voiceUnread={voiceUnread}
                complaintsOpen={complaintsOpen}
              />
            </div>

            <div className="scrollbar-thin-light flex max-h-[70dvh] flex-col gap-3 overflow-y-auto pr-1 lg:max-h-[calc(100dvh-230px)]">
              {(complaints ?? []).length === 0 ? (
                <div className="air-empty flex flex-col items-center rounded-2xl p-8 text-center">
                  <span className="air-float text-3xl" aria-hidden="true">🚨</span>
                  <h3 className="mt-3 text-sm font-semibold text-foreground">Aucun signalement</h3>
                  <p className="mt-1.5 max-w-sm text-xs text-muted-foreground">
                    Les problèmes signalés par vos invités (bouton « Signaler un problème »
                    de la plaque QR) arriveront ici, connectés au bouton Messages.
                  </p>
                </div>
              ) : filteredComplaints.length === 0 ? (
                <div className="air-empty flex flex-col items-center rounded-2xl p-8 text-center">
                  <span className="text-2xl" aria-hidden="true">🔍</span>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Aucun signalement pour « {search.trim()} ».
                  </p>
                </div>
              ) : (
                filteredComplaints.map((c) => {
                  const meta = complaintMeta(c.category);
                  const isOpen = c.status === 'OPEN';
                  return (
                    <Card
                      key={c.id}
                      className={cn(
                        'air-shadow rounded-2xl bg-card',
                        isOpen
                          ? c.isUrgent
                            ? 'border-red-300 bg-red-50/50 dark:border-red-500/40 dark:bg-red-500/10'
                            : 'border-border'
                          : 'border-border opacity-70',
                      )}
                    >
                      <CardContent className="space-y-2.5 p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex min-w-0 items-start gap-3">
                            <span
                              aria-hidden="true"
                              className={cn(
                                'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg text-white shadow',
                                isOpen && c.isUrgent ? 'kpi-bubble-rausch' : 'kpi-bubble-orange',
                              )}
                            >
                              {meta.emoji}
                            </span>
                            <div className="min-w-0">
                              <p className="flex flex-wrap items-center gap-2 text-sm font-bold text-foreground">
                                {meta.label}
                                {/* v4.32 — point rouge tant que la notification n'a pas été vue. */}
                                {isOpen && c.isRead === false && (
                                  <span
                                    aria-label="Non lue"
                                    className="h-2 w-2 shrink-0 rounded-full bg-[#0066EF]"
                                  />
                                )}
                                {c.isUrgent && isOpen && (
                                  <Badge className="rounded-full bg-red-500 text-[10px] font-bold text-white hover:bg-red-500">
                                    ⚠️ URGENT
                                  </Badge>
                                )}
                                {!isOpen && (
                                  <Badge className="rounded-full bg-emerald-600 text-[10px] font-bold text-white hover:bg-emerald-600">
                                    <Check className="mr-0.5 h-3 w-3" aria-hidden="true" /> Résolu
                                  </Badge>
                                )}
                              </p>
                              <p className="mt-0.5 text-[11px] text-muted-foreground">
                                {relativeFrTime(c.createdAt)}
                                {c.propertyName ? ` · ${c.propertyName}` : ''}
                                {c.guestName ? ` · ${c.guestName}` : ''}
                              </p>
                            </div>
                          </div>
                        </div>

                        <p className="whitespace-pre-wrap break-words text-sm text-foreground">
                          {c.description}
                        </p>

                        {c.photos.length > 0 && (
                          <div className="flex flex-wrap items-center gap-2">
                            {c.photos.map((p, i) => (
                              <a key={i} href={p} target="_blank" rel="noopener noreferrer">
                                {/* Photos stockées en data-URL (≤ 500 Ko) par l'API Hub */}
                                <img
                                  src={p}
                                  alt={`Photo du signalement ${i + 1}`}
                                  className="h-16 w-16 rounded-xl border border-border object-cover transition-opacity hover:opacity-90"
                                  loading="lazy"
                                  decoding="async"
                                />
                              </a>
                            ))}
                          </div>
                        )}

                        {isOpen && (
                          <div className="mt-1 flex flex-wrap items-center gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              disabled={resolvingId === c.id}
                              onClick={() => void resolveComplaint(c.id)}
                              className="h-8 rounded-full border-blue-300 font-semibold text-blue-700 hover:bg-blue-50 dark:border-blue-500/40 dark:text-blue-400 dark:hover:bg-blue-500/10"
                            >
                              {resolvingId === c.id ? (
                                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                              ) : (
                                <Check className="h-3.5 w-3.5" aria-hidden="true" />
                              )}
                              Marquer résolu
                            </Button>
                            {/* v4.53 « FICHE ASSURANCE EN 1 CLIC » — estimation
                                des dégâts + rapport PDF pré-rempli (caution
                                Airbnb / assurance habitation). */}
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              onClick={() => openInsuranceDialog(c)}
                              className="h-8 rounded-full font-semibold text-foreground hover:bg-muted"
                              aria-label="Générer la fiche assurance PDF"
                            >
                              <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                              Fiche assurance
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </section>
        )}
      </div>

      {/* ── v4.53 « FICHE ASSURANCE EN 1 CLIC » — estimation des dégâts
          puis rapport PDF pré-rempli (photos + description + montant). ── */}
      <Dialog open={!!insuranceComplaint} onOpenChange={(o) => !o && setInsuranceComplaint(null)}>
        <DialogContent className="max-w-lg rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-foreground">
              🫖 Fiche assurance / dépôt de garantie
            </DialogTitle>
            <DialogDescription>
              Le rapport PDF est pré-rempli avec le signalement, les photos et le logement.
              Complétez l&apos;estimation des dégâts — le document est prêt pour Airbnb ou votre
              assurance habitation.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <div className="rounded-xl bg-muted/50 p-3 text-xs text-muted-foreground">
              <p className="font-semibold text-foreground">
                {insuranceComplaint
                  ? `${complaintMeta(insuranceComplaint.category).emoji} ${complaintMeta(insuranceComplaint.category).label}`
                  : ''}
                {insuranceComplaint?.guestName ? ` — ${insuranceComplaint.guestName}` : ''}
              </p>
              <p className="mt-0.5">
                {insuranceComplaint
                  ? new Date(insuranceComplaint.createdAt).toLocaleString('fr-FR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : ''}
                {insuranceComplaint?.propertyName ? ` · ${insuranceComplaint.propertyName}` : ''}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-items" className="text-xs font-semibold text-muted-foreground">
                Objet(s) endommagé(s)
              </Label>
              <Input
                id="insurance-items"
                value={insuranceItems}
                onChange={(e) => setInsuranceItems(e.target.value)}
                maxLength={120}
                placeholder="Ex. : machine à café Delonghi, verre à pied…"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-estimate" className="text-xs font-semibold text-muted-foreground">
                Estimation des dégâts (€)
              </Label>
              <Input
                id="insurance-estimate"
                inputMode="decimal"
                value={insuranceEstimate}
                onChange={(e) => setInsuranceEstimate(e.target.value)}
                maxLength={10}
                placeholder="89,99"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-comment" className="text-xs font-semibold text-muted-foreground">
                Commentaire (optionnel)
              </Label>
              <Textarea
                id="insurance-comment"
                value={insuranceComment}
                onChange={(e) => setInsuranceComment(e.target.value)}
                maxLength={600}
                rows={3}
                placeholder="Contexte, échanges avec l'invité, remplacement prévu…"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              className="rounded-full"
              onClick={() => setInsuranceComplaint(null)}
            >
              Annuler
            </Button>
            <Button
              type="button"
              onClick={() => void generateInsurance()}
              disabled={insuranceBusy}
              className="air-gradient rounded-full font-semibold text-white shadow hover:opacity-95"
            >
              {insuranceBusy ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <FileText className="h-4 w-4" aria-hidden="true" />
              )}
              Générer le PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// =============================================================
// Helpers de rendu (v4.69 — messagerie moderne)
// =============================================================

/** Avatar initiales sur dégradé bleu (design system .air-gradient). */
function Avatar({ name, className }: { name: string; className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={cn(
        'air-gradient flex shrink-0 items-center justify-center rounded-full font-bold text-white shadow',
        className ?? 'h-9 w-9 text-xs',
      )}
    >
      {initialsOf(name)}
    </span>
  );
}

/** Segmented control 🎙️ Vocaux / 🚨 Signalements (avec pastilles). */
function SegmentedTabs({
  tab,
  onChange,
  voiceUnread,
  complaintsOpen,
}: {
  tab: MessagesTab;
  onChange: (t: MessagesTab) => void;
  voiceUnread: number;
  complaintsOpen: number;
}) {
  const base =
    'flex h-9 items-center justify-center gap-1.5 rounded-full px-3 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50';
  return (
    <div className="grid grid-cols-2 gap-1 rounded-full bg-muted p-1" role="tablist" aria-label="Filtrer les messages">
      <button
        type="button"
        role="tab"
        aria-selected={tab === 'voice'}
        onClick={() => onChange('voice')}
        className={cn(base, tab === 'voice' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}
      >
        <span aria-hidden="true">🎙️</span> Vocaux
        {voiceUnread > 0 && (
          <span className="ml-0.5 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#0066EF] px-1 text-[10px] font-bold text-white">
            {voiceUnread > 9 ? '9+' : voiceUnread}
          </span>
        )}
      </button>
      <button
        type="button"
        role="tab"
        aria-selected={tab === 'complaints'}
        onClick={() => onChange('complaints')}
        className={cn(base, tab === 'complaints' ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground')}
      >
        <span aria-hidden="true">🚨</span> Signalements
        {complaintsOpen > 0 && (
          <span className="ml-0.5 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-white">
            {complaintsOpen > 9 ? '9+' : complaintsOpen}
          </span>
        )}
      </button>
    </div>
  );
}

/** Bulle vocale : lecteur custom (play/pause + waveform simulée),
 *  suppression poubelle (confirm + DELETE + rollback côté parent). */
function VoiceBubble({
  m,
  onFirstPlay,
  onDelete,
  deleting,
}: {
  m: VoiceItem;
  onFirstPlay: (m: VoiceItem) => void;
  onDelete: (id: string) => void;
  deleting: boolean;
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const bars = useMemo(() => waveformFor(m.id), [m.id]);
  const isHost = m.senderType === 'host';

  const togglePlay = () => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) {
      el.pause();
      return;
    }
    void el.play().catch(() => toast.error('Lecture de ce vocal impossible.'));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className={cn('flex flex-col gap-0.5', isHost ? 'items-end' : 'items-start')}
    >
      <div className={cn('flex max-w-[88%] items-center gap-1.5 sm:max-w-[75%]', isHost && 'flex-row-reverse')}>
        <Avatar name={m.senderName} className="h-7 w-7 text-[9px]" />
        <div
          className={cn(
            'flex items-center gap-2 rounded-2xl px-2.5 py-2',
            isHost
              ? 'rounded-tr-md border border-[#0066EF]/30 bg-[#0066EF]/10 dark:border-[#3B82F6]/40'
              : 'rounded-tl-md border border-border bg-slate-100 dark:border-slate-700 dark:bg-slate-800/70',
          )}
        >
          <button
            type="button"
            onClick={togglePlay}
            aria-label={playing ? `Mettre en pause le message de ${m.senderName}` : `Écouter le message de ${m.senderName}`}
            className="air-gradient flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-white shadow transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50"
          >
            {playing ? (
              <Pause className="h-4 w-4" aria-hidden="true" />
            ) : (
              <Play className="ml-0.5 h-4 w-4" aria-hidden="true" />
            )}
          </button>
          <span className="flex h-7 items-center gap-[2.5px]" aria-hidden="true">
            {bars.map((h, i) => (
              <span
                key={i}
                style={{ height: `${h}px` }}
                className={cn(
                  'w-[3px] rounded-full transition-colors',
                  playing ? 'bg-[#0066EF] dark:bg-[#3B82F6]' : 'bg-slate-300 dark:bg-slate-600',
                )}
              />
            ))}
          </span>
          {m.durationSec > 0 && (
            <span className="shrink-0 text-[11px] font-bold tabular-nums text-muted-foreground">
              {m.durationSec} s
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={() => onDelete(m.id)}
          disabled={deleting}
          aria-label="Supprimer ce message vocal"
          title="Supprimer ce message vocal"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-rose-400 transition-colors hover:bg-rose-50 hover:text-rose-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-rose-400 disabled:opacity-50 dark:hover:bg-rose-950/40"
        >
          {deleting ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
          ) : (
            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
          )}
        </button>
      </div>
      <p className={cn('px-1 text-[10px] text-muted-foreground/80', isHost && 'text-right')}>
        {relativeFrTime(m.createdAt)}
        {m.fileSizeKb > 0 ? ` · ${m.fileSizeKb} Ko` : ''}
      </p>
      {/* Élément audio piloté par le bouton custom — onPlay déclenche le
          marquage « lu » (logique conservée de la liste à plat). */}
      <audio
        ref={audioRef}
        src={voicePlaybackSrc(m.audioData, m.audioUrl)}
        preload="metadata"
        className="hidden"
        onPlay={() => {
          setPlaying(true);
          onFirstPlay(m);
        }}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
        onError={() => toast.error('Lecture de ce vocal impossible.')}
      />
    </motion.div>
  );
}
