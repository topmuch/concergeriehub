'use client';

// =============================================================
// MessagesContent — ONGLET MESSAGES du Dashboard Client (/airbnb/messages)
//
// Centre unifié des entrées invitées :
//   🎙️ Messages vocaux (VoiceMessage) — envoyés via « Contacter l'hôte »
//      du Hub et les modules QR vocaux. Lecture directe via la route
//      /api/uploads/voice/[file] (correction du bug de lecture en
//      standalone). Marquage « lu » automatique à la lecture.
//   🚨 Signalements de problème (GuestComplaint) — envoyés via
//      « Signaler un problème » du Hub. Photos, urgence, résolution.
//   🧹 Suivi Ménage (CleaningReport, v4.42) — rapports créés par la
//      femme de ménage depuis le Hub (bouton « Mode Ménage ») :
//      horaires, checklist de validation et photo de l'appartement.
//      Lecture seule : le badge Messages ne compte PAS ces rapports.
//
// Filtre : suit la propriété sélectionnée dans le header du shell
// (HostContext). Rafraîchissement : bouton + polling 45 s.
// =============================================================
import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Check, ChevronDown, Loader2, RefreshCw } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useRefreshMessageCounts } from '@/components/airbnb/messages-badge';
import { voicePlaybackSrc } from '@/lib/voice-audio';
import { relativeFrTime } from '@/lib/automations';
// RÉPONSE VOCALE — le propriétaire répond par message vocal enregistré.
import { VoiceReplyButton } from '@/components/airbnb/host/voice-reply-button';

// ── Types (contrat de /api/airbnb/messages) ──

interface VoiceItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  senderName: string;
  senderType: string;
  audioUrl: string;
  /** v4.32 — copie dataURL en base (lecture durable, v. bug redéploiements). */
  audioData?: string | null;
  durationSec: number;
  fileSizeKb: number;
  isRead: boolean;
  createdAt: string;
}

interface ComplaintItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  category: string;
  description: string;
  photos: string[];
  isUrgent: boolean;
  guestName: string | null;
  status: string;
  /** v4.32 — notification déjà vue (badge rouge éteint une fois lue). */
  isRead?: boolean;
  createdAt: string;
}

/** v4.42 — rapport de passage ménage (journal CleaningReport créé par
 *  la femme de ménage depuis le Hub, bouton « Mode Ménage »). */
interface CleaningReport {
  id: string;
  propertyId: string;
  propertyName: string | null;
  staffName: string | null;
  checklist: { label: string; done: boolean }[];
  /** 1ʳᵉ photo de l'appartement propre (dataURL). */
  coverPhoto: string | null;
  /** Nombre total de photos (cover incluse). */
  photoCount: number;
  /** Arrivée du staff (ISO) — null si validation sans pointage d'arrivée. */
  startedAt: string | null;
  /** Validation / départ du staff (ISO). */
  endedAt: string | null;
  createdAt: string;
}

const COMPLAINT_LABELS: Record<string, { emoji: string; label: string }> = {
  PLUMBING: { emoji: '🚰', label: 'Plomberie' },
  ELECTRICAL: { emoji: '⚡', label: 'Électricité' },
  CLEANING: { emoji: '🧹', label: 'Ménage' },
  OTHER: { emoji: '📝', label: 'Autre' },
};

function complaintMeta(category: string) {
  return COMPLAINT_LABELS[category] ?? COMPLAINT_LABELS.OTHER;
}

// v4.42 — formats date/heure FR pour les rapports de ménage
// (rendu 100 % client : aucun risque d'hydratation).
function formatFrDateTime(iso: string): string {
  return new Date(iso).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatFrTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('fr-FR', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function MessagesContent() {
  const { selectedId, selectedProperty, propertiesLoading } = useHostContext();
  // Synchronise le badge du bouton Messages (header + sidebar) dès qu'une
  // action est effectuée sur cette page.
  const refreshCounts = useRefreshMessageCounts();
  const [voice, setVoice] = useState<VoiceItem[] | null>(null);
  const [complaints, setComplaints] = useState<ComplaintItem[] | null>(null);
  // v4.42 — journal des passages ménage (onglet « 🧹 Ménage »).
  const [cleaningReports, setCleaningReports] = useState<CleaningReport[] | null>(null);
  // v4.42 — checklists détaillées dépliées (Set : plusieurs rapports
  // peuvent être ouverts en même temps).
  const [expandedReports, setExpandedReports] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  const scopeLabel =
    selectedId === 'all' ? 'Toutes les propriétés' : selectedProperty?.name ?? '';

  const load = useCallback(
    async (mode: 'initial' | 'refresh') => {
      if (mode === 'refresh') setRefreshing(true);
      try {
        const res = await fetch(
          `/api/airbnb/messages?propertyId=${encodeURIComponent(selectedId)}`,
          { cache: 'no-store' },
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as {
          voice: VoiceItem[];
          complaints: ComplaintItem[];
          cleaningReports: CleaningReport[];
        };
        setVoice(data.voice ?? []);
        setComplaints(data.complaints ?? []);
        setCleaningReports(data.cleaningReports ?? []);
      } catch {
        if (mode === 'initial') {
          setVoice([]);
          setCleaningReports([]);
        }
        toast.error('Impossible de charger les messages. Réessayez.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedId],
  );

  // Chargement à l'ouverture + à chaque changement de propriété + polling 45 s.
  useEffect(() => {
    setLoading(true);
    void load('initial');
  }, [load]);
  useEffect(() => {
    const poll = setInterval(() => void load('refresh'), 45_000);
    return () => clearInterval(poll);
  }, [load]);

  const voiceUnread = useMemo(() => (voice ?? []).filter((v) => !v.isRead).length, [voice]);
  const complaintsOpen = useMemo(
    () => (complaints ?? []).filter((c) => c.status === 'OPEN').length,
    [complaints],
  );

  // v4.42 — rapports de ménage, les plus récents d'abord (l'API renvoie
  // déjà createdAt desc ; tri défensif par fin de passage).
  const cleaningSorted = useMemo(
    () =>
      [...(cleaningReports ?? [])].sort(
        (a, b) =>
          new Date(b.endedAt ?? b.createdAt).getTime() -
          new Date(a.endedAt ?? a.createdAt).getTime(),
      ),
    [cleaningReports],
  );

  // v4.42 — déplier/replier le détail de checklist d'un rapport.
  const toggleReportDetail = useCallback((id: string) => {
    setExpandedReports((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  }, []);

  // Marquer un vocal comme lu (à la lecture) — optimiste.
  const markVoiceRead = useCallback(async (id: string) => {
    setVoice((prev) => (prev ?? []).map((v) => (v.id === id ? { ...v, isRead: true } : v)));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'voice', id, action: 'read' }),
      });
    } catch {
      // silencieux — l'état optimiste reste, re-synchronisé au prochain poll
    }
  }, []);

  // v4.32 — demande client : « le bouton de notification rouge reste rouge
  // même si la notification est lue ». Ouvrir l'onglet Signalements = tout
  // est considéré vu : le badge rouge s'éteint (les réclamations restent
  // ouvertes jusqu'à résolution, sans allumer le badge).
  const markAllComplaintsSeen = useCallback(async () => {
    setComplaints((prev) => (prev ?? []).map((c) => (c.isRead ? c : { ...c, isRead: true })));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', action: 'read-all' }),
      });
      refreshCounts();
    } catch {
      // silencieux — re-synchronisé au prochain poll
    }
  }, [refreshCounts]);

  // Résoudre un signalement — optimiste + rollback si échec.
  const resolveComplaint = useCallback(async (id: string) => {
    setResolvingId(id);
    const previous = complaints;
    setComplaints((prev) =>
      (prev ?? []).map((c) => (c.id === id ? { ...c, status: 'RESOLVED' } : c)),
    );
    try {
      const res = await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', id, action: 'resolve' }),
      });
      if (!res.ok) throw new Error();
      toast.success('Signalement marqué comme résolu ✅');
      refreshCounts();
    } catch {
      setComplaints(previous);
      toast.error('Impossible de résoudre le signalement. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  }, [complaints]);

  if (loading && voice === null) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-9 w-64" />
        <Skeleton className="h-11 w-full max-w-md rounded-xl" />
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl">
      {/* ----- En-tête ----- */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <span aria-hidden="true">💬</span> Messages
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Vocaux, signalements et suivi ménage — {scopeLabel}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          disabled={refreshing}
          className="gap-2 rounded-xl self-start sm:self-auto"
          aria-label="Rafraîchir les messages"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden="true" />
          Rafraîchir
        </Button>
      </div>

      {/* ----- Onglets Vocaux / Signalements ----- */}
      <Tabs
        defaultValue="voice"
        onValueChange={(v) => {
          if (v === 'complaints') void markAllComplaintsSeen();
        }}
      >
        <TabsList className="h-11 max-w-full rounded-xl bg-slate-100 p-1 overflow-x-auto custom-scrollbar">
          <TabsTrigger
            value="voice"
            className="rounded-lg px-4 text-sm font-semibold data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            🎙️ Vocaux
            {voiceUnread > 0 && (
              <Badge className="ml-2 bg-[#E23F2B] text-white hover:bg-[#E23F2B] h-5 min-w-5 px-1.5 text-[10px] font-bold">
                {voiceUnread > 9 ? '9+' : voiceUnread}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger
            value="complaints"
            className="rounded-lg px-4 text-sm font-semibold data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            🚨 Signalements
            {complaintsOpen > 0 && (
              <Badge className="ml-2 bg-amber-500 text-white hover:bg-amber-500 h-5 min-w-5 px-1.5 text-[10px] font-bold">
                {complaintsOpen > 9 ? '9+' : complaintsOpen}
              </Badge>
            )}
          </TabsTrigger>
          {/* v4.42 — suivi ménage : badge = nombre de rapports (compteur
              neutre, n'alimente PAS le badge Messages global). */}
          <TabsTrigger
            value="cleaning"
            className="rounded-lg px-4 text-sm font-semibold data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            🧹 Ménage
            {cleaningSorted.length > 0 && (
              <Badge className="ml-2 bg-emerald-600 text-white hover:bg-emerald-600 h-5 min-w-5 px-1.5 text-[10px] font-bold">
                {cleaningSorted.length > 9 ? '9+' : cleaningSorted.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ───────── Vocaux ───────── */}
        <TabsContent value="voice" className="mt-4">
          {(voice ?? []).length === 0 ? (
            <Card className="rounded-2xl border-dashed bg-white">
              <CardContent className="py-14 flex flex-col items-center text-center">
                <div className="h-14 w-14 rounded-2xl bg-emerald-50 flex items-center justify-center mb-3">
                  <span className="text-2xl" aria-hidden="true">🎙️</span>
                </div>
                <h3 className="font-semibold text-slate-900">Aucun message vocal</h3>
                <p className="text-sm text-slate-500 mt-1.5 max-w-sm">
                  Les messages vocaux laissés par vos invités (bouton « Contacter l&apos;hôte »
                  de la plaque QR) apparaîtront ici.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3 max-h-[62vh] overflow-y-auto custom-scrollbar pr-1">
              {(voice ?? []).map((m) => (
                <Card
                  key={m.id}
                  className={`rounded-2xl bg-white transition-colors ${m.isRead ? '' : 'border-[#E23F2B]/30 bg-[#FEF1EF]/40'}`}
                >
                  <CardContent className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-slate-900 flex items-center gap-2">
                          <span aria-hidden="true" className="text-base">🎙️</span>
                          {m.senderName}
                          {!m.isRead && (
                            <span
                              aria-label="Non lu"
                              className="h-2 w-2 rounded-full bg-[#E23F2B] shrink-0"
                            />
                          )}
                        </p>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {relativeFrTime(m.createdAt)}
                          {m.propertyName ? ` · ${m.propertyName}` : ''}
                        </p>
                      </div>
                      <span className="text-[11px] font-semibold text-slate-400 shrink-0">
                        {m.durationSec > 0 ? `${m.durationSec} s` : ''}
                        {m.fileSizeKb > 0 ? ` · ${m.fileSizeKb} Ko` : ''}
                      </span>
                    </div>
                    <audio
                      controls
                      preload="metadata"
                      src={voicePlaybackSrc(m.audioData, m.audioUrl)}
                      className="h-9 w-full"
                      aria-label={`Message vocal de ${m.senderName}`}
                      onPlay={() => {
                        if (!m.isRead) {
                          void markVoiceRead(m.id);
                          refreshCounts();
                        }
                      }}
                    />
                    {/* RÉPONSE VOCALE — le propriétaire répond par vocal
                        (pré-écoute avant envoi) ; l'invité la voit dans le
                        hub « Contacter l'hôte » et le guidebook. */}
                    <div className="pt-0.5">
                      <VoiceReplyButton voiceMessageId={m.id} onSent={() => void load('refresh')} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ───────── Signalements ───────── */}
        <TabsContent value="complaints" className="mt-4">
          {(complaints ?? []).length === 0 ? (
            <Card className="rounded-2xl border-dashed bg-white">
              <CardContent className="py-14 flex flex-col items-center text-center">
                <div className="h-14 w-14 rounded-2xl bg-amber-50 flex items-center justify-center mb-3">
                  <span className="text-2xl" aria-hidden="true">🚨</span>
                </div>
                <h3 className="font-semibold text-slate-900">Aucun signalement</h3>
                <p className="text-sm text-slate-500 mt-1.5 max-w-sm">
                  Les problèmes signalés par vos invités (bouton « Signaler un problème »
                  de la plaque QR) arriveront ici, connectés au bouton Messages.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3 max-h-[62vh] overflow-y-auto custom-scrollbar pr-1">
              {(complaints ?? []).map((c) => {
                const meta = complaintMeta(c.category);
                const isOpen = c.status === 'OPEN';
                return (
                  <Card
                    key={c.id}
                    className={`rounded-2xl bg-white ${isOpen ? (c.isUrgent ? 'border-red-300 bg-red-50/50' : 'border-slate-300') : 'opacity-70'}`}
                  >
                    <CardContent className="p-4 space-y-2.5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                            <span aria-hidden="true" className="text-base">{meta.emoji}</span>
                            {meta.label}
                            {/* v4.32 — point rouge tant que la notification n'a pas été vue. */}
                            {isOpen && c.isRead === false && (
                              <span
                                aria-label="Non lue"
                                className="h-2 w-2 rounded-full bg-[#E23F2B] shrink-0"
                              />
                            )}
                            {c.isUrgent && isOpen && (
                              <Badge className="bg-red-500 text-white hover:bg-red-500 text-[10px] font-bold">
                                ⚠️ URGENT
                              </Badge>
                            )}
                            {!isOpen && (
                              <Badge className="bg-emerald-600 text-white hover:bg-emerald-600 text-[10px] font-bold">
                                <Check className="h-3 w-3 mr-0.5" aria-hidden="true" /> Résolu
                              </Badge>
                            )}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {relativeFrTime(c.createdAt)}
                            {c.propertyName ? ` · ${c.propertyName}` : ''}
                            {c.guestName ? ` · ${c.guestName}` : ''}
                          </p>
                        </div>
                      </div>

                      <p className="text-sm text-slate-700 whitespace-pre-wrap break-words">
                        {c.description}
                      </p>

                      {c.photos.length > 0 && (
                        <div className="flex items-center gap-2 flex-wrap">
                          {c.photos.map((p, i) => (
                            <a key={i} href={p} target="_blank" rel="noopener noreferrer">
                              {/* Photos stockées en data-URL (≤ 500 Ko) par l'API Hub */}
                              <img
                                src={p}
                                alt={`Photo du signalement ${i + 1}`}
                                className="h-16 w-16 rounded-lg border border-slate-200 object-cover hover:opacity-90 transition-opacity"
                                loading="lazy"
                                decoding="async"
                              />
                            </a>
                          ))}
                        </div>
                      )}

                      {isOpen && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={resolvingId === c.id}
                          onClick={() => void resolveComplaint(c.id)}
                          className="mt-1 h-8 border-emerald-300 text-emerald-700 hover:bg-emerald-50 font-semibold"
                        >
                          {resolvingId === c.id ? (
                            <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                          ) : (
                            <Check className="h-3.5 w-3.5" aria-hidden="true" />
                          )}
                          Marquer résolu
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* ───────── Suivi Ménage (v4.42) ───────── */}
        <TabsContent value="cleaning" className="mt-4">
          {cleaningSorted.length === 0 ? (
            <Card className="rounded-2xl border-dashed bg-white">
              <CardContent className="py-14 flex flex-col items-center text-center">
                <div className="h-14 w-14 rounded-2xl bg-emerald-50 flex items-center justify-center mb-3">
                  <span className="text-2xl" aria-hidden="true">🧹</span>
                </div>
                <h3 className="font-semibold text-slate-900">
                  Aucun passage de ménage enregistré pour le moment
                </h3>
                <p className="text-sm text-slate-500 mt-1.5 max-w-sm">
                  Votre femme de ménage valide son passage depuis le Hub
                  (bouton « Mode Ménage ») : horaires, checklist et photo de
                  l&apos;appartement propre apparaîtront ici.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3 max-h-[62vh] overflow-y-auto custom-scrollbar pr-1">
              {cleaningSorted.map((r) => {
                const isExpanded = expandedReports.has(r.id);
                const doneCount = r.checklist.filter((c) => c.done).length;
                const endIso = r.endedAt ?? r.createdAt;
                const arrival = r.startedAt ? formatFrTime(r.startedAt) : null;
                const departure = formatFrTime(endIso);
                return (
                  <Card key={r.id} className="rounded-2xl bg-white border-slate-200">
                    <CardContent className="p-4 space-y-2.5">
                      {/* En-tête : titre + propriété + date/heure de fin */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-sm font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                            <span aria-hidden="true" className="text-base">🧹</span>
                            Ménage terminé
                            {r.propertyName && (
                              <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100 border border-slate-200 text-[10px] font-semibold">
                                {r.propertyName}
                              </Badge>
                            )}
                          </p>
                          <p className="text-[11px] text-slate-500 mt-0.5">
                            {formatFrDateTime(endIso)}
                          </p>
                        </div>
                      </div>

                      {/* Agent + horaires du passage */}
                      <p className="text-xs text-slate-600 flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">
                          <span aria-hidden="true">👤</span> {r.staffName ?? 'Équipe ménage'}
                        </span>
                        <span aria-hidden="true" className="text-slate-300">·</span>
                        <span>
                          <span aria-hidden="true">🕐</span>{' '}
                          {arrival
                            ? `Arrivée ${arrival} · Départ ${departure}`
                            : `Validé à ${departure}`}
                        </span>
                      </p>

                      {/* Photo de l'appartement propre (dataURL ≤ 500 Ko)
                          + pastille « +N photos » si autres photos */}
                      {r.coverPhoto && (
                        <a
                          href={r.coverPhoto}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="relative block overflow-hidden rounded-xl border border-slate-200"
                          aria-label="Voir la photo de l'appartement propre"
                        >
                          <img
                            src={r.coverPhoto}
                            alt={`Appartement propre après le ménage${r.propertyName ? ` — ${r.propertyName}` : ''}`}
                            className="w-full max-h-40 object-cover hover:opacity-95 transition-opacity"
                            loading="lazy"
                            decoding="async"
                          />
                          {r.photoCount > 1 && (
                            <span className="absolute bottom-2 right-2 rounded-full bg-slate-900/70 px-2 py-0.5 text-[11px] font-semibold text-white">
                              +{r.photoCount - 1} photos
                            </span>
                          )}
                        </a>
                      )}

                      {/* Checklist : résumé repliable + détail ✅/⬜ */}
                      {r.checklist.length > 0 && (
                        <div className="pt-0.5">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => toggleReportDetail(r.id)}
                            aria-expanded={isExpanded}
                            className="h-8 rounded-xl border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold"
                          >
                            <ChevronDown
                              className={`h-3.5 w-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                              aria-hidden="true"
                            />
                            {doneCount}/{r.checklist.length} points validés ·{' '}
                            {isExpanded ? 'Masquer' : 'Voir le détail'}
                          </Button>
                          {isExpanded && (
                            <ul className="mt-2 space-y-1.5 rounded-xl border border-slate-200 bg-slate-50 p-3">
                              {r.checklist.map((item, i) => (
                                <li
                                  key={`${i}-${item.label}`}
                                  className={`flex items-start gap-2 text-sm ${item.done ? 'text-slate-700' : 'text-slate-400'}`}
                                >
                                  <span aria-hidden="true" className="shrink-0">
                                    {item.done ? '✅' : '⬜'}
                                  </span>
                                  <span>{item.label}</span>
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Masque propertiesLoading (le shell gère déjà le skeleton global) */}
      {propertiesLoading ? null : null}
    </div>
  );
}
