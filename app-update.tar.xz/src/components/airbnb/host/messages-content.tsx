'use client';

// =============================================================
// MessagesContent — ONGLET MESSAGES du Dashboard Client (/airbnb/messages)
//
// Centre unifié des entrées invitées :
//   🎙️ Messages vocaux (VoiceMessage) — envoyés via « Contacter l'hôte »
//      du Hub et les modules QR vocaux. Lecture directe via la route
//      /api/uploads/voice/[file] (correction du bug de lecture en
//      standalone). Marquage « lu » automatique à la lecture.
//   🚨 Signalements de problème (GuestComplaint) — envoyés via
//      « Signaler un problème » du Hub. Photos, urgence, résolution.
//   🧹 Ménage : depuis la v4.43, les preuves de ménage (rapports de
//      passage, photos, vocaux de l'équipe) vivent dans l'ONGLET DÉDIÉ
//      « Ménage » (/airbnb/menage) — demandé par le client.
//
// Filtre : suit la propriété sélectionnée dans le header du shell
// (HostContext). Rafraîchissement : bouton + polling 45 s.
//
// v4.60 « AIRBNB PRO » — refonte visuelle uniquement (zéro logique) :
// cartes air-shadow tokens + bulles d'expéditeur tonées, onglets pilules,
// empty states .air-empty, badges dark-safe, CTA air-gradient.
// =============================================================
import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { Check, FileText, Loader2, RefreshCw } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useHostContext } from '@/components/airbnb/host/host-context';
import { useRefreshMessageCounts } from '@/components/airbnb/messages-badge';
import { voicePlaybackSrc } from '@/lib/voice-audio';
import { relativeFrTime } from '@/lib/automations';
import { cn } from '@/lib/utils';
// RÉPONSE VOCALE — le propriétaire répond par message vocal enregistré.
import { VoiceReplyButton } from '@/components/airbnb/host/voice-reply-button';
// v4.53 « FICHE ASSURANCE / INVENTAIRE EN 1 CLIC » — PDF pré-rempli
// pour les réclamations de caution (Airbnb / assurance habitation).
import { downloadInsurancePdf } from '@/lib/insurance-pdf';

// ── Types (contrat de /api/airbnb/messages) ──

interface VoiceItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  senderName: string;
  senderType: string;
  audioUrl: string;
  /** v4.32 — copie dataURL en base (lecture durable, v. bug redéploiements). */
  audioData?: string | null;
  durationSec: number;
  fileSizeKb: number;
  isRead: boolean;
  createdAt: string;
}

interface ComplaintItem {
  id: string;
  propertyId: string;
  propertyName: string | null;
  category: string;
  description: string;
  photos: string[];
  isUrgent: boolean;
  guestName: string | null;
  status: string;
  /** v4.32 — notification déjà vue (badge rouge éteint une fois lue). */
  isRead?: boolean;
  createdAt: string;
}

/** v4.42 — rapport de passage ménage : DÉPLACÉ dans l'onglet Ménage
 *  (/airbnb/menage, v4.43) — plus affiché ici. */

const COMPLAINT_LABELS: Record<string, { emoji: string; label: string }> = {
  PLUMBING: { emoji: '🚰', label: 'Plomberie' },
  ELECTRICAL: { emoji: '⚡', label: 'Électricité' },
  CLEANING: { emoji: '🧹', label: 'Ménage' },
  // v4.53 — casse invité : bouton « Fiche assurance » pré-remplie.
  BREAKAGE: { emoji: '🫖', label: 'Casse / objet abîmé' },
  OTHER: { emoji: '📝', label: 'Autre' },
};

function complaintMeta(category: string) {
  return COMPLAINT_LABELS[category] ?? COMPLAINT_LABELS.OTHER;
}

export function MessagesContent() {
  const { selectedId, selectedProperty, propertiesLoading } = useHostContext();
  // Synchronise le badge du bouton Messages (header + sidebar) dès qu'une
  // action est effectuée sur cette page.
  const refreshCounts = useRefreshMessageCounts();
  const [voice, setVoice] = useState<VoiceItem[] | null>(null);
  const [complaints, setComplaints] = useState<ComplaintItem[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  // ── v4.53 « FICHE ASSURANCE EN 1 CLIC » — modal d'estimation des
  //    dégâts puis PDF pré-rempli (casse invité). ──
  const [insuranceComplaint, setInsuranceComplaint] = useState<ComplaintItem | null>(null);
  const [insuranceItems, setInsuranceItems] = useState('');
  const [insuranceEstimate, setInsuranceEstimate] = useState('');
  const [insuranceComment, setInsuranceComment] = useState('');
  const [insuranceBusy, setInsuranceBusy] = useState(false);

  const openInsuranceDialog = useCallback((c: ComplaintItem) => {
    setInsuranceComplaint(c);
    // Pré-remplissage : l'objet endommagé est déduit de la description
    // (après l'emoji / préfixe), l'estimation reste à la main de l'hôte.
    const cleaned = c.description.replace(/^[^a-zA-Zà-üÀ-Ü]+/, '').trim();
    setInsuranceItems(cleaned.slice(0, 120));
    setInsuranceEstimate('');
    setInsuranceComment('');
  }, []);

  const generateInsurance = useCallback(async () => {
    const c = insuranceComplaint;
    if (!c) return;
    const estimate = Number(insuranceEstimate.trim().replace(',', '.'));
    if (!Number.isFinite(estimate) || estimate < 0 || estimate > 100_000) {
      toast.error('Indiquez une estimation des dégâts valide (ex. 89,99).');
      return;
    }
    setInsuranceBusy(true);
    try {
      await downloadInsurancePdf({
        propertyName: c.propertyName ?? 'Logement',
        propertyAddress: null,
        guestName: c.guestName,
        reportedAtLabel: new Date(c.createdAt).toLocaleString('fr-FR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        categoryLabel: complaintMeta(c.category).label,
        description: c.description,
        photos: c.photos,
        damagedItems: insuranceItems.trim(),
        damageEstimate: estimate,
        hostComment: insuranceComment.trim(),
        statusLabel: c.status === 'RESOLVED' ? 'Résolu' : 'Ouvert',
      });
      toast.success('Fiche assurance générée — prête à joindre à votre réclamation ✅');
      setInsuranceComplaint(null);
    } catch {
      toast.error('Génération du PDF impossible. Réessayez.');
    } finally {
      setInsuranceBusy(false);
    }
  }, [insuranceComplaint, insuranceEstimate, insuranceItems, insuranceComment]);

  const scopeLabel =
    selectedId === 'all' ? 'Toutes les propriétés' : selectedProperty?.name ?? '';

  const load = useCallback(
    async (mode: 'initial' | 'refresh') => {
      if (mode === 'refresh') setRefreshing(true);
      try {
        const res = await fetch(
          `/api/airbnb/messages?propertyId=${encodeURIComponent(selectedId)}`,
          { cache: 'no-store' },
        );
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = (await res.json()) as {
          voice: VoiceItem[];
          complaints: ComplaintItem[];
        };
        setVoice(data.voice ?? []);
        setComplaints(data.complaints ?? []);
      } catch {
        if (mode === 'initial') {
          setVoice([]);
        }
        toast.error('Impossible de charger les messages. Réessayez.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedId],
  );

  // Chargement à l'ouverture + à chaque changement de propriété + polling 45 s.
  useEffect(() => {
    setLoading(true);
    void load('initial');
  }, [load]);
  useEffect(() => {
    const poll = setInterval(() => void load('refresh'), 45_000);
    return () => clearInterval(poll);
  }, [load]);

  const voiceUnread = useMemo(() => (voice ?? []).filter((v) => !v.isRead).length, [voice]);
  const complaintsOpen = useMemo(
    () => (complaints ?? []).filter((c) => c.status === 'OPEN').length,
    [complaints],
  );

  // Marquer un vocal comme lu (à la lecture) — optimiste.
  const markVoiceRead = useCallback(async (id: string) => {
    setVoice((prev) => (prev ?? []).map((v) => (v.id === id ? { ...v, isRead: true } : v)));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'voice', id, action: 'read' }),
      });
    } catch {
      // silencieux — l'état optimiste reste, re-synchronisé au prochain poll
    }
  }, []);

  // v4.32 — demande client : « le bouton de notification rouge reste rouge
  // même si la notification est lue ». Ouvrir l'onglet Signalements = tout
  // est considéré vu : le badge rouge s'éteint (les réclamations restent
  // ouvertes jusqu'à résolution, sans allumer le badge).
  const markAllComplaintsSeen = useCallback(async () => {
    setComplaints((prev) => (prev ?? []).map((c) => (c.isRead ? c : { ...c, isRead: true })));
    try {
      await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', action: 'read-all' }),
      });
      refreshCounts();
    } catch {
      // silencieux — re-synchronisé au prochain poll
    }
  }, [refreshCounts]);

  // Résoudre un signalement — optimiste + rollback si échec.
  const resolveComplaint = useCallback(async (id: string) => {
    setResolvingId(id);
    const previous = complaints;
    setComplaints((prev) =>
      (prev ?? []).map((c) => (c.id === id ? { ...c, status: 'RESOLVED' } : c)),
    );
    try {
      const res = await fetch('/api/airbnb/messages', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'complaint', id, action: 'resolve' }),
      });
      if (!res.ok) throw new Error();
      toast.success('Signalement marqué comme résolu ✅');
      refreshCounts();
    } catch {
      setComplaints(previous);
      toast.error('Impossible de résoudre le signalement. Réessayez.');
    } finally {
      setResolvingId(null);
    }
  }, [complaints]);

  if (loading && voice === null) {
    return (
      <div className="flex max-w-4xl flex-col gap-4">
        <Skeleton className="h-9 w-64 rounded-xl" aria-hidden="true" />
        <Skeleton className="h-11 w-full max-w-md rounded-full" aria-hidden="true" />
        <div className="flex flex-col gap-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-24 w-full rounded-2xl" aria-hidden="true" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="flex max-w-4xl flex-col gap-6">
      {/* ----- En-tête ----- */}
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between"
      >
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight text-foreground">
            <span aria-hidden="true">💬</span> Messages
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Vocaux et signalements — {scopeLabel}
          </p>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => void load('refresh')}
          disabled={refreshing}
          className="gap-2 self-start rounded-full sm:self-auto"
          aria-label="Rafraîchir les messages"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} aria-hidden="true" />
          Rafraîchir
        </Button>
      </motion.div>

      {/* ----- Onglets Vocaux / Signalements ----- */}
      <Tabs
        defaultValue="voice"
        onValueChange={(v) => {
          if (v === 'complaints') void markAllComplaintsSeen();
        }}
      >
        <TabsList className="h-11 max-w-full overflow-x-auto rounded-full bg-muted p-1 custom-scrollbar">
          <TabsTrigger
            value="voice"
            className="rounded-full px-4 text-sm font-semibold data-[state=active]:bg-card data-[state=active]:shadow-sm"
          >
            🎙️ Vocaux
            {voiceUnread > 0 && (
              <Badge className="ml-2 h-5 min-w-5 rounded-full bg-[#0066EF] px-1.5 text-[10px] font-bold text-white hover:bg-[#0066EF]">
                {voiceUnread > 9 ? '9+' : voiceUnread}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger
            value="complaints"
            className="rounded-full px-4 text-sm font-semibold data-[state=active]:bg-card data-[state=active]:shadow-sm"
          >
            🚨 Signalements
            {complaintsOpen > 0 && (
              <Badge className="ml-2 h-5 min-w-5 rounded-full bg-amber-500 px-1.5 text-[10px] font-bold text-white hover:bg-amber-500">
                {complaintsOpen > 9 ? '9+' : complaintsOpen}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ───────── Vocaux ───────── */}
        <TabsContent value="voice" className="mt-4">
          {(voice ?? []).length === 0 ? (
            <div className="air-empty flex flex-col items-center rounded-2xl p-8 text-center">
              <span className="air-float text-3xl" aria-hidden="true">🎙️</span>
              <h3 className="mt-3 text-sm font-semibold text-foreground">Aucun message vocal</h3>
              <p className="mt-1.5 max-w-sm text-xs text-muted-foreground">
                Les messages vocaux laissés par vos invités (bouton « Contacter l&apos;hôte »
                de la plaque QR) apparaîtront ici.
              </p>
            </div>
          ) : (
            <div className="flex max-h-[62vh] flex-col gap-3 overflow-y-auto pr-1 custom-scrollbar [scrollbar-width:thin]">
              {(voice ?? []).map((m) => (
                <Card
                  key={m.id}
                  className={cn(
                    'air-shadow rounded-2xl bg-card',
                    m.isRead
                      ? 'border-border'
                      : 'border-[#0066EF]/40 bg-blue-50/50 dark:border-[#3B82F6]/40 dark:bg-[#0066EF]/10',
                  )}
                >
                  <CardContent className="space-y-2.5 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex min-w-0 items-start gap-3">
                        <span
                          aria-hidden="true"
                          className="kpi-bubble-teal flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow"
                        >
                          <span className="text-lg leading-none">🎙️</span>
                        </span>
                        <div className="min-w-0">
                          <p className="flex items-center gap-2 text-sm font-bold text-foreground">
                            {m.senderName}
                            {!m.isRead && (
                              <span
                                aria-label="Non lu"
                                className="h-2 w-2 shrink-0 rounded-full bg-[#0066EF]"
                              />
                            )}
                          </p>
                          <p className="mt-0.5 text-[11px] text-muted-foreground">
                            {relativeFrTime(m.createdAt)}
                            {m.propertyName ? ` · ${m.propertyName}` : ''}
                          </p>
                        </div>
                      </div>
                      <span className="shrink-0 text-[11px] font-semibold text-muted-foreground/80">
                        {m.durationSec > 0 ? `${m.durationSec} s` : ''}
                        {m.fileSizeKb > 0 ? ` · ${m.fileSizeKb} Ko` : ''}
                      </span>
                    </div>
                    <audio
                      controls
                      preload="metadata"
                      src={voicePlaybackSrc(m.audioData, m.audioUrl)}
                      className="h-9 w-full"
                      aria-label={`Message vocal de ${m.senderName}`}
                      onPlay={() => {
                        if (!m.isRead) {
                          void markVoiceRead(m.id);
                          refreshCounts();
                        }
                      }}
                    />
                    {/* RÉPONSE VOCALE — le propriétaire répond par vocal
                        (pré-écoute avant envoi) ; l'invité la voit dans le
                        hub « Contacter l'hôte » et le guidebook. */}
                    <div className="pt-0.5">
                      <VoiceReplyButton voiceMessageId={m.id} onSent={() => void load('refresh')} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* ───────── Signalements ───────── */}
        <TabsContent value="complaints" className="mt-4">
          {(complaints ?? []).length === 0 ? (
            <div className="air-empty flex flex-col items-center rounded-2xl p-8 text-center">
              <span className="air-float text-3xl" aria-hidden="true">🚨</span>
              <h3 className="mt-3 text-sm font-semibold text-foreground">Aucun signalement</h3>
              <p className="mt-1.5 max-w-sm text-xs text-muted-foreground">
                Les problèmes signalés par vos invités (bouton « Signaler un problème »
                de la plaque QR) arriveront ici, connectés au bouton Messages.
              </p>
            </div>
          ) : (
            <div className="flex max-h-[62vh] flex-col gap-3 overflow-y-auto pr-1 custom-scrollbar [scrollbar-width:thin]">
              {(complaints ?? []).map((c) => {
                const meta = complaintMeta(c.category);
                const isOpen = c.status === 'OPEN';
                return (
                  <Card
                    key={c.id}
                    className={cn(
                      'air-shadow rounded-2xl bg-card',
                      isOpen
                        ? c.isUrgent
                          ? 'border-red-300 bg-red-50/50 dark:border-red-500/40 dark:bg-red-500/10'
                          : 'border-border'
                        : 'border-border opacity-70',
                    )}
                  >
                    <CardContent className="space-y-2.5 p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex min-w-0 items-start gap-3">
                          <span
                            aria-hidden="true"
                            className={cn(
                              'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg text-white shadow',
                              isOpen && c.isUrgent ? 'kpi-bubble-rausch' : 'kpi-bubble-orange',
                            )}
                          >
                            {meta.emoji}
                          </span>
                          <div className="min-w-0">
                            <p className="flex flex-wrap items-center gap-2 text-sm font-bold text-foreground">
                              {meta.label}
                              {/* v4.32 — point rouge tant que la notification n'a pas été vue. */}
                              {isOpen && c.isRead === false && (
                                <span
                                  aria-label="Non lue"
                                  className="h-2 w-2 shrink-0 rounded-full bg-[#0066EF]"
                                />
                              )}
                              {c.isUrgent && isOpen && (
                                <Badge className="rounded-full bg-red-500 text-[10px] font-bold text-white hover:bg-red-500">
                                  ⚠️ URGENT
                                </Badge>
                              )}
                              {!isOpen && (
                                <Badge className="rounded-full bg-emerald-600 text-[10px] font-bold text-white hover:bg-emerald-600">
                                  <Check className="mr-0.5 h-3 w-3" aria-hidden="true" /> Résolu
                                </Badge>
                              )}
                            </p>
                            <p className="mt-0.5 text-[11px] text-muted-foreground">
                              {relativeFrTime(c.createdAt)}
                              {c.propertyName ? ` · ${c.propertyName}` : ''}
                              {c.guestName ? ` · ${c.guestName}` : ''}
                            </p>
                          </div>
                        </div>
                      </div>

                      <p className="whitespace-pre-wrap break-words text-sm text-foreground">
                        {c.description}
                      </p>

                      {c.photos.length > 0 && (
                        <div className="flex flex-wrap items-center gap-2">
                          {c.photos.map((p, i) => (
                            <a key={i} href={p} target="_blank" rel="noopener noreferrer">
                              {/* Photos stockées en data-URL (≤ 500 Ko) par l'API Hub */}
                              <img
                                src={p}
                                alt={`Photo du signalement ${i + 1}`}
                                className="h-16 w-16 rounded-xl border border-border object-cover transition-opacity hover:opacity-90"
                                loading="lazy"
                                decoding="async"
                              />
                            </a>
                          ))}
                        </div>
                      )}

                      {isOpen && (
                        <div className="mt-1 flex flex-wrap items-center gap-2">
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            disabled={resolvingId === c.id}
                            onClick={() => void resolveComplaint(c.id)}
                            className="h-8 rounded-full border-blue-300 font-semibold text-blue-700 hover:bg-blue-50 dark:border-blue-500/40 dark:text-blue-400 dark:hover:bg-blue-500/10"
                          >
                            {resolvingId === c.id ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />
                            ) : (
                              <Check className="h-3.5 w-3.5" aria-hidden="true" />
                            )}
                            Marquer résolu
                          </Button>
                          {/* v4.53 « FICHE ASSURANCE EN 1 CLIC » — estimation
                              des dégâts + rapport PDF pré-rempli (caution
                              Airbnb / assurance habitation). */}
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            onClick={() => openInsuranceDialog(c)}
                            className="h-8 rounded-full font-semibold text-foreground hover:bg-muted"
                            aria-label="Générer la fiche assurance PDF"
                          >
                            <FileText className="h-3.5 w-3.5" aria-hidden="true" />
                            Fiche assurance
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

      </Tabs>

      {/* ── v4.53 « FICHE ASSURANCE EN 1 CLIC » — estimation des dégâts
          puis rapport PDF pré-rempli (photos + description + montant). ── */}
      <Dialog open={!!insuranceComplaint} onOpenChange={(o) => !o && setInsuranceComplaint(null)}>
        <DialogContent className="max-w-lg rounded-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-foreground">
              🫖 Fiche assurance / dépôt de garantie
            </DialogTitle>
            <DialogDescription>
              Le rapport PDF est pré-rempli avec le signalement, les photos et le logement.
              Complétez l&apos;estimation des dégâts — le document est prêt pour Airbnb ou votre
              assurance habitation.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <div className="rounded-xl bg-muted/50 p-3 text-xs text-muted-foreground">
              <p className="font-semibold text-foreground">
                {insuranceComplaint
                  ? `${complaintMeta(insuranceComplaint.category).emoji} ${complaintMeta(insuranceComplaint.category).label}`
                  : ''}
                {insuranceComplaint?.guestName ? ` — ${insuranceComplaint.guestName}` : ''}
              </p>
              <p className="mt-0.5">
                {insuranceComplaint
                  ? new Date(insuranceComplaint.createdAt).toLocaleString('fr-FR', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })
                  : ''}
                {insuranceComplaint?.propertyName ? ` · ${insuranceComplaint.propertyName}` : ''}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-items" className="text-xs font-semibold text-muted-foreground">
                Objet(s) endommagé(s)
              </Label>
              <Input
                id="insurance-items"
                value={insuranceItems}
                onChange={(e) => setInsuranceItems(e.target.value)}
                maxLength={120}
                placeholder="Ex. : machine à café Delonghi, verre à pied…"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-estimate" className="text-xs font-semibold text-muted-foreground">
                Estimation des dégâts (€)
              </Label>
              <Input
                id="insurance-estimate"
                inputMode="decimal"
                value={insuranceEstimate}
                onChange={(e) => setInsuranceEstimate(e.target.value)}
                maxLength={10}
                placeholder="89,99"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance-comment" className="text-xs font-semibold text-muted-foreground">
                Commentaire (optionnel)
              </Label>
              <Textarea
                id="insurance-comment"
                value={insuranceComment}
                onChange={(e) => setInsuranceComment(e.target.value)}
                maxLength={600}
                rows={3}
                placeholder="Contexte, échanges avec l'invité, remplacement prévu…"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              className="rounded-full"
              onClick={() => setInsuranceComplaint(null)}
            >
              Annuler
            </Button>
            <Button
              type="button"
              onClick={() => void generateInsurance()}
              disabled={insuranceBusy}
              className="air-gradient rounded-full font-semibold text-white shadow hover:opacity-95"
            >
              {insuranceBusy ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : (
                <FileText className="h-4 w-4" aria-hidden="true" />
              )}
              Générer le PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Masque propertiesLoading (le shell gère déjà le skeleton global) */}
      {propertiesLoading ? null : null}
    </div>
  );
}
