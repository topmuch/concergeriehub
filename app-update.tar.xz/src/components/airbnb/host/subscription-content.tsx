'use client';

// =============================================================
// v5.4 — « Gérer mon abonnement » (Espace Hôte, onglet sidebar).
//
// Trois offres en cartes (grille responsive 1 / 3 colonnes) :
//   - Abonnement 1 — 1 à 3 biens — 299 €/an (palier « essentiel ») ;
//   - Abonnement 2 — 4 à 20 biens — 499 €/an (palier « pro ») ;
//   - Plus de 20 biens — sur devis (contact mailto + WhatsApp).
//
// Paiement : MÊME flux PayPal Orders que l'offre EDL publique
// (cf. src/components/edl/edl-checkout.tsx) — POST
// /api/edl/paypal/order avec { plan: 'essentiel' | 'pro' } puis
// redirection vers approveUrl. Retour : /edl/paiement/retour
// (capture serveur) puis /edl/activer/[token].
//
// État actuel : bandeau alimenté par le serveur (page.tsx —
// InspectionSubscription active + endDate au format fr-FR).
// =============================================================

import { useState } from 'react';
import { BadgeCheck, Building2, Check, Hotel, CreditCard, Home, Loader2 } from 'lucide-react';

export interface CurrentOfferView {
  /** Libellé lisible, ex. « Abonnement 1 (1 à 3 biens) ». */
  planLabel: string;
  /** true si l'offre en cours correspond au palier 299 €. */
  isEssential: boolean;
  /** true si l'offre en cours correspond au palier 499 €. */
  isPro: boolean;
  /** Fin de validité (ISO) — affichée au format fr-FR. */
  endDateIso: string;
}

interface SubscriptionContentProps {
  currentOffer: CurrentOfferView | null;
}

type PlanKey = 'essentiel' | 'pro';

// Montants affichés « 299,00 € » (convention projet).
const eur2 = (n: number) => `${n.toFixed(2).replace('.', ',')} €`;

const frDate = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'long',
  year: 'numeric',
});

const ESSENTIAL_FEATURES = [
  'États des lieux illimités (entrée + sortie)',
  'PDF signé électroniquement avec QR de vérification',
  'Partage invité par WhatsApp et e-mail',
  'Tableau de bord et documents',
  'Alertes dégâts en temps réel',
  "Mode d'emploi intégré",
];

const PRO_FEATURES = [
  "Tout l'Abonnement 1",
  'Jusqu\u2019à 20 logements protégés',
  'Documents fusionnés Entrée + Sortie',
  'Statistiques par logement',
  'Support prioritaire 7j/7',
];

const ENTERPRISE_FEATURES = [
  'Nombre de logements illimité',
  'Onboarding accompagné',
  'Facturation centralisée',
  'Accompagnement dédié',
];

// TODO: remplacer par le vrai numéro WhatsApp de RoomScan si disponible.
const WHATSAPP_URL = `https://wa.me/33612345678?text=${encodeURIComponent(
  "Bonjour, je suis intéressé par l'offre RoomScan pour plus de 20 biens. Pouvez-vous m'établir un devis ?",
)}`;

export function SubscriptionContent({ currentOffer }: SubscriptionContentProps) {
  // Flux PayPal en cours ('essentiel' | 'pro') — un seul à la fois.
  const [busy, setBusy] = useState<PlanKey | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Même pattern que /components/edl/edl-checkout.tsx :
  // création de commande PayPal → redirection vers approveUrl.
  async function startCheckout(plan: PlanKey) {
    setError(null);
    setBusy(plan);
    try {
      const res = await fetch('/api/edl/paypal/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan }),
      });
      const data = (await res.json().catch(() => null)) as {
        approveUrl?: string;
        error?: string;
      } | null;
      if (res.ok && data?.approveUrl) {
        window.location.href = data.approveUrl;
        return;
      }
      setError(
        data?.error ??
          'Impossible de démarrer le paiement pour le moment. Réessayez dans un instant.',
      );
      setBusy(null);
    } catch {
      setError('Connexion impossible. Vérifiez votre réseau et réessayez.');
      setBusy(null);
    }
  }

  const essentialDisabled = busy !== null || currentOffer?.isEssential === true;
  const proDisabled = busy !== null || currentOffer?.isPro === true;

  return (
    <div className="flex-1">
      <div className="mx-auto flex w-full max-w-5xl flex-col px-4 py-8 md:py-12">
        {/* ---------- En-tête ---------- */}
        <div className="mb-8">
          <h1 className="flex items-center gap-3 text-2xl font-bold tracking-tight text-foreground md:text-3xl">
            <span
              aria-hidden="true"
              className="kpi-bubble-rausch inline-flex h-11 w-11 items-center justify-center rounded-xl text-white shadow"
            >
              <CreditCard className="h-5 w-5" />
            </span>
            Gérer mon abonnement
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Votre offre RoomScan, sans engagement.
          </p>
        </div>

        {/* ---------- Bandeau erreur paiement ---------- */}
        {error && (
          <div
            role="alert"
            className="mb-6 rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 dark:border-red-500/30 dark:bg-red-950/40 dark:text-red-300"
          >
            {error}
          </div>
        )}

        {/* ---------- Bandeau offre actuelle ---------- */}
        {currentOffer ? (
          <div
            role="status"
            className="mb-8 flex items-start gap-2 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800 dark:border-emerald-500/30 dark:bg-emerald-950/40 dark:text-emerald-300"
          >
            <BadgeCheck className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            <span>
              <strong>Offre actuelle : {currentOffer.planLabel}</strong> — valable jusqu&apos;au{' '}
              {frDate.format(new Date(currentOffer.endDateIso))}.
            </span>
          </div>
        ) : (
          <div
            role="status"
            className="mb-8 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-card px-4 py-3 text-sm text-foreground"
          >
            <span>
              <strong>Aucun abonnement actif</strong> — choisissez l&apos;offre adaptée à votre
              activité.
            </span>
            <button
              type="button"
              onClick={() => void startCheckout('essentiel')}
              disabled={busy !== null}
              className="btn-primary-red"
            >
              {busy === 'essentiel' ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : null}
              Souscrire — 299 €/an
            </button>
          </div>
        )}

        {/* ---------- Offres (grille 1 / 3 colonnes) ---------- */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* ── Abonnement 1 — 1 à 3 biens ── */}
          <article
            aria-label="Abonnement 1 — 1 à 3 biens"
            className="air-shadow relative flex flex-col rounded-2xl border border-border bg-card p-6"
          >
            {currentOffer?.isEssential && (
              <span className="absolute -top-3 left-6 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 shadow dark:border-emerald-500/30 dark:bg-emerald-950/60 dark:text-emerald-300">
                Votre offre actuelle
              </span>
            )}
            <div className="mb-3 flex items-center gap-3">
              <span
                aria-hidden="true"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-muted"
              >
                <Home className="h-5 w-5 text-muted-foreground" />
              </span>
              <h2 className="text-lg font-bold text-foreground">Abonnement 1</h2>
            </div>
            <p className="text-sm text-muted-foreground">1 à 3 biens</p>
            <p className="mt-3 flex items-baseline gap-1">
              <span className="text-4xl font-extrabold tracking-tight tabular-nums text-foreground">
                299 €
              </span>
              <span className="text-sm text-muted-foreground">/an</span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">soit {eur2(299)} par année</p>

            <ul className="my-5 flex-1 space-y-2.5">
              {ESSENTIAL_FEATURES.map((feature) => (
                <li key={feature} className="flex items-start gap-2.5">
                  <span
                    aria-hidden="true"
                    className="mt-0.5 inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-500/15"
                  >
                    <Check className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                  </span>
                  <span className="text-sm text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              type="button"
              onClick={() => void startCheckout('essentiel')}
              disabled={essentialDisabled}
              className="btn-primary-red w-full"
            >
              {busy === 'essentiel' ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : null}
              {currentOffer?.isEssential ? 'Votre offre actuelle' : 'Souscrire — 299 €/an'}
            </button>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              Paiement sécurisé par PayPal — carte bancaire acceptée.
            </p>
          </article>

          {/* ── Abonnement 2 — 4 à 20 biens (offre mise en avant) ── */}
          <article
            aria-label="Abonnement 2 — 4 à 20 biens"
            className="air-shadow air-hoverlift relative flex flex-col rounded-2xl border border-[#2563EB]/60 bg-card p-6 ring-2 ring-[#2563EB]/25"
          >
            <span className="absolute -top-3 left-6 rounded-full border border-[#2563EB] bg-[#2563EB] px-3 py-1 text-xs font-bold text-white shadow">
              Multi-biens
            </span>
            <div className="mb-3 flex items-center gap-3">
              <span
                aria-hidden="true"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-[#2563EB]/10"
              >
                <Building2 className="h-5 w-5 text-[#2563EB]" />
              </span>
              <h2 className="text-lg font-bold text-foreground">Abonnement 2</h2>
            </div>
            <p className="text-sm text-muted-foreground">4 à 20 biens</p>
            <p className="mt-3 flex items-baseline gap-1">
              <span className="text-4xl font-extrabold tracking-tight tabular-nums text-foreground">
                499 €
              </span>
              <span className="text-sm text-muted-foreground">/an</span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">soit {eur2(499)} par année</p>

            <ul className="my-5 flex-1 space-y-2.5">
              {PRO_FEATURES.map((feature) => (
                <li key={feature} className="flex items-start gap-2.5">
                  <span
                    aria-hidden="true"
                    className="mt-0.5 inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-500/15"
                  >
                    <Check className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                  </span>
                  <span className="text-sm text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              type="button"
              onClick={() => void startCheckout('pro')}
              disabled={proDisabled}
              className="btn-secondary-blue w-full"
            >
              {busy === 'pro' ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : null}
              {currentOffer?.isPro
                ? 'Votre offre actuelle'
                : currentOffer
                  ? "Passer à l'Abonnement 2 — 499 €/an"
                  : 'Souscrire — 499 €/an'}
            </button>
            <p className="mt-2 text-center text-[11px] text-muted-foreground">
              Paiement sécurisé par PayPal — carte bancaire acceptée.
            </p>
          </article>

          {/* ── Plus de 20 biens — sur devis ── */}
          <article
            aria-label="Plus de 20 biens — prix sur devis"
            className="air-shadow relative flex flex-col rounded-2xl border border-border bg-card p-6"
          >
            <div className="mb-3 flex items-center gap-3">
              <span
                aria-hidden="true"
                className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-muted"
              >
                <Hotel className="h-5 w-5 text-muted-foreground" />
              </span>
              <h2 className="text-lg font-bold text-foreground">Plus de 20 biens</h2>
            </div>
            <p className="text-sm text-muted-foreground">Portefeuilles étendus et réseaux</p>
            <p className="mt-3 flex items-baseline gap-1">
              <span className="text-4xl font-extrabold tracking-tight text-foreground">
                Sur devis
              </span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">tarification adaptée à votre parc</p>

            <ul className="my-5 flex-1 space-y-2.5">
              {ENTERPRISE_FEATURES.map((feature) => (
                <li key={feature} className="flex items-start gap-2.5">
                  <span
                    aria-hidden="true"
                    className="mt-0.5 inline-flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-500/15"
                  >
                    <Check className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                  </span>
                  <span className="text-sm text-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-col gap-2">
              <a
                href="mailto:contact@roomscan.pro?subject=Offre%20plus%20de%2020%20biens"
                className="btn-secondary-blue w-full"
              >
                Nous contacter
              </a>
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-tertiary-gray w-full"
              >
                WhatsApp
                <span className="sr-only">— ouvre WhatsApp dans un nouvel onglet</span>
              </a>
            </div>
          </article>
        </div>

        {/* ---------- Aide ---------- */}
        <p className="mt-10 text-center text-xs text-muted-foreground">
          Besoin d&apos;aide pour choisir ? Consultez le <strong>Mode d&apos;emploi</strong> ou{' '}
          <a
            href="mailto:contact@roomscan.pro"
            className="font-semibold text-foreground underline-offset-2 hover:underline"
          >
            contactez-nous
          </a>
          .
        </p>
      </div>
    </div>
  );
}
