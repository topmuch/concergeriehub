'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

// =============================================================
// AUDIT 4-c — « Mes tâches » (Espace Hôte, membres d'équipe).
// Consomme GET /api/airbnb/my-assignments (réponse RÉELLE) :
//   - CLEANER     → séjours à ménager (guestName, dates, ménage)
//   - MAINTENANCE → réclamations techniques ouvertes
//   - MANAGER/OWNER → les deux sections
// v4.60 « AIRBNB PRO » : cartes air-shadow rounded-2xl en tokens,
// badges sémantiques dark-safe, empty states .air-empty, erreur +
// Réessayer air-gradient, bulle kpi-bubble, stagger framer-motion.
// =============================================================

interface AssignmentStay {
  id: string;
  guestName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  cleaningStatus: string;
  status: string;
}

interface AssignmentRequest {
  id: string;
  description: string;
  status: string;
  urgencyLevel: string;
  preferredDate: string | null;
  createdAt: string;
  provider: { businessName: string; category: string } | null;
}

interface AssignmentBlock {
  property: { id: string; name: string; propertyType: string; address: string | null };
  role: string;
  cleaning: { upcoming: AssignmentStay[] };
  maintenance: { open: AssignmentRequest[] };
}

const ROLE_LABELS: Record<string, string> = {
  OWNER: 'Propriétaire',
  MANAGER: 'Manager',
  CLEANER: 'Ménage',
  MAINTENANCE: 'Maintenance',
};
/** PENDING='À faire' (orange) · IN_PROGRESS='En cours' (bleu) · DONE='Terminé' (vert). */
function cleaningBadge(status: string): { label: string; className: string } {
  if (status === 'PENDING') return { label: 'À faire', className: 'border-orange-200 bg-orange-50 text-orange-700 dark:border-orange-500/30 dark:bg-orange-500/10 dark:text-orange-300' };
  if (status === 'IN_PROGRESS') return { label: 'En cours', className: 'border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/10 dark:text-sky-300' };
  if (status === 'DONE') return { label: 'Terminé', className: 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300' };
  return { label: status, className: 'border-border bg-muted text-muted-foreground' };
}

function requestBadge(status: string): { label: string; className: string } {
  if (status === 'pending') return { label: 'En attente', className: 'border-border bg-muted text-muted-foreground' };
  if (status === 'accepted') return { label: 'Acceptée', className: 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300' };
  if (status === 'in_progress') return { label: 'En cours', className: 'border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/10 dark:text-sky-300' };
  return { label: status, className: 'border-border bg-muted text-muted-foreground' };
}

function urgencyBadge(level: string): { label: string; className: string } | null {
  if (level === 'urgent') return { label: 'Urgent', className: 'border-orange-200 bg-orange-50 text-orange-700 dark:border-orange-500/30 dark:bg-orange-500/10 dark:text-orange-300' };
  if (level === 'emergency') return { label: 'Urgence', className: 'border-red-200 bg-red-50 text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300' };
  return null; // 'normal' → pas de badge bruyant
}

function formatDay(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
}

function formatDayTime(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function MyAssignmentsContent() {
  const [assignments, setAssignments] = useState<AssignmentBlock[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Charge les affectations réelles. mode='retry' (bouton Réessayer)
  // repasse par le skeleton ; l'effet initial est déjà « loading ».
  const load = useCallback(async (mode: 'initial' | 'retry') => {
    if (mode === 'retry') setLoading(true);
    try {
      const res = await fetch('/api/airbnb/my-assignments', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as
        | { assignments?: AssignmentBlock[]; error?: string }
        | null;
      if (!res.ok || !json) {
        setError(json?.error ?? 'Impossible de charger vos tâches.');
        setAssignments(null);
        return;
      }
      setError('');
      setAssignments(json.assignments ?? []);
    } catch {
      setError('Connexion impossible. Réessayez.');
      setAssignments(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load('initial');
  }, [load]);

  const hasNoTask =
    (assignments ?? []).length === 0 ||
    (assignments ?? []).every(
      (a) => a.cleaning.upcoming.length === 0 && a.maintenance.open.length === 0,
    );

  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col">
      {/* ----- En-tête ----- */}
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: 'easeOut' }}
        className="mb-6"
      >
        <h1 className="text-2xl font-bold tracking-tight text-foreground">🧹 Mes tâches</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Vos interventions à venir sur les biens de l&apos;équipe.
        </p>
      </motion.div>

      {/* ----- Chargement (skeleton) ----- */}
      {loading && (
        <div className="space-y-4" aria-busy="true" aria-label="Chargement de vos tâches">
          {[0, 1].map((i) => (
            <div key={i} className="air-shadow rounded-2xl border border-border bg-card p-4 space-y-3">
              <Skeleton className="h-6 w-44 rounded-lg" />
              <Skeleton className="h-16 w-full rounded-xl" />
              <Skeleton className="h-16 w-full rounded-xl" />
            </div>
          ))}
        </div>
      )}

      {/* ----- Erreur + Réessayer ----- */}
      {!loading && error && (
        <div className="air-empty flex flex-col items-center gap-3 rounded-2xl p-8 text-center" role="alert">
          <span className="air-float text-3xl" aria-hidden="true">⚠️</span>
          <p className="text-sm font-semibold text-foreground">{error}</p>
          <button
            type="button"
            onClick={() => void load('retry')}
            className="air-gradient inline-flex h-9 items-center gap-2 rounded-full px-4 text-xs font-bold text-white shadow transition-transform hover:scale-[1.03] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0066EF]/50"
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
            Réessayer
          </button>
        </div>
      )}

      {/* ----- État vide ----- */}
      {!loading && !error && hasNoTask && (
        <div className="air-empty rounded-2xl p-10 text-center">
          <p className="air-float text-4xl" aria-hidden="true">🎉</p>
          <p className="mt-3 text-sm font-semibold text-foreground">Aucune tâche pour le moment 🎉</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Les nouveaux séjours et réclamations apparaîtront ici automatiquement.
          </p>
        </div>
      )}

      {/* ----- Tâches par bien ----- */}
      {!loading && !error && !hasNoTask && (
        <div className="space-y-5">
          {(assignments ?? []).map((block, i) => {
            const roleLabel = ROLE_LABELS[block.role] ?? block.role;
            const propertyEmpty =
              block.cleaning.upcoming.length === 0 && block.maintenance.open.length === 0;
            if (propertyEmpty) return null;
            return (
              <motion.section
                key={block.property.id}
                aria-label={`Tâches pour ${block.property.name}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.06 * i, duration: 0.3, ease: 'easeOut' }}
                className="air-shadow rounded-2xl border border-border bg-card p-4 sm:p-5"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-3">
                    <span
                      aria-hidden="true"
                      className="kpi-bubble-rausch flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-base text-white shadow"
                    >
                      🏠
                    </span>
                    <h2 className="truncate text-base font-bold text-foreground">
                      {block.property.name}
                    </h2>
                  </div>
                  <span className="rounded-full border border-border bg-muted px-2.5 py-0.5 text-xs font-semibold text-muted-foreground">
                    {roleLabel}
                  </span>
                </div>

                {/* — Séjours à ménager (CLEANER / MANAGER / OWNER) — */}
                {block.cleaning.upcoming.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                      🛏️ Séjours à ménager
                    </p>
                    <ul className="mt-2 space-y-2">
                      {block.cleaning.upcoming.map((stay) => {
                        const badge = cleaningBadge(stay.cleaningStatus);
                        return (
                          <li
                            key={stay.id}
                            className="flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-xl border border-border/70 bg-muted/40 p-4 transition-colors hover:bg-muted/60"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-semibold text-foreground">
                                {stay.guestName || 'Invité'}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                🛬 {formatDay(stay.checkIn)} → 🛫 {formatDay(stay.checkOut)} ·{' '}
                                {stay.guests} voyageur{stay.guests > 1 ? 's' : ''}
                              </p>
                            </div>
                            <span
                              className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${badge.className}`}
                            >
                              {badge.label}
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}

                {/* — Réclamations ouvertes (MAINTENANCE / MANAGER / OWNER) — */}
                {block.maintenance.open.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                      🔧 Réclamations ouvertes
                    </p>
                    <ul className="mt-2 space-y-2">
                      {block.maintenance.open.map((req) => {
                        const badge = requestBadge(req.status);
                        const urgency = urgencyBadge(req.urgencyLevel);
                        return (
                          <li
                            key={req.id}
                            className="flex flex-wrap items-start gap-x-3 gap-y-1.5 rounded-xl border border-border/70 bg-muted/40 p-4 transition-colors hover:bg-muted/60"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-semibold text-foreground line-clamp-2">
                                {req.description || 'Réclamation sans description'}
                              </p>
                              <p className="mt-0.5 text-xs text-muted-foreground">
                                🗓️ {formatDayTime(req.preferredDate ?? req.createdAt)}
                                {req.provider?.businessName
                                  ? ` · 🧰 ${req.provider.businessName}`
                                  : ''}
                              </p>
                            </div>
                            <div className="flex shrink-0 items-center gap-1.5">
                              {urgency && (
                                <span
                                  className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${urgency.className}`}
                                >
                                  {urgency.label}
                                </span>
                              )}
                              <span
                                className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${badge.className}`}
                              >
                                {badge.label}
                              </span>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
              </motion.section>
            );
          })}

          <p className="text-center text-xs text-muted-foreground">
            💡 Une question ? <Link href="/airbnb/messages" className="font-semibold underline underline-offset-2 transition-colors hover:text-foreground">Écrivez à l&apos;équipe</Link>
          </p>
        </div>
      )}
    </div>
  );
}
