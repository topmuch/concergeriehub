'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

// =============================================================
// AUDIT 4-c — « Mes tâches » (Espace Hôte, membres d'équipe).
// Consomme GET /api/airbnb/my-assignments (réponse RÉELLE) :
//   - CLEANER     → séjours à ménager (guestName, dates, ménage)
//   - MAINTENANCE → réclamations techniques ouvertes
//   - MANAGER/OWNER → les deux sections
// Design système du shell hôte : cartes bg-card border-border
// rounded-2xl p-4, état vide, skeleton, erreur + Réessayer.
// =============================================================

interface AssignmentStay {
  id: string;
  guestName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  cleaningStatus: string;
  status: string;
}

interface AssignmentRequest {
  id: string;
  description: string;
  status: string;
  urgencyLevel: string;
  preferredDate: string | null;
  createdAt: string;
  provider: { businessName: string; category: string } | null;
}

interface AssignmentBlock {
  property: { id: string; name: string; propertyType: string; address: string | null };
  role: string;
  cleaning: { upcoming: AssignmentStay[] };
  maintenance: { open: AssignmentRequest[] };
}

const ROLE_LABELS: Record<string, string> = {
  OWNER: 'Propriétaire',
  MANAGER: 'Manager',
  CLEANER: 'Ménage',
  MAINTENANCE: 'Maintenance',
};
/** PENDING='À faire' (orange) · IN_PROGRESS='En cours' (bleu) · DONE='Terminé' (vert). */
function cleaningBadge(status: string): { label: string; className: string } {
  if (status === 'PENDING') return { label: 'À faire', className: 'border-orange-200 bg-orange-50 text-orange-700' };
  if (status === 'IN_PROGRESS') return { label: 'En cours', className: 'border-sky-200 bg-sky-50 text-sky-700' };
  if (status === 'DONE') return { label: 'Terminé', className: 'border-emerald-200 bg-emerald-50 text-emerald-700' };
  return { label: status, className: 'border-slate-200 bg-slate-100 text-slate-600' };
}

function requestBadge(status: string): { label: string; className: string } {
  if (status === 'pending') return { label: 'En attente', className: 'border-slate-200 bg-slate-100 text-slate-600' };
  if (status === 'accepted') return { label: 'Acceptée', className: 'border-amber-200 bg-amber-50 text-amber-700' };
  if (status === 'in_progress') return { label: 'En cours', className: 'border-sky-200 bg-sky-50 text-sky-700' };
  return { label: status, className: 'border-slate-200 bg-slate-100 text-slate-600' };
}

function urgencyBadge(level: string): { label: string; className: string } | null {
  if (level === 'urgent') return { label: 'Urgent', className: 'border-orange-200 bg-orange-50 text-orange-700' };
  if (level === 'emergency') return { label: 'Urgence', className: 'border-red-200 bg-red-50 text-red-700' };
  return null; // 'normal' → pas de badge bruyant
}

function formatDay(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
}

function formatDayTime(iso: string): string {
  return new Date(iso).toLocaleDateString('fr-FR', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function MyAssignmentsContent() {
  const [assignments, setAssignments] = useState<AssignmentBlock[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Charge les affectations réelles. mode='retry' (bouton Réessayer)
  // repasse par le skeleton ; l'effet initial est déjà « loading ».
  const load = useCallback(async (mode: 'initial' | 'retry') => {
    if (mode === 'retry') setLoading(true);
    try {
      const res = await fetch('/api/airbnb/my-assignments', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as
        | { assignments?: AssignmentBlock[]; error?: string }
        | null;
      if (!res.ok || !json) {
        setError(json?.error ?? 'Impossible de charger vos tâches.');
        setAssignments(null);
        return;
      }
      setError('');
      setAssignments(json.assignments ?? []);
    } catch {
      setError('Connexion impossible. Réessayez.');
      setAssignments(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load('initial');
  }, [load]);

  const hasNoTask =
    (assignments ?? []).length === 0 ||
    (assignments ?? []).every(
      (a) => a.cleaning.upcoming.length === 0 && a.maintenance.open.length === 0,
    );

  return (
    <div className="max-w-4xl mx-auto w-full">
      {/* ----- En-tête ----- */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">🧹 Mes tâches</h1>
        <p className="text-sm text-slate-500 mt-1">
          Vos interventions à venir sur les biens de l&apos;équipe.
        </p>
      </div>

      {/* ----- Chargement (skeleton) ----- */}
      {loading && (
        <div className="space-y-4" aria-busy="true" aria-label="Chargement de vos tâches">
          {[0, 1].map((i) => (
            <div key={i} className="bg-card border border-border rounded-2xl p-4 space-y-3">
              <Skeleton className="h-6 w-44 rounded-lg" />
              <Skeleton className="h-16 w-full rounded-xl" />
              <Skeleton className="h-16 w-full rounded-xl" />
            </div>
          ))}
        </div>
      )}

      {/* ----- Erreur + Réessayer ----- */}
      {!loading && error && (
        <div className="bg-card border border-border rounded-2xl p-8 text-center" role="alert">
          <p className="text-3xl" aria-hidden="true">🔌</p>
          <p className="mt-2 text-sm text-slate-600">{error}</p>
          <Button className="mt-4" onClick={() => void load('retry')}>
            Réessayer
          </Button>
        </div>
      )}

      {/* ----- État vide ----- */}
      {!loading && !error && hasNoTask && (
        <div className="bg-card border border-border rounded-2xl p-10 text-center">
          <p className="text-4xl" aria-hidden="true">🎉</p>
          <p className="mt-3 text-sm font-semibold text-slate-900">Aucune tâche pour le moment 🎉</p>
          <p className="mt-1 text-sm text-slate-500">
            Les nouveaux séjours et réclamations apparaîtront ici automatiquement.
          </p>
        </div>
      )}

      {/* ----- Tâches par bien ----- */}
      {!loading && !error && !hasNoTask && (
        <div className="space-y-5">
          {(assignments ?? []).map((block) => {
            const roleLabel = ROLE_LABELS[block.role] ?? block.role;
            const propertyEmpty =
              block.cleaning.upcoming.length === 0 && block.maintenance.open.length === 0;
            if (propertyEmpty) return null;
            return (
              <section
                key={block.property.id}
                aria-label={`Tâches pour ${block.property.name}`}
                className="bg-card border border-border rounded-2xl p-4 sm:p-5"
              >
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <h2 className="text-base font-bold text-slate-900">
                    🏠 {block.property.name}
                  </h2>
                  <span className="rounded-full border border-slate-200 bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600">
                    {roleLabel}
                  </span>
                </div>

                {/* — Séjours à ménager (CLEANER / MANAGER / OWNER) — */}
                {block.cleaning.upcoming.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
                      🛏️ Séjours à ménager
                    </p>
                    <ul className="mt-2 space-y-2">
                      {block.cleaning.upcoming.map((stay) => {
                        const badge = cleaningBadge(stay.cleaningStatus);
                        return (
                          <li
                            key={stay.id}
                            className="flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-xl border border-slate-100 bg-slate-50/60 p-4"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-sm font-semibold text-slate-900">
                                {stay.guestName || 'Invité'}
                              </p>
                              <p className="text-xs text-slate-500">
                                🛬 {formatDay(stay.checkIn)} → 🛫 {formatDay(stay.checkOut)} ·{' '}
                                {stay.guests} voyageur{stay.guests > 1 ? 's' : ''}
                              </p>
                            </div>
                            <span
                              className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${badge.className}`}
                            >
                              {badge.label}
                            </span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}

                {/* — Réclamations ouvertes (MAINTENANCE / MANAGER / OWNER) — */}
                {block.maintenance.open.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
                      🔧 Réclamations ouvertes
                    </p>
                    <ul className="mt-2 space-y-2">
                      {block.maintenance.open.map((req) => {
                        const badge = requestBadge(req.status);
                        const urgency = urgencyBadge(req.urgencyLevel);
                        return (
                          <li
                            key={req.id}
                            className="flex flex-wrap items-start gap-x-3 gap-y-1.5 rounded-xl border border-slate-100 bg-slate-50/60 p-4"
                          >
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-semibold text-slate-900 line-clamp-2">
                                {req.description || 'Réclamation sans description'}
                              </p>
                              <p className="mt-0.5 text-xs text-slate-500">
                                🗓️ {formatDayTime(req.preferredDate ?? req.createdAt)}
                                {req.provider?.businessName
                                  ? ` · 🧰 ${req.provider.businessName}`
                                  : ''}
                              </p>
                            </div>
                            <div className="flex shrink-0 items-center gap-1.5">
                              {urgency && (
                                <span
                                  className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${urgency.className}`}
                                >
                                  {urgency.label}
                                </span>
                              )}
                              <span
                                className={`rounded-full border px-2.5 py-0.5 text-xs font-semibold ${badge.className}`}
                              >
                                {badge.label}
                              </span>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                )}
              </section>
            );
          })}

          <p className="text-center text-xs text-slate-400">
            💡 Une question ? <Link href="/airbnb/messages" className="font-semibold underline underline-offset-2 hover:text-slate-600">Écrivez à l&apos;équipe</Link>
          </p>
        </div>
      )}
    </div>
  );
}
