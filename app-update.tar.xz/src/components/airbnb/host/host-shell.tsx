'use client';

import { type ReactNode, useState, useSyncExternalStore } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { signOut } from 'next-auth/react';
import { motion } from 'framer-motion';
import {
  BadgeCheck,
  BellRing,
  CalendarDays,
  ClipboardList,
  ConciergeBell,
  CreditCard,
  FileText,
  Gift,
  Heart,
  Home,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Plus,
  QrCode,
  Search,
  Settings,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  SprayCan,
  Users,
  Wrench,
  type LucideIcon,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Toaster } from '@/components/ui/sonner';
import { NotificationsBell } from '@/components/airbnb/notifications-bell';
import { MessagesButton, MessagesNavBadge } from '@/components/airbnb/messages-badge';
import {
  HostProvider,
  useHostContext,
  type HostProperty,
} from '@/components/airbnb/host/host-context';
import { cn } from '@/lib/utils';
import { ThemeToggle } from '@/components/shared/theme-toggle';
// v4.77-c2 « ADMIN I18N » — libellés du shell (sidebar/header) en 5 langues.
import { AdminLangProvider, useAdminLang } from '@/lib/admin-i18n';
import { AdminLangSwitcher } from '@/components/admin/lang-switcher';

// =============================================================
// HostShell — v7.0 « AZUR » — refonte design du shell Espace Hôte
// (/airbnb/*) — demande client : style dashboard bleu/lavande
// (référence fournie) :
//  • Sidebar BLEUE vive en dégradé vertical #4A8BFF → #2563EB,
//    icônes lucide blanches, item actif = pastille bg-white/20 +
//    ring-white/40, logo = carré blanc arrondi avec icône bleue ;
//  • Fond console LAVANDE #E4E9F7 explicite (rendu identique en
//    mode clair ET sombre — aucune manipulation de <html>) ;
//  • Topbar blanche translucide (bg-white/80 backdrop-blur
//    rounded-2xl) avec recherche rapide, sélecteur de propriété,
//    messages, alertes, ajout de bien ;
//  • Rôles conservés : managementOnly / ownerOnly / teamMemberOnly
//    (AUDIT 4-c inchangé) · Navigation et badges inchangés.
// =============================================================

interface NavItem {
  href: string;
  label: string;
  /** Icône lucide blanche de l'entrée (design « AZUR »). */
  icon: LucideIcon;
  /** Réservé aux profils de gestion (owner / manager). */
  managementOnly: boolean;
  /** Réservé au propriétaire d'au moins un bien (Facturation). */
  ownerOnly?: boolean;
  /** Réservé aux membres d'équipe — masqué d'un propriétaire pur. */
  teamMemberOnly?: boolean;
}

const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: 'Pilotage',
    items: [
      { href: '/airbnb/dashboard', label: "Vue d'ensemble", icon: LayoutDashboard, managementOnly: false },
      { href: '/airbnb/dashboard/coach', label: 'Coach IA', icon: Sparkles, managementOnly: true },
      { href: '/airbnb/calendar', label: 'Calendrier', icon: CalendarDays, managementOnly: false },
      // AUDIT 4-c — interventions des membres d'équipe (ménage, maintenance).
      { href: '/airbnb/my-assignments', label: 'Mes tâches', icon: ClipboardList, managementOnly: false, teamMemberOnly: true },
      { href: '/airbnb/messages', label: 'Messages', icon: MessageSquare, managementOnly: false },
      // v4.69 — PHASE 2 — mini-CRM « Invités » (historique complet par séjour).
      // v5.3 — renommé « Séjours » (vocabulaire client) : chaque séjour
      // porte ses encarts check-in / check-out + recherche date & nom.
      { href: '/airbnb/guests', label: 'Séjours', icon: Users, managementOnly: false },
    ],
  },
  {
    label: 'Mes biens',
    items: [
      { href: '/airbnb/properties', label: 'Propriétés', icon: Home, managementOnly: false },
      { href: '/airbnb/plates', label: 'Plaques QR', icon: QrCode, managementOnly: false },
      // PREMIUM (V5) : /airbnb/guest-experience redirige vers le bien sélectionné.
      { href: '/airbnb/guest-experience', label: 'Expérience Invité', icon: Heart, managementOnly: true },
      // v4.74 « SMART PROMPTS » — notifications temporelles du hub.
      { href: '/airbnb/notifications', label: 'Notifications', icon: BellRing, managementOnly: true },
      // v4.74 « BOUTIQUE DE SOUVENIRS » — produits vendus au départ.
      { href: '/airbnb/souvenirs', label: 'Souvenirs', icon: Gift, managementOnly: true },
    ],
  },
  {
    label: 'Services',
    items: [
      // DIGITAL CONCIERGE (V4.1) — managementOnly : codes d'accès sensibles.
      { href: '/airbnb/concierge', label: 'Conciergerie', icon: ConciergeBell, managementOnly: true },
      // v4.43 « ONGLET MÉNAGE DÉDIÉ ».
      { href: '/airbnb/menage', label: 'Ménage & Stock', icon: SprayCan, managementOnly: true },
      // v4.103 — MODULE STANDALONE « ÉTAT DES LIEUX » (299 €/an) :
      // l'hôte crée, partage et suit ses EDL (dashboard dédié hors shell).
      { href: '/inspection/dashboard', label: 'États des Lieux', icon: ShieldCheck, managementOnly: true },
      // v5.3 — « Documents » : bibliothèque des PDF d'inspection avec
      // filtres (Tous / Entrée / Sortie / Complet), recherche et poids.
      { href: '/airbnb/documents', label: 'Documents', icon: FileText, managementOnly: true },
      { href: '/airbnb/providers', label: 'Prestataires', icon: Wrench, managementOnly: false },
      { href: '/airbnb/team', label: 'Équipe', icon: Users, managementOnly: true },
    ],
  },
  {
    label: 'Business',
    items: [
      { href: '/airbnb/orders', label: 'Commandes & Revenus', icon: ShoppingBag, managementOnly: true },
      // AUDIT 4-c — ownerOnly : masquée aux managers / membres d'équipe.
      { href: '/airbnb/billing', label: 'Facturation', icon: CreditCard, managementOnly: true, ownerOnly: true },
      // v5.3 — « Gérer mon abonnement » : offres 1-3 biens 299 €, 4-20
      // biens 499 €, 20+ sur devis — détail des prestations par offre.
      { href: '/airbnb/subscription', label: 'Gérer mon abonnement', icon: BadgeCheck, managementOnly: true, ownerOnly: true },
      { href: '/airbnb/settings', label: 'Paramètres', icon: Settings, managementOnly: true },
    ],
  },
];

function initialsOf(name: string | null | undefined): string {
  return (
    name
      ?.trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || '?'
  );
}

export interface HostShellProps {
  children: ReactNode;
  userName: string | null;
  userEmail: string | null;
  planName: string;
  accessLevel: 'full' | 'team';
}

export function HostShell({ children, userName, userEmail, planName, accessLevel }: HostShellProps) {
  const firstName = userName?.trim().split(/\s+/)[0] ?? 'Hôte';

  return (
    // v4.77-c2 — le shell (sidebar + header) est traduit en 5 langues via
    // AdminLangProvider (langue partagée avec le login et le hub hôte).
    <AdminLangProvider>
    <HostProvider accessLevel={accessLevel} userFirstName={firstName}>
      <ShellRoot
        userName={userName}
        userEmail={userEmail}
        planName={planName}
        accessLevel={accessLevel}
      >
        {children}
      </ShellRoot>
    </HostProvider>
    </AdminLangProvider>
  );
}

function ShellRoot({
  children,
  userName,
  userEmail,
  planName,
  accessLevel,
}: Required<Omit<HostShellProps, 'children'>> & { children: ReactNode }) {
  const pathname = usePathname();
  // v4.77-c2 — traduction des libellés du shell (clé = texte FR source).
  const { t } = useAdminLang();
  const [mobileOpen, setMobileOpen] = useState(false);
  // v7.0 « AZUR » — recherche rapide de navigation (UI seule : filtre
  // les entrées de menu existantes, aucune logique métier).
  const [navQuery, setNavQuery] = useState('');
  // Portfolio déjà chargé par le HostProvider (une seule requête
  // /api/airbnb/properties pour tout le shell) — sert à dériver
  // l'ownership réel sans nouvelle requête (audit 4-c).
  const { properties, plan } = useHostContext();
  // Vrai uniquement après hydratation — évite le mismatch des IDs Radix
  // auto-générés (aria-controls) entre le rendu serveur et le client.
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  // AUDIT 4-c — ownership réel : au moins un bien possédé (isOwner
  // par bien, ou ownedCount du plan renvoyé par l'API portfolio).
  const ownsAProperty =
    properties.some((p: HostProperty) => p.isOwner) || (plan?.ownedCount ?? 0) > 0;
  // Membre d'équipe quelque part (bien accessible non possédé) →
  // CLEANER / MAINTENANCE / MANAGER membre d'un bien d'autrui.
  const isTeamMemberSomewhere = properties.some((p: HostProperty) => !p.isOwner);

  const isItemVisible = (item: NavItem): boolean => {
    if (item.ownerOnly) return accessLevel === 'full' && ownsAProperty;
    if (item.teamMemberOnly) return accessLevel === 'team' || isTeamMemberSomewhere;
    return accessLevel === 'full' || !item.managementOnly;
  };

  // v4.60 — sur une page « expérience invité » (détail bien
  // /airbnb/properties/[id]/guest-experience), seul l'onglet
  // « Expérience Invité » s'allume — pas « Propriétés » en même temps.
  const isActive = (item: NavItem): boolean => {
    if (item.href === '/airbnb/dashboard') return pathname === '/airbnb/dashboard';
    // v4.74 — pages détaillées /properties/[id]/notifications et /souvenirs :
    // seul l'onglet dédié s'allume (pas « Propriétés » en même temps).
    if (pathname.includes('/notifications')) return item.href === '/airbnb/notifications';
    if (pathname.includes('/souvenirs')) return item.href === '/airbnb/souvenirs';
    if (pathname.includes('/guest-experience')) return item.href === '/airbnb/guest-experience';
    return pathname.startsWith(item.href);
  };

  // Résultats de la recherche rapide (entrées de menu visibles uniquement).
  // Calcul direct (liste ~20 entrées) — pas de mémoisation nécessaire.
  const navQueryTrimmed = navQuery.trim().toLowerCase();
  const navResults =
    navQueryTrimmed.length < 1
      ? []
      : NAV_GROUPS.flatMap((g) => g.items)
          .filter(isItemVisible)
          .filter((item) => item.label.toLowerCase().includes(navQueryTrimmed))
          .slice(0, 6);

  // La nav groupée est réutilisée par la sidebar desktop ET le drawer
  // mobile : au clic sur un lien on referme le drawer (no-op desktop).
  const navList = (
    <nav
      aria-label={t("Navigation de l'espace hôte")}
      className="flex flex-col gap-5 px-4"
      onClick={() => setMobileOpen(false)}
    >
      {NAV_GROUPS.map((group) => {
        const items = group.items.filter(isItemVisible);
        if (items.length === 0) return null;
        return (
          <div key={group.label}>
            <p className="mb-2 px-1 text-[10px] font-bold uppercase tracking-[0.22em] text-white/60">
              {t(group.label)}
            </p>
            <div className="flex flex-col gap-1">
              {items.map((item, i) => {
                const active = isActive(item);
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.href}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.025 * i, duration: 0.22, ease: 'easeOut' }}
                  >
                    <Link
                      href={item.href}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        // v7.0 « AZUR » — item actif = pastille blanche
                        // translucide + anneau blanc (demande client).
                        'group flex min-h-[38px] items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-[13px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60',
                        active
                          ? 'bg-white/20 text-white ring-1 ring-white/40'
                          : 'text-white/80 hover:bg-white/10 hover:text-white',
                      )}
                    >
                      <Icon
                        className={cn('h-[17px] w-[17px] shrink-0', active ? 'text-white' : 'text-white/70 group-hover:text-white')}
                        aria-hidden="true"
                      />
                      <span className="truncate">{t(item.label)}</span>
                      {/* Onglet MESSAGES : badge vocaux non lus + signalements ouverts */}
                      {item.href === '/airbnb/messages' && <MessagesNavBadge />}
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          </div>
        );
      })}
    </nav>
  );

  const logo = (
    <Link href="/" aria-label={t('Retour au site RoomScan')} className="flex items-center gap-2.5 px-5 py-1">
      {/* v7.0 « AZUR » — logo = CARRÉ BLANC arrondi avec icône bleue */}
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-white shadow-md shadow-blue-900/20">
        <Image
          src="/brand/roomscan-icon.png"
          alt=""
          width={64}
          height={64}
          className="h-6 w-6 object-contain"
        />
      </span>
      <span className="flex min-w-0 flex-col leading-tight">
        <span className="truncate text-[15px] font-bold text-white">RoomScan</span>
        <span className="text-[9px] font-bold uppercase tracking-[0.28em] text-white/70">
          {t('Espace Hôte')}
        </span>
      </span>
    </Link>
  );

  const profileBlock = (
    <div className="mx-3 mb-4">
      <div className="mb-2 flex items-center justify-end px-1">
        <ThemeToggle variant="light" />
      </div>
      <div className="flex items-center gap-2.5 rounded-2xl border border-white/20 bg-white/10 px-3 py-2.5">
        <span
          aria-hidden="true"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-xs font-bold text-[#2563EB]"
        >
          {initialsOf(userName)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold text-white">{userName ?? t('Invité')}</p>
          <p className="truncate text-[10px] font-semibold uppercase tracking-[0.14em] text-white/60">{planName}</p>
        </div>
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: '/' })}
          title={t('Se déconnecter')}
          aria-label={t('Se déconnecter')}
          className="shrink-0 rounded-lg p-1.5 text-white/70 transition-colors hover:bg-white/15 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/60"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
        </button>
      </div>
    </div>
  );

  return (
    // v8.0 « ENCRE NOIRE + THÈMES RÉELS » — le blocage des variables
    // claires en inline (qui empêchait le bouton sombre/clair de rien
    // changer) est SUPPRIMÉ : le shell suit désormais le thème global
    // next-themes. Mode clair = lavande #E4E9F7 + encre NOIRE via la
    // couche .ink-scope (globals.css) ; mode sombre = nuit saphir
    // #070D1F + encres claires + surfaces cartes nuit. La sidebar
    // bleue garde son dégradé et son texte blanc dans les DEUX modes.
    // Les primitives shadcn (dialogs, sheets, selects…) suivent le
    // thème global — valeurs claires identiques à l'ancien épinglage.
    <div className="ink-scope flex min-h-screen bg-[#E4E9F7] text-slate-800 dark:bg-[#070D1F] dark:text-[#E8EEFA]">
      {/* ============ SIDEBAR DESKTOP (256px, dégradé bleu vif) ============ */}
      <aside
        className="fixed inset-y-0 left-0 z-40 hidden w-[256px] flex-col overflow-hidden md:flex"
        style={{ background: 'linear-gradient(180deg,#4A8BFF,#2563EB)' }}
      >
        <div className="relative z-10 flex h-16 items-center border-b border-white/15">{logo}</div>
        <div className="lux-scroll relative z-10 flex-1 overflow-y-auto py-4">{navList}</div>
        <div className="relative z-10">{profileBlock}</div>
      </aside>

      {/* ===================== CONTENU ===================== */}
      <div className="flex min-h-screen w-full flex-col md:ml-[256px] md:w-[calc(100%-256px)]">
        {/* ----- Topbar blanche translucide arrondie ----- */}
        <header className="sticky top-0 z-30 mx-3 mt-3 flex h-14 shrink-0 items-center gap-2 rounded-2xl border border-slate-100 bg-white/80 px-3 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] backdrop-blur dark:border-white/10 sm:mx-4 sm:gap-3 sm:px-4 lg:mx-6">
          {/* Burger mobile → drawer Sheet (monté après hydratation :
              IDs Radix stables, zéro mismatch aria-controls) */}
          {mounted ? (
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-9 rounded-xl px-3 text-xs font-semibold text-slate-600 hover:bg-slate-100 hover:text-slate-900 md:hidden"
                  aria-label={t('Ouvrir le menu')}
                >
                  {t('Menu')}
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="w-[290px] overflow-y-auto border-none p-0 text-white"
                style={{ background: 'linear-gradient(180deg,#4A8BFF,#2563EB)' }}
              >
                <SheetHeader className="border-b border-white/15 pb-2 pt-4">
                  <SheetTitle asChild>
                    <div>{logo}</div>
                  </SheetTitle>
                </SheetHeader>
                <div className="flex h-[calc(100%-5rem)] flex-col justify-between pb-4 pt-4">
                  <div className="lux-scroll flex-1 overflow-y-auto">{navList}</div>
                  {profileBlock}
                </div>
              </SheetContent>
            </Sheet>
          ) : (
            <span aria-hidden="true" className="h-9 w-9 shrink-0 md:hidden" />
          )}

          {/* Recherche rapide de navigation (UI seule — filtre les
              entrées de menu existantes, aucune logique métier) */}
          {mounted && (
            <div className="relative hidden min-w-0 flex-1 max-w-xs sm:block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden="true" />
              <input
                type="search"
                value={navQuery}
                onChange={(e) => setNavQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && navResults[0]) {
                    setNavQuery('');
                    window.location.assign(navResults[0].href);
                  }
                  if (e.key === 'Escape') setNavQuery('');
                }}
                placeholder={t('Rechercher…')}
                aria-label={t('Rechercher dans la navigation')}
                className="h-9 w-full rounded-xl border border-slate-200 bg-slate-50 pl-9 pr-3 text-sm text-slate-800 placeholder:text-slate-400 focus:border-blue-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
              />
              {navQuery.trim().length > 0 && (
                <div className="absolute left-0 top-full z-50 mt-2 w-72 rounded-xl border border-slate-100 bg-white p-1.5 shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)]">
                  {navResults.length === 0 ? (
                    <p className="px-3 py-2.5 text-xs text-slate-400">{t('Aucun résultat')}</p>
                  ) : (
                    navResults.map((item) => {
                      const Icon = item.icon;
                      return (
                        <Link
                          key={item.href}
                          href={item.href}
                          onClick={() => setNavQuery('')}
                          className="flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-slate-700 transition-colors hover:bg-slate-100 hover:text-slate-900"
                        >
                          <Icon className="h-4 w-4 shrink-0 text-blue-600" aria-hidden="true" />
                          <span className="truncate">{t(item.label)}</span>
                        </Link>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          )}

          {/* Sélecteur de propriété (multi-propriétés) — mobile : prend
              l'espace restant entre le Menu et les actions (largeur
              bornée, libellé tronqué) ; desktop : largeur naturelle. */}
          <div className="min-w-0 flex-1 sm:ml-0 sm:flex-none">
            <PropertySelector />
          </div>

          <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
            {/* v4.77-c2 — sélecteur de langue (5 drapeaux, dropdown) */}
            <AdminLangSwitcher />
            {/* Bouton MESSAGES (badge : vocales non lus + signalements) */}
            {accessLevel === 'full' && <MessagesButton />}
            <NotificationsBell />
            {accessLevel === 'full' && <AddPropertyButton />}
          </div>
        </header>

        {/* ----- Contenu scrollable ----- */}
        <motion.main
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="w-full flex-1 p-4 sm:p-6"
        >
          {children}
        </motion.main>

        {/* ----- Footer collé en bas (mt-auto) ----- */}
        <footer className="mt-auto py-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
          <p className="text-center text-xs text-slate-500">
            Copyright © <span className="font-bold text-slate-700">RoomScan</span> 2025
            — {t('La conciergerie digitale de vos locations, sans application')}
          </p>
        </footer>
      </div>

      <Toaster position="top-center" richColors />
    </div>
  );
}

// =============================================================
// Sélecteur de propriété du header — alimenté par HostContext
// =============================================================

function PropertySelector() {
  const {
    properties,
    propertiesLoading,
    selectedId,
    setSelectedId,
    selectedProperty,
  } = useHostContext();
  // v4.77-c2 — libellés du sélecteur traduits (clé = texte FR source).
  const { t } = useAdminLang();

  if (propertiesLoading) {
    return <Skeleton className="h-9 w-full max-w-[150px] rounded-xl bg-slate-200 sm:w-56" aria-hidden="true" />;
  }

  const showAllOption = properties.length > 1;
  const label =
    selectedId === 'all'
      ? `${t('Toutes les propriétés')} (${properties.length})`
      : selectedProperty?.name ?? t('Aucune propriété');

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex h-9 w-full max-w-[150px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium text-slate-700 transition-all hover:border-blue-300 hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40 sm:w-auto sm:max-w-[260px]"
          aria-label={`${t('Propriété sélectionnée')} : ${label}`}
        >
          <span
            className="h-2 w-2 shrink-0 rounded-full"
            style={{ backgroundColor: selectedId === 'all' ? '#10b981' : '#2563EB' }}
            aria-hidden="true"
          />
          <span className="truncate">{label}</span>
          <span className="shrink-0 text-slate-400" aria-hidden="true">▾</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64 border border-slate-100 bg-white text-slate-800 shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)]">
        <DropdownMenuLabel className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-400">
          {t('Propriété sélectionnée')}
        </DropdownMenuLabel>
        {showAllOption && (
          <>
            <DropdownMenuItem
              onClick={() => setSelectedId('all')}
              className="gap-2 rounded-lg focus:bg-slate-100 focus:text-slate-900"
              aria-selected={selectedId === 'all'}
            >
              <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: '#10b981' }} aria-hidden="true" />
              <span className="flex-1 truncate font-semibold">{t('Toutes les propriétés')}</span>
              {selectedId === 'all' && <span className="text-blue-600" aria-hidden="true">✓</span>}
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-slate-100" />
          </>
        )}
        {properties.map((p: HostProperty) => (
          <DropdownMenuItem
            key={p.id}
            onClick={() => setSelectedId(p.id)}
            className="gap-2 rounded-lg focus:bg-slate-100 focus:text-slate-900"
            aria-selected={selectedId === p.id}
          >
            <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: '#2563EB' }} aria-hidden="true" />
            <span className="flex-1 truncate">{p.name}</span>
            {selectedId === p.id && <span className="text-blue-600" aria-hidden="true">✓</span>}
          </DropdownMenuItem>
        ))}
        {properties.length === 0 && (
          <div className="px-2 py-3 text-center text-xs text-slate-400">
            {t("Aucune propriété pour l'instant — ajoutez-en une pour démarrer.")}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// =============================================================
// Bouton « Ajouter une propriété » du header
// =============================================================

function AddPropertyButton() {
  const router = useRouter();
  const { t } = useAdminLang();
  return (
    <Button
      type="button"
      onClick={() => router.push('/airbnb/properties?new=1')}
      // v7.0 « AZUR » — convention boutons : DÉGRADÉ BLEU = action
      // principale (demande client, ex-bouton rouge).
      className="h-9 rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-2.5 text-xs font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/50 sm:px-3.5"
      aria-label={t('Ajouter une propriété')}
    >
      {/* Responsive : icône seule en mobile, libellés au-delà de sm/lg. */}
      <Plus className="h-4 w-4 sm:hidden" aria-hidden="true" />
      <span className="hidden sm:inline lg:hidden">{t('Ajouter')}</span>
      <span className="hidden lg:inline">{t('Ajouter une propriété')}</span>
    </Button>
  );
}
