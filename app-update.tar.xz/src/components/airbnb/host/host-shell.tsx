'use client';

import { type ReactNode, useState, useSyncExternalStore } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { signOut } from 'next-auth/react';
import { motion } from 'framer-motion';
import {
  BadgeEuro,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  CreditCard,
  DoorOpen,
  Home,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquareText,
  Plus,
  Settings,
  ShoppingBag,
  Smartphone,
  Sparkles,
  SprayCan,
  Users,
  Wrench,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Toaster } from '@/components/ui/sonner';
import { NotificationsBell } from '@/components/airbnb/notifications-bell';
import { MessagesButton, MessagesNavBadge } from '@/components/airbnb/messages-badge';
import {
  HostProvider,
  useHostContext,
  type HostProperty,
} from '@/components/airbnb/host/host-context';
import { cn } from '@/lib/utils';
import { ThemeToggle } from '@/components/shared/theme-toggle';

// =============================================================
// HostShell — v4.59 « AIRBNB PRO » — refonte complète du shell
// Espace Hôte (/airbnb/*) :
//  • Sidebar gradient rausch (clair & dark) — même langage que la
//    Console Superadmin ;
//  • Navigation RÉORGANISÉE en 4 groupes simples (Pilotage /
//    Mes biens / Services / Business) + « Mes tâches » pour
//    l'équipe — plus de liste plate de 15 onglets ;
//  • Header glass : sélecteur de propriété, messages, cloche,
//    ajout de bien ;
//  • Rôles conservés : managementOnly / ownerOnly / teamMemberOnly
//    (AUDIT 4-c inchangé).
// =============================================================

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  /** Réservé aux profils de gestion (owner / manager). */
  managementOnly: boolean;
  /** Réservé au propriétaire d'au moins un bien (Facturation). */
  ownerOnly?: boolean;
  /** Réservé aux membres d'équipe — masqué d'un propriétaire pur. */
  teamMemberOnly?: boolean;
}

const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: 'Pilotage',
    items: [
      { href: '/airbnb/dashboard', icon: LayoutDashboard, label: "Vue d'ensemble", managementOnly: false },
      { href: '/airbnb/calendar', icon: CalendarDays, label: 'Calendrier', managementOnly: false },
      // AUDIT 4-c — interventions des membres d'équipe (ménage, maintenance).
      { href: '/airbnb/my-assignments', icon: SprayCan, label: 'Mes tâches', managementOnly: false, teamMemberOnly: true },
      { href: '/airbnb/messages', icon: MessageSquareText, label: 'Messages', managementOnly: false },
      // v4.69 — PHASE 2 — mini-CRM « Invités » (historique complet par séjour).
      { href: '/airbnb/guests', icon: Users, label: 'Invités', managementOnly: false },
    ],
  },
  {
    label: 'Mes biens',
    items: [
      { href: '/airbnb/properties', icon: Home, label: 'Propriétés', managementOnly: false },
      { href: '/airbnb/plates', icon: Smartphone, label: 'Plaques QR', managementOnly: false },
      // PREMIUM (V5) : /airbnb/guest-experience redirige vers le bien sélectionné.
      { href: '/airbnb/guest-experience', icon: Sparkles, label: 'Expérience Invité', managementOnly: true },
      // v4.74 « SMART PROMPTS » — notifications temporelles du hub.
      { href: '/airbnb/notifications', icon: Bell, label: 'Notifications', managementOnly: true },
      // v4.74 « BOUTIQUE DE SOUVENIRS » — produits vendus au départ.
      { href: '/airbnb/souvenirs', icon: ShoppingBag, label: 'Souvenirs', managementOnly: true },
    ],
  },
  {
    label: 'Services',
    items: [
      // DIGITAL CONCIERGE (V4.1) — managementOnly : codes d'accès sensibles.
      { href: '/airbnb/concierge', icon: KeyRound, label: 'Conciergerie', managementOnly: true },
      // v4.43 « ONGLET MÉNAGE DÉDIÉ ».
      { href: '/airbnb/menage', icon: SprayCan, label: 'Ménage & Stock', managementOnly: true },
      { href: '/airbnb/providers', icon: Wrench, label: 'Prestataires', managementOnly: false },
      { href: '/airbnb/team', icon: Users, label: 'Équipe', managementOnly: true },
    ],
  },
  {
    label: 'Business',
    items: [
      { href: '/airbnb/orders', icon: BadgeEuro, label: 'Commandes & Revenus', managementOnly: true },
      // AUDIT 4-c — ownerOnly : masquée aux managers / membres d'équipe.
      { href: '/airbnb/billing', icon: CreditCard, label: 'Facturation', managementOnly: true, ownerOnly: true },
      { href: '/airbnb/settings', icon: Settings, label: 'Paramètres', managementOnly: true },
    ],
  },
];

function initialsOf(name: string | null | undefined): string {
  return (
    name
      ?.trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || '?'
  );
}

export interface HostShellProps {
  children: ReactNode;
  userName: string | null;
  userEmail: string | null;
  planName: string;
  accessLevel: 'full' | 'team';
}

export function HostShell({ children, userName, userEmail, planName, accessLevel }: HostShellProps) {
  const firstName = userName?.trim().split(/\s+/)[0] ?? 'Hôte';

  return (
    <HostProvider accessLevel={accessLevel} userFirstName={firstName}>
      <ShellRoot
        userName={userName}
        userEmail={userEmail}
        planName={planName}
        accessLevel={accessLevel}
      >
        {children}
      </ShellRoot>
    </HostProvider>
  );
}

function ShellRoot({
  children,
  userName,
  userEmail,
  planName,
  accessLevel,
}: Required<Omit<HostShellProps, 'children'>> & { children: ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  // Portfolio déjà chargé par le HostProvider (une seule requête
  // /api/airbnb/properties pour tout le shell) — sert à dériver
  // l'ownership réel sans nouvelle requête (audit 4-c).
  const { properties, plan } = useHostContext();
  // Vrai uniquement après hydratation — évite le mismatch des IDs Radix
  // auto-générés (aria-controls) entre le rendu serveur et le client.
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  // AUDIT 4-c — ownership réel : au moins un bien possédé (isOwner
  // par bien, ou ownedCount du plan renvoyé par l'API portfolio).
  const ownsAProperty =
    properties.some((p: HostProperty) => p.isOwner) || (plan?.ownedCount ?? 0) > 0;
  // Membre d'équipe quelque part (bien accessible non possédé) →
  // CLEANER / MAINTENANCE / MANAGER membre d'un bien d'autrui.
  const isTeamMemberSomewhere = properties.some((p: HostProperty) => !p.isOwner);

  const isItemVisible = (item: NavItem): boolean => {
    if (item.ownerOnly) return accessLevel === 'full' && ownsAProperty;
    if (item.teamMemberOnly) return accessLevel === 'team' || isTeamMemberSomewhere;
    return accessLevel === 'full' || !item.managementOnly;
  };

  // v4.60 — sur une page « expérience invité » (détail bien
  // /airbnb/properties/[id]/guest-experience), seul l'onglet
  // « Expérience Invité » s'allume — pas « Propriétés » en même temps.
  const isActive = (item: NavItem): boolean => {
    if (item.href === '/airbnb/dashboard') return pathname === '/airbnb/dashboard';
    // v4.74 — pages détaillées /properties/[id]/notifications et /souvenirs :
    // seul l'onglet dédié s'allume (pas « Propriétés » en même temps).
    if (pathname.includes('/notifications')) return item.href === '/airbnb/notifications';
    if (pathname.includes('/souvenirs')) return item.href === '/airbnb/souvenirs';
    if (pathname.includes('/guest-experience')) return item.href === '/airbnb/guest-experience';
    return pathname.startsWith(item.href);
  };

  // La nav groupée est réutilisée par la sidebar desktop ET le drawer
  // mobile : au clic sur un lien on referme le drawer (no-op desktop).
  const navList = (
    <nav
      aria-label="Navigation de l'espace hôte"
      className="flex flex-col gap-4 px-3"
      onClick={() => setMobileOpen(false)}
    >
      {NAV_GROUPS.map((group, gi) => {
        const items = group.items.filter(isItemVisible);
        if (items.length === 0) return null;
        return (
          <div key={group.label}>
            <p
              className={cn(
                'mb-1.5 px-3 text-[10px] font-bold uppercase tracking-[0.14em] text-white/45',
                gi > 0 && 'mt-1',
              )}
            >
              {group.label}
            </p>
            <div className="flex flex-col gap-0.5">
              {items.map((item, i) => {
                const active = isActive(item);
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.href}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.025 * i, duration: 0.22, ease: 'easeOut' }}
                  >
                    <Link
                      href={item.href}
                      aria-current={active ? 'page' : undefined}
                      className={cn(
                        'group flex h-11 items-center gap-3 rounded-xl px-2.5 text-[14.5px] font-medium transition-all duration-200',
                        active
                          ? 'bg-white font-bold text-[#0047B3] shadow-lg'
                          : 'text-white/85 hover:bg-white/12 hover:text-white',
                      )}
                    >
                      <span
                        aria-hidden="true"
                        className={cn(
                          'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-colors',
                          active
                            ? 'bg-[#0066EF] text-white shadow-sm'
                            : 'bg-white/10 text-white/80 group-hover:bg-white/20 group-hover:text-white',
                        )}
                      >
                        <Icon className="h-[16px] w-[16px]" />
                      </span>
                      <span className="truncate">{item.label}</span>
                      {/* Onglet MESSAGES : badge vocaux non lus + signalements ouverts */}
                      {item.href === '/airbnb/messages' && <MessagesNavBadge />}
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          </div>
        );
      })}
    </nav>
  );

  const logo = (
    <Link href="/" aria-label="Retour au site RoomScan" className="flex items-center gap-2.5 px-5 py-1">
      {/* Logo officiel RoomScan — variante blanche (fonds sombres), proportions d'origine */}
      <Image
        src="/brand/roomscan-icon-white.png"
        alt=""
        width={124}
        height={121}
        className="shrink-0"
        style={{ height: 40, width: 'auto' }}
      />
      <span className="flex min-w-0 flex-col leading-tight">
        <span className="truncate text-[15px] font-bold text-white">RoomScan</span>
        <span className="text-[10px] font-semibold uppercase tracking-wider text-white/65">
          Espace Hôte
        </span>
      </span>
    </Link>
  );

  const profileBlock = (
    <div className="mx-3 mb-4">
      <div className="mb-2 flex items-center justify-end px-1">
        <ThemeToggle variant="light" />
      </div>
      <div className="flex items-center gap-2.5 rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur-sm">
        <span
          aria-hidden="true"
          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-xs font-extrabold text-[#0047B3] shadow"
        >
          {initialsOf(userName)}
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold text-white">{userName ?? 'Invité'}</p>
          <p className="truncate text-[11px] font-medium text-white/65">{planName}</p>
        </div>
        <button
          type="button"
          onClick={() => signOut({ callbackUrl: '/' })}
          title="Se déconnecter"
          aria-label="Se déconnecter"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/70 transition-colors hover:bg-white/15 hover:text-white"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* ===================== SIDEBAR DESKTOP (260px, gradient) ===================== */}
      <aside className="air-sidebar fixed inset-y-0 left-0 z-40 hidden w-[260px] flex-col overflow-hidden md:flex">
        <div className="relative z-10 flex h-16 items-center border-b border-white/10">{logo}</div>
        <div className="relative z-10 flex-1 overflow-y-auto py-4 scrollbar-thin">{navList}</div>
        <div className="relative z-10">{profileBlock}</div>
      </aside>

      {/* ===================== CONTENU ===================== */}
      <div className="dash-surface flex min-h-screen w-full flex-col md:ml-[260px] md:w-[calc(100%-260px)]">
        {/* ----- Header glass ----- */}
        <header className="air-header sticky top-0 z-30 flex h-16 shrink-0 items-center gap-2 border-b border-black/5 px-4 dark:border-white/10 sm:gap-3 sm:px-6">
          {/* Burger mobile → drawer Sheet (monté après hydratation :
              IDs Radix stables, zéro mismatch aria-controls) */}
          {mounted ? (
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden hover:bg-black/5 dark:hover:bg-white/10"
                  aria-label="Ouvrir le menu"
                >
                  <Menu className="h-5 w-5 text-foreground" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="air-sidebar w-[290px] overflow-y-auto border-none p-0"
              >
                <SheetHeader className="border-b border-white/10 pb-2 pt-4">
                  <SheetTitle asChild>
                    <div>{logo}</div>
                  </SheetTitle>
                </SheetHeader>
                <div className="flex h-[calc(100%-5rem)] flex-col justify-between pb-4 pt-4">
                  <div className="flex-1 overflow-y-auto scrollbar-thin">{navList}</div>
                  {profileBlock}
                </div>
              </SheetContent>
            </Sheet>
          ) : (
            <span aria-hidden="true" className="h-9 w-9 shrink-0 md:hidden" />
          )}

          {/* Sélecteur de propriété (multi-propriétés) */}
          <PropertySelector />

          <div className="ml-auto flex items-center gap-2 sm:gap-3">
            {/* Bouton MESSAGES (badge : vocales non lus + signalements) */}
            {accessLevel === 'full' && <MessagesButton />}
            <NotificationsBell />
            {accessLevel === 'full' && <AddPropertyButton />}
          </div>
        </header>

        {/* ----- Contenu scrollable ----- */}
        <motion.main
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="w-full flex-1 p-4 sm:p-6"
        >
          {children}
        </motion.main>

        {/* ----- Footer collé en bas (mt-auto) ----- */}
        <footer className="mt-auto border-t border-black/5 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] dark:border-white/10">
          <p className="text-center text-xs text-muted-foreground">
            Copyright © <span className="font-semibold text-foreground/80">RoomScan</span> 2025
            — La conciergerie digitale de vos locations, sans application
          </p>
        </footer>
      </div>

      <Toaster position="top-center" richColors />
    </div>
  );
}

// =============================================================
// Sélecteur de propriété du header — alimenté par HostContext
// =============================================================

function PropertySelector() {
  const {
    properties,
    propertiesLoading,
    selectedId,
    setSelectedId,
    selectedProperty,
  } = useHostContext();

  if (propertiesLoading) {
    return <Skeleton className="h-9 w-40 rounded-lg sm:w-56" aria-hidden="true" />;
  }

  const showAllOption = properties.length > 1;
  const label =
    selectedId === 'all'
      ? `Toutes les propriétés (${properties.length})`
      : selectedProperty?.name ?? 'Aucune propriété';

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          className="flex h-9 max-w-[190px] items-center gap-2 rounded-full border border-black/10 bg-white px-2.5 text-sm font-semibold text-foreground shadow-sm transition-all hover:shadow-md dark:border-white/15 dark:bg-white/10 sm:max-w-[260px] sm:px-3"
          aria-label={`Propriété sélectionnée : ${label}`}
        >
          <span
            aria-hidden="true"
            className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#0066EF] to-[#0047B3] text-white"
          >
            <DoorOpen className="h-3.5 w-3.5" />
          </span>
          <span className="truncate">{label}</span>
          <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64">
        <DropdownMenuLabel className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
          Propriété sélectionnée
        </DropdownMenuLabel>
        {showAllOption && (
          <>
            <DropdownMenuItem
              onClick={() => setSelectedId('all')}
              className="gap-2"
              aria-selected={selectedId === 'all'}
            >
              <span className="w-4 text-center" aria-hidden="true">🏢</span>
              <span className="flex-1 truncate font-semibold">Toutes les propriétés</span>
              {selectedId === 'all' && <Check className="h-4 w-4 text-[#0066EF]" />}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
          </>
        )}
        {properties.map((p: HostProperty) => (
          <DropdownMenuItem
            key={p.id}
            onClick={() => setSelectedId(p.id)}
            className="gap-2"
            aria-selected={selectedId === p.id}
          >
            <span className="w-4 text-center" aria-hidden="true">🏠</span>
            <span className="flex-1 truncate">{p.name}</span>
            {selectedId === p.id && <Check className="h-4 w-4 text-[#0066EF]" />}
          </DropdownMenuItem>
        ))}
        {properties.length === 0 && (
          <div className="px-2 py-3 text-center text-xs text-muted-foreground">
            Aucune propriété pour l&apos;instant — ajoutez-en une pour démarrer.
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

// =============================================================
// Bouton « Ajouter une propriété » du header
// =============================================================

function AddPropertyButton() {
  const router = useRouter();
  return (
    <Button
      type="button"
      onClick={() => router.push('/airbnb/properties?new=1')}
      className="air-gradient h-9 rounded-full px-2.5 text-sm font-bold text-white shadow-md transition-all hover:shadow-lg sm:px-4"
      aria-label="Ajouter une propriété"
    >
      <Plus className="h-4 w-4" aria-hidden="true" />
      <span className="hidden lg:inline">Ajouter une propriété</span>
    </Button>
  );
}
