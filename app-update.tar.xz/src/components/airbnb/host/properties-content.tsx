'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion, type Variants } from 'framer-motion';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { StatusBadge } from '@/components/airbnb/host/status-badge';
import { useHostContext, type HostProperty } from '@/components/airbnb/host/host-context';
import { useCreateProperty, type CreatePropertyResult } from '@/hooks/use-properties';
import { PROPERTY_TYPE_META, propertyTypeMeta } from '@/lib/b2b';
import { cn } from '@/lib/utils';
// v4.43 — autocomplétion d'adresse (Google Places / OpenStreetMap) :
// adresse complète + latitude/longitude exactes stockées en base.
import { AddressAutocomplete } from '@/components/airbnb/host/address-autocomplete';

// =============================================================
// PropertiesContent — page « Mes Propriétés » du Dashboard Client
// v5.2 « SAPHIR LUXE » — refonte design profonde (demande client) :
// mode sombre bleuté, SANS ICÔNES ni emojis (typographie, points
// colorés, monogrammes). Données, handlers et textes métier intacts.
//
// • Grille de PropertyCards (monogramme par bien, stats 30j réelles,
//   actions Voir / Modifier / Équipe + lien Hub public)
// • v5.3 (Task 3-b) — widgets contextuels par carte : mini-stats EDL
//   (check-ins réalisés, litiges, dernier check-in), badge de statut
//   « Protégé » / « Onboarding à finaliser », action rapide
//   « Nouveau séjour » (dialog local → POST bookings).
// • Wizard d'ajout 3 étapes (Informations → Configuration →
//   Plaque QR) branché sur useCreateProperty + POST /api/airbnb/plaques
// • Modale d'édition → PATCH /api/airbnb/properties/{id}
// • Bandeau de capacité de plan + bannière d'invitations
// =============================================================

const ROLE_LABELS: Record<string, string> = {
  OWNER: 'Propriétaire',
  MANAGER: 'Manager',
  CLEANER: 'Ménage',
  MAINTENANCE: 'Maintenance',
};

const WIZARD_STEPS = ['Informations', 'Configuration', 'Plaque QR'] as const;

/** Plaque QR renvoyée par POST /api/airbnb/plaques. */
interface GeneratedPlaque {
  id: string;
  hubSlug: string | null;
  status: string;
  activationCode: string;
}

const gridVariants: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06 } },
};

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.3, ease: 'easeOut' } },
};

// =============================================================
// Composant racine
// =============================================================

export function PropertiesContent({ openWizardOnInit = false }: { openWizardOnInit?: boolean }) {
  const router = useRouter();
  const { properties, propertiesLoading, propertiesError, plan, invitations, setSelectedId, refreshProperties } =
    useHostContext();

  const [wizardOpen, setWizardOpen] = useState(openWizardOnInit);
  const [editTarget, setEditTarget] = useState<HostProperty | null>(null);
  // v5.3 (Task 3-b) — bien cible du dialog « Nouveau séjour ».
  const [stayTarget, setStayTarget] = useState<HostProperty | null>(null);

  const openWizard = useCallback(() => setWizardOpen(true), []);

  return (
    <div className="flex flex-col gap-6">
      {/* ---------- En-tête ---------- */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400">Portfolio</p>
          <h1 className="font-bold mt-1 text-2xl font-semibold text-slate-800 sm:text-3xl">
            Mes Propriétés
          </h1>
          <p className="mt-1.5 text-xs text-slate-400 sm:text-sm">
            {properties.length} bien{properties.length > 1 ? 's' : ''} géré
            {properties.length > 1 ? 's' : ''}
            {plan ? (
              <>
                {' '}
                · Plan <span className="font-semibold text-slate-800">{plan.planName}</span>
              </>
            ) : null}
          </p>
        </div>
        <button
          type="button"
          onClick={openWizard}
          className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 w-full sm:w-auto"
          aria-label="Ajouter une propriété"
        >
          Ajouter une propriété
        </button>
      </div>

      {/* ---------- Bandeau de capacité (limite de plan atteinte) ---------- */}
      {plan && !plan.canAddProperty && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap items-center gap-3 rounded-2xl border border-[#F59E0B]/25 bg-[#F59E0B]/8 px-4 py-3"
          role="status"
        >
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: '#F59E0B' }} aria-hidden="true" />
          <p className="min-w-0 flex-1 text-sm text-amber-600">
            <span className="font-bold">
              Limite du plan atteinte ({plan.ownedCount}/{plan.maxProperties})
            </span>{' '}
            — passez à Airbnb Pro pour gérer jusqu&apos;à 10 biens et inviter une équipe.
          </p>
          <Link
            href="/airbnb/billing"
            className="inline-flex h-8 shrink-0 items-center rounded-full bg-[#F59E0B] px-3 text-xs font-semibold text-[#1a1206] transition-[filter] hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]/50"
          >
            Découvrir les offres
          </Link>
        </motion.div>
      )}

      {/* ---------- Bannière invitations en attente ---------- */}
      {invitations.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap items-center gap-3 rounded-2xl border border-[#F59E0B]/25 bg-[#F59E0B]/8 px-4 py-3"
          role="status"
        >
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: '#F59E0B' }} aria-hidden="true" />
          <p className="min-w-0 flex-1 text-sm text-amber-600">
            <span className="font-bold">Invitation</span> — {invitations[0].property.name} (
            {ROLE_LABELS[invitations[0].role] ?? invitations[0].role})
            {invitations.length > 1 && ` + ${invitations.length - 1} autre(s)`} — gérer dans Équipe
          </p>
          <Link
            href="/airbnb/team"
            className="inline-flex h-8 shrink-0 items-center rounded-full bg-[#F59E0B] px-3 text-xs font-semibold text-[#1a1206] transition-[filter] hover:brightness-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F59E0B]/50"
          >
            Voir l&apos;invitation
          </Link>
        </motion.div>
      )}

      {/* ---------- Erreur API ---------- */}
      {propertiesError && (
        <div
          className="flex items-center gap-3 rounded-2xl border border-[#F43F5E]/25 bg-[#F43F5E]/10 px-4 py-3 text-sm text-rose-600"
          role="alert"
        >
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: '#F43F5E' }} aria-hidden="true" />
          {propertiesError}
        </div>
      )}

      {/* ---------- Grille / empty state / chargement ---------- */}
      {propertiesLoading ? (
        <div
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3"
          aria-label="Chargement des propriétés"
        >
          {[0, 1, 2].map((i) => (
            <div key={i} className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] overflow-hidden">
              <Skeleton className="h-20 w-full rounded-none bg-slate-100" aria-hidden="true" />
              <div className="flex flex-col gap-3 p-4">
                <Skeleton className="h-5 w-2/3 bg-slate-100" aria-hidden="true" />
                <Skeleton className="h-4 w-4/5 bg-slate-100" aria-hidden="true" />
                <Skeleton className="h-10 w-full bg-slate-100" aria-hidden="true" />
                <Skeleton className="h-9 w-full bg-slate-100" aria-hidden="true" />
              </div>
            </div>
          ))}
        </div>
      ) : properties.length === 0 ? (
        <EmptyState onAdd={openWizard} />
      ) : (
        <motion.section
          aria-label="Vos propriétés"
          className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3"
          variants={gridVariants}
          initial="hidden"
          animate="show"
        >
          {properties.map((p, i) => (
            <PropertyCard
              key={p.id}
              property={p}
              index={i}
              onEdit={() => setEditTarget(p)}
              onView={() => {
                setSelectedId(p.id);
                router.push('/airbnb/dashboard');
              }}
              onTeam={() => router.push(`/airbnb/team?property=${p.id}`)}
              onNewStay={() => setStayTarget(p)}
            />
          ))}
        </motion.section>
      )}

      {/* ---------- Overlays ---------- */}
      <AddPropertyWizard open={wizardOpen} onOpenChange={setWizardOpen} />
      <NewStayDialog
        property={stayTarget}
        open={stayTarget !== null}
        onOpenChange={(open) => {
          if (!open) setStayTarget(null);
        }}
        onCreated={refreshProperties}
      />
      <EditPropertyDialog
        property={editTarget}
        open={editTarget !== null}
        onOpenChange={(open) => {
          if (!open) setEditTarget(null);
        }}
      />
    </div>
  );
}

// =============================================================
// PropertyCard — carte d'un bien du portfolio
// =============================================================

interface PropertyCardProps {
  property: HostProperty;
  index: number;
  onView: () => void;
  onEdit: () => void;
  onTeam: () => void;
  /** v5.3 (Task 3-b) — ouvre le dialog « Nouveau séjour » sur ce bien. */
  onNewStay: () => void;
}

function PropertyCard({ property: p, index, onView, onEdit, onTeam, onNewStay }: PropertyCardProps) {
  const typeMeta = propertyTypeMeta(p.propertyType);
  const canManage = p.isOwner || p.myRole === 'OWNER' || p.myRole === 'MANAGER';
  // v5.3 (Task 3-b) — mini-stats EDL (présence du check-in Hub = protection).
  const edl = p.edlStats ?? { checkinsDone: 0, litiges: 0, lastCheckinAt: null };
  const isProtected = edl.checkinsDone > 0;

  return (
    <motion.article
      variants={cardVariants}
      transition={{ duration: 0.3, delay: Math.min(index * 0.04, 0.24), ease: 'easeOut' }}
      whileHover={{ y: -4 }}
      className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] transition-shadow hover:shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)] group flex min-w-0 flex-col overflow-hidden"
    >
      {/* Bandeau : monogramme + type + statut */}
      <div className="relative flex h-20 shrink-0 items-center gap-3 border-b border-slate-100 bg-slate-50 px-4">
        <span
          aria-hidden="true"
          className="tabular-nums tracking-tight flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#3d6fe0]/15 text-lg font-semibold text-blue-700 ring-1 ring-[#2563EB]/25"
        >
          {p.name.trim().charAt(0).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400 !text-[9.5px]">{typeMeta.label}</p>
        </div>
        <span className="sr-only">{`Type : ${typeMeta.label}`}</span>
        <StatusBadge status={p.isActive ? 'active' : 'inactive'} className="shrink-0" />
      </div>

      {/* Corps : nom + rôle + adresse + lien hub */}
      <div className="min-w-0 p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-bold min-w-0 truncate text-lg font-semibold text-slate-800" title={p.name}>
            {p.name}
          </h3>
          <StatusBadge
            status={p.myRole}
            label={p.isOwner ? 'Propriétaire' : (ROLE_LABELS[p.myRole] ?? p.myRole)}
            className="shrink-0"
          />
        </div>
        <p className="mt-1.5 truncate text-sm text-slate-400" title={p.address ?? undefined}>
          {p.address ?? 'Adresse non renseignée'}
        </p>
        {p.qrHubSlug && (
          <a
            href={`/hub/${p.qrHubSlug}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 transition-colors hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]/50"
            aria-label={`Ouvrir le Hub public de ${p.name} dans un nouvel onglet`}
          >
            <span aria-hidden="true">→</span>
            Voir le Hub public
          </a>
        )}
      </div>

      {/* Stats 30 jours */}
      <div className="grid grid-cols-4 divide-x divide-slate-100 border-y border-slate-100 bg-slate-50 px-2 py-3 text-center">
        <div className="min-w-0">
          <p className="tabular-nums tracking-tight truncate text-sm font-semibold text-slate-800" title={`${p.stats.scans30d}`}>
            {p.stats.scans30d}
          </p>
          <p className="text-[10px] uppercase tracking-[0.14em] text-slate-400/80">scans</p>
        </div>
        <div className="min-w-0">
          <p
            className="tabular-nums tracking-tight truncate text-sm font-semibold text-slate-800"
            title={`${Math.round(p.stats.upsellRevenue30d)} €`}
          >
            {Math.round(p.stats.upsellRevenue30d)} €
          </p>
          <p className="text-[10px] uppercase tracking-[0.14em] text-slate-400/80">upsell 30j</p>
        </div>
        <div className="min-w-0">
          <p className="tabular-nums tracking-tight truncate text-sm font-semibold text-slate-800">
            {Math.round(p.stats.occupancyRate * 100)}%
          </p>
          <p className="text-[10px] uppercase tracking-[0.14em] text-slate-400/80">occ.</p>
        </div>
        <div className="min-w-0">
          <p className="tabular-nums tracking-tight truncate text-sm font-semibold text-slate-800" title={`${p.stats.qrCount}`}>
            {p.stats.qrCount}
          </p>
          <p className="text-[10px] uppercase tracking-[0.14em] text-slate-400/80">QR</p>
        </div>
      </div>

      {/* v5.3 (Task 3-b) — Widgets EDL : badge de statut + mini-stats */}
      <div className="flex flex-col gap-2 border-y border-slate-100 bg-slate-50 px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          {/* Badge de statut de protection */}
          {isProtected ? (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-emerald-300">
              <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              Protégé
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full border border-[#F59E0B]/40 bg-[#F59E0B]/10 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em] text-amber-600">
              <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-[#F59E0B]" />
              Onboarding à finaliser
            </span>
          )}
        </div>
        {/* Mini-stats EDL : check-ins réalisés · litiges · dernier check-in (fr-FR) */}
        <p className="text-xs text-slate-400">
          <span className="tabular-nums tracking-tight font-semibold text-slate-800">{edl.checkinsDone}</span>{' '}
          check-in{edl.checkinsDone > 1 ? 's' : ''} réalisé{edl.checkinsDone > 1 ? 's' : ''}
          <span aria-hidden="true"> · </span>
          <span className={cn(edl.litiges > 0 && 'font-semibold text-rose-600')}>
            {edl.litiges} litige{edl.litiges > 1 ? 's' : ''}
          </span>
          <span aria-hidden="true"> · </span>
          {edl.lastCheckinAt ? (
            <>
              Dernier check-in :{' '}
              <span className="font-semibold text-slate-800">
                {new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit' }).format(
                  new Date(edl.lastCheckinAt),
                )}
              </span>
            </>
          ) : (
            <>Dernier check-in : —</>
          )}
        </p>
      </div>

      {/* v5.3 (Task 3-b) — Action rapide « Nouveau séjour » (OWNER/MANAGER) */}
      {canManage && (
        <div className="px-3 pt-3">
          <button
            type="button"
            onClick={onNewStay}
            className="btn-primary-red w-full"
            aria-label={`Créer un nouveau séjour pour ${p.name}`}
          >
            Nouveau séjour
          </button>
        </div>
      )}

      {/* Actions */}
      <div className="mt-auto flex gap-2 p-3">
        <Button
          variant="outline"
          className="h-9 flex-1 rounded-full border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 hover:text-slate-900"
          onClick={onView}
          aria-label={`Voir le tableau de bord de ${p.name}`}
        >
          Voir
        </Button>
        {canManage && (
          <Button
            variant="outline"
            className="h-9 flex-1 rounded-full border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 hover:text-slate-900"
            onClick={onEdit}
            aria-label={`Modifier ${p.name}`}
          >
            Modifier
          </Button>
        )}
        <Button
          variant="outline"
          className="h-9 flex-1 rounded-full border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-slate-100 hover:text-slate-900"
          onClick={onTeam}
          aria-label={`Gérer l'équipe de ${p.name}`}
        >
          Équipe
        </Button>
      </div>
    </motion.article>
  );
}

// =============================================================
// EmptyState — aucune propriété
// =============================================================

function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="bg-slate-50 ring-1 ring-slate-100 flex flex-col items-center gap-2 px-6 py-12 text-center"
    >
      <span aria-hidden="true" className="h-2 w-2 rounded-full" style={{ backgroundColor: '#2563EB' }} />
      <h2 className="font-bold mt-2 text-lg font-semibold text-slate-800">
        Créez votre première propriété
      </h2>
      <p className="mx-auto mt-1 max-w-md text-xs text-slate-400">
        Ajoutez votre bien pour générer sa plaque QR, son Hub public voyageurs et centraliser
        scans, services, équipe et calendrier.
      </p>
      <button type="button" onClick={onAdd} className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 mt-4 w-full sm:w-auto" aria-label="Ajouter une première propriété">
        Ajouter une propriété
      </button>
    </motion.div>
  );
}

// =============================================================
// Stepper — 3 points numérotés reliés (wizard)
// =============================================================

function Stepper({ step }: { step: number }) {
  return (
    <ol
      className="flex items-center gap-2"
      aria-label={`Étape ${step} sur 3 : ${WIZARD_STEPS[step - 1]}`}
    >
      {WIZARD_STEPS.map((label, i) => {
        const n = i + 1;
        const done = n < step;
        const current = n === step;
        return (
          <li key={label} className="flex flex-1 items-center gap-2 last:flex-none">
            <span
              aria-current={current ? 'step' : undefined}
              className={cn(
                'flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-colors',
                done && 'bg-[#3d6fe0] text-slate-800',
                current && 'border border-[#F59E0B] bg-[#F59E0B]/10 text-amber-600',
                !done && !current && 'bg-slate-50 text-slate-400',
              )}
            >
              {done ? '✓' : n}
            </span>
            <span
              className={cn(
                'hidden text-xs font-semibold sm:block',
                current ? 'text-slate-800' : 'text-slate-400',
              )}
            >
              {label}
            </span>
            {n < WIZARD_STEPS.length && (
              <span
                aria-hidden="true"
                className={cn('h-0.5 min-w-4 flex-1 rounded-full', done ? 'bg-[#2563EB]/50' : 'bg-slate-100')}
              />
            )}
          </li>
        );
      })}
    </ol>
  );
}

// =============================================================
// AddPropertyWizard — création en 3 étapes
// =============================================================

interface AddPropertyWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function AddPropertyWizard({ open, onOpenChange }: AddPropertyWizardProps) {
  const router = useRouter();
  const { createProperty } = useCreateProperty();

  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [propertyType, setPropertyType] = useState('AIRBNB');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [hubPin, setHubPin] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [limitHit, setLimitHit] = useState<{ message: string } | null>(null);
  const [created, setCreated] = useState<NonNullable<CreatePropertyResult['property']> | null>(null);
  const [plaque, setPlaque] = useState<GeneratedPlaque | null>(null);

  const reset = useCallback(() => {
    setStep(1);
    setName('');
    setAddress('');
    setPropertyType('AIRBNB');
    setLatitude('');
    setLongitude('');
    setHubPin('');
    setErrors({});
    setSubmitting(false);
    setGenerating(false);
    setLimitHit(null);
    setCreated(null);
    setPlaque(null);
  }, []);

  const handleClose = useCallback(
    (nextOpen: boolean) => {
      onOpenChange(nextOpen);
      if (!nextOpen) reset();
    },
    [onOpenChange, reset],
  );

  // ----- Validation étape 1 -----
  const validateStep1 = useCallback((): boolean => {
    const next: Record<string, string> = {};
    const trimmedName = name.trim();
    const trimmedAddress = address.trim();
    if (trimmedName.length < 2 || trimmedName.length > 80) {
      next.name = 'Le nom doit contenir entre 2 et 80 caractères.';
    }
    if (!trimmedAddress) {
      next.address = "L'adresse du bien est requise.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }, [name, address]);

  // ----- Validation étape 2 (coordonnées + PIN) -----
  const validateStep2 = useCallback((): boolean => {
    const next: Record<string, string> = {};
    const lat = latitude.trim();
    const lng = longitude.trim();
    const pin = hubPin.trim();
    if (lat) {
      const num = Number(lat.replace(',', '.'));
      if (!Number.isFinite(num) || num < -90 || num > 90) {
        next.latitude = 'Latitude invalide (entre -90 et 90).';
      }
    }
    if (lng) {
      const num = Number(lng.replace(',', '.'));
      if (!Number.isFinite(num) || num < -180 || num > 180) {
        next.longitude = 'Longitude invalide (entre -180 et 180).';
      }
    }
    if (pin && !/^\d{4}$/.test(pin)) {
      next.hubPin = 'Le PIN doit contenir exactement 4 chiffres.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }, [latitude, longitude, hubPin]);

  // ----- Soumission étape 2 → 3 -----
  const handleSubmit = useCallback(async () => {
    if (!validateStep2()) return;
    setSubmitting(true);
    setLimitHit(null);
    const latNum = latitude.trim() ? Number(latitude.trim().replace(',', '.')) : null;
    const lngNum = longitude.trim() ? Number(longitude.trim().replace(',', '.')) : null;
    const result = await createProperty({
      name: name.trim(),
      address: address.trim(),
      propertyType,
      latitude: latNum,
      longitude: lngNum,
      hubPin: hubPin.trim() || null,
    });
    setSubmitting(false);
    if (!result.ok) {
      if (result.status === 403 && result.upgrade) {
        // Limite de plan atteinte : toast + rester sur l'étape 2 + offre upgrade
        toast.error(result.message ?? result.error ?? 'Limite du plan atteinte.');
        setLimitHit({
          message: result.message ?? result.error ?? 'Limite du plan atteinte.',
        });
      } else {
        toast.error(result.error ?? 'Erreur lors de la création du bien.');
      }
      return;
    }
    setCreated(result.property ?? null);
    toast.success('Bien créé avec succès 🎉');
    setStep(3);
  }, [address, createProperty, hubPin, latitude, longitude, name, propertyType, validateStep2]);

  // ----- Génération de la plaque QR (étape 3) -----
  const handleGeneratePlaque = useCallback(async () => {
    if (!created) return;
    setGenerating(true);
    try {
      const res = await fetch('/api/airbnb/plaques', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ propertyId: created.id }),
      });
      const data = (await res.json().catch(() => ({}))) as { plaque?: GeneratedPlaque; error?: string };
      if (!res.ok || !data.plaque) {
        toast.error(data.error ?? 'Erreur lors de la génération de la plaque.');
        return;
      }
      setPlaque(data.plaque);
      toast.success('Plaque QR générée 📱');
    } catch (error) {
      console.error('[AddPropertyWizard] plaque generation failed:', error);
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setGenerating(false);
    }
  }, [created]);

  const copyToClipboard = useCallback(async (value: string, label: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} copié !`);
    } catch {
      toast.error('Copie impossible — sélectionnez le texte manuellement.');
    }
  }, []);

  const hubUrl =
    plaque?.hubSlug != null
      ? `${typeof window !== 'undefined' ? window.location.origin : ''}/hub/${plaque.hubSlug}`
      : null;

  const stepTitles: Record<number, { title: string; description: string }> = {
    1: {
      title: 'Ajouter une propriété',
      description: 'Étape 1/3 — Renseignez les informations principales de votre bien.',
    },
    2: {
      title: 'Ajouter une propriété',
      description: 'Étape 2/3 — Configuration optionnelle : géolocalisation et PIN Mode Hôte.',
    },
    3: {
      title: 'Ajouter une propriété',
      description: 'Étape 3/3 — Votre bien est créé : générez sa plaque QR pour le Hub public.',
    },
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-2xl border-slate-100 bg-[#FFFFFF] text-slate-800 shadow-2xl sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="font-bold text-xl font-semibold text-slate-800">
            {stepTitles[step].title}
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-400">
            {stepTitles[step].description}
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4">
          <Stepper step={step} />

          {/* ---------- Étape 1 : Informations ---------- */}
          {step === 1 && (
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="wizard-name" className="text-slate-400">Nom du bien *</Label>
                <Input
                  id="wizard-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex : Loft Canal Saint-Martin"
                  maxLength={80}
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? 'wizard-name-error' : undefined}
                  className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
                />
                {errors.name && (
                  <p id="wizard-name-error" className="text-xs font-medium text-rose-600">
                    {errors.name}
                  </p>
                )}
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="wizard-address" className="text-slate-400">Adresse *</Label>
                {/* v4.43 — autocomplétion : l'hôte tape les premières lettres,
                    choisit l'adresse → texte complet + lat/lng remplis auto. */}
                <AddressAutocomplete
                  id="wizard-address"
                  value={address}
                  onChange={(v) => {
                    setAddress(v);
                  }}
                  onSelect={(pick) => {
                    setAddress(pick.label);
                    if (pick.lat != null && pick.lng != null) {
                      setLatitude(String(pick.lat));
                      setLongitude(String(pick.lng));
                    }
                  }}
                  invalid={Boolean(errors.address)}
                  describedBy={errors.address ? 'wizard-address-error' : undefined}
                />
                <p className="text-[11px] text-slate-400">
                  Tapez les premières lettres : l&apos;adresse se complète et la position GPS
                  (latitude/longitude) est extraite automatiquement — activée pour le bouton
                  « Retour à la maison » des invités.
                </p>
                {errors.address && (
                  <p id="wizard-address-error" className="text-xs font-medium text-rose-600">
                    {errors.address}
                  </p>
                )}
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="wizard-type" className="text-slate-400">Type de bien</Label>
                <Select value={propertyType} onValueChange={setPropertyType}>
                  <SelectTrigger
                    id="wizard-type"
                    className="w-full rounded-xl border-slate-200 bg-slate-50 text-slate-800"
                    aria-label="Type de bien"
                  >
                    <SelectValue placeholder="Choisir un type" />
                  </SelectTrigger>
                  <SelectContent className="border-slate-100 bg-[#FFFFFF] text-slate-800">
                    {Object.entries(PROPERTY_TYPE_META).map(([key, meta]) => (
                      <SelectItem key={key} value={key} className="focus:bg-slate-100 focus:text-slate-900">
                        {meta.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* ---------- Étape 2 : Configuration ---------- */}
          {step === 2 && (
            <div className="flex flex-col gap-4">
              {limitHit && (
                <div
                  className="flex flex-wrap items-center gap-2 rounded-xl border border-[#F59E0B]/25 bg-[#F59E0B]/8 px-3 py-2.5 text-sm text-amber-600"
                  role="alert"
                >
                  <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: '#F59E0B' }} aria-hidden="true" />
                  <span className="min-w-0 flex-1 font-medium">{limitHit.message}</span>
                </div>
              )}
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="wizard-lat" className="text-slate-400">Latitude</Label>
                  <Input
                    id="wizard-lat"
                    value={latitude}
                    onChange={(e) => setLatitude(e.target.value)}
                    placeholder="48.8566"
                    inputMode="decimal"
                    aria-invalid={Boolean(errors.latitude)}
                    aria-describedby={errors.latitude ? 'wizard-lat-error' : 'wizard-coords-help'}
                    className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
                  />
                  {errors.latitude && (
                    <p id="wizard-lat-error" className="text-xs font-medium text-rose-600">
                      {errors.latitude}
                    </p>
                  )}
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="wizard-lng" className="text-slate-400">Longitude</Label>
                  <Input
                    id="wizard-lng"
                    value={longitude}
                    onChange={(e) => setLongitude(e.target.value)}
                    placeholder="2.3522"
                    inputMode="decimal"
                    aria-invalid={Boolean(errors.longitude)}
                    aria-describedby={errors.longitude ? 'wizard-lng-error' : 'wizard-coords-help'}
                    className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
                  />
                  {errors.longitude && (
                    <p id="wizard-lng-error" className="text-xs font-medium text-rose-600">
                      {errors.longitude}
                    </p>
                  )}
                </div>
              </div>
              <p id="wizard-coords-help" className="text-xs text-slate-400">
                Utilisez maps.google.com pour trouver les coordonnées — nécessaires pour
                l&apos;annuaire de prestataires géolocalisé.
              </p>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="wizard-pin" className="text-slate-400">PIN Mode Hôte (optionnel)</Label>
                <Input
                  id="wizard-pin"
                  type="password"
                  value={hubPin}
                  onChange={(e) => setHubPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  inputMode="numeric"
                  autoComplete="off"
                  aria-invalid={Boolean(errors.hubPin)}
                  aria-describedby={errors.hubPin ? 'wizard-pin-error' : 'wizard-pin-help'}
                  className={cn(
                    'w-40 rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50',
                    errors.hubPin && 'border-[#F43F5E]/60 focus-visible:ring-[#F43F5E]/50',
                  )}
                />
                {errors.hubPin ? (
                  <p id="wizard-pin-error" className="text-xs font-medium text-rose-600">
                    {errors.hubPin}
                  </p>
                ) : (
                  <p id="wizard-pin-help" className="text-xs text-slate-400">
                    Protège l&apos;accès tablette/QR du Hub — hashing bcrypt côté serveur.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* ---------- Étape 3 : Plaque QR ---------- */}
          {step === 3 && created && (
            <div className="flex flex-col gap-4">
              {/* Résumé du bien créé */}
              <div className="flex items-start gap-3 rounded-2xl border border-[#10b981]/25 bg-[#10b981]/8 p-4">
                <span className="h-2 w-2 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: '#10b981' }} aria-hidden="true" />
                <div className="min-w-0">
                  <p className="font-bold text-slate-800">{created.name}</p>
                  <p className="mt-0.5 truncate text-sm text-slate-400">
                    {address.trim()} · {propertyTypeMeta(propertyType).label}
                  </p>
                </div>
              </div>

              {!plaque ? (
                <div className="bg-slate-50 ring-1 ring-slate-100 flex flex-col items-center gap-3 p-6 text-center">
                  <p className="text-xs text-slate-400">
                    Générez la plaque QR de ce bien : son Hub public sera accessible par scan
                    (Wi-Fi, guidebook, upselling…).
                  </p>
                  <button
                    type="button"
                    className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-60"
                    onClick={() => void handleGeneratePlaque()}
                    disabled={generating}
                  >
                    Générer la plaque QR maintenant
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1.5 rounded-2xl border border-slate-100 bg-slate-50 p-4">
                    <div className="flex items-center justify-between gap-2">
                      <Label htmlFor="plaque-code" className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400 !text-[9.5px]">
                        Code d&apos;activation
                      </Label>
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-8 rounded-full border-slate-200 bg-slate-50 px-3 text-xs text-slate-700 hover:bg-slate-100 hover:text-slate-900"
                        onClick={() => void copyToClipboard(plaque.activationCode, 'Code')}
                        aria-label="Copier le code d'activation"
                      >
                        Copier
                      </Button>
                    </div>
                    <code
                      id="plaque-code"
                      className="tabular-nums tracking-tight select-all text-lg font-semibold tracking-[0.2em] text-amber-600"
                    >
                      {plaque.activationCode}
                    </code>
                  </div>

                  {hubUrl && (
                    <div className="flex flex-col gap-1.5 rounded-2xl border border-slate-100 bg-slate-50 p-4">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400 !text-[9.5px]">Lien du Hub public</span>
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-8 rounded-full border-slate-200 bg-slate-50 px-3 text-xs text-slate-700 hover:bg-slate-100 hover:text-slate-900"
                          onClick={() => void copyToClipboard(hubUrl, 'Lien')}
                          aria-label="Copier le lien du Hub public"
                        >
                          Copier
                        </Button>
                      </div>
                      <a
                        href={`/hub/${plaque.hubSlug}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex min-w-0 items-center gap-1.5 text-sm font-medium text-blue-700 transition-colors hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2563EB]/50"
                      >
                        <span aria-hidden="true">→</span>
                        <span className="truncate font-semibold">{hubUrl}</span>
                      </a>
                    </div>
                  )}

                  <p className="text-xs text-slate-400">
                    Imprimez la plaque et posez-la dans le logement — vos voyageurs scannent, tout
                    est là.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Garde : étape 3 sans `created` (ne devrait jamais arriver) */}
          {step === 3 && !created && (
            <p className="text-sm text-rose-600" role="alert">
              Une erreur est survenue. Fermez et relancez l&apos;assistant.
            </p>
          )}
        </div>
        <DialogFooter className="mt-1 gap-2">
          {step === 1 ? (
            <>
              <Button
                variant="outline"
                className="rounded-full border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900"
                onClick={() => handleClose(false)}
              >
                Annuler
              </Button>
              <button
                type="button"
                className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 px-4 text-xs"
                onClick={() => {
                  if (validateStep1()) {
                    setErrors({});
                    setStep(2);
                  } else {
                    toast.error('Veuillez corriger les champs en rouge.');
                  }
                }}
              >
                Continuer
              </button>
            </>
          ) : step === 2 ? (
            <>
              <Button
                variant="outline"
                className="rounded-full border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900"
                onClick={() => setStep(1)}
                disabled={submitting}
              >
                Retour
              </Button>
              {limitHit && (
                <Button
                  variant="outline"
                  asChild
                  className="rounded-full border-[#F59E0B]/30 bg-[#F59E0B]/10 text-xs font-semibold text-amber-600 hover:bg-[#F59E0B]/20 hover:text-amber-600"
                >
                  <Link href="/airbnb/billing">Voir les offres</Link>
                </Button>
              )}
              <button
                type="button"
                className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-60"
                onClick={() => void handleSubmit()}
                disabled={submitting}
              >
                Créer le bien
              </button>
            </>
          ) : (
            <>
              {plaque && (
                <Button
                  variant="outline"
                  className="rounded-full border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900"
                  onClick={() => router.push(`/airbnb/plates/${plaque.id}/print`)}
                >
                  Imprimer la plaque
                </Button>
              )}
              <button
                type="button"
                className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 px-4 text-xs"
                onClick={() => handleClose(false)}
              >
                Terminer
              </button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// EditPropertyDialog — modification d'un bien (PATCH)
// =============================================================

interface EditPropertyDialogProps {
  property: HostProperty | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

function EditPropertyDialog({ property, open, onOpenChange }: EditPropertyDialogProps) {
  const { refreshProperties } = useHostContext();

  // Clé = id du bien : l'état interne se réinitialise à chaque ciblage différent.
  return property ? (
    <EditPropertyDialogInner
      key={property.id}
      property={property}
      open={open}
      onOpenChange={onOpenChange}
      refreshProperties={refreshProperties}
    />
  ) : null;
}

interface EditPropertyDialogInnerProps {
  property: HostProperty;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  refreshProperties: () => Promise<void>;
}

function EditPropertyDialogInner({
  property,
  open,
  onOpenChange,
  refreshProperties,
}: EditPropertyDialogInnerProps) {
  const [name, setName] = useState(property.name);
  const [address, setAddress] = useState(property.address ?? '');
  const [propertyType, setPropertyType] = useState(property.propertyType);
  const [latitude, setLatitude] = useState(
    property.latitude != null ? String(property.latitude) : '',
  );
  const [longitude, setLongitude] = useState(
    property.longitude != null ? String(property.longitude) : '',
  );
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setErrors({});
  }, [open]);

  const handleSave = useCallback(async () => {
    const next: Record<string, string> = {};
    const trimmedName = name.trim();
    const trimmedAddress = address.trim();
    const lat = latitude.trim();
    const lng = longitude.trim();

    if (trimmedName.length < 2 || trimmedName.length > 80) {
      next.name = 'Le nom doit contenir entre 2 et 80 caractères.';
    }
    if (!trimmedAddress) {
      next.address = "L'adresse du bien est requise.";
    }
    if (lat) {
      const num = Number(lat.replace(',', '.'));
      if (!Number.isFinite(num) || num < -90 || num > 90) {
        next.latitude = 'Latitude invalide (entre -90 et 90).';
      }
    }
    if (lng) {
      const num = Number(lng.replace(',', '.'));
      if (!Number.isFinite(num) || num < -180 || num > 180) {
        next.longitude = 'Longitude invalide (entre -180 et 180).';
      }
    }
    setErrors(next);
    if (Object.keys(next).length > 0) return;

    setSaving(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${property.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: trimmedName,
          address: trimmedAddress,
          propertyType,
          latitude: lat ? Number(lat.replace(',', '.')) : null,
          longitude: lng ? Number(lng.replace(',', '.')) : null,
        }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) {
        toast.error(data.error ?? 'Erreur lors de la mise à jour du bien.');
        return;
      }
      await refreshProperties();
      toast.success('Bien mis à jour ✅');
      onOpenChange(false);
    } catch (error) {
      console.error('[EditPropertyDialog] PATCH failed:', error);
      toast.error('Erreur réseau. Réessayez dans un instant.');
    } finally {
      setSaving(false);
    }
  }, [address, latitude, longitude, name, onOpenChange, property.id, propertyType, refreshProperties]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-2xl border-slate-100 bg-[#FFFFFF] text-slate-800 shadow-2xl sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-bold text-xl font-semibold text-slate-800">
            {`Modifier « ${property.name} »`}
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-400">
            Les changements sont visibles immédiatement dans le Hub public.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edit-name" className="text-slate-400">Nom du bien *</Label>
            <Input
              id="edit-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={80}
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? 'edit-name-error' : undefined}
              className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 focus-visible:ring-[#2563EB]/50"
            />
            {errors.name && (
              <p id="edit-name-error" className="text-xs font-medium text-rose-600">
                {errors.name}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edit-address" className="text-slate-400">Adresse *</Label>
            {/* v4.43 — autocomplétion : adresse complète + lat/lng exacts. */}
            <AddressAutocomplete
              id="edit-address"
              value={address}
              onChange={(v) => setAddress(v)}
              onSelect={(pick) => {
                setAddress(pick.label);
                if (pick.lat != null && pick.lng != null) {
                  setLatitude(String(pick.lat));
                  setLongitude(String(pick.lng));
                }
              }}
              invalid={Boolean(errors.address)}
              describedBy={errors.address ? 'edit-address-error' : undefined}
            />
            <p className="text-[11px] text-slate-400">
              Tapez les premières lettres : l&apos;adresse se complète et la position GPS est
              extraite automatiquement (utilisée par le bouton « Retour à la maison » des invités).
            </p>
            {errors.address && (
              <p id="edit-address-error" className="text-xs font-medium text-rose-600">
                {errors.address}
              </p>
            )}
          </div>
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="edit-type" className="text-slate-400">Type de bien</Label>
            <Select value={propertyType} onValueChange={setPropertyType}>
              <SelectTrigger
                id="edit-type"
                className="w-full rounded-xl border-slate-200 bg-slate-50 text-slate-800"
                aria-label="Type de bien"
              >
                <SelectValue placeholder="Choisir un type" />
              </SelectTrigger>
              <SelectContent className="border-slate-100 bg-[#FFFFFF] text-slate-800">
                {Object.entries(PROPERTY_TYPE_META).map(([key, meta]) => (
                  <SelectItem key={key} value={key} className="focus:bg-slate-100 focus:text-slate-900">
                    {meta.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="edit-lat" className="text-slate-400">Latitude</Label>
              <Input
                id="edit-lat"
                value={latitude}
                onChange={(e) => setLatitude(e.target.value)}
                placeholder="48.8566"
                inputMode="decimal"
                aria-invalid={Boolean(errors.latitude)}
                className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
              />
              {errors.latitude && (
                <p className="text-xs font-medium text-rose-600">{errors.latitude}</p>
              )}
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="edit-lng" className="text-slate-400">Longitude</Label>
              <Input
                id="edit-lng"
                value={longitude}
                onChange={(e) => setLongitude(e.target.value)}
                placeholder="2.3522"
                inputMode="decimal"
                aria-invalid={Boolean(errors.longitude)}
                className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
              />
              {errors.longitude && (
                <p className="text-xs font-medium text-rose-600">{errors.longitude}</p>
              )}
            </div>
          </div>
        </div>
        <DialogFooter className="mt-1 gap-2">
          <Button
            variant="outline"
            className="rounded-full border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900"
            onClick={() => onOpenChange(false)}
            disabled={saving}
          >
            Annuler
          </Button>
          <button
            type="button"
            className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 px-4 text-xs disabled:pointer-events-none disabled:opacity-60"
            onClick={() => void handleSave()}
            disabled={saving}
          >
            Enregistrer
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// =============================================================
// NewStayDialog (v5.3, Task 3-b) — création rapide de séjour
// depuis la carte « Mes biens ». Dialog local minimal (nom invité +
// dates) branché sur POST /api/airbnb/properties/{id}/bookings —
// même endpoint que le calendrier (source MANUAL, défauts 15 h/11 h).
// Choix technique : le calendrier /airbnb/calendar n'expose pas de
// paramètre ?new=<propertyId> et son dialog n'est pas exporté →
// un dialog local autonome est le chemin le plus ROBUSTE.
// =============================================================

function NewStayDialog({
  property,
  open,
  onOpenChange,
  onCreated,
}: {
  property: HostProperty | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => Promise<void>;
}) {
  const [guestName, setGuestName] = useState('');
  // Dates (type=date) — heures fixes aux standards du calendrier.
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [busy, setBusy] = useState(false);

  // Réinitialisation à chaque ouverture.
  useEffect(() => {
    if (open) {
      setGuestName('');
      setCheckIn('');
      setCheckOut('');
    }
  }, [open, property?.id]);

  async function submit() {
    if (!property) return;
    if (guestName.trim().length < 2) {
      toast.error('Le nom de l’invité est requis (2 caractères minimum).');
      return;
    }
    if (!checkIn || !checkOut) {
      toast.error('Les dates d’arrivée et de départ sont requises.');
      return;
    }
    // Heures fixes (arrivée 15 h, départ 11 h) — fin de séjour EXACTE
    // pour le verrouillage du hub (même convention que le calendrier).
    const ci = `${checkIn}T15:00`;
    const co = `${checkOut}T11:00`;
    if (new Date(co) <= new Date(ci)) {
      toast.error('La date de départ doit être après la date d’arrivée.');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/airbnb/properties/${property.id}/bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestName: guestName.trim(),
          checkIn: ci,
          checkOut: co,
          guests: 2,
          source: 'MANUAL',
        }),
      });
      const json = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? 'Création refusée');
      toast.success('Séjour ajouté au planning', {
        description: `${property.name} — arrive le ${new Intl.DateTimeFormat('fr-FR', {
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        }).format(new Date(ci))}.`,
      });
      onOpenChange(false);
      await onCreated();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur réseau');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto rounded-2xl border-slate-100 bg-[#FFFFFF] text-slate-800 shadow-2xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-bold text-xl font-semibold text-slate-800">
            Nouveau séjour
          </DialogTitle>
          <DialogDescription className="text-sm text-slate-400">
            {property ? property.name : ''} — séjour manuel (hors plateformes). Horaires standard :
            arrivée 15 h, départ 11 h.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="stay-guest" className="text-slate-400">
              Nom de l&apos;invité *
            </Label>
            <Input
              id="stay-guest"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder="Camille Laurent"
              maxLength={80}
              className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#2563EB]/50"
            />
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="stay-checkin" className="text-slate-400">
                Arrivée *
              </Label>
              <Input
                id="stay-checkin"
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 [color-scheme:dark] focus-visible:ring-[#2563EB]/50"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="stay-checkout" className="text-slate-400">
                Départ *
              </Label>
              <Input
                id="stay-checkout"
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 [color-scheme:dark] focus-visible:ring-[#2563EB]/50"
              />
            </div>
          </div>
        </div>
        <DialogFooter className="mt-1 gap-2">
          <Button
            variant="outline"
            className="rounded-full border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100 hover:text-slate-900"
            onClick={() => onOpenChange(false)}
            disabled={busy}
          >
            Annuler
          </Button>
          <button
            type="button"
            className="btn-primary-red disabled:pointer-events-none disabled:opacity-60"
            onClick={() => void submit()}
            disabled={busy}
          >
            Créer le séjour
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
