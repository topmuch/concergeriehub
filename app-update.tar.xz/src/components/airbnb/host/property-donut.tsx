'use client';

// =============================================================
// PropertyDonut — Task 3-a : widget « Répartition par logement »
// v7.0 « AZUR » — carte blanche arrondie sur fond lavande, donut
// recharts (~260 px) : nombre de séjours par bien sur les 90 derniers
// jours, POURCENTAGES visibles + GROS chiffre total centré
// (text-3xl font-bold) + légende à droite « 45% · 9 séjours ».
// Palette bleue/violette cohérente avec le nouveau thème.
// Pleine largeur sur mobile.
// =============================================================
import {
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import type { PropertyBreakdownItem } from '@/hooks/use-overview';
import { cn } from '@/lib/utils';

// Palette azur / violette du thème (cyclée si plus de 8 logements)
const DONUT_COLORS = ['#5B8CFF', '#7C6FF0', '#93B4FF', '#F472B6', '#C7D7FF', '#A78BFA', '#2563EB', '#C084FC'];

const RADIAN = Math.PI / 180;

/** Squelette local (évite une importation circulaire avec overview-content). */
function DonutSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-slate-100', className)} />;
}

/** Étiquette « 45 % » placée à l'extérieur du donut (lisible clair + sombre). */
function donutLabel(props: {
  cx?: number;
  cy?: number;
  midAngle?: number;
  outerRadius?: number;
  percent?: number;
}) {
  const cx = props.cx ?? 0;
  const cy = props.cy ?? 0;
  const percent = props.percent ?? 0;
  if (percent <= 0) return null;
  // v5.3 — rayon étiquette réduit pour ne jamais rogné aux bords du conteneur
  const radius = (props.outerRadius ?? 0) + 12;
  const x = cx + radius * Math.cos(-(props.midAngle ?? 0) * RADIAN);
  const y = cy + radius * Math.sin(-(props.midAngle ?? 0) * RADIAN);
  return (
    <text
      x={x}
      y={y}
      fill="#64748B"
      fontSize={13}
      fontWeight={700}
      textAnchor={x >= cx ? 'start' : 'end'}
      dominantBaseline="central"
    >
      {`${Math.round(percent * 100)} %`}
    </text>
  );
}

export function PropertyDonut({
  data,
  loading = false,
}: {
  data: PropertyBreakdownItem[];
  loading?: boolean;
}) {
  const total = data.reduce((acc, d) => acc + d.count, 0);

  return (
    <div className="flex flex-col rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
      <div className="mb-2 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-xs font-bold uppercase tracking-[0.16em] text-slate-400">Répartition</h2>
          <p className="mt-1 text-[15px] font-bold text-slate-800">Séjours par logement</p>
          <p className="mt-0.5 text-xs text-slate-400">90 derniers jours</p>
        </div>
        {!loading && total > 0 && (
          <span className="inline-flex items-center rounded-full bg-blue-50 px-2.5 py-0.5 text-xs font-semibold text-blue-700 ring-1 ring-blue-200">{`${total} séjour${total > 1 ? 's' : ''}`}</span>
        )}
      </div>

      {loading ? (
        <DonutSkeleton className="h-[260px] w-full" />
      ) : total === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl bg-slate-50 p-8 text-center ring-1 ring-slate-100">
          <p className="text-lg font-bold text-slate-800">Aucun séjour</p>
          <p className="max-w-xs text-xs text-slate-400">
            La répartition par logement apparaîtra dès les premières arrivées.
          </p>
        </div>
      ) : (
        <div className="mt-2 flex flex-col items-center gap-4 lg:flex-row lg:items-center">
          {/* Donut ~260 px + total au centre */}
          <div
            className="relative h-[260px] w-full max-w-[260px] shrink-0"
            role="img"
            aria-label="Répartition des séjours par logement sur les 90 derniers jours"
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart margin={{ top: 26, right: 30, bottom: 26, left: 30 }}>
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: '1px solid #E2E8F0',
                    backgroundColor: '#ffffff',
                    color: '#0f172a',
                    boxShadow: '0 12px 32px rgba(37,99,235,0.15)',
                    fontSize: 13,
                  }}
                  itemStyle={{ color: '#0f172a' }}
                  formatter={(value: number | string, name: string) => [
                    `${value} séjour${Number(value) > 1 ? 's' : ''}`,
                    name,
                  ]}
                />
                <Pie
                  data={data}
                  dataKey="count"
                  nameKey="name"
                  innerRadius="52%"
                  outerRadius="68%"
                  paddingAngle={2}
                  stroke="none"
                  label={donutLabel}
                  labelLine={false}
                  isAnimationActive={false}
                >
                  {data.map((entry, i) => (
                    <Cell key={entry.name} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            {/* GROS chiffre total au centre du donut (demande client) */}
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center" aria-hidden="true">
              <span className="text-3xl font-bold tracking-tight text-slate-800">{total}</span>
              <span className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400">séjours</span>
            </div>
          </div>

          {/* Légende droite : couleur · logement · pourcentage */}
          <ul className="lux-scroll flex w-full flex-col gap-2 overflow-y-auto pr-1 lg:max-h-[260px]" role="list">
            {data.map((entry, i) => (
              <li
                key={entry.name}
                className="flex items-center gap-2.5 rounded-xl border border-slate-100 bg-slate-50 px-3 py-2"
              >
                <span
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ backgroundColor: DONUT_COLORS[i % DONUT_COLORS.length] }}
                  aria-hidden="true"
                />
                <span className="min-w-0 flex-1 truncate text-xs font-semibold text-slate-600" title={entry.name}>
                  {entry.name}
                </span>
                <span className="shrink-0 text-xs font-bold tabular-nums text-blue-700">{`${entry.pct} %`}</span>
                <span className="shrink-0 text-[11px] tabular-nums text-slate-400">{entry.count}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
