'use client';

// =============================================================
// PropertyDonut — Task 3-a : widget « Répartition par logement »
// Donut recharts AGRANDI (~260 px) : nombre de séjours par bien sur
// les 90 derniers jours, POURCENTAGES visibles (étiquettes autour du
// cercle) + légende à droite « 45% · 9 séjours ». Palette bleutée/or
// cohérente avec le thème. Pleine largeur sur mobile.
// =============================================================
import {
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from 'recharts';
import type { PropertyBreakdownItem } from '@/hooks/use-overview';
import { cn } from '@/lib/utils';

// Palette bleutée / or du thème (cyclée si plus de 8 logements)
const DONUT_COLORS = ['#4D8DFF', '#E9C47C', '#8FB3FF', '#D8B25C', '#A9C4FF', '#B08938', '#5EEAD4', '#F3D795'];

const RADIAN = Math.PI / 180;

/** Squelette local (évite une importation circulaire avec overview-content). */
function DonutSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-white/8', className)} />;
}

/** Étiquette « 45 % » placée à l'extérieur du donut (lisible clair + sombre). */
function donutLabel(props: {
  cx?: number;
  cy?: number;
  midAngle?: number;
  outerRadius?: number;
  percent?: number;
}) {
  const cx = props.cx ?? 0;
  const cy = props.cy ?? 0;
  const percent = props.percent ?? 0;
  if (percent <= 0) return null;
  // v5.3 — rayon étiquette réduit pour ne jamais rogné aux bords du conteneur
  const radius = (props.outerRadius ?? 0) + 12;
  const x = cx + radius * Math.cos(-(props.midAngle ?? 0) * RADIAN);
  const y = cy + radius * Math.sin(-(props.midAngle ?? 0) * RADIAN);
  return (
    <text
      x={x}
      y={y}
      fill="#5D6B8A"
      fontSize={13}
      fontWeight={700}
      textAnchor={x >= cx ? 'start' : 'end'}
      dominantBaseline="central"
    >
      {`${Math.round(percent * 100)} %`}
    </text>
  );
}

export function PropertyDonut({
  data,
  loading = false,
}: {
  data: PropertyBreakdownItem[];
  loading?: boolean;
}) {
  const total = data.reduce((acc, d) => acc + d.count, 0);

  return (
    <div className="lux-card flex flex-col p-5 sm:p-6">
      <div className="mb-2 flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="lux-eyebrow">Répartition</h2>
          <p className="lux-display mt-1 text-xl text-white">Séjours par logement</p>
          <p className="mt-0.5 text-xs text-[#8fa0c2]">90 derniers jours</p>
        </div>
        {!loading && total > 0 && (
          <span className="lux-chip">{`${total} séjour${total > 1 ? 's' : ''}`}</span>
        )}
      </div>

      {loading ? (
        <DonutSkeleton className="h-[260px] w-full" />
      ) : total === 0 ? (
        <div className="lux-empty flex flex-1 flex-col items-center justify-center gap-2 rounded-2xl p-8 text-center">
          <p className="lux-display text-lg text-white">Aucun séjour</p>
          <p className="max-w-xs text-xs text-[#8fa0c2]">
            La répartition par logement apparaîtra dès les premières arrivées.
          </p>
        </div>
      ) : (
        <div className="mt-2 flex flex-col items-center gap-4 lg:flex-row lg:items-center">
          {/* Donut ~260 px + total au centre */}
          <div
            className="relative h-[260px] w-full max-w-[260px] shrink-0"
            role="img"
            aria-label="Répartition des séjours par logement sur les 90 derniers jours"
          >
            <ResponsiveContainer width="100%" height="100%">
              <PieChart margin={{ top: 26, right: 30, bottom: 26, left: 30 }}>
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: '1px solid rgba(148,170,214,0.25)',
                    backgroundColor: '#0d1530',
                    color: '#eef3fb',
                    boxShadow: '0 12px 32px rgba(2,6,18,0.6)',
                    fontSize: 13,
                  }}
                  itemStyle={{ color: '#eef3fb' }}
                  formatter={(value: number | string, name: string) => [
                    `${value} séjour${Number(value) > 1 ? 's' : ''}`,
                    name,
                  ]}
                />
                <Pie
                  data={data}
                  dataKey="count"
                  nameKey="name"
                  innerRadius="52%"
                  outerRadius="68%"
                  paddingAngle={2}
                  stroke="none"
                  label={donutLabel}
                  labelLine={false}
                  isAnimationActive={false}
                >
                  {data.map((entry, i) => (
                    <Cell key={entry.name} fill={DONUT_COLORS[i % DONUT_COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            {/* Total au centre du donut */}
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center" aria-hidden="true">
              <span className="lux-display text-2xl font-bold text-white">{total}</span>
              <span className="luxkpi-label mt-0.5 text-[9px]">séjours</span>
            </div>
          </div>

          {/* Légende droite : couleur · logement · pourcentage */}
          <ul className="lux-scroll flex w-full flex-col gap-2 overflow-y-auto pr-1 lg:max-h-[260px]" role="list">
            {data.map((entry, i) => (
              <li
                key={entry.name}
                className="flex items-center gap-2.5 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2"
              >
                <span
                  className="lux-dot shrink-0"
                  style={{ backgroundColor: DONUT_COLORS[i % DONUT_COLORS.length] }}
                  aria-hidden="true"
                />
                <span className="lux-eyebrow min-w-0 flex-1 truncate !tracking-normal" title={entry.name}>
                  {entry.name}
                </span>
                <span className="shrink-0 text-xs font-bold tabular-nums text-[#a9c4ff]">{`${entry.pct} %`}</span>
                <span className="shrink-0 text-[11px] tabular-nums text-[#8fa0c2]">{entry.count}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
