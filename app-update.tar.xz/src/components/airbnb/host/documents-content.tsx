'use client';

// =============================================================
// DocumentsContent — page « Documents » du Dashboard Client (Task 3-b)
// Bibliothèque unifiée des PDF d'inspection :
//   • module EDL standalone + états des lieux du Hub (source affichée) ;
//   • recherche (logement / invité) + filtres segmentés
//     Tous | Entrée | Sortie | Complet (Entrée + Sortie) ;
//   • badges « Complet (Entrée + Sortie) » (tooltip PDF combiné) et
//     « Litige » (rouge, dégâts Hub) ;
//   • poids du fichier (« 2,4 Mo », « — » si PDF jamais généré —
//     le poids se remplit à la 1re génération, comportement voulu) ;
//   • actions PDF (gris) et Ouvrir (bleu) par convention v6.1.
// Données : GET /api/airbnb/documents (tri createdAt desc côté API).
// =============================================================

import { useCallback, useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import {
  AlertTriangle,
  CheckCheck,
  ExternalLink,
  FileText,
  RefreshCw,
  Search,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

// ---------- Types (contrat GET /api/airbnb/documents) ----------

interface DocumentRow {
  id: string;
  source: 'edl' | 'hub';
  title: string;
  propertyName: string;
  guestName: string;
  kind: 'ENTREE' | 'SORTIE';
  statusLabel: string;
  status: string;
  createdAt: string;
  pdfUrl: string;
  publicPageUrl: string;
  pdfSizeBytes: number | null;
  linked: boolean;
  complete: boolean;
  hasLitige: boolean;
}

type KindFilter = 'all' | 'ENTREE' | 'SORTIE' | 'complete';

const KIND_FILTERS: { value: KindFilter; label: string }[] = [
  { value: 'all', label: 'Tous' },
  { value: 'ENTREE', label: 'Entrée' },
  { value: 'SORTIE', label: 'Sortie' },
  { value: 'complete', label: 'Complet (Entrée + Sortie)' },
];

// ---------- Helpers FR (dates + poids) ----------

/** Date de création « 17 oct. 2025 · 14:32 ». */
function formatFrDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

/** Poids lisible : « 2,4 Mo » (≥ 1 Mo, 1 décimale) sinon « 380 Ko ». */
function formatFileSize(bytes: number | null): string {
  if (bytes == null || !Number.isFinite(bytes) || bytes <= 0) return '—';
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1).replace('.', ',')} Mo`;
  }
  return `${Math.max(1, Math.round(bytes / 1024))} Ko`;
}

/** Recherche insensible aux accents / casses (logement, invité). */
function normalizeText(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

// =============================================================
// Composant racine
// =============================================================

export function DocumentsContent() {
  const [docs, setDocs] = useState<DocumentRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [query, setQuery] = useState('');
  const [kind, setKind] = useState<KindFilter>('all');

  // ── Chargement de la bibliothèque unifiée ──
  const loadDocs = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch('/api/airbnb/documents', { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as
        | { documents?: DocumentRow[]; error?: string }
        | null;
      if (!res.ok) throw new Error(json?.error ?? `HTTP ${res.status}`);
      setDocs(json?.documents ?? []);
    } catch {
      setError('Impossible de charger vos documents. Vérifiez votre connexion.');
    }
  }, []);

  useEffect(() => {
    setDocs(null);
    void loadDocs();
  }, [loadDocs, reloadKey]);

  // ── Filtres client (recherche + segment) ──
  const filtered = useMemo(() => {
    const q = normalizeText(query.trim());
    return (docs ?? []).filter((d) => {
      if (kind === 'ENTREE' && d.kind !== 'ENTREE') return false;
      if (kind === 'SORTIE' && d.kind !== 'SORTIE') return false;
      if (kind === 'complete' && !d.complete) return false;
      if (!q) return true;
      return (
        normalizeText(d.propertyName).includes(q) || normalizeText(d.guestName).includes(q)
      );
    });
  }, [docs, query, kind]);

  const filtersActive = query.trim() !== '' || kind !== 'all';

  return (
    <div className="flex flex-col gap-6">
      {/* ---------- En-tête ---------- */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-400">Bibliothèque</p>
          <h1 className="font-bold mt-1 text-2xl font-semibold text-slate-800 sm:text-3xl">
            Documents
          </h1>
          <p className="mt-1.5 text-xs text-slate-400 sm:text-sm">
            Tous vos états des lieux — entrées, sorties et documents fusionnés (module États des
            Lieux + Hub).
          </p>
        </div>
        <button
          type="button"
          onClick={() => setReloadKey((k) => k + 1)}
          className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition-all hover:brightness-105 h-9 w-full sm:w-auto"
          aria-label="Rafraîchir la liste des documents"
        >
          <RefreshCw className="h-4 w-4" aria-hidden="true" /> Rafraîchir
        </button>
      </div>

      {/* ---------- Barre de recherche + filtres segmentés ---------- */}
      <div className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] flex flex-col gap-3 p-4">
        <div className="relative w-full">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
            aria-hidden="true"
          />
          <Input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher par logement ou invité…"
            aria-label="Rechercher un document par logement ou invité"
            className="h-11 rounded-xl border-slate-200 bg-slate-50 pl-10 text-sm text-slate-800 placeholder:text-slate-400/80 focus-visible:border-[#2563EB]/50 focus-visible:ring-[#2563EB]/30"
          />
        </div>
        <div className="flex flex-wrap gap-1.5" role="group" aria-label="Filtrer par type de document">
          {KIND_FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setKind(f.value)}
              aria-pressed={kind === f.value}
              className={cn(
                'min-h-[36px] rounded-full border px-3.5 text-xs font-semibold transition-colors',
                kind === f.value
                  ? 'border-[#2563EB]/60 bg-[#3d6fe0]/20 text-slate-800'
                  : 'border-slate-200 bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-slate-900',
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* ---------- Compteur de résultats ---------- */}
      <p className="text-xs text-slate-400" aria-live="polite">
        {docs === null
          ? 'Chargement des documents…'
          : error
            ? ''
            : `${filtered.length} document${filtered.length > 1 ? 's' : ''}${
                filtersActive ? ` sur ${docs.length}` : ''
              }`}
      </p>

      {/* ---------- Erreur ---------- */}
      {docs !== null && error && (
        <div
          className="flex flex-col items-start gap-3 rounded-2xl border border-[#F43F5E]/25 bg-[#F43F5E]/10 px-4 py-3 sm:flex-row sm:items-center"
          role="alert"
        >
          <span className="h-2 w-2 rounded-full shrink-0" style={{ backgroundColor: '#F43F5E' }} aria-hidden="true" />
          <p className="min-w-0 flex-1 text-sm text-rose-600">{error}</p>
          <button
            type="button"
            onClick={() => setReloadKey((k) => k + 1)}
            className="btn-tertiary-gray"
            aria-label="Réessayer le chargement des documents"
          >
            Réessayer
          </button>
        </div>
      )}

      {/* ---------- Liste / squelettes / état vide ---------- */}
      {docs === null ? (
        <div
          className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] divide-y divide-slate-100 overflow-hidden"
          aria-label="Chargement des documents"
        >
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1 space-y-2">
                <Skeleton className="h-5 w-2/3 bg-slate-100" aria-hidden="true" />
                <Skeleton className="h-4 w-1/2 bg-slate-100" aria-hidden="true" />
              </div>
              <Skeleton className="h-9 w-full bg-slate-100 sm:w-40" aria-hidden="true" />
            </div>
          ))}
        </div>
      ) : !error && filtered.length === 0 ? (
        <EmptyDocuments filtersActive={filtersActive} />
      ) : (
        <motion.section
          aria-label="Vos documents d'état des lieux"
          className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] divide-y divide-slate-100 overflow-hidden"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
        >
          <ul className="lux-scroll max-h-[70vh] divide-y divide-slate-100 overflow-y-auto">
            {filtered.map((d) => (
              <DocumentItem key={`${d.source}-${d.id}`} doc={d} />
            ))}
          </ul>
        </motion.section>
      )}
    </div>
  );
}

// =============================================================
// DocumentItem — une ligne de document
// =============================================================

function DocumentItem({ doc }: { doc: DocumentRow }) {
  const isEntree = doc.kind === 'ENTREE';
  return (
    <li className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
      {/* Informations principales */}
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Type : Entrée (vert, convention check-in) / Sortie (rouge) */}
          <span
            className={cn(
              'inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-bold uppercase tracking-[0.1em]',
              isEntree
                ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-300'
                : 'border-[#F43F5E]/30 bg-[#F43F5E]/10 text-rose-600',
            )}
          >
            {isEntree ? 'Entrée' : 'Sortie'}
          </span>
          {/* Badge « Complet (Entrée + Sortie) » + tooltip PDF combiné */}
          {doc.complete && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Badge
                  variant="outline"
                  className="border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                >
                  <CheckCheck className="h-3 w-3" aria-hidden="true" />
                  Complet (Entrée + Sortie)
                </Badge>
              </TooltipTrigger>
              <TooltipContent className="border-slate-100 bg-[#FFFFFF] text-slate-800">
                PDF combiné (entrée + sortie)
              </TooltipContent>
            </Tooltip>
          )}
          {/* Badge « Litige » rouge (dégâts renseignés côté Hub) */}
          {doc.hasLitige && (
            <Badge variant="destructive">
              <AlertTriangle className="h-3 w-3" aria-hidden="true" />
              Litige
            </Badge>
          )}
        </div>
        <p className="font-bold mt-1.5 truncate text-sm font-semibold text-slate-800" title={doc.title}>
          {doc.title}
        </p>
        <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-400">
          <span className="font-semibold text-blue-700">{formatFrDateTime(doc.createdAt)}</span>
          <span aria-hidden="true">·</span>
          <span>Statut : {doc.statusLabel}</span>
          <span aria-hidden="true">·</span>
          <span>Poids : {formatFileSize(doc.pdfSizeBytes)}</span>
          <span aria-hidden="true">·</span>
          <span className="uppercase tracking-[0.08em]">
            {doc.source === 'edl' ? 'Module États des Lieux' : 'Hub'}
          </span>
        </p>
      </div>

      {/* Actions : PDF (gris) + Ouvrir (bleu) — convention v6.1 */}
      <div className="flex shrink-0 gap-2">
        <a
          href={doc.pdfUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-tertiary-gray"
          aria-label={`Ouvrir le PDF de ${doc.title}`}
        >
          <FileText className="h-4 w-4" aria-hidden="true" /> PDF
        </a>
        <a
          href={doc.publicPageUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-secondary-blue"
          aria-label={`Ouvrir la page publique de ${doc.title}`}
        >
          <ExternalLink className="h-4 w-4" aria-hidden="true" /> Ouvrir
        </a>
      </div>
    </li>
  );
}

// =============================================================
// EmptyDocuments — état vide élégant (globale ou après filtres)
// =============================================================

function EmptyDocuments({ filtersActive }: { filtersActive: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="bg-slate-50 ring-1 ring-slate-100 flex flex-col items-center gap-2 px-6 py-12 text-center"
      role="status"
    >
      <span aria-hidden="true" className="h-2 w-2 rounded-full" style={{ backgroundColor: '#2563EB' }} />
      <span className="mt-2 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-50 ring-1 ring-slate-200">
        {filtersActive ? (
          <Search className="h-6 w-6 text-slate-400" aria-hidden="true" />
        ) : (
          <FileText className="h-6 w-6 text-slate-400" aria-hidden="true" />
        )}
      </span>
      <h2 className="font-bold mt-1 text-lg font-semibold text-slate-800">
        {filtersActive ? 'Aucun document trouvé' : 'Aucun document pour le moment'}
      </h2>
      <p className="mx-auto mt-1 max-w-md text-xs text-slate-400">
        {filtersActive
          ? 'Ajustez la recherche ou les filtres — les documents Entrée, Sortie et Complet apparaissent ici dès leur création.'
          : 'Les PDF d’inspection (entrées, sorties, documents fusionnés) s’afficheront ici automatiquement dès leur première génération.'}
      </p>
    </motion.div>
  );
}
