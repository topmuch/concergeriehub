'use client';

// =============================================================
// NotificationsBell — ÉTAPE 13 V2 + Task 3-a « badge alertes dégâts »
// Déclencheur TYPOGRAPHIQUE « Alertes » du header (v5.2 SAPHIR LUXE,
// sans icône) : BADGE ROUGE avec compte dès qu'il y a des non-lues —
// encore plus proéminent (pulsation) si alerte CRITIQUE non lue
// (type 'damage_alert' / severity 'critical' = dégâts signalés).
// Panneau déroulant (Popover), alertes critiques remontées en tête,
// marquage lu individuel/global. Polling 45 s + refresh à l'ouverture.
// =============================================================
import { useCallback, useEffect, useMemo, useState, useSyncExternalStore } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { relativeFrTime } from '@/lib/automations';
import { Bell } from 'lucide-react';

interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string | null;
  data: Record<string, unknown>;
  isRead: boolean;
  createdAt: string;
}

/** Task 3-a — alerte CRITIQUE : dégâts signalés (type dédié ou severity). */
function isCritical(n: NotificationItem): boolean {
  return n.type === 'damage_alert' || n.data?.severity === 'critical';
}

const RED_CRIT = '#E11D2E';

export function NotificationsBell() {
  const router = useRouter();
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);
  // v5.0 — « Tout marquer comme lu » : spinner pendant l'appel PUT.
  const [markingAll, setMarkingAll] = useState(false);

  // Task 3-a — alertes critiques non lues (badge proéminent) + tri :
  // critiques non lues en tête de liste, puis ordre chronologique.
  const hasCritical = useMemo(() => items.some((n) => !n.isRead && isCritical(n)), [items]);
  const sortedItems = useMemo(
    () =>
      [...items].sort((a, b) => {
        const ca = !a.isRead && isCritical(a) ? 0 : 1;
        const cb = !b.isRead && isCritical(b) ? 0 : 1;
        if (ca !== cb) return ca - cb;
        return b.createdAt.localeCompare(a.createdAt);
      }),
    [items],
  );

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/airbnb/notifications?limit=25', {
        cache: 'no-store',
      });
      if (!res.ok) return; // 401 visiteur, erreurs passagères : on retente
      const data = (await res.json()) as {
        notifications: NotificationItem[];
        unreadCount: number;
      };
      setItems(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch {
      // réseau indisponible : on retentera au prochain cycle
    }
  }, []);

  // Chargement initial (macrotâche) + polling léger (45 s)
  useEffect(() => {
    const initial = setTimeout(() => {
      load();
    }, 0);
    const poll = setInterval(() => {
      load();
    }, 45_000);
    return () => {
      clearTimeout(initial);
      clearInterval(poll);
    };
  }, [load]);

  const markRead = async (id: string) => {
    // Optimiste
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
    try {
      const res = await fetch(`/api/airbnb/notifications?notificationId=${encodeURIComponent(id)}`, {
        method: 'PATCH',
      });
      if (res.ok) {
        const data = (await res.json()) as { unreadCount: number };
        setUnreadCount(data.unreadCount);
      }
    } catch {
      // silencieux — l'état optimiste reste
    }
  };

  // v5.0 — marque TOUTES les notifications lues : mise à jour
  // optimiste immédiate (badge → 0, plus de non-lues), puis PUT
  // /api/airbnb/notifications (updateMany côté API). En cas
  // d'échec on resynchronise avec le serveur + toast d'erreur.
  const markAllRead = async () => {
    if (markingAll || unreadCount === 0) return;
    setMarkingAll(true);
    setItems((prev) => prev.map((n) => ({ ...n, isRead: true })));
    setUnreadCount(0);
    try {
      const res = await fetch('/api/airbnb/notifications', { method: 'PUT' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      toast.success('Toutes les notifications sont marquées comme lues');
    } catch {
      toast.error('Impossible de tout marquer comme lu');
      await load(); // resynchronise l'état réel (badge + liste)
    } finally {
      setMarkingAll(false);
    }
  };

  // ÉTAPE 17.3 : une notification peut porter un deep-link (ex. une
  // commande atterrit sur /airbnb/dashboard/orders). Au clic on
  // marque comme lu puis on navigue.
  const openNotification = (id: string) => {
    void markRead(id);
    const target = items.find((n) => n.id === id);
    const url = typeof target?.data?.url === 'string' ? target.data.url : '';
    if (url && url.startsWith('/')) {
      setOpen(false);
      router.push(url);
    }
  };

  // Visiteur non connecté : la cloche reste visible mais vide
  // (elle n'est rendue que pour les utilisateurs connectés via le shell).

  // Monté uniquement après hydratation : évite le mismatch des IDs
  // Radix auto-générés (aria-controls) entre SSR et client.
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  if (!mounted) {
    return (
      <span
        aria-hidden="true"
        className="inline-block h-9 w-9 rounded-xl border border-slate-200 bg-slate-100 sm:w-[78px]"
      />
    );
  }

  return (
    <Popover
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (next) void load();
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={
            unreadCount > 0
              ? `Alertes (${unreadCount} non lue${unreadCount > 1 ? 's' : ''}${hasCritical ? ', dont des alertes critiques' : ''})`
              : 'Alertes'
          }
          className="relative inline-flex h-9 items-center gap-2 rounded-xl px-2.5 text-xs font-semibold text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900"
        >
          <Bell className="h-4 w-4 shrink-0" aria-hidden="true" />
          {/* Responsive : libellé masqué en mobile (icône + badge suffisent). */}
          <span className="hidden sm:inline">Alertes</span>
          {unreadCount > 0 && (
            /* Task 3-a — BADGE ROUGE avec compte ; pulsation si alerte
               critique non lue (dégâts signalés) pour la rendre
               immédiatement repérable. */
            <span
              aria-hidden="true"
              className={cn(
                'inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full px-1 text-[10px] font-bold leading-none text-white',
                hasCritical && 'animate-pulse',
              )}
              style={{
                backgroundColor: RED_CRIT,
                ...(hasCritical ? { boxShadow: `0 0 0 3px ${RED_CRIT}33` } : {}),
              }}
            >
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
      </PopoverTrigger>

      <PopoverContent align="end" className="w-[min(24rem,calc(100vw-2rem))] border border-slate-100 bg-white p-0 text-slate-800 shadow-[0_16px_48px_-12px_rgba(37,99,235,0.25)]">
        <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-4 py-3">
          <p className="text-sm font-bold text-slate-800">
            Alertes
            {/* Task 3-a — rappel visuel des alertes critiques dans le panneau */}
            {hasCritical && (
              <span
                className="ml-2 inline-flex items-center rounded-full px-2 py-0.5 align-middle text-[10px] font-bold uppercase tracking-wide text-white"
                style={{ backgroundColor: RED_CRIT }}
              >
                Critique
              </span>
            )}
          </p>
          {unreadCount > 0 && (
            <button
              type="button"
              onClick={() => void markAllRead()}
              disabled={markingAll}
              aria-label="Tout marquer comme lu"
              className="inline-flex items-center rounded-full px-3 py-2 text-xs font-semibold text-blue-600 transition-colors hover:bg-blue-50 hover:text-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500/40 disabled:cursor-wait disabled:opacity-60"
            >
              {markingAll && (
                <span
                  className="mr-1.5 h-2 w-2 animate-pulse rounded-full"
                  style={{ backgroundColor: '#2563EB' }}
                  aria-hidden="true"
                />
              )}
              Tout marquer comme lu
            </button>
          )}
        </div>

        <div className="lux-scroll max-h-96 overflow-y-auto">
          {items.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <p className="text-sm font-bold text-slate-800">Aucune notification</p>
              <p className="mt-1 text-xs text-slate-400">
                Réservations, ménages et réclamations arriveront ici.
              </p>
            </div>
          ) : (
            <ul role="list">
              {sortedItems.map((n) => {
                const crit = isCritical(n);
                return (
                  <li key={n.id}>
                    <button
                      type="button"
                      onClick={() => openNotification(n.id)}
                      aria-label={
                        typeof n.data?.url === 'string'
                          ? `${n.title} — ouvrir`
                          : n.title
                      }
                      className={cn(
                        'flex w-full gap-3 border-b border-slate-100 px-4 py-3 text-left transition-colors last:border-b-0 hover:bg-slate-50 focus-visible:bg-slate-50 focus-visible:outline-none',
                        !n.isRead && (crit ? 'bg-[#E11D2E]/[0.08]' : 'bg-amber-50/60'),
                      )}
                    >
                      <span
                        aria-label={n.isRead ? undefined : crit ? 'Alerte critique non lue' : 'Non lue'}
                        aria-hidden={n.isRead || undefined}
                        className={cn('mt-2 h-2 w-2 shrink-0 rounded-full', !n.isRead && crit && 'animate-pulse')}
                        style={{
                          backgroundColor: n.isRead
                            ? '#cbd5e1'
                            : crit
                              ? RED_CRIT
                              : '#f59e0b',
                        }}
                      />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-sm font-semibold text-slate-800">
                            {n.title}
                          </span>
                          {crit && !n.isRead && (
                            <span
                              className="shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white"
                              style={{ backgroundColor: RED_CRIT }}
                            >
                              Dégâts
                            </span>
                          )}
                        </span>
                        {n.body && (
                          <span className="mt-0.5 block text-xs text-slate-400 line-clamp-2">
                            {n.body}
                          </span>
                        )}
                        <span className="mt-1 block text-[11px] text-slate-400/80">
                          {relativeFrTime(n.createdAt)}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="border-t border-slate-100 px-4 py-2.5">
          <Link
            href="/airbnb/dashboard/automations"
            onClick={() => setOpen(false)}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 transition-colors hover:text-slate-800"
          >
            Gérer les automatisations
            <span aria-hidden="true">→</span>
          </Link>
        </div>
      </PopoverContent>
    </Popover>
  );
}
