'use client';

import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  AudioLines,
  Bell,
  BookOpen,
  ChevronRight,
  CreditCard,
  Globe,
  LayoutDashboard,
  LogOut,
  Mail,
  Percent,
  QrCode,
  ScrollText,
  Settings,
  ShoppingCart,
  Users,
  Wrench,
  Home,
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import { ThemeToggle } from '@/components/shared/theme-toggle';
// =============================================================
// AdminAppSidebar — v4.59 « AIRBNB PRO » — refonte complète.
// Sidebar gradient marine profond (clair & dark), navigation
// réorganisée en 3 groupes clairs, icônes Lucide dans des tuiles,
// actif = pastille blanche + texte bleu logo, profil + bascule thème.
// =============================================================

interface NavItem {
  href: string;
  label: string;
  description: string;
  icon: React.ElementType;
  exact?: boolean;
}

const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: 'Pilotage',
    items: [
      {
        href: '/admin/dashboard',
        label: 'Tableau de bord',
        description: 'KPIs temps réel, revenus et activité',
        icon: LayoutDashboard,
        exact: true,
      },
      {
        href: '/admin/users',
        label: 'Clients & Hôtes',
        description: 'Comptes, plans et actions',
        icon: Users,
      },
      {
        href: '/admin/hosts',
        label: 'Biens & Plaques',
        description: 'Hôtes, propriétés et plaques QR',
        icon: Home,
      },
      {
        href: '/admin/subscriptions',
        label: 'Abonnements',
        description: 'MRR, plans, factures, coupons',
        icon: CreditCard,
      },
      {
        href: '/admin/invoices',
        label: 'Commissions',
        description: 'Factures mensuelles des hôtes',
        icon: Percent,
      },
      {
        href: '/admin/notification-settings',
        label: 'Notifications',
        description: 'Smart Prompts, contrôle global, impact',
        icon: Bell,
      },
    ],
  },
  {
    label: 'Opérations',
    items: [
      {
        href: '/admin/qr',
        label: 'Générateur QR',
        description: 'Lots, plaques physiques, setup tokens',
        icon: QrCode,
      },
      {
        href: '/admin/providers',
        label: 'Prestataires',
        description: 'Annuaire, carte, vérifications',
        icon: Wrench,
      },
      {
        href: '/admin/transactions',
        label: 'Transactions',
        description: 'Commandes, marketplace, reversements',
        icon: ShoppingCart,
      },
    ],
  },
  {
    label: 'Plateforme',
    items: [
      {
        href: '/admin/emails',
        label: 'Emails',
        description: 'Outbox transactionnelle et configuration',
        icon: Mail,
      },
      {
        href: '/admin/content',
        label: 'Contenu universel',
        description: 'Guidebook & appareils partagés',
        icon: BookOpen,
      },
      {
        href: '/admin/voices',
        label: 'Voix plateforme',
        description: 'Voix par défaut des messages du Hub',
        icon: AudioLines,
      },
      {
        href: '/admin/logs',
        label: 'Logs & Tickets',
        description: 'Audit, scans, support',
        icon: ScrollText,
      },
      {
        href: '/admin/settings',
        label: 'Paramètres',
        description: 'Plateforme, white-label, sécurité',
        icon: Settings,
      },
    ],
  },
];

interface AdminAppSidebarProps {
  adminName: string;
  adminEmail: string;
}

export function AdminAppSidebar({ adminName, adminEmail }: AdminAppSidebarProps) {
  const pathname = usePathname();

  const initials =
    adminName
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || 'SA';

  return (
    <Sidebar
      collapsible="icon"
      className="air-sidebar border-none"
      style={{ ['--sidebar' as string]: 'transparent' }}
    >
      {/* ----- En-tête : marque + badge contrôle ----- */}
      <SidebarHeader className="relative z-10 pb-2 pt-5">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild tooltip="Retour au site">
              <Link href="/" aria-label="Retour au site RoomScan">
                {/* Logo officiel RoomScan — variante blanche (fonds sombres), proportions d'origine */}
                <Image
                  src="/brand/roomscan-icon-white.png"
                  alt=""
                  width={124}
                  height={121}
                  className="shrink-0"
                  style={{ height: 40, width: 'auto' }}
                />
                <span className="flex min-w-0 flex-col items-start gap-0.5 leading-tight">
                  <span className="truncate text-base font-extrabold text-white">
                    RoomScan
                  </span>
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-white/65">
                    Console Superadmin
                  </span>
                </span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>

      {/* ----- Navigation 3 groupes ----- */}
      <SidebarContent className="relative z-10 px-2 pt-2">
        {NAV_GROUPS.map((group) => (
          <SidebarGroup key={group.label}>
            <SidebarGroupLabel className="text-[11px] font-bold uppercase tracking-widest text-white/45">
              {group.label}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {group.items.map((item) => {
                  const active = item.exact
                    ? pathname === item.href || pathname === '/admin'
                    : pathname.startsWith(item.href);
                  const Icon = item.icon;
                  return (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton
                        asChild
                        isActive={active}
                        tooltip={`${item.label} — ${item.description}`}
                      >
                        <Link
                          href={item.href}
                          aria-current={active ? 'page' : undefined}
                          className="group h-11 rounded-xl text-[14px] font-medium text-white/85 transition-all hover:bg-white/12 hover:text-white data-[active=true]:bg-white data-[active=true]:font-bold data-[active=true]:text-[#0047B3] data-[active=true]:shadow-lg data-[active=true]:hover:bg-white data-[active=true]:hover:text-[#0047B3]"
                        >
                          <span
                            aria-hidden="true"
                            className={cnTile(active)}
                          >
                            <Icon className="h-[18px] w-[18px]" />
                          </span>
                          <span className="truncate">{item.label}</span>
                          <ChevronRight
                            className="ml-auto h-4 w-4 opacity-0 transition-opacity group-hover:opacity-60 data-[active=true]:opacity-50 group-data-[collapsible=icon]:hidden"
                            aria-hidden="true"
                          />
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}

        {/* Lien externe : site public */}
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton tooltip="Ouvrir le site public RoomScan" asChild>
                  <Link
                    href="/"
                    target="_blank"
                    rel="noreferrer"
                    className="group h-11 rounded-xl text-[14px] font-medium text-white/85 hover:bg-white/12 hover:text-white"
                  >
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/10 transition-colors group-hover:bg-white/20">
                      <Globe className="h-[16px] w-[16px]" />
                    </span>
                    <span>Site public</span>
                    <ChevronRight
                      className="ml-auto h-4 w-4 opacity-0 transition-opacity group-hover:opacity-60 group-data-[collapsible=icon]:hidden"
                      aria-hidden="true"
                    />
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {/* ----- Pied : bascule thème + compte admin ----- */}
      <SidebarFooter className="relative z-10 pb-5">
        <div className="mb-2 flex items-center justify-end px-2 group-data-[collapsible=icon]:justify-center">
          <ThemeToggle variant="light" />
        </div>
        <SidebarMenu>
          <SidebarMenuItem>
            <div className="flex items-center gap-2.5 rounded-2xl bg-white/10 px-3 py-2.5 backdrop-blur-sm group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-2">
              <span
                aria-hidden="true"
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white text-xs font-extrabold text-[#0047B3] shadow"
              >
                {initials}
              </span>
              <div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden">
                <p className="truncate text-sm font-bold text-white">{adminName}</p>
                <p className="truncate text-[11px] text-white/60">{adminEmail}</p>
              </div>
              <button
                type="button"
                onClick={() => signOut({ callbackUrl: '/' })}
                title="Se déconnecter"
                aria-label="Se déconnecter"
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/70 transition-colors hover:bg-white/15 hover:text-white group-data-[collapsible=icon]:hidden"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

/** Tuile d'icône : translucide au repos, colorée quand actif. */
function cnTile(active: boolean): string {
  return [
    'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition-colors',
    active
      ? 'bg-[#0066EF] text-white shadow-sm'
      : 'bg-white/10 text-white/80 group-hover:bg-white/20 group-hover:text-white',
  ].join(' ');
}
