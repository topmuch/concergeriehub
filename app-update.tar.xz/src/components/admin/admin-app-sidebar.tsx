'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  Activity,
  ArrowLeftRight,
  Bell,
  Building2,
  CreditCard,
  ExternalLink,
  Gauge,
  Globe,
  LifeBuoy,
  Mail,
  Mic,
  QrCode,
  Receipt,
  ScrollText,
  Settings,
  Users,
  Wrench,
  type LucideIcon,
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import { ThemeToggle } from '@/components/shared/theme-toggle';

// =============================================================
// AdminAppSidebar — v8.0 « ENCRE NOIRE + NAV COMPACTE » (refonte
// design client) : rail bleu vif dégradé (#4A8BFF → #2563EB) à
// icônes blanches dans boutons arrondis, item actif = pastille
// bg-white/20 + ring blanc, logo = carré blanc arrondi à icône
// bleue, tooltips au survol, drawer sur mobile. SYSTÈME DE SCROLL
// DES ONGLETS SUPPRIMÉ : nav compactée (boutons h-8, groupes
// resserrés, en-tête/pied réduits) pour tenir sans défilement sur
// desktop, scrollbar invisibilisée en repli. Mêmes items de
// navigation et liens qu'avant (rien retiré).
// =============================================================

interface NavItem {
  href: string;
  label: string;
  description: string;
  icon: LucideIcon;
  exact?: boolean;
}

const NAV_GROUPS: { label: string; items: NavItem[] }[] = [
  {
    label: 'Pilotage',
    items: [
      {
        href: '/admin/dashboard',
        label: 'Tableau de bord',
        description: 'KPIs temps réel, revenus et activité',
        icon: Gauge,
        exact: true,
      },
      {
        href: '/admin/monitoring',
        label: 'Tour de Contrôle',
        description: 'Santé système, incidents et crons',
        icon: Activity,
      },
      {
        href: '/admin/users',
        label: 'Clients & Hôtes',
        description: 'Comptes, plans et actions',
        icon: Users,
      },
      {
        href: '/admin/hosts',
        label: 'Biens & Plaques',
        description: 'Hôtes, propriétés et plaques QR',
        icon: Building2,
      },
      {
        href: '/admin/subscriptions',
        label: 'Abonnements',
        description: 'MRR, plans, factures, coupons',
        icon: CreditCard,
      },
      {
        href: '/admin/invoices',
        label: 'Commissions',
        description: 'Factures mensuelles des hôtes',
        icon: Receipt,
      },
      {
        href: '/admin/notification-settings',
        label: 'Notifications',
        description: 'Smart Prompts, contrôle global, impact',
        icon: Bell,
      },
    ],
  },
  {
    label: 'Opérations',
    items: [
      {
        href: '/admin/qr',
        label: 'Générateur QR',
        description: 'Lots, plaques physiques, setup tokens',
        icon: QrCode,
      },
      {
        href: '/admin/providers',
        label: 'Prestataires',
        description: 'Annuaire, carte, vérifications',
        icon: Wrench,
      },
      {
        href: '/admin/transactions',
        label: 'Transactions',
        description: 'Commandes, marketplace, reversements',
        icon: ArrowLeftRight,
      },
    ],
  },
  {
    label: 'Plateforme',
    items: [
      {
        href: '/admin/emails',
        label: 'Emails',
        description: 'Outbox transactionnelle et configuration',
        icon: Mail,
      },
      {
        href: '/admin/assistance',
        label: 'Assistance',
        description: 'Tickets des hôtes — réponses et suivi',
        icon: LifeBuoy,
      },
      {
        href: '/admin/content',
        label: 'Contenu universel',
        description: 'Guidebook & appareils partagés',
        icon: Globe,
      },
      {
        href: '/admin/voices',
        label: 'Voix plateforme',
        description: 'Voix par défaut des messages du Hub',
        icon: Mic,
      },
      {
        href: '/admin/logs',
        label: 'Logs & Tickets',
        description: 'Audit, scans, support',
        icon: ScrollText,
      },
      {
        href: '/admin/settings',
        label: 'Paramètres',
        description: 'Plateforme, white-label, sécurité',
        icon: Settings,
      },
    ],
  },
];

interface AdminAppSidebarProps {
  adminName: string;
  adminEmail: string;
}

export function AdminAppSidebar({ adminName, adminEmail }: AdminAppSidebarProps) {
  const pathname = usePathname();

  const initials =
    adminName
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase() ?? '')
      .join('') || 'SA';

  return (
    <Sidebar
      collapsible="icon"
      className="border-none"
      style={{ ['--sidebar' as string]: 'transparent' }}
    >
      {/* Dégradé bleu peint sur toute la hauteur (desktop + drawer mobile) */}
      <div className="flex h-full w-full flex-col bg-gradient-to-b from-[#4A8BFF] to-[#2563EB]">
        {/* ----- En-tête : logo carré blanc arrondi + marque ----- */}
        <SidebarHeader className="relative z-10 pb-1 pt-2">
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton
                size="lg"
                asChild
                tooltip="Retour au site"
                className="h-10 group-data-[collapsible=icon]:p-0!"
              >
                <Link href="/" aria-label="Retour au site RoomScan">
                  <span
                    aria-hidden="true"
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white shadow-md shadow-blue-900/20"
                  >
                    {/* Icône officielle bleue (PNG brand) sur carré blanc */}
                    <img
                      src="/brand/roomscan-icon.png"
                      alt=""
                      width={20}
                      height={20}
                      className="h-5 w-5 object-contain"
                    />
                  </span>
                  <span className="flex min-w-0 flex-col items-start gap-0 leading-tight">
                    <span className="truncate text-sm font-bold text-white">RoomScan</span>
                    <span className="text-[9px] font-bold uppercase tracking-[0.24em] text-blue-100">
                      Console Superadmin
                    </span>
                  </span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarHeader>

        {/* ----- Navigation 3 groupes (icônes blanches arrondies) —
             compacte : tient sans scroll, scrollbar invisibilisée ----- */}
        <SidebarContent className="relative z-10 px-2 pt-1 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {NAV_GROUPS.map((group) => (
            <SidebarGroup key={group.label} className="p-0.5">
              <SidebarGroupLabel className="h-auto px-2.5 py-0 text-[9px] font-bold uppercase tracking-[0.28em] text-blue-100/80">
                {group.label}
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="gap-0.5">
                  {group.items.map((item) => {
                    const active = item.exact
                      ? pathname === item.href || pathname === '/admin'
                      : pathname.startsWith(item.href);
                    const Icon = item.icon;
                    return (
                      <SidebarMenuItem key={item.href}>
                        <SidebarMenuButton
                          asChild
                          isActive={active}
                          tooltip={`${item.label} — ${item.description}`}
                          className={cnSidebarItem(active)}
                        >
                          <Link
                            href={item.href}
                            aria-current={active ? 'page' : undefined}
                            aria-label={`${item.label} — ${item.description}`}
                          >
                            <Icon aria-hidden="true" className="!h-4 !w-4" />
                            <span className="truncate">{item.label}</span>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}

          {/* Lien externe : site public */}
          <SidebarGroup className="p-0.5">
            <SidebarGroupContent>
              <SidebarMenu className="gap-0.5">
                <SidebarMenuItem>
                  <SidebarMenuButton
                    tooltip="Ouvrir le site public RoomScan"
                    asChild
                    className="h-7 rounded-xl text-white hover:bg-white/15 hover:text-white data-[active=true]:bg-white/20 data-[active=true]:text-white group-data-[collapsible=icon]:size-9! group-data-[collapsible=icon]:p-1.5!"
                  >
                    <Link
                      href="/"
                      target="_blank"
                      rel="noreferrer"
                      aria-label="Ouvrir le site public RoomScan"
                    >
                      <ExternalLink aria-hidden="true" className="!h-4 !w-4" />
                      <span>Site public</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        {/* ----- Pied : bascule thème + compte admin ----- */}
        <SidebarFooter className="relative z-10 pb-2">
          <div className="mb-0.5 flex items-center justify-end px-2 group-data-[collapsible=icon]:justify-center">
            <ThemeToggle variant="light" />
          </div>
          <SidebarMenu>
            <SidebarMenuItem>
              <div className="flex items-center gap-2.5 rounded-2xl border border-white/15 bg-white/10 px-3 py-1.5 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-2">
                <span
                  aria-hidden="true"
                  className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white text-[11px] font-bold text-blue-700 shadow-sm"
                >
                  {initials}
                </span>
                <div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden">
                  <p className="truncate text-sm font-semibold text-white">{adminName}</p>
                  <p className="truncate text-[11px] text-blue-100/85">{adminEmail}</p>
                </div>
                <button
                  type="button"
                  onClick={() => signOut({ callbackUrl: '/' })}
                  title="Se déconnecter"
                  aria-label="Se déconnecter"
                  className="shrink-0 rounded-lg px-2 py-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-blue-100 transition-colors hover:bg-white/15 hover:text-white group-data-[collapsible=icon]:hidden"
                >
                  Quitter
                </button>
              </div>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </div>
    </Sidebar>
  );
}

/** Skin du bouton de navigation : pastille blanche translucide si actif.
    Compact v8.0 : h-7 (28px) — toute la nav tient sans défilement
    dès 768px de haut. */
function cnSidebarItem(active: boolean): string {
  return [
    'h-7 rounded-xl text-white hover:bg-white/15 hover:text-white',
    'group-data-[collapsible=icon]:size-9! group-data-[collapsible=icon]:p-1.5!',
    'group-data-[collapsible=icon]:justify-center',
    active
      ? 'bg-white/20! text-white! ring-1 ring-white/40 hover:bg-white/25!'
      : 'data-[active=true]:bg-white/15 data-[active=true]:text-white',
  ].join(' ');
}
