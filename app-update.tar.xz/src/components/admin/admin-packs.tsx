'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PACKS, type PackDefinition } from '@/lib/packs-config';
import { QR_MODULE_LABELS } from '@/types/database';

// ── Helpers ────────────────────────────────────────────────────
/** Count unique module types across all packs */
function countUniqueModules(packs: PackDefinition[]): number {
  const moduleTypes = new Set<string>();
  for (const pack of packs) {
    for (const qr of pack.qrCodes) {
      moduleTypes.add(qr.moduleType);
    }
  }
  return moduleTypes.size;
}

/** Get the French label for a module type, fallback to the key */
function moduleLabel(type: string): string {
  return (QR_MODULE_LABELS as Record<string, string>)[type] || type;
}

// ── Component ──────────────────────────────────────────────────
export function AdminPacks() {
  const totalPacks = PACKS.length;
  const totalModules = PACKS.reduce((sum, p) => sum + p.qrCodes.length, 0);
  const uniqueModules = countUniqueModules(PACKS);

  return (
    <Card className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]">
      <CardHeader>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Catalogue</p>
            <CardTitle className="font-bold text-slate-800 mt-1 text-xl text-slate-800">Packs pré-configurés</CardTitle>
            <CardDescription className="text-sm text-slate-400">
              Visualisation et gestion des packs d'inscription
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* ── Info Banner ──────────────────────────────────────── */}
        <div className="flex gap-3 rounded-xl border border-[#5c8af0]/25 bg-[#5c8af0]/[0.08] p-4">
          <span className="h-2 w-2 shrink-0 rounded-full mt-1.5 shrink-0" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
          <div>
            <p className="text-sm font-medium text-blue-700">
              Configuration en code
            </p>
            <p className="mt-1 text-sm text-slate-400">
              Les packs sont présentés lors de l'inscription. Le client choisit son profil
              et les modules sont installés automatiquement. Les packs sont configurés dans{' '}
              <code className="rounded bg-slate-100 px-1.5 py-0.5 text-xs font-mono text-blue-700">
                packs-config.ts
              </code>
              .
            </p>
          </div>
        </div>

        {/* ── Stats Bar ────────────────────────────────────────── */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] relative p-4">
            <span className="h-2 w-2 shrink-0 rounded-full absolute right-4 top-4 opacity-70" style={{ backgroundColor: '#34d399' }} aria-hidden="true" />
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Packs configurés</p>
            <p className="tabular-nums mt-2 text-3xl leading-none text-slate-800">{totalPacks}</p>
          </div>
          <div className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] relative p-4">
            <span className="h-2 w-2 shrink-0 rounded-full absolute right-4 top-4 opacity-70" style={{ backgroundColor: '#5c8af0' }} aria-hidden="true" />
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Total QR codes</p>
            <p className="tabular-nums mt-2 text-3xl leading-none text-slate-800">{totalModules}</p>
          </div>
          <div className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] relative p-4">
            <span className="h-2 w-2 shrink-0 rounded-full absolute right-4 top-4 opacity-70" style={{ backgroundColor: '#e9c47c' }} aria-hidden="true" />
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Modules couverts</p>
            <p className="tabular-nums mt-2 text-3xl leading-none text-slate-800">{uniqueModules}</p>
          </div>
        </div>

        {/* ── Pack Cards Grid ──────────────────────────────────── */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 xl:grid-cols-3">
          {PACKS.map((pack) => {
            return (
              <Card
                key={pack.id}
                className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] transition hover:-translate-y-0.5 hover:shadow-[0_14px_40px_-12px_rgba(37,99,235,0.28)] overflow-hidden"
              >
                {/* Header */}
                <div className="flex items-center justify-between border-b border-slate-100 bg-white/[0.03] px-5 py-3">
                  <span className="font-bold text-slate-800 text-base text-slate-800">{pack.name}</span>
                  <Badge
                    variant="secondary"
                    className="border border-amber-200 bg-amber-50 text-xs text-amber-500"
                  >
                    {pack.badge}
                  </Badge>
                </div>

                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm font-medium leading-snug text-slate-500">
                    {pack.description}
                  </CardTitle>
                  <CardDescription className="text-xs text-slate-400">
                    {pack.targetAudience}
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-4 pb-5">
                  {/* Module Count */}
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="border-slate-200 bg-white/[0.03] text-xs text-slate-400">
                      {pack.qrCodes.length} QR code{pack.qrCodes.length > 1 ? 's' : ''}
                    </Badge>
                    <Badge variant="outline" className="border-slate-200 bg-white/[0.03] text-xs text-slate-400">
                      {new Set(pack.qrCodes.map((q) => q.moduleType)).size} module{new Set(pack.qrCodes.map((q) => q.moduleType)).size > 1 ? 's' : ''}
                    </Badge>
                  </div>

                  {/* Modules List */}
                  <div className=" max-h-48 overflow-y-auto rounded-xl border border-slate-200">
                    <table className="w-full text-sm">
                      <thead className="sticky top-0 bg-[#EEF0FF]">
                        <tr>
                          <th className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] px-3 py-2 text-left">
                            Module
                          </th>
                          <th className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden sm:table-cell px-3 py-2 text-left">
                            Pièce
                          </th>
                          <th className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] px-3 py-2 text-left">
                            Nom
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/8">
                        {pack.qrCodes.map((qr, idx) => (
                          <tr key={idx} className="hover:bg-[#F8FAFF]">
                            <td className="px-3 py-2">
                              <Badge variant="secondary" className="border border-[#5c8af0]/25 bg-[#5c8af0]/10 text-xs text-blue-700">
                                {moduleLabel(qr.moduleType)}
                              </Badge>
                            </td>
                            <td className="hidden sm:table-cell px-3 py-2 text-slate-400">
                              {qr.roomName}
                            </td>
                            <td className="px-3 py-2 font-medium text-slate-800">
                              {qr.name}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Features */}
                  <div className="rounded-xl border border-slate-200 bg-white/[0.03] p-3">
                    <ul className="space-y-1.5">
                      {pack.features.map((feature) => (
                        <li
                          key={feature}
                          className="flex items-start gap-2 text-sm text-slate-500"
                        >
                          <span aria-hidden="true" className="mt-0.5 shrink-0 text-emerald-600">✓</span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* ── Future Note ──────────────────────────────────────── */}
        <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 rounded-xl p-4 text-center text-sm text-slate-400">
          <p>
            Fonctionnalité à venir : activation/désactivation des packs et personnalisation
            des modules par pack directement depuis cette interface.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
