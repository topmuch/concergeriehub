'use client';

import { useCallback, useEffect, useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { HOST_PLANS } from '@/lib/billing';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { AdminPacks } from '@/components/admin/admin-packs';

// =============================================================
// AdminSubscriptions — Module 4 Abonnements
//  - KPIs réels : MRR, ARR, actifs, impayés, churn 30 j
//  - Onglet Abonnements : table (hôtes/marchands/prestataires)
//    + actions cancel / reactivate (confirmées, auditées)
//  - Onglet Factures : paiements d'abonnement (Transaction réels)
//  - Onglet Coupons : création + annulation (coupon marketplace)
//  - Onglet Packs : réutilisation du composant AdminPacks (config)
// Sources : /api/admin/subscriptions, /api/admin/coupons.
// =============================================================

interface SubRow {
  id: string;
  plan: string;
  amount: number;
  currency: string;
  billingCycle: string;
  status: string;
  stripeSubscriptionId: string | null;
  currentPeriodEnd: string | null;
  createdAt: string;
  subscriber: { type: string; id: string; name: string; email: string | null };
}

interface InvoiceRow {
  id: string;
  amount: number;
  currency: string;
  status: string;
  stripePaymentId: string | null;
  createdAt: string;
}

interface CouponRow {
  id: string;
  code: string;
  discountType: string;
  discountValue: number;
  maxUses: number;
  currentUses: number;
  scans: number;
  status: string;
  commissionRate: number;
  validUntil: string | null;
  createdAt: string;
  merchantName: string;
  ownerEmail: string | null;
}

interface SubsStats {
  mrrEur: number;
  arrEur: number;
  activeCount: number;
  pastDueCount: number;
  cancelled30d: number;
  byPlan: { plan: string; count: number }[];
}

const STATUS_LABEL: Record<string, { label: string; dot: string }> = {
  active: { label: 'Actif', dot: '#34d399' },
  past_due: { label: 'Impayé', dot: '#fbbf24' },
  cancelled: { label: 'Annulé', dot: '#8fa0c2' },
  trialing: { label: 'Essai', dot: '#5c8af0' },
};

export function AdminSubscriptionsContent() {
  const [stats, setStats] = useState<SubsStats | null>(null);
  const [subs, setSubs] = useState<SubRow[]>([]);
  const [invoices, setInvoices] = useState<InvoiceRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);

  const [coupons, setCoupons] = useState<CouponRow[]>([]);
  const [couponsLoading, setCouponsLoading] = useState(true);
  const [couponDialog, setCouponDialog] = useState(false);
  const [couponForm, setCouponForm] = useState({ code: '', discountType: 'percentage', discountValue: '10', maxUses: '50', commissionRate: '5' });
  const [couponBusy, setCouponBusy] = useState(false);

  const fetchSubs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/subscriptions');
      if (!res.ok) throw new Error('Erreur de chargement');
      const data = await res.json();
      setStats(data.stats);
      setSubs(Array.isArray(data.data) ? data.data : []);
      setInvoices(Array.isArray(data.invoices) ? data.invoices : []);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchCoupons = useCallback(async () => {
    setCouponsLoading(true);
    try {
      const res = await fetch('/api/admin/coupons');
      if (!res.ok) throw new Error('Erreur de chargement des coupons');
      const data = await res.json();
      setCoupons(Array.isArray(data.data) ? data.data : []);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setCouponsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSubs();
    fetchCoupons();
  }, [fetchSubs, fetchCoupons]);

  const subAction = async (sub: SubRow, action: 'cancel' | 'reactivate') => {
    setBusyId(sub.id);
    try {
      const res = await fetch(`/api/admin/subscriptions/${sub.id}?action=${action}`, { method: 'PATCH' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur serveur');
      toast.success(data.message || 'OK');
      fetchSubs();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setBusyId(null);
    }
  };

  // ── v4.71 — ÉDITION D'UN ABONNEMENT (plan / cycle / montant / statut) ──
  const [editSub, setEditSub] = useState<SubRow | null>(null);
  const [editForm, setEditForm] = useState({
    plan: 'airbnb_solo',
    billingCycle: 'annual',
    amount: '',
    status: 'active',
  });
  const [editBusy, setEditBusy] = useState(false);

  const openEdit = (sub: SubRow) => {
    const isHostPlan = HOST_PLANS.some((p) => p.id === sub.plan);
    setEditSub(sub);
    setEditForm({
      plan: isHostPlan ? sub.plan : 'custom',
      billingCycle: sub.billingCycle === 'monthly' ? 'monthly' : 'annual',
      amount: sub.amount.toFixed(2),
      status: sub.status,
    });
  };

  /** Prix du plan × cycle (recalcul immédiat côté serveur via HOST_PLANS). */
  const editPricePreview = (): { price: number | null; cycle: string } | null => {
    const hp = HOST_PLANS.find((p) => p.id === editForm.plan);
    if (!hp) return null;
    const cycle = editForm.billingCycle === 'monthly' ? 'monthly' : 'annual';
    return { price: hp.prices[cycle] ?? hp.prices.annual, cycle: hp.prices[cycle] != null ? cycle : 'annual' };
  };

  const saveEdit = async () => {
    if (!editSub) return;
    setEditBusy(true);
    try {
      const body: Record<string, unknown> = { status: editForm.status };
      if (editForm.plan === 'custom') {
        const amount = Number(editForm.amount.replace(',', '.'));
        if (!Number.isFinite(amount) || amount < 0) throw new Error('Montant invalide');
        body.plan = 'custom';
        body.amount = amount;
        body.billingCycle = editForm.billingCycle;
      } else {
        body.plan = editForm.plan;
        body.billingCycle = editPricePreview()?.cycle ?? editForm.billingCycle;
      }
      const res = await fetch(`/api/admin/subscriptions/${editSub.id}?action=edit`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur serveur');
      toast.success(data.message || 'Abonnement mis à jour');
      setEditSub(null);
      fetchSubs();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setEditBusy(false);
    }
  };

  const createCoupon = async () => {
    setCouponBusy(true);
    try {
      const res = await fetch('/api/admin/coupons', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: couponForm.code || undefined,
          discountType: couponForm.discountType,
          discountValue: Number(couponForm.discountValue),
          maxUses: Number(couponForm.maxUses),
          commissionRate: Number(couponForm.commissionRate),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur serveur');
      toast.success(`Coupon ${data.coupon.code} créé`);
      setCouponDialog(false);
      setCouponForm({ code: '', discountType: 'percentage', discountValue: '10', maxUses: '50', commissionRate: '5' });
      fetchCoupons();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setCouponBusy(false);
    }
  };

  const cancelCoupon = async (coupon: CouponRow) => {
    try {
      const res = await fetch(`/api/admin/coupons/${coupon.id}?action=cancel`, { method: 'PATCH' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erreur serveur');
      toast.success(data.message || 'Coupon annulé');
      fetchCoupons();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Erreur inconnue');
    }
  };

  return (
    <div className="space-y-4 p-4 sm:p-6">
      {/* ----- KPIs réels ----- */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'MRR (revenu mensuel récurrent)', value: stats ? `${stats.mrrEur.toFixed(2)} €` : undefined, tone: 'bg-[linear-gradient(160deg,#FF9A62,#F97316)]' },
          { label: 'ARR (projections 12 mois)', value: stats ? `${stats.arrEur.toFixed(2)} €` : undefined, tone: 'bg-[linear-gradient(160deg,#5B8CFF,#2E5BFF)]' },
          { label: 'Abonnements actifs', value: stats?.activeCount, tone: 'bg-[linear-gradient(160deg,#34D399,#059669)]' },
          { label: 'Impayés / churn 30 j', value: stats ? `${stats.pastDueCount} / ${stats.cancelled30d}` : undefined, tone: 'bg-[linear-gradient(160deg,#FF6B7E,#E11D48)]' },
        ].map((kpi) => (
          <div key={kpi.label} className={`relative overflow-hidden rounded-2xl p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.25)] ${kpi.tone}`}>
            <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/85">{kpi.label}</span>
            <div className="mt-2.5 text-3xl font-bold leading-none text-white">
              {kpi.value === undefined ? (
                <span className="block h-7 w-24 animate-pulse rounded-lg bg-white/25" aria-hidden="true" />
              ) : (
                kpi.value
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-slate-100 bg-white shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] overflow-hidden">
        <div className="p-0">
          <Tabs defaultValue="abonnements" className="gap-0">
            <div className="border-b border-slate-100 px-4 pt-4 sm:px-6">
              <TabsList className="h-auto flex-wrap justify-start gap-1 rounded-full border border-slate-200 bg-slate-50 p-1">
                <TabsTrigger value="abonnements" className="rounded-full text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 data-[state=active]:bg-slate-100 data-[state=active]:text-slate-800">
                  Abonnements
                </TabsTrigger>
                <TabsTrigger value="factures" className="rounded-full text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 data-[state=active]:bg-slate-100 data-[state=active]:text-slate-800">
                  Factures
                </TabsTrigger>
                <TabsTrigger value="coupons" className="rounded-full text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 data-[state=active]:bg-slate-100 data-[state=active]:text-slate-800">
                  Coupons
                </TabsTrigger>
                <TabsTrigger value="packs" className="rounded-full text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-400 data-[state=active]:bg-slate-100 data-[state=active]:text-slate-800">
                  Packs &amp; Config
                </TabsTrigger>
              </TabsList>
            </div>

            {/* ----- Onglet Abonnements ----- */}
            <TabsContent value="abonnements" className="p-4 sm:p-6">
              {loading ? (
                <TableSkeletonRows />
              ) : subs.length === 0 ? (
                <EmptyState text="Aucun abonnement en base — les abonnements apparaissent dès le premier paiement (Stripe ou démo)." />
              ) : (
                <div className="overflow-x-auto rounded-xl border border-slate-200">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-100">
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Souscripteur</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Plan</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Montant</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden md:table-cell">Statut</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden lg:table-cell">Fin de période</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden xl:table-cell">Créé le</TableHead>
                        <TableHead className="w-12"><span className="sr-only">Actions</span></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subs.map((s) => {
                        const st = STATUS_LABEL[s.status] ?? { label: s.status, dot: '#8fa0c2' };
                        return (
                          <TableRow key={s.id} className="border-slate-100 hover:bg-[#F8FAFF]">
                            <TableCell>
                              <p className="font-semibold text-slate-800">{s.subscriber.name}</p>
                              <p className="text-xs text-slate-400">
                                {s.subscriber.type === 'user' ? s.subscriber.email : s.subscriber.type}
                              </p>
                            </TableCell>
                            <TableCell>
                              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200">{s.plan}</span>
                            </TableCell>
                            <TableCell className="text-sm">
                              <span className="tabular-nums font-semibold text-slate-800">{s.amount.toFixed(2)} €</span>
                              <span className="text-slate-400"> / {s.billingCycle === 'monthly' ? 'mois' : 'an'}</span>
                            </TableCell>
                            <TableCell className="hidden md:table-cell">
                              <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200">
                                <span className="h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: st.dot }} aria-hidden="true" />
                                {st.label}
                              </span>
                            </TableCell>
                            <TableCell className="hidden text-sm text-slate-400 lg:table-cell">
                              {s.currentPeriodEnd ? format(new Date(s.currentPeriodEnd), 'dd MMM yyyy', { locale: fr }) : '—'}
                            </TableCell>
                            <TableCell className="hidden text-sm text-slate-400 xl:table-cell">
                              {format(new Date(s.createdAt), 'dd MMM yyyy', { locale: fr })}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center justify-end gap-1">
                                {/* v4.71 — Modifier (plan / cycle / montant / statut) */}
                                <Button variant="ghost" size="sm" className="h-8 rounded-full px-2.5 text-[11px] font-semibold text-slate-400 hover:bg-slate-200/70 hover:text-slate-800"
                                  onClick={() => openEdit(s)} disabled={busyId === s.id}
                                  aria-label="Modifier cet abonnement">
                                  Modifier
                                </Button>
                                {s.status === 'active' && (
                                  <Button variant="ghost" size="sm" className="h-8 rounded-full px-2.5 text-[11px] font-semibold text-red-500 hover:bg-[#f07d6a]/10 hover:text-red-500"
                                    onClick={() => subAction(s, 'cancel')} disabled={busyId === s.id}
                                    aria-label="Annuler cet abonnement">
                                    Annuler
                                  </Button>
                                )}
                                {s.status !== 'active' && (
                                  <Button variant="ghost" size="sm" className="h-8 rounded-full px-2.5 text-[11px] font-semibold text-[#5c8af0] hover:bg-[#5c8af0]/10 hover:text-blue-700"
                                    onClick={() => subAction(s, 'reactivate')} disabled={busyId === s.id}
                                    aria-label="Réactiver cet abonnement">
                                    Réactiver
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* ----- Onglet Factures ----- */}
            <TabsContent value="factures" className="p-4 sm:p-6">
              {invoices.length === 0 ? (
                <EmptyState text="Aucune facture — les paiements d'abonnement (webhook Stripe / démo) y apparaissent." />
              ) : (
                <div className=" max-h-96 overflow-y-auto rounded-xl border border-slate-200">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-[#EEF0FF]">
                      <TableRow className="border-slate-100">
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Facture</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Montant</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Statut</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden sm:table-cell">Référence Stripe</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {invoices.map((i) => (
                        <TableRow key={i.id} className="border-slate-100 hover:bg-[#F8FAFF]">
                          <TableCell className="font-mono text-xs text-slate-800">#{i.id.slice(0, 8)}</TableCell>
                          <TableCell className="tabular-nums text-sm font-semibold text-slate-800">{i.amount.toFixed(2)} €</TableCell>
                          <TableCell>
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200">
                              <span
                                className="h-2 w-2 shrink-0 rounded-full"
                                style={{ backgroundColor: i.status === 'completed' || i.status === 'PAID' ? '#34d399' : '#8fa0c2' }}
                                aria-hidden="true"
                              />
                              {i.status}
                            </span>
                          </TableCell>
                          <TableCell className="hidden font-mono text-xs text-slate-400 sm:table-cell">
                            {i.stripePaymentId ?? '—'}
                          </TableCell>
                          <TableCell className="text-sm text-slate-400">
                            {format(new Date(i.createdAt), 'dd MMM yyyy HH:mm', { locale: fr })}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* ----- Onglet Coupons ----- */}
            <TabsContent value="coupons" className="p-4 sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <p className="text-sm text-slate-400">Coupons marketplace — réductions et scans réels.</p>
                <Button size="sm" className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:brightness-110 h-9 rounded-full px-4 text-xs" onClick={() => setCouponDialog(true)}>
                  Nouveau coupon
                </Button>
              </div>
              {couponsLoading ? (
                <TableSkeletonRows />
              ) : coupons.length === 0 ? (
                <EmptyState text="Aucun coupon en base." />
              ) : (
                <div className=" max-h-96 overflow-y-auto rounded-xl border border-slate-200">
                  <Table>
                    <TableHeader className="sticky top-0 z-10 bg-[#EEF0FF]">
                      <TableRow className="border-slate-100">
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Code</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Réduction</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Usage</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A] hidden sm:table-cell">Marchand</TableHead>
                        <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Statut</TableHead>
                        <TableHead className="w-12"><span className="sr-only">Actions</span></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {coupons.map((c) => (
                        <TableRow key={c.id} className="border-slate-100 hover:bg-[#F8FAFF]">
                          <TableCell className="font-mono text-sm font-bold text-amber-500">{c.code}</TableCell>
                          <TableCell className="tabular-nums text-sm text-slate-800">
                            {c.discountType === 'percentage'
                              ? `-${c.discountValue}%`
                              : c.discountType === 'fixed'
                                ? `-${c.discountValue.toFixed(2)} €`
                                : 'BOGO'}
                          </TableCell>
                          <TableCell className="text-xs text-slate-400">
                            {c.currentUses}/{c.maxUses} · {c.scans} scan{c.scans > 1 ? 's' : ''}
                          </TableCell>
                          <TableCell className="hidden text-sm text-slate-500 sm:table-cell">{c.merchantName}</TableCell>
                          <TableCell>
                            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200">
                              <span
                                className="h-2 w-2 shrink-0 rounded-full"
                                style={{ backgroundColor: c.status === 'active' ? '#34d399' : '#8fa0c2' }}
                                aria-hidden="true"
                              />
                              {c.status}
                            </span>
                          </TableCell>
                          <TableCell>
                            {c.status === 'active' && (
                              <Button variant="ghost" size="sm" className="h-8 w-8 rounded-full p-0 text-red-500 hover:bg-[#f07d6a]/10 hover:text-red-500"
                                onClick={() => cancelCoupon(c)} aria-label={`Annuler le coupon ${c.code}`}>
                                <span aria-hidden="true">×</span>
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* ----- Onglet Packs (composant orphelin rebranché) ----- */}
            <TabsContent value="packs" className="p-4 sm:p-6">
              <AdminPacks />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* ----- Dialog création coupon ----- */}
      <Dialog open={couponDialog} onOpenChange={setCouponDialog}>
        <DialogContent className="border-slate-200 bg-white text-slate-800">
          <DialogHeader>
            <DialogTitle className="font-bold text-slate-800 text-lg text-slate-800">Nouveau coupon marketplace</DialogTitle>
            <DialogDescription className="text-slate-400">
              Code généré automatiquement si vide (format HUB-XXXXXXXX).
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div className="grid gap-2">
              <Label htmlFor="coupon-code" className="text-slate-400">Code (optionnel)</Label>
              <Input id="coupon-code" placeholder="HUB-XXXXXX" value={couponForm.code}
                className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#5c8af0]/50"
                onChange={(e) => setCouponForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="coupon-type" className="text-slate-400">Type</Label>
                <select
                  id="coupon-type"
                  className="h-9 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-800 [&>option]:bg-white [&>option]:text-slate-800"
                  value={couponForm.discountType}
                  onChange={(e) => setCouponForm((f) => ({ ...f, discountType: e.target.value }))}
                >
                  <option value="percentage">Pourcentage (%)</option>
                  <option value="fixed">Montant fixe (€)</option>
                </select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="coupon-value" className="text-slate-400">Valeur</Label>
                <Input id="coupon-value" type="number" min="1" value={couponForm.discountValue}
                  className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#5c8af0]/50"
                  onChange={(e) => setCouponForm((f) => ({ ...f, discountValue: e.target.value }))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label htmlFor="coupon-uses" className="text-slate-400">Utilisations max</Label>
                <Input id="coupon-uses" type="number" min="1" value={couponForm.maxUses}
                  className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#5c8af0]/50"
                  onChange={(e) => setCouponForm((f) => ({ ...f, maxUses: e.target.value }))} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="coupon-commission" className="text-slate-400">Commission (%)</Label>
                <Input id="coupon-commission" type="number" min="0" max="100" value={couponForm.commissionRate}
                  className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#5c8af0]/50"
                  onChange={(e) => setCouponForm((f) => ({ ...f, commissionRate: e.target.value }))} />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={createCoupon} disabled={couponBusy} className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:brightness-110 h-9 rounded-full px-4 text-xs">
              Créer le coupon
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── v4.71 — Dialog « Modifier l'abonnement » ── */}
      <Dialog open={!!editSub} onOpenChange={(v) => !v && setEditSub(null)}>
        <DialogContent className="max-w-md rounded-2xl border-slate-200 bg-white text-slate-800">
          <DialogHeader>
            <DialogTitle className="font-bold text-slate-800 text-lg text-slate-800">Modifier l'abonnement</DialogTitle>
            <DialogDescription className="text-slate-400">
              {editSub
                ? `${editSub.subscriber.name}${editSub.subscriber.email ? ` — ${editSub.subscriber.email}` : ''} · plan actuel : ${editSub.plan}`
                : ''}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Plan */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-plan" className="text-slate-400">Plan</Label>
              <Select
                value={editForm.plan}
                onValueChange={(v) => {
                  const hp = HOST_PLANS.find((p) => p.id === v);
                  const cycle = editForm.billingCycle === 'monthly' ? 'monthly' : 'annual';
                  setEditForm((f) => ({
                    ...f,
                    plan: v,
                    amount: hp ? String(hp.prices[cycle] ?? hp.prices.annual) : f.amount,
                  }));
                }}
              >
                <SelectTrigger id="edit-plan" className="rounded-xl border-slate-200 bg-slate-50 text-slate-800"><SelectValue /></SelectTrigger>
                <SelectContent className="border-slate-200 bg-white text-slate-800">
                  {HOST_PLANS.map((p) => (
                    <SelectItem key={p.id} className="focus:bg-slate-200/70 focus:text-slate-800" value={p.id}>
                      {p.name} — {p.maxProperties} bien{p.maxProperties > 1 ? 's' : ''}
                    </SelectItem>
                  ))}
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="custom">Personnalisé (montant libre)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {/* Cycle */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-cycle" className="text-slate-400">Cycle de facturation</Label>
              <Select
                value={editForm.billingCycle}
                onValueChange={(v) => {
                  const hp = HOST_PLANS.find((p) => p.id === editForm.plan);
                  setEditForm((f) => ({
                    ...f,
                    billingCycle: v,
                    ...(hp ? { amount: String(hp.prices[v as 'monthly' | 'annual'] ?? hp.prices.annual) } : {}),
                  }));
                }}
              >
                <SelectTrigger id="edit-cycle" className="rounded-xl border-slate-200 bg-slate-50 text-slate-800"><SelectValue /></SelectTrigger>
                <SelectContent className="border-slate-200 bg-white text-slate-800">
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="monthly">Mensuel</SelectItem>
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="annual">Annuel</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {/* Montant (custom uniquement) */}
            {editForm.plan === 'custom' && (
              <div className="space-y-1.5">
                <Label htmlFor="edit-amount" className="text-slate-400">Montant (€ / cycle)</Label>
                <Input
                  id="edit-amount"
                  type="number"
                  min="0"
                  step="0.01"
                  value={editForm.amount}
                  onChange={(e) => setEditForm((f) => ({ ...f, amount: e.target.value }))}
                  className="rounded-xl border-slate-200 bg-slate-50 text-slate-800 placeholder:text-slate-400/60 focus-visible:ring-[#5c8af0]/50"
                />
              </div>
            )}
            {/* Statut */}
            <div className="space-y-1.5">
              <Label htmlFor="edit-status" className="text-slate-400">Statut</Label>
              <Select
                value={editForm.status}
                onValueChange={(v) => setEditForm((f) => ({ ...f, status: v }))}
              >
                <SelectTrigger id="edit-status" className="rounded-xl border-slate-200 bg-slate-50 text-slate-800"><SelectValue /></SelectTrigger>
                <SelectContent className="border-slate-200 bg-white text-slate-800">
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="active">Actif</SelectItem>
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="trialing">Essai</SelectItem>
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="past_due">Impayé</SelectItem>
                  <SelectItem className="focus:bg-slate-200/70 focus:text-slate-800" value="cancelled">Annulé</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {/* Aperçu prix recalculé */}
            {editForm.plan !== 'custom' && editPricePreview() && (
              <p className="rounded-xl border border-[#5c8af0]/25 bg-[#5c8af0]/8 px-3 py-2 text-xs font-semibold text-blue-700">
                Prix recalculé immédiatement :{' '}
                <span className="tabular-nums font-bold text-slate-800">
                  {(editPricePreview()!.price ?? 0).toFixed(2)} € / {editPricePreview()!.cycle === 'monthly' ? 'mois' : 'an'}
                </span>{' '}
                · {HOST_PLANS.find((p) => p.id === editForm.plan)?.maxProperties} bien(s) inclus
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 h-9 rounded-full px-4 text-xs" onClick={() => setEditSub(null)} disabled={editBusy}>
              Annuler
            </Button>
            <Button onClick={saveEdit} disabled={editBusy} className="inline-flex items-center justify-center rounded-xl bg-[linear-gradient(135deg,#4A8BFF,#2563EB)] text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:brightness-110 h-9 rounded-full px-4 text-xs">
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 rounded-xl px-4 py-12 text-center">
      <p className="mx-auto max-w-md text-sm text-slate-400">{text}</p>
    </div>
  );
}

function TableSkeletonRows() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <Skeleton key={i} className="h-12 w-full bg-slate-200/70" />
      ))}
    </div>
  );
}
