'use client';

// =============================================================
// AdminInvoicesContent — v4.69 PHASE 5 « CRM Superadmin & Facturation »
// -------------------------------------------------------------
// Facturation mensuelle des commissions RoomScan :
//   • KPIs (à encaisser / encaissé / en retard) ;
//   • génération des factures du mois (tous les hôtes actifs ou un hôte) ;
//   • tableau : hôte, mois, commandes, total encaissé, taux, commission,
//     échéance, statut — actions : marquer payée, PDF, taux, supprimer.
// API : GET/POST/PATCH/DELETE /api/admin/commission-invoices (Superadmin).
// PDF : downloadCommissionInvoicePdf (client, jspdf).
// =============================================================
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import {
  AlertTriangle,
  BadgeEuro,
  CheckCircle2,
  Download,
  FileText,
  Loader2,
  Percent,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { downloadCommissionInvoicePdf } from '@/lib/commission-invoice-pdf';

// ── Types (contrat API) ──────────────────────────────────────
interface InvoiceRow {
  id: string;
  month: number;
  year: number;
  totalOrdersAmount: number;
  commissionRate: number;
  commissionOwed: number;
  ordersCount: number;
  breakdown: { minibar?: number; services?: number; laundry?: number } | null;
  status: string;
  dueDate: string;
  paidAt: string | null;
  invoicePdfUrl?: string | null;
  host: { id: string; email: string; fullName: string | null };
}

interface Kpis {
  pendingTotal: number;
  paidTotal: number;
  overdueTotal: number;
  pendingCount: number;
  overdueCount: number;
  paidCount: number;
}

const MONTHS_FR = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre',
];

const eur = (n: number) => `${n.toFixed(2).replace('.', ',')} €`;

function monthLabel(month: number, year: number): string {
  return `${MONTHS_FR[Math.min(11, Math.max(0, month - 1))]} ${year}`;
}

function statusBadge(status: string): { label: string; className: string } {
  if (status === 'paid') return { label: 'Payée', className: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
  if (status === 'overdue') return { label: 'En retard', className: 'bg-red-100 text-red-800 border-red-200' };
  return { label: 'En attente', className: 'bg-amber-100 text-amber-800 border-amber-200' };
}

function frDate(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
}

export function AdminInvoicesContent() {
  const [invoices, setInvoices] = useState<InvoiceRow[] | null>(null);
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  // Sélection du mois à facturer : par défaut = le mois précédent.
  const now = new Date();
  const prevMonth = now.getMonth() === 0 ? 12 : now.getMonth(); // getMonth() = index → mois précédent = index courant
  const prevYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
  const [genMonth, setGenMonth] = useState(prevMonth);
  const [genYear, setGenYear] = useState(prevYear);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  // Dialog taux de commission
  const [rateHost, setRateHost] = useState<{ id: string; email: string; rate: number } | null>(null);
  const [rateInput, setRateInput] = useState('20');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/commission-invoices', { cache: 'no-store' });
      const json = (await res.json()) as { invoices?: InvoiceRow[]; kpis?: Kpis; error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Chargement impossible.');
        setInvoices([]);
        return;
      }
      setInvoices(json.invoices ?? []);
      setKpis(json.kpis ?? null);
    } catch {
      toast.error('Connexion impossible. Réessayez.');
      setInvoices([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  /** Génère les factures du mois sélectionné (tous les hôtes actifs). */
  async function generate() {
    setBusy(true);
    try {
      const res = await fetch('/api/admin/commission-invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ month: genMonth, year: genYear }),
      });
      const json = (await res.json()) as { ok?: boolean; created?: number; updated?: number; skipped?: number; error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Génération impossible.');
        return;
      }
      toast.success(
        `Factures générées — ${json.created ?? 0} créée(s), ${json.updated ?? 0} mise(s) à jour, ${json.skipped ?? 0} ignorée(s).`,
      );
      await load();
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(id: string, status: string) {
    setBusy(true);
    try {
      const res = await fetch('/api/admin/commission-invoices', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
      const json = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Mise à jour impossible.');
        return;
      }
      toast.success(status === 'paid' ? 'Facture marquée payée ✓' : 'Statut mis à jour');
      await load();
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setBusy(false);
    }
  }

  async function removeInvoice(id: string) {
    if (!window.confirm('Supprimer définitivement cette facture (non payée) ?')) return;
    setBusy(true);
    try {
      const res = await fetch(`/api/admin/commission-invoices?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
      const json = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Suppression impossible.');
        return;
      }
      toast.success('Facture supprimée');
      await load();
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setBusy(false);
    }
  }

  async function saveRate() {
    if (!rateHost) return;
    const pct = Number(rateInput.replace(',', '.'));
    if (!Number.isFinite(pct) || pct <= 0 || pct > 50) {
      toast.error('Taux invalide (entre 0,1 et 50 %).');
      return;
    }
    setBusy(true);
    try {
      const res = await fetch('/api/admin/commission-invoices', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hostId: rateHost.id, commissionRate: pct / 100 }),
      });
      const json = (await res.json()) as { ok?: boolean; error?: string };
      if (!res.ok) {
        toast.error(json.error || 'Mise à jour impossible.');
        return;
      }
      toast.success(`Taux de commission mis à jour : ${pct} %`);
      setRateHost(null);
      await load();
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setBusy(false);
    }
  }

  const filtered = (invoices ?? []).filter((i) => {
    if (statusFilter !== 'all' && i.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      const host = `${i.host.fullName ?? ''} ${i.host.email}`.toLowerCase();
      if (!host.includes(q) && !monthLabel(i.month, i.year).toLowerCase().includes(q)) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex flex-col gap-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">💰 Commissions & Facturation</h1>
          <p className="text-sm text-muted-foreground">
            Facturation mensuelle de la commission RoomScan sur les commandes encaissées par les hôtes via leur Hub.
          </p>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="border-amber-200 bg-amber-50/50">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-100 text-lg" aria-hidden="true">
              ⏳
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-wide text-amber-700">À encaisser</p>
              <p className="truncate text-xl font-bold text-amber-900">
                {kpis ? eur(kpis.pendingTotal) : '…'}
                <span className="ml-1.5 text-xs font-medium text-amber-700/80">({kpis?.pendingCount ?? 0})</span>
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-emerald-200 bg-emerald-50/50">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-lg" aria-hidden="true">
              ✅
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-wide text-emerald-700">Encaissé</p>
              <p className="truncate text-xl font-bold text-emerald-900">
                {kpis ? eur(kpis.paidTotal) : '…'}
                <span className="ml-1.5 text-xs font-medium text-emerald-700/80">({kpis?.paidCount ?? 0})</span>
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-red-200 bg-red-50/50">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-100 text-lg" aria-hidden="true">
              <AlertTriangle className="h-5 w-5 text-red-600" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-wide text-red-700">En retard</p>
              <p className="truncate text-xl font-bold text-red-900">
                {kpis ? eur(kpis.overdueTotal) : '…'}
                <span className="ml-1.5 text-xs font-medium text-red-700/80">({kpis?.overdueCount ?? 0})</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Barre de génération */}
      <Card>
        <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
          <div className="space-y-1.5">
            <Label htmlFor="gen-month">Mois à facturer</Label>
            <Select value={String(genMonth)} onValueChange={(v) => setGenMonth(Number(v))}>
              <SelectTrigger id="gen-month" className="w-[170px]">
                <SelectValue placeholder="Mois" />
              </SelectTrigger>
              <SelectContent>
                {MONTHS_FR.map((m, idx) => (
                  <SelectItem key={m} value={String(idx + 1)}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="gen-year">Année</Label>
            <Input
              id="gen-year"
              type="number"
              min={2024}
              max={2100}
              value={genYear}
              onChange={(e) => setGenYear(Number(e.target.value) || prevYear)}
              className="w-[110px]"
            />
          </div>
          <Button onClick={generate} disabled={busy} className="sm:ml-auto">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Plus className="h-4 w-4" aria-hidden="true" />}
            ⚡ Générer les factures du mois
          </Button>
        </CardContent>
      </Card>

      {/* Filtres */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un hôte ou un mois…"
            className="pl-9"
            aria-label="Rechercher une facture"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[180px]" aria-label="Filtrer par statut">
            <SelectValue placeholder="Statut" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les statuts</SelectItem>
            <SelectItem value="pending">En attente</SelectItem>
            <SelectItem value="paid">Payées</SelectItem>
            <SelectItem value="overdue">En retard</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tableau */}
      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="flex items-center justify-center gap-2 p-10 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> Chargement des factures…
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-10 text-center">
              <p className="text-2xl" aria-hidden="true">🧾</p>
              <p className="mt-2 text-sm font-medium">Aucune facture de commission</p>
              <p className="mt-1 text-xs text-muted-foreground">
                Sélectionnez un mois puis cliquez sur « Générer les factures » pour calculer les commissions des hôtes actifs.
              </p>
            </div>
          ) : (
            <div className="max-h-[62vh] overflow-auto">
              <table className="w-full min-w-[860px] text-sm">
                <thead className="sticky top-0 bg-muted/80 backdrop-blur">
                  <tr className="text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                    <th className="px-4 py-3">Mois</th>
                    <th className="px-4 py-3">Hôte</th>
                    <th className="px-4 py-3 text-right">Commandes</th>
                    <th className="px-4 py-3 text-right">Total encaissé</th>
                    <th className="px-4 py-3 text-right">Taux</th>
                    <th className="px-4 py-3 text-right">Commission</th>
                    <th className="px-4 py-3">Échéance</th>
                    <th className="px-4 py-3">Statut</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filtered.map((i) => {
                    const badge = statusBadge(i.status);
                    return (
                      <tr key={i.id} className="hover:bg-muted/40">
                        <td className="px-4 py-3 font-medium">{monthLabel(i.month, i.year)}</td>
                        <td className="px-4 py-3">
                          <p className="font-medium">{i.host.fullName || 'Hôte'}</p>
                          <p className="text-xs text-muted-foreground">{i.host.email}</p>
                        </td>
                        <td className="px-4 py-3 text-right tabular-nums">{i.ordersCount}</td>
                        <td className="px-4 py-3 text-right tabular-nums">{eur(i.totalOrdersAmount)}</td>
                        <td className="px-4 py-3 text-right tabular-nums">{Math.round(i.commissionRate * 100)} %</td>
                        <td className="px-4 py-3 text-right font-bold tabular-nums text-primary">{eur(i.commissionOwed)}</td>
                        <td className="px-4 py-3 text-xs text-muted-foreground">{frDate(i.dueDate)}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className={badge.className}>
                            {badge.label}
                          </Badge>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center justify-end gap-1">
                            {i.status !== 'paid' && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="h-8 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                                onClick={() => void setStatus(i.id, 'paid')}
                                disabled={busy}
                                aria-label={`Marquer la facture de ${i.host.email} comme payée`}
                              >
                                <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" /> Payée
                              </Button>
                            )}
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8"
                              onClick={() =>
                                downloadCommissionInvoicePdf({
                                  monthLabel: monthLabel(i.month, i.year),
                                  hostName: i.host.fullName || 'Hôte',
                                  hostEmail: i.host.email,
                                  totalOrdersAmount: i.totalOrdersAmount,
                                  commissionRate: i.commissionRate,
                                  commissionOwed: i.commissionOwed,
                                  ordersCount: i.ordersCount,
                                  breakdown: i.breakdown,
                                  status: i.status,
                                  dueDate: i.dueDate,
                                  paidAt: i.paidAt,
                                  issuedBy: 'RoomScan',
                                })
                              }
                              aria-label={`Télécharger le PDF de la facture de ${i.host.email}`}
                            >
                              <Download className="h-3.5 w-3.5" aria-hidden="true" /> PDF
                            </Button>
                            {i.invoicePdfUrl ? (
                              <a
                                href={i.invoicePdfUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex h-8 items-center gap-1.5 rounded-md border border-input bg-background px-3 text-xs font-medium hover:bg-accent"
                                aria-label={`Ouvrir le PDF public (serveur) de la facture de ${i.host.email}`}
                              >
                                <FileText className="h-3.5 w-3.5" aria-hidden="true" /> PDF public
                              </a>
                            ) : null}
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-8"
                              onClick={() => {
                                setRateHost({ id: i.host.id, email: i.host.email, rate: i.commissionRate });
                                setRateInput(String(Math.round(i.commissionRate * 100)));
                              }}
                              aria-label={`Modifier le taux de commission de ${i.host.email}`}
                            >
                              <Percent className="h-3.5 w-3.5" aria-hidden="true" />
                            </Button>
                            {i.status !== 'paid' && (
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-8 text-rose-600 hover:text-rose-700"
                                onClick={() => void removeInvoice(i.id)}
                                disabled={busy}
                                aria-label={`Supprimer la facture de ${i.host.email}`}
                              >
                                <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog taux de commission */}
      <Dialog open={!!rateHost} onOpenChange={(v) => !v && setRateHost(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Percent className="h-4 w-4 text-primary" aria-hidden="true" /> Taux de commission
            </DialogTitle>
            <DialogDescription>
              Taux appliqué aux commandes encaissées par <span className="font-medium">{rateHost?.email}</span> (ex : 10 ou 20 %).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="rate-input">Taux en %</Label>
            <Input
              id="rate-input"
              inputMode="decimal"
              value={rateInput}
              onChange={(e) => setRateInput(e.target.value)}
              placeholder="20"
            />
            <p className="text-xs text-muted-foreground">
              <BadgeEuro className="mr-1 inline h-3.5 w-3.5" aria-hidden="true" />
              Prend effet à la prochaine génération de factures. Les factures déjà payées ne sont pas recalculées.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRateHost(null)}>
              Annuler
            </Button>
            <Button onClick={() => void saveRate()} disabled={busy}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : null}
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
