'use client';

import { useCallback, useEffect, useState } from 'react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  // FIX-11 — matériau de la plaque (aluminium défaut | bois | acrylique)
  parsePlaqueMaterial,
  PLAQUE_MATERIAL_META,
} from '@/lib/plaque-material';

type QrStatus = 'inactive' | 'active' | 'lost' | 'cancelled';

type FilterStatus = 'ALL' | QrStatus;

interface PhysicalQr {
  id: string;
  activationCode: string;
  status: string;
  activatedByUserId: string | null;
  activatedAt: string | null;
  batchId: string;
  batch: {
    id: string;
    quantity: number;
    createdAt: string;
    designConfig: string; // FIX-11 — design du lot (matériau)
  };
  activatedBy?: { id: string; email: string; fullName: string | null } | null;
}

interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

// Badges de statut « lux » — teintes sémantiques 8-10 % sur fond nuit.
const STATUS_MAP: Record<string, { label: string; variant: 'secondary' | 'default' | 'destructive' | 'outline'; className?: string }> = {
  inactive: { label: 'Inactif', variant: 'secondary', className: 'border border-white/10 bg-white/[0.05] text-[#8fa0c2]' },
  active: { label: 'Actif', variant: 'default', className: 'border border-[#34d399]/25 bg-[#34d399]/10 text-[#86e9cb] hover:bg-[#34d399]/15' },
  lost: { label: 'Perdu', variant: 'destructive', className: 'border border-[#f07d6a]/25 bg-[#f07d6a]/10 text-[#f07d6a]' },
  cancelled: { label: 'Annulé', variant: 'outline', className: 'border border-[#fbbf24]/25 bg-[#fbbf24]/10 text-[#fbbf24]' },
};

const FILTER_OPTIONS: { value: FilterStatus; label: string }[] = [
  { value: 'ALL', label: 'Tous' },
  { value: 'inactive', label: 'Inactif' },
  { value: 'active', label: 'Actif' },
  { value: 'lost', label: 'Perdu' },
  { value: 'cancelled', label: 'Annulé' },
];

type PendingAction = {
  id: string;
  newStatus: QrStatus;
  label: string;
  description: string;
} | null;

function TableSkeleton() {
  return (
    <div className="space-y-3 p-4">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          <Skeleton className="h-4 w-32 bg-white/8" />
          <Skeleton className="h-4 w-20 bg-white/8" />
          <Skeleton className="h-5 w-20 rounded-full bg-white/8" />
          <Skeleton className="h-4 w-32 bg-white/8" />
          <Skeleton className="h-4 w-24 bg-white/8" />
          <Skeleton className="h-8 w-20 bg-white/8" />
        </div>
      ))}
    </div>
  );
}

export function ManagePhysicalQr() {
  const [qrs, setQrs] = useState<PhysicalQr[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('ALL');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState<PaginationMeta | null>(null);
  const [pendingAction, setPendingAction] = useState<PendingAction>(null);
  const [updating, setUpdating] = useState(false);

  const fetchQrs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const params = new URLSearchParams();
      params.set('page', String(page));
      params.set('limit', '20');
      if (statusFilter !== 'ALL') params.set('status', statusFilter);
      if (search.trim()) params.set('search', search.trim());

      const res = await fetch(`/api/admin/physical-qr?${params.toString()}`);
      if (!res.ok) throw new Error('Erreur lors du chargement des QR codes');
      const data = await res.json();
      setQrs(Array.isArray(data) ? data : data.data ?? data.qrCodes ?? []);
      if (data.pagination) {
        setPagination(data.pagination);
      } else {
        setPagination({
          page: data.page ?? page,
          limit: data.limit ?? 20,
          total: data.total ?? (Array.isArray(data) ? data.length : 0),
          totalPages: data.totalPages ?? 1,
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur inconnue');
    } finally {
      setLoading(false);
    }
  }, [statusFilter, search, page]);

  useEffect(() => {
    fetchQrs();
  }, [fetchQrs]);

  const handleStatusChange = (value: string) => {
    setStatusFilter(value as FilterStatus);
    setPage(1);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setPage(1);
  };

  const handleStatusAction = (qr: PhysicalQr, newStatus: QrStatus) => {
    const labels: Record<QrStatus, string> = {
      lost: 'Marquer comme perdu',
      inactive: 'Réinitialiser',
      cancelled: 'Annuler',
      active: 'Activer',
    };
    const descriptions: Record<QrStatus, string> = {
      lost: `Voulez-vous vraiment marquer le code ${qr.activationCode} comme perdu ?`,
      inactive: `Voulez-vous vraiment réinitialiser le code ${qr.activationCode} ? Il redeviendra inactif.`,
      cancelled: `Voulez-vous vraiment annuler le code ${qr.activationCode} ? Cette action est irréversible.`,
      active: `Voulez-vous vraiment activer le code ${qr.activationCode} ?`,
    };
    setPendingAction({
      id: qr.id,
      newStatus,
      label: labels[newStatus],
      description: descriptions[newStatus],
    });
  };

  const confirmAction = async () => {
    if (!pendingAction) return;
    try {
      setUpdating(true);
      const res = await fetch('/api/admin/physical-qr', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: pendingAction.id,
          status: pendingAction.newStatus,
        }),
      });
      if (!res.ok) throw new Error('Erreur lors de la mise à jour');
      setPendingAction(null);
      fetchQrs();
    } catch (err) {
      console.error(err);
    } finally {
      setUpdating(false);
    }
  };

  const getStatusInfo = (status: string) => {
    return STATUS_MAP[status] || { label: status, variant: 'outline' as const, className: 'border-white/12 text-[#8fa0c2]' };
  };

  return (
    <Card className="lux-card">
      <CardHeader>
        <CardTitle className="lux-display text-xl text-white">QR codes physiques</CardTitle>
        <CardDescription className="text-sm text-[#8fa0c2]">
          Gérez et suivez l&apos;état de tous les QR codes physiques
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filters */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <Input
            placeholder="Rechercher un code d'activation..."
            value={search}
            onChange={handleSearchChange}
            className="h-10 rounded-xl border-white/12 bg-white/[0.04] text-white placeholder:text-[#8fa0c2]/60 focus-visible:ring-[#5c8af0]/50 sm:max-w-xs"
          />
          <Select value={statusFilter} onValueChange={handleStatusChange}>
            <SelectTrigger className="h-10 w-full rounded-xl border-white/12 bg-white/[0.04] text-white sm:w-44">
              <SelectValue placeholder="Statut" />
            </SelectTrigger>
            <SelectContent className="border-white/10 bg-[#0d1530] text-white">
              {FILTER_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value} className="focus:bg-white/8 focus:text-white">
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Loading */}
        {loading && <TableSkeleton />}

        {/* Error */}
        {error && !loading && (
          <div className="lux-empty flex flex-col items-center justify-center rounded-2xl px-4 py-12 text-center">
            <span className="lux-dot mb-4" style={{ backgroundColor: '#f07d6a' }} aria-hidden="true" />
            <p className="text-sm text-[#f07d6a]">{error}</p>
            <Button variant="outline" size="sm" className="lux-btn-ghost mt-3 h-8 rounded-full px-4 text-xs" onClick={fetchQrs}>
              Réessayer
            </Button>
          </div>
        )}

        {/* Empty */}
        {!loading && !error && qrs.length === 0 && (
          <div className="lux-empty flex flex-col items-center justify-center rounded-2xl px-4 py-12 text-center">
            <span className="lux-dot mb-4 opacity-70" style={{ backgroundColor: '#8fa0c2' }} aria-hidden="true" />
            <h3 className="lux-display text-lg text-white">Aucun QR code</h3>
            <p className="mt-1 text-sm text-[#8fa0c2]">
              Aucun QR code ne correspond à vos critères de recherche.
            </p>
          </div>
        )}

        {/* Table */}
        {!loading && !error && qrs.length > 0 && (
          <>
            <div className="overflow-x-auto rounded-xl border border-white/10">
              <Table>
                <TableHeader className="sticky top-0 z-10 bg-[#0d1530]">
                  <TableRow className="border-white/8 hover:bg-transparent">
                    <TableHead className="lux-eyebrow !text-[9.5px]">Code d&apos;activation</TableHead>
                    <TableHead className="lux-eyebrow !text-[9.5px]">Lot</TableHead>
                    {/* FIX-11 — matériau de la plaque (designConfig du lot) */}
                    <TableHead className="lux-eyebrow !text-[9.5px]">Matériau</TableHead>
                    <TableHead className="lux-eyebrow !text-[9.5px]">Statut</TableHead>
                    <TableHead className="lux-eyebrow !text-[9.5px]">Activé par</TableHead>
                    <TableHead className="lux-eyebrow !text-[9.5px]">Date d&apos;activation</TableHead>
                    <TableHead className="lux-eyebrow !text-[9.5px] text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {qrs.map((qr) => {
                    const statusInfo = getStatusInfo(qr.status);
                    return (
                      <TableRow key={qr.id} className="border-white/8 hover:bg-white/[0.04]">
                        <TableCell className="font-mono text-sm font-medium text-white">
                          {qr.activationCode}
                        </TableCell>
                        <TableCell className="font-mono text-xs text-[#8fa0c2]">
                          {qr.batchId.slice(0, 8)}…
                        </TableCell>
                        <TableCell>
                          {(() => {
                            const material = parsePlaqueMaterial(qr.batch.designConfig);
                            const meta = PLAQUE_MATERIAL_META[material];
                            return (
                              <Badge
                                variant="outline"
                                className="whitespace-nowrap border-white/12 bg-white/[0.03] text-xs text-[#8fa0c2]"
                                title={`Matériau : ${meta.label}`}
                              >
                                {meta.label}
                              </Badge>
                            );
                          })()}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={statusInfo.variant}
                            className={statusInfo.className}
                          >
                            {statusInfo.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-[#8fa0c2]">
                          {qr.activatedBy?.email ? (
                            <span className="text-xs">{qr.activatedBy.email}</span>
                          ) : qr.activatedByUserId ? (
                            <span className="font-mono text-xs">
                              {qr.activatedByUserId.slice(0, 8)}…
                            </span>
                          ) : (
                            <span className="text-[#8fa0c2]/50">—</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-[#8fa0c2]">
                          {qr.activatedAt
                            ? format(new Date(qr.activatedAt), 'dd MMM yyyy', {
                                locale: fr,
                              })
                            : (
                                <span className="text-[#8fa0c2]/50">—</span>
                              )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {qr.status === 'active' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-xs text-[#f07d6a] hover:bg-[#f07d6a]/10 hover:text-[#f07d6a]"
                                onClick={() => handleStatusAction(qr, 'lost')}
                                title="Marquer perdu"
                              >
                                Perdu
                              </Button>
                            )}
                            {(qr.status === 'lost' || qr.status === 'cancelled') && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-xs text-[#8fa0c2] hover:bg-white/[0.06] hover:text-white"
                                onClick={() => handleStatusAction(qr, 'inactive')}
                                title="Réinitialiser"
                              >
                                Réinit.
                              </Button>
                            )}
                            {(qr.status === 'active' || qr.status === 'inactive') && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-xs text-[#fbbf24] hover:bg-[#fbbf24]/10 hover:text-[#fbbf24]"
                                onClick={() => handleStatusAction(qr, 'cancelled')}
                                title="Annuler"
                              >
                                Annuler
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            {pagination && pagination.totalPages > 1 && (
              <div className="flex items-center justify-between pt-4">
                <p className="text-sm text-[#8fa0c2]">
                  Page {pagination.page} sur {pagination.totalPages} —{' '}
                  {pagination.total} résultat{pagination.total > 1 ? 's' : ''}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="lux-btn-ghost h-8 rounded-full px-4 text-xs"
                    disabled={pagination.page <= 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                  >
                    Précédent
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="lux-btn-ghost h-8 rounded-full px-4 text-xs"
                    disabled={pagination.page >= pagination.totalPages}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    Suivant
                  </Button>
                </div>
              </div>
            )}
          </>
        )}

        {/* Confirmation Dialog */}
        <AlertDialog
          open={pendingAction !== null}
          onOpenChange={(open) => {
            if (!open) setPendingAction(null);
          }}
        >
          <AlertDialogContent className="border-white/10 bg-[#0b1226] text-white">
            <AlertDialogHeader>
              <AlertDialogTitle className="lux-display text-lg text-white">{pendingAction?.label}</AlertDialogTitle>
              <AlertDialogDescription className="text-sm text-[#8fa0c2]">
                {pendingAction?.description}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={updating} className="lux-btn-ghost rounded-full border-white/10 bg-transparent px-4 text-xs text-[#c7d3ec]">
                Annuler
              </AlertDialogCancel>
              <AlertDialogAction
                onClick={confirmAction}
                disabled={updating}
                className="lux-btn rounded-full text-xs"
              >
                {updating ? 'Mise à jour…' : 'Confirmer'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
}
