'use client';

// =============================================================
// AdminAssistance — ONGLET « ASSISTANCE » du SUPERADMIN (v4.125)
// CONNECTÉ à l'onglet Assistance du dashboard hôte (mêmes tables
// edl_support_*). Liste de tous les tickets, fil de discussion,
// réponse de l'équipe (message 'ADMIN' → statut ANSWERED) et
// gestion des statuts.
// =============================================================
import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { LifeBuoy, RefreshCw, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const STATUS_META: Record<string, { label: string; cls: string }> = {
  OPEN: { label: 'Ouvert (attend réponse)', cls: 'bg-amber-400/10 text-amber-300 border-amber-400/30' },
  ANSWERED: { label: 'Répondu', cls: 'bg-sky-400/10 text-sky-300 border-sky-400/30' },
  RESOLVED: { label: 'Résolu', cls: 'bg-emerald-400/10 text-emerald-300 border-emerald-400/30' },
  CLOSED: { label: 'Fermé', cls: 'bg-white/5 text-[#8fa0c2] border-white/15' },
};
const PRIORITY_LABEL: Record<string, string> = {
  LOW: 'Basse',
  NORMAL: 'Normale',
  HIGH: 'Haute',
  URGENT: 'Urgente',
};
const CATEGORY_LABEL: Record<string, string> = {
  GENERAL: 'Question générale',
  TECHNIQUE: 'Problème technique',
  SEJOUR: 'Séjour / EDL',
  FACTURATION: 'Facturation',
  AUTRE: 'Autre',
};

function fmt(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return new Intl.DateTimeFormat('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
}

interface TicketPreview {
  id: string;
  subject: string;
  category: string;
  priority: string;
  status: string;
  userName: string;
  userEmail: string;
  createdAt: string;
  updatedAt: string;
  messagesCount: number;
  lastMessage: { author: string; body: string; createdAt: string } | null;
}
interface TicketMessage {
  id: string;
  author: string;
  authorName: string;
  body: string;
  createdAt: string;
}
interface TicketDetail extends Omit<TicketPreview, 'lastMessage' | 'messagesCount'> {
  messages: TicketMessage[];
}

export function AdminAssistance() {
  const [tickets, setTickets] = useState<TicketPreview[] | null>(null);
  const [counts, setCounts] = useState<{ total: number; open: number; answered: number; resolved: number; closed: number } | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<TicketDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);

  const load = useCallback(async (filter: string) => {
    setLoading(true);
    try {
      const qs = filter !== 'ALL' ? `?status=${filter}` : '';
      const res = await fetch(`/api/admin/assistance${qs}`, { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as
        | { tickets?: TicketPreview[]; counts?: typeof counts }
        | null;
      if (!res.ok) {
        toast.error('Chargement impossible.');
        setTickets([]);
        return;
      }
      setTickets(Array.isArray(json?.tickets) ? json.tickets : []);
      if (json?.counts) setCounts(json.counts);
    } catch {
      toast.error('Erreur de connexion.');
      setTickets([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load(statusFilter);
  }, [load, statusFilter]);

  const openDetail = async (id: string) => {
    setDetailLoading(true);
    setReply('');
    try {
      const res = await fetch(`/api/admin/assistance/${id}`, { cache: 'no-store' });
      const json = (await res.json().catch(() => null)) as { ticket?: TicketDetail } | null;
      if (!res.ok || !json?.ticket) {
        toast.error('Ticket introuvable.');
        return;
      }
      setSelected(json.ticket);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setDetailLoading(false);
    }
  };

  const sendReply = async () => {
    if (!selected || sending) return;
    const text = reply.trim();
    if (text.length < 2) return toast.error('Écrivez la réponse avant d’envoyer.');
    setSending(true);
    try {
      const res = await fetch(`/api/admin/assistance/${selected.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      const json = (await res.json().catch(() => null)) as { error?: string; message?: string } | null;
      if (!res.ok) {
        toast.error(json?.message ?? json?.error ?? 'Envoi impossible.');
        return;
      }
      toast.success('Réponse envoyée — visible par l’hôte dans son onglet Assistance.');
      setReply('');
      await openDetail(selected.id);
      void load(statusFilter);
    } catch {
      toast.error('Erreur de connexion.');
    } finally {
      setSending(false);
    }
  };

  const setTicketStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/admin/assistance/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) {
        toast.error('Action impossible.');
        return;
      }
      toast.success('Statut mis à jour.');
      if (selected?.id === id) await openDetail(id);
      void load(statusFilter);
    } catch {
      toast.error('Erreur de connexion.');
    }
  };

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-4 p-4 sm:p-6">
      {/* ── En-tête ── */}
      <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <span
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-[#e9c47c]/30 bg-[#e9c47c]/10 text-[#e9c47c]"
              aria-hidden="true"
            >
              <LifeBuoy className="h-5 w-5" />
            </span>
            <div>
              <h2 className="text-base font-bold text-white">Assistance — tickets des hôtes</h2>
              <p className="text-xs text-[#8fa0c2]">
                Connecté à l&apos;onglet « Assistance » du dashboard États des Lieux : chaque ticket
                créé par un hôte arrive ici, vos réponses s&apos;affichent dans son fil.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {counts ? (
              <div className="flex flex-wrap gap-1.5 text-[10px] font-bold">
                <span className="rounded-full border border-amber-400/30 bg-amber-400/10 px-2 py-1 text-amber-300">
                  {counts.open} ouverts
                </span>
                <span className="rounded-full border border-sky-400/30 bg-sky-400/10 px-2 py-1 text-sky-300">
                  {counts.answered} répondus
                </span>
                <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-2 py-1 text-emerald-300">
                  {counts.resolved} résolus
                </span>
              </div>
            ) : null}
            <button
              type="button"
              onClick={() => void load(statusFilter)}
              aria-label="Rafraîchir"
              className="rounded-lg border border-white/10 p-2 text-white/70 transition-colors hover:bg-white/5 hover:text-white"
            >
              <RefreshCw className={cn('h-4 w-4', loading && 'animate-spin')} />
            </button>
          </div>
        </div>

        {/* Filtres statut */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {['ALL', 'OPEN', 'ANSWERED', 'RESOLVED', 'CLOSED'].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStatusFilter(s)}
              aria-pressed={statusFilter === s}
              className={cn(
                'min-h-[34px] rounded-lg border px-3 text-xs font-bold transition-colors',
                statusFilter === s
                  ? 'border-[#e9c47c]/50 bg-[#e9c47c]/15 text-[#e9c47c]'
                  : 'border-white/10 text-white/70 hover:bg-white/5',
              )}
            >
              {s === 'ALL' ? 'Tous' : STATUS_META[s].label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* ── Liste des tickets ── */}
        <div className="grid content-start gap-3">
          {loading ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)
          ) : tickets && tickets.length > 0 ? (
            tickets.map((t) => {
              const meta = STATUS_META[t.status] ?? STATUS_META.OPEN;
              const active = selected?.id === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    void openDetail(t.id);
                  }}
                  aria-current={active ? 'true' : undefined}
                  className={cn(
                    'rounded-2xl border bg-white/[0.04] p-4 text-left transition-colors hover:bg-white/[0.07]',
                    active ? 'border-[#e9c47c]/50' : 'border-white/10',
                  )}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="min-w-0 flex-1 truncate text-sm font-bold text-white">{t.subject}</p>
                    <span className={cn('inline-flex shrink-0 items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold', meta.cls)}>
                      {meta.label}
                    </span>
                  </div>
                  <p className="mt-1 text-[11px] text-[#8fa0c2]">
                    {t.userName} ({t.userEmail}) · {CATEGORY_LABEL[t.category] ?? t.category} ·{' '}
                    priorité {PRIORITY_LABEL[t.priority] ?? t.priority}
                  </p>
                  <p className="mt-0.5 text-[11px] text-[#8fa0c2]">
                    {t.messagesCount} message(s) · mis à jour {fmt(t.updatedAt)}
                  </p>
                  {t.lastMessage ? (
                    <p className="mt-1.5 line-clamp-1 text-xs text-white/70">
                      {t.lastMessage.author === 'HOST' ? 'Hôte : ' : 'Vous : '}
                      {t.lastMessage.body}
                    </p>
                  ) : null}
                </button>
              );
            })
          ) : (
            <p className="rounded-2xl border border-white/10 bg-white/[0.04] p-8 text-center text-sm text-[#8fa0c2]">
              Aucun ticket{statusFilter !== 'ALL' ? ' pour ce statut' : ''}.
            </p>
          )}
        </div>

        {/* ── Détail / fil ── */}
        <div className="grid content-start gap-3">
          {selected ? (
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-white">{selected.subject}</p>
                  <p className="text-[11px] text-[#8fa0c2]">
                    {selected.userName} ({selected.userEmail}) · ouvert {fmt(selected.createdAt)}
                  </p>
                </div>
                <span className={cn('inline-flex shrink-0 items-center rounded-full border px-2.5 py-0.5 text-[10px] font-bold', (STATUS_META[selected.status] ?? STATUS_META.OPEN).cls)}>
                  {(STATUS_META[selected.status] ?? STATUS_META.OPEN).label}
                </span>
              </div>

              {/* Fil */}
              <div className="mt-4 max-h-[420px] space-y-3 overflow-y-auto pr-1 lux-scroll">
                {detailLoading ? (
                  <Skeleton className="h-20 rounded-2xl" />
                ) : (
                  selected.messages.map((m) => {
                    const isAdmin = m.author === 'ADMIN';
                    return (
                      <div key={m.id} className={cn('flex', isAdmin ? 'justify-end' : 'justify-start')}>
                        <div
                          className={cn(
                            'max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed',
                            isAdmin ? 'rounded-br-sm border border-[#e9c47c]/30 bg-[#e9c47c]/10 text-[#f5e7c8]' : 'rounded-bl-sm border border-white/10 bg-white/[0.05] text-white',
                          )}
                        >
                          <p className="mb-1 text-[10px] font-bold uppercase tracking-wide opacity-75">
                            {isAdmin ? `Support — ${m.authorName}` : `${m.authorName} (hôte)`}
                          </p>
                          <p className="whitespace-pre-wrap">{m.body}</p>
                          <p className="mt-1 text-right text-[10px] opacity-60">{fmt(m.createdAt)}</p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Réponse admin */}
              <div className="mt-4 border-t border-white/10 pt-3">
                <label htmlFor="admin-reply" className="text-xs font-semibold text-white">
                  Réponse de l&apos;équipe
                </label>
                <textarea
                  id="admin-reply"
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  rows={3}
                  maxLength={5000}
                  placeholder="Répondez à l'hôte… (visible immédiatement dans son dashboard)"
                  className="mt-1.5 w-full rounded-lg border border-white/10 bg-white/[0.05] px-3 py-2 text-sm text-white outline-none placeholder:text-white/30 focus:border-[#e9c47c]/50"
                />
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap gap-1.5">
                    {selected.status !== 'RESOLVED' ? (
                      <button
                        type="button"
                        onClick={() => {
                          void setTicketStatus(selected.id, 'RESOLVED');
                        }}
                        className="min-h-[34px] rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-2.5 text-[11px] font-bold text-emerald-300 transition-colors hover:bg-emerald-400/20"
                      >
                        Marquer résolu
                      </button>
                    ) : null}
                    {selected.status !== 'CLOSED' ? (
                      <button
                        type="button"
                        onClick={() => {
                          void setTicketStatus(selected.id, 'CLOSED');
                        }}
                        className="min-h-[34px] rounded-lg border border-white/15 px-2.5 text-[11px] font-bold text-white/70 transition-colors hover:bg-white/5"
                      >
                        Fermer le ticket
                      </button>
                    ) : null}
                  </div>
                  <Button
                    type="button"
                    disabled={sending}
                    onClick={() => {
                      void sendReply();
                    }}
                    className="h-10 rounded-lg bg-[#e9c47c] px-4 text-sm font-bold text-[#1a1206] hover:bg-[#f0d393]"
                  >
                    <Send className="mr-1.5 h-4 w-4" /> {sending ? 'Envoi…' : 'Répondre'}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex min-h-[240px] items-center justify-center rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-[#8fa0c2]">
              Sélectionnez un ticket pour lire le fil et répondre à l&apos;hôte.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
