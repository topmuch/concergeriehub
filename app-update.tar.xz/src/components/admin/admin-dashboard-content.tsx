'use client';

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from 'recharts';
import {
  type ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { formatEur } from '@/lib/b2b';

// =============================================================
// AdminDashboardContent — v7.0 « BLEU AZUR » : Dashboard Superadmin.
// Refonte design PROFONDE (demande client) : tuiles KPI en dégradés
// colorés à grande valeur blanche + vague décorative, graphique aires
// violet dégradé, donuts à gros chiffre, tableaux en-tête violet clair
// · fond lavande clair identique en clair et en sombre.
//  - Les 6 KPI opérationnels plateforme (bloc lux de /api/admin/kpis)
//    en cartes « joyaux » multicolores : minibar, séjour & compte à
//    rebours, calendrier, ménage, départs tardifs, avis
//  - KPIs plateforme conservés (Utilisateurs, Hôtes actifs,
//    Propriétés, MRR + GMV, commission, plaques, prestataires,
//    séjours, commandes 30 j) — mêmes définitions métier
//  - 3 graphiques + GMV par catégorie + top prestataires conservés
//  - « Santé plateforme » + « Transactions récentes » + « Dernières
//    inscriptions » + « Règle d'or » conservés — redesignés uniquement.
// Source : /api/admin/kpis (définitions métier inchangées).
// =============================================================

// ---------- Palette graphique (violet primaire / rose secondaire) ----------
const SAPPHIRE = '#7C6FF0';
const TEAL = '#F472B6';

/** Badge doux réutilisable (pastilles à point coloré). */
const CHIP_CLASS =
  'inline-flex items-center gap-1.5 rounded-full bg-slate-50 px-2.5 py-0.5 text-xs font-medium text-slate-600 ring-1 ring-slate-200';

const revenueConfig = {
  gmv: { label: 'GMV (achats invités)', color: SAPPHIRE },
  commission: { label: 'Commission plateforme', color: TEAL },
} satisfies ChartConfig;

const paymentConfig = {
  PAID: { label: 'Payées', color: '#10B981' },
  UNPAID: { label: 'Impayées', color: '#F59E0B' },
  REFUNDED: { label: 'Remboursées', color: '#5B8CFF' },
  FAILED: { label: 'Échecs', color: '#94A3B8' },
} satisfies ChartConfig;

const categoryConfig = {
  gmv: { label: 'GMV', color: '#5B8CFF' },
} satisfies ChartConfig;

const signupConfig = {
  count: { label: 'Inscriptions', color: SAPPHIRE },
} satisfies ChartConfig;

const planConfig = {
  airbnb_solo: { label: 'Solo', color: '#93B4FF' },
  airbnb_pro: { label: 'Pro', color: '#5B8CFF' },
  agency: { label: 'Agence', color: '#F59E0B' },
  free: { label: 'Free', color: '#94A3B8' },
} satisfies ChartConfig;

interface KpisData {
  stats: {
    totalHosts: number;
    activeHosts: number;
    newHosts30d: number;
    propertiesCount: number;
    activePropertiesCount: number;
    providersTotal: number;
    providersActive: number;
    providersOwner: number;
    providersGuest: number;
    bookingsActive: number;
    bookingsUpcoming: number;
    subscriptionsActive: number;
    mrrEur: number;
    gmvPaidEur: number;
    platformRevenueEur: number;
    hostEarningsEur: number;
    ordersTotal: number;
    ordersPaid: number;
    ordersUnpaid: number;
    ordersRefunded: number;
    ordersFailed: number;
    orders30d: number;
    gmv30dEur: number;
    avgOrderEur: number;
    scansTotal: number;
    plaquesTotal: number;
    plaquesActive: number;
    plaquesInactive: number;
    plaquesLost: number;
  };
  series: { date: string; gmv: number; commission: number }[];
  hostSignupTrend: { date: string; count: number }[];
  planDistribution: { plan: string; count: number }[];
  paymentDistribution: { key: string; count: number }[];
  categoryRevenue: { category: string; label: string; gmv: number; orders: number }[];
  providerRevenue: { name: string; gmv: number; orders: number }[];
  recentOrders: {
    id: string;
    guestName: string;
    providerName: string;
    providerCategory: string | null;
    itemName: string;
    totalAmount: number;
    commission: number;
    status: string;
    paymentStatus: string;
    createdAt: string;
    paidAt: string | null;
  }[];
  recentHosts: {
    id: string;
    fullName: string | null;
    email: string;
    selectedPlan: string | null;
    isActive: boolean;
    createdAt: string;
    propertyCount: number;
  }[];
  recentActivity: {
    id: string;
    actionType: string;
    createdAt: string;
    propertyName: string | null;
    userName: string | null;
    module: string | null;
  }[];
  recentActivations: {
    id: string;
    activationCode: string;
    hubSlug: string | null;
    userName: string | null;
    createdAt: string;
  }[];
  lux?: LuxBlock;
}

// ---------- Bloc « lux » : les 6 KPI opérationnels plateforme ----------
interface LuxBlock {
  minibar: { itemsMonth: number; revenueMonth: number; itemsTotal: number; revenueTotal: number; ordersTotal: number };
  stay: { kind: 'active' | 'upcoming'; guestName: string; propertyName: string; checkIn: string; checkOut: string } | null;
  calendar: { inProgress: number; upcoming: number };
  housekeeping: { done: number; scheduled: number };
  lateCheckouts: { upcoming: number; next: { guestName: string; propertyName: string; until: string | null } | null };
  reviews: { positive: number; neutral: number; negative: number };
}

// ---------- « Santé plateforme » : incidents réels (/api/admin/notifications) ----------
interface HealthItem {
  kind: string;
  emoji: string;
  title: string;
  detail: string;
  href: string;
  at: string;
}

/** Pastille colorée par type d'incident (remplace les emojis). */
const HEALTH_KIND_DOT: Record<string, string> = {
  email_failed: '#F87171',
  order_unpaid: '#F59E0B',
  sub_past_due: '#A78BFA',
  plaque_lost: '#94A3B8',
};
const HEALTH_KIND_LABEL: Record<string, string> = {
  email_failed: 'Emails',
  order_unpaid: 'Commandes',
  sub_past_due: 'Abonnements',
  plaque_lost: 'Plaques',
};

// ---------- Libellés (pastilles typographiques, sans icône) ----------
const PAYMENT_META: Record<string, { label: string; dot: string }> = {
  PAID: { label: 'Payée', dot: '#10B981' },
  UNPAID: { label: 'Impayée', dot: '#F59E0B' },
  REFUNDED: { label: 'Remboursée', dot: '#5B8CFF' },
  FAILED: { label: 'Échec', dot: '#94A3B8' },
};

function planLabel(plan: string | null): string {
  switch (plan) {
    case 'airbnb_solo': return 'Solo';
    case 'airbnb_pro': return 'Pro';
    case 'agency': return 'Agence';
    default: return 'Free';
  }
}

/** Point coloré par type d'action du flux (remplace les emojis). */
const ACTION_DOT: Record<string, string> = {
  qr_created: '#5B8CFF',
  qr_updated: '#5B8CFF',
  wifi_updated: SAPPHIRE,
  guidebook_updated: '#F59E0B',
  scan: '#5B8CFF',
  voice_received: '#A78BFA',
  complaint: '#F87171',
  service_ordered: '#10B981',
  property_created: '#38BDF8',
  host_login: '#F59E0B',
};

function actionLabel(type: string): string {
  switch (type) {
    case 'qr_created': return 'QR code créé';
    case 'qr_updated': return 'QR code modifié';
    case 'wifi_updated': return 'Wi-Fi mis à jour';
    case 'guidebook_updated': return 'Guidebook mis à jour';
    case 'scan': return 'Scan de la plaque';
    case 'voice_received': return 'Message vocal reçu';
    case 'complaint': return 'Réclamation voyageur';
    case 'service_ordered': return 'Service commandé';
    case 'property_created': return 'Bien ajouté';
    case 'host_login': return 'Connexion hôte';
    default: return type;
  }
}

// ---------- Flux temps réel fusionné (activités + activations plaques) ----------
interface FeedItem {
  id: string;
  dot: string;
  label: string;
  who: string;
  detail: string | null;
  createdAt: string;
}

function buildFeed(data: KpisData): FeedItem[] {
  const activities: FeedItem[] = data.recentActivity.map((a) => ({
    id: a.id,
    dot: ACTION_DOT[a.actionType] ?? '#94A3B8',
    label: actionLabel(a.actionType),
    who: a.userName ?? 'Système',
    detail: a.propertyName,
    createdAt: a.createdAt,
  }));
  const activations: FeedItem[] = data.recentActivations.map((a) => ({
    id: a.id,
    dot: '#F59E0B',
    label: 'Plaque activée',
    who: a.userName ?? 'Système',
    detail: `${a.activationCode}${a.hubSlug ? ` · /${a.hubSlug}` : ''}`,
    createdAt: a.createdAt,
  }));
  return [...activities, ...activations]
    .sort((x, y) => (x.createdAt < y.createdAt ? 1 : -1))
    .slice(0, 12);
}

const fmtDay = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short' });
const fmtFullDate = new Intl.DateTimeFormat('fr-FR', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
});
const fmtDateTime = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
});
const fmtDayHour = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
});

function formatDay(iso: string): string {
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(
    new Date(iso),
  );
}

function metaOf<T>(map: Record<string, T>, key: string, fallback: T): T {
  return map[key] ?? fallback;
}

/** Compte à rebours lisible jusqu'à l'échéance (horloge locale). */
function countdownLabel(target: Date, now: Date): string {
  const ms = target.getTime() - now.getTime();
  if (ms <= 0) return 'Échéance atteinte';
  const min = Math.floor(ms / 60_000);
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} h ${String(min % 60).padStart(2, '0')}`;
  const j = Math.floor(h / 24);
  return `${j} j ${String(h % 24).padStart(2, '0')} h`;
}

// ---------- Actions rapides (routes console superadmin) ----------
const QUICK_ACTIONS: { href: string; label: string; dot: string }[] = [
  { href: '/admin/users', label: 'Clients', dot: '#2563EB' },
  { href: '/admin/qr', label: 'Générer des QR', dot: '#7C6FF0' },
  { href: '/admin/emails', label: 'Emails', dot: '#F472B6' },
  { href: '/admin/providers', label: 'Prestataires', dot: '#F97316' },
];

// ---------- Carte KPI « tuile dégradée » (grande valeur blanche + vague) ----------
const TILE_TONES: Record<
  'gold' | 'sapphire' | 'violet' | 'emerald' | 'coral' | 'rose',
  string
> = {
  gold: 'bg-[linear-gradient(160deg,#FF9A62,#F97316)]',
  sapphire: 'bg-[linear-gradient(160deg,#5B8CFF,#2E5BFF)]',
  violet: 'bg-[linear-gradient(160deg,#C084FC,#7C3AED)]',
  emerald: 'bg-[linear-gradient(160deg,#34D399,#059669)]',
  coral: 'bg-[linear-gradient(160deg,#FF6B7E,#E11D48)]',
  rose: 'bg-[linear-gradient(160deg,#F472B6,#DB2777)]',
};

function LuxKpiCard({
  tone,
  label,
  value,
  chip,
  hint,
  loading,
  index = 0,
  children,
}: {
  tone: 'gold' | 'sapphire' | 'violet' | 'emerald' | 'coral' | 'rose';
  label: string;
  value: string;
  chip?: string;
  hint?: string;
  loading?: boolean;
  index?: number;
  children?: ReactNode;
}) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.35, ease: 'easeOut' }}
      className={cn(
        'relative overflow-hidden rounded-2xl p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.25)]',
        TILE_TONES[tone],
      )}
      aria-label={label}
    >
      {/* Vague décorative (spéc client) */}
      <svg
        viewBox="0 0 220 60"
        preserveAspectRatio="none"
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 h-12 w-full"
      >
        <path d="M0 60 C 40 20, 80 55, 120 35 S 190 10, 220 30 L 220 60 Z" fill="#ffffff" opacity="0.18" />
      </svg>
      <div className="relative flex items-center justify-between gap-2">
        <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-white/85">{label}</span>
        {chip && !loading && (
          <span className="rounded-full bg-white/20 px-2.5 py-0.5 text-[10px] font-bold text-white ring-1 ring-white/30">
            {chip}
          </span>
        )}
      </div>
      {loading ? (
        <div className="mt-3 h-9 w-28 animate-pulse rounded-lg bg-white/20" aria-hidden="true" />
      ) : (
        <p className="mt-2.5 truncate text-3xl font-bold leading-none text-white sm:text-4xl">{value}</p>
      )}
      {children}
      {hint && !loading && (
        <p className="relative mt-2.5 truncate text-[12px] leading-snug text-white/85">{hint}</p>
      )}
    </motion.article>
  );
}

/** Carte statistique typographique (KPIs plateforme — sobre, sans icône). */
function LuxStat({
  label,
  value,
  chip,
  hint,
  dot = SAPPHIRE,
  index = 0,
}: {
  label: string;
  value: ReactNode;
  chip?: string;
  hint?: string;
  dot?: string;
  index?: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.03 * index, duration: 0.3, ease: 'easeOut' }}
      className="relative rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-5"
    >
      <div className="flex items-start justify-between gap-2">
        <span className="text-[11px] font-bold uppercase tracking-[0.14em] text-slate-400">{label}</span>
        {chip && <span className={cn(CHIP_CLASS, '!px-2 !py-0.5 !text-[10px]')}>{chip}</span>}
      </div>
      <p className="mt-2 truncate text-3xl font-bold leading-none text-slate-800">{value}</p>
      {hint && <p className="mt-2 truncate text-[11.5px] text-slate-400">{hint}</p>}
      <span
        className="absolute right-4 top-4 h-2 w-2 rounded-full opacity-80"
        style={{ backgroundColor: dot }}
        aria-hidden="true"
      />
    </motion.div>
  );
}

function LuxSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-slate-200/70', className)} />;
}

// ---------- Composant principal ----------
export function AdminDashboardContent() {
  const [data, setData] = useState<KpisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [today, setToday] = useState('');
  // « Santé plateforme » — incidents réels agrégés
  const [health, setHealth] = useState<HealthItem[] | null>(null);
  const [healthState, setHealthState] = useState<'loading' | 'ok' | 'error'>('loading');
  // Horloge locale pour le compte à rebours du séjour (anti-hydratation)
  const [tick, setTick] = useState<Date | null>(null);

  useEffect(() => {
    // Après montage uniquement (évite tout écart d'hydratation)
    setToday(fmtFullDate.format(new Date()));
    setTick(new Date());
    const id = setInterval(() => setTick(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/kpis');
      if (!res.ok) throw new Error('http');
      setData((await res.json()) as KpisData);
    } catch {
      setError('Impossible de charger les statistiques. Réessayez.');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadHealth = useCallback(async () => {
    setHealthState('loading');
    try {
      const res = await fetch('/api/admin/notifications', { cache: 'no-store' });
      if (!res.ok) throw new Error('http');
      const json = (await res.json()) as { count: number; items: HealthItem[] };
      setHealth(Array.isArray(json.items) ? json.items : []);
      setHealthState('ok');
    } catch {
      setHealthState('error');
    }
  }, []);

  useEffect(() => {
    load();
    loadHealth();
  }, [load, loadHealth]);

  function refreshAll() {
    load();
    loadHealth();
    toast.success('Statistiques actualisées');
  }

  // ----- Loading -----
  if (loading && !data) {
    return (
      <div className="min-h-full bg-[#E4E9F7] p-4 pb-10 text-slate-800 sm:p-6">
        <div className="mx-auto w-full max-w-7xl space-y-6" aria-busy="true" aria-label="Chargement">
          <LuxSkeleton className="h-40 w-full rounded-3xl" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <LuxSkeleton key={i} className="h-40 rounded-2xl" />
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <LuxSkeleton key={i} className="h-32 rounded-2xl" />
            ))}
          </div>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <LuxSkeleton className="h-80 rounded-2xl lg:col-span-2" />
            <LuxSkeleton className="h-80 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  // ----- Erreur -----
  if (error || !data) {
    return (
      <div className="min-h-full bg-[#E4E9F7] p-4 pb-10 text-slate-800 sm:p-6">
        <div className="mx-auto flex w-full max-w-7xl justify-center px-0 py-16">
          <div
            className="w-full max-w-md rounded-2xl border border-slate-100 bg-white p-8 text-center shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]"
            role="alert"
          >
            <span className="mx-auto block h-2.5 w-2.5 rounded-full bg-red-400" aria-hidden="true" />
            <p className="mt-3 text-xl font-bold text-slate-800">Erreur de chargement</p>
            <p className="mt-1 text-sm text-slate-400">{error || 'Données indisponibles'}</p>
            <button
              type="button"
              onClick={load}
              className="mt-5 rounded-xl px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition hover:brightness-110"
              style={{ backgroundImage: 'linear-gradient(135deg,#4A8BFF,#2563EB)' }}
            >
              Réessayer
            </button>
          </div>
        </div>
      </div>
    );
  }

  const { stats, series, paymentDistribution, categoryRevenue, providerRevenue } = data;
  const lux = data.lux ?? null;
  const refundRate =
    stats.ordersPaid + stats.ordersRefunded > 0
      ? Math.round((stats.ordersRefunded / (stats.ordersPaid + stats.ordersRefunded)) * 100)
      : 0;
  const maxProviderGmv = Math.max(...providerRevenue.map((p) => p.gmv), 1);
  const totalOrdersForDonut = paymentDistribution.reduce((acc, d) => acc + d.count, 0);
  const feed = buildFeed(data);
  const activeHostsPct = stats.totalHosts > 0 ? Math.round((stats.activeHosts / stats.totalHosts) * 100) : 0;
  const totalLuxReviews = lux ? lux.reviews.positive + lux.reviews.neutral + lux.reviews.negative : 0;

  // Séjour + compte à rebours (KPI 2 plateforme)
  const stayCard = lux?.stay
    ? (() => {
        const s = lux.stay;
        const isActive = s.kind === 'active';
        const target = isActive ? new Date(s.checkOut) : new Date(s.checkIn);
        const cd = tick ? countdownLabel(target, tick) : null;
        return {
          chip: cd ? (isActive ? `Départ dans ${cd}` : `Entrée dans ${cd}`) : undefined,
          hint: `${isActive ? 'Séjour en cours' : 'Prochain séjour'} — ${s.guestName} · ${s.propertyName}`,
        };
      })()
    : null;

  return (
    <div className="min-h-full bg-[#E4E9F7] p-4 pb-10 text-slate-800 sm:p-6">
      <div className="mx-auto w-full max-w-7xl space-y-7">
        {/* ================= Hero « BLEU AZUR » (v7.0) ================= */}
        <motion.section
          aria-labelledby="admin-greeting"
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="rounded-3xl border border-slate-100 bg-white p-6 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-8"
        >
          <div className="relative flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600" suppressHydrationWarning>
                Console superadmin
              </p>
              <h2 id="admin-greeting" className="mt-2 text-3xl font-bold tracking-tight text-slate-800 sm:text-[38px]">
                Vue d&apos;ensemble
              </h2>
              <p className="mt-2 text-sm text-slate-400" suppressHydrationWarning>
                Santé de la plateforme RoomScan{today ? ` — ${today}` : ''}.
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-3" aria-hidden="true">
              <div className="hidden h-10 w-10 items-center justify-center rounded-2xl bg-blue-50 text-lg font-bold text-blue-600 sm:flex">
                R
              </div>
            </div>
          </div>
          <div className="relative mt-5 flex flex-wrap items-center gap-2.5">
            <span className={CHIP_CLASS}>
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#10B981' }} aria-hidden="true" />
              {stats.ordersPaid} commande{stats.ordersPaid > 1 ? 's' : ''} payée{stats.ordersPaid > 1 ? 's' : ''}
            </span>
            <span className={CHIP_CLASS}>
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#5B8CFF' }} aria-hidden="true" />
              {stats.activeHosts} hôte{stats.activeHosts > 1 ? 's' : ''} actif{stats.activeHosts > 1 ? 's' : ''}
            </span>
            <span className={CHIP_CLASS}>
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#7C6FF0' }} aria-hidden="true" />
              {stats.activePropertiesCount} bien{stats.activePropertiesCount > 1 ? 's' : ''} actif
              {stats.activePropertiesCount > 1 ? 's' : ''}
            </span>
            <button
              type="button"
              onClick={refreshAll}
              className="ml-auto inline-flex h-9 items-center rounded-xl border border-slate-200 bg-white px-4 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50"
            >
              Actualiser
            </button>
          </div>
        </motion.section>

        {/* ================= LES 6 KPI opérationnels — fonds colorés ================= */}
        <section aria-label="Indicateurs opérationnels" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {/* KPI 1 · MINIBAR */}
          <LuxKpiCard
            index={0}
            tone="gold"
            label="Minibar"
            loading={loading}
            value={lux ? formatEur(lux.minibar.revenueMonth) : '—'}
            chip={lux && lux.minibar.revenueTotal > 0 ? `Total ${formatEur(lux.minibar.revenueTotal)}` : undefined}
            hint={
              lux
                ? `${lux.minibar.itemsMonth} produit${lux.minibar.itemsMonth > 1 ? 's' : ''} consommé${lux.minibar.itemsMonth > 1 ? 's' : ''} ce mois · ${lux.minibar.ordersTotal} commande${lux.minibar.ordersTotal > 1 ? 's' : ''} au total`
                : undefined
            }
          />

          {/* KPI 2 · CHECK-IN / CHECK-OUT + compte à rebours */}
          <LuxKpiCard
            index={1}
            tone="sapphire"
            label="Check-in — Check-out"
            loading={loading}
            value={stayCard ? 'Séjour' : '—'}
            chip={stayCard?.chip}
            hint={stayCard?.hint ?? 'Aucun séjour programmé sur la plateforme'}
          >
            {lux?.stay && (
              <div className="relative mt-3 grid grid-cols-2 gap-2 text-[12px] leading-tight">
                <div className="rounded-lg border border-white/25 bg-white/15 px-2.5 py-2">
                  <p className="text-[9px] font-bold uppercase tracking-wide text-white/75">Entrée</p>
                  <p className="mt-0.5 font-semibold tabular-nums" suppressHydrationWarning>
                    {fmtDayHour.format(new Date(lux.stay.checkIn))}
                  </p>
                </div>
                <div className="rounded-lg border border-white/25 bg-white/15 px-2.5 py-2">
                  <p className="text-[9px] font-bold uppercase tracking-wide text-white/75">Départ</p>
                  <p className="mt-0.5 font-semibold tabular-nums" suppressHydrationWarning>
                    {fmtDayHour.format(new Date(lux.stay.checkOut))}
                  </p>
                </div>
              </div>
            )}
          </LuxKpiCard>

          {/* KPI 3 · CALENDRIER */}
          <LuxKpiCard
            index={2}
            tone="violet"
            label="Calendrier"
            loading={loading}
            value={lux ? `${lux.calendar.inProgress}` : '—'}
            chip={lux ? `${lux.calendar.upcoming} à venir` : undefined}
            hint="Clients en cours sur l'ensemble des biens"
          />

          {/* KPI 4 · MÉNAGE */}
          <LuxKpiCard
            index={3}
            tone="emerald"
            label="Ménage"
            loading={loading}
            value={lux ? `${lux.housekeeping.done}` : '—'}
            chip={lux ? `${lux.housekeeping.scheduled} programmé${lux.housekeeping.scheduled > 1 ? 's' : ''}` : undefined}
            hint="Rapports de ménage validés avec preuves — plateforme entière"
          />

          {/* KPI 5 · DÉPART TARDIF */}
          <LuxKpiCard
            index={4}
            tone="coral"
            label="Départ tardif"
            loading={loading}
            value={lux ? `${lux.lateCheckouts.upcoming}` : '—'}
            chip={lux && lux.lateCheckouts.upcoming > 0 ? 'à venir' : undefined}
            hint={
              lux?.lateCheckouts.next
                ? `Prochain : ${lux.lateCheckouts.next.guestName}${lux.lateCheckouts.next.until ? ` — jusqu'à ${fmtDayHour.format(new Date(lux.lateCheckouts.next.until))}` : ''}`
                : 'Aucun départ tardif programmé'
            }
          />

          {/* KPI 6 · AVIS */}
          <LuxKpiCard
            index={5}
            tone="rose"
            label="Avis"
            loading={loading}
            value={lux ? `${lux.reviews.positive}` : '—'}
            chip={lux ? `${lux.reviews.negative} négatif${lux.reviews.negative > 1 ? 's' : ''}` : undefined}
            hint={
              lux && totalLuxReviews > 0
                ? `Avis positifs · ${lux.reviews.neutral} neutre${lux.reviews.neutral > 1 ? 's' : ''} sur ${totalLuxReviews} au total`
                : 'Les retours des voyageurs apparaîtront ici'
            }
          />
        </section>

        {/* ================= Actions rapides ================= */}
        <section aria-label="Actions rapides" className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {QUICK_ACTIONS.map((action, i) => (
            <motion.div
              key={action.href}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.25 }}
            >
              <Link
                href={action.href}
                className="group flex items-center gap-3 rounded-2xl border border-slate-100 bg-white p-4 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] transition hover:-translate-y-0.5 hover:shadow-[0_14px_40px_-12px_rgba(37,99,235,0.28)]"
              >
                <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: action.dot }} aria-hidden="true" />
                <span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-700">{action.label}</span>
                <span aria-hidden="true" className="shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5">
                  →
                </span>
              </Link>
            </motion.div>
          ))}
        </section>

        {/* ================= KPIs plateforme (définitions métier inchangées) ================= */}
        <section aria-label="Indicateurs plateforme" className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <LuxStat
            index={0}
            label="Utilisateurs totaux"
            value={String(stats.totalHosts)}
            chip={stats.newHosts30d > 0 ? `+${stats.newHosts30d} sur 30 j` : '0 sur 30 j'}
            hint="Comptes hôtes inscrits sur la plateforme"
          />
          <LuxStat
            index={1}
            label="Hôtes actifs"
            value={String(stats.activeHosts)}
            chip={`${activeHostsPct} % du total`}
            hint="Comptes hôtes actuellement actifs"
            dot="#10B981"
          />
          <LuxStat
            index={2}
            label="Propriétés"
            value={<>{stats.activePropertiesCount} <span className="text-lg text-slate-400">/ {stats.propertiesCount}</span></>}
            hint="Biens actifs équipés d'une plaque QR"
            dot="#7C6FF0"
          />
          <LuxStat
            index={3}
            label="MRR estimé"
            value={formatEur(stats.mrrEur)}
            chip={
              stats.subscriptionsActive > 0
                ? `${stats.subscriptionsActive} abonnement${stats.subscriptionsActive > 1 ? 's' : ''} actif${stats.subscriptionsActive > 1 ? 's' : ''}`
                : 'Aucun abonnement'
            }
            hint="Revenu mensuel récurrent normalisé"
            dot="#F59E0B"
          />
        </section>

        <section aria-label="Indicateurs opérationnels secondaires" className="grid grid-cols-2 gap-4 lg:grid-cols-3">
          <LuxStat
            index={0}
            label="GMV encaissée"
            value={formatEur(stats.gmvPaidEur)}
            chip={`${formatEur(stats.gmv30dEur)} sur 30 j`}
            hint={`${stats.ordersPaid} commande${stats.ordersPaid > 1 ? 's' : ''} payée${stats.ordersPaid > 1 ? 's' : ''} · panier moyen ${formatEur(stats.avgOrderEur)}`}
          />
          <LuxStat
            index={1}
            label="Revenus plateforme"
            value={formatEur(stats.platformRevenueEur)}
            chip="Commission 15 %"
            hint={`Part reversée aux hôtes : ${formatEur(stats.hostEarningsEur)}`}
            dot="#10B981"
          />
          <LuxStat
            index={2}
            label="Plaques activées"
            value={<>{stats.plaquesActive} <span className="text-lg text-slate-400">/ {stats.plaquesTotal}</span></>}
            hint={`${stats.plaquesInactive} inactive${stats.plaquesInactive > 1 ? 's' : ''} · ${stats.plaquesLost} perdue${stats.plaquesLost > 1 ? 's' : ''}`}
            dot="#F59E0B"
          />
          <LuxStat
            index={3}
            label="Prestataires actifs"
            value={<>{stats.providersActive} <span className="text-lg text-slate-400">/ {stats.providersTotal}</span></>}
            hint={`${stats.providersOwner} owner · ${stats.providersGuest} guest`}
            dot="#5eead4"
          />
          <LuxStat
            index={4}
            label="Séjours en cours"
            value={<>{stats.bookingsActive} <span className="text-lg text-slate-400">+ {stats.bookingsUpcoming} à venir</span></>}
            hint="Check-ins en cours et confirmés"
            dot={SAPPHIRE}
          />
          <LuxStat
            index={5}
            label="Commandes 30 j"
            value={<>{stats.orders30d} <span className="text-lg text-slate-400">/ {stats.ordersTotal}</span></>}
            hint={`${stats.ordersRefunded} remboursée${stats.ordersRefunded > 1 ? 's' : ''} (${refundRate} %)`}
            dot="#94A3B8"
          />
        </section>

        {/* ================= Graphiques ================= */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* ----- Tendance 30 j : GMV + commission ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6 lg:col-span-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Finance</p>
                <p className="mt-1 text-lg font-bold text-slate-800">Revenus des 30 derniers jours</p>
                <p className="mt-0.5 text-xs text-slate-400">
                  Volume acheté par les invités (GMV) et commission retenue par la plateforme
                </p>
              </div>
            </div>
            <ChartContainer config={revenueConfig} className="mt-4 h-72 w-full">
              <ComposedChart data={series} margin={{ left: 4, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="fillGmvAzur" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-gmv)" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="var(--color-gmv)" stopOpacity={0.04} />
                  </linearGradient>
                  <linearGradient id="fillCommissionAzur" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-commission)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="var(--color-commission)" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={{ stroke: '#E2E8F0' }}
                  tickMargin={8}
                  minTickGap={28}
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                  tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  width={44}
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                  tickFormatter={(v: number) => `${Math.round(v)}€`}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      labelFormatter={(_p, payload) => {
                        const raw = payload?.[0]?.payload as { date?: string } | undefined;
                        return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                      }}
                    />
                  }
                />
                <Area
                  dataKey="gmv"
                  type="monotone"
                  stroke="var(--color-gmv)"
                  strokeWidth={2.5}
                  fill="url(#fillGmvAzur)"
                  dot={false}
                />
                <Area
                  dataKey="commission"
                  type="monotone"
                  stroke="var(--color-commission)"
                  strokeWidth={2}
                  fill="url(#fillCommissionAzur)"
                  dot={false}
                />
              </ComposedChart>
            </ChartContainer>
          </div>

          {/* ----- Donut statuts de paiement ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Paiements</p>
            <p className="mt-1 text-lg font-bold text-slate-800">Statuts de paiement</p>
            <p className="mt-0.5 text-xs text-slate-400">Répartition des {totalOrdersForDonut} commandes</p>
            <div className="relative mt-4">
              <ChartContainer config={paymentConfig} className="h-56 w-full">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                  <Pie
                    data={paymentDistribution}
                    dataKey="count"
                    nameKey="key"
                    innerRadius={58}
                    outerRadius={88}
                    strokeWidth={3}
                    paddingAngle={2}
                  >
                    {paymentDistribution.map((entry) => (
                      <Cell key={entry.key} fill={`var(--color-${entry.key})`} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-3xl font-bold text-slate-800">{totalOrdersForDonut}</p>
                  <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-400">commandes</p>
                </div>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {paymentDistribution.map((d) => {
                const meta = metaOf(PAYMENT_META, d.key, { label: d.key, dot: '#94A3B8' });
                if (d.count === 0) return null;
                return (
                  <span key={d.key} className={CHIP_CLASS}>
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: meta.dot }} aria-hidden="true" />
                    {meta.label} : {d.count}
                  </span>
                );
              })}
            </div>
          </div>
        </section>

        {/* ================= Croissance & abonnements ================= */}
        <section aria-label="Croissance et abonnements" className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* ----- Courbe d'inscriptions hôtes 30 j ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Croissance</p>
                <p className="mt-1 text-lg font-bold text-slate-800">Inscriptions des hôtes</p>
                <p className="mt-0.5 text-xs text-slate-400">Nouveaux comptes créés sur les 30 derniers jours</p>
              </div>
            <span className={CHIP_CLASS}>
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: '#10B981' }} aria-hidden="true" />
                +{stats.newHosts30d} sur 30 j
            </span>
            </div>
            <ChartContainer config={signupConfig} className="mt-4 h-64 w-full">
              <AreaChart data={data.hostSignupTrend} margin={{ left: 4, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="fillSignupsLux" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-count)" stopOpacity={0.45} />
                    <stop offset="95%" stopColor="var(--color-count)" stopOpacity={0.04} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#E2E8F0" />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={{ stroke: '#E2E8F0' }}
                  tickMargin={8}
                  minTickGap={28}
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                  tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  width={32}
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: '#94A3B8' }}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      labelFormatter={(_p, payload) => {
                        const raw = payload?.[0]?.payload as { date?: string } | undefined;
                        return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                      }}
                    />
                  }
                />
                <Area
                  dataKey="count"
                  type="monotone"
                  stroke="var(--color-count)"
                  strokeWidth={2}
                  fill="url(#fillSignupsLux)"
                  dot={false}
                />
              </AreaChart>
            </ChartContainer>
          </div>

          {/* ----- Répartition des abonnements (Solo vs Pro) ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Abonnements</p>
            <p className="mt-1 text-lg font-bold text-slate-800">Répartition des abonnements</p>
            <p className="mt-0.5 text-xs text-slate-400">Comptes hôtes par plan sélectionné</p>
            {data.planDistribution.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-10 text-center">
                <p className="text-sm text-slate-400">Aucun hôte inscrit pour le moment.</p>
              </div>
            ) : (
              <>
                <div className="relative mt-4">
                  <ChartContainer config={planConfig} className="h-56 w-full">
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="plan" />} />
                      <Pie
                        data={data.planDistribution}
                        dataKey="count"
                        nameKey="plan"
                        innerRadius={58}
                        outerRadius={88}
                        strokeWidth={3}
                        paddingAngle={2}
                      >
                        {data.planDistribution.map((entry) => (
                          <Cell key={entry.plan} fill={`var(--color-${entry.plan})`} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ChartContainer>
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-3xl font-bold text-slate-800">{stats.totalHosts}</p>
                      <p className="mt-0.5 text-[10px] font-semibold uppercase tracking-wide text-slate-400">hôtes</p>
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {data.planDistribution.map((p) => (
                    <span key={p.plan} className={CHIP_CLASS}>
                      {planLabel(p.plan === 'airbnb_solo' || p.plan === 'airbnb_pro' || p.plan === 'agency' ? p.plan : 'free')} : {p.count}
                    </span>
                  ))}
                </div>
              </>
            )}
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* ----- GMV par catégorie ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Prestations</p>
            <p className="mt-1 text-lg font-bold text-slate-800">GMV par catégorie</p>
            <p className="mt-0.5 text-xs text-slate-400">Chiffre d&apos;affaires invités par type de prestation</p>
            {categoryRevenue.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-10 text-center">
                <p className="text-sm text-slate-400">Aucune commande payée pour le moment.</p>
              </div>
            ) : (
              <ChartContainer config={categoryConfig} className="mt-4 h-64 w-full">
                <BarChart layout="vertical" data={categoryRevenue} margin={{ left: 8, right: 16, top: 4 }}>
                  <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="#E2E8F0" />
                  <XAxis
                    type="number"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#94A3B8' }}
                    tickFormatter={(v: number) => `${Math.round(v)}€`}
                  />
                  <YAxis
                    type="category"
                    dataKey="label"
                    width={150}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#94A3B8' }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="gmv" fill="var(--color-gmv)" radius={[0, 6, 6, 0]} maxBarSize={22} />
                </BarChart>
              </ChartContainer>
            )}
          </div>

          {/* ----- Top prestataires ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Classement</p>
            <p className="mt-1 text-lg font-bold text-slate-800">Top prestataires</p>
            <p className="mt-0.5 text-xs text-slate-400">Classement par GMV encaissée (commandes payées)</p>
            {providerRevenue.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-10 text-center">
                <p className="text-sm text-slate-400">Aucune commande payée pour le moment.</p>
              </div>
            ) : (
              <ul className="mt-4 space-y-3.5">
                {providerRevenue.map((p, i) => (
                  <li key={p.name} className="group">
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <span className="flex min-w-0 items-center gap-2.5 font-semibold text-slate-800">
                        <span
                          aria-hidden="true"
                          className={cn(
                            'flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold',
                            i === 0
                              ? 'bg-amber-400 text-white shadow-sm'
                              : 'bg-slate-100 text-slate-500 ring-1 ring-slate-200',
                          )}
                        >
                          {i + 1}
                        </span>
                        <span className="truncate">{p.name}</span>
                      </span>
                      <span className="shrink-0 text-right">
                        <span className="font-bold text-slate-800">{formatEur(p.gmv)}</span>
                        <span className="ml-1.5 text-[11px] text-slate-400">{p.orders} cmd</span>
                      </span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#5B8CFF] to-[#7C6FF0]"
                        style={{ width: `${Math.max((p.gmv / maxProviderGmv) * 100, 6)}%` }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Transactions récentes + activité ================= */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* ----- Transactions récentes ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6 lg:col-span-2">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Finance</p>
            <p className="mt-1 text-lg font-bold text-slate-800">Transactions récentes</p>
            <p className="mt-0.5 text-xs text-slate-400">Les 8 dernières transactions passées depuis les QR Hubs</p>
            {data.recentOrders.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-10 text-center">
                <p className="text-sm text-slate-400">Aucune commande pour le moment.</p>
              </div>
            ) : (
              <div className="mt-4 max-h-96 overflow-x-auto overflow-y-auto rounded-2xl border border-slate-100">
                <Table>
                  <TableHeader className="sticky top-0 z-10 rounded-lg bg-[#EEF0FF]">
                    <TableRow className="border-slate-100 hover:bg-transparent">
                      <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Invité</TableHead>
                      <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Prestation</TableHead>
                      <TableHead className="text-right text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Montant</TableHead>
                      <TableHead className="text-right text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Commission</TableHead>
                      <TableHead className="text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Paiement</TableHead>
                      <TableHead className="text-right text-[11px] font-semibold uppercase tracking-wide text-[#1E3A8A]">Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody className="bg-white">
                    {data.recentOrders.map((o) => {
                      const pay = metaOf(PAYMENT_META, o.paymentStatus, { label: o.paymentStatus, dot: '#94A3B8' });
                      return (
                        <TableRow key={o.id} className="border-slate-100 hover:bg-[#F8FAFF]">
                          <TableCell className="whitespace-nowrap font-semibold text-slate-800">
                            {o.guestName}
                          </TableCell>
                          <TableCell className="max-w-[180px]">
                            <p className="truncate text-slate-800">{o.itemName}</p>
                            <p className="truncate text-[11px] text-slate-400">{o.providerName}</p>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right font-semibold tabular-nums text-slate-800">
                            {formatEur(o.totalAmount)}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right font-semibold tabular-nums text-emerald-600">
                            {formatEur(o.commission)}
                          </TableCell>
                          <TableCell>
                            <span className={CHIP_CLASS}>
                              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: pay.dot }} aria-hidden="true" />
                              {pay.label}
                            </span>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right text-[11px] text-slate-400">
                            {fmtDateTime.format(new Date(o.createdAt))}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>

          {/* ----- Flux temps réel fusionné ----- */}
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Temps réel</p>
            <p className="mt-1 text-lg font-bold text-slate-800">Dernières activités</p>
            <p className="mt-0.5 text-xs text-slate-400">Activations de plaques, scans &amp; actions hôtes</p>
            {feed.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-10 text-center">
                <p className="text-sm text-slate-400">Aucune activité enregistrée pour le moment.</p>
              </div>
            ) : (
              <ul className="-mx-2 mt-2 max-h-96 divide-y divide-slate-100 overflow-y-auto">
                {feed.map((a) => (
                  <li key={a.id} className="flex items-start gap-3 rounded-lg px-2 py-3 transition-colors hover:bg-[#F8FAFF]">
                    <span className="mt-2 h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: a.dot }} aria-hidden="true" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-800">{a.label}</p>
                      <p className="truncate text-xs text-slate-400">
                        {a.who}
                        {a.detail ? ` · ${a.detail}` : ''}
                      </p>
                    </div>
                    <span className="shrink-0 text-[11px] text-slate-400">
                      {fmtDateTime.format(new Date(a.createdAt))}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Santé plateforme (real data /api/admin/notifications) ================= */}
        <section aria-label="Santé plateforme">
          <div className="rounded-2xl border border-slate-100 bg-white p-5 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Monitoring</p>
                <p className="mt-1 text-lg font-bold text-slate-800">Santé plateforme</p>
                <p className="mt-0.5 text-xs text-slate-400">
                  Incidents réels détectés : emails en échec, commandes impayées &gt; 48 h, abonnements en impayé,
                  plaques perdues
                </p>
              </div>
              {healthState === 'ok' && health && (
                <span className={CHIP_CLASS}>
                  <span
                    className={cn('h-2 w-2 rounded-full', health.length > 0 && 'animate-pulse')}
                    style={{ backgroundColor: health.length === 0 ? '#10B981' : '#F59E0B' }}
                    aria-hidden="true"
                  />
                  {health.length === 0 ? 'Tout est opérationnel' : `${health.length} point${health.length > 1 ? 's' : ''} d'attention`}
                </span>
              )}
            </div>

            {healthState === 'loading' ? (
              <div className="mt-4 flex flex-col gap-2">
                {Array.from({ length: 2 }).map((_, i) => (
                  <LuxSkeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : healthState === 'error' ? (
              <p className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-6 text-center text-sm text-slate-400">
                Monitoring momentanément indisponible.
              </p>
            ) : !health || health.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-8 text-center">
                <p className="text-lg font-bold text-slate-800">Aucun incident — la plateforme est saine.</p>
                <p className="mt-1 text-xs text-slate-400">
                  Emails, paiements, abonnements et plaques : tout roule.
                </p>
              </div>
            ) : (
              <ul className="mt-4 divide-y divide-slate-100">
                {health.map((n, i) => {
                  const dot = HEALTH_KIND_DOT[n.kind] ?? '#94A3B8';
                  const label = HEALTH_KIND_LABEL[n.kind] ?? n.kind;
                  return (
                    <li key={`${n.kind}-${i}`}>
                      <Link
                        href={n.href}
                        className="-mx-2 flex items-start gap-3 rounded-xl px-2 py-3 transition-colors hover:bg-[#F8FAFF]"
                      >
                        <span className="mt-2 h-2 w-2 shrink-0 rounded-full" style={{ backgroundColor: dot }} aria-hidden="true" />
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-semibold text-slate-800">{n.title}</span>
                          <span className="block truncate text-xs text-slate-400">{n.detail}</span>
                        </span>
                        <span className="flex shrink-0 flex-col items-end gap-1">
                          <span className={CHIP_CLASS}>{label}</span>
                          <span className="text-[11px] text-slate-400">{fmtDateTime.format(new Date(n.at))}</span>
                        </span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Dernières inscriptions ================= */}
        <section aria-label="Dernières inscriptions">
          <div className="overflow-hidden rounded-2xl border border-slate-100 bg-white p-0 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)]">
            <div className="px-5 pb-3 pt-5 sm:px-6">
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-blue-600">Croissance</p>
              <p className="mt-1 text-lg font-bold text-slate-800">Dernières inscriptions</p>
              <p className="mt-0.5 text-xs text-slate-400">Les 6 comptes hôtes les plus récents</p>
            </div>
            {data.recentHosts.length === 0 ? (
              <div className="mx-5 mb-5 rounded-2xl border border-dashed border-slate-200 bg-slate-50/60 px-4 py-8 text-center sm:mx-6">
                <p className="text-sm text-slate-400">Aucun hôte inscrit pour le moment.</p>
              </div>
            ) : (
              <ul className="max-h-96 divide-y divide-slate-100 overflow-y-auto">
                {data.recentHosts.map((h) => (
                  <li key={h.id} className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-[#F8FAFF] sm:px-6">
                    <span
                      aria-hidden="true"
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-50 text-xs font-bold text-blue-700 ring-1 ring-blue-200"
                    >
                      {(h.fullName ?? h.email).slice(0, 2).toUpperCase()}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold text-slate-800">
                        {h.fullName ?? 'Sans nom'}
                        {!h.isActive && (
                          <span className="ml-2 text-[11px] font-semibold text-red-500">
                            · désactivé
                          </span>
                        )}
                      </p>
                      <p className="truncate text-xs text-slate-400">{h.email}</p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1">
                      <span className={CHIP_CLASS}>{planLabel(h.selectedPlan)}</span>
                      <span className="text-[11px] text-slate-400">
                        {h.propertyCount} bien{h.propertyCount > 1 ? 's' : ''} · {formatDay(h.createdAt)}
                      </span>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Rappel règle d'or ================= */}
        <section aria-label="Règle de gestion des prestataires" className="pb-4">
          <div className="rounded-2xl border border-blue-200 bg-blue-50 p-5">
            <div className="flex items-start gap-3">
              <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-blue-600" aria-hidden="true" />
              <div>
                <p className="text-sm font-bold text-blue-800">Règle d&apos;or — Prestataires</p>
                <p className="mt-1 text-xs leading-relaxed text-blue-700/80">
                  Seul le Superadmin (vous) ajoute et géolocalise les prestataires. Les hôtes les consultent
                  depuis leur dashboard, et les voyageurs découvrent les expériences via le QR Hub.
                  Gestion complète : <span className="font-semibold">menu Prestataires</span> dans la barre latérale.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
