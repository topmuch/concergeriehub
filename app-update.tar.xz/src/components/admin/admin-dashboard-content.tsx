'use client';

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from 'recharts';
import {
  type ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { formatEur } from '@/lib/b2b';
import {
  CalendarDays,
  ChevronRight,
  CreditCard,
  HeartPulse,
  Home,
  Landmark,
  Mail,
  PiggyBank,
  QrCode,
  ShoppingCart,
  Store,
  Tag,
  UserCheck,
  Users,
  Wrench,
  type LucideIcon,
} from 'lucide-react';

// =============================================================
// AdminDashboardContent — V5 « AIRBNB PRO CLAIR » : Dashboard Superadmin.
// MODE CLAIR GARANTI (wrapper .light indépendant de html.dark).
//  - Hero clair signature Rausch + actions rapides
//  - 4 KPIs plateforme (mission v5.0) : Utilisateurs totaux, Hôtes
//    actifs, Propriétés, Abonnements actifs / MRR estimé
//  - 6 KPIs secondaires conservés (GMV, commission, plaques,
//    prestataires, séjours, commandes 30 j)
//  - 3 graphiques (tendance 30 j, donut statuts de paiement,
//    inscriptions & abonnements) + GMV par catégorie + top prestataires
//  - « Santé plateforme » : incidents réels via /api/admin/notifications
//  - « Transactions récentes » + « Dernières inscriptions »
// Source : /api/admin/kpis (définitions métier inchangées).
// =============================================================

// ----- Design tokens « clair garanti » (utilities inline, pas de dark:) -----
const AIR_SHADOW = 'shadow-[0_6px_16px_rgba(0,0,0,0.08),0_1px_2px_rgba(0,0,0,0.04)]';
const AIR_SHADOW_LG = 'shadow-[0_12px_32px_rgba(0,0,0,0.12),0_2px_6px_rgba(0,0,0,0.06)]';
const CARD_CLAIR = cn('rounded-2xl border border-[#ece7e1] bg-white', AIR_SHADOW);

interface KpisData {
  stats: {
    totalHosts: number;
    activeHosts: number;
    newHosts30d: number;
    propertiesCount: number;
    activePropertiesCount: number;
    providersTotal: number;
    providersActive: number;
    providersOwner: number;
    providersGuest: number;
    bookingsActive: number;
    bookingsUpcoming: number;
    subscriptionsActive: number;
    mrrEur: number;
    gmvPaidEur: number;
    platformRevenueEur: number;
    hostEarningsEur: number;
    ordersTotal: number;
    ordersPaid: number;
    ordersUnpaid: number;
    ordersRefunded: number;
    ordersFailed: number;
    orders30d: number;
    gmv30dEur: number;
    avgOrderEur: number;
    scansTotal: number;
    plaquesTotal: number;
    plaquesActive: number;
    plaquesInactive: number;
    plaquesLost: number;
  };
  series: { date: string; gmv: number; commission: number }[];
  hostSignupTrend: { date: string; count: number }[];
  planDistribution: { plan: string; count: number }[];
  paymentDistribution: { key: string; count: number }[];
  categoryRevenue: { category: string; label: string; gmv: number; orders: number }[];
  providerRevenue: { name: string; gmv: number; orders: number }[];
  recentOrders: {
    id: string;
    guestName: string;
    providerName: string;
    providerCategory: string | null;
    itemName: string;
    totalAmount: number;
    commission: number;
    status: string;
    paymentStatus: string;
    createdAt: string;
    paidAt: string | null;
  }[];
  recentHosts: {
    id: string;
    fullName: string | null;
    email: string;
    selectedPlan: string | null;
    isActive: boolean;
    createdAt: string;
    propertyCount: number;
  }[];
  recentActivity: {
    id: string;
    actionType: string;
    createdAt: string;
    propertyName: string | null;
    userName: string | null;
    module: string | null;
  }[];
  recentActivations: {
    id: string;
    activationCode: string;
    hubSlug: string | null;
    userName: string | null;
    createdAt: string;
  }[];
}

// ---------- « Santé plateforme » : incidents réels (/api/admin/notifications) ----------
interface HealthItem {
  kind: string;
  emoji: string;
  title: string;
  detail: string;
  href: string;
  at: string;
}

const HEALTH_KIND_META: Record<string, { label: string; className: string }> = {
  email_failed: { label: 'Emails', className: 'bg-rose-50 text-rose-700 ring-rose-200' },
  order_unpaid: { label: 'Commandes', className: 'bg-amber-50 text-amber-700 ring-amber-200' },
  sub_past_due: { label: 'Abonnements', className: 'bg-violet-50 text-violet-700 ring-violet-200' },
  plaque_lost: { label: 'Plaques', className: 'bg-slate-100 text-slate-600 ring-slate-200' },
};

// ---------- Configs de charts (palette « AIRBNB PRO » : rausch #FF385C + teal #00A699) ----------
const revenueConfig = {
  gmv: { label: 'GMV (achats invités)', color: '#FF385C' },
  commission: { label: 'Commission plateforme', color: '#00A699' },
} satisfies ChartConfig;

const paymentConfig = {
  PAID: { label: 'Payées', color: '#00A699' },
  UNPAID: { label: 'Impayées', color: '#F59E0B' },
  REFUNDED: { label: 'Remboursées', color: '#FF385C' },
  FAILED: { label: 'Échecs', color: '#94A3B8' },
} satisfies ChartConfig;

const categoryConfig = {
  gmv: { label: 'GMV', color: '#FF385C' },
} satisfies ChartConfig;

const signupConfig = {
  count: { label: 'Inscriptions', color: '#FF385C' },
} satisfies ChartConfig;

const planConfig = {
  airbnb_solo: { label: 'Solo', color: '#00A699' },
  airbnb_pro: { label: 'Pro', color: '#FF385C' },
  agency: { label: 'Agence', color: '#F59E0B' },
  free: { label: 'Free', color: '#94A3B8' },
} satisfies ChartConfig;

// ---------- Libellés / formats (badges clairs) ----------
const PAYMENT_META: Record<string, { label: string; className: string }> = {
  PAID: { label: 'Payée', className: 'bg-emerald-50 border-emerald-200 text-emerald-700' },
  UNPAID: { label: 'Impayée', className: 'bg-amber-50 border-amber-200 text-amber-700' },
  REFUNDED: { label: 'Remboursée', className: 'bg-rose-50 border-rose-200 text-rose-700' },
  FAILED: { label: 'Échec', className: 'bg-slate-100 border-slate-200 text-slate-600' },
};

const ORDER_STATUS_META: Record<string, { label: string; className: string }> = {
  PENDING: { label: 'En attente', className: 'bg-slate-100 border-slate-200 text-slate-600' },
  CONFIRMED: { label: 'Confirmée', className: 'bg-teal-50 border-teal-200 text-teal-700' },
  PREPARING: { label: 'En préparation', className: 'bg-amber-50 border-amber-200 text-amber-700' },
  DELIVERED: { label: 'Livrée', className: 'bg-emerald-50 border-emerald-200 text-emerald-700' },
  CANCELLED: { label: 'Annulée', className: 'bg-rose-50 border-rose-200 text-rose-700' },
};

function planLabel(plan: string | null): { label: string; className: string } {
  switch (plan) {
    case 'airbnb_solo':
      return { label: 'Solo', className: 'bg-emerald-50 border-emerald-200 text-emerald-700' };
    case 'airbnb_pro':
      return { label: 'Pro', className: 'bg-slate-900 border-slate-900 text-white' };
    case 'agency':
      return { label: 'Agence', className: 'bg-amber-50 border-amber-200 text-amber-700' };
    default:
      return { label: 'Free', className: 'bg-slate-100 border-slate-200 text-slate-600' };
  }
}

const ACTION_META: Record<string, { emoji: string; label: string }> = {
  qr_created: { emoji: '➕', label: 'QR code créé' },
  qr_updated: { emoji: '✏️', label: 'QR code modifié' },
  wifi_updated: { emoji: '📶', label: 'Wi-Fi mis à jour' },
  guidebook_updated: { emoji: '📖', label: 'Guidebook mis à jour' },
  scan: { emoji: '📡', label: 'Scan de la plaque' },
  voice_received: { emoji: '🎙️', label: 'Message vocal reçu' },
  complaint: { emoji: '🚨', label: 'Réclamation voyageur' },
  service_ordered: { emoji: '🥐', label: 'Service commandé' },
  property_created: { emoji: '🏠', label: 'Bien ajouté' },
  host_login: { emoji: '🔑', label: 'Connexion hôte' },
};

function actionMeta(type: string) {
  return ACTION_META[type] ?? { emoji: '•', label: type };
}

// ---------- Flux temps réel fusionné (activités + activations plaques) ----------
interface FeedItem {
  id: string;
  emoji: string;
  label: string;
  who: string;
  detail: string | null;
  createdAt: string;
}

function buildFeed(data: KpisData): FeedItem[] {
  const activities: FeedItem[] = data.recentActivity.map((a) => {
    const meta = actionMeta(a.actionType);
    return {
      id: a.id,
      emoji: meta.emoji,
      label: meta.label,
      who: a.userName ?? 'Système',
      detail: a.propertyName,
      createdAt: a.createdAt,
    };
  });
  const activations: FeedItem[] = data.recentActivations.map((a) => ({
    id: a.id,
    emoji: '🏷️',
    label: 'Plaque activée',
    who: a.userName ?? 'Système',
    detail: `${a.activationCode}${a.hubSlug ? ` · /${a.hubSlug}` : ''}`,
    createdAt: a.createdAt,
  }));
  return [...activities, ...activations]
    .sort((x, y) => (x.createdAt < y.createdAt ? 1 : -1))
    .slice(0, 12);
}

const fmtDay = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short' });
const fmtFullDate = new Intl.DateTimeFormat('fr-FR', {
  weekday: 'long',
  day: 'numeric',
  month: 'long',
  year: 'numeric',
});
const fmtDateTime = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
});

function formatDay(iso: string): string {
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(
    new Date(iso),
  );
}

function metaOf<T>(map: Record<string, T>, key: string, fallback: T): T {
  return map[key] ?? fallback;
}

// ---------- Actions rapides (routes console superadmin) ----------
const QUICK_ACTIONS: { href: string; label: string; icon: LucideIcon; bubble: string }[] = [
  { href: '/admin/users', label: 'Clients', icon: Users, bubble: 'bg-gradient-to-br from-[#FF385C] to-[#D70466]' },
  { href: '/admin/qr', label: 'Générer des QR', icon: QrCode, bubble: 'bg-gradient-to-br from-[#00A699] to-[#047857]' },
  { href: '/admin/emails', label: 'Emails', icon: Mail, bubble: 'bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9]' },
  { href: '/admin/providers', label: 'Prestataires', icon: Store, bubble: 'bg-gradient-to-br from-[#06B6D4] to-[#0E7490]' },
];

// ---------- Carte KPI « AIRBNB PRO clair » ----------
type KpiTone = 'rausch' | 'emerald' | 'amber' | 'violet' | 'teal' | 'orange';

/** Dégradés pastel CLAIRS explicites (indépendants de html.dark). */
const KPI_CARD_TONES: Record<KpiTone, string> = {
  rausch: 'bg-gradient-to-br from-[#FFF0F2] to-[#FFE3E8] text-[#BE1244]',
  emerald: 'bg-gradient-to-br from-[#E7FAF6] to-[#D2F3EC] text-[#0B7A6E]',
  amber: 'bg-gradient-to-br from-[#FFF4E5] to-[#FFE8CC] text-[#B45309]',
  violet: 'bg-gradient-to-br from-[#F3EFFE] to-[#E9E2FC] text-[#6D28D9]',
  teal: 'bg-gradient-to-br from-[#E8F7FA] to-[#D5EFF6] text-[#0E7490]',
  orange: 'bg-gradient-to-br from-[#FFF0E8] to-[#FFE2D2] text-[#C2410C]',
};

/** Bulles d'icône dégradées (identiques clair/sombre). */
const KPI_BUBBLE_TONES: Record<KpiTone, string> = {
  rausch: 'bg-gradient-to-br from-[#FF385C] to-[#D70466]',
  emerald: 'bg-gradient-to-br from-[#00A699] to-[#047857]',
  amber: 'bg-gradient-to-br from-[#F59E0B] to-[#D97706]',
  violet: 'bg-gradient-to-br from-[#8B5CF6] to-[#6D28D9]',
  teal: 'bg-gradient-to-br from-[#06B6D4] to-[#0E7490]',
  orange: 'bg-gradient-to-br from-[#FB923C] to-[#C2410C]',
};

function KpiCard({
  label,
  value,
  suffix,
  icon: Icon,
  tone,
  chip,
  hint,
  index = 0,
}: {
  label: string;
  value: string;
  suffix?: ReactNode;
  icon: LucideIcon;
  tone: KpiTone;
  chip?: { text: string };
  hint?: string;
  index?: number;
}) {
  // Style « AIRBNB PRO clair » : bulle icône en dégradé + chip tendance,
  // la couleur texte du ton se propage à valeur/chip/hint.
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 * index, duration: 0.3, ease: 'easeOut' }}
      whileHover={{ y: -3 }}
      title={hint}
      className={cn('rounded-2xl p-5 air-hoverlift', KPI_CARD_TONES[tone], AIR_SHADOW)}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          aria-hidden="true"
          className={cn(
            'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow',
            KPI_BUBBLE_TONES[tone],
          )}
        >
          <Icon className="h-5 w-5" strokeWidth={2.2} />
        </span>
        {chip && (
          <span className="inline-flex shrink-0 items-center rounded-full bg-white/70 px-2.5 py-0.5 text-[11px] font-bold">
            {chip.text}
          </span>
        )}
      </div>
      <p className="mt-3 truncate text-2xl font-extrabold tabular-nums sm:text-3xl">
        {value}
        {suffix != null && (
          <span className="ml-1 text-sm font-bold opacity-70 sm:text-base">{suffix}</span>
        )}
      </p>
      <p className="mt-0.5 truncate text-sm font-semibold">{label}</p>
      {hint && <p className="mt-0.5 truncate text-[11px] opacity-75">{hint}</p>}
    </motion.div>
  );
}

/** Skeleton clair local (le Skeleton global a une variante dark:). */
function AirSkeleton({ className }: { className?: string }) {
  return <div aria-hidden="true" className={cn('animate-pulse rounded-2xl bg-slate-200/70', className)} />;
}

// ---------- Composant principal ----------
export function AdminDashboardContent() {
  const [data, setData] = useState<KpisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [today, setToday] = useState('');
  // « Santé plateforme » — incidents réels agrégés
  const [health, setHealth] = useState<HealthItem[] | null>(null);
  const [healthState, setHealthState] = useState<'loading' | 'ok' | 'error'>('loading');

  useEffect(() => {
    // Après montage uniquement (évite tout écart d'hydratation)
    setToday(fmtFullDate.format(new Date()));
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/kpis');
      if (!res.ok) throw new Error('http');
      setData((await res.json()) as KpisData);
    } catch {
      setError('Impossible de charger les statistiques. Réessayez.');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadHealth = useCallback(async () => {
    setHealthState('loading');
    try {
      const res = await fetch('/api/admin/notifications', { cache: 'no-store' });
      if (!res.ok) throw new Error('http');
      const json = (await res.json()) as { count: number; items: HealthItem[] };
      setHealth(Array.isArray(json.items) ? json.items : []);
      setHealthState('ok');
    } catch {
      setHealthState('error');
    }
  }, []);

  useEffect(() => {
    load();
    loadHealth();
  }, [load, loadHealth]);

  function refreshAll() {
    load();
    loadHealth();
    toast.success('Statistiques actualisées');
  }

  // ----- Loading -----
  if (loading && !data) {
    return (
      <div className="light min-h-full bg-[#faf9f7] text-slate-900 [color-scheme:light]">
        <div className="mx-auto w-full max-w-7xl space-y-6 px-4 py-8" aria-busy="true" aria-label="Chargement">
          <AirSkeleton className="h-40 w-full rounded-3xl" />
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[0, 1, 2, 3].map((i) => (
              <AirSkeleton key={i} className="h-36 rounded-2xl" />
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <AirSkeleton key={i} className="h-36 rounded-2xl" />
            ))}
          </div>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <AirSkeleton className="h-80 rounded-2xl lg:col-span-2" />
            <AirSkeleton className="h-80 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  // ----- Erreur -----
  if (error || !data) {
    return (
      <div className="light min-h-full bg-[#faf9f7] text-slate-900 [color-scheme:light]">
        <div className="mx-auto flex w-full max-w-7xl justify-center px-4 py-16">
          <div
            className={cn('w-full max-w-md rounded-2xl border border-rose-100 bg-rose-50/70 p-8 text-center', AIR_SHADOW)}
            role="alert"
          >
            <p className="text-3xl" aria-hidden="true">😵</p>
            <p className="mt-2 font-semibold text-slate-900">Erreur de chargement</p>
            <p className="mt-1 text-sm text-slate-500">{error || 'Données indisponibles'}</p>
            <button
              type="button"
              onClick={load}
              className="mt-5 inline-flex items-center justify-center rounded-full bg-[#FF385C] px-6 py-2.5 text-sm font-semibold text-white shadow transition-colors hover:bg-[#E31C5F] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF385C]/50 focus-visible:ring-offset-2"
            >
              Réessayer
            </button>
          </div>
        </div>
      </div>
    );
  }

  const { stats, series, paymentDistribution, categoryRevenue, providerRevenue } = data;
  const refundRate =
    stats.ordersPaid + stats.ordersRefunded > 0
      ? Math.round((stats.ordersRefunded / (stats.ordersPaid + stats.ordersRefunded)) * 100)
      : 0;
  const maxProviderGmv = Math.max(...providerRevenue.map((p) => p.gmv), 1);
  const totalOrdersForDonut = paymentDistribution.reduce((acc, d) => acc + d.count, 0);
  const feed = buildFeed(data);
  const activeHostsPct = stats.totalHosts > 0 ? Math.round((stats.activeHosts / stats.totalHosts) * 100) : 0;

  return (
    <div className="light min-h-full bg-[#faf9f7] text-slate-900 [color-scheme:light]">
      <div className="mx-auto w-full max-w-7xl space-y-6 px-4 py-8">
        {/* ================= Hero « AIRBNB PRO clair » ================= */}
        <motion.section
          aria-labelledby="admin-greeting"
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className={cn('relative overflow-hidden rounded-3xl border border-[#f3dedf] bg-white p-6 sm:p-8', AIR_SHADOW_LG)}
        >
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -right-20 -top-28 h-72 w-72 rounded-full bg-[#FF385C]/10 blur-3xl"
          />
          <span
            aria-hidden="true"
            className="pointer-events-none absolute -bottom-24 left-1/3 h-56 w-56 rounded-full bg-[#00A699]/10 blur-3xl"
          />
          <div className="relative flex flex-wrap items-start justify-between gap-4">
            <div className="min-w-0">
              <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#FF385C]" suppressHydrationWarning>
                Console superadmin
              </p>
              <h2 id="admin-greeting" className="mt-1.5 text-2xl font-extrabold tracking-tight text-slate-900 sm:text-3xl">
                Vue d&apos;ensemble 🛡️
              </h2>
              <p className="mt-1.5 text-sm text-slate-600" suppressHydrationWarning>
                Santé de la plateforme RoomScan{today ? ` — ${today}` : ''}.
              </p>
            </div>
            <button
              type="button"
              onClick={refreshAll}
              className="inline-flex h-10 items-center justify-center gap-2 rounded-full border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 transition-colors hover:border-[#FF385C]/40 hover:text-[#FF385C] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#FF385C]/40"
            >
              Actualiser
            </button>
          </div>
          <div className="relative mt-5 flex flex-wrap gap-2">
            <span className="rounded-full bg-[#FFF0F2] px-3 py-1 text-xs font-bold text-[#BE1244] ring-1 ring-[#FF385C]/15">
              💳 {stats.ordersPaid} commande{stats.ordersPaid > 1 ? 's' : ''} payée{stats.ordersPaid > 1 ? 's' : ''}
            </span>
            <span className="rounded-full bg-[#FFF4E5] px-3 py-1 text-xs font-bold text-[#B45309] ring-1 ring-amber-500/15">
              👩‍💻 {stats.activeHosts} hôte{stats.activeHosts > 1 ? 's' : ''} actif{stats.activeHosts > 1 ? 's' : ''}
            </span>
            <span className="rounded-full bg-[#E8F7FA] px-3 py-1 text-xs font-bold text-[#0E7490] ring-1 ring-cyan-500/15">
              🏠 {stats.activePropertiesCount} bien{stats.activePropertiesCount > 1 ? 's' : ''} actif
              {stats.activePropertiesCount > 1 ? 's' : ''}
            </span>
          </div>
        </motion.section>

        {/* ================= Actions rapides ================= */}
        <section aria-label="Actions rapides" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {QUICK_ACTIONS.map((action, i) => (
            <motion.div
              key={action.href}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i, duration: 0.25 }}
            >
              <Link
                href={action.href}
                className={cn('air-hoverlift group flex items-center gap-3 p-4', CARD_CLAIR)}
              >
                <span
                  aria-hidden="true"
                  className={cn(
                    'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow',
                    action.bubble,
                  )}
                >
                  <action.icon className="h-[18px] w-[18px]" strokeWidth={2.2} />
                </span>
                <span className="min-w-0 flex-1 truncate text-sm font-bold text-slate-900">{action.label}</span>
                <ChevronRight
                  aria-hidden="true"
                  className="h-4 w-4 shrink-0 text-slate-400 transition-transform group-hover:translate-x-0.5"
                />
              </Link>
            </motion.div>
          ))}
        </section>

        {/* ================= KPIs plateforme (mission v5.0) ================= */}
        <section aria-label="KPIs plateforme" className="grid grid-cols-2 gap-4 xl:grid-cols-4">
          <KpiCard
            index={0}
            label="Utilisateurs totaux"
            value={String(stats.totalHosts)}
            icon={Users}
            tone="rausch"
            chip={{ text: stats.newHosts30d > 0 ? `+${stats.newHosts30d} sur 30 j` : '0 sur 30 j' }}
            hint="Comptes hôtes inscrits sur la plateforme"
          />
          <KpiCard
            index={1}
            label="Hôtes actifs"
            value={String(stats.activeHosts)}
            icon={UserCheck}
            tone="emerald"
            chip={{ text: `${activeHostsPct} % du total` }}
            hint="Comptes hôtes actuellement actifs"
          />
          <KpiCard
            index={2}
            label="Propriétés"
            value={String(stats.activePropertiesCount)}
            suffix={<>/ {stats.propertiesCount}</>}
            icon={Home}
            tone="teal"
            hint="Biens actifs équipés d'une plaque QR"
          />
          <KpiCard
            index={3}
            label="MRR estimé"
            value={formatEur(stats.mrrEur)}
            icon={PiggyBank}
            tone="violet"
            chip={
              stats.subscriptionsActive > 0
                ? { text: `${stats.subscriptionsActive} abonnement${stats.subscriptionsActive > 1 ? 's' : ''} actif${stats.subscriptionsActive > 1 ? 's' : ''}` }
                : { text: 'Aucun abonnement' }
            }
            hint="Revenu mensuel récurrent normalisé"
          />
        </section>

        {/* ================= KPIs secondaires (conservés) ================= */}
        <section aria-label="KPIs opérationnels" className="grid grid-cols-2 gap-4 lg:grid-cols-3">
          <KpiCard
            index={0}
            label="GMV encaissée"
            value={formatEur(stats.gmvPaidEur)}
            icon={CreditCard}
            tone="rausch"
            chip={{ text: `${formatEur(stats.gmv30dEur)} sur 30 j` }}
            hint={`${stats.ordersPaid} commande${stats.ordersPaid > 1 ? 's' : ''} payée${stats.ordersPaid > 1 ? 's' : ''} · panier moyen ${formatEur(stats.avgOrderEur)}`}
          />
          <KpiCard
            index={1}
            label="Revenus plateforme"
            value={formatEur(stats.platformRevenueEur)}
            icon={Landmark}
            tone="emerald"
            chip={{ text: 'Commission 15 %' }}
            hint={`Part reversée aux hôtes : ${formatEur(stats.hostEarningsEur)}`}
          />
          <KpiCard
            index={2}
            label="Plaques activées"
            value={String(stats.plaquesActive)}
            suffix={<>/ {stats.plaquesTotal}</>}
            icon={Tag}
            tone="orange"
            hint={`${stats.plaquesInactive} inactive${stats.plaquesInactive > 1 ? 's' : ''} · ${stats.plaquesLost} perdue${stats.plaquesLost > 1 ? 's' : ''}`}
          />
          <KpiCard
            index={3}
            label="Prestataires actifs"
            value={String(stats.providersActive)}
            suffix={<>/ {stats.providersTotal}</>}
            icon={Wrench}
            tone="teal"
            hint={`🔧 ${stats.providersOwner} owner · 🥂 ${stats.providersGuest} guest`}
          />
          <KpiCard
            index={4}
            label="Séjours en cours"
            value={String(stats.bookingsActive)}
            suffix={<>+ {stats.bookingsUpcoming} à venir</>}
            icon={CalendarDays}
            tone="rausch"
            hint="Check-ins en cours et confirmés"
          />
          <KpiCard
            index={5}
            label="Commandes 30 j"
            value={String(stats.orders30d)}
            suffix={<>/ {stats.ordersTotal}</>}
            icon={ShoppingCart}
            tone="amber"
            hint={`${stats.ordersRefunded} remboursée${stats.ordersRefunded > 1 ? 's' : ''} (${refundRate} %)`}
          />
        </section>

        {/* ================= Graphiques ================= */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* ----- Tendance 30 j : GMV + commission ----- */}
          <div className={cn('p-5 sm:p-6 lg:col-span-2', CARD_CLAIR)}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-bold text-slate-900">Revenus des 30 derniers jours</p>
                <p className="mt-0.5 text-xs text-slate-500">
                  Volume acheté par les invités (GMV) et commission retenue par la plateforme
                </p>
              </div>
            </div>
            <ChartContainer config={revenueConfig} className="mt-4 h-72 w-full">
              <ComposedChart data={series} margin={{ left: 4, right: 8, top: 8 }}>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  minTickGap={28}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  width={44}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v: number) => `${Math.round(v)}€`}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      labelFormatter={(_p, payload) => {
                        const raw = payload?.[0]?.payload as { date?: string } | undefined;
                        return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                      }}
                    />
                  }
                />
                <Bar dataKey="gmv" fill="var(--color-gmv)" radius={[4, 4, 0, 0]} maxBarSize={28} />
                <Line
                  dataKey="commission"
                  type="monotone"
                  stroke="var(--color-commission)"
                  strokeWidth={2.5}
                  dot={false}
                />
              </ComposedChart>
            </ChartContainer>
          </div>

          {/* ----- Donut statuts de paiement ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">Statuts de paiement</p>
            <p className="mt-0.5 text-xs text-slate-500">Répartition des {totalOrdersForDonut} commandes</p>
            <div className="relative mt-4">
              <ChartContainer config={paymentConfig} className="h-56 w-full">
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                  <Pie
                    data={paymentDistribution}
                    dataKey="count"
                    nameKey="key"
                    innerRadius={58}
                    outerRadius={88}
                    strokeWidth={3}
                    paddingAngle={2}
                  >
                    {paymentDistribution.map((entry) => (
                      <Cell key={entry.key} fill={`var(--color-${entry.key})`} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-2xl font-bold tabular-nums text-slate-900">{totalOrdersForDonut}</p>
                  <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">commandes</p>
                </div>
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {paymentDistribution.map((d) => {
                const meta = metaOf(PAYMENT_META, d.key, {
                  label: d.key,
                  className: 'bg-slate-100 border-slate-200 text-slate-600',
                });
                if (d.count === 0) return null;
                return (
                  <span
                    key={d.key}
                    className={cn(
                      'inline-flex rounded-full border px-2 py-0.5 text-[11px] font-bold',
                      meta.className,
                    )}
                  >
                    {meta.label} : {d.count}
                  </span>
                );
              })}
            </div>
          </div>
        </section>

        {/* ================= Croissance & abonnements ================= */}
        <section aria-label="Croissance et abonnements" className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* ----- Courbe d'inscriptions hôtes 30 j ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-bold text-slate-900">Inscriptions des hôtes</p>
                <p className="mt-0.5 text-xs text-slate-500">Nouveaux comptes créés sur les 30 derniers jours</p>
              </div>
              <span className="inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-700">
                +{stats.newHosts30d} sur 30 j
              </span>
            </div>
            <ChartContainer config={signupConfig} className="mt-4 h-64 w-full">
              <AreaChart data={data.hostSignupTrend} margin={{ left: 4, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="fillSignups" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-count)" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="var(--color-count)" stopOpacity={0.03} />
                  </linearGradient>
                </defs>
                <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  minTickGap={28}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  width={32}
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                />
                <ChartTooltip
                  content={
                    <ChartTooltipContent
                      labelFormatter={(_p, payload) => {
                        const raw = payload?.[0]?.payload as { date?: string } | undefined;
                        return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                      }}
                    />
                  }
                />
                <Area
                  dataKey="count"
                  type="monotone"
                  stroke="var(--color-count)"
                  strokeWidth={2.5}
                  fill="url(#fillSignups)"
                  dot={false}
                />
              </AreaChart>
            </ChartContainer>
          </div>

          {/* ----- Répartition des abonnements (Solo vs Pro) ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">Répartition des abonnements</p>
            <p className="mt-0.5 text-xs text-slate-500">Comptes hôtes par plan sélectionné</p>
            {data.planDistribution.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-10 text-center">
                <p className="text-2xl" aria-hidden="true">🐣</p>
                <p className="mt-2 text-sm text-slate-500">Aucun hôte inscrit pour le moment.</p>
              </div>
            ) : (
              <>
                <div className="relative mt-4">
                  <ChartContainer config={planConfig} className="h-56 w-full">
                    <PieChart>
                      <ChartTooltip content={<ChartTooltipContent nameKey="plan" />} />
                      <Pie
                        data={data.planDistribution}
                        dataKey="count"
                        nameKey="plan"
                        innerRadius={58}
                        outerRadius={88}
                        strokeWidth={3}
                        paddingAngle={2}
                      >
                        {data.planDistribution.map((entry) => (
                          <Cell key={entry.plan} fill={`var(--color-${entry.plan})`} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ChartContainer>
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-2xl font-bold tabular-nums text-slate-900">{stats.totalHosts}</p>
                      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">hôtes</p>
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  {data.planDistribution.map((p) => {
                    const meta = planLabel(p.plan === 'airbnb_solo' || p.plan === 'airbnb_pro' || p.plan === 'agency' ? p.plan : 'free');
                    return (
                      <span
                        key={p.plan}
                        className="inline-flex rounded-full border border-slate-200 bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600"
                      >
                        {meta.label} : {p.count}
                      </span>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* ----- GMV par catégorie ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">GMV par catégorie</p>
            <p className="mt-0.5 text-xs text-slate-500">Chiffre d&apos;affaires invités par type de prestation</p>
            {categoryRevenue.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-10 text-center">
                <p className="text-2xl" aria-hidden="true">📊</p>
                <p className="mt-2 text-sm text-slate-500">Aucune commande payée pour le moment.</p>
              </div>
            ) : (
              <ChartContainer config={categoryConfig} className="mt-4 h-64 w-full">
                <BarChart layout="vertical" data={categoryRevenue} margin={{ left: 8, right: 16, top: 4 }}>
                  <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis
                    type="number"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    tickFormatter={(v: number) => `${Math.round(v)}€`}
                  />
                  <YAxis
                    type="category"
                    dataKey="label"
                    width={150}
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: '#475569' }}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="gmv" fill="var(--color-gmv)" radius={[0, 6, 6, 0]} maxBarSize={22} />
                </BarChart>
              </ChartContainer>
            )}
          </div>

          {/* ----- Top prestataires ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">Top prestataires</p>
            <p className="mt-0.5 text-xs text-slate-500">Classement par GMV encaissée (commandes payées)</p>
            {providerRevenue.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-10 text-center">
                <p className="text-2xl" aria-hidden="true">🏆</p>
                <p className="mt-2 text-sm text-slate-500">Aucune commande payée pour le moment.</p>
              </div>
            ) : (
              <ul className="mt-4 space-y-3.5">
                {providerRevenue.map((p, i) => (
                  <li key={p.name} className="group">
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <span className="flex min-w-0 items-center gap-2 font-semibold text-slate-900">
                        <span
                          aria-hidden="true"
                          className={cn(
                            'flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold',
                            i === 0
                              ? 'bg-gradient-to-br from-[#FF385C] to-[#D70466] text-white shadow'
                              : 'bg-slate-100 text-slate-500',
                          )}
                        >
                          {i + 1}
                        </span>
                        <span className="truncate">{p.name}</span>
                      </span>
                      <span className="shrink-0 text-right">
                        <span className="font-bold tabular-nums text-slate-900">{formatEur(p.gmv)}</span>
                        <span className="ml-1.5 text-[11px] text-slate-400">{p.orders} cmd</span>
                      </span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-[#FF385C] to-[#D70466]"
                        style={{ width: `${Math.max((p.gmv / maxProviderGmv) * 100, 6)}%` }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Transactions récentes + activité ================= */}
        <section className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* ----- Transactions récentes ----- */}
          <div className={cn('p-5 sm:p-6 lg:col-span-2', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">Transactions récentes</p>
            <p className="mt-0.5 text-xs text-slate-500">Les 8 dernières transactions passées depuis les QR Hubs</p>
            {data.recentOrders.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-10 text-center">
                <p className="text-2xl" aria-hidden="true">🛒</p>
                <p className="mt-2 text-sm text-slate-500">Aucune commande pour le moment.</p>
              </div>
            ) : (
              <div className="mt-4 max-h-96 overflow-y-auto rounded-2xl border border-slate-200">
                <Table>
                  <TableHeader className="sticky top-0 z-10 bg-slate-100">
                    <TableRow>
                      <TableHead className="text-xs uppercase tracking-wide text-slate-500">Invité</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-slate-500">Prestation</TableHead>
                      <TableHead className="text-right text-xs uppercase tracking-wide text-slate-500">Montant</TableHead>
                      <TableHead className="text-right text-xs uppercase tracking-wide text-slate-500">Commission</TableHead>
                      <TableHead className="text-xs uppercase tracking-wide text-slate-500">Paiement</TableHead>
                      <TableHead className="text-right text-xs uppercase tracking-wide text-slate-500">Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.recentOrders.map((o) => {
                      const pay = metaOf(PAYMENT_META, o.paymentStatus, {
                        label: o.paymentStatus,
                        className: 'bg-slate-100 border-slate-200 text-slate-600',
                      });
                      return (
                        <TableRow key={o.id} className="hover:bg-slate-50">
                          <TableCell className="whitespace-nowrap font-semibold text-slate-900">
                            {o.guestName}
                          </TableCell>
                          <TableCell className="max-w-[180px]">
                            <p className="truncate text-slate-900">{o.itemName}</p>
                            <p className="truncate text-[11px] text-slate-500">{o.providerName}</p>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right font-bold tabular-nums text-slate-900">
                            {formatEur(o.totalAmount)}
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right font-semibold tabular-nums text-emerald-700">
                            {formatEur(o.commission)}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline" className={cn('font-bold', pay.className)}>
                              {pay.label}
                            </Badge>
                          </TableCell>
                          <TableCell className="whitespace-nowrap text-right text-[11px] text-slate-400">
                            {fmtDateTime.format(new Date(o.createdAt))}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>

          {/* ----- Flux temps réel fusionné ----- */}
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <p className="font-bold text-slate-900">Dernières activités</p>
            <p className="mt-0.5 text-xs text-slate-500">Activations de plaques, scans &amp; actions hôtes — temps réel</p>
            {feed.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-10 text-center">
                <p className="text-2xl" aria-hidden="true">📡</p>
                <p className="mt-2 text-sm text-slate-500">Aucune activité enregistrée pour le moment.</p>
              </div>
            ) : (
              <ul className="-mx-2 mt-2 max-h-96 divide-y divide-slate-100 overflow-y-auto">
                {feed.map((a) => (
                  <li key={a.id} className="flex items-start gap-3 rounded-lg px-2 py-3 transition-colors hover:bg-slate-50">
                    <span
                      aria-hidden="true"
                      className="flex h-9 w-9 shrink-0 select-none items-center justify-center rounded-xl bg-slate-100 text-lg leading-none"
                    >
                      {a.emoji}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-bold text-slate-900">{a.label}</p>
                      <p className="truncate text-xs text-slate-500">
                        {a.who}
                        {a.detail ? ` · ${a.detail}` : ''}
                      </p>
                    </div>
                    <span className="shrink-0 text-[11px] text-slate-400">
                      {fmtDateTime.format(new Date(a.createdAt))}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Santé plateforme (real data /api/admin/notifications) ================= */}
        <section aria-label="Santé plateforme">
          <div className={cn('p-5 sm:p-6', CARD_CLAIR)}>
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <span
                  aria-hidden="true"
                  className="flex h-10 w-10 shrink-0 select-none items-center justify-center rounded-xl bg-gradient-to-br from-[#FF385C] to-[#D70466] text-lg leading-none text-white shadow"
                >
                  <HeartPulse className="h-5 w-5" strokeWidth={2.2} />
                </span>
                <div>
                  <p className="text-sm font-bold leading-tight text-slate-900">Santé plateforme</p>
                  <p className="mt-0.5 text-xs text-slate-500">
                    Incidents réels détectés : emails en échec, commandes impayées &gt; 48 h, abonnements en impayé,
                    plaques perdues
                  </p>
                </div>
              </div>
              {healthState === 'ok' && health && (
                <span
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold ring-1',
                    health.length === 0
                      ? 'bg-emerald-50 text-emerald-700 ring-emerald-200'
                      : 'bg-amber-50 text-amber-700 ring-amber-200',
                  )}
                >
                  <span
                    aria-hidden="true"
                    className={cn('h-2 w-2 rounded-full', health.length === 0 ? 'bg-emerald-500' : 'animate-pulse bg-amber-500')}
                  />
                  {health.length === 0 ? 'Tout est opérationnel' : `${health.length} point${health.length > 1 ? 's' : ''} d'attention`}
                </span>
              )}
            </div>

            {healthState === 'loading' ? (
              <div className="mt-4 flex flex-col gap-2">
                {Array.from({ length: 2 }).map((_, i) => (
                  <AirSkeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : healthState === 'error' ? (
              <p className="mt-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-6 text-center text-sm text-slate-500">
                Monitoring momentanément indisponible.
              </p>
            ) : !health || health.length === 0 ? (
              <div className="mt-4 rounded-2xl border border-dashed border-emerald-200 bg-emerald-50/60 px-4 py-8 text-center">
                <p className="text-2xl" aria-hidden="true">✅</p>
                <p className="mt-2 text-sm font-semibold text-emerald-800">Aucun incident — la plateforme est saine.</p>
                <p className="mt-1 text-xs text-emerald-700/80">
                  Emails, paiements, abonnements et plaques : tout roule.
                </p>
              </div>
            ) : (
              <ul className="mt-4 divide-y divide-slate-100">
                {health.map((n, i) => {
                  const kindMeta = metaOf(HEALTH_KIND_META, n.kind, {
                    label: n.kind,
                    className: 'bg-slate-100 text-slate-600 ring-slate-200',
                  });
                  return (
                    <li key={`${n.kind}-${i}`}>
                      <Link
                        href={n.href}
                        className="-mx-2 flex items-start gap-3 rounded-xl px-2 py-3 transition-colors hover:bg-slate-50"
                      >
                        <span
                          aria-hidden="true"
                          className="flex h-9 w-9 shrink-0 select-none items-center justify-center rounded-xl bg-slate-100 text-lg leading-none"
                        >
                          {n.emoji}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-bold text-slate-900">{n.title}</span>
                          <span className="block truncate text-xs text-slate-500">{n.detail}</span>
                        </span>
                        <span className="flex shrink-0 flex-col items-end gap-1">
                          <span className={cn('inline-flex rounded-full px-2 py-0.5 text-[11px] font-bold ring-1', kindMeta.className)}>
                            {kindMeta.label}
                          </span>
                          <span className="text-[11px] text-slate-400">{fmtDateTime.format(new Date(n.at))}</span>
                        </span>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Dernières inscriptions ================= */}
        <section aria-label="Dernières inscriptions">
          <div className={cn('overflow-hidden p-0', CARD_CLAIR)}>
            <div className="flex items-start gap-3 px-5 pb-3 pt-5 sm:px-6">
              <span
                aria-hidden="true"
                className="flex h-9 w-9 shrink-0 select-none items-center justify-center rounded-xl bg-slate-100 text-lg leading-none"
              >
                🆕
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold leading-tight text-slate-900">Dernières inscriptions</p>
                <p className="mt-0.5 text-xs leading-relaxed text-slate-500">Les 6 comptes hôtes les plus récents</p>
              </div>
            </div>
            {data.recentHosts.length === 0 ? (
              <div className="mx-5 mb-5 rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-8 text-center sm:mx-6">
                <p className="text-2xl" aria-hidden="true">🧑‍💻</p>
                <p className="mt-2 text-sm text-slate-500">Aucun hôte inscrit pour le moment.</p>
              </div>
            ) : (
              <ul className="max-h-96 divide-y divide-slate-100 overflow-y-auto">
                {data.recentHosts.map((h) => {
                  const plan = planLabel(h.selectedPlan);
                  return (
                    <li key={h.id} className="flex items-center gap-3 px-5 py-3 transition-colors hover:bg-slate-50 sm:px-6">
                      <span
                        aria-hidden="true"
                        className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-[#FF385C]/10 to-[#D70466]/10 text-xs font-extrabold text-[#BE1244] ring-1 ring-[#FF385C]/20"
                      >
                        {(h.fullName ?? h.email).slice(0, 2).toUpperCase()}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-slate-900">
                          {h.fullName ?? 'Sans nom'}
                          {!h.isActive && (
                            <span className="ml-2 text-[11px] font-bold text-rose-600">· désactivé</span>
                          )}
                        </p>
                        <p className="truncate text-xs text-slate-500">{h.email}</p>
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-1">
                        <Badge className={cn('font-bold', plan.className)} variant="outline">
                          {plan.label}
                        </Badge>
                        <span className="text-[11px] text-slate-400">
                          {h.propertyCount} bien{h.propertyCount > 1 ? 's' : ''} · {formatDay(h.createdAt)}
                        </span>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </section>

        {/* ================= Rappel règle d'or ================= */}
        <section aria-label="Règle de gestion des prestataires" className="pb-4">
          <div className={cn('rounded-2xl border border-emerald-200/80 bg-emerald-50/70 p-5', AIR_SHADOW)}>
            <div className="flex items-start gap-3">
              <span
                aria-hidden="true"
                className="flex h-10 w-10 shrink-0 select-none items-center justify-center rounded-xl bg-gradient-to-br from-[#00A699] to-[#047857] text-lg leading-none text-white shadow"
              >
                🛡️
              </span>
              <div>
                <p className="text-sm font-bold text-emerald-900">Règle d&apos;or — Prestataires</p>
                <p className="mt-0.5 text-xs leading-relaxed text-emerald-800/90">
                  Seul le Superadmin (vous) ajoute et géolocalise les prestataires. Les hôtes les consultent
                  depuis leur dashboard, et les voyageurs découvrent les expériences via le QR Hub.
                  Gestion complète : <span className="font-bold">menu Prestataires</span> dans la barre latérale.
                </p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
