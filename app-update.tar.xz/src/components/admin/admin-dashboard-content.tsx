'use client';

import { useCallback, useEffect, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { toast } from 'sonner';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Line,
  Pie,
  PieChart,
  XAxis,
  YAxis,
} from 'recharts';
import {
  type ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { formatEur } from '@/lib/b2b';
import {
  CalendarDays,
  ChevronRight,
  CreditCard,
  Home,
  Landmark,
  Mail,
  PiggyBank,
  QrCode,
  ShoppingCart,
  Store,
  Tag,
  Users,
  Wrench,
  type LucideIcon,
} from 'lucide-react';

// =============================================================
// AdminDashboardContent — V3 « AIRBNB PRO » : Dashboard Superadmin.
//  - Hero gradient signature + chips verre, actions rapides
//  - 8 cartes KPI colorées kpi-* (GMV, commission plateforme, MRR,
//    hôtes, biens, prestataires, séjours, commandes 30 j)
//  - 3 graphiques (tendance 30 j GMV + commission, donut statuts de
//    paiement, GMV par catégorie) + inscriptions & abonnements
//  - Top prestataires, dernières commandes, activité, derniers hôtes
// Design : tokens sémantiques (bg-card / text-foreground / …),
// dark mode natif via next-themes. Logique métier inchangée.
// Source : /api/admin/kpis (définitions métier inchangées).
// =============================================================

interface KpisData {
  stats: {
    totalHosts: number;
    activeHosts: number;
    newHosts30d: number;
    propertiesCount: number;
    activePropertiesCount: number;
    providersTotal: number;
    providersActive: number;
    providersOwner: number;
    providersGuest: number;
    bookingsActive: number;
    bookingsUpcoming: number;
    subscriptionsActive: number;
    mrrEur: number;
    gmvPaidEur: number;
    platformRevenueEur: number;
    hostEarningsEur: number;
    ordersTotal: number;
    ordersPaid: number;
    ordersUnpaid: number;
    ordersRefunded: number;
    ordersFailed: number;
    orders30d: number;
    gmv30dEur: number;
    avgOrderEur: number;
    scansTotal: number;
    plaquesTotal: number;
    plaquesActive: number;
    plaquesInactive: number;
    plaquesLost: number;
  };
  series: { date: string; gmv: number; commission: number }[];
  hostSignupTrend: { date: string; count: number }[];
  planDistribution: { plan: string; count: number }[];
  paymentDistribution: { key: string; count: number }[];
  categoryRevenue: { category: string; label: string; gmv: number; orders: number }[];
  providerRevenue: { name: string; gmv: number; orders: number }[];
  recentOrders: {
    id: string;
    guestName: string;
    providerName: string;
    providerCategory: string | null;
    itemName: string;
    totalAmount: number;
    commission: number;
    status: string;
    paymentStatus: string;
    createdAt: string;
    paidAt: string | null;
  }[];
  recentHosts: {
    id: string;
    fullName: string | null;
    email: string;
    selectedPlan: string | null;
    isActive: boolean;
    createdAt: string;
    propertyCount: number;
  }[];
  recentActivity: {
    id: string;
    actionType: string;
    createdAt: string;
    propertyName: string | null;
    userName: string | null;
    module: string | null;
  }[];
  recentActivations: {
    id: string;
    activationCode: string;
    hubSlug: string | null;
    userName: string | null;
    createdAt: string;
  }[];
}

// ---------- Configs de charts (palette « AIRBNB PRO » : rausch #FF385C + teal #00A699) ----------
const revenueConfig = {
  gmv: { label: 'GMV (achats invités)', color: '#FF385C' },
  commission: { label: 'Commission plateforme', color: '#00A699' },
} satisfies ChartConfig;

const paymentConfig = {
  PAID: { label: 'Payées', color: '#00A699' },
  UNPAID: { label: 'Impayées', color: '#F59E0B' },
  REFUNDED: { label: 'Remboursées', color: '#FF385C' },
  FAILED: { label: 'Échecs', color: '#94A3B8' },
} satisfies ChartConfig;

const categoryConfig = {
  gmv: { label: 'GMV', color: '#FF385C' },
} satisfies ChartConfig;

const signupConfig = {
  count: { label: 'Inscriptions', color: '#FF385C' },
} satisfies ChartConfig;

const planConfig = {
  airbnb_solo: { label: 'Solo', color: '#00A699' },
  airbnb_pro: { label: 'Pro', color: '#FF385C' },
  agency: { label: 'Agence', color: '#F59E0B' },
  free: { label: 'Free', color: '#94A3B8' },
} satisfies ChartConfig;

// ---------- Libellés / formats (badges dark-safe : teinte conservée + variantes dark) ----------
const PAYMENT_META: Record<string, { label: string; className: string }> = {
  PAID: {
    label: 'Payée',
    className:
      'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300',
  },
  UNPAID: {
    label: 'Impayée',
    className:
      'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300',
  },
  REFUNDED: {
    label: 'Remboursée',
    className:
      'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-500/10 dark:border-rose-500/30 dark:text-rose-300',
  },
  FAILED: { label: 'Échec', className: 'bg-muted border-border text-muted-foreground' },
};

const ORDER_STATUS_META: Record<string, { label: string; className: string }> = {
  PENDING: { label: 'En attente', className: 'bg-muted border-border text-muted-foreground' },
  CONFIRMED: {
    label: 'Confirmée',
    className:
      'bg-teal-50 border-teal-200 text-teal-700 dark:bg-teal-500/10 dark:border-teal-500/30 dark:text-teal-300',
  },
  PREPARING: {
    label: 'En préparation',
    className:
      'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300',
  },
  DELIVERED: {
    label: 'Livrée',
    className:
      'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300',
  },
  CANCELLED: {
    label: 'Annulée',
    className:
      'bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-500/10 dark:border-rose-500/30 dark:text-rose-300',
  },
};

function planLabel(plan: string | null): { label: string; className: string } {
  switch (plan) {
    case 'airbnb_solo':
      return {
        label: 'Solo',
        className:
          'bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300',
      };
    case 'airbnb_pro':
      return {
        label: 'Pro',
        className: 'bg-slate-900 border-slate-900 text-white dark:bg-white dark:border-white dark:text-slate-900',
      };
    case 'agency':
      return {
        label: 'Agence',
        className:
          'bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300',
      };
    default:
      return { label: 'Free', className: 'bg-muted border-border text-muted-foreground' };
  }
}

const ACTION_META: Record<string, { emoji: string; label: string }> = {
  qr_created: { emoji: '➕', label: 'QR code créé' },
  qr_updated: { emoji: '✏️', label: 'QR code modifié' },
  wifi_updated: { emoji: '📶', label: 'Wi-Fi mis à jour' },
  guidebook_updated: { emoji: '📖', label: 'Guidebook mis à jour' },
  scan: { emoji: '📡', label: 'Scan de la plaque' },
  voice_received: { emoji: '🎙️', label: 'Message vocal reçu' },
  complaint: { emoji: '🚨', label: 'Réclamation voyageur' },
  service_ordered: { emoji: '🥐', label: 'Service commandé' },
  property_created: { emoji: '🏠', label: 'Bien ajouté' },
  host_login: { emoji: '🔑', label: 'Connexion hôte' },
};

function actionMeta(type: string) {
  return ACTION_META[type] ?? { emoji: '•', label: type };
}

// ---------- Flux temps réel fusionné (activités + activations plaques) ----------
interface FeedItem {
  id: string;
  emoji: string;
  label: string;
  who: string;
  detail: string | null;
  createdAt: string;
}

function buildFeed(data: KpisData): FeedItem[] {
  const activities: FeedItem[] = data.recentActivity.map((a) => {
    const meta = actionMeta(a.actionType);
    return {
      id: a.id,
      emoji: meta.emoji,
      label: meta.label,
      who: a.userName ?? 'Système',
      detail: a.propertyName,
      createdAt: a.createdAt,
    };
  });
  const activations: FeedItem[] = data.recentActivations.map((a) => ({
    id: a.id,
    emoji: '🏷️',
    label: 'Plaque activée',
    who: a.userName ?? 'Système',
    detail: `${a.activationCode}${a.hubSlug ? ` · /${a.hubSlug}` : ''}`,
    createdAt: a.createdAt,
  }));
  return [...activities, ...activations]
    .sort((x, y) => (x.createdAt < y.createdAt ? 1 : -1))
    .slice(0, 12);
}

const fmtDay = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short' });
const fmtFullDate = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'long',
  year: 'numeric',
});
const fmtDateTime = new Intl.DateTimeFormat('fr-FR', {
  day: 'numeric',
  month: 'short',
  hour: '2-digit',
  minute: '2-digit',
});

function formatDay(iso: string): string {
  return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' }).format(
    new Date(iso),
  );
}

function metaOf<T>(map: Record<string, T>, key: string, fallback: T): T {
  return map[key] ?? fallback;
}

// ---------- Actions rapides (routes console superadmin) ----------
const QUICK_ACTIONS: { href: string; label: string; icon: LucideIcon; bubble: string }[] = [
  { href: '/admin/users', label: 'Clients', icon: Users, bubble: 'kpi-bubble-rausch' },
  { href: '/admin/qr', label: 'Générer des QR', icon: QrCode, bubble: 'kpi-bubble-emerald' },
  { href: '/admin/emails', label: 'Emails', icon: Mail, bubble: 'kpi-bubble-violet' },
  { href: '/admin/providers', label: 'Prestataires', icon: Store, bubble: 'kpi-bubble-teal' },
];

// ---------- Carte KPI « AIRBNB PRO » ----------
type KpiTone = 'rausch' | 'emerald' | 'amber' | 'violet' | 'teal' | 'orange';

const KPI_CARD_TONES: Record<KpiTone, string> = {
  rausch: 'kpi-rausch',
  emerald: 'kpi-emerald',
  amber: 'kpi-amber',
  violet: 'kpi-violet',
  teal: 'kpi-teal',
  orange: 'kpi-orange',
};

const KPI_BUBBLE_TONES: Record<KpiTone, string> = {
  rausch: 'kpi-bubble-rausch',
  emerald: 'kpi-bubble-emerald',
  amber: 'kpi-bubble-amber',
  violet: 'kpi-bubble-violet',
  teal: 'kpi-bubble-teal',
  orange: 'kpi-bubble-orange',
};

function KpiCard({
  label,
  value,
  suffix,
  icon: Icon,
  tone,
  chip,
  hint,
}: {
  label: string;
  value: string;
  suffix?: ReactNode;
  icon: LucideIcon;
  tone: KpiTone;
  chip?: { text: string };
  hint?: string;
}) {
  // Style « AIRBNB PRO » : bulle icône en dégradé + chip tendance,
  // la couleur texte du ton (kpi-*) se propage à valeur/chip/hint.
  return (
    <Card
      className={cn(
        'gap-0 rounded-2xl border-0 bg-transparent p-5 air-shadow air-hoverlift',
        KPI_CARD_TONES[tone],
      )}
      title={hint}
    >
      <div className="flex items-start justify-between gap-2">
        <span
          aria-hidden="true"
          className={cn(
            'flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow',
            KPI_BUBBLE_TONES[tone],
          )}
        >
          <Icon className="h-5 w-5" strokeWidth={2.2} />
        </span>
        {chip && (
          <span className="inline-flex shrink-0 items-center rounded-full bg-white/60 px-2.5 py-0.5 text-[11px] font-bold dark:bg-white/10">
            {chip.text}
          </span>
        )}
      </div>
      <p className="mt-3 truncate text-2xl font-extrabold tabular-nums sm:text-3xl">
        {value}
        {suffix != null && (
          <span className="ml-1 text-sm font-bold opacity-70 sm:text-base">{suffix}</span>
        )}
      </p>
      <p className="mt-0.5 truncate text-sm font-medium opacity-80">{label}</p>
      {hint && <p className="mt-0.5 truncate text-[11px] opacity-70">{hint}</p>}
    </Card>
  );
}

// ---------- Composant principal ----------
export function AdminDashboardContent() {
  const [data, setData] = useState<KpisData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [today, setToday] = useState('');

  useEffect(() => {
    // Après montage uniquement (évite tout écart d'hydratation)
    setToday(fmtFullDate.format(new Date()));
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/admin/kpis');
      if (!res.ok) throw new Error('http');
      setData((await res.json()) as KpisData);
    } catch {
      setError('Impossible de charger les statistiques. Réessayez.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // ----- Loading -----
  if (loading && !data) {
    return (
      <div className="max-w-7xl mx-auto w-full px-4 py-8 space-y-6" aria-busy="true" aria-label="Chargement">
        <Skeleton className="h-36 w-full rounded-3xl" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[72px] rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
          {[0, 1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-40 rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Skeleton className="h-80 rounded-2xl lg:col-span-2" />
          <Skeleton className="h-80 rounded-2xl" />
        </div>
      </div>
    );
  }

  // ----- Erreur -----
  if (error || !data) {
    return (
      <div className="max-w-7xl mx-auto w-full px-4 py-16 flex justify-center">
        <div className="air-empty max-w-md w-full rounded-2xl p-8 text-center" role="alert">
          <p className="text-3xl" aria-hidden="true">😵</p>
          <p className="mt-2 font-semibold text-foreground">Erreur de chargement</p>
          <p className="mt-1 text-sm text-muted-foreground">{error || 'Données indisponibles'}</p>
          <button
            type="button"
            onClick={load}
            className="mt-5 inline-flex items-center justify-center rounded-full px-6 py-2.5 text-sm font-semibold text-white air-gradient shadow transition-opacity hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  const { stats, series, paymentDistribution, categoryRevenue, providerRevenue } = data;
  const refundRate =
    stats.ordersPaid + stats.ordersRefunded > 0
      ? Math.round((stats.ordersRefunded / (stats.ordersPaid + stats.ordersRefunded)) * 100)
      : 0;
  const maxProviderGmv = Math.max(...providerRevenue.map((p) => p.gmv), 1);
  const totalOrdersForDonut = paymentDistribution.reduce((acc, d) => acc + d.count, 0);
  const feed = buildFeed(data);

  return (
    <div className="max-w-7xl mx-auto w-full px-4 py-8 space-y-6">
      {/* ================= Hero « AIRBNB PRO » ================= */}
      <section
        aria-labelledby="admin-greeting"
        className="air-gradient-deep relative overflow-hidden rounded-3xl air-shadow-lg p-6 text-white sm:p-8"
      >
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -right-20 -top-28 h-72 w-72 rounded-full bg-white/10 blur-3xl"
        />
        <span
          aria-hidden="true"
          className="pointer-events-none absolute -bottom-24 left-1/3 h-56 w-56 rounded-full bg-white/5 blur-3xl"
        />
        <div className="relative flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <h2 id="admin-greeting" className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Vue d&apos;ensemble 🛡️
            </h2>
            <p className="mt-1.5 text-sm text-white/80">
              Santé de la plateforme Conciergerie Hub{today ? ` — ${today}` : ''}.
            </p>
          </div>
          <Button
            variant="ghost"
            onClick={() => {
              load();
              toast.success('Statistiques actualisées');
            }}
            className="rounded-full border border-white/30 text-white hover:bg-white/15 hover:text-white dark:hover:bg-white/15"
          >
            Actualiser
          </Button>
        </div>
        <div className="relative mt-5 flex flex-wrap gap-2">
          <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold">
            💳 {stats.ordersPaid} commande{stats.ordersPaid > 1 ? 's' : ''} payée
            {stats.ordersPaid > 1 ? 's' : ''}
          </span>
          <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold">
            👩‍💻 {stats.activeHosts} hôte{stats.activeHosts > 1 ? 's' : ''} actif
            {stats.activeHosts > 1 ? 's' : ''}
          </span>
          <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold">
            🏠 {stats.activePropertiesCount} bien{stats.activePropertiesCount > 1 ? 's' : ''} actif
            {stats.activePropertiesCount > 1 ? 's' : ''}
          </span>
        </div>
      </section>

      {/* ================= Actions rapides ================= */}
      <section aria-label="Actions rapides" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {QUICK_ACTIONS.map((action) => (
          <Link
            key={action.href}
            href={action.href}
            className="group flex items-center gap-3 rounded-2xl border border-border bg-card p-4 air-shadow air-hoverlift"
          >
            <span
              aria-hidden="true"
              className={cn(
                'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow',
                action.bubble,
              )}
            >
              <action.icon className="h-[18px] w-[18px]" strokeWidth={2.2} />
            </span>
            <span className="min-w-0 flex-1 truncate text-sm font-semibold text-foreground">
              {action.label}
            </span>
            <ChevronRight
              aria-hidden="true"
              className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-0.5"
            />
          </Link>
        ))}
      </section>

      {/* ================= KPIs principaux ================= */}
      <section aria-label="KPIs financiers" className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard
          label="GMV encaissée"
          value={formatEur(stats.gmvPaidEur)}
          icon={CreditCard}
          tone="rausch"
          chip={{ text: `${formatEur(stats.gmv30dEur)} sur 30 j` }}
          hint={`${stats.ordersPaid} commande${stats.ordersPaid > 1 ? 's' : ''} payée${stats.ordersPaid > 1 ? 's' : ''} · panier moyen ${formatEur(stats.avgOrderEur)}`}
        />
        <KpiCard
          label="Revenus plateforme"
          value={formatEur(stats.platformRevenueEur)}
          icon={Landmark}
          tone="emerald"
          chip={{ text: 'Commission 15 %' }}
          hint={`Part reversée aux hôtes : ${formatEur(stats.hostEarningsEur)}`}
        />
        <KpiCard
          label="MRR abonnements"
          value={formatEur(stats.mrrEur)}
          icon={PiggyBank}
          tone="violet"
          chip={
            stats.subscriptionsActive > 0
              ? { text: `${stats.subscriptionsActive} abonnement${stats.subscriptionsActive > 1 ? 's' : ''} actif${stats.subscriptionsActive > 1 ? 's' : ''}` }
              : { text: 'Aucun abonnement' }
          }
          hint="Revenu mensuel récurrent normalisé"
        />
        <KpiCard
          label="Hôtes actifs"
          value={String(stats.activeHosts)}
          icon={Users}
          tone="amber"
          chip={{ text: `${stats.totalHosts} inscrit${stats.totalHosts > 1 ? 's' : ''}` }}
          hint={stats.newHosts30d > 0 ? `+${stats.newHosts30d} nouveau${stats.newHosts30d > 1 ? 'x' : ''} sur 30 jours` : 'Aucun nouveau hôte sur 30 jours'}
        />
      </section>

      {/* ================= KPIs secondaires ================= */}
      <section aria-label="KPIs opérationnels" className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <KpiCard
          label="Biens actifs"
          value={String(stats.activePropertiesCount)}
          suffix={<>/ {stats.propertiesCount}</>}
          icon={Home}
          tone="teal"
          hint="Biens équipés d'une plaque QR"
        />
        <KpiCard
          label="Plaques activées"
          value={String(stats.plaquesActive)}
          suffix={<>/ {stats.plaquesTotal}</>}
          icon={Tag}
          tone="orange"
          hint={`${stats.plaquesInactive} inactive${stats.plaquesInactive > 1 ? 's' : ''} · ${stats.plaquesLost} perdue${stats.plaquesLost > 1 ? 's' : ''}`}
        />
        <KpiCard
          label="Prestataires actifs"
          value={String(stats.providersActive)}
          suffix={<>/ {stats.providersTotal}</>}
          icon={Wrench}
          tone="emerald"
          hint={`🔧 ${stats.providersOwner} owner · 🥂 ${stats.providersGuest} guest`}
        />
        <KpiCard
          label="Séjours en cours"
          value={String(stats.bookingsActive)}
          suffix={<>+ {stats.bookingsUpcoming} à venir</>}
          icon={CalendarDays}
          tone="rausch"
          hint="Check-ins en cours et confirmés"
        />
        <KpiCard
          label="Commandes 30 j"
          value={String(stats.orders30d)}
          suffix={<>/ {stats.ordersTotal}</>}
          icon={ShoppingCart}
          tone="amber"
          hint={`${stats.ordersRefunded} remboursée${stats.ordersRefunded > 1 ? 's' : ''} (${refundRate} %)`}
        />
      </section>

      {/* ================= Graphiques ================= */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ----- Tendance 30 j : GMV + commission ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6 lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-semibold text-foreground">Revenus des 30 derniers jours</p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Volume acheté par les invités (GMV) et commission retenue par la plateforme
              </p>
            </div>
          </div>
          <ChartContainer config={revenueConfig} className="mt-4 h-72 w-full">
            <ComposedChart data={series} margin={{ left: 4, right: 8, top: 8 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                minTickGap={28}
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                width={44}
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickFormatter={(v: number) => `${Math.round(v)}€`}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    labelFormatter={(_p, payload) => {
                      const raw = payload?.[0]?.payload as { date?: string } | undefined;
                      return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                    }}
                  />
                }
              />
              <Bar dataKey="gmv" fill="var(--color-gmv)" radius={[4, 4, 0, 0]} maxBarSize={28} />
              <Line
                dataKey="commission"
                type="monotone"
                stroke="var(--color-commission)"
                strokeWidth={2.5}
                dot={false}
              />
            </ComposedChart>
          </ChartContainer>
        </Card>

        {/* ----- Donut statuts de paiement ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <p className="font-semibold text-foreground">Statuts de paiement</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Répartition des {totalOrdersForDonut} commandes</p>
          <div className="relative mt-4">
            <ChartContainer config={paymentConfig} className="h-56 w-full">
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent nameKey="key" />} />
                <Pie
                  data={paymentDistribution}
                  dataKey="count"
                  nameKey="key"
                  innerRadius={58}
                  outerRadius={88}
                  strokeWidth={3}
                  paddingAngle={2}
                >
                  {paymentDistribution.map((entry) => (
                    <Cell key={entry.key} fill={`var(--color-${entry.key})`} />
                  ))}
                </Pie>
              </PieChart>
            </ChartContainer>
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <p className="text-2xl font-bold tabular-nums text-foreground">{totalOrdersForDonut}</p>
                <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">commandes</p>
              </div>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {paymentDistribution.map((d) => {
              const meta = metaOf(PAYMENT_META, d.key, {
                label: d.key,
                className: 'bg-muted border-border text-muted-foreground',
              });
              if (d.count === 0) return null;
              return (
                <span
                  key={d.key}
                  className={cn(
                    'inline-flex text-[11px] font-semibold px-2 py-0.5 rounded-full border',
                    meta.className,
                  )}
                >
                  {meta.label} : {d.count}
                </span>
              );
            })}
          </div>
        </Card>
      </section>

      {/* ================= Croissance & abonnements ================= */}
      <section aria-label="Croissance et abonnements" className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ----- Courbe d'inscriptions hôtes 30 j ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="font-semibold text-foreground">Inscriptions des hôtes</p>
              <p className="mt-0.5 text-xs text-muted-foreground">Nouveaux comptes créés sur les 30 derniers jours</p>
            </div>
            <span className="inline-flex text-[11px] font-semibold px-2 py-0.5 rounded-full border bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-500/10 dark:border-emerald-500/30 dark:text-emerald-300">
              +{stats.newHosts30d} sur 30 j
            </span>
          </div>
          <ChartContainer config={signupConfig} className="mt-4 h-64 w-full">
            <AreaChart data={data.hostSignupTrend} margin={{ left: 4, right: 8, top: 8 }}>
              <defs>
                <linearGradient id="fillSignups" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="var(--color-count)" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="var(--color-count)" stopOpacity={0.03} />
                </linearGradient>
              </defs>
              <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="date"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                minTickGap={28}
                tick={{ fontSize: 11, fill: '#64748b' }}
                tickFormatter={(v: string) => fmtDay.format(new Date(`${v}T12:00:00`))}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                width={32}
                allowDecimals={false}
                tick={{ fontSize: 11, fill: '#64748b' }}
              />
              <ChartTooltip
                content={
                  <ChartTooltipContent
                    labelFormatter={(_p, payload) => {
                      const raw = payload?.[0]?.payload as { date?: string } | undefined;
                      return raw?.date ? fmtFullDate.format(new Date(`${raw.date}T12:00:00`)) : '';
                    }}
                  />
                }
              />
              <Area
                dataKey="count"
                type="monotone"
                stroke="var(--color-count)"
                strokeWidth={2.5}
                fill="url(#fillSignups)"
                dot={false}
              />
            </AreaChart>
          </ChartContainer>
        </Card>

        {/* ----- Répartition des abonnements (Solo vs Pro) ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <p className="font-semibold text-foreground">Répartition des abonnements</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Comptes hôtes par plan sélectionné</p>
          {data.planDistribution.length === 0 ? (
            <div className="air-empty mt-4 rounded-2xl px-4 py-10 text-center">
              <p className="text-2xl" aria-hidden="true">🐣</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucun hôte inscrit pour le moment.</p>
            </div>
          ) : (
            <>
              <div className="relative mt-4">
                <ChartContainer config={planConfig} className="h-56 w-full">
                  <PieChart>
                    <ChartTooltip content={<ChartTooltipContent nameKey="plan" />} />
                    <Pie
                      data={data.planDistribution}
                      dataKey="count"
                      nameKey="plan"
                      innerRadius={58}
                      outerRadius={88}
                      strokeWidth={3}
                      paddingAngle={2}
                    >
                      {data.planDistribution.map((entry) => (
                        <Cell key={entry.plan} fill={`var(--color-${entry.plan})`} />
                      ))}
                    </Pie>
                  </PieChart>
                </ChartContainer>
                <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-2xl font-bold tabular-nums text-foreground">{stats.totalHosts}</p>
                    <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">hôtes</p>
                  </div>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {data.planDistribution.map((p) => {
                  const meta = planLabel(p.plan === 'airbnb_solo' || p.plan === 'airbnb_pro' || p.plan === 'agency' ? p.plan : 'free');
                  return (
                    <span
                      key={p.plan}
                      className="inline-flex text-[11px] font-semibold px-2 py-0.5 rounded-full border bg-muted border-border text-muted-foreground"
                    >
                      {meta.label} : {p.count}
                    </span>
                  );
                })}
              </div>
            </>
          )}
        </Card>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* ----- GMV par catégorie ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <p className="font-semibold text-foreground">GMV par catégorie</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Chiffre d&apos;affaires invités par type de prestation</p>
          {categoryRevenue.length === 0 ? (
            <div className="air-empty mt-4 rounded-2xl px-4 py-10 text-center">
              <p className="text-2xl" aria-hidden="true">📊</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucune commande payée pour le moment.</p>
            </div>
          ) : (
            <ChartContainer config={categoryConfig} className="mt-4 h-64 w-full">
              <BarChart layout="vertical" data={categoryRevenue} margin={{ left: 8, right: 16, top: 4 }}>
                <CartesianGrid horizontal={false} strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  type="number"
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  tickFormatter={(v: number) => `${Math.round(v)}€`}
                />
                <YAxis
                  type="category"
                  dataKey="label"
                  width={150}
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 11, fill: '#475569' }}
                />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="gmv" fill="var(--color-gmv)" radius={[0, 6, 6, 0]} maxBarSize={22} />
              </BarChart>
            </ChartContainer>
          )}
        </Card>

        {/* ----- Top prestataires ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <p className="font-semibold text-foreground">Top prestataires</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Classement par GMV encaissée (commandes payées)</p>
          {providerRevenue.length === 0 ? (
            <div className="air-empty mt-4 rounded-2xl px-4 py-10 text-center">
              <p className="text-2xl" aria-hidden="true">🏆</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucune commande payée pour le moment.</p>
            </div>
          ) : (
            <ul className="mt-4 space-y-3.5">
              {providerRevenue.map((p, i) => (
                <li key={p.name} className="group">
                  <div className="flex items-center justify-between gap-3 text-sm">
                    <span className="flex items-center gap-2 min-w-0 font-medium text-foreground">
                      <span
                        aria-hidden="true"
                        className={cn(
                          'flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[11px] font-bold',
                          i === 0 ? 'kpi-bubble-rausch text-white shadow' : 'bg-muted text-muted-foreground',
                        )}
                      >
                        {i + 1}
                      </span>
                      <span className="truncate">{p.name}</span>
                    </span>
                    <span className="shrink-0 text-right">
                      <span className="font-bold tabular-nums text-foreground">{formatEur(p.gmv)}</span>
                      <span className="ml-1.5 text-[11px] text-muted-foreground">{p.orders} cmd</span>
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 rounded-full bg-muted overflow-hidden">
                    <div
                      className="air-gradient h-full rounded-full"
                      style={{ width: `${Math.max((p.gmv / maxProviderGmv) * 100, 6)}%` }}
                    />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </section>

      {/* ================= Commandes + activité ================= */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* ----- Dernières commandes ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6 lg:col-span-2">
          <p className="font-semibold text-foreground">Dernières commandes</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Les 8 dernières commandes passées depuis les QR Hubs</p>
          {data.recentOrders.length === 0 ? (
            <div className="air-empty mt-4 rounded-2xl px-4 py-10 text-center">
              <p className="text-2xl" aria-hidden="true">🛒</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucune commande pour le moment.</p>
            </div>
          ) : (
            <div className="mt-4 max-h-96 overflow-y-auto rounded-2xl border border-border">
              <Table>
                <TableHeader className="sticky top-0 z-10 bg-muted">
                  <TableRow>
                    <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Invité</TableHead>
                    <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Prestation</TableHead>
                    <TableHead className="text-right text-xs uppercase tracking-wide text-muted-foreground">Montant</TableHead>
                    <TableHead className="text-right text-xs uppercase tracking-wide text-muted-foreground">Commission</TableHead>
                    <TableHead className="text-xs uppercase tracking-wide text-muted-foreground">Paiement</TableHead>
                    <TableHead className="text-right text-xs uppercase tracking-wide text-muted-foreground">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.recentOrders.map((o) => {
                    const pay = metaOf(PAYMENT_META, o.paymentStatus, {
                      label: o.paymentStatus,
                      className: 'bg-muted border-border text-muted-foreground',
                    });
                    return (
                      <TableRow key={o.id} className="hover:bg-muted/50">
                        <TableCell className="font-medium text-foreground whitespace-nowrap">
                          {o.guestName}
                        </TableCell>
                        <TableCell className="max-w-[180px]">
                          <p className="truncate text-foreground">{o.itemName}</p>
                          <p className="truncate text-[11px] text-muted-foreground">{o.providerName}</p>
                        </TableCell>
                        <TableCell className="text-right font-semibold text-foreground tabular-nums whitespace-nowrap">
                          {formatEur(o.totalAmount)}
                        </TableCell>
                        <TableCell className="text-right text-emerald-700 dark:text-emerald-400 font-medium tabular-nums whitespace-nowrap">
                          {formatEur(o.commission)}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={cn('font-semibold', pay.className)}>
                            {pay.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right text-[11px] text-muted-foreground whitespace-nowrap">
                          {fmtDateTime.format(new Date(o.createdAt))}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </Card>

        {/* ----- Flux temps réel fusionné ----- */}
        <Card className="rounded-2xl border-border bg-card air-shadow p-5 sm:p-6">
          <p className="font-semibold text-foreground">Dernières activités</p>
          <p className="mt-0.5 text-xs text-muted-foreground">Activations de plaques, scans &amp; actions hôtes — temps réel</p>
          {feed.length === 0 ? (
            <div className="air-empty mt-4 rounded-2xl px-4 py-10 text-center">
              <p className="text-2xl" aria-hidden="true">📡</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucune activité enregistrée pour le moment.</p>
            </div>
          ) : (
            <ul className="mt-2 divide-y divide-border -mx-2 max-h-96 overflow-y-auto">
              {feed.map((a) => (
                <li key={a.id} className="flex items-start gap-3 px-2 py-3 hover:bg-muted/50 transition-colors rounded-lg">
                  <span
                    aria-hidden="true"
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-lg leading-none select-none"
                  >
                    {a.emoji}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-foreground">{a.label}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {a.who}
                      {a.detail ? ` · ${a.detail}` : ''}
                    </p>
                  </div>
                  <span className="text-[11px] text-muted-foreground shrink-0">
                    {fmtDateTime.format(new Date(a.createdAt))}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </section>

      {/* ================= Derniers hôtes ================= */}
      <section aria-label="Derniers hôtes inscrits">
        <Card className="gap-0 overflow-hidden rounded-2xl border-border bg-card p-0 air-shadow">
          <div className="flex items-start gap-3 px-5 pb-3 pt-5 sm:px-6">
            <span
              aria-hidden="true"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-lg leading-none select-none"
            >
              🆕
            </span>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-foreground leading-tight">Derniers hôtes inscrits</p>
              <p className="mt-0.5 text-xs text-muted-foreground leading-relaxed">Les 6 comptes hôtes les plus récents</p>
            </div>
          </div>
          {data.recentHosts.length === 0 ? (
            <div className="air-empty mx-5 mb-5 rounded-2xl px-4 py-8 text-center sm:mx-6">
              <p className="text-2xl" aria-hidden="true">🧑‍💻</p>
              <p className="mt-2 text-sm text-muted-foreground">Aucun hôte inscrit pour le moment.</p>
            </div>
          ) : (
            <ul className="max-h-96 divide-y divide-border overflow-y-auto">
              {data.recentHosts.map((h) => {
                const plan = planLabel(h.selectedPlan);
                return (
                  <li key={h.id} className="flex items-center gap-3 px-5 py-3 hover:bg-muted/50 transition-colors sm:px-6">
                    <span
                      aria-hidden="true"
                      className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-border bg-muted text-xs font-bold text-muted-foreground"
                    >
                      {(h.fullName ?? h.email).slice(0, 2).toUpperCase()}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-foreground truncate">
                        {h.fullName ?? 'Sans nom'}
                        {!h.isActive && (
                          <span className="ml-2 text-[11px] font-semibold text-red-600 dark:text-red-400">· désactivé</span>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">{h.email}</p>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <Badge className={cn('font-semibold', plan.className)} variant="outline">
                        {plan.label}
                      </Badge>
                      <span className="text-[11px] text-muted-foreground">
                        {h.propertyCount} bien{h.propertyCount > 1 ? 's' : ''} · {formatDay(h.createdAt)}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </section>

      {/* ================= Rappel règle d'or ================= */}
      <section aria-label="Règle de gestion des prestataires" className="pb-4">
        <div className="air-shadow rounded-2xl border border-emerald-200/70 bg-emerald-50/60 p-5 dark:border-emerald-500/30 dark:bg-emerald-500/10">
          <div className="flex items-start gap-3">
            <span
              aria-hidden="true"
              className="kpi-bubble-emerald flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg leading-none text-white shadow select-none"
            >
              🛡️
            </span>
            <div>
              <p className="text-sm font-semibold text-emerald-900 dark:text-emerald-200">Règle d&apos;or — Prestataires</p>
              <p className="mt-0.5 text-xs text-emerald-800 dark:text-emerald-300/90 leading-relaxed">
                Seul le Superadmin (vous) ajoute et géolocalise les prestataires. Les hôtes les consultent
                depuis leur dashboard, et les voyageurs découvrent les expériences via le QR Hub.
                Gestion complète : <span className="font-semibold">menu Prestataires</span> dans la barre latérale.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
