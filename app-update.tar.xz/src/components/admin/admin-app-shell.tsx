'use client';

import { type CSSProperties, type ReactNode, useState } from 'react';
import { usePathname } from 'next/navigation';
import { signOut } from 'next-auth/react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { AdminAppSidebar } from '@/components/admin/admin-app-sidebar';
import { AdminGlobalSearch } from '@/components/admin/admin-global-search';
import { AdminNotifications } from '@/components/admin/admin-notifications';
import { SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { Toaster } from '@/components/ui/sonner';

// =============================================================
// AdminAppShell — v8.0 « ENCRE NOIRE + THÈMES RÉELS » (refonte
// design client) : fond lavande clair #E4E9F7 en mode clair, fond
// nuit saphir #070D1F en mode sombre (le bouton sombre/clair de la
// sidebar fonctionne désormais RÉELLEMENT), police NOIRE en clair
// via la couche .ink-scope (globals.css). Topbar translucide
// arrondie, sidebar bleue à icônes, footer discret. Aucune
// fonctionnalité retirée.
// =============================================================

const SECTION_TITLES: { match: (p: string) => boolean; title: string }[] = [
  { match: (p) => p === '/admin' || p.startsWith('/admin/dashboard'), title: 'Tableau de bord' },
  { match: (p) => p.startsWith('/admin/users'), title: 'Clients & Hôtes' },
  { match: (p) => p.startsWith('/admin/hosts'), title: 'Biens & Plaques' },
  { match: (p) => p.startsWith('/admin/subscriptions'), title: 'Abonnements' },
  { match: (p) => p.startsWith('/admin/qr'), title: 'Générateur QR' },
  { match: (p) => p.startsWith('/admin/providers'), title: 'Prestataires' },
  { match: (p) => p.startsWith('/admin/transactions'), title: 'Transactions' },
  { match: (p) => p.startsWith('/admin/emails'), title: 'Emails' },
  { match: (p) => p.startsWith('/admin/assistance'), title: 'Assistance' },
  { match: (p) => p.startsWith('/admin/content'), title: 'Contenu universel' },
  { match: (p) => p.startsWith('/admin/logs'), title: 'Logs & Tickets' },
  { match: (p) => p.startsWith('/admin/settings'), title: 'Paramètres' },
];

interface AdminAppShellProps {
  children: ReactNode;
  adminName: string;
  adminEmail: string;
}

export function AdminAppShell({ children, adminName, adminEmail }: AdminAppShellProps) {
  const pathname = usePathname();
  const section = SECTION_TITLES.find((s) => s.match(pathname));
  const [menuOpen, setMenuOpen] = useState(false);

  // Sidebar icône ≈ 76px (spéc client : rail bleu à icônes)
  const providerStyle = {
    '--sidebar-width-icon': '4.75rem',
  } as CSSProperties;

  return (
    <SidebarProvider style={providerStyle}>
      <AdminAppSidebar adminName={adminName} adminEmail={adminEmail} />
      <SidebarInset className="ink-scope min-h-svh flex flex-col bg-[#E4E9F7] text-slate-800 dark:bg-[#070D1F] dark:text-[#E8EEFA]">
        {/* ----- Topbar blanche translucide arrondie ----- */}
        <header className="sticky top-0 z-40 shrink-0 px-3 pt-3 sm:px-5 sm:pt-4">
          <div className="flex h-16 items-center gap-2 rounded-2xl border border-white/70 bg-white/80 px-3 shadow-[0_10px_40px_-12px_rgba(37,99,235,0.15)] backdrop-blur-xl dark:border-white/10 sm:gap-3 sm:px-5">
            <SidebarTrigger
              aria-label="Afficher ou masquer le menu"
              className="rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-800"
            />
            <div className="hidden min-w-0 items-center gap-2.5 lg:flex">
              <h1 className="truncate text-lg font-bold tracking-tight text-slate-800">
                {section?.title ?? 'Console'}
              </h1>
              <span
                className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] text-blue-700 ring-1 ring-blue-200 dark:bg-blue-950/70 dark:text-blue-200 dark:ring-blue-800/60"
                title="Session Superadmin"
              >
                Superadmin
              </span>
            </div>

            <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
              <AdminGlobalSearch />
              <AdminNotifications />

              {/* ----- Menu profil ----- */}
              <DropdownMenu open={menuOpen} onOpenChange={setMenuOpen}>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="Menu du profil"
                    aria-haspopup="menu"
                    className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#4A8BFF] to-[#2563EB] text-xs font-bold text-white ring-2 ring-blue-200 transition-transform hover:scale-105 sm:h-9 sm:w-9"
                  >
                    {adminName
                      .trim()
                      .split(/\s+/)
                      .slice(0, 2)
                      .map((w) => w[0]?.toUpperCase() ?? '')
                      .join('') || 'SA'}
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-60 rounded-2xl">
                  <DropdownMenuLabel>
                    <p className="truncate text-sm font-bold text-slate-800">{adminName}</p>
                    <p className="truncate text-xs font-normal text-slate-400">{adminEmail}</p>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => signOut({ callbackUrl: '/' })}
                    className="cursor-pointer rounded-xl text-red-600 focus:bg-red-50 focus:text-red-600"
                  >
                    Se déconnecter
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* ----- Contenu ----- */}
        <main className="w-full flex-1 text-slate-800">{children}</main>

        {/* ----- Footer copyright (collé en bas : mt-auto) ----- */}
        <footer className="mt-auto px-4 pb-4 pt-6">
          <p className="text-center text-xs font-medium text-slate-400">
            Copyright ©{' '}
            <span className="font-bold text-slate-600">
              RoomScan
            </span>{' '}
            2025 — Centre de contrôle de la plateforme, accès restreint
          </p>
        </footer>

        <Toaster position="top-center" richColors />
      </SidebarInset>
    </SidebarProvider>
  );
}
