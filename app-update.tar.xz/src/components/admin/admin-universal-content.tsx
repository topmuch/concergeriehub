// =============================================================
// AdminUniversalContent — Éditeur « 📚 Contenu universel » (v4.47)
// -------------------------------------------------------------
// Le Superadmin définit le contenu de référence partagé par TOUTES
// les maisons de la plateforme :
//   1. 📖 Guidebook universel  (titre + sections) — affiché dans les
//      hubs sans guidebook propre, importable en 1 clic côté hôte.
//   2. 🛠️ Pack universel d'appareils (nom + emoji + instructions) —
//      affiché comme Guide des appareils si l'hôte n'a rien saisi,
//      importable en 1 clic dans la Conciergerie.
// API : GET/PUT /api/admin/universal-content (Superadmin, audit).
// =============================================================
'use client';

import { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Loader2, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Skeleton } from '@/components/ui/skeleton';

interface UniversalAppliance {
  id: string;
  name: string;
  emoji?: string;
  instructions: string;
  videoUrl?: string;
  imageUrl?: string;
}

interface UniversalGuidebook {
  title: string;
  sections: string[];
}

interface UniversalContent {
  guidebook: UniversalGuidebook;
  appliances: UniversalAppliance[];
}

function newRowKey(): string {
  try {
    return crypto.randomUUID().slice(0, 8);
  } catch {
    return Math.random().toString(36).slice(2, 10);
  }
}

export function AdminUniversalContent() {
  const [content, setContent] = useState<UniversalContent | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/universal-content');
      const json = (await res.json().catch(() => null)) as {
        ok?: boolean;
        content?: UniversalContent;
        error?: string;
      } | null;
      if (!res.ok || !json?.ok || !json.content) {
        toast.error(json?.error || 'Chargement impossible.');
        return;
      }
      setContent(json.content);
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const save = async () => {
    if (!content) return;
    if (!content.guidebook.title.trim()) {
      toast.error('Le guidebook universel doit avoir un titre.');
      return;
    }
    const cleanSections = content.guidebook.sections.map((s) => s.trim()).filter(Boolean);
    if (cleanSections.length === 0) {
      toast.error('Ajoutez au moins une section au guidebook universel.');
      return;
    }
    for (const a of content.appliances) {
      if (!a.name.trim()) {
        toast.error('Chaque appareil du pack universel doit avoir un nom.');
        return;
      }
    }
    setSaving(true);
    try {
      const res = await fetch('/api/admin/universal-content', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guidebook: { title: content.guidebook.title.trim(), sections: cleanSections },
          appliances: content.appliances.map((a, i) => ({
            id: a.id || `ua-${i + 1}`,
            name: a.name.trim(),
            emoji: a.emoji?.trim() || '🛠️',
            instructions: a.instructions.trim() || '—',
            // v4.48 — préserver photo + vidéo (elles étaient perdues à la sauvegarde).
            imageUrl: a.imageUrl?.trim() || undefined,
            videoUrl: a.videoUrl?.trim() || undefined,
          })),
        }),
      });
      const json = (await res.json().catch(() => null)) as {
        ok?: boolean;
        content?: UniversalContent;
        error?: string;
        message?: string;
      } | null;
      if (!res.ok || !json?.ok) {
        toast.error(json?.error || 'Échec de la sauvegarde.');
        return;
      }
      if (json.content) setContent(json.content);
      toast.success(json.message || 'Contenu universel enregistré ✅');
    } catch {
      toast.error('Connexion impossible. Réessayez.');
    } finally {
      setSaving(false);
    }
  };

  // ── Handlers guidebook ──
  const setTitle = (title: string) =>
    setContent((c) => (c ? { ...c, guidebook: { ...c.guidebook, title } } : c));
  const setSection = (i: number, value: string) =>
    setContent((c) =>
      c
        ? {
            ...c,
            guidebook: {
              ...c.guidebook,
              sections: c.guidebook.sections.map((s, idx) => (idx === i ? value : s)),
            },
          }
        : c,
    );
  const addSection = () =>
    setContent((c) =>
      c ? { ...c, guidebook: { ...c.guidebook, sections: [...c.guidebook.sections, ''] } } : c,
    );
  const removeSection = (i: number) =>
    setContent((c) =>
      c
        ? {
            ...c,
            guidebook: {
              ...c.guidebook,
              sections: c.guidebook.sections.filter((_, idx) => idx !== i),
            },
          }
        : c,
    );

  // ── Handlers appareils ──
  const setAppliance = (id: string, patch: Partial<UniversalAppliance>) =>
    setContent((c) =>
      c
        ? {
            ...c,
            appliances: c.appliances.map((a) => (a.id === id ? { ...a, ...patch } : a)),
          }
        : c,
    );
  const addAppliance = () =>
    setContent((c) =>
      c
        ? {
            ...c,
            appliances: [...c.appliances, { id: newRowKey(), name: '', emoji: '🛠️', instructions: '' }],
          }
        : c,
    );
  const removeAppliance = (id: string) =>
    setContent((c) =>
      c ? { ...c, appliances: c.appliances.filter((a) => a.id !== id) } : c,
    );

  return (
    <div className="mx-auto max-w-4xl space-y-6 p-4 sm:p-6">
      {/* ── En-tête ── */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-bold text-slate-900">📚 Contenu universel</h2>
        <p className="mt-1 text-sm leading-relaxed text-slate-500">
          Ce contenu de référence s&apos;affiche dans <strong>toutes les maisons</strong> de la
          plateforme dont l&apos;hôte n&apos;a pas encore rempli son propre guidebook ou son guide
          des appareils. Les hôtes peuvent aussi l&apos;importer en 1 clic puis le personnaliser.
        </p>
      </div>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-40 w-full rounded-2xl" />
          <Skeleton className="h-64 w-full rounded-2xl" />
        </div>
      ) : !content ? (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-sm font-semibold text-red-700">
          Contenu indisponible — rechargez la page.
        </div>
      ) : (
        <>
          {/* ── 1. Guidebook universel ── */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Guidebook universel">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <h3 className="text-base font-bold text-slate-900">📖 Guidebook universel</h3>
                <p className="mt-0.5 text-xs text-slate-500">
                  Guide de bienvenue générique — première ligne de chaque section = titre.
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addSection}
                disabled={saving || content.guidebook.sections.length >= 20}
                className="gap-1.5"
              >
                <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter une section
              </Button>
            </div>

            <div className="mt-4 space-y-1.5">
              <Label htmlFor="ug-title">Titre du guide</Label>
              <Input
                id="ug-title"
                value={content.guidebook.title}
                onChange={(e) => setTitle(e.target.value)}
                maxLength={120}
                placeholder="Guide universel de la maison"
              />
            </div>

            <div className="mt-4 space-y-2">
              <Label>Sections ({content.guidebook.sections.length})</Label>
              {content.guidebook.sections.map((section, i) => (
                <div key={i} className="relative">
                  <Textarea
                    value={section}
                    onChange={(e) => setSection(i, e.target.value)}
                    rows={4}
                    maxLength={2000}
                    aria-label={`Section ${i + 1} du guidebook universel`}
                    className="min-h-[96px] pr-10 text-sm"
                    placeholder={`Section ${i + 1} — ex : 👋 Bienvenue !\nNous sommes ravis de vous accueillir…`}
                  />
                  <button
                    type="button"
                    onClick={() => removeSection(i)}
                    aria-label={`Supprimer la section ${i + 1}`}
                    disabled={saving}
                    className="absolute top-2 right-2 inline-flex h-7 w-7 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-400 transition-colors hover:border-red-200 hover:text-red-600"
                  >
                    <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* ── 2. Pack universel d'appareils ── */}
          <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm" aria-label="Pack universel d'appareils">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div>
                <h3 className="text-base font-bold text-slate-900">🛠️ Pack universel d&apos;appareils</h3>
                <p className="mt-0.5 text-xs text-slate-500">
                  Catalogue d&apos;appareils courants avec instructions génériques.
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addAppliance}
                disabled={saving || content.appliances.length >= 40}
                className="gap-1.5"
              >
                <Plus className="h-4 w-4" aria-hidden="true" /> Ajouter un appareil
              </Button>
            </div>

            <div className="mt-4 space-y-3">
              {content.appliances.map((a, i) => (
                <div key={a.id} className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-2.5">
                  <div className="flex items-center gap-2">
                    {/* v4.48 — vignette de la photo produit universelle embarquée. */}
                    {a.imageUrl ? (
                      <img
                        src={a.imageUrl}
                        alt={`Photo de ${a.name || 'l’appareil'}`}
                        className="h-9 w-9 shrink-0 rounded-lg border border-slate-200 object-cover"
                        loading="lazy"
                        decoding="async"
                      />
                    ) : null}
                    <Input
                      value={a.emoji ?? ''}
                      onChange={(e) => setAppliance(a.id, { emoji: e.target.value })}
                      maxLength={4}
                      className="w-14 text-center"
                      placeholder="🛠️"
                      aria-label={`Emoji de l'appareil ${a.name || i + 1}`}
                    />
                    <Input
                      value={a.name}
                      onChange={(e) => setAppliance(a.id, { name: e.target.value })}
                      maxLength={80}
                      className="flex-1"
                      placeholder="Nom de l'appareil (ex : Machine à café)"
                      aria-label={`Nom de l'appareil ${i + 1}`}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeAppliance(a.id)}
                      aria-label={`Supprimer l'appareil ${a.name || i + 1}`}
                      disabled={saving}
                      className="h-9 w-9 shrink-0 text-slate-400 hover:text-red-600"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden="true" />
                    </Button>
                  </div>
                  <Textarea
                    value={a.instructions}
                    onChange={(e) => setAppliance(a.id, { instructions: e.target.value })}
                    rows={3}
                    maxLength={4000}
                    aria-label={`Instructions de l'appareil ${a.name || i + 1}`}
                    placeholder="Instructions génériques — numérotées, avec astuces…"
                    className="text-sm"
                  />
                </div>
              ))}
            </div>
          </section>

          {/* ── Barre d'enregistrement ── */}
          <div className="sticky bottom-4 flex items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white/95 p-4 shadow-lg backdrop-blur">
            <p className="text-xs text-slate-500">
              {content.guidebook.sections.length} section(s) · {content.appliances.length} appareil(s)
            </p>
            <Button
              type="button"
              onClick={save}
              disabled={saving}
              className="h-11 bg-slate-900 px-6 font-semibold hover:bg-slate-800"
            >
              {saving ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
              ) : null}
              Enregistrer
            </Button>
          </div>
        </>
      )}
    </div>
  );
}
